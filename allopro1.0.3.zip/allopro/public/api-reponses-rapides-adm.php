<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('messagerie');
require_once __DIR__ . '/../models/ReponseRapide.php';

header('Content-Type: application/json; charset=utf-8');

function reponseJson(array $donnees, int $code = 200): void {
    http_response_code($code);
    echo json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    reponseJson(['ok' => false, 'erreur' => 'Méthode non autorisée.'], 405);
}
if (empty($_SESSION['csrf']) || !isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'], (string) $_POST['csrf'])) {
    reponseJson(['ok' => false, 'erreur' => 'Requête invalide, rechargez la page.'], 403);
}

$role   = (string) ($_SESSION['role'] ?? '');
$userId = (int) ($_SESSION['user_id'] ?? 0);
$gestionnaire = in_array($role, ['coordinateur', 'admin'], true);

$model  = new ReponseRapide();
$action = $_POST['action'] ?? '';

// Lecture et validation des champs du formulaire
function lireChamps(): array {
    $titre     = trim($_POST['titre'] ?? '');
    $contenu   = trim($_POST['contenu'] ?? '');
    $categorie = trim($_POST['categorie'] ?? '');
    $motsCles  = trim($_POST['mots_cles'] ?? '');

    if ($titre === '')   reponseJson(['ok' => false, 'erreur' => 'Le titre est obligatoire.'], 422);
    if ($contenu === '') reponseJson(['ok' => false, 'erreur' => 'Le message est obligatoire.'], 422);
    if (mb_strlen($titre) > 100)     reponseJson(['ok' => false, 'erreur' => 'Titre trop long (100 caractères maximum).'], 422);
    if (mb_strlen($contenu) > 2000)  reponseJson(['ok' => false, 'erreur' => 'Message trop long (2000 caractères maximum).'], 422);
    if (mb_strlen($categorie) > 60)  reponseJson(['ok' => false, 'erreur' => 'Catégorie trop longue (60 caractères maximum).'], 422);
    if (mb_strlen($motsCles) > 255)  reponseJson(['ok' => false, 'erreur' => 'Mots-clés trop longs (255 caractères maximum).'], 422);

    // Mots-clés propres : "salut,  bonjour ,," => "salut, bonjour"
    $motsCles = implode(', ', array_filter(array_map('trim', explode(',', $motsCles)), 'strlen'));
    return [$titre, $contenu, $motsCles, $categorie];
}

try {
    if ($action === 'creer') {
        [$titre, $contenu, $motsCles, $categorie] = lireChamps();
        $model->create($titre, $contenu, $motsCles, $categorie, $role, $userId);

    } elseif ($action === 'modifier' || $action === 'supprimer') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        $existante = $id ? $model->getById($id) : null;
        if (!$existante) {
            reponseJson(['ok' => false, 'erreur' => 'Réponse rapide introuvable.'], 404);
        }
        $estAuteur = (int) $existante['cree_par_id'] === $userId && ($existante['cree_par_type'] ?? '') !== 'partenaire';
        if (!$gestionnaire && !$estAuteur) {
            reponseJson(['ok' => false, 'erreur' => "Vous ne pouvez modifier que vos propres réponses."], 403);
        }

        if ($action === 'modifier') {
            [$titre, $contenu, $motsCles, $categorie] = lireChamps();
            $model->modifier($id, $titre, $contenu, $motsCles, $categorie);
        } else {
            $model->supprimer($id);
        }

    } else {
        reponseJson(['ok' => false, 'erreur' => 'Action inconnue.'], 400);
    }

    // On renvoie la liste à jour : la page n'a plus qu'à la réafficher
    reponseJson(['ok' => true, 'reponses' => array_values((array) $model->getAll())]);

} catch (PDOException $e) {
    error_log('Réponses rapides : ' . $e->getMessage());
    reponseJson(['ok' => false, 'erreur' => "Enregistrement impossible. Vérifiez les valeurs saisies ou réessayez."], 500);
}

// On renvoie la liste à jour : la page n'a plus qu'à la réafficher
reponseJson(['ok' => true, 'reponses' => array_values((array) $model->getAll())]);