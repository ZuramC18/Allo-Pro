<?php
require_once __DIR__ . '/../includes/auth.php';
verifierConnexion();
require_once __DIR__ . '/../models/User.php';

$userModel = new User();
$moi = $userModel->getById($_SESSION['user_id']);

// Si ce n'est plus nécessaire (déjà fait, ou compte créé classiquement), inutile de rester sur cette page
if (!$moi['mdp_a_definir']) {
    header("Location: " . pageAccueilPourRole($_SESSION['role']));
    exit;
}

$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['passer'])) {
        header("Location: " . pageAccueilPourRole($_SESSION['role']));
        exit;
    }

    $motDePasse = $_POST['mot_de_passe'] ?? '';
    $confirmation = $_POST['confirmation'] ?? '';

    if (strlen($motDePasse) < 8) {
        $erreur = "Le mot de passe doit contenir au moins 8 caractères.";
    } elseif ($motDePasse !== $confirmation) {
        $erreur = "Les deux mots de passe ne correspondent pas.";
    } else {
        $userModel->definirMotDePasse($_SESSION['user_id'], $motDePasse);
        header("Location: " . pageAccueilPourRole($_SESSION['role']));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sécuriser votre compte — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="images/icon.png">
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
</head>
<body>
    <div class="auth-page">
        <div class="auth-photo">
            <div class="auth-photo__img"></div>
            <div class="auth-photo__contenu">
                <a href="index.php" class="auth-photo__logo">ALLÔ<span> PRO</span></a>
                <div class="auth-photo__citation">« Un mot de passe en plus de Google, pour ne jamais perdre l'accès à votre compte. »</div>
            </div>
        </div>

        <div class="auth-form-panel">
            <form method="POST" class="auth-form">
                <a href="index.php" class="auth-retour">← Retour à l’accueil</a>
                <h2>Bienvenue, <?= htmlspecialchars($moi['prenom']) ?></h2>
                <p class="auth-form__soustitre">Vous vous êtes inscrit avec Google. Ajoutez un mot de passe pour pouvoir aussi vous connecter sans lui.</p>

                <?php if ($erreur): ?><div class="erreur"><?= htmlspecialchars($erreur) ?></div><?php endif; ?>

                <div class="champ">
                    <label>Nouveau mot de passe</label>
                    <input type="password" name="mot_de_passe" class="auth-password-field" minlength="8" required>
                    <label class="auth-password-toggle-label">
                        <input type="checkbox" class="auth-password-toggle">
                        Afficher le mot de passe
                    </label>
                </div>
                <div class="champ">
                    <label>Confirmer le mot de passe</label>
                    <input type="password" name="confirmation" class="auth-password-field" minlength="8" required>
                    <label class="auth-password-toggle-label">
                        <input type="checkbox" class="auth-password-toggle">
                        Afficher le mot de passe
                    </label>
                </div>

                <button type="submit" class="bouton-principal">Définir mon mot de passe</button>
            </form>

            <form method="POST" style="text-align:center; margin-top:14px;">
                <button type="submit" name="passer" value="1" style="background:none; border:none; color:#8B9198; font-size:13px; cursor:pointer; text-decoration:underline;">
                    Plus tard
                </button>
            </form>
        </div>
    </div>
    <script src="js/auth.js?v=<?= filemtime(__DIR__ . '/js/auth.js') ?>" defer></script>
</body>
</html>