<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('coordination');
require_once __DIR__ . '/../models/Message.php';
require_once __DIR__ . '/../models/User.php';

header('Content-Type: application/json');

$messageModel = new Message();
$userModel = new User();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'liste') {
    echo json_encode($messageModel->getConversationsCoordination($_GET['filtre'] ?? 'non_attribuees'));

} elseif ($action === 'compteurs') {
    echo json_encode([
        'non_attribuees' => count($messageModel->getConversationsCoordination('non_attribuees')),
        'attribuees'     => count($messageModel->getConversationsCoordination('attribuees')),
        'toutes'         => count($messageModel->getConversationsCoordination('toutes')),
    ]);

} elseif ($action === 'conseillers') {
    echo json_encode($userModel->getConseillersActifsAvecCharge(trim($_GET['q'] ?? '') ?: null));

} elseif ($action === 'clients_conseiller') {
    $conseillerId = (int) ($_GET['conseiller_id'] ?? 0);
    $conseiller = $conseillerId > 0 ? $userModel->getById($conseillerId) : null;
    if (!$conseiller || $conseiller['role'] !== 'conseiller' || $conseiller['statut'] !== 'actif') {
        http_response_code(404);
        echo json_encode(['erreur' => 'Conseiller introuvable']);
        exit;
    }
    echo json_encode($messageModel->getClientsAttribuesConseiller($conseillerId));

} elseif ($action === 'conversation') {
    $clientId = (int) ($_GET['client_id'] ?? 0);
    $client = null;
    foreach ($messageModel->getConversationsCoordination('toutes') as $c) {
        if ($c['id'] == $clientId) { $client = $c; break; }
    }
    if (!$client) { http_response_code(404); echo json_encode(['erreur' => 'introuvable']); exit; }
    echo json_encode(['client' => $client, 'messages' => $messageModel->getByClient($clientId)]);

} elseif ($action === 'assigner' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $clientId = (int) $_POST['client_id'];
    $conseillerId = (int) $_POST['conseiller_id'];
    $ancien = $userModel->getConseillerAssigne($clientId);
    $userModel->reassignerConseiller($clientId, $conseillerId);
    journaliser($ancien ? 'conversation.reassignee' : 'conversation.attribuee', 'compte', $clientId, null, 'Conseiller ID ' . $conseillerId);
    echo json_encode(['ok' => true]);

} else {
    http_response_code(400);
    echo json_encode(['erreur' => 'action inconnue']);
}