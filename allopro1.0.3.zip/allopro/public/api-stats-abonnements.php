<?php
require_once __DIR__ . '/../includes/auth-admin.php';
verifierAcces('abonnements');
require_once __DIR__ . '/../models/Abonnement.php';

header('Content-Type: application/json');

$abonnementModel = new Abonnement();
$statsPass = $abonnementModel->compterPassVendus();

echo json_encode([
    'abonnements_actifs' => $abonnementModel->compterAbonnementsActifs(),
    'pass_vendus' => (int) $statsPass['total'],
    'revenus_pass' => (float) $statsPass['montant']
]);