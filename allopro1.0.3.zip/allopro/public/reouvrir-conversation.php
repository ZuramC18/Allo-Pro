<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../models/User.php';

(new User())->reouvrirConversation($_SESSION['user_id']);
header("Location: /allopro/views/client/messagerie.php");
exit;