<?php
session_start();
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Partenaire.php';
require_once __DIR__ . '/../includes/email-verification.php';
require_once __DIR__ . '/../includes/audit.php';
require_once __DIR__ . '/../includes/helpers.php';

$typesValides = ['client', 'partenaire'];
$typeDemande = $_GET['type'] ?? '';
$type = in_array($typeDemande, $typesValides, true) ? $typeDemande : 'client';
$adresse = is_string($_GET['email'] ?? null) ? trim($_GET['email']) : '';
$message = '';
$erreur = '';
$verificationReussie = false;
$activationEnAttente = false;

if (!empty($_SESSION['verification_email_type'])) {
    $typeSession = $_SESSION['verification_email_type'];
    $type = in_array($typeSession, $typesValides, true) ? $typeSession : 'client';
    $adresseSession = $_SESSION['verification_email_adresse'] ?? '';
    $adresse = is_string($adresseSession) ? $adresseSession : $adresse;

    if (($_SESSION['verification_email_notice'] ?? '') === 'envoye') {
        $message = 'Consultez votre boîte de réception : votre code de confirmation à 6 chiffres a été envoyé à ' . $adresse . '.';
    } elseif (($_SESSION['verification_email_notice'] ?? '') === 'modifiee') {
        $message = 'Votre nouvelle adresse e-mail est enregistrée. Un code de confirmation à 6 chiffres lui a été envoyé.';
    } elseif (($_SESSION['verification_email_notice'] ?? '') === 'echec') {
        $erreur = 'Le code de vérification n’a pas pu être envoyé. Vous pouvez en demander un nouveau ci-dessous.';
    }
    unset($_SESSION['verification_email_type'], $_SESSION['verification_email_adresse'], $_SESSION['verification_email_notice']);
}

if (empty($_SESSION['csrf_verification_email'])) {
    $_SESSION['csrf_verification_email'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['token'])) {
    $jeton = is_string($_GET['token']) ? $_GET['token'] : '';
    if (preg_match('/\A[a-f0-9]{64}\z/i', $jeton)) {
        $modele = $type === 'partenaire' ? new Partenaire() : new User();
        if ($modele->confirmerEmailParJeton(hash('sha256', $jeton))) {
            $message = 'Votre adresse e-mail est vérifiée. Votre compte est prêt !';
            $verificationReussie = true;
        } else {
            $erreur = 'Ce lien a expiré ou a déjà été utilisé. Demandez un nouveau code pour continuer.';
        }
    } else {
        $erreur = 'Ce lien n’est pas valide. Demandez un nouveau code pour continuer.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = '';
    $erreur = '';
    $csrfSoumis = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    $typeSoumis = $_POST['type'] ?? '';
    $type = in_array($typeSoumis, $typesValides, true) ? $typeSoumis : 'client';
    $adresse = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
    $lienConnexion = $type === 'partenaire' ? 'connexion-partenaire.php' : 'connexion.php';

    if (!hash_equals($_SESSION['csrf_verification_email'], $csrfSoumis)) {
        $erreur = 'La demande a expiré. Rechargez cette page et réessayez.';
    } elseif (!filter_var($adresse, FILTER_VALIDATE_EMAIL)) {
        $erreur = 'Saisissez une adresse e-mail valide.';
    } else {
        $modele = $type === 'partenaire' ? new Partenaire() : new User();
        if ($action === 'verifier') {
            $code = is_string($_POST['code'] ?? null) ? trim($_POST['code']) : '';
            if (!preg_match('/\A[0-9]{6}\z/', $code)) {
                $erreur = 'Saisissez le code à 6 chiffres reçu par e-mail.';
            } elseif ($modele->confirmerEmailParCode($adresse, $code)) {
                unset($_SESSION['verification_email_type'], $_SESSION['verification_email_adresse']);
                $compte = $modele->findByEmail($adresse);
                if ($type === 'client' && $compte && ($compte['role'] ?? '') === 'client') {
                    if (($compte['statut'] ?? '') === 'suspendu') {
                        $erreur = 'Votre adresse e-mail est confirmée, mais ce compte a été suspendu. Contactez le support ALLÔ PRO.';
                    } else {
                        session_regenerate_id(true);
                        unset(
                            $_SESSION['user_id'],
                            $_SESSION['role'],
                            $_SESSION['prenom'],
                            $_SESSION['nom_famille'],
                            $_SESSION['nom'],
                            $_SESSION['partenaire_id'],
                            $_SESSION['partenaire_nom'],
                            $_SESSION['technicien_id'],
                            $_SESSION['technicien_nom']
                        );
                        $_SESSION['user_id'] = $compte['id'];
                        $_SESSION['role'] = $compte['role'];
                        $_SESSION['prenom'] = $compte['prenom'];
                        $_SESSION['nom_famille'] = $compte['nom'];
                        $_SESSION['nom'] = nomComplet($compte['prenom'], $compte['nom']);
                        journaliser('connexion.reussie', 'compte', $compte['id'], $compte['matricule']);
                        header('Location: dashboard.php');
                        exit;
                    }
                } elseif ($type === 'partenaire' && $compte && ($compte['statut'] ?? '') === 'actif') {
                    session_regenerate_id(true);
                    unset(
                        $_SESSION['user_id'],
                        $_SESSION['role'],
                        $_SESSION['prenom'],
                        $_SESSION['nom_famille'],
                        $_SESSION['nom'],
                        $_SESSION['partenaire_id'],
                        $_SESSION['partenaire_nom'],
                        $_SESSION['technicien_id'],
                        $_SESSION['technicien_nom']
                    );
                    $_SESSION['partenaire_id'] = $compte['id'];
                    $_SESSION['partenaire_nom'] = $compte['nom_entreprise'];
                    journaliser('connexion.reussie', 'compte', $compte['id'], $compte['matricule']);
                    header('Location: /allopro/views/partenaire/accueil.php');
                    exit;
                } elseif ($type === 'partenaire' && $compte) {
                    $message = 'Votre adresse e-mail est confirmée. Votre compte partenaire est en attente de validation par ALLÔ PRO.';
                    $verificationReussie = true;
                    $activationEnAttente = true;
                } else {
                    $erreur = 'Votre adresse e-mail est confirmée, mais votre compte est introuvable. Contactez le support ALLÔ PRO.';
                }
            } else {
                $erreur = 'Ce code est invalide, expiré ou bloqué après plusieurs essais. Demandez un nouveau code pour continuer.';
            }
        } elseif ($action === 'renvoyer') {
            $compte = $modele->findByEmail($adresse);
            if ($compte && empty($compte['email_verifie'])
                && ($type === 'partenaire' || ($compte['role'] ?? '') === 'client')) {
                $nom = $type === 'partenaire'
                    ? (string) ($compte['nom_entreprise'] ?? '')
                    : trim((string) ($compte['prenom'] ?? '') . ' ' . (string) ($compte['nom'] ?? ''));
                try {
                    if (!envoyerCodeVerificationEmail($modele, (int) $compte['id'], $adresse, $nom, $type)) {
                        $erreur = 'Un code vient d’être envoyé récemment. Patientez une minute avant d’en demander un autre.';
                    }
                } catch (RuntimeException $e) {
                    error_log('Échec de l’envoi du code de vérification : ' . $e->getMessage());
                    $erreur = 'Le code n’a pas pu être envoyé. Vérifiez la configuration e-mail ou réessayez dans une minute.';
                }
            }
            if ($erreur === '') {
                $message = 'Si cette adresse correspond à un compte en attente, un code de vérification a été envoyé. Vérifiez aussi vos courriers indésirables.';
            }
            $_SESSION['verification_email_type'] = $type;
            $_SESSION['verification_email_adresse'] = $adresse;
        } else {
            $erreur = 'Cette demande n’est pas valide. Réessayez.';
        }
    }
}

$lienConnexion = $type === 'partenaire' ? 'connexion-partenaire.php' : 'connexion.php';
$adresseValide = filter_var($adresse, FILTER_VALIDATE_EMAIL) !== false;
$adresseMasquee = '';
if ($adresseValide) {
    [$nomLocal, $domaine] = explode('@', $adresse, 2);
    $partiesDomaine = explode('.', $domaine, 2);
    $adresseMasquee = mb_substr($nomLocal, 0, 1)
        . str_repeat('*', max(1, mb_strlen($nomLocal) - 1))
        . '@'
        . mb_substr($partiesDomaine[0], 0, 1)
        . str_repeat('*', max(1, mb_strlen($partiesDomaine[0]) - 1))
        . (isset($partiesDomaine[1]) ? '.' . $partiesDomaine[1] : '');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#12181B">
    <title>Vérifiez votre e-mail — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="images/icon.png">
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
    <style>
        .auth-photo--verification .auth-photo__img {
            background-image: linear-gradient(145deg, rgba(18,24,27,.72), rgba(18,24,27,.96)), url('https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg?auto=compress&w=1200');
            background-position: center;
        }
        .verification-form { max-width: 420px; }
        .verification-form .auth-form__soustitre { line-height: 1.65; margin-bottom: 24px; }
        .verification-etape { display: inline-flex; padding: 7px 11px; margin-bottom: 15px; border-radius: 20px; background: #FFF2E9; color: #BD4C10; font-size: 11px; font-weight: 800; letter-spacing: .08em; }
        .verification-destinataire { margin: -8px 0 22px; color: #59636A; font-size: 14px; }
        .verification-destinataire strong { color: #12181B; overflow-wrap: anywhere; }
        .verification-code { width: 100%; height: 66px; padding: 12px 16px; border: 1px solid #E2DFD8; border-radius: 10px; background: #F9FAFA; color: #12181B; font: 700 28px 'Space Grotesk', sans-serif; letter-spacing: .48em; text-align: center; transition: border-color .15s ease, box-shadow .15s ease; }
        .verification-code:focus { outline: none; border-color: #FF7A30; box-shadow: 0 0 0 3px rgba(255,122,48,.14); }
        .verification-aide { margin: 10px 0 18px; color: #8B9198; font-size: 12px; line-height: 1.5; }
        .verification-secondaire { display: block; width: 100%; margin-top: 13px; padding: 12px; border: 1px solid #E2DFD8; border-radius: 8px; background: #fff; color: #12181B; font: 600 13px 'Inter', sans-serif; cursor: pointer; }
        .verification-secondaire:hover { border-color: #FF7A30; }
        .verification-info { padding: 12px 14px; margin-bottom: 18px; border: 1px solid #A7F3D0; border-radius: 8px; background: #ECFDF5; color: #065F46; font-size: 14px; line-height: 1.55; }
        .verification-icone { display: grid; width: 48px; height: 48px; margin-bottom: 18px; place-items: center; border-radius: 14px; background: #FFF2E9; color: #E76520; font-size: 23px; }
        .verification-form .champ { margin-top: 19px; }
        .verification-form .champ select { width: 100%; min-height: 46px; padding: 10px 14px; border: 1px solid #E2DFD8; border-radius: 8px; background: #fff; font: inherit; }
        .verification-form .champ select:focus { outline: none; border-color: #FF7A30; box-shadow: 0 0 0 3px rgba(255,122,48,.12); }
        .verification-separateur { display: flex; align-items: center; gap: 10px; margin: 22px 0 0; color: #8B9198; font-size: 12px; }
        .verification-separateur::before, .verification-separateur::after { height: 1px; flex: 1; background: #E9ECEE; content: ''; }
        @media (max-width: 760px) { .verification-form { max-width: 440px; } }
    </style>
</head>
<body>
    <div class="auth-page">
        <aside class="auth-photo auth-photo--verification" aria-label="ALLÔ PRO">
            <div class="auth-photo__img"></div>
            <div class="auth-photo__contenu">
                <a href="index.php" class="auth-photo__logo">ALLÔ<span> PRO</span></a>
                <div class="auth-photo__citation">Un dernier petit pas pour rejoindre ALLÔ PRO.</div>
                <div class="auth-photo__badges">
                    <div><div class="auth-photo__badge-chiffre">Simple</div><div class="auth-photo__badge-label">Un code, et c’est confirmé</div></div>
                    <div><div class="auth-photo__badge-chiffre">Sécurisé</div><div class="auth-photo__badge-label">Votre compte vous appartient</div></div>
                </div>
            </div>
        </aside>

        <main class="auth-form-panel">
            <section class="auth-form verification-form" aria-labelledby="titre-verification">
                <a href="index.php" class="auth-retour">← Retour à l’accueil</a>
                <?php if ($verificationReussie): ?>
                    <div class="verification-icone" aria-hidden="true">✓</div>
                    <span class="verification-etape">ADRESSE CONFIRMÉE</span>
                    <h2 id="titre-verification"><?= $activationEnAttente ? 'Validation en cours' : 'Tout est prêt !' ?></h2>
                    <p class="auth-form__soustitre"><?= $activationEnAttente
                        ? 'Votre adresse e-mail est vérifiée. L’équipe ALLÔ PRO doit encore valider votre compte partenaire.'
                        : 'Votre adresse e-mail est vérifiée. Vous pouvez maintenant vous connecter à votre compte ALLÔ PRO.' ?></p>
                    <?php if ($message): ?><div class="verification-info" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
                    <?php if (!$activationEnAttente): ?>
                        <a class="bouton-principal" style="display:block;text-align:center;text-decoration:none" href="<?= htmlspecialchars($lienConnexion, ENT_QUOTES, 'UTF-8') ?>">Me connecter</a>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="verification-icone" aria-hidden="true">✉</div>
                    <span class="verification-etape">ÉTAPE FINALE · 1 MINUTE</span>
                    <h2 id="titre-verification">Vérifiez votre e-mail</h2>
                    <p class="auth-form__soustitre">Nous vous envoyons un code à 6 chiffres pour confirmer que cette adresse vous appartient.</p>

                    <?php if ($message): ?><div class="verification-info" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
                    <?php if ($erreur): ?><div class="erreur" role="alert"><?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

                    <?php if ($adresseValide): ?>
                        <p class="verification-destinataire">Code envoyé à <strong><?= htmlspecialchars($adresseMasquee, ENT_QUOTES, 'UTF-8') ?></strong></p>
                        <form method="POST" class="auth-form__actions">
                            <input type="hidden" name="action" value="verifier">
                            <input type="hidden" name="type" value="<?= htmlspecialchars($type, ENT_QUOTES, 'UTF-8') ?>">
                            <input type="hidden" name="email" value="<?= htmlspecialchars($adresse, ENT_QUOTES, 'UTF-8') ?>">
                            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_verification_email'], ENT_QUOTES, 'UTF-8') ?>">
                            <div class="champ">
                                <label for="code">Votre code de vérification</label>
                                <input class="verification-code" type="text" id="code" name="code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" minlength="6" maxlength="6" placeholder="000000" aria-describedby="code-aide" required autofocus>
                                <p class="verification-aide" id="code-aide">Le code est valable 10 minutes. Pensez à vérifier vos courriers indésirables.</p>
                            </div>
                            <button type="submit" class="bouton-principal">Confirmer mon adresse</button>
                        </form>
                        <div class="verification-separateur">Vous n’avez pas reçu le code ?</div>
                    <?php endif; ?>

                    <form method="POST">
                        <input type="hidden" name="action" value="renvoyer">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_verification_email'], ENT_QUOTES, 'UTF-8') ?>">
                        <?php if ($adresseValide): ?>
                            <input type="hidden" name="type" value="<?= htmlspecialchars($type, ENT_QUOTES, 'UTF-8') ?>">
                            <div class="champ">
                                <label for="email">Adresse e-mail</label>
                                <input type="email" id="email" name="email" value="<?= htmlspecialchars($adresse, ENT_QUOTES, 'UTF-8') ?>" autocomplete="email" required>
                            </div>
                        <?php else: ?>
                            <div class="champ">
                                <label for="type">Type de compte</label>
                                <select id="type" name="type">
                                    <option value="client" <?= $type === 'client' ? 'selected' : '' ?>>Client</option>
                                    <option value="partenaire" <?= $type === 'partenaire' ? 'selected' : '' ?>>Partenaire</option>
                                </select>
                            </div>
                            <div class="champ">
                                <label for="email">Adresse e-mail</label>
                                <input type="email" id="email" name="email" value="<?= htmlspecialchars($adresse, ENT_QUOTES, 'UTF-8') ?>" autocomplete="email" required>
                            </div>
                        <?php endif; ?>
                        <button type="submit" class="verification-secondaire"><?= $adresseValide ? 'Renvoyer un code' : 'Recevoir mon code' ?></button>
                    </form>
                    <p class="auth-form__lien"><a href="<?= htmlspecialchars($lienConnexion, ENT_QUOTES, 'UTF-8') ?>">Retour à la connexion</a></p>
                <?php endif; ?>
            </section>
        </main>
    </div>
    <script>
        const codeInput = document.getElementById('code');
        if (codeInput) {
            codeInput.addEventListener('input', () => {
                codeInput.value = codeInput.value.replace(/\D/g, '').slice(0, 6);
            });
        }
    </script>
</body>
</html>
