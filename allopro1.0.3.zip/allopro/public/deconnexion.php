<?php
session_start();
if (($_SESSION['role'] ?? '') === 'conseiller' && !empty($_SESSION['user_id'])) {
    require_once __DIR__ . '/../models/User.php';
    (new User())->definirPresenceConseiller((int) $_SESSION['user_id'], 'offline');
}
session_unset();
session_destroy();
header("Location: index.php");
exit;