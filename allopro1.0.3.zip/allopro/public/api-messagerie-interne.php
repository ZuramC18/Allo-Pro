<?php
/**
 * API de la messagerie interne (équipe / partenaires / techniciens).
 * Réponses toujours en JSON ; codes HTTP :
 *   401 = pas connecté (session expirée), 403 = connecté mais accès refusé,
 *   400 = requête invalide, 405 = mauvaise méthode, 500 = erreur serveur.
 */
ini_set('display_errors', '0');   // un warning PHP en HTML casserait le JSON lu par le navigateur
session_start();
require_once __DIR__ . '/../models/MessagerieInterne.php';
require_once __DIR__ . '/../config/roles.php';

// Si config/roles.php ne définit pas les libellés des rôles, getNomContact() planterait (erreur 500)
defined('LIBELLES_ROLES') || define('LIBELLES_ROLES', []);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');   // les requêtes de rafraîchissement ne doivent jamais venir d'un cache

const LONGUEUR_MAX_MESSAGE = 2000;
const TYPES_CONTACT = ['equipe', 'partenaire', 'technicien'];

const DEBUG_MESSAGERIE = false;

function repondre($donnees, int $code = 200): void {
    http_response_code($code);
    echo json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function erreur(string $message, int $code): void {
    repondre(['erreur' => $message], $code);
}

function moiMessagerieInterne(): array {
    if (isset($_SESSION['technicien_id'])) return ['technicien', (int) $_SESSION['technicien_id']];
    if (isset($_SESSION['partenaire_id'])) return ['partenaire', (int) $_SESSION['partenaire_id']];
    if (isset($_SESSION['user_id']) && in_array($_SESSION['role'] ?? '', ROLES_INTERNES, true)) return ['equipe', (int) $_SESSION['user_id']];
    return [null, null];
}

[$moiType, $moiId] = moiMessagerieInterne();
$estConnecte = isset($_SESSION['technicien_id']) || isset($_SESSION['partenaire_id']) || isset($_SESSION['user_id']);

// La session n'est plus modifiée ici : on libère son verrou. Sans cela, chaque requête de
// rafraîchissement (toutes les 2,5 s) bloque les autres pages du même utilisateur.
session_write_close();

if (!$moiType) {
    $estConnecte ? erreur('Accès refusé', 403) : erreur('Session expirée', 401);
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Actions qui modifient des données : POST obligatoire + en-tête propre à notre script
// (un formulaire placé sur un autre site ne peut pas l'ajouter : protection contre le CSRF)
if (in_array($action, ['ouvrir', 'envoyer'], true)) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Allow: POST');
        erreur('Méthode non autorisée', 405);
    }
    if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'fetch') {
        erreur('Requête refusée', 403);
    }
}

try {
    $model = new MessagerieInterne();

    switch ($action) {

        case 'contacts':
            if ($moiType === 'equipe')          repondre($model->getContactsEquipe($moiId));
            elseif ($moiType === 'partenaire')  repondre($model->getContactsPartenaire($moiId));
            else                                repondre($model->getContactsTechnicien($moiId));
            break;

        case 'conversations':
            repondre($model->getConversationsListe($moiType, $moiId) ?: []);
            break;

        case 'ouvrir':
            $autreType = $_POST['autre_type'] ?? '';
            $autreId   = (int) ($_POST['autre_id'] ?? 0);
            if (!in_array($autreType, TYPES_CONTACT, true) || $autreId <= 0) erreur('Contact invalide', 400);
            if ($autreType === $moiType && $autreId === $moiId)             erreur('Vous ne pouvez pas vous écrire à vous-même', 400);

            // Ouvrir une discussion n'enregistre RIEN : la conversation n'est créée qu'au premier message envoyé.
            if (!$model->peutContacter($moiType, $moiId, $autreType, $autreId)) erreur('Contact non autorisé', 403);
            $convId = $model->trouverConversation($moiType, $moiId, $autreType, $autreId);   // null = jamais écrit

            $contact = $model->getNomContact($autreType, $autreId);
            // getNomContact doit renvoyer un tableau ; toute autre valeur (ex. texte) casserait l'affichage
            if (!is_array($contact)) erreur('Contact introuvable', 404);

            repondre(['conversation_id' => $convId ? (int) $convId : null, 'contact' => $contact]);
            break;

        case 'messages':
            $convId  = (int) ($_GET['conversation_id'] ?? 0);
            $apresId = max(0, (int) ($_GET['apres_id'] ?? 0));
            if ($convId <= 0 || !$model->estParticipant($convId, $moiType, $moiId)) erreur('Accès refusé', 403);

            $messages = $model->getMessages($convId, $apresId) ?: [];
            // Marquer comme lu seulement à l'ouverture ou quand de nouveaux messages arrivent
            // (évite une écriture en base à chaque rafraîchissement)
            if ($apresId === 0 || !empty($messages)) {
                $model->marquerLues($convId, $moiType, $moiId);
            }
            repondre($messages);
            break;

        case 'envoyer':
            // Le message est contrôlé AVANT toute création de conversation
            $contenu = trim((string) ($_POST['contenu'] ?? ''));
            if ($contenu === '')                                   erreur('Message vide', 400);
            if (mb_strlen($contenu) > LONGUEUR_MAX_MESSAGE)        erreur('Message trop long (' . LONGUEUR_MAX_MESSAGE . ' caractères maximum)', 400);

            $convId = (int) ($_POST['conversation_id'] ?? 0);

            if ($convId > 0) {
                // Conversation déjà enregistrée
                if (!$model->estParticipant($convId, $moiType, $moiId)) erreur('Accès refusé', 403);
                // Les règles ont pu changer depuis la création de la conversation (technicien parti, compte désactivé...)
                if (!$model->conversationAutorisee($convId, $moiType, $moiId)) erreur("Cette conversation n'est plus autorisée.", 403);
                $model->envoyerMessage($convId, $moiType, $moiId, $contenu);
            } else {
                // Premier message : la conversation est créée maintenant, avec ce message
                $autreType = $_POST['autre_type'] ?? '';
                $autreId   = (int) ($_POST['autre_id'] ?? 0);
                if (!in_array($autreType, TYPES_CONTACT, true) || $autreId <= 0) erreur('Contact invalide', 400);
                if ($autreType === $moiType && $autreId === $moiId)             erreur('Vous ne pouvez pas vous écrire à vous-même', 400);

                $convId = $model->envoyerAuContact($moiType, $moiId, $autreType, $autreId, $contenu);
                if (!$convId) erreur('Contact non autorisé', 403);
            }

            repondre(['ok' => true, 'conversation_id' => (int) $convId]);
            break;

        default:
            erreur('Action inconnue', 400);
    }
} catch (Throwable $e) {
    error_log('[messagerie-interne] ' . $e->getMessage() . ' (' . $e->getFile() . ':' . $e->getLine() . ')');
    erreur(
        DEBUG_MESSAGERIE
            ? 'Erreur serveur — ' . get_class($e) . ' : ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')'
            : 'Erreur serveur',
        500
    );
}