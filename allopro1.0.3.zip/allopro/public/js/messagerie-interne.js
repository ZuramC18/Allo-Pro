/**
 * Messagerie interne — version fiabilisée.
 * Mêmes éléments HTML (ids) et même API que l'ancienne version.
 *
 * Correctif : l'API exige l'en-tête « X-Requested-With: fetch » sur les actions qui modifient des
 * données (ouvrir une conversation, envoyer un message). Le JS ne l'envoyait pas : l'API répondait
 * 403 « Requête refusée » et aucune conversation ne pouvait s'ouvrir. L'en-tête est maintenant
 * ajouté automatiquement à tous les appels (voir appelAPI).
 */
(function () {
    'use strict';
    if (window.__MI_DEJA_INITIALISE__) return;
    window.__MI_DEJA_INITIALISE__ = true;

    const API = new URL('../api-messagerie-interne.php', document.currentScript.src).href;
    const $ = (id) => document.getElementById(id);

    // ---------- Vérification du HTML : un id manquant est signalé dans la console ----------
    const IDS_REQUIS = ['mi-conversations', 'mi-recherche-conversations', 'mi-fil-vide', 'mi-demarrer-conversation', 'mi-fil', 'mi-fil-corps', 'mi-fil-avatar', 'mi-fil-nom',
        'mi-fil-soustitre', 'mi-champ-message', 'mi-btn-envoyer', 'mi-modale-contacts', 'mi-contacts-liste',
        'mi-recherche-contact', 'mi-ouvrir-contacts', 'mi-fermer-contacts'];
    const manquants = IDS_REQUIS.filter((id) => !$(id));
    if (manquants.length) {
        console.error('[Messagerie] éléments HTML introuvables : ' + manquants.join(', '));
        return;
    }

    const listeEl = $('mi-conversations');
    const rechercheConversationsEl = $('mi-recherche-conversations');
    const filVide = $('mi-fil-vide');
    const fil = $('mi-fil');
    const filCorps = $('mi-fil-corps');
    const filAvatar = $('mi-fil-avatar');
    const filNom = $('mi-fil-nom');
    const filSousTitre = $('mi-fil-soustitre');
    const lienInfosTechnicien = $('mi-fil-infos-technicien');
    const champMessage = $('mi-champ-message');
    const btnEnvoyer = $('mi-btn-envoyer');
    const btnRetour = $('mi-retour');   // optionnel : bouton « retour à la liste » sur mobile

    // ---------- État ----------
    let conversationActive = null;
    window.MI_CONVERSATION_ACTIVE = null;
    let contactEnAttente = null;   // discussion ouverte mais pas encore enregistrée : {type, id}. Créée au premier message.
    let contactActif = null;
    let dernierId = 0;
    let dernierJour = '';
    let envoiEnCours = false;
    let jeton = 0;                 // change à chaque conversation ouverte/fermée : invalide les réponses en retard
    let minuteurMessages = null;
    let delaiMessages = 2500;
    let chargementListe = false;
    let signatureListe = '';
    const idsAffiches = new Set();

    // ---------- Utilitaires ----------
    const PALETTE = ['#6C5CE7', '#FF7A30', '#16A34A', '#D97706', '#0EA5E9', '#DC2626', '#123C4D'];
    function couleurPour(texte) {
        texte = String(texte || '');
        let h = 0;
        for (let i = 0; i < texte.length; i++) h = texte.charCodeAt(i) + ((h << 5) - h);
        return PALETTE[Math.abs(h) % PALETTE.length];
    }

    // Échappe aussi les guillemets : indispensable pour les valeurs placées dans des attributs HTML
    function echapper(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }
    function initiale(nom) {
        const mots = String(nom || '?').trim().split(/\s+/).filter(Boolean);
        const lettres = mots.length > 1 ? [mots[0], mots[mots.length - 1]] : mots;
        return lettres.map((mot) => Array.from(mot)[0] || '').join('').toLocaleUpperCase('fr-FR') || '?';
    }
    function normaliser(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
    const avatarPersonne = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M5 21a7 7 0 0 1 14 0"/></svg>';
    function contenuAvatar(nom, type, photoProfil, avatarInitiales) {
        const cheminValide = typeof photoProfil === 'string'
            && /^uploads\/techniciens\/[a-f0-9]{32}\.(jpg|png|webp)$/.test(photoProfil);
        if (type === 'technicien' && cheminValide && !avatarInitiales) {
            return `<img src="../../public/${encodeURI(photoProfil)}" alt="" loading="lazy" decoding="async">`;
        }
        if (type === 'technicien' && !avatarInitiales) return avatarPersonne;
        return echapper(initiale(nom));
    }
    function avatarHTML(nom, type, photoProfil, avatarInitiales, classe) {
        const photoAffichee = type === 'technicien'
            && typeof photoProfil === 'string'
            && /^uploads\/techniciens\/[a-f0-9]{32}\.(jpg|png|webp)$/.test(photoProfil)
            && !avatarInitiales;
        return `<div class="${classe} ${photoAffichee ? 'mi-avatar--photo' : ''}" style="background:${couleurPour(nom)}">${contenuAvatar(nom, type, photoProfil, avatarInitiales)}</div>`;
    }
    function afficherAvatarEntete(nom, type, photoProfil, avatarInitiales) {
        filAvatar.style.background = couleurPour(nom);
        filAvatar.classList.toggle('mi-avatar--photo', type === 'technicien'
            && typeof photoProfil === 'string'
            && /^uploads\/techniciens\/[a-f0-9]{32}\.(jpg|png|webp)$/.test(photoProfil)
            && !avatarInitiales);
        filAvatar.innerHTML = contenuAvatar(nom, type, photoProfil, avatarInitiales);
    }

    function filtrerConversations() {
        const terme = normaliser(rechercheConversationsEl.value.trim());
        const items = Array.from(listeEl.querySelectorAll('.mi-item'));
        let visibles = 0;
        items.forEach((item) => {
            const correspond = normaliser(item.dataset.recherche || item.textContent).includes(terme);
            item.hidden = !correspond;
            if (correspond) visibles++;
        });

        let messageVide = listeEl.querySelector('.mi-recherche-vide');
        if (terme && visibles === 0 && items.length > 0) {
            if (!messageVide) {
                messageVide = document.createElement('div');
                messageVide.className = 'mi-recherche-vide';
                messageVide.textContent = 'Aucune conversation ne correspond à cette recherche.';
                listeEl.appendChild(messageVide);
            }
        } else if (messageVide) {
            messageVide.remove();
        }
    }

    function parserDate(s) {
        if (!s) return null;
        const d = new Date(String(s).replace(' ', 'T'));
        return isNaN(d.getTime()) ? null : d;
    }
    const memeJour = (a, b) => a.toDateString() === b.toDateString();
    function heureCourte(d) { return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }); }

    // Liste des conversations : heure si aujourd'hui, « Hier », sinon jj/mm. Une date absente ne casse plus rien.
    function formaterDateListe(s) {
        const d = parserDate(s);
        if (!d) return '';
        const auj = new Date();
        if (memeJour(d, auj)) return heureCourte(d);
        const hier = new Date(auj); hier.setDate(auj.getDate() - 1);
        if (memeJour(d, hier)) return 'Hier';
        return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
    }
    function libelleJour(d) {
        const auj = new Date();
        const hier = new Date(auj); hier.setDate(auj.getDate() - 1);
        if (memeJour(d, auj)) return "Aujourd'hui";
        if (memeJour(d, hier)) return 'Hier';
        return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    }

    // ---------- Appels réseau ----------
    async function appelAPI(url, options) {
        const opts = Object.assign({ credentials: 'same-origin' }, options);
        // En-tête exigé par l'API pour les actions qui modifient des données (protection CSRF)
        opts.headers = Object.assign({ 'X-Requested-With': 'fetch' }, opts.headers);

        const res = await fetch(url, opts);

        if (!res.ok) {
            // L'API répond { erreur: "..." } : on conserve ce message pour l'afficher à l'utilisateur
            let message = '';
            try { message = (await res.json()).erreur || ''; } catch (e) { /* corps non JSON */ }
            if (res.status >= 500) console.error('[Messagerie] Erreur serveur ' + res.status + ' :', message || '(pas de détail)');
            const err = new Error(message || 'HTTP ' + res.status);
            err.status = res.status;
            err.serveur = message;
            err.session = res.status === 401;   // 401 = non connecté ; 403 = accès refusé (autre problème)
            throw err;
        }

        const texte = await res.text();
        try { return JSON.parse(texte); }
        catch (e) { const err = new Error('Réponse invalide'); err.session = /<html|<!doctype/i.test(texte); throw err; }   // page de connexion renvoyée à la place du JSON
    }

    // Actions qui modifient des données : POST + corps encodé en formulaire
    function postAPI(params) {
        return appelAPI(API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(params).toString()
        });
    }

    // ---------- Notification (en haut de l'écran, indépendante de la mise en page) ----------
    const toast = document.createElement('div');
    toast.className = 'mi-toast';
    toast.setAttribute('role', 'alert');
    document.body.appendChild(toast);
    let minuteurToast = null;
    let toastPersistant = false;

    function afficherErreur(message, persistant) {
        toast.textContent = message;
        toast.classList.add('mi-toast--visible');
        toastPersistant = !!persistant;
        clearTimeout(minuteurToast);
        // Les messages longs (ex. détail d'une erreur serveur) restent affichés plus longtemps
        if (!persistant) minuteurToast = setTimeout(() => toast.classList.remove('mi-toast--visible'), Math.min(20000, Math.max(5000, message.length * 70)));
    }
    function masquerErreurReseau() {
        if (toastPersistant) { toast.classList.remove('mi-toast--visible'); toastPersistant = false; }
    }
    function gererErreur(e) {
        if (e && e.session) afficherErreur('Votre session a expiré. Rechargez la page pour vous reconnecter.', true);
        else if (!navigator.onLine || (e && e.name === 'TypeError')) afficherErreur('Connexion perdue… nouvelle tentative en cours.', true);
        else console.warn('[Messagerie]', e);
    }

    // ---------- Liste des conversations ----------
    async function chargerConversations() {
        if (chargementListe) return;
        chargementListe = true;
        try {
            const conversations = await appelAPI(API + '?action=conversations');
            if (!Array.isArray(conversations)) throw new Error((conversations && conversations.erreur) || 'Réponse inattendue');
            masquerErreurReseau();

            // On ne réécrit la liste que si elle a changé : plus de scintillement ni de perte de défilement
            const signature = JSON.stringify(conversations) + '|' + conversationActive;
            if (signature === signatureListe) return;
            signatureListe = signature;

            if (conversations.length === 0) {
                listeEl.innerHTML = '<div class="mi-vide">Aucune conversation pour l\'instant.<br>Cliquez sur <strong>+</strong> pour en démarrer une.</div>';
                return;
            }

            const defilement = listeEl.scrollTop;
            listeEl.innerHTML = conversations.map((c) => {
                const id = Number(c.conversation_id);
                const actif = conversationActive === id;
                const nonLus = actif ? 0 : (Number(c.non_lus) || 0);
                return `
                    <div class="mi-item ${actif ? 'mi-item--actif' : ''}" role="button" tabindex="0" data-id="${id}" data-nom="${echapper(c.nom)}" data-soustitre="${echapper(c.sous_titre || '')}" data-autre-type="${echapper(c.autre_type || '')}" data-autre-id="${echapper(c.autre_id || '')}" data-photo-profil="${echapper(c.photo_profil || '')}" data-avatar-initiales="${c.avatar_initiales ? '1' : '0'}" data-recherche="${echapper([c.nom, c.sous_titre, c.dernier_message].filter(Boolean).join(' '))}">
                        ${avatarHTML(c.nom, c.autre_type, c.photo_profil, c.avatar_initiales, 'mi-item__avatar')}
                        <div class="mi-item__corps">
                            <div class="mi-item__haut"><span class="mi-item__nom">${echapper(c.nom)}</span><span class="mi-item__date">${echapper(formaterDateListe(c.derniere_date))}</span></div>
                            <div class="mi-item__apercu">${echapper(c.dernier_message || 'Nouvelle conversation')}</div>
                        </div>
                        ${nonLus > 0 ? `<span class="mi-item__badge">${nonLus}</span>` : ''}
                    </div>`;
            }).join('');
            listeEl.scrollTop = defilement;
            filtrerConversations();
        } catch (e) {
            gererErreur(e);
        } finally {
            chargementListe = false;
        }
    }

    function marquerConversationActive() {
        listeEl.querySelectorAll('.mi-item').forEach((el) => {
            const actif = Number(el.dataset.id) === conversationActive;
            el.classList.toggle('mi-item--actif', actif);
            if (actif) { const b = el.querySelector('.mi-item__badge'); if (b) b.remove(); }
        });
    }

    // ---------- Messages ----------
    function estMoi(m) {
        return window.MI_MOI_TYPE === m.expediteur_type && String(window.MI_MOI_ID) === String(m.expediteur_id);
    }

    function creerBulle(m) {
        const div = document.createElement('div');
        div.className = 'mi-bulle ' + (estMoi(m) ? 'mi-bulle--moi' : 'mi-bulle--autre');
        div.dataset.id = m.id;
        const d = parserDate(m.date_creation);
        div.innerHTML = `<div class="mi-bulle__texte">${echapper(m.contenu).replace(/\n/g, '<br>')}</div><div class="mi-bulle__heure">${d ? heureCourte(d) : ''}</div>`;
        return div;
    }

    function ajouterMessage(m) {
        // Retire « Chargement… » / « Aucun message » dès qu'un vrai message arrive
        const info = filCorps.querySelector('.mi-fil__chargement');
        if (info) info.remove();

        const d = parserDate(m.date_creation);
        if (d && d.toDateString() !== dernierJour) {
            dernierJour = d.toDateString();
            const sep = document.createElement('div');
            sep.className = 'mi-jour';
            sep.innerHTML = '<span>' + echapper(libelleJour(d)) + '</span>';
            filCorps.appendChild(sep);
        }
        filCorps.appendChild(creerBulle(m));
    }

    async function actualiserMessages(premierChargement) {
        const conv = conversationActive;
        const monJeton = jeton;
        if (!conv) return false;
        try {
            const messages = await appelAPI(`${API}?action=messages&conversation_id=${conv}&apres_id=${dernierId}`);
            if (monJeton !== jeton) return false;   // l'utilisateur a changé de conversation pendant l'attente
            if (!Array.isArray(messages)) throw new Error((messages && messages.erreur) || 'Réponse inattendue');
            masquerErreurReseau();
            delaiMessages = 2500;

            if (premierChargement) filCorps.innerHTML = '';

            // On ne force le défilement que si la personne est déjà en bas (ou si c'est son propre message)
            const procheDuBas = filCorps.scrollHeight - filCorps.scrollTop - filCorps.clientHeight < 80;
            let ajoutes = 0, deMoi = false;
            messages.forEach((m) => {
                const id = Number(m.id);
                if (idsAffiches.has(id)) return;
                idsAffiches.add(id);
                ajouterMessage(m);
                dernierId = Math.max(dernierId, id);
                ajoutes++;
                if (estMoi(m)) deMoi = true;
            });

            if (filCorps.children.length === 0) filCorps.innerHTML = '<div class="mi-fil__chargement">Aucun message. Écrivez le premier !</div>';
            if (premierChargement || (ajoutes && (procheDuBas || deMoi))) filCorps.scrollTop = filCorps.scrollHeight;
            if (ajoutes && !premierChargement) chargerConversations();
            return true;
        } catch (e) {
            if (monJeton === jeton) {
                if (premierChargement) filCorps.innerHTML = '<div class="mi-fil__chargement">Impossible de charger les messages. Nouvelle tentative…</div>';
                delaiMessages = Math.min(delaiMessages * 2, 15000);   // on espace les tentatives en cas de panne
                gererErreur(e);
            }
            return false;
        }
    }

    // Boucle de rafraîchissement : une seule requête à la fois, ralentie quand l'onglet est caché
    function planifierMessages() {
        clearTimeout(minuteurMessages);
        if (!conversationActive) return;
        const monJeton = jeton;
        minuteurMessages = setTimeout(async () => {
            if (monJeton !== jeton) return;
            if (!document.hidden) await actualiserMessages(false);
            if (monJeton === jeton) planifierMessages();
        }, document.hidden ? 10000 : delaiMessages);
    }

    function afficherLienInfosTechnicien(type, id) {
        const afficher = document.body.classList.contains('page-partenaire-messagerie-interne')
            && type === 'technicien' && Number(id) > 0;
        lienInfosTechnicien.hidden = !afficher;
        lienInfosTechnicien.href = afficher ? `detail-technicien.php?id=${encodeURIComponent(Number(id))}&retour=messagerie` : '#';
    }

    lienInfosTechnicien.addEventListener('click', () => {
        if (!contactActif) return;
        sessionStorage.setItem('allopro_messagerie_retour_technicien', JSON.stringify({
            conversationId: conversationActive,
            contact: contactActif
        }));
    });

    async function ouvrirConversation(conversationId, nom, sousTitre, autreType, autreId, photoProfil, avatarInitiales) {
        conversationId = Number(conversationId);
        if (!conversationId) return;

        if (conversationId === conversationActive) {   // déjà ouverte : on s'assure juste qu'elle est visible
            fil.classList.add('mi-fil--visible');
            afficherLienInfosTechnicien(autreType, autreId);
            champMessage.focus();
            return;
        }

        conversationActive = conversationId;
        window.MI_CONVERSATION_ACTIVE = conversationId;
        contactEnAttente = null;
        contactActif = { type: String(autreType || ''), id: String(autreId || ''), nom, sousTitre: sousTitre || '', photoProfil: photoProfil || '', avatarInitiales: !!avatarInitiales };
        jeton++;
        dernierId = 0;
        dernierJour = '';
        idsAffiches.clear();
        clearTimeout(minuteurMessages);

        filVide.style.display = 'none';
        fil.classList.add('mi-fil--visible');
        afficherAvatarEntete(nom, autreType, photoProfil, avatarInitiales);
        filNom.textContent = nom;
        filSousTitre.textContent = sousTitre || '';
        afficherLienInfosTechnicien(autreType, autreId);
        filCorps.innerHTML = '<div class="mi-fil__chargement">Chargement…</div>';
        marquerConversationActive();

        const monJeton = jeton;
        await actualiserMessages(true);
        if (monJeton !== jeton) return;
        planifierMessages();
        signatureListe = '';
        chargerConversations();
        champMessage.focus();
    }

    // Ouvre la fenêtre de discussion avec un contact qui n'a encore jamais reçu de message :
    // rien n'est enregistré tant que rien n'est envoyé.
    function ouvrirBrouillon(type, id, nom, sousTitre, photoProfil, avatarInitiales) {
        conversationActive = null;
        window.MI_CONVERSATION_ACTIVE = null;
        contactEnAttente = { type: String(type), id: String(id) };
        contactActif = { type: String(type), id: String(id), nom, sousTitre: sousTitre || '', photoProfil: photoProfil || '', avatarInitiales: !!avatarInitiales };
        jeton++;
        dernierId = 0;
        dernierJour = '';
        idsAffiches.clear();
        clearTimeout(minuteurMessages);

        filVide.style.display = 'none';
        fil.classList.add('mi-fil--visible');
        afficherAvatarEntete(nom, type, photoProfil, avatarInitiales);
        filNom.textContent = nom;
        filSousTitre.textContent = sousTitre || '';
        afficherLienInfosTechnicien(type, id);
        filCorps.innerHTML = '<div class="mi-fil__chargement">Aucun message. Écrivez le premier !</div>';
        marquerConversationActive();   // aucune ligne de la liste n'est sélectionnée
        signatureListe = '';
        chargerConversations();
        champMessage.focus();
    }

    function fermerConversation() {
        conversationActive = null;
        window.MI_CONVERSATION_ACTIVE = null;
        contactEnAttente = null;
        contactActif = null;
        jeton++;
        clearTimeout(minuteurMessages);
        fil.classList.remove('mi-fil--visible');
        filVide.style.display = '';
        afficherLienInfosTechnicien('', 0);
        signatureListe = '';
        chargerConversations();
    }
    if (btnRetour) btnRetour.addEventListener('click', fermerConversation);
    rechercheConversationsEl.addEventListener('input', filtrerConversations);

    // Liste : clic et clavier (Entrée / Espace)
    function activerItem(e) {
        const item = e.target.closest('.mi-item');
        if (item) ouvrirConversation(item.dataset.id, item.dataset.nom, item.dataset.soustitre, item.dataset.autreType, item.dataset.autreId, item.dataset.photoProfil, item.dataset.avatarInitiales === '1');
    }
    listeEl.addEventListener('click', activerItem);
    listeEl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activerItem(e); }
    });

    // ---------- Envoi ----------
    function ajusterHauteur() {
        if (champMessage.tagName !== 'TEXTAREA') return;
        champMessage.style.height = 'auto';
        champMessage.style.height = Math.min(champMessage.scrollHeight, 140) + 'px';
    }

    async function envoyerMessage() {
        const contenu = champMessage.value.trim();
        const conv = conversationActive;
        const attente = contactEnAttente;
        if (!contenu || (!conv && !attente) || envoiEnCours) return;

        envoiEnCours = true;
        btnEnvoyer.disabled = true;
        champMessage.value = '';
        ajusterHauteur();

        try {
            // Conversation existante : on envoie dedans. Sinon c'est le premier message : l'API crée la conversation.
            const reponse = await postAPI(conv
                ? { action: 'envoyer', conversation_id: conv, contenu: contenu }
                : { action: 'envoyer', autre_type: attente.type, autre_id: attente.id, contenu: contenu });
            if (reponse && reponse.erreur) throw new Error(reponse.erreur);

            if (!conv) {
                // La conversation vient d'être enregistrée avec ce premier message
                if (contactEnAttente === attente && reponse.conversation_id) {   // l'utilisateur n'est pas parti ailleurs entre-temps
                    conversationActive = Number(reponse.conversation_id);
                    window.MI_CONVERSATION_ACTIVE = conversationActive;
                    contactEnAttente = null;
                    if (contactActif) contactActif = Object.assign({}, contactActif);
                    jeton++;
                    dernierId = 0;
                    dernierJour = '';
                    idsAffiches.clear();
                    await actualiserMessages(true);
                    planifierMessages();
                }
                signatureListe = '';
                chargerConversations();
            } else if (conv === conversationActive) {
                await actualiserMessages(false);
            }
        } catch (e) {
            // Le message n'est plus perdu : on le remet dans le champ pour réessayer
            if (!champMessage.value) { champMessage.value = contenu; ajusterHauteur(); }
            afficherErreur(e.session
                ? 'Votre session a expiré. Rechargez la page.'
                : (e.serveur || "Le message n'a pas pu être envoyé. Réessayez."));
        } finally {
            envoiEnCours = false;
            btnEnvoyer.disabled = false;
            champMessage.focus();
        }
    }

    btnEnvoyer.addEventListener('click', envoyerMessage);
    champMessage.addEventListener('input', ajusterHauteur);
    champMessage.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); envoyerMessage(); }
    });

    // ---------- Carnet d'adresses ----------
    const modale = $('mi-modale-contacts');
    const contactsListeEl = $('mi-contacts-liste');
    const rechercheEl = $('mi-recherche-contact');
    let contactsBruts = null;
    let ouvertureEnCours = false;

    const fermerModale = () => modale.classList.remove('mi-modale-fond--visible');
    const modaleOuverte = () => modale.classList.contains('mi-modale-fond--visible');

    $('mi-ouvrir-contacts').addEventListener('click', async () => {
        contactsListeEl.innerHTML = '<div class="mi-fil__chargement">Chargement…</div>';
        modale.classList.add('mi-modale-fond--visible');
        try {
            contactsBruts = await appelAPI(API + '?action=contacts');
            rechercheEl.value = '';
            rendreContacts('');
            rechercheEl.focus();
        } catch (e) {
            contactsListeEl.innerHTML = '<div class="mi-vide">Impossible de charger les contacts. Fermez puis réessayez.</div>';
            gererErreur(e);
        }
    });
    $('mi-demarrer-conversation').addEventListener('click', () => $('mi-ouvrir-contacts').click());
    $('mi-fermer-contacts').addEventListener('click', fermerModale);
    modale.addEventListener('click', (e) => { if (e.target === modale) fermerModale(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modaleOuverte()) fermerModale(); });

    function ligneContact(type, id, nom, sousTitre, photoProfil, avatarInitiales) {
        return `<div class="mi-contact-item" role="button" tabindex="0" data-type="${echapper(type)}" data-id="${echapper(id)}">
                    ${avatarHTML(nom, type, photoProfil, avatarInitiales, 'mi-contact-item__avatar')}
                    <div><div class="mi-contact-item__nom">${echapper(nom)}</div><div class="mi-contact-item__soustitre">${echapper(sousTitre || '')}</div></div>
                </div>`;
    }

    function rendreContacts(termeBrut) {
        if (!contactsBruts) return;
        const terme = normaliser(termeBrut);
        const contient = (nom) => normaliser(nom).includes(terme);
        let html = '';

        const equipe = (contactsBruts.equipe || []).filter((m) => contient(m.nom));
        if (equipe.length > 0) {
            html += '<div class="mi-groupe-titre">Équipe ALLÔ PRO</div>';
            equipe.forEach((m) => { html += ligneContact('equipe', m.id, m.nom, m.role_libelle || m.role); });
        }

        if (window.MI_MOI_TYPE === 'equipe') {
            (contactsBruts.partenaires || []).forEach((p) => {
                const techniciens = p.techniciens || [];
                const techMatch = techniciens.filter((t) => contient(t.nom));
                const partenaireMatch = contient(p.nom);
                if (!terme || partenaireMatch || techMatch.length > 0) {
                    html += '<div class="mi-groupe-titre">' + echapper(p.nom) + '</div>';
                    html += ligneContact('partenaire', p.id, p.nom, "Contacter l'entreprise");
                    (terme && !partenaireMatch ? techMatch : techniciens).forEach((t) => {
                        html += ligneContact('technicien', t.id, t.nom, t.metier, t.photo_profil, t.avatar_initiales);
                    });
                }
            });
        } else if (window.MI_MOI_TYPE === 'partenaire') {
            const techs = (contactsBruts.techniciens || []).filter((t) => contient(t.nom));
            if (techs.length > 0) {
                html += '<div class="mi-groupe-titre">Mes techniciens</div>';
                techs.forEach((t) => { html += ligneContact('technicien', t.id, t.nom, t.metier, t.photo_profil, t.avatar_initiales); });
            }
        } else {
            const emp = contactsBruts.employeur;
            if (emp && (!terme || contient(emp.nom_entreprise))) {
                html += '<div class="mi-groupe-titre">Mon employeur</div>';
                html += ligneContact('partenaire', emp.id, emp.nom_entreprise, 'Entreprise');
            }
            const collegues = (contactsBruts.collegues || []).filter((t) => contient(t.nom));
            if (collegues.length > 0) {
                html += '<div class="mi-groupe-titre">Collègues</div>';
                collegues.forEach((t) => { html += ligneContact('technicien', t.id, t.nom, t.metier, t.photo_profil, t.avatar_initiales); });
            }
        }

        contactsListeEl.innerHTML = html || '<div class="mi-vide">Aucun contact trouvé.</div>';
    }

    let debounceRecherche;
    rechercheEl.addEventListener('input', () => {
        clearTimeout(debounceRecherche);
        debounceRecherche = setTimeout(() => rendreContacts(rechercheEl.value.trim()), 150);
    });

    async function choisirContact(e) {
        const item = e.target.closest('.mi-contact-item');
        if (!item || ouvertureEnCours) return;
        ouvertureEnCours = true;
        item.classList.add('mi-contact-item--attente');
        try {
            const data = await postAPI({ action: 'ouvrir', autre_type: item.dataset.type, autre_id: item.dataset.id });
            if (data.erreur) { afficherErreur(data.erreur); return; }
            if (!data.contact || typeof data.contact !== 'object') throw new Error('Contact invalide');

            fermerModale();
            signatureListe = '';
            if (data.conversation_id) await ouvrirConversation(data.conversation_id, data.contact.nom, data.contact.sous_titre, item.dataset.type, item.dataset.id, data.contact.photo_profil, data.contact.avatar_initiales);
            else ouvrirBrouillon(item.dataset.type, item.dataset.id, data.contact.nom, data.contact.sous_titre, data.contact.photo_profil, data.contact.avatar_initiales);   // jamais écrit : rien n'est créé en base
        } catch (err) {
            afficherErreur(err.session
                ? 'Votre session a expiré. Rechargez la page.'
                : (err.serveur || "Impossible d'ouvrir la conversation. Réessayez."));
        } finally {
            ouvertureEnCours = false;
            item.classList.remove('mi-contact-item--attente');
        }
    }
    contactsListeEl.addEventListener('click', choisirContact);
    contactsListeEl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); choisirContact(e); }
    });

    // ---------- Rafraîchissement de la liste (en continu, ralenti si l'onglet est caché) ----------
    function boucleListe() {
        setTimeout(async () => {
            if (!document.hidden) await chargerConversations();
            boucleListe();
        }, document.hidden ? 15000 : 4000);
    }

    // Au retour sur l'onglet ou au retour du réseau : mise à jour immédiate
    function rattraper() {
        if (document.hidden) return;
        chargerConversations();
        if (conversationActive) { delaiMessages = 2500; actualiserMessages(false).then(planifierMessages); }
    }
    document.addEventListener('visibilitychange', rattraper);
    window.addEventListener('online', rattraper);

    const paramsRetour = new URLSearchParams(window.location.search);
    if (paramsRetour.get('restaurer_conversation') === '1') {
        const retourEnregistre = sessionStorage.getItem('allopro_messagerie_retour_technicien');
        sessionStorage.removeItem('allopro_messagerie_retour_technicien');
        window.history.replaceState(null, '', window.location.pathname);
        if (retourEnregistre) {
            try {
                const retour = JSON.parse(retourEnregistre);
                if (retour && retour.contact && retour.contact.type === 'technicien' && Number(retour.contact.id) > 0) {
                    if (Number(retour.conversationId) > 0) {
                        ouvrirConversation(retour.conversationId, retour.contact.nom, retour.contact.sousTitre, retour.contact.type, retour.contact.id, retour.contact.photoProfil, retour.contact.avatarInitiales);
                    } else {
                        ouvrirBrouillon(retour.contact.type, retour.contact.id, retour.contact.nom, retour.contact.sousTitre);
                    }
                } else {
                    afficherErreur('La conversation précédente n’a pas pu être restaurée. Ouvrez-la à nouveau depuis la liste.');
                }
            } catch (e) {
                console.warn('[Messagerie] restauration de conversation invalide', e);
                afficherErreur('La conversation précédente n’a pas pu être restaurée. Ouvrez-la à nouveau depuis la liste.');
            }
        } else {
            afficherErreur('La conversation précédente n’est plus disponible. Ouvrez-la à nouveau depuis la liste.');
        }
    }
    chargerConversations();
    boucleListe();
})();