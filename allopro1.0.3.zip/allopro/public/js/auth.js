document.querySelectorAll('.auth-password-toggle').forEach(function (toggle) {
    toggle.addEventListener('change', function () {
        var champ = toggle.closest('.champ, .profil-champ');
        var motDePasse = champ && champ.querySelector('.auth-password-field');

        if (motDePasse) {
            motDePasse.type = toggle.checked ? 'text' : 'password';
        }
    });
});
