// ---------- Utilitaires ----------
function echapper(s) {
    return String(s ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
const versHtml = (t) => echapper(t).replace(/\n/g, '<br>');

// ---------- Fil de messages ----------
const filCorps = document.getElementById('fil-corps');
let clientActifId = filCorps ? filCorps.dataset.clientId : null;
let quitterConversation = null;
if (filCorps) {
    const clientId = filCorps.dataset.clientId;
    const viewer = filCorps.dataset.viewer;
    let dernierId = 0;

    const bulles = filCorps.querySelectorAll('[data-id]');
    if (bulles.length > 0) dernierId = bulles[bulles.length - 1].dataset.id;

    filCorps.scrollTop = filCorps.scrollHeight;

    function creerBulle(m) {
        const div = document.createElement('div');
        div.className = 'bulle ' + (m.expediteur_type === viewer ? 'bulle--moi' : 'bulle--autre');
        div.dataset.id = m.id;
        div.dataset.lu = m.lu ?? 0;
        div.dataset.luDate = m.lu_date ?? '';
        div.dataset.modifie = m.modifie ?? 0;
        const date = new Date(m.date_creation.replace(' ', 'T'));
        const heure = date.toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
        div.innerHTML =
            `<div class="bulle__meta">${echapper(m.nom_expediteur || m.expediteur_type)} · ${heure}</div>` +
            `<div class="bulle__texte">${versHtml(m.contenu)}</div>`;
        return div;
    }

    let enCours = false;
    let relancer = false;

    async function verifierNouveaux() {
        if (enCours) { relancer = true; return; }
        enCours = true;
        try {
            const res = await fetch(`/allopro/public/api-messages.php?client_id=${encodeURIComponent(clientId)}&apres_id=${encodeURIComponent(dernierId)}`);
            if (!res.ok) throw new Error();
            const nouveaux = await res.json();
            if (Array.isArray(nouveaux) && nouveaux.length > 0) {
                const enBas = filCorps.scrollHeight - filCorps.scrollTop - filCorps.clientHeight < 80;
                nouveaux.forEach(m => {
                    if (!filCorps.querySelector(`[data-id="${m.id}"]`)) filCorps.appendChild(creerBulle(m));
                    dernierId = m.id;
                });
                if (enBas) filCorps.scrollTop = filCorps.scrollHeight;
            }
        } catch (e) { /* silencieux */ }
        finally {
            enCours = false;
            if (relancer) { relancer = false; verifierNouveaux(); }
        }
    }

    const pollTimer = setInterval(verifierNouveaux, 3000);

    // Quitter la conversation sans recharger la page
    let conversationOuverte = true;
    quitterConversation = function () {
        if (!conversationOuverte) return;
        conversationOuverte = false;
        clearInterval(pollTimer);

        const fil = filCorps.closest('.fil') || filCorps;
        fil.style.display = 'none';

        if (!document.getElementById('fil-placeholder')) {
            const p = document.createElement('div');
            p.id = 'fil-placeholder';
            p.style.cssText = 'flex:1;display:flex;align-items:center;justify-content:center;color:#6B7280;font-size:14px;';
            p.textContent = 'Sélectionnez une conversation';
            fil.insertAdjacentElement('afterend', p);
        }

        // Masque le panneau d'informations du client
        document.querySelectorAll('[data-fiche-client], .info-client, #infos-client, .infos-client, .fiche-client, .reponses-rapides')
            .forEach(el => { el.style.display = 'none'; });

        document.body.classList.remove('a-conversation');   // mobile : réaffiche la liste

        clientActifId = null;
        document.querySelectorAll('.conv-item--active').forEach(el => el.classList.remove('conv-item--active'));

        const url = filCorps.dataset.retour;
        if (url) history.pushState(null, '', url);
    };

    // Bouton « précédent » du navigateur : on recharge l'état correspondant
    window.addEventListener('popstate', () => location.reload());

    const btnEnvoyer = document.getElementById('btn-envoyer');
    const champMessage = document.getElementById('champ-message');

    if (btnEnvoyer && champMessage) {
        btnEnvoyer.addEventListener('click', async () => {
            const contenu = champMessage.value.trim();
            if (!contenu || btnEnvoyer.disabled) return;
            btnEnvoyer.disabled = true;
            try {
                const res = await fetch('/allopro/public/api-messages.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `client_id=${encodeURIComponent(clientId)}&contenu=${encodeURIComponent(contenu)}`
                });
                if (!res.ok) throw new Error();
                champMessage.value = '';
                await verifierNouveaux();
                filCorps.scrollTop = filCorps.scrollHeight;
            } catch (e) {
                alert("Le message n'a pas pu être envoyé.");
            } finally {
                btnEnvoyer.disabled = false;
                champMessage.focus();
            }
        });

        champMessage.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); btnEnvoyer.click(); }
        });
    }
}

// ---------- Liste des conversations ----------
const convListe = document.getElementById('conv-liste');
if (convListe) {
    function initiales(nom) {
        const parties = String(nom ?? '').trim().split(/\s+/);
        const premiere = parties[0]?.[0] || '';
        const derniere = parties.length > 1 ? parties[parties.length - 1][0] : '';
        return (premiere + derniere).toUpperCase();
    }

    function rendreListe(conversations) {
        if (conversations.length === 0) {
            convListe.innerHTML = '<div class="conv-liste__entete">Conversations</div><p style="padding:20px; color:#6B7280; font-size:14px;">Aucune conversation pour le moment.</p>';
            return;
        }

        let html = '<div class="conv-liste__entete">Conversations</div>';
        conversations.forEach(c => {
            const actif = String(c.id) === String(clientActifId) ? 'conv-item--active' : '';
            const apercu = c.dernier_message
                ? echapper(c.dernier_message)
                : '<em>Aucun message</em>';
            const date = c.derniere_date
                ? new Date(c.derniere_date.replace(' ', 'T')).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })
                : '';
            const badge = c.non_lus > 0 ? `<span class="conv-item__badge">${echapper(c.non_lus)}</span>` : '';

            html += `
                <a href="messagerie.php?client_id=${encodeURIComponent(c.id)}" class="conv-item ${actif}">
                    <div class="conv-item__avatar">${echapper(initiales(c.nom))}</div>
                    <div class="conv-item__contenu">
                        <div class="conv-item__haut">
                            <span class="conv-item__nom">${echapper(c.nom)}</span>
                            <span class="conv-item__date">${date}</span>
                        </div>
                        <div class="conv-item__apercu">${apercu}</div>
                    </div>
                    ${badge}
                </a>`;
        });
        convListe.innerHTML = html;
    }

    let listeEnCours = false;
    async function actualiserListe() {
        if (listeEnCours) return;
        listeEnCours = true;
        try {
            const res = await fetch('/allopro/public/api-conversations.php');
            if (!res.ok) throw new Error();
            const conversations = await res.json();
            if (Array.isArray(conversations)) rendreListe(conversations);
        } catch (e) { /* silencieux */ }
        finally { listeEnCours = false; }
    }

    setInterval(actualiserListe, 5000);
}

// ---------- Menu contextuel (Copier / Modifier) ----------
const menuContextuel = document.getElementById('menu-contextuel');
if (menuContextuel) {
    const modaleFond = document.getElementById('modale-fond');
    const modaleTextarea = document.getElementById('modale-textarea');
    const btnCopier = document.getElementById('btn-copier');
    const btnModifier = document.getElementById('btn-modifier');
    const btnAnnuler = document.getElementById('modale-annuler');
    const btnValider = document.getElementById('modale-valider');
    let bulleCiblee = null;

    function fermerMenu() { menuContextuel.style.display = 'none'; }
    function fermerModale() { modaleFond.style.display = 'none'; }

    // Petit message de confirmation
    function toast(texte) {
        document.querySelectorAll('.toast-msg').forEach(el => el.remove());
        const t = document.createElement('div');
        t.className = 'toast-msg';
        t.textContent = texte;
        t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);' +
            'background:#111827;color:#fff;padding:8px 16px;border-radius:8px;font-size:14px;z-index:10000;';
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 3000);
    }

    // Copie : clipboard API (HTTPS/localhost) avec repli pour HTTP
    async function copierTexte(texte) {
        if (navigator.clipboard && window.isSecureContext) {
            try { await navigator.clipboard.writeText(texte); return true; } catch (e) { /* repli */ }
        }
        const ta = document.createElement('textarea');
        ta.value = texte;
        ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
        document.body.appendChild(ta);
        ta.select();
        let ok = false;
        try { ok = document.execCommand('copy'); } catch (e) { /* ignore */ }
        ta.remove();
        return ok;
    }

    function peutModifierCoteClient(bulle) {
        const lu = bulle.dataset.lu === '1';
        const luDate = bulle.dataset.luDate;
        if (!lu || !luDate) return true;
        const secondesEcoulees = (Date.now() - new Date(luDate.replace(' ', 'T')).getTime()) / 1000;
        return secondesEcoulees <= 90;
    }

    function ouvrirMenu(bulle, x, y) {
        bulleCiblee = bulle;
        const estMoi = bulle.classList.contains('bulle--moi');
        const modifiable = estMoi && peutModifierCoteClient(bulle);

        btnModifier.style.display = estMoi ? 'block' : 'none';
        btnModifier.classList.toggle('menu-contextuel__item--desactive', !modifiable);
        btnModifier.dataset.modifiable = modifiable;

        menuContextuel.style.display = 'block';
        const px = Math.min(x, window.innerWidth - menuContextuel.offsetWidth - 8);
        const py = Math.min(y, window.innerHeight - menuContextuel.offsetHeight - 8);
        menuContextuel.style.left = Math.max(8, px) + 'px';
        menuContextuel.style.top = Math.max(8, py) + 'px';
    }

    // Clic droit (ordinateur)
    document.addEventListener('contextmenu', (e) => {
        const bulle = e.target.closest('.bulle');
        if (!bulle) return;
        e.preventDefault();
        ouvrirMenu(bulle, e.clientX, e.clientY);
    });

    // Appui long (mobile)
    let timerAppui = null;
    document.addEventListener('touchstart', (e) => {
        const bulle = e.target.closest('.bulle');
        if (!bulle) return;
        const t = e.touches[0];
        timerAppui = setTimeout(() => ouvrirMenu(bulle, t.clientX, t.clientY), 500);
    }, { passive: true });
    ['touchend', 'touchmove', 'touchcancel'].forEach(ev =>
        document.addEventListener(ev, () => clearTimeout(timerAppui), { passive: true })
    );

    document.addEventListener('click', (e) => {
        if (!menuContextuel.contains(e.target)) fermerMenu();
    });

    // Copier
    btnCopier.addEventListener('click', async () => {
        const zone = bulleCiblee?.querySelector('.bulle__texte');
        fermerMenu();
        if (!zone) return;
        const ok = await copierTexte(zone.innerText);
        toast(ok ? 'Message copié' : 'Copie impossible');
    });

    // Modifier
    btnModifier.addEventListener('click', () => {
        if (btnModifier.dataset.modifiable !== 'true') {
            fermerMenu();
            alert("Ce message ne peut plus être modifié.");
            return;
        }
        const zone = bulleCiblee?.querySelector('.bulle__texte');
        if (!zone) return;
        modaleTextarea.value = zone.innerText;
        modaleFond.style.display = 'flex';
        modaleTextarea.focus();
        fermerMenu();
    });

    btnAnnuler.addEventListener('click', fermerModale);

    btnValider.addEventListener('click', async () => {
        const nouveauContenu = modaleTextarea.value.trim();
        if (!nouveauContenu || !bulleCiblee || btnValider.disabled) return;

        const bulle = bulleCiblee;
        btnValider.disabled = true;
        try {
            const res = await fetch('/allopro/public/api-message-modifier.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `message_id=${encodeURIComponent(bulle.dataset.id)}&contenu=${encodeURIComponent(nouveauContenu)}`
            });
            const data = await res.json();

            if (data.ok) {
                const zone = bulle.querySelector('.bulle__texte');
                if (zone) zone.innerHTML = versHtml(data.contenu ?? nouveauContenu);
                bulle.dataset.modifie = '1';
                const meta = bulle.querySelector('.bulle__meta');
                if (meta && !meta.querySelector('.bulle__modifie')) {
                    meta.insertAdjacentHTML('beforeend', ' · <span class="bulle__modifie">modifié</span>');
                }
                fermerModale();
                toast('Message modifié');
            } else {
                alert(data.erreur || "Impossible de modifier ce message.");
                fermerModale();
            }
        } catch (e) {
            alert("Erreur : le message n'a pas pu être modifié.");
        } finally {
            btnValider.disabled = false;
        }
    });
}

// ---------- Échap : ferme d'abord menu/modale, sinon quitte la conversation ----------
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || e.isComposing) return;

    const estOuvert = (el) => el && getComputedStyle(el).display !== 'none';

    const menu = document.getElementById('menu-contextuel');
    if (estOuvert(menu)) { menu.style.display = 'none'; return; }

    const modale = document.getElementById('modale-fond');
    if (estOuvert(modale)) { modale.style.display = 'none'; return; }

    // Modale des réponses rapides
    const rrModale = document.querySelector('.rr-modale-fond--visible');
    if (rrModale) { rrModale.classList.remove('rr-modale-fond--visible'); return; }

    // Si on est en train d'écrire un message, le premier Échap retire seulement le focus
    const champ = document.getElementById('champ-message');
    if (champ && document.activeElement === champ && champ.value.trim() !== '') {
        champ.blur();
        return;
    }

    // Page conseiller (liste + fil) : on quitte sans recharger
    if (quitterConversation && document.getElementById('conv-liste')) {
        quitterConversation();
        return;
    }

    // Page client (pas de liste) : redirection
    const url = document.getElementById('fil-corps')?.dataset.retour;
    if (url) window.location.href = url;
});