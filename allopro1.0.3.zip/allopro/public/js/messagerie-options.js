(function () {
    'use strict';

    const boutonOptions = document.getElementById('btn-options-conversation');
    const menuOptions = document.getElementById('menu-options-conversation');
    const boutonAction = document.getElementById('btn-action-conversation');
    if (!boutonOptions || !menuOptions || !boutonAction) return;

    function fermerMenu(rendreFocus) {
        menuOptions.hidden = true;
        boutonOptions.setAttribute('aria-expanded', 'false');
        if (rendreFocus) boutonOptions.focus();
    }

    boutonOptions.addEventListener('click', () => {
        const ouvrir = menuOptions.hidden;
        menuOptions.hidden = !ouvrir;
        boutonOptions.setAttribute('aria-expanded', ouvrir ? 'true' : 'false');
        if (ouvrir) boutonAction.focus();
    });

    document.addEventListener('click', (event) => {
        if (!event.target.closest('.conversation-options')) fermerMenu(false);
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !menuOptions.hidden) {
            event.stopImmediatePropagation();
            fermerMenu(true);
        }
    }, true);

    boutonAction.addEventListener('click', async () => {
        if (boutonAction.disabled) return;
        let conseillerId = boutonAction.dataset.conseillerId;
        if (boutonAction.dataset.action === 'reouvrir_conversation' && !Number(conseillerId)) {
            const selectConseiller = document.querySelector('.select-reaffectation');
            conseillerId = selectConseiller?.value || '';
            if (!conseillerId) {
                window.alert('Choisissez d’abord le conseiller dans la liste d’affectation, puis réouvrez la conversation.');
                selectConseiller?.focus();
                return;
            }
        }
        boutonAction.disabled = true;
        try {
            const reponse = await fetch('/allopro/public/api-messages.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: boutonAction.dataset.action,
                    client_id: boutonAction.dataset.clientId,
                    conseiller_id: conseillerId,
                    csrf: boutonAction.dataset.csrf
                })
            });
            const resultat = await reponse.json();
            if (!reponse.ok || !resultat.ok) throw new Error(resultat.erreur || 'La conversation n’a pas pu être mise à jour.');

            const retour = document.getElementById('fil-corps')?.dataset.retour || 'messagerie.php';
            if (boutonAction.dataset.action === 'reouvrir_conversation') {
                window.location.href = `${retour}?client_id=${encodeURIComponent(boutonAction.dataset.clientId)}`;
            } else {
                window.location.reload();
            }
        } catch (erreur) {
            window.alert(erreur.message || 'La conversation n’a pas pu être mise à jour. Réessayez.');
            boutonAction.disabled = false;
        }
    });
})();