<?php
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../includes/auth.php';
ini_set('display_errors', '0');
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['erreur' => 'Votre session a expiré. Reconnectez-vous puis réessayez.'], JSON_UNESCAPED_UNICODE);
    exit;
}
rafraichirCompteConnecte();
require_once __DIR__ . '/../models/Message.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Parametre.php';

$estClient = $_SESSION['role'] === 'client';
$clientId = $estClient ? $_SESSION['user_id'] : ($_GET['client_id'] ?? $_POST['client_id'] ?? null);

$expediteurType = $estClient ? 'client' : 'conseiller';
$messageModel = new Message();
$userModel = new User();

if (in_array($_GET['action'] ?? $_POST['action'] ?? '', ['fermer_conversation', 'reouvrir_conversation', 'desactiver_client'], true)) {
    $actionConversation = $_GET['action'] ?? $_POST['action'];
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['erreur' => 'Méthode non autorisée']);
        exit;
    }

    verifierAcces('messagerie');
    $roleActeur = $_SESSION['role'] ?? '';
    if ($actionConversation === 'desactiver_client') {
        if ($roleActeur !== 'admin') {
            http_response_code(403);
            echo json_encode(['erreur' => 'Seul un admin peut désactiver un client.']);
            exit;
        }
        $csrf = (string) ($_POST['csrf'] ?? '');
        if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $csrf)) {
            http_response_code(403);
            echo json_encode(['erreur' => 'Jeton de sécurité invalide. Rechargez la page.']);
            exit;
        }
        $cibleClientId = filter_var($_POST['client_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!$cibleClientId) {
            http_response_code(400);
            echo json_encode(['erreur' => 'Client invalide.']);
            exit;
        }
        $client = $userModel->getById($cibleClientId);
        if (!$client || ($client['role'] ?? '') !== 'client') {
            http_response_code(404);
            echo json_encode(['erreur' => 'Client introuvable.']);
            exit;
        }
        if (!$userModel->changerStatut($cibleClientId, 'suspendu')) {
            http_response_code(500);
            echo json_encode(['erreur' => 'La désactivation du client a échoué.']);
            exit;
        }
        journaliser('client.suspendu', 'compte', $cibleClientId, $client['matricule'] ?? null, $client['nom'] ?? 'Client');
        echo json_encode(['ok' => true]);
        exit;
    }

    if (!in_array($roleActeur, ['conseiller', 'coordinateur', 'admin'], true)) {
        http_response_code(403);
        echo json_encode(['erreur' => 'Accès refusé pour gérer cette conversation.']);
        exit;
    }

    $csrf = (string) ($_POST['csrf'] ?? '');
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $csrf)) {
        http_response_code(403);
        echo json_encode(['erreur' => 'Jeton de sécurité invalide. Rechargez la page.']);
        exit;
    }

    $cibleClientId = filter_var($_POST['client_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!$cibleClientId) {
        http_response_code(400);
        echo json_encode(['erreur' => 'Client invalide.']);
        exit;
    }

    $conseillerId = $roleActeur === 'conseiller'
        ? (int) $_SESSION['user_id']
        : (filter_var($_POST['conseiller_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) ?: 0);
    if (!$conseillerId) {
        http_response_code(400);
        echo json_encode(['erreur' => 'Conseiller affecté introuvable.']);
        exit;
    }

    $parametreModel = new Parametre();
    $resultat = $actionConversation === 'fermer_conversation'
        ? $userModel->fermerConversationEtAttribuerSuivant(
            $cibleClientId,
            $conseillerId,
            $parametreModel->attributionAutomatiqueActive(),
            $parametreModel->getLimiteClientsParConseiller()
        )
        : $userModel->reouvrirConversationAttribuee(
            $cibleClientId,
            $conseillerId,
            0
        );
    if ($resultat === 'limite') {
        http_response_code(409);
        echo json_encode(['erreur' => 'Le plafond de clients ouverts de ce conseiller est atteint. Clôturez une autre conversation avant de la réouvrir.']);
        exit;
    }
    if ($resultat === false) {
        http_response_code(409);
        echo json_encode(['erreur' => 'Le statut ou l’affectation de cette conversation a changé. Actualisez la page puis réessayez.']);
        exit;
    }

    if ($actionConversation === 'fermer_conversation') {
        journaliser('conversation.fermee', 'compte', $cibleClientId, null, 'Clôturée par ' . $roleActeur . ' ID ' . (int) $_SESSION['user_id']);
        if (!empty($resultat['client_suivant_id'])) {
            journaliser('conversation.attribuee', 'compte', $resultat['client_suivant_id'], null, 'Affectation automatique au conseiller ID ' . $conseillerId . ' après clôture');
        }
        echo json_encode(['ok' => true, 'client_suivant_id' => $resultat['client_suivant_id']]);
    } else {
        journaliser('conversation.reouverte', 'compte', $cibleClientId, null, 'Réouverte par ' . $roleActeur . ' ID ' . (int) $_SESSION['user_id'] . ' pour le conseiller ID ' . $conseillerId);
        echo json_encode(['ok' => true, 'conversation_reouverte' => true, 'client_suivant_id' => null]);
    }
    exit;
}

if (!$clientId) { http_response_code(400); echo json_encode(['erreur' => 'client manquant']); exit; }

if (!$estClient) {
    verifierAcces('messagerie');

    if (($_SESSION['role'] ?? '') === 'conseiller') {
        $assigneId = $userModel->getConseillerAssigne($clientId);
        if (!$assigneId) {
            $userModel->reassignerConseiller($clientId, $_SESSION['user_id']); // conversation orpheline : il la prend
        } elseif ((int) $assigneId !== (int) $_SESSION['user_id']) {
            http_response_code(403);
            echo json_encode(['erreur' => 'Cette conversation est assignée à un autre conseiller.']);
            exit;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $contenu = trim((string) ($_POST['contenu'] ?? ''));
    if (mb_strlen($contenu) > 2000) {
        http_response_code(413);
        echo json_encode(['erreur' => 'Le message dépasse 2 000 caractères.']);
        exit;
    }

    $fichierImage = $_FILES['image'] ?? null;
    $fichierAudio = $_FILES['audio'] ?? $_FILES['voice'] ?? null;
    $aImage = is_array($fichierImage) && ($fichierImage['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    $aAudio = is_array($fichierAudio) && ($fichierAudio['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    $cheminImage = null;
    $cheminAudio = null;

    if ($aImage && $aAudio) {
        http_response_code(400);
        echo json_encode(['erreur' => 'Choisissez soit une image, soit une note vocale.']);
        exit;
    }

    if ($aImage || $aAudio) {
        if ($aImage && !$estClient) {
            http_response_code(403);
            echo json_encode(['erreur' => 'Seul un client peut joindre une image.']);
            exit;
        }
        if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
            http_response_code(403);
            echo json_encode(['erreur' => 'Jeton de sécurité invalide. Rechargez la page.']);
            exit;
        }
    }

    if ($aImage) {
        if (($fichierImage['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode(['erreur' => 'Le transfert de l’image a échoué. Réessayez.']);
            exit;
        }

        $tailleMaxImage = 1572864;
        if (($fichierImage['size'] ?? 0) <= 0 || $fichierImage['size'] > $tailleMaxImage) {
            http_response_code(413);
            echo json_encode(['erreur' => 'L’image doit faire 1,5 Mo maximum.']);
            exit;
        }

        $typesImageAcceptes = ['image/jpeg', 'image/png', 'image/webp'];
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $typeImage = $finfo->file($fichierImage['tmp_name']);
        $dimensions = @getimagesize($fichierImage['tmp_name']);
        if (!in_array($typeImage, $typesImageAcceptes, true) || !$dimensions || ($dimensions['mime'] ?? '') !== $typeImage) {
            http_response_code(415);
            echo json_encode(['erreur' => 'Format refusé. Utilisez une image JPG, PNG ou WebP.']);
            exit;
        }

        [$largeurImage, $hauteurImage] = $dimensions;
        if ($largeurImage > 6000 || $hauteurImage > 6000 || $largeurImage * $hauteurImage > 24000000) {
            http_response_code(413);
            echo json_encode(['erreur' => 'Les dimensions de l’image sont trop grandes.']);
            exit;
        }

        $image = @imagecreatefromstring(file_get_contents($fichierImage['tmp_name']));
        if (!$image) {
            http_response_code(415);
            echo json_encode(['erreur' => 'Cette image ne peut pas être lue.']);
            exit;
        }

        $dossierImages = __DIR__ . '/uploads/messages';
        if (!is_dir($dossierImages) && !mkdir($dossierImages, 0750, true) && !is_dir($dossierImages)) {
            imagedestroy($image);
            http_response_code(500);
            echo json_encode(['erreur' => 'Le stockage des images est indisponible.']);
            exit;
        }

        $nomImage = bin2hex(random_bytes(16)) . '.webp';
        $destinationImage = $dossierImages . '/' . $nomImage;
        $imageEnregistree = imagewebp($image, $destinationImage, 82);
        imagedestroy($image);
        if (!$imageEnregistree) {
            http_response_code(500);
            echo json_encode(['erreur' => 'L’image n’a pas pu être convertie.']);
            exit;
        }
        $cheminImage = 'uploads/messages/' . $nomImage;
    }

    if ($aAudio) {
        if (($fichierAudio['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode(['erreur' => 'Le transfert de la note vocale a échoué.']);
            exit;
        }

        $tailleMaxAudio = 10485760;
        if (($fichierAudio['size'] ?? 0) <= 0 || $fichierAudio['size'] > $tailleMaxAudio) {
            http_response_code(413);
            echo json_encode(['erreur' => 'La note vocale doit faire 10 Mo maximum.']);
            exit;
        }

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $typeAudio = $finfo->file($fichierAudio['tmp_name']);
        $typesAudioAcceptes = ['audio/webm', 'video/webm', 'audio/mpeg', 'audio/mp4', 'video/mp4', 'audio/ogg', 'application/ogg', 'audio/x-wav', 'audio/wav'];
        if (!in_array($typeAudio, $typesAudioAcceptes, true)) {
            http_response_code(415);
            echo json_encode(['erreur' => 'Format audio refusé. Utilisez un fichier webm, mp3, m4a, ogg ou wav.']);
            exit;
        }

        $dossierMeda = __DIR__ . '/uploads/messages';
        $extAudio = match ($typeAudio) {
            'audio/webm', 'video/webm' => 'webm',
            'audio/mpeg' => 'mp3',
            'audio/mp4', 'video/mp4' => 'm4a',
            'audio/ogg', 'application/ogg' => 'ogg',
            'audio/wav', 'audio/x-wav' => 'wav',
            default => 'audio'
        };
        $nomAudio = bin2hex(random_bytes(16)) . '.' . $extAudio;
        $destinationAudio = $dossierMeda . '/' . $nomAudio;
        if (!move_uploaded_file($fichierAudio['tmp_name'], $destinationAudio)) {
            http_response_code(500);
            echo json_encode(['erreur' => 'La note vocale n’a pas pu être enregistrée.']);
            exit;
        }
        $cheminAudio = 'uploads/messages/' . $nomAudio;
    }

    if ($contenu === '' && !$cheminImage && !$cheminAudio) {
        http_response_code(400);
        echo json_encode(['erreur' => 'Écrivez un message ou joignez une image ou une note vocale.']);
        exit;
    }

    if ($estClient && !$userModel->getConseillerAssigne($clientId) && (new Parametre())->attributionAutomatiqueActive()) {
        $userModel->assignerConseillerAutomatique($clientId);
    }
    try {
        $messageEnregistre = $messageModel->create($clientId, $expediteurType, $_SESSION['user_id'], $contenu, null, $cheminImage, $cheminAudio);
        if (!$messageEnregistre) throw new RuntimeException('Insertion du message refusée');
    } catch (Throwable $e) {
        if ($cheminImage && isset($destinationImage) && is_file($destinationImage)) unlink($destinationImage);
        if ($cheminAudio && isset($destinationAudio) && is_file($destinationAudio)) unlink($destinationAudio);
        error_log('[messagerie] ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['erreur' => 'Le message n’a pas pu être enregistré.']);
        exit;
    }
    echo json_encode(['ok' => true]);
    exit;
}

$apresId = $_GET['apres_id'] ?? 0;
$messages = $messageModel->getByClient($clientId, $apresId);
$messageModel->marquerLues($clientId, $expediteurType);
echo json_encode($messages);