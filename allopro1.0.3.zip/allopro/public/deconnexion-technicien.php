<?php
session_start();
unset($_SESSION['technicien_id'], $_SESSION['technicien_nom']);
header("Location: index.php");
exit;