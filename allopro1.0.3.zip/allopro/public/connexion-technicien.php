<?php
session_start();
require_once __DIR__ . '/../models/Technicien.php';
require_once __DIR__ . '/../includes/audit.php';

$erreur = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $motDePasse = $_POST['mot_de_passe'];

    $technicienModel = new Technicien();
    $data = $technicienModel->findByEmail($email);

    if ($data && password_verify($motDePasse, $data['mot_de_passe']) && $data['statut'] === 'actif') {
        $_SESSION['technicien_id'] = $data['id'];
        $_SESSION['technicien_nom'] = $data['nom'];
        journaliser('connexion.reussie', 'compte', $data['id'], $data['matricule']);
        header("Location: /allopro/views/technicien/accueil.php");
        exit;
    } else {
        $erreur = "Email ou mot de passe incorrect, ou compte désactivé.";
        journaliser('connexion.echec', 'compte', $data['id'] ?? null, $data['matricule'] ?? null, 'Email saisi : ' . $email);
    }
}

if (isset($_GET['raison']) && !$erreur) {
    $messagesRaison = [
        'suspendu' => "Votre session a été fermée car ce compte a été suspendu.",
        'compte_introuvable' => "Votre session a expiré. Merci de vous reconnecter.",
    ];
    $erreur = $messagesRaison[$_GET['raison']] ?? '';
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion technicien — ALLÔ PRO</title>
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
    <link rel="icon" type="image/png" href="images/icon.png">
    <style>
        .auth-photo--inscription .auth-photo__img {
            background-image:
                linear-gradient(180deg, rgba(18,24,27,0.55) 0%, rgba(18,24,27,0.92) 100%),
                url('https://images.pexels.com/photos/4480531/pexels-photo-4480531.jpeg?auto=compress&cs=tinysrgb&w=1200');
        }
    </style>
</head>
<body>
    <div class="auth-page">
        <div class="auth-photo auth-photo--inscription">
            <div class="auth-photo__img"></div>
            <div class="auth-photo__contenu">
                <a href="index.php" class="auth-photo__logo">ALLÔ<span> PRO</span></a>

                <div class="auth-photo__citation">« Vos missions, vos tâches et vos rappels, où que vous soyez. »</div>

                <div class="auth-photo__badges">
                    <div>
                        <div class="auth-photo__badge-chiffre">Missions</div>
                        <div class="auth-photo__badge-label">Vos interventions</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">Tâches</div>
                        <div class="auth-photo__badge-label">Votre planning</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">Rappels</div>
                        <div class="auth-photo__badge-label">Rien n'est oublié</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="auth-form-panel">
            <form method="POST" class="auth-form">
                <a href="index.php" class="auth-retour">← Retour à l’accueil</a>
                <h2>Espace technicien</h2>
                <p class="auth-form__soustitre">Connectez-vous pour accéder à vos missions</p>

                <?php if ($erreur): ?><div class="erreur"><?= htmlspecialchars($erreur) ?></div><?php endif; ?>

                <div class="champ">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" autocomplete="email" required autofocus>
                </div>
                <div class="champ">
                    <label for="mot_de_passe">Mot de passe</label>
                    <input type="password" id="mot_de_passe" name="mot_de_passe" class="auth-password-field" autocomplete="current-password" required>
                    <label class="auth-password-toggle-label">
                        <input type="checkbox" class="auth-password-toggle">
                        Afficher le mot de passe
                    </label>
                    <p class="auth-password-forgot"><a href="mot-de-passe-oublie.php?type=technicien">Mot de passe oublié ?</a></p>
                </div>

                <button type="submit" class="bouton-principal">Se connecter</button>

                <p class="auth-form__lien">Vous êtes partenaire ? <a href="connexion-partenaire.php">Espace partenaire</a></p>
            </form>
        </div>
    </div>
    <script src="js/auth.js?v=<?= filemtime(__DIR__ . '/js/auth.js') ?>" defer></script>
</body>
</html>