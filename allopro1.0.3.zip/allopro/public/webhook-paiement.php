<?php
require_once __DIR__ . '/../models/Paiement.php';
require_once __DIR__ . '/../models/Demande.php';
require_once __DIR__ . '/../includes/audit.php';

$reference = $_GET['reference'] ?? $_POST['reference'] ?? null;

// --- En production : vérifier ici la signature du webhook envoyée par Wave/Orange Money ---
// pour s'assurer que la requête vient bien d'eux et n'a pas été forgée par n'importe qui.

if ($reference) {
    $paiementModel = new Paiement();
    $paiement = $paiementModel->getByReference($reference);

    if ($paiement) {
        $paiementModel->marquerValide($reference);
        journaliser('paiement.valide', 'paiement', $paiement['id'], $reference, number_format($paiement['montant'], 0, ',', ' ') . ' F (' . $paiement['methode'] . ')', ACTEUR_SYSTEME);
    }
}

if (isset($_GET['depuis_client'])) {
    session_start();
    header("Location: /allopro/views/client/paiement-succes.php?reference=" . urlencode($reference));
    exit;
}

http_response_code(200);
echo "OK";