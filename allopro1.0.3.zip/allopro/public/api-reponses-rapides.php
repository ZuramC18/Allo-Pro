<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('messagerie');
require_once __DIR__ . '/../models/ReponseRapide.php';

header('Content-Type: application/json');
$model = new ReponseRapide();
$action = $_POST['action'] ?? '';

if ($action === 'creer') {
    $model->create(trim($_POST['titre']), trim($_POST['contenu']), trim($_POST['mots_cles']), trim($_POST['categorie']), $_SESSION['role'], $_SESSION['user_id']);
    echo json_encode(['ok' => true]);
} elseif ($action === 'modifier') {
    $model->modifier((int) $_POST['id'], trim($_POST['titre']), trim($_POST['contenu']), trim($_POST['mots_cles']), trim($_POST['categorie']));
    echo json_encode(['ok' => true]);
} elseif ($action === 'supprimer') {
    $model->supprimer((int) $_POST['id']);
    echo json_encode(['ok' => true]);
} else {
    http_response_code(400);
    echo json_encode(['erreur' => 'action inconnue']);
}