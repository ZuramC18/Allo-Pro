<?php
session_start();
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/email-verification.php';

$erreur = '';
if (empty($_SESSION['csrf_inscription_client'])) {
    $_SESSION['csrf_inscription_client'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = is_string($_POST['prenom'] ?? null) ? trim($_POST['prenom']) : '';
    $nom = is_string($_POST['nom'] ?? null) ? trim($_POST['nom']) : '';
    $email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
    $motDePasse = is_string($_POST['mot_de_passe'] ?? null) ? $_POST['mot_de_passe'] : '';
    $telephone = is_string($_POST['telephone'] ?? null) ? trim($_POST['telephone']) : '';

    $user = new User();

    $csrfSoumis = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_inscription_client'], $csrfSoumis)) {
        $erreur = "Le formulaire a expiré. Rechargez la page et réessayez.";
    } elseif ($prenom === '' || $nom === '') {
        $erreur = "Le prénom et le nom sont obligatoires.";
    } elseif (mb_strlen($prenom) > 100 || mb_strlen($nom) > 100) {
        $erreur = "Le prénom et le nom ne doivent pas dépasser 100 caractères.";
    } elseif (mb_strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreur = "Saisissez une adresse email valide.";
    } elseif (strlen($motDePasse) < 8) {
        $erreur = "Le mot de passe doit contenir au moins 8 caractères.";
    } elseif ($user->findByEmail($email)) {
        $erreur = "Cet email est déjà utilisé.";
    } else {
        $id = $user->create($prenom, $nom, $email, $motDePasse, $telephone, 'client', false);
        try {
            $_SESSION['verification_email_notice'] = envoyerCodeVerificationEmail(
                $user,
                $id,
                $email,
                trim($prenom . ' ' . $nom),
                'client'
            ) ? 'envoye' : 'echec';
        } catch (RuntimeException $e) {
            error_log('Échec de l’envoi du mail de vérification client : ' . $e->getMessage());
            $_SESSION['verification_email_notice'] = 'echec';
        }
        $_SESSION['verification_email_type'] = 'client';
        $_SESSION['verification_email_adresse'] = $email;
        header("Location: verification-email.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inscription — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="images/icon.png">
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <style>
        .auth-photo--inscription .auth-photo__img {
            background-image: linear-gradient(180deg, rgba(18,24,27,0.55) 0%, rgba(18,24,27,0.92) 100%), url('https://images.pexels.com/photos/16509869/pexels-photo-16509869.jpeg?auto=compress&w=1200');
        }
    </style>
</head>
<body>
    <div class="auth-page">
        <div class="auth-photo auth-photo--inscription">
            <div class="auth-photo__img"></div>
            <div class="auth-photo__contenu">
                <a href="index.php" class="auth-photo__logo">ALLÔ<span> PRO</span></a>

                <div class="auth-photo__citation">« Rejoignez des milliers de clients qui ne cherchent plus un numéro d'artisan au hasard. »</div>

                <div class="auth-photo__badges">
                    <div>
                        <div class="auth-photo__badge-chiffre">2 min</div>
                        <div class="auth-photo__badge-label">Pour créer un compte</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">24/7</div>
                        <div class="auth-photo__badge-label">Assistance dispo</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">0 FCFA</div>
                        <div class="auth-photo__badge-label">Frais d'inscription</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="auth-form-panel">
            <form method="POST" class="auth-form">
                <a href="index.php" class="auth-retour">← Retour à l’accueil</a>
                <h2>Créer un compte</h2>
                <p class="auth-form__soustitre">Rejoignez ALLÔ PRO en quelques secondes</p>

                <?php if ($erreur): ?><div class="erreur"><?= htmlspecialchars($erreur) ?></div><?php endif; ?>
                <?php if ($erreur === "Cet email est déjà utilisé."): ?>
                    <p class="auth-form__lien"><a href="verification-email.php?type=client&amp;email=<?= rawurlencode($email) ?>">Vous n'avez pas encore vérifié votre adresse ?</a></p>
                <?php endif; ?>

                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_inscription_client'], ENT_QUOTES, 'UTF-8') ?>">
                <div class="champ">
                    <label for="prenom">Prénom</label>
                    <input type="text" id="prenom" name="prenom" value="<?= htmlspecialchars($prenom ?? '', ENT_QUOTES, 'UTF-8') ?>" autocomplete="given-name" maxlength="100" required>
                </div>
                <div class="champ">
                    <label for="nom">Nom</label>
                    <input type="text" id="nom" name="nom" value="<?= htmlspecialchars($nom ?? '', ENT_QUOTES, 'UTF-8') ?>" autocomplete="family-name" maxlength="100" required>
                </div>
                <div class="champ">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>" autocomplete="email" maxlength="150" required>
                </div>
                <div class="champ">
                    <label for="mot_de_passe">Mot de passe</label>
                    <input type="password" id="mot_de_passe" name="mot_de_passe" class="auth-password-field" autocomplete="new-password" minlength="8" required>
                    <label class="auth-password-toggle-label">
                        <input type="checkbox" class="auth-password-toggle">
                        Afficher le mot de passe
                    </label>
                </div>
                <div class="champ">
                    <label>Téléphone</label>
                    <input type="tel" name="telephone" value="<?= htmlspecialchars($telephone ?? '', ENT_QUOTES, 'UTF-8') ?>" autocomplete="tel">
                </div>

                <button type="submit" class="bouton-principal">S'inscrire</button>

                <div style="text-align:center; margin:18px 0; color:#9CA3AF; font-size:13px;">— ou —</div>

                <div id="g_id_onload"
                    data-client_id="<?php require_once __DIR__ . '/../config/google.php'; echo htmlspecialchars(GOOGLE_CLIENT_ID, ENT_QUOTES, 'UTF-8'); ?>"
                    data-login_uri="<?= htmlspecialchars(GOOGLE_LOGIN_URI, ENT_QUOTES, 'UTF-8') ?>"
                    data-auto_select="false">
                </div>
                <div class="g_id_signin" data-type="standard" data-width="380" data-shape="rectangular" data-theme="outline" data-text="signin_with" data-size="large" style="display:flex; justify-content:center;"></div>

                <p class="auth-form__lien">Déjà un compte ? <a href="connexion.php">Se connecter</a></p>
            </form>
        </div>
    </div>
    <script src="js/auth.js?v=<?= filemtime(__DIR__ . '/js/auth.js') ?>" defer></script>
</body>
</html>