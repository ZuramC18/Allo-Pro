<?php
require_once __DIR__ . '/../includes/auth.php';
verifierConnexion();
header("Location: " . pageAccueilPourRole($_SESSION['role']));
exit;