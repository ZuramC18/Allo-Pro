<?php
session_start();
require_once __DIR__ . '/../config/google.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/jwt-google.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/audit.php';
require_once __DIR__ . '/../models/User.php';

// Protection CSRF recommandée par Google pour ce flux : le cookie et le champ POST doivent correspondre
if (!isset($_POST['g_csrf_token'])) {
    die('ERREUR : g_csrf_token absent du POST');
}

if (!isset($_COOKIE['g_csrf_token'])) {
    die('ERREUR : g_csrf_token absent du COOKIE');
}

if ($_POST['g_csrf_token'] !== $_COOKIE['g_csrf_token']) {
    die(
        'ERREUR : tokens différents<br>' .
        'POST : ' . htmlspecialchars($_POST['g_csrf_token']) . '<br>' .
        'COOKIE : ' . htmlspecialchars($_COOKIE['g_csrf_token'])
    );
}

$charge = verifierJetonGoogle($_POST['credential'] ?? '', GOOGLE_CLIENT_ID);
if (!$charge) {
    header("Location: connexion.php?erreur=google_invalide");
    exit;
}

$googleId = $charge['sub'];
$email = $charge['email'];
$prenom = $charge['given_name'] ?? '';
$nom = $charge['family_name'] ?? '';

$userModel = new User();
$compte = $userModel->findByGoogleId($googleId);

if (!$compte) {
    $compte = $userModel->findByEmail($email);
    if ($compte) {
        $userModel->lierGoogleId($compte['id'], $googleId);
    } else {
        $nouvelId = $userModel->create($prenom, $nom, $email, null, null, 'client');
        $userModel->lierGoogleId($nouvelId, $googleId);
        $userModel->marquerMdpADefinir($nouvelId, true); // nouveau compte Google : pas encore de mot de passe
        $compte = $userModel->getById($nouvelId);
        journaliser('compte.cree', 'compte', $nouvelId, $compte['matricule'], nomComplet($prenom, $nom) . ' — via Google');
    }
}

// Google n’accepte le jeton que si l’adresse email a été vérifiée par le fournisseur.
$userModel->marquerEmailVerifie((int) $compte['id']);

if ($compte['statut'] === 'suspendu') {
    journaliser('connexion.refusee', 'compte', $compte['id'], $compte['matricule'], 'Compte suspendu (Google)');
    header("Location: connexion.php?erreur=suspendu");
    exit;
}

$_SESSION['user_id'] = $compte['id'];
$_SESSION['role'] = $compte['role'];
$_SESSION['prenom'] = $compte['prenom'];
$_SESSION['nom_famille'] = $compte['nom'];
$_SESSION['nom'] = nomComplet($compte['prenom'], $compte['nom']);

journaliser('connexion.reussie', 'compte', $compte['id'], $compte['matricule'], 'Via Google');

if ($compte['mdp_a_definir']) {
    header("Location: /allopro/public/definir-mot-de-passe.php");
    exit;
}
header("Location: /allopro/public/dashboard.php");
exit;