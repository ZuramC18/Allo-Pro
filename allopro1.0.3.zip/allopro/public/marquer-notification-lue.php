<?php
require_once __DIR__ . '/../includes/auth.php';
verifierConnexion();
require_once __DIR__ . '/../models/Notification.php';

$id = $_GET['id'] ?? null;
$redirection = $_GET['redirection'] ?? 'index.php';

if ($id) {
    (new Notification())->marquerLue($id);
}
header("Location: " . $redirection);
exit;