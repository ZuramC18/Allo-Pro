<?php
session_start();
unset($_SESSION['partenaire_id'], $_SESSION['partenaire_nom']);
header("Location: index.php");
exit;