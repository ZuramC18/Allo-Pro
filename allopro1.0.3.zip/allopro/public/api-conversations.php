<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('messagerie');
require_once __DIR__ . '/../models/Message.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$messageModel = new Message();

$estCoordinateurOuAdmin = in_array($_SESSION['role'], ['coordinateur', 'admin'], true);

$conversations = $estCoordinateurOuAdmin
    ? $messageModel->getConversationsToutes()
    : $messageModel->getConversationsPourConseiller((int) $_SESSION['user_id']);

echo json_encode($conversations, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);