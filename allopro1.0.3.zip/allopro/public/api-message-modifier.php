<?php
header('Content-Type: application/json; charset=utf-8');
http_response_code(410);
echo json_encode(['erreur' => 'La modification des messages est désactivée.']);