<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('messagerie');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

if (($_SESSION['role'] ?? '') !== 'conseiller') {
    http_response_code(403);
    echo json_encode(['erreur' => 'Accès réservé aux conseillers.']);
    exit;
}

require_once __DIR__ . '/../models/User.php';
$userModel = new User();
$userId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $presence = $userModel->getPresenceConseiller($userId);
    if (!$presence) {
        http_response_code(403);
        echo json_encode(['erreur' => 'Compte conseiller inactif ou introuvable.']);
        exit;
    }
    echo json_encode($presence);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: GET, POST');
    http_response_code(405);
    echo json_encode(['erreur' => 'Méthode non autorisée.']);
    exit;
}

$csrfSession = (string) ($_SESSION['csrf'] ?? '');
$csrfRecu = (string) ($_POST['csrf'] ?? '');
if ($csrfSession === '' || !hash_equals($csrfSession, $csrfRecu)) {
    http_response_code(403);
    echo json_encode(['erreur' => 'Jeton de sécurité invalide.']);
    exit;
}

$action = $_POST['action'] ?? '';
if ($action === 'heartbeat') {
    $presence = $userModel->actualiserPresenceConseiller($userId);
} elseif ($action === 'status') {
    $statut = $_POST['status'] ?? '';
    if (!in_array($statut, ['online', 'pause', 'offline'], true)) {
        http_response_code(422);
        echo json_encode(['erreur' => 'Statut de présence invalide.']);
        exit;
    }
    $userModel->definirPresenceConseiller($userId, $statut);
    $presence = $userModel->getPresenceConseiller($userId);
} else {
    http_response_code(400);
    echo json_encode(['erreur' => 'Action de présence inconnue.']);
    exit;
}

if (!$presence) {
    http_response_code(403);
    echo json_encode(['erreur' => 'Compte conseiller inactif ou introuvable.']);
    exit;
}

echo json_encode($presence);
