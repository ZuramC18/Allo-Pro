<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('demandes');
require_once __DIR__ . '/../models/Technicien.php';

header('Content-Type: application/json');

$partenaireId = $_GET['partenaire_id'] ?? null;
$categorieId = $_GET['categorie_id'] ?? null;

if (!$partenaireId) {
    echo json_encode([]);
    exit;
}

$technicienModel = new Technicien();
$techniciens = $technicienModel->getActifsByPartenaire($partenaireId, $categorieId);
echo json_encode($techniciens);