<?php
session_start();
require_once __DIR__ . '/../models/Partenaire.php';
require_once __DIR__ . '/../includes/audit.php';

$erreur = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $motDePasse = $_POST['mot_de_passe'];

    $partenaire = new Partenaire();
    $data = $partenaire->findByEmail($email);

if ($data && password_verify($motDePasse, $data['mot_de_passe'])) {
        if (empty($data['email_verifie'])) {
            $erreur = "Vérifiez votre adresse email avant de vous connecter.";
            $emailVerification = true;
        } elseif ($data['statut'] === 'actif') {
            $_SESSION['partenaire_id'] = $data['id'];
            $_SESSION['partenaire_nom'] = $data['nom_entreprise'];
            journaliser('connexion.reussie', 'compte', $data['id'], $data['matricule']);
            header("Location: /allopro/views/partenaire/accueil.php");
            exit;
        } else {
            $erreur = "Email ou mot de passe incorrect, ou compte désactivé.";
            journaliser('connexion.echec', 'compte', $data['id'], $data['matricule'], 'Compte partenaire non actif');
        }
    } else {
        $erreur = "Email ou mot de passe incorrect, ou compte désactivé.";
        journaliser('connexion.echec', 'compte', $data['id'] ?? null, $data['matricule'] ?? null, 'Email saisi : ' . $email);
    }
}

if (isset($_GET['raison']) && !$erreur) {
    $messagesRaison = [
        'suspendu' => "Votre session a été fermée car ce compte a été suspendu.",
        'compte_introuvable' => "Votre session a expiré. Merci de vous reconnecter.",
    ];
    $erreur = $messagesRaison[$_GET['raison']] ?? '';
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion partenaire — ALLÔ PRO</title>
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
    <link rel="icon" type="image/png" href="images/icon.png">
    <style>
        .auth-photo--inscription .auth-photo__img {
            background-image:
                linear-gradient(180deg, rgba(18,24,27,0.55) 0%, rgba(18,24,27,0.92) 100%),
                url('https://images.pexels.com/photos/33694014/pexels-photo-33694014.jpeg?auto=compress&cs=tinysrgb&w=1200');
        }
    </style>
</head>
<body>
    <div class="auth-page">
        <div class="auth-photo auth-photo--inscription">
            <div class="auth-photo__img"></div>
            <div class="auth-photo__contenu">
                <a href="index.php" class="auth-photo__logo">ALLÔ<span> PRO</span></a>

                <div class="auth-photo__citation">« Gérez vos équipes et vos missions depuis un seul espace. »</div>

                <div class="auth-photo__badges">
                    <div>
                        <div class="auth-photo__badge-chiffre">Équipe</div>
                        <div class="auth-photo__badge-label">Vos techniciens</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">Missions</div>
                        <div class="auth-photo__badge-label">Suivi en direct</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">Paiements</div>
                        <div class="auth-photo__badge-label">Vos reversements</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="auth-form-panel">
            <form method="POST" class="auth-form">
                <a href="index.php" class="auth-retour">← Retour à l’accueil</a>
                <h2>Espace partenaire</h2>
                <p class="auth-form__soustitre">Connectez-vous pour gérer vos missions et vos équipes</p>

                <?php if ($erreur): ?><div class="erreur"><?= htmlspecialchars($erreur) ?></div><?php endif; ?>
                <?php if (!empty($emailVerification)): ?>
                    <p class="auth-form__lien"><a href="verification-email.php?type=partenaire&amp;email=<?= rawurlencode($email) ?>">Recevoir un code de vérification</a></p>
                <?php endif; ?>

                <div class="champ">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" autocomplete="email" required autofocus>
                </div>
                <div class="champ">
                    <label for="mot_de_passe">Mot de passe</label>
                    <input type="password" id="mot_de_passe" name="mot_de_passe" class="auth-password-field" autocomplete="current-password" required>
                    <label class="auth-password-toggle-label">
                        <input type="checkbox" class="auth-password-toggle">
                        Afficher le mot de passe
                    </label>
                    <p class="auth-password-forgot"><a href="mot-de-passe-oublie.php?type=partenaire">Mot de passe oublié ?</a></p>
                </div>

                <button type="submit" class="bouton-principal">Se connecter</button>

                <p class="auth-form__lien">Pas encore partenaire ? <a href="inscription-partenaire.php">S'inscrire</a></p>
                <p class="auth-form__lien">Vous êtes technicien ? <a href="connexion-technicien.php">Connexion Technicien</a></p>
            </form>
        </div>
    </div>
    <script src="js/auth.js?v=<?= filemtime(__DIR__ . '/js/auth.js') ?>" defer></script>
</body>
</html>