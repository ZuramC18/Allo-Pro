<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../models/Message.php';

header('Content-Type: application/json');
$nbNonLus = (new Message())->compterNonLus($_SESSION['user_id'], 'client');
echo json_encode(['count' => $nbNonLus]);