<?php
session_start();

require_once __DIR__ . '/../models/Abonnement.php';
$abonnementModel = new Abonnement();
$formulesAccueil = $abonnementModel->getFormulesActives();


$derniereDemande = null;
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'client') {
    require_once __DIR__ . '/../models/Demande.php';
    $demandeModel = new Demande();
    $mesDemandes = $demandeModel->getByClient($_SESSION['user_id']);
    $derniereDemande = $mesDemandes[0] ?? null;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Services du quotidien à Dakar | ALLÔ PRO</title>
    <link rel="stylesheet" href="css/index.css?v=<?= filemtime(__DIR__ . '/css/index.css') ?>">
    <link rel="icon" type="image/png" href="images/icon.png">
</head>
<body>

    <nav class="nav" id="nav">
        <a href="index.php" class="nav__logo">ALLÔ<span> PRO</span></a>
        <button type="button" class="nav__menu-toggle" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="nav-liens">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <div class="nav__liens" id="nav-liens">
            <a href="#comment-ca-marche">Comment ça marche</a>
            <a href="#services">Services</a>
            <a href="#garanties">Notre approche</a>
            <a href="#abonnement">Abonnement</a>
            <a href="#questions">FAQ</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="dashboard.php" class="nav__bouton">Mon espace</a>
            <?php else: ?>
                <a href="connexion.php">Connexion</a>
                <a href="inscription.php" class="nav__bouton">S'inscrire</a>
            <?php endif; ?>
        </div>
    </nav>

    <section class="hero">
        <div class="hero__bg"></div>
        <div class="hero__contenu">
            <div class="hero__badge">Services du quotidien à Dakar</div>
            <h1>Un problème.<br>Un seul <span>numéro</span>.</h1>
            <p>Plomberie, électricité, climatisation, informatique et petits travaux : décrivez votre besoin, ALLÔ PRO organise la mise en relation et vous permet de suivre votre demande.</p>

            <div class="hero__actions">
                <a href="<?= isset($_SESSION['user_id']) ? (($_SESSION['role'] ?? '') === 'client' ? '../views/client/nouvelle-demande.php' : 'dashboard.php') : 'inscription.php' ?>" class="btn-primaire">
                    <?= $derniereDemande ? 'Nouvelle intervention' : 'Demander une intervention' ?>
                </a>
                <a href="#comment-ca-marche" class="btn-secondaire">Comment ça marche</a>
            </div>

            <div class="hero__stats">
                <div>
                    <div class="stat__chiffre">Décrivez</div>
                    <div class="stat__label">votre besoin</div>
                </div>
                <div>
                    <div class="stat__chiffre">Suivez</div>
                    <div class="stat__label">votre demande</div>
                </div>
                <div>
                    <div class="stat__chiffre">Choisissez</div>
                    <div class="stat__label">votre mode de paiement</div>
                </div>
            </div>
        </div>
    </section>

    <section class="etapes-section" id="comment-ca-marche">
        <div class="conteneur">
            <span class="section-tag reveal">Le processus</span>
            <h2 class="section-titre reveal">De la demande au suivi de l’intervention</h2>

            <div class="etapes-grille">
                <div class="etape-carte reveal">
                    <span class="etape-carte__num">01</span>
                    <h3>Décrivez le problème</h3>
                    <p>Indiquez la catégorie, décrivez le besoin, précisez l’urgence et l’adresse. La photo est facultative.</p>
                </div>
                <div class="etape-carte reveal reveal-delay-1">
                    <span class="etape-carte__num">02</span>
                    <h3>Un conseiller prend le relais</h3>
                    <p>Votre demande est examinée et son traitement est organisé selon les informations fournies.</p>
                </div>
                <div class="etape-carte reveal reveal-delay-2">
                    <span class="etape-carte__num">03</span>
                    <h3>Gardez le fil</h3>
                    <p>Consultez l’évolution de la demande et échangez avec l’équipe depuis votre espace client.</p>
                </div>
                <div class="etape-carte reveal reveal-delay-3">
                    <span class="etape-carte__num">04</span>
                    <h3>Choisissez le paiement</h3>
                    <p>Réglez après l’intervention avec Wave ou Orange Money, ou utilisez un Pass ou un crédit applicable.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="services-section" id="services">
        <div class="conteneur">
            <div class="services-entete">
                <div>
                    <span class="section-tag reveal">Nos catégories</span>
                    <h2 class="section-titre reveal">Les catégories pour lesquelles déposer une demande</h2>
                </div>
            </div>

            <div class="services-grille">
                <div class="service-photo reveal">
                    <img src="https://images.pexels.com/photos/5767595/pexels-photo-5767595.jpeg?auto=compress&w=900&dpr=1" alt="Électricité">
                    <div class="service-photo__overlay">
                        <div class="service-photo__tag">Habitat</div>
                        <div class="service-photo__titre">Électricité</div>
                        <div class="service-photo__liste">Installation, panne, mise aux normes</div>
                    </div>
                </div>
                <div class="service-photo service-photo--petit reveal reveal-delay-1">
                    <img src="https://images.pexels.com/photos/16509869/pexels-photo-16509869/free-photo-of-close-up-of-man-using-a-spanner.jpeg?auto=compress&w=900&dpr=1" alt="Plomberie">
                    <div class="service-photo__overlay">
                        <div class="service-photo__tag">Habitat</div>
                        <div class="service-photo__titre">Plomberie</div>
                    </div>
                </div>
                <div class="service-photo service-photo--petit reveal reveal-delay-2">
                    <img src="https://images.pexels.com/photos/2136243/pexels-photo-2136243.jpeg?auto=compress&w=900&dpr=1" alt="Digital">
                    <div class="service-photo__overlay">
                        <div class="service-photo__tag">Digital</div>
                        <div class="service-photo__titre">Informatique</div>
                    </div>
                </div>
                <div class="service-photo service-photo--petit reveal reveal-delay-1">
                    <img src="https://images.pexels.com/photos/12741843/pexels-photo-12741843.jpeg?auto=compress&w=900&dpr=1" alt="Froid">
                    <div class="service-photo__overlay">
                        <div class="service-photo__tag">Froid</div>
                        <div class="service-photo__titre">Climatisation</div>
                    </div>
                </div>
                <div class="service-photo service-photo--petit reveal reveal-delay-2">
                    <img src="https://images.pexels.com/photos/6419128/pexels-photo-6419128.jpeg?auto=compress&w=900&dpr=1" alt="Petits travaux">
                    <div class="service-photo__overlay">
                        <div class="service-photo__tag">Habitat</div>
                        <div class="service-photo__titre">Petits travaux</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="confiance-section" id="garanties">
        <div class="conteneur">
            <span class="section-tag reveal">Pourquoi ALLÔ PRO</span>
            <h2 class="section-titre reveal">Un parcours clair, de la demande au suivi</h2>

            <div class="confiance-grille">
                <article class="confiance-carte reveal">
                    <span class="confiance-carte__repere">01 / DEMANDE</span>
                    <h3>Donnez les bonnes informations</h3>
                    <p>Choisissez une catégorie, décrivez le problème, indiquez l’urgence et l’adresse. Vous pouvez ajouter une photo pour préciser le besoin.</p>
                </article>
                <article class="confiance-carte reveal reveal-delay-1">
                    <span class="confiance-carte__repere">02 / ACCOMPAGNEMENT</span>
                    <h3>Échangez avec l’équipe</h3>
                    <p>Un conseiller prend en charge la demande et vous accompagne dans son traitement depuis votre espace client.</p>
                </article>
                <article class="confiance-carte reveal reveal-delay-2">
                    <span class="confiance-carte__repere">03 / SUIVI</span>
                    <h3>Retrouvez les étapes au même endroit</h3>
                    <p>Consultez l’évolution de votre demande, échangez par messagerie et retrouvez les informations de l’intervention.</p>
                </article>
            </div>
        </div>
    </section>

    <section class="pricing-section" id="abonnement">
        <div class="conteneur">
            <div class="pricing-entete">
                <span class="section-tag reveal">Pour les besoins réguliers</span>
                <h2 class="section-titre reveal">Des formules selon votre rythme</h2>
                <p class="reveal">Comparez le tarif, le nombre de crédits et les catégories couvertes par chaque formule.</p>
            </div>

            <div class="pricing-grille">
                <?php foreach ($formulesAccueil as $i => $f):
                    $catsEligibles = $abonnementModel->getCategoriesEligibles($f['id']);

                    $lienFormule = 'connexion.php';
                    $texteLien = 'Se connecter';
                    if (isset($_SESSION['user_id'])) {
                        if ($_SESSION['role'] === 'admin') { $lienFormule = '../views/admin/abonnements.php'; $texteLien = 'Gérer'; }
                        else { $lienFormule = '../views/client/abonnement.php'; $texteLien = 'Souscrire'; }
                    }
                ?>
                    <article class="pricing-carte reveal <?= $i % 2 ? 'reveal-delay-1' : '' ?>">
                        <h3 class="pricing-carte__nom"><?= htmlspecialchars($f['nom'], ENT_QUOTES, 'UTF-8') ?></h3>
                        <div class="pricing-carte__prix">
                            <?= number_format((float) $f['prix'], 0, ',', ' ') ?>
                            <span class="pricing-carte__devise">FCFA</span>
                            <span class="pricing-carte__periode">/mois</span>
                        </div>
                        <p class="pricing-carte__desc"><?= htmlspecialchars($f['description'], ENT_QUOTES, 'UTF-8') ?></p>

                        <ul class="pricing-carte__liste">
                            <li><span class="pricing-check" aria-hidden="true">✓</span> <?= (int) $f['nombre_credits'] ?> crédit<?= (int) $f['nombre_credits'] > 1 ? 's' : '' ?> d’intervention</li>
                            <li><span class="pricing-check">✓</span>
                                <?php if (empty($catsEligibles)): ?>
                                    Toutes catégories de service
                                <?php else: ?>
                                    <?= implode(', ', array_map(fn($c) => htmlspecialchars($c['nom']), $catsEligibles)) ?>
                                <?php endif; ?>
                            </li>
                            <li><span class="pricing-check" aria-hidden="true">✓</span> Paiement par Wave ou Orange Money</li>
                        </ul>

                        <a href="<?= $lienFormule ?>" class="pricing-carte__bouton"><?= $texteLien ?></a>
                    </article>
                <?php endforeach; ?>
            </div>

            <?php if (empty($formulesAccueil)): ?>
                <div class="pricing-vide">
                    <p>Aucune formule d’abonnement n’est disponible pour le moment.</p>
                    <a href="<?= isset($_SESSION['user_id']) ? (($_SESSION['role'] ?? '') === 'client' ? '../views/client/nouvelle-demande.php' : 'dashboard.php') : 'inscription.php' ?>">Vous pouvez tout de même demander une intervention à l’unité.</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="questions-section" id="questions">
        <div class="conteneur">
            <div class="questions-entete">
                <span class="section-tag reveal">À savoir</span>
                <h2 class="section-titre reveal">Questions fréquentes</h2>
                <p class="reveal">Les informations utiles avant de créer votre demande.</p>
            </div>

            <div class="questions-liste reveal">
                <details>
                    <summary>Comment demander une intervention ?</summary>
                    <p>Créez votre compte, puis indiquez la catégorie, la description du problème, son niveau d’urgence et l’adresse. Vous pouvez joindre une photo, mais ce n’est pas obligatoire.</p>
                </details>
                <details>
                    <summary>Dois-je prendre un abonnement ?</summary>
                    <p>Non. Vous pouvez demander une intervention et choisir le paiement après l’intervention. Les abonnements et les Pass sont des options pour celles et ceux qui souhaitent utiliser des crédits prépayés.</p>
                </details>
                <details>
                    <summary>Quelle est la différence entre un Pass et un abonnement ?</summary>
                    <p>Un Pass couvre une intervention selon la catégorie indiquée sur l’offre. Un abonnement propose plusieurs crédits et peut être limité à certaines catégories. Vérifiez les détails affichés avant de choisir.</p>
                </details>
                <details>
                    <summary>Comment régler une intervention ?</summary>
                    <p>Pour un paiement après l’intervention, Wave et Orange Money sont proposés. Si votre abonnement ou votre Pass couvre la catégorie choisie, vous pouvez aussi sélectionner ce mode de prise en charge.</p>
                </details>
                <details>
                    <summary>Où suivre ma demande ?</summary>
                    <p>Connectez-vous à votre espace client pour consulter son statut, retrouver les détails et échanger avec l’équipe par messagerie.</p>
                </details>
            </div>
        </div>
    </section>

    <section class="cta-finale">
        <div class="conteneur">
            <h2>Un besoin à signaler ?</h2>
            <p>Créez une demande et retrouvez son suivi dans votre espace client.</p>
            <a href="<?= isset($_SESSION['user_id']) ? 'dashboard.php' : 'inscription.php' ?>" class="btn-blanc">
                <?= isset($_SESSION['user_id']) ? 'Accéder à mon espace' : 'Créer mon compte' ?>
            </a>
        </div>
    </section>

    <footer class="footer">
        <div class="footer__grille">
            <div class="footer__colonne">
                <div class="footer__colonne-titre">ALLÔ PRO</div>
                <p>Un point d’entrée pour organiser vos interventions à Dakar et suivre vos demandes depuis votre espace client.</p>
                
            </div>

            <div class="footer__colonne">
                <div class="footer__colonne-titre">Services</div>
                <ul class="footer__liens">
                    <li><a href="#services">Voir les catégories</a></li>
                    <li><a href="#comment-ca-marche">Comment ça marche</a></li>
                    <li><a href="#abonnement">Formules d’abonnement</a></li>
                    <li><a href="#questions">Questions fréquentes</a></li>
                </ul>
            </div>
            <div class="footer__colonne">
                <div class="footer__colonne-titre">Nous contacter</div>
                <ul class="footer__liens">
                    <li><a href="mailto:contact@allopro.sn">Écrire au support</a></li>
                    <li><a href="inscription-partenaire.php">Devenir partenaire</a></li>
                    <li>Dakar, Sénégal</li>
                </ul>
            </div>
            <div class="footer__colonne">
                <div class="footer__colonne-titre">Accès rapide</div>
                <ul class="footer__liens">
                    <li><a href="#garanties">Notre approche</a></li>
                    <li><a href="<?= isset($_SESSION['user_id']) ? 'dashboard.php' : 'connexion.php' ?>">Espace client</a></li>
                </ul>
            </div>
        </div>

        <div class="footer__bas">
            <span>© <?= date('Y') ?> ALLÔ PRO. Tous droits réservés.</span>
        </div>
    </footer>

    <script>
    try {
        // Filet de sécurité : si quoi que ce soit plante, le contenu redevient visible après 2 secondes
        setTimeout(() => document.documentElement.classList.add('js-echec'), 2000);

        const nav = document.getElementById('nav');
        window.addEventListener('scroll', () => {
            nav.classList.toggle('nav--scrolled', window.scrollY > 40);
        });

        const boutonMenu = document.querySelector('.nav__menu-toggle');
        const liensMenu = document.getElementById('nav-liens');
        if (boutonMenu && liensMenu) {
            const fermerMenu = () => {
                nav.classList.remove('nav--menu-ouvert');
                boutonMenu.setAttribute('aria-expanded', 'false');
                boutonMenu.setAttribute('aria-label', 'Ouvrir le menu');
            };

            boutonMenu.addEventListener('click', () => {
                const ouvert = boutonMenu.getAttribute('aria-expanded') !== 'true';
                nav.classList.toggle('nav--menu-ouvert', ouvert);
                boutonMenu.setAttribute('aria-expanded', String(ouvert));
                boutonMenu.setAttribute('aria-label', ouvert ? 'Fermer le menu' : 'Ouvrir le menu');
            });

            liensMenu.querySelectorAll('a').forEach(lien => lien.addEventListener('click', fermerMenu));
            document.addEventListener('click', event => {
                if (
                    boutonMenu.getAttribute('aria-expanded') === 'true'
                    && !nav.contains(event.target)
                ) {
                    fermerMenu();
                }
            });
            document.addEventListener('keydown', event => {
                if (event.key === 'Escape') {
                    fermerMenu();
                    boutonMenu.focus();
                }
            });
        }

        const elementsReveal = document.querySelectorAll('.reveal');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) entry.target.classList.add('visible');
            });
        }, { threshold: 0.15 });
        elementsReveal.forEach(el => observer.observe(el));

    } catch (e) {
        console.error('Erreur script index.php :', e);
        document.documentElement.classList.add('js-echec');
    }
    </script>
</body>
</html>