<?php
session_start();
require_once __DIR__ . '/audit.php';
require_once __DIR__ . '/../config/database.php';

function verifierTechnicienConnecte() {
    if (!isset($_SESSION['technicien_id'])) {
        header("Location: /allopro/public/connexion-technicien.php");
        exit;
    }

    $stmt = (new Database())->getConnection()->prepare("SELECT nom, statut, photo_profil, avatar_initiales FROM techniciens WHERE id = :id");
    $stmt->execute([':id' => $_SESSION['technicien_id']]);
    $t = $stmt->fetch();

    if (!$t || $t['statut'] !== 'actif') {
        journaliser('session.coupee', 'compte', $_SESSION['technicien_id'], $_SESSION['technicien_nom'] ?? null, 'Technicien désactivé pendant une session active');
        unset($_SESSION['technicien_id'], $_SESSION['technicien_nom']);
        header("Location: /allopro/public/connexion-technicien.php?raison=suspendu");
        exit;
    }
    $_SESSION['technicien_nom'] = $t['nom'];
    $_SESSION['technicien_photo_profil'] = $t['photo_profil'];
    $_SESSION['technicien_avatar_initiales'] = (bool) $t['avatar_initiales'];
}