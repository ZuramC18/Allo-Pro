<?php
require_once __DIR__ . '/SmtpMailer.php';

function envoyerLienReinitialisation($modele, array $compte, string $type): bool {
    if (!in_array($type, ['client', 'partenaire', 'technicien'], true)) {
        throw new InvalidArgumentException('Type de compte invalide.');
    }

    $configuration = require __DIR__ . '/../config/mail.php';
    $urlBase = filter_var($configuration['base_url'], FILTER_VALIDATE_URL);
    $partiesUrl = $urlBase ? parse_url($urlBase) : false;
    if (!$partiesUrl || !in_array($partiesUrl['scheme'] ?? '', ['http', 'https'], true)
        || empty($partiesUrl['host']) || isset($partiesUrl['user']) || isset($partiesUrl['pass'])
        || isset($partiesUrl['query']) || isset($partiesUrl['fragment'])) {
        throw new RuntimeException('ALLOPRO_BASE_URL doit être une URL HTTP(S) valide.');
    }
    if ($partiesUrl['scheme'] !== 'https'
        && !in_array(strtolower($partiesUrl['host']), ['localhost', '127.0.0.1', '::1'], true)) {
        throw new RuntimeException('ALLOPRO_BASE_URL doit utiliser HTTPS en dehors de l’environnement local.');
    }

    $jeton = bin2hex(random_bytes(32));
    $expiration = gmdate('Y-m-d H:i:s', time() + 3600);
    if (!$modele->creerJetonReinitialisation((int) $compte['id'], hash('sha256', $jeton), $expiration)) {
        return false;
    }

    $lien = rtrim($configuration['base_url'], '/') . '/mot-de-passe-oublie.php?type='
        . rawurlencode($type) . '&token=' . rawurlencode($jeton);
    $nom = $type === 'partenaire'
        ? (string) ($compte['nom_entreprise'] ?? '')
        : (string) ($compte['nom'] ?? '');
    $nomSecurise = htmlspecialchars($nom, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $lienSecurise = htmlspecialchars($lien, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $html = '<!doctype html><html lang="fr"><meta charset="UTF-8"><body style="margin:0;padding:32px;background:#f7f5f1;font-family:Arial,sans-serif;color:#1c1c1c">'
        . '<div style="max-width:560px;margin:auto;padding:32px;background:#fff;border-radius:16px">'
        . '<h1 style="color:#123c4d">Réinitialisez votre mot de passe</h1>'
        . '<p>Bonjour ' . $nomSecurise . ',</p>'
        . '<p>Une demande de réinitialisation du mot de passe de votre compte ALLÔ PRO a été effectuée.</p>'
        . '<p style="margin:28px 0"><a href="' . $lienSecurise . '" style="padding:14px 22px;background:#e8a33d;color:#123c4d;border-radius:8px;text-decoration:none;font-weight:bold">Choisir un nouveau mot de passe</a></p>'
        . '<p>Ce lien expire dans une heure et ne peut être utilisé qu’une seule fois.</p>'
        . '<p style="font-size:12px;color:#6b7280">Si vous n’êtes pas à l’origine de cette demande, ignorez cet email. Votre mot de passe actuel restera inchangé.</p>'
        . '</div></body></html>';
    $texte = "Bonjour {$nom},\n\nUne demande de réinitialisation du mot de passe de votre compte ALLÔ PRO a été effectuée.\nChoisissez un nouveau mot de passe avec ce lien :\n{$lien}\n\nCe lien expire dans une heure et ne peut être utilisé qu’une seule fois.\nSi vous n’êtes pas à l’origine de cette demande, ignorez cet email. Votre mot de passe actuel restera inchangé.";

    try {
        (new SmtpMailer($configuration))->envoyer(
            (string) $compte['email'],
            $nom,
            'Réinitialisation de votre mot de passe — ALLÔ PRO',
            $texte,
            $html
        );
    } catch (Throwable $e) {
        $modele->annulerJetonReinitialisation((int) $compte['id'], hash('sha256', $jeton));
        throw $e;
    }
    return true;
}
