<?php
require_once __DIR__ . '/../models/Tache.php';
$rappels = (new Tache())->getRappels($_SESSION['technicien_id']);
?>
<?php if (!empty($rappels)): ?>
    <?php foreach ($rappels as $r): ?>
        <?php $enRetard = strtotime($r['date_echeance']) < time(); ?>
        <div style="background:<?= $enRetard ? '#FDECEC' : '#FEF3C7' ?>; color:<?= $enRetard ? '#B91C1C' : '#92400E' ?>; border-radius:8px; padding:14px 18px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">
            <span><strong><?= $enRetard ? '⏰ En retard : ' : '🔔 Aujourd\'hui : ' ?></strong><?= htmlspecialchars($r['titre']) ?> — <?= date('d/m à H:i', strtotime($r['date_echeance'])) ?></span>
            <a href="taches.php" style="color:inherit; font-weight:600; font-size:13px; text-decoration:underline;">Voir mes tâches</a>
        </div>
    <?php endforeach; ?>
<?php endif; ?>