<?php
$pagePartenaire = basename($_SERVER['PHP_SELF']);
require_once __DIR__ . '/icones.php';
require_once __DIR__ . '/AvatarProfil.php';
$photoPartenaireSidebar = AvatarProfil::estValide($_SESSION['partenaire_photo_profil'] ?? null, 'partenaires')
    ? (string) $_SESSION['partenaire_photo_profil']
    : null;
$initialesPartenaireSidebar = AvatarProfil::initiales((string) ($_SESSION['partenaire_nom'] ?? 'Partenaire'));
?>
<script>
(function () {
    try {
        var theme = localStorage.getItem('allopro_theme');
        if (theme !== 'dark' && theme !== 'light') {
            theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        document.documentElement.setAttribute('data-theme', theme);
        if (!window.matchMedia('(max-width: 1024px)').matches && localStorage.getItem('allopro_sidebar') === 'closed') {
            document.documentElement.classList.add('partenaire-sidebar-fermee');
        }
    } catch (e) {
        document.documentElement.setAttribute('data-theme', 'light');
    }
})()
</script>
<link rel="stylesheet" href="../../public/css/dark.css?v=<?= filemtime(__DIR__ . '/../public/css/dark.css') ?>">
<link rel="stylesheet" href="../../public/css/partenaire-sidebar.css?v=<?= filemtime(__DIR__ . '/../public/css/partenaire-sidebar.css') ?>">

<button type="button" class="sidebar__mobile-toggle" id="partenaire-menu-toggle" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="sidebar-partenaire">
    <svg class="sidebar__mobile-ouvrir" width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
    <svg class="sidebar__mobile-fermer" width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>
</button>
<a class="sidebar__mobile-site" href="accueil.php" aria-label="ALLÔ PRO — Accueil partenaire">
    <span>ALLÔ</span> <strong>PRO</strong>
</a>

<aside class="sidebar partenaire-sidebar" id="sidebar-partenaire">
    <div class="partenaire-sidebar__entete">
        <a href="../../public/index.php" class="sidebar__logo">
            <span class="sidebar__logo-marque">A</span>
            <span class="sidebar__logo-texte">ALLÔ <strong>PRO</strong></span>
        </a>
        <button type="button" class="partenaire-sidebar__theme" id="partenaire-theme-toggle" aria-pressed="false" aria-label="Passer en mode sombre" title="Passer en mode sombre">
            <svg class="icone-lune" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
            <svg class="icone-soleil" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
        </button>
        <button type="button" class="partenaire-sidebar__masquer" id="partenaire-sidebar-masquer" aria-label="Masquer le menu" title="Masquer le menu">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m11 17-5-5 5-5"/><path d="m18 17-5-5 5-5"/></svg>
        </button>
    </div>

    <div class="partenaire-sidebar__identite">
        <span class="partenaire-sidebar__identite-icone">
            <?php if (empty($_SESSION['partenaire_avatar_initiales']) && $photoPartenaireSidebar !== null): ?>
                <img src="../../public/<?= htmlspecialchars($photoPartenaireSidebar, ENT_QUOTES, 'UTF-8') ?>" alt="">
            <?php elseif (!empty($_SESSION['partenaire_avatar_initiales'])): ?>
                <?= htmlspecialchars($initialesPartenaireSidebar, ENT_QUOTES, 'UTF-8') ?>
            <?php else: ?>
                <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
            <?php endif; ?>
        </span>
        <span class="partenaire-sidebar__texte"><?= htmlspecialchars($_SESSION['partenaire_nom'] ?? 'Espace partenaire', ENT_QUOTES, 'UTF-8') ?></span>
    </div>

    <div class="partenaire-sidebar__section">Espace partenaire</div>
    <nav class="sidebar__nav" aria-label="Navigation principale">
        <?php
        $liensPartenaire = [
            ['accueil.php', 'dashboard', 'Accueil'],
            ['missions.php', 'receipt', 'Mes missions'],
            ['taches.php', 'clipboard', 'Mes tâches'],
            ['techniciens.php', 'wrench', 'Mes techniciens'],
            ['profil.php', 'building', 'Mon profil'],
            ['messagerie.php', 'messages', 'Messagerie interne'],
        ];
        foreach ($liensPartenaire as [$href, $icone, $libelle]):
            $actif = $pagePartenaire === $href;
        ?>
            <a href="<?= htmlspecialchars($href, ENT_QUOTES, 'UTF-8') ?>"
               class="sidebar__lien <?= $actif ? 'sidebar__lien--actif' : '' ?>"
               title="<?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?>"
               <?= $actif ? 'aria-current="page"' : '' ?>
               <?= $href === 'messagerie.php' ? 'data-mi-notification' : '' ?>>
                <span class="sidebar__icone"><?= icone($icone, 19) ?></span>
                <span class="sidebar__texte"><?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?></span>
                <?php if ($href === 'messagerie.php'): ?><span class="mi-sidebar-badge" data-mi-badge hidden></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="partenaire-sidebar__bas">
        <a href="../../public/deconnexion-partenaire.php" class="sidebar__lien sidebar__lien--sortie" title="Déconnexion">
            <span class="sidebar__icone"><?= icone('logout', 19) ?></span>
            <span class="sidebar__texte">Déconnexion</span>
        </a>
    </div>
</aside>
<button type="button" class="partenaire-sidebar__reouvrir" id="partenaire-sidebar-reouvrir" aria-label="Afficher le menu" title="Afficher le menu">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m13 17 5-5-5-5"/><path d="m6 17 5-5-5-5"/></svg>
</button>
<header class="partenaire-topbar">
    <div class="partenaire-topbar__section">Espace partenaire</div>
    <a class="partenaire-topbar__marque" href="accueil.php" aria-label="ALLÔ PRO — Accueil partenaire">ALLÔ <strong>PRO</strong></a>
    <button type="button" class="partenaire-topbar__theme" data-partenaire-theme-toggle aria-label="Passer en mode sombre" title="Passer en mode sombre" aria-pressed="false">
        <svg class="partenaire-topbar__lune" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
        <svg class="partenaire-topbar__soleil" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
    </button>
</header>
<button type="button" class="sidebar__voile" id="partenaire-menu-voile" aria-label="Fermer le menu" tabindex="-1"></button>

<script>
(function () {
    var html = document.documentElement;
    var menu = document.getElementById('sidebar-partenaire');
    var boutonMenu = document.getElementById('partenaire-menu-toggle');
    var voile = document.getElementById('partenaire-menu-voile');
    var boutonTheme = document.getElementById('partenaire-theme-toggle');
    var boutonMasquer = document.getElementById('partenaire-sidebar-masquer');
    var boutonReouvrir = document.getElementById('partenaire-sidebar-reouvrir');
    var breakpointLarge = window.matchMedia('(min-width: 1025px)');

    function definirSidebarFermee(fermee, memoriser) {
        html.classList.toggle('partenaire-sidebar-fermee', fermee);
        if (memoriser) {
            try { localStorage.setItem('allopro_sidebar', fermee ? 'closed' : 'open'); } catch (e) {}
        }
    }

    boutonMasquer.addEventListener('click', function () {
        definirSidebarFermee(true, true);
        boutonReouvrir.focus();
    });
    boutonReouvrir.addEventListener('click', function () {
        definirSidebarFermee(false, true);
        boutonMasquer.focus();
    });
    function ajusterSidebarAuBreakpoint() {
        if (!breakpointLarge.matches) {
            definirSidebarFermee(false, false);
            return;
        }
        try { definirSidebarFermee(localStorage.getItem('allopro_sidebar') === 'closed', false); } catch (e) {}
    }
    if (breakpointLarge.addEventListener) breakpointLarge.addEventListener('change', ajusterSidebarAuBreakpoint);
    else breakpointLarge.addListener(ajusterSidebarAuBreakpoint);

    function fermerMenu() {
        document.body.classList.remove('sidebar-mobile-ouverte');
        boutonMenu.setAttribute('aria-expanded', 'false');
        boutonMenu.setAttribute('aria-label', 'Ouvrir le menu');
    }

    if (menu && boutonMenu && voile) {
        boutonMenu.addEventListener('click', function () {
            var ouvert = document.body.classList.toggle('sidebar-mobile-ouverte');
            boutonMenu.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
            boutonMenu.setAttribute('aria-label', ouvert ? 'Fermer le menu' : 'Ouvrir le menu');
        });
        voile.addEventListener('click', fermerMenu);
        menu.querySelectorAll('a').forEach(function (lien) {
            lien.addEventListener('click', function () {
                if (window.matchMedia('(max-width: 700px)').matches) fermerMenu();
            });
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') fermerMenu();
        });
    }

    function mettreAJourTheme() {
        var sombre = html.getAttribute('data-theme') === 'dark';
        var libelle = sombre ? 'Passer en mode clair' : 'Passer en mode sombre';
        boutonTheme.setAttribute('aria-pressed', sombre ? 'true' : 'false');
        boutonTheme.setAttribute('aria-label', libelle);
        boutonTheme.title = libelle;
        document.querySelectorAll('[data-partenaire-theme-toggle]').forEach(function (bouton) {
            bouton.setAttribute('aria-pressed', sombre ? 'true' : 'false');
            bouton.setAttribute('aria-label', libelle);
            bouton.title = libelle;
        });
    }

    boutonTheme.addEventListener('click', function () {
        var prochain = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', prochain);
        try { localStorage.setItem('allopro_theme', prochain); } catch (e) {}
        mettreAJourTheme();
    });
    document.addEventListener('click', function (event) {
        if (event.target.closest('[data-partenaire-theme-toggle]')) boutonTheme.click();
    });
    window.addEventListener('storage', function (event) {
        if (event.key === 'allopro_theme' && ['dark', 'light'].includes(event.newValue)) {
            html.setAttribute('data-theme', event.newValue);
            mettreAJourTheme();
        }
    });
    mettreAJourTheme();
})()
</script>
<script src="../../public/js/messagerie-interne-notifications.js" defer></script>
