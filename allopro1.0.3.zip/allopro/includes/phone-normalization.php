<?php

function normaliserTelephone(string $telephone): string {
    return preg_replace('/\D+/', '', $telephone) ?? '';
}

function masquerTelephone(string $telephone): string {
    $chiffres = normaliserTelephone($telephone);
    if (strlen($chiffres) < 2) {
        return '••••••••';
    }
    return '••••••' . substr($chiffres, -2);
}
