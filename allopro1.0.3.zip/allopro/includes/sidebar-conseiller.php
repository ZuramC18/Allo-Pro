<?php
$pageCourante = basename($_SERVER['PHP_SELF']);
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$liensSidebar = [
    [
        'label'   => 'Mon profil',
        'href'    => 'profil.php',
        'pages'   => ['profil.php'],
        'icone'   => '<circle cx="12" cy="8" r="4"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/>',
    ],
    [
        'label'   => 'Demandes',
        'href'    => 'liste-demandes.php',
        'pages'   => ['liste-demandes.php', 'traiter-demande.php'],
        'icone'   => '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/>',
    ],
    [
        'label'   => 'Messages',
        'href'    => 'messagerie.php',
        'pages'   => ['messagerie.php'],
        'icone'   => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    ],
    [
        'label'   => 'Partenaires',
        'href'    => 'partenaires.php',
        'pages'   => ['partenaires.php'],
        'icone'   => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    ],
    [
        'label'   => 'SAV',
        'href'    => 'sav.php',
        'pages'   => ['sav.php'],
        'icone'   => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><path d="m4.93 4.93 4.24 4.24"/><path d="m14.83 9.17 4.24-4.24"/><path d="m14.83 14.83 4.24 4.24"/><path d="m9.17 14.83-4.24 4.24"/>',
    ],
    [
        'label'   => 'Messagerie interne',
        'href'    => '../admin/messagerie-interne.php',
        'pages'   => ['../admin/messagerie-interne.php'],
        'icone'   => '<path d="M4 4h12a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2h-4l-4 4v-4H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M9 8h7M9 11h5"/><path d="M18 9h2a2 2 0 0 1 2 2v7h-3l-3 3v-3h-2"/>',
    ],
];
?>
<button type="button" class="sidebar__mobile-toggle" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="sidebar-conseiller">
    <svg class="sidebar__mobile-ouvrir" width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
    <svg class="sidebar__mobile-fermer" width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>
</button>
<a class="sidebar__mobile-site" href="liste-demandes.php" aria-label="ALLÔ PRO — Accueil conseiller">
    <span>ALLÔ</span> <strong>PRO</strong>
</a>
<aside class="sidebar" id="sidebar-conseiller">
    <div class="sidebar__logo">
        <span class="sidebar__logo-marque">A</span>
        <span class="sidebar__logo-texte">ALLÔ <strong>PRO</strong></span>
    </div>

    <nav class="sidebar__nav" aria-label="Navigation principale">
        <?php foreach ($liensSidebar as $lien): $actif = in_array($pageCourante, $lien['pages'], true); ?>
            <a href="<?= $lien['href'] ?>"
               class="sidebar__lien <?= $actif ? 'sidebar__lien--actif' : '' ?>"
               <?= $lien['label'] === 'Messagerie interne' ? 'data-mi-notification' : '' ?>
               title="<?= $lien['label'] ?>"
               <?= $actif ? 'aria-current="page"' : '' ?>>
                <svg class="sidebar__icone" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><?= $lien['icone'] ?></svg>
                <span class="sidebar__texte"><?= $lien['label'] ?></span><?php if ($lien['label'] === 'Messagerie interne'): ?> <span class="mi-sidebar-badge" data-mi-badge hidden></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <button type="button" class="sidebar__lien sidebar__theme" id="theme-toggle" aria-pressed="false" title="Changer de thème">
        <svg class="sidebar__icone icone-lune" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>
        </svg>
        <svg class="sidebar__icone icone-soleil" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <circle cx="12" cy="12" r="4"/>
            <path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/>
            <path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>
        </svg>
        <span class="sidebar__texte">Mode sombre</span>
        <span class="theme-switch" aria-hidden="true"></span>
    </button>
    <?php if (($_SESSION['role'] ?? '') === 'conseiller'): ?>
        <div class="sidebar__presence" data-csrf="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
            <label class="sidebar__presence-label" for="statut-presence-conseiller">Mon statut</label>
            <div class="sidebar__presence-select-wrap">
                <span class="sidebar__presence-point" aria-hidden="true"></span>
                <select id="statut-presence-conseiller" class="sidebar__presence-select" aria-label="Choisir mon statut de présence">
                    <option value="online">En ligne</option>
                    <option value="pause">En pause</option>
                    <option value="offline" selected>Hors ligne</option>
                </select>
            </div>
            <span class="sidebar__presence-message" id="presence-message" role="status" aria-live="polite" hidden></span>
        </div>
    <?php endif; ?>
    <a href="../../public/deconnexion.php" class="sidebar__lien sidebar__lien--sortie" title="Déconnexion">
        <svg class="sidebar__icone" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>
        </svg>
        <span class="sidebar__texte">Déconnexion</span>
    </a>
</aside>
<button type="button" class="sidebar__voile" aria-label="Fermer le menu" tabindex="-1"></button>

<script>
(function () {
    var menu = document.getElementById('sidebar-conseiller');
    var boutonMenu = document.querySelector('.sidebar__mobile-toggle');
    var voile = document.querySelector('.sidebar__voile');
    if (menu && boutonMenu && voile) {
        function fermerMenu() {
            document.body.classList.remove('sidebar-mobile-ouverte');
            boutonMenu.setAttribute('aria-expanded', 'false');
            boutonMenu.setAttribute('aria-label', 'Ouvrir le menu');
        }
        function basculerMenu() {
            var ouvert = document.body.classList.toggle('sidebar-mobile-ouverte');
            boutonMenu.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
            boutonMenu.setAttribute('aria-label', ouvert ? 'Fermer le menu' : 'Ouvrir le menu');
        }
        boutonMenu.addEventListener('click', basculerMenu);
        voile.addEventListener('click', fermerMenu);
        menu.querySelectorAll('a').forEach(function (lien) {
            lien.addEventListener('click', fermerMenu);
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') fermerMenu();
        });
    }

    var btn = document.getElementById('theme-toggle');
    if (!btn) return;
    var racine = document.documentElement;

    function maj() {
        var sombre = racine.getAttribute('data-theme') === 'dark';
        var libelle = sombre ? 'Passer en mode clair' : 'Passer en mode sombre';
        btn.setAttribute('aria-pressed', sombre ? 'true' : 'false');
        btn.setAttribute('aria-label', libelle);
        btn.title = libelle;
        btn.querySelector('.sidebar__texte').textContent = sombre ? 'Mode clair' : 'Mode sombre';
    }

    btn.addEventListener('click', function () {
        var sombre = racine.getAttribute('data-theme') === 'dark';
        if (sombre) { racine.removeAttribute('data-theme'); } else { racine.setAttribute('data-theme', 'dark'); }
        try { localStorage.setItem('allopro_theme', sombre ? 'light' : 'dark'); } catch (e) {}
        maj();
    });
    maj();
})();
</script>

<script src="../../public/js/messagerie-interne-notifications.js" defer></script>
<script src="../../public/js/presence-conseiller.js?v=<?= filemtime(__DIR__ . '/../public/js/presence-conseiller.js') ?>" defer></script>