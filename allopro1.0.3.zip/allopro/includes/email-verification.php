<?php
require_once __DIR__ . '/SmtpMailer.php';

function envoyerCodeVerificationEmail($modele, int $id, string $email, string $nom, string $type): bool {
    if (!in_array($type, ['client', 'partenaire'], true)) {
        throw new InvalidArgumentException('Type de compte invalide.');
    }

    $configuration = require __DIR__ . '/../config/mail.php';
    $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expiration = gmdate('Y-m-d H:i:s', time() + 600);
    if (!$modele->definirCodeVerificationEmail($id, password_hash($code, PASSWORD_DEFAULT), $expiration)) {
        return false;
    }

    $nomSecurise = htmlspecialchars($nom !== '' ? $nom : 'et bienvenue', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $codeSecurise = htmlspecialchars($code, ENT_QUOTES, 'UTF-8');
    $html = '<!doctype html><html lang="fr"><meta charset="UTF-8"><body style="margin:0;padding:32px;background:#f4f6f7;font-family:Arial,sans-serif;color:#182328">'
        . '<div style="max-width:560px;margin:auto;padding:36px;background:#fff;border:1px solid #e7ecee;border-radius:20px">'
        . '<div style="margin-bottom:28px;font-size:22px;font-weight:bold;letter-spacing:-1px;color:#12181b">ALLÔ <span style="color:#ff7a30">PRO</span></div>'
        . '<div style="display:inline-block;padding:7px 11px;background:#fff2e9;border-radius:20px;color:#bd4c10;font-size:12px;font-weight:bold;letter-spacing:.5px">VÉRIFICATION DE VOTRE ADRESSE</div>'
        . '<h1 style="margin:20px 0 12px;color:#12181b;font-size:27px">Bonjour ' . $nomSecurise . ' !</h1>'
        . '<p style="color:#59636a;font-size:15px;line-height:1.7">Entrez ce code pour confirmer votre adresse e-mail et terminer la création de votre compte ALLÔ PRO.</p>'
        . '<div style="margin:28px 0;padding:22px;background:#f7f8f8;border:1px solid #e7ecee;border-radius:14px;text-align:center">'
        . '<div style="color:#79838a;font-size:12px;font-weight:bold;letter-spacing:1.5px">VOTRE CODE DE VÉRIFICATION</div>'
        . '<div style="margin-top:12px;color:#12181b;font-family:Arial,sans-serif;font-size:38px;font-weight:bold;letter-spacing:10px">' . $codeSecurise . '</div>'
        . '</div>'
        . '<p style="color:#59636a;font-size:14px;line-height:1.6">Ce code est valable pendant <strong>10 minutes</strong> et ne peut être utilisé qu’une seule fois.</p>'
        . '<p style="margin-top:28px;padding-top:20px;border-top:1px solid #edf0f1;color:#899197;font-size:12px;line-height:1.6">Si vous n’êtes pas à l’origine de cette demande, vous pouvez ignorer cet e-mail.</p>'
        . '</div></body></html>';
    $texte = "Bonjour {$nom},\n\nPour confirmer votre adresse e-mail et terminer la création de votre compte ALLÔ PRO, saisissez le code suivant :\n\n{$code}\n\nCe code est valable pendant 10 minutes et ne peut être utilisé qu’une seule fois.\nSi vous n’êtes pas à l’origine de cette demande, ignorez cet e-mail.";

    (new SmtpMailer($configuration))->envoyer($email, $nom, 'Votre code de vérification — ALLÔ PRO', $texte, $html);
    return true;
}
