<?php

final class AvatarProfil {
    private const FORMATS = [
        IMAGETYPE_JPEG => ['extension' => 'jpg', 'mime' => 'image/jpeg'],
        IMAGETYPE_PNG => ['extension' => 'png', 'mime' => 'image/png'],
        IMAGETYPE_WEBP => ['extension' => 'webp', 'mime' => 'image/webp'],
    ];

    public static function stocker(array $fichier, string $typeCompte): string {
        if (!in_array($typeCompte, ['clients', 'partenaires', 'equipe'], true)) {
            throw new RuntimeException('Le type de profil est invalide.');
        }
        if (($fichier['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new RuntimeException(match ((int) ($fichier['error'] ?? UPLOAD_ERR_NO_FILE)) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'La photo dépasse la taille maximale de 5 Mo.',
                UPLOAD_ERR_NO_FILE => 'Choisissez une photo avant de continuer.',
                default => 'La photo n’a pas pu être reçue. Réessayez.',
            });
        }
        if ((int) ($fichier['size'] ?? 0) < 1 || (int) $fichier['size'] > 5 * 1024 * 1024) {
            throw new RuntimeException('La photo doit faire 5 Mo maximum.');
        }
        $fichierTemporaire = (string) ($fichier['tmp_name'] ?? '');
        if ($fichierTemporaire === '' || !is_uploaded_file($fichierTemporaire)) {
            throw new RuntimeException('Le fichier transmis n’est pas un téléversement valide.');
        }

        $image = @getimagesize($fichierTemporaire);
        $format = is_array($image) ? (self::FORMATS[$image[2] ?? 0] ?? null) : null;
        $mimeDetecte = (new finfo(FILEINFO_MIME_TYPE))->file($fichierTemporaire);
        if (!$format || $mimeDetecte !== $format['mime']) {
            throw new RuntimeException('Format invalide. Utilisez une image JPG, PNG ou WebP.');
        }
        if ((int) ($image[0] ?? 0) < 1 || (int) ($image[1] ?? 0) < 1
            || (int) $image[0] * (int) $image[1] > 25000000) {
            throw new RuntimeException('Les dimensions de cette image ne sont pas prises en charge.');
        }

        $dossier = __DIR__ . '/../public/uploads/profils/' . $typeCompte . '/';
        if (!is_dir($dossier) && !mkdir($dossier, 0755, true) && !is_dir($dossier)) {
            error_log('Création du dossier de photos de profil impossible : ' . $typeCompte);
            throw new RuntimeException('Le stockage des photos est indisponible pour le moment.');
        }
        $nomFichier = bin2hex(random_bytes(16)) . '.' . $format['extension'];
        if (!move_uploaded_file($fichierTemporaire, $dossier . $nomFichier)) {
            throw new RuntimeException('La photo n’a pas pu être enregistrée. Réessayez.');
        }
        return 'uploads/profils/' . $typeCompte . '/' . $nomFichier;
    }

    public static function estValide(?string $chemin, string $typeCompte): bool {
        return in_array($typeCompte, ['clients', 'partenaires', 'equipe'], true)
            && is_string($chemin)
            && preg_match(
                '#^uploads/profils/' . preg_quote($typeCompte, '#') . '/[a-f0-9]{32}\.(?:jpg|png|webp)$#',
                $chemin
            ) === 1;
    }

    public static function supprimer(?string $chemin): void {
        if (!is_string($chemin)
            || preg_match('#^uploads/profils/(?:clients|partenaires|equipe)/[a-f0-9]{32}\.(?:jpg|png|webp)$#', $chemin) !== 1) {
            return;
        }
        $fichier = __DIR__ . '/../public/' . $chemin;
        if (is_file($fichier) && !unlink($fichier)) {
            error_log('Suppression de la photo de profil impossible : ' . $chemin);
        }
    }

    public static function initiales(string $nom): string {
        $mots = preg_split('/\s+/u', trim($nom), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (!$mots) return '?';
        $lettres = mb_substr($mots[0], 0, 1, 'UTF-8');
        if (count($mots) > 1) {
            $lettres .= mb_substr($mots[count($mots) - 1], 0, 1, 'UTF-8');
        }
        return mb_strtoupper($lettres, 'UTF-8');
    }
}
