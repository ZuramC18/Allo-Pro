<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../config/database.php';

const ACTEUR_SYSTEME = ['type' => 'systeme', 'id' => null, 'matricule' => 'SYSTEME', 'nom' => 'Système'];

// Retrouve qui agit, à partir de la session
function acteurCourant() {
    static $cache = [];
    $chemin = $_SERVER['SCRIPT_NAME'] ?? '';

    // Si plusieurs sessions coexistent dans le même navigateur (tests), l'espace consulté départage
    if (isset($_SESSION['technicien_id']) && (preg_match('#/views/technicien/|connexion-technicien#', $chemin) || !isset($_SESSION['user_id']))) {
        $source = 'technicien'; $id = (int) $_SESSION['technicien_id'];
    } elseif (isset($_SESSION['partenaire_id']) && (preg_match('#/views/partenaire/|connexion-partenaire#', $chemin) || !isset($_SESSION['user_id']))) {
        $source = 'partenaire'; $id = (int) $_SESSION['partenaire_id'];
    } elseif (isset($_SESSION['user_id'])) {
        $source = 'user'; $id = (int) $_SESSION['user_id'];
    } else {
        return ['type' => 'inconnu', 'id' => null, 'matricule' => null, 'nom' => null];
    }

    $cle = $source . ':' . $id;
    if (!isset($cache[$cle])) {
        $requetes = [
            'user'       => "SELECT role AS type, nom, matricule FROM users WHERE id = :id",
            'partenaire' => "SELECT 'partenaire' AS type, nom_entreprise AS nom, matricule FROM partenaires WHERE id = :id",
            'technicien' => "SELECT 'technicien' AS type, nom, matricule FROM techniciens WHERE id = :id",
        ];
        $stmt = (new Database())->getConnection()->prepare($requetes[$source]);
        $stmt->execute([':id' => $id]);
        $ligne = $stmt->fetch();

        $cache[$cle] = $ligne
            ? ['type' => $ligne['type'], 'id' => $id, 'matricule' => $ligne['matricule'], 'nom' => $ligne['nom']]
            : ['type' => 'inconnu', 'id' => $id, 'matricule' => null, 'nom' => null];
    }
    return $cache[$cle];
}

// Enregistre une action sensible. Ne fait jamais échouer l'action métier elle-même.
function journaliser($action, $entite, $entiteId = null, $cible = null, $detail = null, $acteur = null) {
    try {
        $acteur = $acteur ?? acteurCourant();
        $stmt = (new Database())->getConnection()->prepare(
            "INSERT INTO audit_log (acteur_type, acteur_id, acteur_matricule, acteur_nom, action, entite, entite_id, cible, detail, ip)
             VALUES (:type, :id, :matricule, :nom, :action, :entite, :entite_id, :cible, :detail, :ip)"
        );
        $stmt->execute([
            ':type' => $acteur['type'],
            ':id' => $acteur['id'],
            ':matricule' => $acteur['matricule'],
            ':nom' => $acteur['nom'],
            ':action' => $action,
            ':entite' => $entite,
            ':entite_id' => $entiteId,
            ':cible' => $cible,
            ':detail' => $detail,
            ':ip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (Exception $e) {
        error_log('Audit : ' . $e->getMessage());
    }
}