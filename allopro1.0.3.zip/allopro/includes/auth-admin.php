<?php
require_once __DIR__ . '/permissions.php';

// Réservée aux pages strictement admin
function verifierAdminConnecte() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(403);
        die("Accès réservé aux administrateurs.");
    }
    rafraichirCompteConnecte();
    if (($_SESSION['role'] ?? '') !== 'admin') {
        http_response_code(403);
        die("Accès réservé aux administrateurs.");
    }
}