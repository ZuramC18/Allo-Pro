<?php
session_start();
require_once __DIR__ . '/audit.php';
require_once __DIR__ . '/../config/database.php';

function verifierPartenaireConnecte() {
    if (!isset($_SESSION['partenaire_id'])) {
        header("Location: /allopro/public/connexion-partenaire.php");
        exit;
    }

    $stmt = (new Database())->getConnection()->prepare(
        "SELECT nom_entreprise, statut, photo_profil, avatar_initiales FROM partenaires WHERE id = :id"
    );
    $stmt->execute([':id' => $_SESSION['partenaire_id']]);
    $p = $stmt->fetch();

    if (!$p || $p['statut'] !== 'actif') {
        journaliser('session.coupee', 'compte', $_SESSION['partenaire_id'], $_SESSION['partenaire_nom'] ?? null, 'Partenaire désactivé pendant une session active');
        unset($_SESSION['partenaire_id'], $_SESSION['partenaire_nom']);
        header("Location: /allopro/public/connexion-partenaire.php?raison=suspendu");
        exit;
    }
    $_SESSION['partenaire_nom'] = $p['nom_entreprise'];
    $_SESSION['partenaire_photo_profil'] = $p['photo_profil'];
    $_SESSION['partenaire_avatar_initiales'] = (bool) $p['avatar_initiales'];
}