<?php
function base64UrlDecode($input) {
    $remainder = strlen($input) % 4;
    if ($remainder) $input .= str_repeat('=', 4 - $remainder);
    return base64_decode(strtr($input, '-_', '+/'));
}

function derLongueur($longueur) {
    if ($longueur <= 0x7F) return chr($longueur);
    $octets = ltrim(pack('N', $longueur), "\x00");
    return chr(0x80 | strlen($octets)) . $octets;
}

function derEntier($octets) {
    return "\x02" . derLongueur(strlen($octets)) . $octets;
}

// Construit une clé publique PEM à partir du module (n) et de l'exposant (e) fournis par Google au format JWK
function jwkVersPem($n, $e) {
    $modulus = base64UrlDecode($n);
    if (ord($modulus[0]) > 0x7f) $modulus = "\x00" . $modulus;
    $exposant = base64UrlDecode($e);
    if (ord($exposant[0]) > 0x7f) $exposant = "\x00" . $exposant;

    $sequence = derEntier($modulus) . derEntier($exposant);
    $sequenceRSA = "\x30" . derLongueur(strlen($sequence)) . $sequence;

    $bitString = "\x00" . $sequenceRSA;
    $bitStringEnc = "\x03" . derLongueur(strlen($bitString)) . $bitString;

    $oidRSA = "\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00";
    $algId = "\x30" . derLongueur(strlen($oidRSA)) . $oidRSA;

    $spki = $algId . $bitStringEnc;
    $spkiSeq = "\x30" . derLongueur(strlen($spki)) . $spki;

    return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($spkiSeq), 64, "\n") . "-----END PUBLIC KEY-----\n";
}

// Vérifie un jeton Google Identity Services ; retourne le payload (tableau) ou null si invalide
function verifierJetonGoogle($jwt, $clientIdAttendu) {
    $parties = explode('.', $jwt);
    if (count($parties) !== 3) return null;
    [$entete64, $charge64, $signature64] = $parties;

    $entete = json_decode(base64UrlDecode($entete64), true);
    $charge = json_decode(base64UrlDecode($charge64), true);
    $signature = base64UrlDecode($signature64);
    if (!$entete || !$charge || ($entete['alg'] ?? '') !== 'RS256') return null;

    $cles = @file_get_contents('https://www.googleapis.com/oauth2/v3/certs');
    if (!$cles) return null;
    $jwks = json_decode($cles, true)['keys'] ?? [];

    $cle = null;
    foreach ($jwks as $k) { if ($k['kid'] === $entete['kid']) { $cle = $k; break; } }
    if (!$cle) return null;

    $pem = jwkVersPem($cle['n'], $cle['e']);
    $ok = openssl_verify("$entete64.$charge64", $signature, $pem, OPENSSL_ALGO_SHA256);
    if ($ok !== 1) return null;

    if (!in_array($charge['iss'] ?? '', ['accounts.google.com', 'https://accounts.google.com'], true)) return null;
    if (($charge['aud'] ?? '') !== $clientIdAttendu) return null;
    if (($charge['exp'] ?? 0) < time()) return null;
    if (($charge['email_verified'] ?? false) !== true && ($charge['email_verified'] ?? '') !== 'true') return null;

    return $charge;
}