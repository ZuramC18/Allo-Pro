<script>
(function () {
    try {
        var t = localStorage.getItem('allopro_theme');
        if (t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    } catch (e) {}
})();
</script>
<link rel="stylesheet" href="../../public/css/dark.css?v=<?= filemtime(__DIR__ . '/../public/css/dark.css') ?>">