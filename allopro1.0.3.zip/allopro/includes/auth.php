<?php
require_once __DIR__ . '/permissions.php';

function verifierConnexion() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /allopro/public/connexion.php");
        exit;
    }
    rafraichirCompteConnecte();
}

function verifierRole($rolesAutorises) {
    verifierConnexion();

    if (!in_array($_SESSION['role'], $rolesAutorises)) {
        http_response_code(403);
        die("Accès refusé — vous n'avez pas les droits nécessaires.");
    }
}