<?php
$pageActuelle = basename($_SERVER['PHP_SELF']);
require_once __DIR__ . '/icones.php';

// [fichier, nom de l'icône SVG (voir includes/icones.php), libellé, module requis]
$menu = [
    "Vue d'ensemble" => [
        ['accueil.php', 'dashboard', 'Tableau de bord', 'tableau_bord'],
        ['statistiques.php', 'chart', 'Statistiques', 'statistiques'],
    ],
    'Opérations' => [
        ['liste-demandes.php', 'inbox', 'Demandes', 'demandes'],
        ['conversations.php', 'shuffle', 'Coordination', 'coordination'],
        ['messagerie.php', 'message', 'Messagerie', 'messagerie'],
        ['messagerie-interne.php', 'messages', 'Messagerie interne', 'messagerie_interne'],
        ['interventions.php', 'receipt', 'Interventions', 'interventions'],
        ['paiements.php', 'card', 'Paiements', 'paiements'],
        ['livre-comptes.php', 'file-text', 'Livre des comptes', 'reversements'],
        ['partage-benefices.php', 'refresh', 'Partage des bénéfices', 'reversements'],
        ['reversements.php', 'refresh', 'Reversements', 'reversements'],
        ['sav.php', 'headset', 'SAV', 'sav'],
    ],
    'Gestion' => [
        ['clients.php', 'users', 'Clients', 'clients'],
        ['partenaires.php', 'building', 'Partenaires', 'partenaires'],
        ['techniciens.php', 'wrench', 'Techniciens', 'techniciens'],
        ['utilisateurs.php', 'key', 'Équipe ALLÔ PRO', 'equipe'],
    ],
    'Configuration' => [
        ['categories.php', 'folder', 'Catégories', 'categories'],
        ['abonnements.php', 'gem', 'Abonnements & Pass', 'abonnements'],
        ['roles.php', 'shield', 'Rôles & permissions', 'roles'],
        ['audit.php', 'file-text', "Journal d'audit", 'audit'],
        ['parametres.php', 'settings', 'Paramètres', 'parametres'],
    ],
];
?>
<!-- Thème : appliqué dès le début de la page pour éviter un flash clair -->
<script>
(function () {
    try {
        var t = localStorage.getItem('allopro_theme');
        if (t !== 'dark' && t !== 'light') t = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', t);
    } catch (e) { document.documentElement.setAttribute('data-theme', 'light'); }

    // Sidebar : masquée par défaut sur tablette/mobile, sinon selon le dernier choix de l'utilisateur
    try {
        var etroit = window.matchMedia('(max-width: 1024px)').matches;
        var pref = localStorage.getItem('allopro_sidebar');
        if (etroit || pref === 'closed') document.documentElement.classList.add('sidebar-fermee');
    } catch (e) {}
})();
</script>
<link rel="stylesheet" href="../../public/css/theme-admin.css?v=<?= filemtime(__DIR__ . '/../public/css/theme-admin.css') ?>">

<div class="admin-sidebar">
    <div class="tete">
        <a href="../../public/index.php" class="admin-sidebar__logo">ALLÔ<span> PRO</span></a>

        <div class="admin-sidebar__actions">
        <!-- Bascule mode sombre -->
        <button type="button" class="admin-sidebar__theme" id="theme-toggle" role="switch" aria-checked="false" aria-label="Mode sombre" title="Mode sombre">
            <svg class="theme-ico theme-ico--lune" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
            <svg class="theme-ico theme-ico--soleil" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
        </button>
        <!-- Masquer la sidebar -->
        <button type="button" class="admin-sidebar__fermer" id="sidebar-fermer" aria-label="Masquer le menu" title="Masquer le menu">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m11 17-5-5 5-5"/><path d="m18 17-5-5 5-5"/></svg>
        </button>
        </div>
    </div>
    <?php $moiSidebar = acteurCourant(); ?>
    <div class="admin-sidebar__role"><?= htmlspecialchars((LIBELLES_ROLES[$_SESSION['role']] ?? '') . ' · ' . ($moiSidebar['matricule'] ?? '—')) ?></div>

    <?php foreach ($menu as $titre => $liens):
        $visibles = array_filter($liens, fn($l) => peut($l[3]));
        if (empty($visibles)) continue;
    ?>
        <div class="admin-sidebar__section-titre"><?= htmlspecialchars($titre) ?></div>
        <?php foreach ($visibles as $l): ?>
            <a href="<?= $l[0] ?>" class="admin-sidebar__lien <?= $pageActuelle === $l[0] ? 'admin-sidebar__lien--actif' : '' ?>" <?= $l[0] === 'messagerie-interne.php' ? 'data-mi-notification' : '' ?>>
                <span class="admin-sidebar__icone"><?= icone($l[1], 18) ?></span> <?= $l[2] ?><?php if ($l[0] === 'messagerie-interne.php'): ?> <span class="mi-sidebar-badge" data-mi-badge hidden></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
    <?php endforeach; ?>

    <div class="admin-sidebar__bas">
        <a href="../../public/deconnexion.php" class="admin-sidebar__lien"><span class="admin-sidebar__icone"><?= icone('logout', 18) ?></span> Déconnexion</a>
    </div>
</div>

<!-- Voile derrière la sidebar (mobile) et bouton pour la ré-afficher -->
<div class="admin-sidebar__voile" id="sidebar-voile"></div>
<button type="button" class="admin-sidebar__ouvrir" id="sidebar-ouvrir" aria-label="Afficher le menu" aria-expanded="false" title="Afficher le menu">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
</button>
<a class="admin-sidebar__site-link" href="accueil.php" aria-label="ALLÔ PRO — Accueil">
    ALLÔ<span> PRO</span>
</a>
<div class="admin-sidebar__top-actions">
    <?php if ($pageActuelle !== 'accueil.php'): ?>
    <span class="admin-sidebar__nom-utilisateur" title="<?= htmlspecialchars($_SESSION['nom'] ?? 'Admin', ENT_QUOTES, 'UTF-8') ?>">
        <?= htmlspecialchars($_SESSION['nom'] ?? 'Admin', ENT_QUOTES, 'UTF-8') ?>
    </span>
    <?php endif; ?>
    <button type="button" class="admin-sidebar__theme-top" id="theme-toggle-top" role="switch" aria-checked="false" aria-label="Passer en mode sombre" title="Passer en mode sombre">
        <svg class="theme-ico theme-ico--lune" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
        <svg class="theme-ico theme-ico--soleil" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
    </button>
</div>

<script>
(function () {
    const html = document.documentElement;
    const boutons = [document.getElementById('theme-toggle'), document.getElementById('theme-toggle-top')].filter(Boolean);
    if (!boutons.length) return;
    const reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function appliquer(theme, animer) {
        if (animer && !reduit) {
            html.classList.add('theme-anim');
            setTimeout(() => html.classList.remove('theme-anim'), 350);
        }
        html.setAttribute('data-theme', theme);
        const sombre = theme === 'dark';
        boutons.forEach((bouton) => {
            bouton.setAttribute('aria-checked', sombre ? 'true' : 'false');
            bouton.setAttribute('aria-label', sombre ? 'Passer en mode clair' : 'Passer en mode sombre');
            bouton.title = sombre ? 'Passer en mode clair' : 'Passer en mode sombre';
        });
    }
    appliquer(html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light', false);

    boutons.forEach((bouton) => bouton.addEventListener('click', () => {
        const suivant = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        appliquer(suivant, true);
        try { localStorage.setItem('allopro_theme', suivant); } catch (e) {}
    }));
    // Synchronisation entre onglets (et avec l'espace client : même clé)
    window.addEventListener('storage', (e) => {
        if (e.key === 'allopro_theme' && (e.newValue === 'dark' || e.newValue === 'light')) appliquer(e.newValue, false);
    });
})();
</script>

<script>
// Afficher / masquer la sidebar
(function () {
    const html = document.documentElement;
    const sidebar = document.querySelector('.admin-sidebar');
    const ouvrir = document.getElementById('sidebar-ouvrir');
    const fermer = document.getElementById('sidebar-fermer');
    const voile = document.getElementById('sidebar-voile');
    if (!sidebar || !ouvrir || !fermer || !voile) return;
    const mobile = window.matchMedia('(max-width: 1024px)');

    const estFermee = () => html.classList.contains('sidebar-fermee');
    function definir(fermee, memoriser) {
        html.classList.toggle('sidebar-fermee', fermee);
        ouvrir.setAttribute('aria-expanded', fermee ? 'false' : 'true');
        // Le choix n'est mémorisé que sur grand écran (sur mobile, le menu est toujours fermé au départ)
        if (memoriser && !mobile.matches) { try { localStorage.setItem('allopro_sidebar', fermee ? 'closed' : 'open'); } catch (e) {} }
    }
    definir(estFermee(), false);

    ouvrir.addEventListener('click', () => { definir(false, true); fermer.focus(); });
    fermer.addEventListener('click', () => { definir(true, true); ouvrir.focus(); });
    voile.addEventListener('click', () => { definir(true, false); ouvrir.focus(); });
    sidebar.querySelectorAll('.admin-sidebar__lien').forEach((a) => a.addEventListener('click', () => { if (mobile.matches) definir(true, false); }));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mobile.matches && !estFermee()) { definir(true, false); ouvrir.focus(); }
    });

    // Passage mobile <-> bureau (rotation d'une tablette, redimensionnement)
    const surChangement = () => {
        if (mobile.matches) { definir(true, false); return; }
        let pref = null; try { pref = localStorage.getItem('allopro_sidebar'); } catch (e) {}
        definir(pref === 'closed', false);
    };
    if (mobile.addEventListener) mobile.addEventListener('change', surChangement); else mobile.addListener(surChangement);
})();
</script>

<script src="../../public/js/messagerie-interne-notifications.js" defer></script>