<?php
require_once __DIR__ . '/../models/Tache.php';

$tacheModel = new Tache();
$csrfSession = 'csrf_taches_' . $typeProprietaire;
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}

$statutTache = is_string($_GET['statut'] ?? null) ? $_GET['statut'] : '';
if (!in_array($statutTache, ['', 'a_faire', 'terminee'], true)) {
    $statutTache = '';
}
$rechercheTache = is_string($_GET['q'] ?? null) ? trim(mb_substr($_GET['q'], 0, 100)) : '';
$erreurTache = '';
$messageTache = is_string($_SESSION['flash_taches_' . $typeProprietaire] ?? null)
    ? $_SESSION['flash_taches_' . $typeProprietaire]
    : '';
unset($_SESSION['flash_taches_' . $typeProprietaire]);

$titreFormulaire = '';
$descriptionFormulaire = '';
$echeanceFormulaire = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $actionTache = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';

    if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
        http_response_code(403);
        $erreurTache = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($actionTache === 'creer') {
        $titreFormulaire = is_string($_POST['titre'] ?? null) ? trim($_POST['titre']) : '';
        $descriptionFormulaire = is_string($_POST['description'] ?? null) ? trim($_POST['description']) : '';
        $echeanceFormulaire = is_string($_POST['date_echeance'] ?? null) ? $_POST['date_echeance'] : '';
        $dateEcheance = null;

        if ($titreFormulaire === '' || mb_strlen($titreFormulaire) > 150) {
            $erreurTache = 'Le titre est obligatoire et doit contenir 150 caractères maximum.';
        } elseif (mb_strlen($descriptionFormulaire) > 2000) {
            $erreurTache = 'Les détails ne peuvent pas dépasser 2 000 caractères.';
        } elseif ($echeanceFormulaire !== '') {
            $date = DateTime::createFromFormat('!Y-m-d\TH:i', $echeanceFormulaire);
            $erreursDate = DateTime::getLastErrors();
            if (!$date || ($erreursDate !== false && ($erreursDate['warning_count'] > 0 || $erreursDate['error_count'] > 0))
                || $date->format('Y-m-d\TH:i') !== $echeanceFormulaire) {
                $erreurTache = 'La date d’échéance est invalide.';
            } else {
                $dateEcheance = $date->format('Y-m-d H:i:s');
            }
        }

        if ($erreurTache === '') {
            try {
                if ($tacheModel->creerPour($typeProprietaire, $proprietaireId, $titreFormulaire, $descriptionFormulaire, $dateEcheance)) {
                    $_SESSION['flash_taches_' . $typeProprietaire] = 'La tâche a été ajoutée.';
                    header('Location: ' . $urlTaches);
                    exit;
                }
                $erreurTache = 'La tâche n’a pas pu être ajoutée. Réessayez.';
            } catch (PDOException $exception) {
                error_log('Création tâche ' . $typeProprietaire . ' ' . $proprietaireId . ' : ' . $exception->getMessage());
                $erreurTache = 'Une erreur est survenue lors de l’enregistrement de la tâche.';
            }
        }
    } elseif (in_array($actionTache, ['terminer', 'reprendre', 'supprimer'], true)) {
        $tacheId = filter_var($_POST['tache_id'] ?? null, FILTER_VALIDATE_INT);
        if ($tacheId === false || $tacheId === null || $tacheId <= 0) {
            $erreurTache = 'La tâche sélectionnée est invalide.';
        } else {
            try {
                if ($actionTache === 'supprimer') {
                    $modifie = $tacheModel->supprimerPour($typeProprietaire, $proprietaireId, $tacheId);
                    $messageAction = 'La tâche a été supprimée.';
                } else {
                    $modifie = $tacheModel->changerStatutPour(
                        $typeProprietaire,
                        $proprietaireId,
                        $tacheId,
                        $actionTache === 'terminer' ? 'terminee' : 'a_faire'
                    );
                    $messageAction = $actionTache === 'terminer' ? 'La tâche est terminée.' : 'La tâche a été remise à faire.';
                }

                if ($modifie) {
                    $_SESSION['flash_taches_' . $typeProprietaire] = $messageAction;
                    $retour = array_filter([
                        'statut' => $statutTache,
                        'q' => $rechercheTache,
                    ], static fn($valeur) => $valeur !== '');
                    header('Location: ' . $urlTaches . ($retour ? '?' . http_build_query($retour) : ''));
                    exit;
                }
                $erreurTache = 'Cette tâche n’existe plus ou ne vous appartient pas.';
            } catch (PDOException $exception) {
                error_log('Mise à jour tâche ' . $typeProprietaire . ' ' . $proprietaireId . ' : ' . $exception->getMessage());
                $erreurTache = 'Une erreur est survenue lors de la mise à jour de la tâche.';
            }
        }
    } else {
        $erreurTache = 'Action de tâche inconnue.';
    }
}

try {
    $taches = $tacheModel->getByProprietaire($typeProprietaire, $proprietaireId);
} catch (PDOException $exception) {
    error_log('Lecture tâches ' . $typeProprietaire . ' ' . $proprietaireId . ' : ' . $exception->getMessage());
    http_response_code(500);
    $taches = [];
    $erreurTache = 'Impossible de charger les tâches pour le moment.';
}

$compteursTaches = ['a_faire' => 0, 'terminee' => 0, 'en_retard' => 0];
$tachesFiltrees = [];
$maintenant = new DateTimeImmutable();
foreach ($taches as $tache) {
    if ($tache['statut'] === 'terminee') {
        $compteursTaches['terminee']++;
    } else {
        $compteursTaches['a_faire']++;
        if ($tache['date_echeance'] && new DateTimeImmutable($tache['date_echeance']) < $maintenant) {
            $compteursTaches['en_retard']++;
        }
    }

    $correspondStatut = $statutTache === '' || $tache['statut'] === $statutTache;
    $texteRecherche = mb_strtolower($tache['titre'] . ' ' . ($tache['description'] ?? ''), 'UTF-8');
    $correspondRecherche = $rechercheTache === '' || mb_strpos($texteRecherche, mb_strtolower($rechercheTache, 'UTF-8')) !== false;
    if ($correspondStatut && $correspondRecherche) {
        $tachesFiltrees[] = $tache;
    }
}

$echapperTache = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
