CREATE TABLE IF NOT EXISTS intervention_checklist (
    id INT NOT NULL AUTO_INCREMENT,
    intervention_id INT NOT NULL,
    cle VARCHAR(40) NOT NULL,
    libelle VARCHAR(180) NOT NULL,
    ordre SMALLINT UNSIGNED NOT NULL,
    terminee TINYINT(1) NOT NULL DEFAULT 0,
    date_modification TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_intervention_checklist_cle (intervention_id, cle),
    CONSTRAINT fk_intervention_checklist_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS intervention_documents (
    id INT NOT NULL AUTO_INCREMENT,
    intervention_id INT NOT NULL,
    technicien_id INT NOT NULL,
    nom_original VARCHAR(255) NOT NULL,
    chemin VARCHAR(200) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    taille INT UNSIGNED NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_intervention_documents_chemin (chemin),
    KEY idx_intervention_documents_intervention (intervention_id, date_creation),
    CONSTRAINT fk_intervention_documents_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE CASCADE,
    CONSTRAINT fk_intervention_documents_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id) ON DELETE CASCADE
);

INSERT INTO intervention_checklist (intervention_id, cle, libelle, ordre)
SELECT i.id, modeles.cle, modeles.libelle, modeles.ordre
FROM interventions i
CROSS JOIN (
    SELECT 'consignes' AS cle, CONVERT(0x56C3A9726966696572206CE2809961647265737365206574206C657320636F6E7369676E657320647520636C69656E74 USING utf8mb4) AS libelle, 1 AS ordre
    UNION ALL SELECT 'materiel', CONVERT(0x5072C3A97061726572206C6573206F7574696C73206574207069C3A8636573206EC3A9636573736169726573 USING utf8mb4), 2
    UNION ALL SELECT 'diagnostic', CONVERT(0x52C3A9616C69736572206574206578706C6971756572206C6520646961676E6F73746963 USING utf8mb4), 3
    UNION ALL SELECT 'intervention', CONVERT(0x456666656374756572206CE28099696E74657276656E74696F6E20656E2073C3A96375726974C3A9 USING utf8mb4), 4
    UNION ALL SELECT 'tests', CONVERT(0x546573746572206C6520666F6E6374696F6E6E656D656E7420617072C3A87320696E74657276656E74696F6E USING utf8mb4), 5
    UNION ALL SELECT 'client', CONVERT(0x5072C3A973656E746572206C652072C3A973756C74617420617520636C69656E742065742072616E676572 USING utf8mb4), 6
) AS modeles
WHERE 1 = 1
ON DUPLICATE KEY UPDATE
    libelle = VALUES(libelle),
    ordre = VALUES(ordre);
