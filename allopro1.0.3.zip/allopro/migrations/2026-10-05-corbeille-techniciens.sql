ALTER TABLE techniciens
    MODIFY COLUMN statut ENUM('actif', 'inactif', 'corbeille') NOT NULL DEFAULT 'actif';
