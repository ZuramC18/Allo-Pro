ALTER TABLE users
    ADD COLUMN reinitialisation_token_hash CHAR(64) NULL,
    ADD COLUMN reinitialisation_expires_at DATETIME NULL,
    ADD COLUMN reinitialisation_sent_at DATETIME NULL,
    ADD INDEX idx_users_reinitialisation_token (reinitialisation_token_hash);

ALTER TABLE partenaires
    ADD COLUMN reinitialisation_token_hash CHAR(64) NULL,
    ADD COLUMN reinitialisation_expires_at DATETIME NULL,
    ADD COLUMN reinitialisation_sent_at DATETIME NULL,
    ADD INDEX idx_partenaires_reinitialisation_token (reinitialisation_token_hash);

ALTER TABLE techniciens
    ADD COLUMN reinitialisation_token_hash CHAR(64) NULL,
    ADD COLUMN reinitialisation_expires_at DATETIME NULL,
    ADD COLUMN reinitialisation_sent_at DATETIME NULL,
    ADD INDEX idx_techniciens_reinitialisation_token (reinitialisation_token_hash);
