ALTER TABLE messages
    ADD COLUMN audio_path VARCHAR(255) NULL AFTER image_path;
