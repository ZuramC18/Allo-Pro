ALTER TABLE users
    ADD COLUMN email_verifie TINYINT(1) NOT NULL DEFAULT 1,
    ADD COLUMN email_verification_token_hash CHAR(64) NULL,
    ADD COLUMN email_verification_expires_at DATETIME NULL,
    ADD COLUMN email_verification_sent_at DATETIME NULL,
    ADD INDEX idx_users_email_verification_token (email_verification_token_hash);

ALTER TABLE partenaires
    ADD COLUMN email_verifie TINYINT(1) NOT NULL DEFAULT 1,
    ADD COLUMN email_verification_token_hash CHAR(64) NULL,
    ADD COLUMN email_verification_expires_at DATETIME NULL,
    ADD COLUMN email_verification_sent_at DATETIME NULL,
    ADD INDEX idx_partenaires_email_verification_token (email_verification_token_hash);
