ALTER TABLE pass_achats
    ADD COLUMN montant_achat DECIMAL(10,2) NULL DEFAULT NULL AFTER pass_type_id;

UPDATE pass_achats pa
JOIN pass_types pt ON pt.id = pa.pass_type_id
SET pa.montant_achat = pt.prix
WHERE pa.montant_achat IS NULL;

ALTER TABLE abonnements_clients
    ADD COLUMN montant_achat DECIMAL(10,2) NULL DEFAULT NULL AFTER formule_id,
    ADD COLUMN credits_inclus INT UNSIGNED NULL DEFAULT NULL AFTER montant_achat;

UPDATE abonnements_clients ac
JOIN formules_abonnement f ON f.id = ac.formule_id
SET ac.montant_achat = f.prix,
    ac.credits_inclus = f.nombre_credits
WHERE ac.montant_achat IS NULL OR ac.credits_inclus IS NULL;

INSERT INTO parametres (cle, valeur)
VALUES ('taux_commission_pass', '10'), ('taux_commission_abonnement', '10')
ON DUPLICATE KEY UPDATE valeur = valeur;
