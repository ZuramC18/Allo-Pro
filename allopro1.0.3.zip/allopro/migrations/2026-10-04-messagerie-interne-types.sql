ALTER TABLE conversations_internes
    MODIFY type_a ENUM('admin', 'equipe', 'partenaire', 'technicien') NOT NULL,
    MODIFY type_b ENUM('admin', 'equipe', 'partenaire', 'technicien') NOT NULL;

ALTER TABLE messages_internes
    MODIFY expediteur_type ENUM('admin', 'equipe', 'partenaire', 'technicien') NOT NULL;

UPDATE conversations_internes SET type_a = 'equipe' WHERE type_a = '';
UPDATE conversations_internes SET type_b = 'equipe' WHERE type_b = '';
UPDATE messages_internes SET expediteur_type = 'equipe' WHERE expediteur_type = '';