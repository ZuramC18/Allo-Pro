ALTER TABLE techniciens
    ADD COLUMN prenom VARCHAR(100) NOT NULL DEFAULT '' AFTER nom,
    ADD COLUMN nom_famille VARCHAR(100) NOT NULL DEFAULT '' AFTER prenom;

UPDATE techniciens
SET prenom = SUBSTRING_INDEX(TRIM(nom), ' ', 1),
    nom_famille = TRIM(SUBSTRING(TRIM(nom), CHAR_LENGTH(SUBSTRING_INDEX(TRIM(nom), ' ', 1)) + 1))
WHERE TRIM(nom) <> '';
