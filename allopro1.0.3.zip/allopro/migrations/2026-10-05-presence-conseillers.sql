ALTER TABLE users
    ADD COLUMN presence_status ENUM('online', 'pause', 'offline') NOT NULL DEFAULT 'offline',
    ADD COLUMN presence_last_seen DATETIME NULL;
