ALTER TABLE techniciens
    ADD COLUMN photo_profil VARCHAR(255) NULL AFTER telephone,
    ADD COLUMN avatar_initiales TINYINT(1) NOT NULL DEFAULT 0 AFTER photo_profil;
