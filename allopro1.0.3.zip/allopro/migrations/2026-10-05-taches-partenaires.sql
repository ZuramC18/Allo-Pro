ALTER TABLE taches
    MODIFY technicien_id INT NULL,
    ADD partenaire_id INT NULL AFTER technicien_id,
    ADD INDEX idx_taches_partenaire_id (partenaire_id),
    ADD CONSTRAINT taches_ibfk_partenaire FOREIGN KEY (partenaire_id) REFERENCES partenaires (id) ON DELETE CASCADE,
    ADD CONSTRAINT chk_taches_un_proprietaire CHECK (
        (technicien_id IS NOT NULL AND partenaire_id IS NULL)
        OR (technicien_id IS NULL AND partenaire_id IS NOT NULL)
    );
