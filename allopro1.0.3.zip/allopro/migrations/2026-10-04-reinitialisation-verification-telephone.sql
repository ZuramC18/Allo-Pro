ALTER TABLE users
    ADD COLUMN reinitialisation_phone_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN reinitialisation_phone_blocked_until DATETIME NULL;

ALTER TABLE partenaires
    ADD COLUMN reinitialisation_phone_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN reinitialisation_phone_blocked_until DATETIME NULL;

ALTER TABLE techniciens
    ADD COLUMN reinitialisation_phone_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN reinitialisation_phone_blocked_until DATETIME NULL;
