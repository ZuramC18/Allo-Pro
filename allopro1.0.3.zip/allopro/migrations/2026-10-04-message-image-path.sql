ALTER TABLE messages
    ADD COLUMN image_path VARCHAR(255) NULL AFTER contenu;