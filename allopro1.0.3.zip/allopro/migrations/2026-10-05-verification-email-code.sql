ALTER TABLE users
    ADD COLUMN email_verification_code_hash VARCHAR(255) NULL,
    ADD COLUMN email_verification_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0;

ALTER TABLE partenaires
    ADD COLUMN email_verification_code_hash VARCHAR(255) NULL,
    ADD COLUMN email_verification_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0;
