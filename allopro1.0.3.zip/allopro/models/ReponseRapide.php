<?php
require_once __DIR__ . '/../config/database.php';

class ReponseRapide {
    private $conn;
    private $table = 'reponses_rapides';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY categorie, titre");
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($titre, $contenu, $motsCles, $categorie, $type, $id) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (titre, contenu, mots_cles, categorie, cree_par_type, cree_par_id)
             VALUES (:titre, :contenu, :mots_cles, :categorie, :type, :id)"
        );
        return $stmt->execute([
            ':titre' => $titre, ':contenu' => $contenu, ':mots_cles' => $motsCles,
            ':categorie' => $categorie ?: 'Général', ':type' => $type, ':id' => $id
        ]);
    }

    public function modifier($id, $titre, $contenu, $motsCles, $categorie) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET titre = :titre, contenu = :contenu, mots_cles = :mots_cles, categorie = :categorie WHERE id = :id"
        );
        return $stmt->execute([
            ':titre' => $titre, ':contenu' => $contenu, ':mots_cles' => $motsCles,
            ':categorie' => $categorie ?: 'Général', ':id' => $id
        ]);
    }

    public function supprimer($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function getParCategorie() {
        $parCat = [];
        foreach ($this->getAll() as $r) { $parCat[$r['categorie']][] = $r; }
        return $parCat;
    }
}