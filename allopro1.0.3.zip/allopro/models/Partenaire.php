<?php
require_once __DIR__ . '/../config/database.php';

class Partenaire {
    private $conn;
    private $table = 'partenaires';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function findByEmail($email) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($nomEntreprise, $email, $motDePasse, $telephone, $zoneIntervention, $emailVerifie = true) {
        $hash = password_hash($motDePasse, PASSWORD_DEFAULT);
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table} (nom_entreprise, email, mot_de_passe, telephone, zone_intervention)
                VALUES (:nom, :email, :mot_de_passe, :telephone, :zone)"
            );
            $stmt->execute([':nom' => $nomEntreprise, ':email' => $email, ':mot_de_passe' => $hash, ':telephone' => $telephone, ':zone' => $zoneIntervention]);
            $id = (int) $this->conn->lastInsertId();

            $maj = $this->conn->prepare("UPDATE {$this->table} SET matricule = :matricule, email_verifie = :email_verifie WHERE id = :id");
            $maj->execute([
                ':matricule' => 'PA-' . str_pad($id, 5, '0', STR_PAD_LEFT),
                ':email_verifie' => $emailVerifie ? 1 : 0,
                ':id' => $id,
            ]);

            $this->conn->commit();
            return $id;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    public function definirCodeVerificationEmail($id, string $hash, string $expiration): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET email_verification_code_hash = :hash,
                 email_verification_expires_at = :expiration,
                 email_verification_sent_at = UTC_TIMESTAMP(),
                 email_verification_attempts = 0
             WHERE id = :id AND email_verifie = 0
               AND (email_verification_sent_at IS NULL
                    OR email_verification_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE))"
        );
        $stmt->execute([':hash' => $hash, ':expiration' => $expiration, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function confirmerEmailParCode(string $email, string $code): bool {
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT id, email_verification_code_hash
                 FROM {$this->table}
                 WHERE email = :email AND email_verifie = 0
                   AND email_verification_expires_at > UTC_TIMESTAMP()
                   AND email_verification_attempts < 5
                 LIMIT 1 FOR UPDATE"
            );
            $stmt->execute([':email' => $email]);
            $verification = $stmt->fetch();
            if (!$verification) {
                $this->conn->commit();
                return false;
            }

            if (!password_verify($code, (string) $verification['email_verification_code_hash'])) {
                $echec = $this->conn->prepare(
                    "UPDATE {$this->table}
                     SET email_verification_attempts = email_verification_attempts + 1
                     WHERE id = :id AND email_verification_attempts < 5"
                );
                $echec->execute([':id' => $verification['id']]);
                $this->conn->commit();
                return false;
            }

            $confirmation = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET email_verifie = 1,
                     email_verification_token_hash = NULL,
                     email_verification_code_hash = NULL,
                     email_verification_expires_at = NULL,
                     email_verification_sent_at = NULL,
                     email_verification_attempts = 0
                 WHERE id = :id AND email_verifie = 0"
            );
            $confirmation->execute([':id' => $verification['id']]);
            $confirme = $confirmation->rowCount() === 1;
            $this->conn->commit();
            return $confirme;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $e;
        }
    }

    public function confirmerEmailParJeton(string $hash): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET email_verifie = 1,
                 email_verification_token_hash = NULL,
                 email_verification_code_hash = NULL,
                 email_verification_expires_at = NULL,
                 email_verification_sent_at = NULL,
                 email_verification_attempts = 0
             WHERE email_verification_token_hash = :hash
               AND email_verification_expires_at > UTC_TIMESTAMP()
               AND email_verifie = 0"
        );
        $stmt->execute([':hash' => $hash]);
        return $stmt->rowCount() === 1;
    }

    public function creerJetonReinitialisation($id, string $hash, string $expiration): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = :hash,
                 reinitialisation_expires_at = :expiration,
                 reinitialisation_sent_at = UTC_TIMESTAMP()
             WHERE id = :id
               AND (reinitialisation_sent_at IS NULL
                    OR reinitialisation_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE))"
        );
        $stmt->execute([':hash' => $hash, ':expiration' => $expiration, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function annulerJetonReinitialisation($id, string $hash): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE id = :id AND reinitialisation_token_hash = :hash"
        );
        $stmt->execute([':id' => $id, ':hash' => $hash]);
    }

    public function telephoneReinitialisationBloque($id): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE id = :id AND reinitialisation_phone_blocked_until > UTC_TIMESTAMP()"
        );
        $stmt->execute([':id' => $id]);
        return (bool) $stmt->fetchColumn();
    }

    public function enregistrerEchecTelephoneReinitialisation($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_blocked_until = IF(
                     reinitialisation_phone_attempts + 1 >= 5,
                     DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE),
                     reinitialisation_phone_blocked_until
                 ),
                 reinitialisation_phone_attempts = LEAST(reinitialisation_phone_attempts + 1, 5)
             WHERE id = :id
               AND (reinitialisation_phone_blocked_until IS NULL
                    OR reinitialisation_phone_blocked_until <= UTC_TIMESTAMP())"
        );
        $stmt->execute([':id' => $id]);
    }

    public function reinitialiserTentativesTelephone($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_attempts = 0,
                 reinitialisation_phone_blocked_until = NULL
             WHERE id = :id"
        );
        $stmt->execute([':id' => $id]);
    }

    public function jetonReinitialisationValide(string $hash): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP() LIMIT 1"
        );
        $stmt->execute([':hash' => $hash]);
        return (bool) $stmt->fetchColumn();
    }

    public function reinitialiserMotDePasseParJeton(string $hash, string $nouveauMotDePasse): bool {
        $motDePasseHash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET mot_de_passe = :mot_de_passe,
                 reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP()"
        );
        $stmt->execute([':mot_de_passe' => $motDePasseHash, ':hash' => $hash]);
        return $stmt->rowCount() === 1;
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function mettreAJourProfil(int $id, string $nomEntreprise, string $telephone, string $zoneIntervention): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET nom_entreprise = :nom_entreprise,
                 telephone = :telephone,
                 zone_intervention = :zone_intervention
             WHERE id = :id"
        );
        return $stmt->execute([
            ':nom_entreprise' => $nomEntreprise,
            ':telephone' => $telephone,
            ':zone_intervention' => $zoneIntervention,
            ':id' => $id,
        ]);
    }

    public function mettreAJourPhotoProfil(int $id, string $chemin): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET photo_profil = :photo, avatar_initiales = 0
             WHERE id = :id"
        );
        return $stmt->execute([':photo' => $chemin, ':id' => $id]);
    }

    public function supprimerPhotoProfil(int $id): bool {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET photo_profil = NULL WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function definirAvatarInitiales(int $id, bool $initiales): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET avatar_initiales = :initiales WHERE id = :id"
        );
        return $stmt->execute([':initiales' => $initiales ? 1 : 0, ':id' => $id]);
    }

    public function changerMotDePasse(int $id, string $motDePasseActuel, string $nouveauMotDePasse): bool {
        $stmt = $this->conn->prepare("SELECT mot_de_passe FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $hashActuel = $stmt->fetchColumn();
        if (!is_string($hashActuel) || !password_verify($motDePasseActuel, $hashActuel)) {
            return false;
        }

        $hashNouveau = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $maj = $this->conn->prepare(
            "UPDATE {$this->table} SET mot_de_passe = :nouveau
             WHERE id = :id AND mot_de_passe = :actuel"
        );
        $maj->execute([':nouveau' => $hashNouveau, ':id' => $id, ':actuel' => $hashActuel]);
        return $maj->rowCount() === 1;
    }

    public function verifierMotDePasse(int $id, string $motDePasse): bool {
        $stmt = $this->conn->prepare("SELECT mot_de_passe FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $hash = $stmt->fetchColumn();
        return is_string($hash) && $hash !== '' && password_verify($motDePasse, $hash);
    }

    public function getAllActifs() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} WHERE statut = 'actif' ORDER BY nom_entreprise");
        return $stmt->fetchAll();
    }

    public function compterTechniciens($partenaireId) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM techniciens WHERE partenaire_id = :id AND statut <> 'corbeille'");
        $stmt->bindParam(':id', $partenaireId);
        $stmt->execute();
        return $stmt->fetch()['total'];
    }

    public function recalculerScore($partenaireId) {
        $stmt = $this->conn->prepare(
            "SELECT AVG(n.note) as moyenne 
            FROM notes n
            JOIN interventions i ON n.demande_id = i.demande_id
            WHERE i.partenaire_id = :partenaire_id"
        );
        $stmt->bindParam(':partenaire_id', $partenaireId);
        $stmt->execute();
        $moyenne = $stmt->fetch()['moyenne'];

        $stmt2 = $this->conn->prepare("UPDATE {$this->table} SET score = :score WHERE id = :id");
        return $stmt2->execute([':score' => round($moyenne, 2), ':id' => $partenaireId]);
    }

    public function mettreAJourNiveau($partenaireId) {
        $partenaire = $this->getById($partenaireId);
        $score = $partenaire['score'];

        if ($score >= 4.5) {
            $niveau = 'excellence';
        } elseif ($score >= 4.0) {
            $niveau = 'premium';
        } elseif ($score >= 3.0) {
            $niveau = 'certifie';
        } else {
            $niveau = 'partenaire';
        }

        $stmt = $this->conn->prepare("UPDATE {$this->table} SET niveau = :niveau WHERE id = :id");
        return $stmt->execute([':niveau' => $niveau, ':id' => $partenaireId]);
    }

    public function compterActifs() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE statut = 'actif'");
        return $stmt->fetch()['total'];
    }

    public function getAllAvecStats($recherche = null, $niveauFiltre = null) {
        $sql = "SELECT p.*,
                    (SELECT COUNT(*) FROM techniciens WHERE partenaire_id = p.id) AS nb_techniciens,
                    (SELECT COUNT(*) FROM interventions WHERE partenaire_id = p.id) AS nb_missions,
                    (SELECT COUNT(*) FROM interventions WHERE partenaire_id = p.id AND statut != 'terminee') AS nb_missions_actives
                FROM {$this->table} p WHERE 1=1";

        if ($recherche) {
            $sql .= " AND (p.nom_entreprise LIKE :recherche1 OR p.email LIKE :recherche2)";
        }
        if ($niveauFiltre) {
            $sql .= " AND p.niveau = :niveau";
        }
        $sql .= " ORDER BY p.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($recherche) {
            $terme = '%' . $recherche . '%';
            $stmt->bindParam(':recherche1', $terme);
            $stmt->bindParam(':recherche2', $terme);
        }
        if ($niveauFiltre) {
            $stmt->bindParam(':niveau', $niveauFiltre);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function changerStatutActivation($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function changerNiveauManuel($id, $niveau) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET niveau = :niveau WHERE id = :id");
        return $stmt->execute([':niveau' => $niveau, ':id' => $id]);
    }

    public function getMissionsRecentes($partenaireId, $limite = 8) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, d.numero_dossier, d.statut AS demande_statut, c.nom AS categorie_nom, t.nom AS technicien_nom
            FROM interventions i
            JOIN demandes d ON i.demande_id = d.id
            JOIN categories c ON d.categorie_id = c.id
            LEFT JOIN techniciens t ON i.technicien_id = t.id
            WHERE i.partenaire_id = :id
            ORDER BY i.id DESC LIMIT :limite"
        );
        $stmt->bindValue(':id', $partenaireId, PDO::PARAM_INT);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterMissionsParStatut($partenaireId): array {
        $stmt = $this->conn->prepare(
            "SELECT i.statut, COUNT(*) AS total
             FROM interventions i
             WHERE i.partenaire_id = :partenaire_id
             GROUP BY i.statut"
        );
        $stmt->execute([':partenaire_id' => $partenaireId]);
        $compteurs = [];
        foreach ($stmt->fetchAll() as $ligne) {
            $compteurs[$ligne['statut']] = (int) $ligne['total'];
        }
        return $compteurs;
    }

    public function compterMissionsFiltrees($partenaireId, ?string $statut = null, string $recherche = ''): int {
        [$where, $params] = $this->construireFiltresMissions($partenaireId, $statut, $recherche);
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*)
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN users u ON u.id = d.client_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             WHERE {$where}"
        );
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }

    public function getMissionsPartenaire($partenaireId, ?string $statut = null, string $recherche = '', int $limite = 30, int $offset = 0): array {
        [$where, $params] = $this->construireFiltresMissions($partenaireId, $statut, $recherche);
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.statut AS intervention_statut, i.date_debut, i.date_fin,
                    d.id AS demande_id, d.numero_dossier, d.description, d.urgence, d.statut AS demande_statut,
                    d.date_creation, u.nom AS client_nom, c.nom AS categorie_nom,
                    a.quartier, a.ville, t.nom AS technicien_nom
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN users u ON u.id = d.client_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             WHERE {$where}
             ORDER BY i.id DESC
             LIMIT :limite OFFSET :offset"
        );
        foreach ($params as $nom => $valeur) {
            $stmt->bindValue($nom, $valeur);
        }
        $stmt->bindValue(':limite', max(1, min(100, $limite)), PDO::PARAM_INT);
        $stmt->bindValue(':offset', max(0, $offset), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function construireFiltresMissions($partenaireId, ?string $statut, string $recherche): array {
        $where = 'i.partenaire_id = :partenaire_id';
        $params = [':partenaire_id' => $partenaireId];
        if ($statut !== null) {
            $where .= ' AND i.statut = :statut';
            $params[':statut'] = $statut;
        }
        if ($recherche !== '') {
            $where .= " AND (d.numero_dossier LIKE :recherche_dossier
                         OR u.nom LIKE :recherche_client
                         OR c.nom LIKE :recherche_categorie
                         OR t.nom LIKE :recherche_technicien
                         OR a.quartier LIKE :recherche_quartier
                         OR a.ville LIKE :recherche_ville)";
            $terme = '%' . $recherche . '%';
            $params[':recherche_dossier'] = $terme;
            $params[':recherche_client'] = $terme;
            $params[':recherche_categorie'] = $terme;
            $params[':recherche_technicien'] = $terme;
            $params[':recherche_quartier'] = $terme;
            $params[':recherche_ville'] = $terme;
        }
        return [$where, $params];
    }

    public function getReversementsDus() {
        require_once __DIR__ . '/Reversement.php';
        return (new Reversement())->getReversementsDus();
    }

}