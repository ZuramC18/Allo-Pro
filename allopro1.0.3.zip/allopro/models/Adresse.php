<?php
require_once __DIR__ . '/../config/database.php';

class Adresse {
    private $conn;
    private $table = 'adresses';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($userId, $libelle, $quartier, $ville, $details) {
        // 1. Une adresse supprimée avec le même quartier et la même ville existe-t-elle déjà ?
        $stmt = $this->conn->prepare(
            "SELECT id FROM {$this->table}
            WHERE user_id = :user_id
            AND quartier = :quartier
            AND ville = :ville
            AND supprimee = 1
            ORDER BY id DESC
            LIMIT 1"
        );
        $stmt->execute([
            ':user_id'  => $userId,
            ':quartier' => $quartier,
            ':ville'    => $ville
        ]);
        $existante = $stmt->fetch();

        // 2. Si oui, on la réactive (et on met à jour le libellé et les précisions saisis)
        if ($existante) {
            $stmt = $this->conn->prepare(
                "UPDATE {$this->table}
                SET supprimee = 0, libelle = :libelle, details = :details
                WHERE id = :id AND user_id = :user_id"
            );
            return $stmt->execute([
                ':libelle'  => $libelle,
                ':details'  => $details,
                ':id'       => $existante['id'],
                ':user_id'  => $userId
            ]);
        }

        // 3. Sinon, création normale
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (user_id, libelle, quartier, ville, details)
            VALUES (:user_id, :libelle, :quartier, :ville, :details)"
        );
        return $stmt->execute([
            ':user_id'  => $userId,
            ':libelle'  => $libelle,
            ':quartier' => $quartier,
            ':ville'    => $ville,
            ':details'  => $details
        ]);
    }

    public function getByUser($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM adresses WHERE user_id = ? AND supprimee = 0 ORDER BY id DESC");
        $stmt->execute([(int) $userId]);
        return $stmt->fetchAll();
    }

    public function supprimer($id, $userId): bool {
        $stmt = $this->conn->prepare("UPDATE adresses SET supprimee = 1 WHERE id = ? AND user_id = ?");
        $stmt->execute([(int) $id, (int) $userId]);
        return $stmt->rowCount() === 1;
    }
}