<?php
require_once __DIR__ . '/../config/database.php';

class Tache {
    private PDO $conn;
    private string $table = 'taches';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    private function colonneProprietaire(string $type): string {
        if ($type === 'technicien') {
            return 'technicien_id';
        }
        if ($type === 'partenaire') {
            return 'partenaire_id';
        }
        throw new InvalidArgumentException('Type de propriétaire de tâche invalide.');
    }

    public function creerPour(string $type, int $proprietaireId, string $titre, string $description, ?string $dateEcheance): bool {
        $colonne = $this->colonneProprietaire($type);
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} ({$colonne}, titre, description, date_echeance)
             VALUES (:proprietaire_id, :titre, :description, :date_echeance)"
        );
        return $stmt->execute([
            ':proprietaire_id' => $proprietaireId,
            ':titre' => $titre,
            ':description' => $description !== '' ? $description : null,
            ':date_echeance' => $dateEcheance,
        ]);
    }

    public function getByProprietaire(string $type, int $proprietaireId): array {
        $colonne = $this->colonneProprietaire($type);
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table}
             WHERE {$colonne} = :proprietaire_id
             ORDER BY (statut = 'a_faire') DESC, date_echeance IS NULL, date_echeance ASC, date_creation DESC"
        );
        $stmt->execute([':proprietaire_id' => $proprietaireId]);
        return $stmt->fetchAll();
    }

    public function getRappelsPour(string $type, int $proprietaireId): array {
        $colonne = $this->colonneProprietaire($type);
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table}
             WHERE {$colonne} = :proprietaire_id
               AND statut = 'a_faire'
               AND date_echeance IS NOT NULL
               AND DATE(date_echeance) <= CURDATE()
             ORDER BY date_echeance ASC"
        );
        $stmt->execute([':proprietaire_id' => $proprietaireId]);
        return $stmt->fetchAll();
    }

    public function changerStatutPour(string $type, int $proprietaireId, int $tacheId, string $statut): bool {
        if (!in_array($statut, ['a_faire', 'terminee'], true)) {
            throw new InvalidArgumentException('Statut de tâche invalide.');
        }
        $colonne = $this->colonneProprietaire($type);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = :statut
             WHERE id = :id AND {$colonne} = :proprietaire_id"
        );
        $stmt->execute([
            ':statut' => $statut,
            ':id' => $tacheId,
            ':proprietaire_id' => $proprietaireId,
        ]);
        return $stmt->rowCount() > 0;
    }

    public function supprimerPour(string $type, int $proprietaireId, int $tacheId): bool {
        $colonne = $this->colonneProprietaire($type);
        $stmt = $this->conn->prepare(
            "DELETE FROM {$this->table}
             WHERE id = :id AND {$colonne} = :proprietaire_id"
        );
        $stmt->execute([':id' => $tacheId, ':proprietaire_id' => $proprietaireId]);
        return $stmt->rowCount() > 0;
    }

    public function create($technicienId, $titre, $description, $dateEcheance): bool {
        return $this->creerPour('technicien', (int) $technicienId, (string) $titre, (string) $description, $dateEcheance ?: null);
    }

    public function getByTechnicien($technicienId): array {
        return $this->getByProprietaire('technicien', (int) $technicienId);
    }

    public function getRappels($technicienId): array {
        return $this->getRappelsPour('technicien', (int) $technicienId);
    }

    public function marquerTerminee($id, $technicienId): bool {
        return $this->changerStatutPour('technicien', (int) $technicienId, (int) $id, 'terminee');
    }

    public function supprimer($id, $technicienId): bool {
        return $this->supprimerPour('technicien', (int) $technicienId, (int) $id);
    }
}
