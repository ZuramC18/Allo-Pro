<?php
require_once __DIR__ . '/../config/database.php';

class ClotureIntervention {
    private $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function cloturer($demandeId, $rapport, $montantBrut): array {
        $rapport = trim((string) $rapport);
        if ($rapport === '') {
            return ['ok' => false, 'erreur' => "Le rapport d'intervention est obligatoire."];
        }

        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT d.*, c.parent_id AS categorie_parent_id
                 FROM demandes d
                 JOIN categories c ON c.id = d.categorie_id
                 WHERE d.id = :id
                 FOR UPDATE"
            );
            $stmt->execute([':id' => $demandeId]);
            $demande = $stmt->fetch();

            if (!$demande || !in_array($demande['statut'], ['attribuee', 'en_cours'], true)) {
                return $this->refuser("Cette demande ne peut plus être clôturée.");
            }

            $stmt = $this->conn->prepare(
                "SELECT id, statut FROM interventions WHERE demande_id = :demande_id FOR UPDATE"
            );
            $stmt->execute([':demande_id' => $demandeId]);
            $intervention = $stmt->fetch();
            if (!$intervention || $intervention['statut'] === 'terminee') {
                return $this->refuser("Cette intervention est déjà clôturée ou n'est pas disponible.");
            }

            $couverture = $this->trouverCouverture($demande);
            $montant = null;
            if ($couverture === null) {
                if (!is_numeric($montantBrut) || !is_finite((float) $montantBrut)
                    || (float) $montantBrut <= 0 || (float) $montantBrut > 99999999.99) {
                    return $this->refuser("Saisissez un montant supérieur à 0 lorsque l'intervention n'est pas couverte.");
                }
                $montant = (float) $montantBrut;
            } elseif (!$this->consommerCouverture($couverture, $demandeId)) {
                return $this->refuser("La couverture n'est plus disponible. Actualisez la page puis réessayez.");
            }

            $stmt = $this->conn->prepare(
                "UPDATE interventions
                 SET statut = 'terminee', rapport = :rapport, montant = :montant, date_fin = NOW()
                 WHERE id = :id AND statut <> 'terminee'"
            );
            $stmt->execute([
                ':rapport' => $rapport,
                ':montant' => $montant,
                ':id' => $intervention['id']
            ]);
            if ($stmt->rowCount() !== 1) {
                return $this->refuser("Cette intervention a déjà été clôturée.");
            }

            $modePaiement = $couverture['type'] ?? 'normal';
            $stmt = $this->conn->prepare(
                "UPDATE demandes
                 SET statut = 'terminee', mode_paiement = :mode,
                     abonnement_id = :abonnement_id, pass_achat_id = :pass_id
                 WHERE id = :id"
            );
            $stmt->execute([
                ':mode' => $modePaiement,
                ':abonnement_id' => ($modePaiement === 'abonnement') ? $couverture['id'] : null,
                ':pass_id' => ($modePaiement === 'pass') ? $couverture['id'] : null,
                ':id' => $demandeId
            ]);

            $this->conn->commit();
            return ['ok' => true, 'couverture' => $couverture, 'montant' => $montant];
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $e;
        }
    }

    private function trouverCouverture(array $demande): ?array {
        $categorieRacine = $demande['categorie_parent_id'] ?: $demande['categorie_id'];

        if ($demande['mode_paiement'] === 'abonnement' && !empty($demande['abonnement_id'])) {
            $abonnement = $this->getAbonnement((int) $demande['abonnement_id'], (int) $demande['client_id']);
            if ($abonnement && $this->abonnementCompatible((int) $abonnement['formule_id'], (int) $categorieRacine)) {
                return ['type' => 'abonnement', 'id' => (int) $abonnement['id']];
            }
        }

        if ($demande['mode_paiement'] === 'pass' && !empty($demande['pass_achat_id'])) {
            $pass = $this->getPass((int) $demande['pass_achat_id'], (int) $demande['client_id']);
            if ($pass && $this->passCompatible($pass, (int) $categorieRacine)) {
                return ['type' => 'pass', 'id' => (int) $pass['id']];
            }
        }

        $stmt = $this->conn->prepare(
            "SELECT ac.id, ac.formule_id
             FROM abonnements_clients ac
             WHERE ac.client_id = :client_id AND ac.statut = 'actif'
                 AND ac.date_fin >= CURDATE() AND ac.credits_restants > 0
             ORDER BY ac.id DESC
             FOR UPDATE"
        );
        $stmt->execute([':client_id' => $demande['client_id']]);
        foreach ($stmt->fetchAll() as $abonnement) {
            if ($this->abonnementCompatible((int) $abonnement['formule_id'], (int) $categorieRacine)) {
                return ['type' => 'abonnement', 'id' => (int) $abonnement['id']];
            }
        }

        $stmt = $this->conn->prepare(
            "SELECT pa.id, pt.categorie_id
             FROM pass_achats pa
             JOIN pass_types pt ON pt.id = pa.pass_type_id
             WHERE pa.client_id = :client_id AND pa.statut = 'disponible'
             ORDER BY pa.date_achat ASC
             FOR UPDATE"
        );
        $stmt->execute([':client_id' => $demande['client_id']]);
        foreach ($stmt->fetchAll() as $pass) {
            if ($this->passCompatible($pass, (int) $categorieRacine)) {
                return ['type' => 'pass', 'id' => (int) $pass['id']];
            }
        }

        return null;
    }

    private function getAbonnement(int $id, int $clientId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT id, formule_id
             FROM abonnements_clients
             WHERE id = :id AND client_id = :client_id AND statut = 'actif'
                 AND date_fin >= CURDATE() AND credits_restants > 0
             FOR UPDATE"
        );
        $stmt->execute([':id' => $id, ':client_id' => $clientId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    private function getPass(int $id, int $clientId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT pa.id, pt.categorie_id
             FROM pass_achats pa
             JOIN pass_types pt ON pt.id = pa.pass_type_id
             WHERE pa.id = :id AND pa.client_id = :client_id AND pa.statut = 'disponible'
             FOR UPDATE"
        );
        $stmt->execute([':id' => $id, ':client_id' => $clientId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    private function abonnementCompatible(int $formuleId, int $categorieRacine): bool {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.parent_id
             FROM formule_categories fc
             JOIN categories c ON c.id = fc.categorie_id
             WHERE fc.formule_id = :formule_id"
        );
        $stmt->execute([':formule_id' => $formuleId]);
        $categories = $stmt->fetchAll();
        if (!$categories) {
            return true;
        }
        foreach ($categories as $categorie) {
            if ((int) ($categorie['parent_id'] ?: $categorie['id']) === $categorieRacine) {
                return true;
            }
        }
        return false;
    }

    private function passCompatible(array $pass, int $categorieRacine): bool {
        if ($pass['categorie_id'] === null) {
            return true;
        }
        $stmt = $this->conn->prepare("SELECT id, parent_id FROM categories WHERE id = :id");
        $stmt->execute([':id' => $pass['categorie_id']]);
        $categorie = $stmt->fetch();
        return $categorie
            && (int) ($categorie['parent_id'] ?: $categorie['id']) === $categorieRacine;
    }

    private function consommerCouverture(array $couverture, int $demandeId): bool {
        if ($couverture['type'] === 'abonnement') {
            $stmt = $this->conn->prepare(
                "UPDATE abonnements_clients
                 SET credits_restants = credits_restants - 1
                 WHERE id = :id AND statut = 'actif' AND date_fin >= CURDATE() AND credits_restants > 0"
            );
            $stmt->execute([':id' => $couverture['id']]);
        } else {
            $stmt = $this->conn->prepare(
                "UPDATE pass_achats
                 SET statut = 'utilise', demande_id = :demande_id, date_utilisation = NOW()
                 WHERE id = :id AND statut = 'disponible'"
            );
            $stmt->execute([':demande_id' => $demandeId, ':id' => $couverture['id']]);
        }
        return $stmt->rowCount() === 1;
    }

    private function refuser(string $message): array {
        if ($this->conn->inTransaction()) {
            $this->conn->rollBack();
        }
        return ['ok' => false, 'erreur' => $message];
    }
}
