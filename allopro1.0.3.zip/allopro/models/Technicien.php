<?php
require_once __DIR__ . '/../config/database.php';

class Technicien {
    private $conn;
    private $table = 'techniciens';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function findByEmail($email) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($partenaireId, $nom, $email, $motDePasse, $telephone, $categorieId) {
        $hash = password_hash($motDePasse, PASSWORD_DEFAULT);
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table} (partenaire_id, nom, email, mot_de_passe, telephone, categorie_id)
                VALUES (:partenaire_id, :nom, :email, :mot_de_passe, :telephone, :categorie_id)"
            );
            $stmt->execute([':partenaire_id' => $partenaireId, ':nom' => $nom, ':email' => $email, ':mot_de_passe' => $hash, ':telephone' => $telephone, ':categorie_id' => $categorieId]);
            $id = (int) $this->conn->lastInsertId();

            $maj = $this->conn->prepare("UPDATE {$this->table} SET matricule = :matricule WHERE id = :id");
            $maj->execute([':matricule' => 'TE-' . str_pad($id, 5, '0', STR_PAD_LEFT), ':id' => $id]);

            $this->conn->commit();
            return $id;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    public function getByPartenaire($partenaireId) {
        $stmt = $this->conn->prepare(
            "SELECT t.*, c.nom AS categorie_nom 
            FROM {$this->table} t 
            LEFT JOIN categories c ON t.categorie_id = c.id
            WHERE t.partenaire_id = :id ORDER BY t.nom"
        );
        $stmt->bindParam(':id', $partenaireId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getEquipePartenaire(int $partenaireId, bool $corbeille = false): array {
        $statut = $corbeille ? 'corbeille' : null;
        $sql = "SELECT t.*, c.nom AS categorie_nom
                FROM {$this->table} t
                LEFT JOIN categories c ON c.id = t.categorie_id
                WHERE t.partenaire_id = :partenaire_id";
        if ($statut !== null) {
            $sql .= " AND t.statut = :statut";
        } else {
            $sql .= " AND t.statut IN ('actif', 'inactif')";
        }
        $sql .= " ORDER BY t.nom";
        $stmt = $this->conn->prepare($sql);
        $params = [':partenaire_id' => $partenaireId];
        if ($statut !== null) {
            $params[':statut'] = $statut;
        }
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getDetailsByIdEtPartenaire(int $technicienId, int $partenaireId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT t.id, t.nom, t.email, t.telephone, t.matricule, t.statut,
                    c.nom AS categorie_nom,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS nb_missions,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id
                       AND i.statut = 'terminee') AS nb_terminees,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id
                       AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')) AS nb_en_cours,
                    (SELECT AVG(n.note) FROM notes n
                     JOIN interventions i ON i.demande_id = n.demande_id
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS note_moyenne,
                    (SELECT COUNT(*) FROM notes n
                     JOIN interventions i ON i.demande_id = n.demande_id
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS nb_avis
             FROM {$this->table} t
             LEFT JOIN categories c ON c.id = t.categorie_id
             WHERE t.id = :technicien_id AND t.partenaire_id = :partenaire_id
             LIMIT 1"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->fetch();
    }

    public function getMissionsRecentesParTechnicien(int $technicienId, int $partenaireId, int $limite = 10): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id, i.statut, i.date_debut, i.date_fin,
                    d.numero_dossier, c.nom AS categorie_nom,
                    n.note, n.commentaire
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN notes n ON n.demande_id = d.id
             WHERE i.technicien_id = :technicien_id AND i.partenaire_id = :partenaire_id
             ORDER BY i.id DESC
             LIMIT :limite"
        );
        $stmt->bindValue(':technicien_id', $technicienId, PDO::PARAM_INT);
        $stmt->bindValue(':partenaire_id', $partenaireId, PDO::PARAM_INT);
        $stmt->bindValue(':limite', max(1, min(20, $limite)), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getActifsByPartenaire($partenaireId, $categorieId = null) {
        $sql = "SELECT t.*, c.nom AS categorie_nom FROM {$this->table} t
                LEFT JOIN categories c ON t.categorie_id = c.id
                WHERE t.partenaire_id = :id AND t.statut = 'actif'";

        if ($categorieId) {
            $sql .= " AND (t.categorie_id = :categorie_id OR c.parent_id = :categorie_id2)";
        }
        $sql .= " ORDER BY t.nom";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $partenaireId);
        if ($categorieId) {
            $stmt->bindParam(':categorie_id', $categorieId);
            $stmt->bindParam(':categorie_id2', $categorieId);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function updateProfil(int $id, string $prenom, string $nomFamille, string $telephone): bool {
        $nomComplet = trim($prenom . ' ' . $nomFamille);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET prenom = :prenom, nom_famille = :nom_famille, nom = :nom, telephone = :telephone
             WHERE id = :id"
        );
        return $stmt->execute([
            ':prenom' => $prenom,
            ':nom_famille' => $nomFamille,
            ':nom' => $nomComplet,
            ':telephone' => $telephone,
            ':id' => $id,
        ]);
    }

    public function updatePhotoProfil(int $id, ?string $chemin): bool {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET photo_profil = :photo WHERE id = :id");
        return $stmt->execute([':photo' => $chemin, ':id' => $id]);
    }

    public function definirAvatarInitiales(int $id, bool $afficherInitiales): bool {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET avatar_initiales = :initiales WHERE id = :id");
        return $stmt->execute([':initiales' => $afficherInitiales ? 1 : 0, ':id' => $id]);
    }

    public function updateMotDePasse($id, $nouveauMotDePasse) {
        $hash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET mot_de_passe = :mot_de_passe WHERE id = :id");
        return $stmt->execute([':mot_de_passe' => $hash, ':id' => $id]);
    }

    public function reinitialiserMotDePasseParPartenaire(int $technicienId, int $partenaireId, string $nouveauMotDePasse): bool {
        $hash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET mot_de_passe = :mot_de_passe,
                 reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE id = :technicien_id
               AND partenaire_id = :partenaire_id
               AND statut IN ('actif', 'inactif')"
        );
        $stmt->execute([
            ':mot_de_passe' => $hash,
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function creerJetonReinitialisation($id, string $hash, string $expiration): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = :hash,
                 reinitialisation_expires_at = :expiration,
                 reinitialisation_sent_at = UTC_TIMESTAMP()
             WHERE id = :id
               AND (reinitialisation_sent_at IS NULL
                    OR reinitialisation_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE))"
        );
        $stmt->execute([':hash' => $hash, ':expiration' => $expiration, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function annulerJetonReinitialisation($id, string $hash): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE id = :id AND reinitialisation_token_hash = :hash"
        );
        $stmt->execute([':id' => $id, ':hash' => $hash]);
    }

    public function telephoneReinitialisationBloque($id): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE id = :id AND reinitialisation_phone_blocked_until > UTC_TIMESTAMP()"
        );
        $stmt->execute([':id' => $id]);
        return (bool) $stmt->fetchColumn();
    }

    public function enregistrerEchecTelephoneReinitialisation($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_blocked_until = IF(
                     reinitialisation_phone_attempts + 1 >= 5,
                     DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE),
                     reinitialisation_phone_blocked_until
                 ),
                 reinitialisation_phone_attempts = LEAST(reinitialisation_phone_attempts + 1, 5)
             WHERE id = :id
               AND (reinitialisation_phone_blocked_until IS NULL
                    OR reinitialisation_phone_blocked_until <= UTC_TIMESTAMP())"
        );
        $stmt->execute([':id' => $id]);
    }

    public function reinitialiserTentativesTelephone($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_attempts = 0,
                 reinitialisation_phone_blocked_until = NULL
             WHERE id = :id"
        );
        $stmt->execute([':id' => $id]);
    }

    public function jetonReinitialisationValide(string $hash): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP() LIMIT 1"
        );
        $stmt->execute([':hash' => $hash]);
        return (bool) $stmt->fetchColumn();
    }

    public function reinitialiserMotDePasseParJeton(string $hash, string $nouveauMotDePasse): bool {
        $motDePasseHash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET mot_de_passe = :mot_de_passe,
                 reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP()"
        );
        $stmt->execute([':mot_de_passe' => $motDePasseHash, ':hash' => $hash]);
        return $stmt->rowCount() === 1;
    }

    public function getAllAvecStats($recherche = null, $partenaireId = null, $categorieId = null, $statut = null) {
        $sql = "SELECT t.*, p.nom_entreprise, c.nom AS metier,
                    (SELECT COUNT(*) FROM interventions WHERE technicien_id = t.id) AS nb_missions,
                    (SELECT COUNT(*) FROM interventions WHERE technicien_id = t.id AND statut != 'terminee') AS nb_actives,
                    (SELECT AVG(n.note) FROM notes n JOIN interventions i ON i.demande_id = n.demande_id WHERE i.technicien_id = t.id) AS note_moyenne
                FROM {$this->table} t
                JOIN partenaires p ON t.partenaire_id = p.id
                LEFT JOIN categories c ON t.categorie_id = c.id
                WHERE 1=1";
        $params = [];

        if ($recherche) {
            $sql .= " AND (t.nom LIKE :recherche1 OR t.email LIKE :recherche2 OR t.telephone LIKE :recherche3)";
            $terme = '%' . $recherche . '%';
            $params[':recherche1'] = $terme;
            $params[':recherche2'] = $terme;
            $params[':recherche3'] = $terme;
        }
        if ($partenaireId) {
            $sql .= " AND t.partenaire_id = :partenaire_id";
            $params[':partenaire_id'] = $partenaireId;
        }
        if ($categorieId) {
            $sql .= " AND t.categorie_id = :categorie_id";
            $params[':categorie_id'] = $categorieId;
        }
        if ($statut) {
            $sql .= " AND t.statut = :statut";
            $params[':statut'] = $statut;
        }
        $sql .= " ORDER BY p.nom_entreprise, t.nom";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function changerStatut($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function changerStatutParPartenaire(int $technicienId, int $partenaireId, string $statut): bool {
        if (!in_array($statut, ['actif', 'inactif'], true)) {
            return false;
        }
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = :statut
             WHERE id = :technicien_id AND partenaire_id = :partenaire_id
               AND statut IN ('actif', 'inactif')"
        );
        $stmt->execute([
            ':statut' => $statut,
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function mettreEnCorbeille(int $technicienId, int $partenaireId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = 'corbeille'
             WHERE id = :technicien_id AND partenaire_id = :partenaire_id
               AND statut IN ('actif', 'inactif')
               AND NOT EXISTS (
                   SELECT 1 FROM interventions i
                   WHERE i.technicien_id = {$this->table}.id
                     AND i.partenaire_id = {$this->table}.partenaire_id
                     AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
               )"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function restaurerDeLaCorbeille(int $technicienId, int $partenaireId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = 'inactif'
             WHERE id = :technicien_id AND partenaire_id = :partenaire_id
               AND statut = 'corbeille'"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function compterGlobal() {
        $stmt = $this->conn->query(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(statut = 'actif'), 0) AS actifs,
                    (SELECT COUNT(DISTINCT technicien_id) FROM interventions WHERE statut != 'terminee' AND technicien_id IS NOT NULL) AS en_mission
            FROM {$this->table}"
        );
        return $stmt->fetch();
    }

}