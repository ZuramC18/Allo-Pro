<?php
require_once __DIR__ . '/../config/database.php';

class Parametre {
    private const VALEURS_DEFAUT = [
        'taux_commission' => '20',
        'taux_commission_pass' => '10',
        'taux_commission_abonnement' => '10',
        'attribution_automatique' => '1',
        'limite_clients_par_conseiller' => '0',
    ];

    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function get($cle, $defaut = null) {
        $stmt = $this->conn->prepare("SELECT valeur FROM parametres WHERE cle = :cle");
        $stmt->bindParam(':cle', $cle);
        $stmt->execute();
        $resultat = $stmt->fetch();
        return $resultat ? $resultat['valeur'] : $defaut;
    }

    public function set($cle, $valeur) {
        $stmt = $this->conn->prepare(
            "INSERT INTO parametres (cle, valeur) VALUES (:cle, :valeur)
             ON DUPLICATE KEY UPDATE valeur = VALUES(valeur)"
        );
        return $stmt->execute([':valeur' => $valeur, ':cle' => $cle]);
    }

    public function getAll() {
        $parametres = self::VALEURS_DEFAUT;
        foreach ($this->conn->query("SELECT cle, valeur FROM parametres")->fetchAll() as $ligne) {
            $parametres[$ligne['cle']] = $ligne['valeur'];
        }
        return $parametres;
    }

    public function setMultiple(array $parametres) {
        $clesAutorisees = array_intersect_key($parametres, self::VALEURS_DEFAUT);
        if (count($clesAutorisees) !== count($parametres)) return false;

        $this->conn->beginTransaction();
        try {
            foreach ($clesAutorisees as $cle => $valeur) {
                $this->set($cle, (string) $valeur);
            }
            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            throw $e;
        }
    }

    public function attributionAutomatiqueActive() {
        return $this->get('attribution_automatique', self::VALEURS_DEFAUT['attribution_automatique']) === '1';
    }

    public function getLimiteClientsParConseiller() {
        return max(0, (int) $this->get('limite_clients_par_conseiller', self::VALEURS_DEFAUT['limite_clients_par_conseiller']));
    }

    public function getTauxCommission() {
        return (float) $this->get('taux_commission', self::VALEURS_DEFAUT['taux_commission']);
    }

    public function getTauxCommissionPass() {
        return (float) $this->get('taux_commission_pass', self::VALEURS_DEFAUT['taux_commission_pass']);
    }

    public function getTauxCommissionAbonnement() {
        return (float) $this->get('taux_commission_abonnement', self::VALEURS_DEFAUT['taux_commission_abonnement']);
    }
}