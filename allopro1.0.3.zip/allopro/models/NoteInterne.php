<?php
require_once __DIR__ . '/../config/database.php';

class NoteInterne {
    private $conn;
    private $table = 'notes_internes_client';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($clientId, $conseillerId, $contenu) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (client_id, conseiller_id, contenu) VALUES (:client_id, :conseiller_id, :contenu)"
        );
        return $stmt->execute([':client_id' => $clientId, ':conseiller_id' => $conseillerId, ':contenu' => $contenu]);
    }

    public function getByClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT n.*, u.nom AS conseiller_nom 
             FROM {$this->table} n
             JOIN users u ON n.conseiller_id = u.id
             WHERE n.client_id = :client_id
             ORDER BY n.date_creation DESC"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}