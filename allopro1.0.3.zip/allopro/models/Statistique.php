<?php
require_once __DIR__ . '/../config/database.php';

class Statistique {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Chaque requête utilise :debut et :fin exactement une fois (règle PDO en mode requêtes préparées réelles)
    private function scalaire($sql, $debut, $fin) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':debut' => $debut, ':fin' => $fin]);
        return $stmt->fetch()['valeur'];
    }

    private function lignes($sql, $debut, $fin) {
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':debut' => $debut, ':fin' => $fin]);
        return $stmt->fetchAll();
    }

    // ===== Indicateurs =====
    public function compterDemandes($debut, $fin) {
        return (int) $this->scalaire("SELECT COUNT(*) AS valeur FROM demandes WHERE date_creation >= :debut AND date_creation < :fin", $debut, $fin);
    }

    public function compterUrgentes($debut, $fin) {
        return (int) $this->scalaire("SELECT COUNT(*) AS valeur FROM demandes WHERE urgence = 'urgente' AND date_creation >= :debut AND date_creation < :fin", $debut, $fin);
    }

    public function compterTerminees($debut, $fin) {
        return (int) $this->scalaire("SELECT COUNT(*) AS valeur FROM demandes WHERE statut = 'terminee' AND date_creation >= :debut AND date_creation < :fin", $debut, $fin);
    }

    public function caEncaisse($debut, $fin) {
        return (float) $this->scalaire("SELECT COALESCE(SUM(montant),0) AS valeur FROM paiements WHERE statut = 'valide' AND date_paiement >= :debut AND date_paiement < :fin", $debut, $fin);
    }

    public function margeRealisee($debut, $fin) {
        return (float) $this->scalaire(
            "SELECT COALESCE(SUM(rd.marge_allopro),0) AS valeur
             FROM reversements_details rd
             JOIN reversements r ON rd.reversement_id = r.id
             WHERE r.periode_fin >= :debut AND r.periode_fin < :fin", $debut, $fin);
    }

    public function noteMoyenne($debut, $fin) {
        $valeur = $this->scalaire("SELECT AVG(note) AS valeur FROM notes WHERE date_creation >= :debut AND date_creation < :fin", $debut, $fin);
        return $valeur !== null ? (float) $valeur : null;
    }

    public function compterNotes($debut, $fin) {
        return (int) $this->scalaire("SELECT COUNT(*) AS valeur FROM notes WHERE date_creation >= :debut AND date_creation < :fin", $debut, $fin);
    }

    public function compterSav($debut, $fin) {
        return (int) $this->scalaire("SELECT COUNT(*) AS valeur FROM tickets_sav WHERE date_creation >= :debut AND date_creation < :fin", $debut, $fin);
    }

    public function dureeMoyenneMinutes($debut, $fin) {
        $valeur = $this->scalaire(
            "SELECT AVG(TIMESTAMPDIFF(MINUTE, date_debut, date_fin)) AS valeur
             FROM interventions
             WHERE statut = 'terminee' AND date_debut IS NOT NULL AND date_fin >= :debut AND date_fin < :fin", $debut, $fin);
        return $valeur !== null ? (float) $valeur : null;
    }

    // ===== Séries temporelles (clé = jour ou mois) =====
    public function serieDemandes($debut, $fin, $parMois) {
        $format = $parMois ? "DATE_FORMAT(date_creation, '%Y-%m')" : "DATE(date_creation)";
        $lignes = $this->lignes("SELECT {$format} AS periode, COUNT(*) AS total FROM demandes WHERE date_creation >= :debut AND date_creation < :fin GROUP BY periode", $debut, $fin);
        return array_column($lignes, 'total', 'periode');
    }

    public function serieCA($debut, $fin, $parMois) {
        $format = $parMois ? "DATE_FORMAT(date_paiement, '%Y-%m')" : "DATE(date_paiement)";
        $lignes = $this->lignes("SELECT {$format} AS periode, SUM(montant) AS total FROM paiements WHERE statut = 'valide' AND date_paiement >= :debut AND date_paiement < :fin GROUP BY periode", $debut, $fin);
        return array_column($lignes, 'total', 'periode');
    }

    // ===== Répartitions =====
    public function repartitionPoles($debut, $fin) {
        return $this->lignes(
            "SELECT COALESCE(p.nom, c.nom) AS pole, COUNT(*) AS total
             FROM demandes d
             JOIN categories c ON d.categorie_id = c.id
             LEFT JOIN categories p ON c.parent_id = p.id
             WHERE d.date_creation >= :debut AND d.date_creation < :fin
             GROUP BY COALESCE(p.nom, c.nom)
             ORDER BY total DESC", $debut, $fin);
    }

    public function repartitionStatuts($debut, $fin) {
        return $this->lignes("SELECT statut, COUNT(*) AS total FROM demandes WHERE date_creation >= :debut AND date_creation < :fin GROUP BY statut", $debut, $fin);
    }

    public function repartitionNotes($debut, $fin) {
        $lignes = $this->lignes("SELECT note, COUNT(*) AS total FROM notes WHERE date_creation >= :debut AND date_creation < :fin GROUP BY note", $debut, $fin);
        return array_column($lignes, 'total', 'note');
    }

    // ===== Classements =====
    public function topQuartiers($debut, $fin, $limite = 6) {
        $limite = (int) $limite;
        return $this->lignes(
            "SELECT a.quartier, COUNT(*) AS total
             FROM demandes d
             JOIN adresses a ON d.adresse_id = a.id
             WHERE d.date_creation >= :debut AND d.date_creation < :fin
             GROUP BY a.quartier
             ORDER BY total DESC LIMIT {$limite}", $debut, $fin);
    }

    public function topPartenaires($debut, $fin, $limite = 6) {
        $limite = (int) $limite;
        return $this->lignes(
            "SELECT p.id, p.nom_entreprise, p.score, p.niveau,
                    COUNT(DISTINCT i.id) AS missions,
                    COALESCE(SUM(pay.montant), 0) AS ca
             FROM partenaires p
             JOIN interventions i ON i.partenaire_id = p.id
             JOIN demandes d ON i.demande_id = d.id
             LEFT JOIN paiements pay ON pay.demande_id = d.id AND pay.statut = 'valide'
             WHERE d.date_creation >= :debut AND d.date_creation < :fin
             GROUP BY p.id, p.nom_entreprise, p.score, p.niveau
             ORDER BY missions DESC LIMIT {$limite}", $debut, $fin);
    }
}