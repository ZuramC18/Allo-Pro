<?php
require_once __DIR__ . '/../config/database.php';

class Categorie {
    private $conn;
    private $table = 'categories';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getParentes() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} WHERE parent_id IS NULL ORDER BY nom");
        return $stmt->fetchAll();
    }

    public function getSousCategories($parentId = null) {
        $sql = "SELECT c.*, p.nom AS parent_nom FROM {$this->table} c LEFT JOIN {$this->table} p ON c.parent_id = p.id WHERE c.parent_id IS NOT NULL";
        if ($parentId) $sql .= " AND c.parent_id = :parent_id";
        $sql .= " ORDER BY p.nom, c.nom";

        $stmt = $this->conn->prepare($sql);
        if ($parentId) $stmt->bindParam(':parent_id', $parentId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function create($nom, $parentId, $tarifBase = null) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (nom, parent_id, tarif_base) VALUES (:nom, :parent_id, :tarif)");
        return $stmt->execute([':nom' => $nom, ':parent_id' => $parentId ?: null, ':tarif' => $tarifBase ?: null]);
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function update($id, $nom, $tarifBase) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET nom = :nom, tarif_base = :tarif WHERE id = :id");
        return $stmt->execute([':nom' => $nom, ':tarif' => $tarifBase ?: null, ':id' => $id]);
    }

    public function changerStatut($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function compterDemandes($categorieId) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM demandes WHERE categorie_id = :id");
        $stmt->bindParam(':id', $categorieId);
        $stmt->execute();
        return $stmt->fetch()['total'];
    }
}