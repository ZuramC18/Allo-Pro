<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Reversement.php';

class LivreComptes {
    private $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    private function journalSql(): string {
        return "SELECT date_operation, categorie, libelle, tiers, reference, montant_credit, montant_debit
                FROM (
                    SELECT pay.date_paiement AS date_operation,
                           'paiement' AS categorie,
                           CONCAT('Paiement de service · ', d.numero_dossier) AS libelle,
                           COALESCE(NULLIF(TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))), ''), u.nom, 'Client') AS tiers,
                           pay.reference_transaction AS reference,
                           pay.montant AS montant_credit,
                           0 AS montant_debit
                    FROM paiements pay
                    JOIN demandes d ON d.id = pay.demande_id
                    LEFT JOIN users u ON u.id = d.client_id
                    WHERE pay.statut = 'valide'

                    UNION ALL

                    SELECT pa.date_achat AS date_operation,
                           'pass' AS categorie,
                           CONCAT('Achat Pass · ', pt.nom) AS libelle,
                           COALESCE(NULLIF(TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))), ''), u.nom, 'Client') AS tiers,
                           pa.reference_transaction AS reference,
                           COALESCE(pa.montant_achat, pt.prix) AS montant_credit,
                           0 AS montant_debit
                    FROM pass_achats pa
                    JOIN pass_types pt ON pt.id = pa.pass_type_id
                    LEFT JOIN users u ON u.id = pa.client_id
                    WHERE pa.statut IN ('disponible', 'utilise', 'expire')

                    UNION ALL

                    SELECT ac.date_creation AS date_operation,
                           'abonnement' AS categorie,
                           CONCAT('Achat abonnement · ', f.nom) AS libelle,
                           COALESCE(NULLIF(TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))), ''), u.nom, 'Client') AS tiers,
                           ac.reference_transaction AS reference,
                           COALESCE(ac.montant_achat, f.prix) AS montant_credit,
                           0 AS montant_debit
                    FROM abonnements_clients ac
                    JOIN formules_abonnement f ON f.id = ac.formule_id
                    LEFT JOIN users u ON u.id = ac.client_id
                    WHERE ac.statut IN ('actif', 'expire', 'resilie')

                    UNION ALL

                    SELECT r.date_paiement AS date_operation,
                           'reversement' AS categorie,
                           CONCAT('Reversement partenaire · ', p.nom_entreprise) AS libelle,
                           p.nom_entreprise AS tiers,
                           CONCAT('REV-', r.id) AS reference,
                           0 AS montant_credit,
                           r.montant_du AS montant_debit
                    FROM reversements r
                    JOIN partenaires p ON p.id = r.partenaire_id
                    WHERE r.statut = 'paye' AND r.date_paiement IS NOT NULL
                ) journal";
    }

    public function getEcritures(string $debut, string $fin, string $categorie = 'toutes'): array {
        $sql = $this->journalSql() . ' WHERE date_operation >= :debut AND date_operation < DATE_ADD(:fin, INTERVAL 1 DAY)';
        $params = [':debut' => $debut, ':fin' => $fin];

        if (in_array($categorie, ['paiement', 'pass', 'abonnement', 'reversement'], true)) {
            $sql .= ' AND categorie = :categorie';
            $params[':categorie'] = $categorie;
        }

        $sql .= ' ORDER BY date_operation ASC, montant_credit DESC, categorie ASC, reference ASC';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getTotauxAvant(string $dateExclusive): array {
        $stmt = $this->conn->prepare(
            'SELECT COALESCE(SUM(montant_credit), 0) AS credits,
                    COALESCE(SUM(montant_debit), 0) AS debits
             FROM (' . $this->journalSql() . ') journal
             WHERE date_operation < :date_exclusive'
        );
        $stmt->execute([':date_exclusive' => $dateExclusive]);
        $totaux = $stmt->fetch();
        return ['credits' => (float) $totaux['credits'], 'debits' => (float) $totaux['debits']];
    }

    public function getSynthesePartenaires(): array {
        $stmt = $this->conn->query(
            "SELECT COALESCE(SUM(montant_du), 0)
             FROM reversements
             WHERE statut = 'en_attente'"
        );
        $reversementsEnAttente = (float) $stmt->fetchColumn();

        $reversementModel = new Reversement();
        $missionsDues = $reversementModel->getReversementsDus();
        $netNonBatch = array_sum(array_column($missionsDues, 'montant_du'));
        $commissionNonBatch = array_sum(array_map(
            static fn($partenaire) => (float) $partenaire['montant_brut'] - (float) $partenaire['montant_du'],
            $missionsDues
        ));

        $stmt = $this->conn->query('SELECT COALESCE(SUM(marge_allopro), 0) FROM reversements_details');
        $commissionsReversementsCrees = (float) $stmt->fetchColumn();

        return [
            'reversements_en_attente' => $reversementsEnAttente,
            'interventions_a_reversement' => (float) $netNonBatch,
            'a_reverser' => $reversementsEnAttente + $netNonBatch,
            'commissions_calculees' => $commissionsReversementsCrees + $commissionNonBatch,
        ];
    }
}
