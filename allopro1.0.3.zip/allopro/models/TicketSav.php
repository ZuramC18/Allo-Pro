<?php
require_once __DIR__ . '/../config/database.php';

class TicketSav {
    private $conn;
    private $table = 'tickets_sav';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (demande_id, statut) VALUES (:demande_id, 'ouvert')"
        );
        return $stmt->execute([':demande_id' => $demandeId]);
    }

    public function getAll($statutFiltre = null) {
        $sql = "SELECT t.*, d.numero_dossier, u.nom AS client_nom, u.telephone AS client_telephone, n.note, n.commentaire
                FROM {$this->table} t
                JOIN demandes d ON t.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                LEFT JOIN notes n ON n.demande_id = d.id";
        if ($statutFiltre) {
            $sql .= " WHERE t.statut = :statut";
        }
        $sql .= " ORDER BY t.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) {
            $stmt->bindParam(':statut', $statutFiltre);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare(
            "SELECT t.*, d.numero_dossier, d.description, u.nom AS client_nom, u.telephone AS client_telephone, n.note, n.commentaire
             FROM {$this->table} t
             JOIN demandes d ON t.demande_id = d.id
             JOIN users u ON d.client_id = u.id
             LEFT JOIN notes n ON n.demande_id = d.id
             WHERE t.id = :id"
        );
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function mettreAJour($id, $statut, $commentaire) {
        $dateResolution = $statut === 'resolu' ? ', date_resolution = NOW()' : '';
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET statut = :statut, commentaire_conseiller = :commentaire {$dateResolution} WHERE id = :id"
        );
        return $stmt->execute([':statut' => $statut, ':commentaire' => $commentaire, ':id' => $id]);
    }

    public function compterOuverts() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE statut != 'resolu'");
        return $stmt->fetch()['total'];
    }

    public function getAllAvecFiltres($statutFiltre = null) {
        $sql = "SELECT t.*, d.numero_dossier, d.id AS demande_id, u.nom AS client_nom, u.telephone AS client_telephone,
                    n.note, n.commentaire, p.nom_entreprise
                FROM {$this->table} t
                JOIN demandes d ON t.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                LEFT JOIN notes n ON n.demande_id = d.id
                LEFT JOIN interventions i ON i.demande_id = d.id
                LEFT JOIN partenaires p ON i.partenaire_id = p.id";

        if ($statutFiltre) {
            $sql .= " WHERE t.statut = :statut";
        }
        $sql .= " ORDER BY FIELD(t.statut, 'ouvert','en_cours','resolu'), t.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) {
            $stmt->bindParam(':statut', $statutFiltre);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterParStatut() {
        $stmt = $this->conn->query("SELECT statut, COUNT(*) as total FROM {$this->table} GROUP BY statut");
        $resultats = $stmt->fetchAll();
        $compteurs = ['ouvert' => 0, 'en_cours' => 0, 'resolu' => 0];
        foreach ($resultats as $r) { $compteurs[$r['statut']] = (int) $r['total']; }
        return $compteurs;
    }

    public function tempsMoyenResolutionHeures() {
        $stmt = $this->conn->query(
            "SELECT AVG(TIMESTAMPDIFF(HOUR, date_creation, date_resolution)) as moyenne 
            FROM {$this->table} WHERE statut = 'resolu' AND date_resolution IS NOT NULL"
        );
        return $stmt->fetch()['moyenne'];
    }

}