<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Parametre.php';

class Reversement {
    private $conn;
    private $table = 'reversements';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    private function missionsDuesSql(): string {
        return "SELECT d.id AS demande_id, d.numero_dossier, i.partenaire_id, d.mode_paiement,
                    CASE d.mode_paiement
                        WHEN 'pass' THEN COALESCE(pa.montant_achat, pt.prix)
                        WHEN 'abonnement' THEN ROUND(
                            COALESCE(ac.montant_achat, f.prix)
                            / NULLIF(COALESCE(ac.credits_inclus, f.nombre_credits), 0),
                            2
                        )
                        ELSE pay.montant
                    END AS montant,
                    CASE d.mode_paiement
                        WHEN 'pass' THEN pa.date_achat
                        WHEN 'abonnement' THEN ac.date_creation
                        ELSE pay.date_paiement
                    END AS date_paiement
             FROM demandes d
             JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN (
                 SELECT demande_id, SUM(montant) AS montant, MAX(date_paiement) AS date_paiement
                 FROM paiements WHERE statut = 'valide' GROUP BY demande_id
             ) pay ON pay.demande_id = d.id
             LEFT JOIN pass_achats pa ON pa.id = d.pass_achat_id AND pa.statut = 'utilise'
             LEFT JOIN pass_types pt ON pt.id = pa.pass_type_id
             LEFT JOIN abonnements_clients ac ON ac.id = d.abonnement_id
             LEFT JOIN formules_abonnement f ON f.id = ac.formule_id
             WHERE d.statut = 'terminee'
               AND i.statut = 'terminee'
               AND i.partenaire_id IS NOT NULL
               AND (
                    (d.mode_paiement = 'normal' AND pay.montant > 0)
                    OR                     (d.mode_paiement = 'pass' AND pa.id IS NOT NULL AND COALESCE(pa.montant_achat, pt.prix) > 0)
                    OR (d.mode_paiement = 'abonnement' AND ac.id IS NOT NULL
                        AND COALESCE(ac.credits_inclus, f.nombre_credits) > 0
                        AND COALESCE(ac.montant_achat, f.prix) > 0)
               )
               AND NOT EXISTS (
                    SELECT 1 FROM reversements_details rd
                    WHERE rd.demande_id = d.id
               )";
    }

    public function getMissionsDuesParPartenaire($partenaireId) {
        $stmt = $this->conn->prepare(
            $this->missionsDuesSql() . ' AND i.partenaire_id = :partenaire_id ORDER BY date_paiement ASC, demande_id ASC'
        );
        $stmt->execute([':partenaire_id' => $partenaireId]);
        $missions = $stmt->fetchAll();
        $parametres = new Parametre();
        $tauxPass = $parametres->getTauxCommissionPass();
        $tauxAbonnement = $parametres->getTauxCommissionAbonnement();
        $tauxNormal = $parametres->getTauxCommission();
        foreach ($missions as &$mission) {
            $taux = $mission['mode_paiement'] === 'pass'
                ? $tauxPass
                : ($mission['mode_paiement'] === 'abonnement'
                    ? $tauxAbonnement
                    : $tauxNormal);
            $mission['taux_commission'] = $taux;
            $mission['marge_allopro'] = round((float) $mission['montant'] * $taux / 100, 2);
            $mission['montant_partenaire'] = (float) $mission['montant'] - $mission['marge_allopro'];
        }
        unset($mission);
        return $missions;
    }

    public function getReversementsDus() {
        $parametres = new Parametre();
        $tauxPass = $parametres->getTauxCommissionPass();
        $tauxAbonnement = $parametres->getTauxCommissionAbonnement();
        $tauxNormal = $parametres->getTauxCommission();
        $stmt = $this->conn->prepare(
            "SELECT p.id, p.nom_entreprise, COUNT(d.demande_id) AS nb_missions,
                    COALESCE(SUM(d.montant), 0) AS montant_brut,
                    COALESCE(SUM(ROUND(d.montant * (
                        1 - CASE d.mode_paiement
                            WHEN 'pass' THEN :taux_pass
                            WHEN 'abonnement' THEN :taux_abonnement
                            ELSE :taux_normal
                        END / 100
                    ), 2)), 0) AS montant_du
             FROM (" . $this->missionsDuesSql() . ") d
             JOIN partenaires p ON p.id = d.partenaire_id
             GROUP BY p.id, p.nom_entreprise
             HAVING montant_du > 0
             ORDER BY montant_du DESC"
        );
        $stmt->execute([
            ':taux_pass' => $tauxPass,
            ':taux_abonnement' => $tauxAbonnement,
            ':taux_normal' => $tauxNormal,
        ]);
        return $stmt->fetchAll();
    }

    public function create($partenaireId, $missions) {
        if (!$missions) {
            throw new InvalidArgumentException('Aucune intervention à reverser.');
        }

        $montantTotalPartenaire = 0;
        $dates = array_column($missions, 'date_paiement');
        $dates = array_values(array_filter($dates));
        if (!$dates) {
            throw new InvalidArgumentException('Les interventions à reverser doivent avoir une date de paiement ou d’achat.');
        }
        $periodeDebut = min($dates);
        $periodeFin = max($dates);

        $this->conn->beginTransaction();
        try {
            $verrou = $this->conn->prepare(
                "SELECT d.id FROM demandes d
                 JOIN interventions i ON i.demande_id = d.id
                 WHERE d.id = :id AND i.partenaire_id = :partenaire_id
                   AND d.statut = 'terminee' AND i.statut = 'terminee'
                 FOR UPDATE"
            );
            $dejaReverse = $this->conn->prepare('SELECT 1 FROM reversements_details WHERE demande_id = :id LIMIT 1');
            $demandesVues = [];
            foreach ($missions as $mission) {
                $demandeId = (int) $mission['demande_id'];
                if (isset($demandesVues[$demandeId])) {
                    throw new RuntimeException('Une intervention est présente plusieurs fois dans ce reversement.');
                }
                $demandesVues[$demandeId] = true;
                $verrou->execute([':id' => $demandeId, ':partenaire_id' => $partenaireId]);
                if (!$verrou->fetchColumn()) {
                    throw new RuntimeException('Une intervention a changé de statut ou de partenaire. Actualisez la page.');
                }
                $dejaReverse->execute([':id' => $demandeId]);
                if ($dejaReverse->fetchColumn()) {
                    throw new RuntimeException('Une intervention sélectionnée a déjà été intégrée à un reversement. Actualisez la page.');
                }
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table} (partenaire_id, periode_debut, periode_fin, montant_du, statut)
                 VALUES (:partenaire_id, :debut, :fin, 0, 'en_attente')"
            );
            $stmt->execute([
                ':partenaire_id' => $partenaireId,
                ':debut' => date('Y-m-d', strtotime($periodeDebut)),
                ':fin' => date('Y-m-d', strtotime($periodeFin))
            ]);
            $reversementId = $this->conn->lastInsertId();

            $stmtDetail = $this->conn->prepare(
                "INSERT INTO reversements_details (reversement_id, demande_id, montant, montant_paiement, taux_commission, marge_allopro)
                 VALUES (:reversement_id, :demande_id, :montant, :montant_paiement, :taux, :marge)"
            );

            foreach ($missions as $mission) {
                $taux = (float) $mission['taux_commission'];
                $marge = round((float) $mission['montant'] * ($taux / 100), 2);
                $montantPartenaire = (float) $mission['montant'] - $marge;
                $montantTotalPartenaire += $montantPartenaire;

                $stmtDetail->execute([
                    ':reversement_id' => $reversementId,
                    ':demande_id' => $mission['demande_id'],
                    ':montant' => $montantPartenaire,
                    ':montant_paiement' => $mission['montant'],
                    ':taux' => $taux,
                    ':marge' => $marge
                ]);
            }

            $stmtMaj = $this->conn->prepare("UPDATE {$this->table} SET montant_du = :montant WHERE id = :id");
            $stmtMaj->execute([':montant' => $montantTotalPartenaire, ':id' => $reversementId]);

            $this->conn->commit();
            return $reversementId;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $e;
        }
    }

    public function getAll($statutFiltre = null) {
        $sql = "SELECT r.*, p.nom_entreprise FROM {$this->table} r JOIN partenaires p ON r.partenaire_id = p.id";
        if ($statutFiltre) $sql .= " WHERE r.statut = :statut";
        $sql .= " ORDER BY r.id DESC";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) $stmt->bindParam(':statut', $statutFiltre);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT r.*, p.nom_entreprise, p.telephone FROM {$this->table} r JOIN partenaires p ON r.partenaire_id = p.id WHERE r.id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getDetails($reversementId) {
        $stmt = $this->conn->prepare(
            "SELECT rd.*, d.numero_dossier, d.mode_paiement
             FROM reversements_details rd
             JOIN demandes d ON rd.demande_id = d.id
             WHERE rd.reversement_id = :id"
        );
        $stmt->bindParam(':id', $reversementId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function marquerPaye($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = 'paye', date_paiement = NOW() WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function margeTotale() {
        $stmt = $this->conn->query("SELECT COALESCE(SUM(marge_allopro), 0) as total FROM reversements_details");
        return $stmt->fetch()['total'];
    }

    public function margeMoisEnCours() {
        $stmt = $this->conn->query(
            "SELECT COALESCE(SUM(rd.marge_allopro), 0) as total 
            FROM reversements_details rd 
            JOIN reversements r ON rd.reversement_id = r.id
            WHERE MONTH(r.periode_fin) = MONTH(CURDATE()) AND YEAR(r.periode_fin) = YEAR(CURDATE())"
        );
        return $stmt->fetch()['total'];
    }

}