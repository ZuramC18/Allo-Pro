<?php
require_once __DIR__ . '/../config/database.php';

class Intervention {
    private $conn;
    private $table = 'interventions';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId, $technicienNom) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (demande_id, technicien_nom, statut, date_debut) 
             VALUES (:demande_id, :technicien_nom, 'acceptee', NOW())"
        );
        return $stmt->execute([
            ':demande_id' => $demandeId,
            ':technicien_nom' => $technicienNom
        ]);
    }

    public function getByDemandeId($demandeId) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, p.nom_entreprise, t.nom AS technicien_nom_reel, c.nom AS technicien_metier
            FROM {$this->table} i
            LEFT JOIN partenaires p ON i.partenaire_id = p.id
            LEFT JOIN techniciens t ON i.technicien_id = t.id
            LEFT JOIN categories c ON t.categorie_id = c.id
            WHERE i.demande_id = :demande_id"
        );
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getMissionByIdEtPartenaire(int $interventionId, int $partenaireId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.demande_id, i.partenaire_id, i.technicien_id,
                    i.statut AS intervention_statut, i.date_debut, i.date_fin,
                    d.numero_dossier, d.description, d.urgence, d.date_creation,
                    d.mode_paiement, d.statut AS demande_statut,
                    u.nom AS client_nom, u.email AS client_email, u.telephone AS client_telephone,
                    c.nom AS categorie_nom, a.quartier, a.ville, a.details AS adresse_details,
                    t.nom AS technicien_nom
             FROM {$this->table} i
             JOIN demandes d ON d.id = i.demande_id
             JOIN users u ON u.id = d.client_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id AND t.partenaire_id = i.partenaire_id
             WHERE i.id = :intervention_id AND i.partenaire_id = :partenaire_id
             LIMIT 1"
        );
        $stmt->execute([
            ':intervention_id' => $interventionId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->fetch();
    }

    public function redistribuerMission(int $interventionId, int $partenaireId, int $technicienId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} i
             JOIN techniciens t ON t.id = :technicien_id
                 AND t.partenaire_id = i.partenaire_id
                 AND t.statut = 'actif'
             SET i.technicien_id = t.id, i.technicien_nom = t.nom
             WHERE i.id = :intervention_id
               AND i.partenaire_id = :partenaire_id
               AND i.statut = 'acceptee'
               AND (i.technicien_id IS NULL OR i.technicien_id <> t.id)"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':intervention_id' => $interventionId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function mettreAJourStatut($demandeId, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE demande_id = :demande_id");
        return $stmt->execute([':statut' => $statut, ':demande_id' => $demandeId]);
    }

    public function cloturer($demandeId, $rapport, $montant = null) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET statut = 'terminee', rapport = :rapport, montant = :montant, date_fin = NOW() 
            WHERE demande_id = :demande_id"
        );
        return $stmt->execute([':rapport' => $rapport, ':montant' => $montant, ':demande_id' => $demandeId]);
    }

    public function creerAvecPartenaire($demandeId, $partenaireId, $technicienId) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (demande_id, partenaire_id, technicien_id, statut, date_debut) 
            VALUES (:demande_id, :partenaire_id, :technicien_id, 'acceptee', NOW())"
        );
        return $stmt->execute([
            ':demande_id' => $demandeId,
            ':partenaire_id' => $partenaireId,
            ':technicien_id' => $technicienId
        ]);
    }

    public function getPartenaireIdByDemande($demandeId) {
        $stmt = $this->conn->prepare("SELECT partenaire_id FROM {$this->table} WHERE demande_id = :demande_id");
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return $stmt->fetch()['partenaire_id'] ?? null;
    }

    public function getByTechnicien($technicienId) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, d.numero_dossier, d.description, d.urgence, d.photo_path,
                    a.quartier, a.ville, a.details AS adresse_details, c.nom AS categorie_nom
            FROM {$this->table} i
            JOIN demandes d ON i.demande_id = d.id
            JOIN adresses a ON d.adresse_id = a.id
            JOIN categories c ON d.categorie_id = c.id
            WHERE i.technicien_id = :technicien_id
            ORDER BY FIELD(i.statut, 'acceptee','en_route','arrive','diagnostic','en_cours','terminee'), i.id DESC"
        );
        $stmt->bindParam(':technicien_id', $technicienId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getByIdEtTechnicien($id, $technicienId) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, d.numero_dossier, d.description, d.urgence, d.photo_path, d.id AS demande_id,
                    a.quartier, a.ville, a.details AS adresse_details, c.nom AS categorie_nom
            FROM {$this->table} i
            JOIN demandes d ON i.demande_id = d.id
            JOIN adresses a ON d.adresse_id = a.id
            JOIN categories c ON d.categorie_id = c.id
            WHERE i.id = :id AND i.technicien_id = :technicien_id"
        );
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':technicien_id', $technicienId);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function mettreAJourStatutParId($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function ajouterPhoto($id, $colonne, $chemin) {
        $colonne = $colonne === 'avant' ? 'photo_avant' : 'photo_apres';
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET {$colonne} = :chemin WHERE id = :id");
        return $stmt->execute([':chemin' => $chemin, ':id' => $id]);
    }

    public function initialiserChecklist(int $interventionId): void {
        $elements = [
            ['consignes', 'Vérifier l’adresse et les consignes du client', 1],
            ['materiel', 'Préparer les outils et pièces nécessaires', 2],
            ['diagnostic', 'Réaliser et expliquer le diagnostic', 3],
            ['intervention', 'Effectuer l’intervention en sécurité', 4],
            ['tests', 'Tester le fonctionnement après intervention', 5],
            ['client', 'Présenter le résultat au client et ranger', 6],
        ];
        $stmt = $this->conn->prepare(
            "INSERT IGNORE INTO intervention_checklist (intervention_id, cle, libelle, ordre)
             VALUES (:intervention_id, :cle, :libelle, :ordre)"
        );
        foreach ($elements as [$cle, $libelle, $ordre]) {
            $stmt->execute([
                ':intervention_id' => $interventionId,
                ':cle' => $cle,
                ':libelle' => $libelle,
                ':ordre' => $ordre,
            ]);
        }
    }

    public function getChecklist(int $interventionId, int $technicienId): array {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.cle, c.libelle, c.ordre, c.terminee
             FROM intervention_checklist c
             JOIN interventions i ON i.id = c.intervention_id
             WHERE c.intervention_id = :intervention_id AND i.technicien_id = :technicien_id
             ORDER BY c.ordre, c.id"
        );
        $stmt->execute([':intervention_id' => $interventionId, ':technicien_id' => $technicienId]);
        return $stmt->fetchAll();
    }

    public function definirElementChecklist(int $elementId, int $interventionId, int $technicienId, bool $terminee): bool {
        $stmt = $this->conn->prepare(
            "UPDATE intervention_checklist c
             JOIN interventions i ON i.id = c.intervention_id
             SET c.terminee = :terminee
             WHERE c.id = :element_id
               AND c.intervention_id = :intervention_id
               AND i.technicien_id = :technicien_id
               AND i.statut <> 'terminee'"
        );
        $stmt->execute([
            ':terminee' => $terminee ? 1 : 0,
            ':element_id' => $elementId,
            ':intervention_id' => $interventionId,
            ':technicien_id' => $technicienId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function ajouterDocument(int $interventionId, int $technicienId, string $nomOriginal, string $chemin, string $mimeType, int $taille): bool {
        $stmt = $this->conn->prepare(
            "INSERT INTO intervention_documents
                (intervention_id, technicien_id, nom_original, chemin, mime_type, taille)
             SELECT i.id, :technicien_insert_id, :nom_original, :chemin, :mime_type, :taille
             FROM interventions i
             WHERE i.id = :intervention_id
               AND i.technicien_id = :technicien_filter_id
               AND i.statut <> 'terminee'"
        );
        $stmt->execute([
            ':intervention_id' => $interventionId,
            ':technicien_insert_id' => $technicienId,
            ':technicien_filter_id' => $technicienId,
            ':nom_original' => $nomOriginal,
            ':chemin' => $chemin,
            ':mime_type' => $mimeType,
            ':taille' => $taille,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function getDocumentsTechnicien(int $technicienId, ?int $interventionId = null): array {
        $sql = "SELECT d.id, d.intervention_id, d.nom_original, d.chemin, d.mime_type, d.taille, d.date_creation
                FROM intervention_documents d
                JOIN interventions i ON i.id = d.intervention_id
                WHERE i.technicien_id = :technicien_id";
        $params = [':technicien_id' => $technicienId];
        if ($interventionId !== null) {
            $sql .= " AND d.intervention_id = :intervention_id";
            $params[':intervention_id'] = $interventionId;
        }
        $sql .= " ORDER BY d.date_creation DESC, d.id DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getDocumentByIdTechnicien(int $documentId, int $technicienId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT d.nom_original, d.chemin, d.mime_type, d.taille
             FROM intervention_documents d
             JOIN interventions i ON i.id = d.intervention_id
             WHERE d.id = :document_id AND i.technicien_id = :technicien_id
             LIMIT 1"
        );
        $stmt->execute([':document_id' => $documentId, ':technicien_id' => $technicienId]);
        return $stmt->fetch();
    }
}