<?php
require_once __DIR__ . '/../config/database.php';

class Paiement {
    private $conn;
    private $table = 'paiements';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId, $montant, $methode) {
        $reference = 'PAY-' . strtoupper(uniqid());
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (demande_id, montant, methode, reference_transaction, statut) 
             VALUES (:demande_id, :montant, :methode, :reference, 'en_attente')"
        );
        $stmt->execute([
            ':demande_id' => $demandeId,
            ':montant' => $montant,
            ':methode' => $methode,
            ':reference' => $reference
        ]);
        return $reference;
    }

    public function getByReference($reference) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE reference_transaction = :ref");
        $stmt->bindParam(':ref', $reference);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getByReferenceForClient($reference, $clientId) {
        $stmt = $this->conn->prepare(
            "SELECT p.*, d.id AS demande_id, d.numero_dossier, d.client_id
             FROM {$this->table} p
             JOIN demandes d ON d.id = p.demande_id
             WHERE p.reference_transaction = :reference AND d.client_id = :client_id
             LIMIT 1"
        );
        $stmt->execute([':reference' => $reference, ':client_id' => $clientId]);
        return $stmt->fetch();
    }

    public function getByDemandeId($demandeId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table} WHERE demande_id = :demande_id
             ORDER BY CASE statut
                 WHEN 'valide' THEN 0
                 WHEN 'en_attente' THEN 1
                 ELSE 2
             END, id DESC
             LIMIT 1"
        );
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function marquerValide($reference) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = 'valide' WHERE reference_transaction = :ref");
        return $stmt->execute([':ref' => $reference]);
    }

    public function sommeAujourdhui() {
        $stmt = $this->conn->query("SELECT COALESCE(SUM(montant),0) as total FROM {$this->table} WHERE statut = 'valide' AND DATE(date_paiement) = CURDATE()");
        return $stmt->fetch()['total'];
    }

    public function getAllAvecFiltres($statutFiltre = null, $methodeFiltre = null) {
        $sql = "SELECT p.*, d.numero_dossier, u.nom AS client_nom
                FROM {$this->table} p
                JOIN demandes d ON p.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                WHERE 1=1";

        if ($statutFiltre) $sql .= " AND p.statut = :statut";
        if ($methodeFiltre) $sql .= " AND p.methode = :methode";
        $sql .= " ORDER BY p.date_paiement DESC LIMIT 200";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) $stmt->bindParam(':statut', $statutFiltre);
        if ($methodeFiltre) $stmt->bindParam(':methode', $methodeFiltre);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function sommeParStatut() {
        $stmt = $this->conn->query("SELECT statut, COALESCE(SUM(montant),0) as total, COUNT(*) as nb FROM {$this->table} GROUP BY statut");
        $resultats = $stmt->fetchAll();
        $sommes = ['valide' => ['total' => 0, 'nb' => 0], 'en_attente' => ['total' => 0, 'nb' => 0], 'echoue' => ['total' => 0, 'nb' => 0]];
        foreach ($resultats as $r) { $sommes[$r['statut']] = ['total' => (float) $r['total'], 'nb' => (int) $r['nb']]; }
        return $sommes;
    }

    public function sommeParMethode() {
        $stmt = $this->conn->query("SELECT methode, COALESCE(SUM(montant),0) as total FROM {$this->table} WHERE statut = 'valide' GROUP BY methode");
        return $stmt->fetchAll();
    }

    public function sommeMoisEnCours() {
        $stmt = $this->conn->query("SELECT COALESCE(SUM(montant),0) as total FROM {$this->table} WHERE statut = 'valide' AND MONTH(date_paiement) = MONTH(CURDATE()) AND YEAR(date_paiement) = YEAR(CURDATE())");
        return $stmt->fetch()['total'];
    }
    
    public function getPassParDemande($demandeId) {
        $stmt = $this->conn->prepare("SELECT id FROM pass_achats WHERE demande_id = :d AND statut = 'utilise' LIMIT 1");
        $stmt->execute([':d' => $demandeId]);
        return $stmt->fetch();
    }

}