<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/roles.php';
require_once __DIR__ . '/Parametre.php';

class User {
    private $conn;
    private $table = 'users';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function findByEmail($email) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function emailUtiliseParAutreCompteClient($email, $id): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE email = :email AND id != :id AND role = 'client'
             LIMIT 1"
        );
        $stmt->execute([':email' => $email, ':id' => $id]);
        return (bool) $stmt->fetchColumn();
    }

    public function mettreAJourProfilClient($id, string $prenom, string $nom, string $email, ?string $telephone): bool {
        $compte = $this->getById($id);
        if (!$compte || ($compte['role'] ?? '') !== 'client') {
            return false;
        }
        $emailModifie = strcasecmp((string) $compte['email'], $email) !== 0 ? 1 : 0;
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET email_verifie = IF(:email_change_verify = 1, 0, email_verifie),
                 email_verification_token_hash = IF(:email_change_token = 1, NULL, email_verification_token_hash),
                 email_verification_expires_at = IF(:email_change_expiry = 1, NULL, email_verification_expires_at),
                 email_verification_sent_at = IF(:email_change_sent = 1, NULL, email_verification_sent_at),
                 email_verification_code_hash = IF(:email_change_code = 1, NULL, email_verification_code_hash),
                 email_verification_attempts = IF(:email_change_attempts = 1, 0, email_verification_attempts),
                 prenom = :prenom, nom = :nom, email = :email, telephone = :telephone
             WHERE id = :id AND role = 'client'"
        );
        return $stmt->execute([
            ':email_change_verify' => $emailModifie,
            ':email_change_token' => $emailModifie,
            ':email_change_expiry' => $emailModifie,
            ':email_change_sent' => $emailModifie,
            ':email_change_code' => $emailModifie,
            ':email_change_attempts' => $emailModifie,
            ':prenom' => $prenom,
            ':nom' => $nom,
            ':email' => $email,
            ':telephone' => $telephone,
            ':id' => $id,
        ]);
    }

    public function mettreAJourPhotoProfilClient(int $id, string $chemin): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET photo_profil = :photo, avatar_initiales = 0
             WHERE id = :id AND role = 'client'"
        );
        return $stmt->execute([':photo' => $chemin, ':id' => $id]);
    }

    public function supprimerPhotoProfilClient(int $id): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET photo_profil = NULL
             WHERE id = :id AND role = 'client'"
        );
        return $stmt->execute([':id' => $id]);
    }

    public function definirAvatarInitialesClient(int $id, bool $initiales): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET avatar_initiales = :initiales
             WHERE id = :id AND role = 'client'"
        );
        return $stmt->execute([':initiales' => $initiales ? 1 : 0, ':id' => $id]);
    }

    public function mettreAJourPhotoProfilInterne(int $id, string $chemin): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET photo_profil = :photo, avatar_initiales = 0
             WHERE id = :id AND role IN " . $this->rolesInternesSQL()
        );
        return $stmt->execute([':photo' => $chemin, ':id' => $id]);
    }

    public function supprimerPhotoProfilInterne(int $id): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET photo_profil = NULL
             WHERE id = :id AND role IN " . $this->rolesInternesSQL()
        );
        return $stmt->execute([':id' => $id]);
    }

    public function definirAvatarInitialesInterne(int $id, bool $initiales): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET avatar_initiales = :initiales
             WHERE id = :id AND role IN " . $this->rolesInternesSQL()
        );
        return $stmt->execute([':initiales' => $initiales ? 1 : 0, ':id' => $id]);
    }

    public function mettreAJourProfilInterne(int $id, string $prenom, string $nom, ?string $telephone): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET prenom = :prenom, nom = :nom, telephone = :telephone
             WHERE id = :id AND role IN " . $this->rolesInternesSQL()
        );
        return $stmt->execute([
            ':prenom' => $prenom,
            ':nom' => $nom,
            ':telephone' => $telephone,
            ':id' => $id,
        ]);
    }

    public function changerMotDePasseInterne(int $id, string $motDePasseActuel, string $nouveauMotDePasse): string {
        $stmt = $this->conn->prepare(
            "SELECT mot_de_passe FROM {$this->table}
             WHERE id = :id AND role IN " . $this->rolesInternesSQL() . " LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $hashActuel = $stmt->fetchColumn();

        if (!is_string($hashActuel) || $hashActuel === '' || !password_verify($motDePasseActuel, $hashActuel)) {
            return 'mot_de_passe_incorrect';
        }

        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET mot_de_passe = :mot_de_passe
             WHERE id = :id AND role IN " . $this->rolesInternesSQL()
        );
        return $stmt->execute([
            ':mot_de_passe' => password_hash($nouveauMotDePasse, PASSWORD_DEFAULT),
            ':id' => $id,
        ]) ? 'ok' : 'echec';
    }

    public function verifierMotDePasseClient($id, string $motDePasse): bool {
        $stmt = $this->conn->prepare(
            "SELECT mot_de_passe FROM {$this->table}
             WHERE id = :id AND role = 'client'
             LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $hash = $stmt->fetchColumn();
        return is_string($hash) && $hash !== '' && password_verify($motDePasse, $hash);
    }

    public function changerMotDePasseClient($id, string $nouveauMotDePasse): bool {
        $hash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET mot_de_passe = :mot_de_passe,
                 mdp_a_definir = 0,
                 reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE id = :id AND role = 'client'"
        );
        return $stmt->execute([':mot_de_passe' => $hash, ':id' => $id]);
    }

    public function create($prenom, $nom, $email, $motDePasse, $telephone, $role = 'client', $emailVerifie = true) {
        $hash = $motDePasse !== null ? password_hash($motDePasse, PASSWORD_DEFAULT) : null;
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table} (prenom, nom, email, mot_de_passe, telephone, role, email_verifie)
                VALUES (:prenom, :nom, :email, :mot_de_passe, :telephone, :role, :email_verifie)"
            );
            $stmt->execute([
                ':prenom' => $prenom,
                ':nom' => $nom,
                ':email' => $email,
                ':mot_de_passe' => $hash,
                ':telephone' => $telephone,
                ':role' => $role,
                ':email_verifie' => $emailVerifie ? 1 : 0,
            ]);
            $id = (int) $this->conn->lastInsertId();

            $matricule = ($role === 'client' ? 'CL' : 'EQ') . '-' . str_pad($id, 5, '0', STR_PAD_LEFT);
            $maj = $this->conn->prepare("UPDATE {$this->table} SET matricule = :matricule WHERE id = :id");
            $maj->execute([':matricule' => $matricule, ':id' => $id]);

            $this->conn->commit();
            return $id;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    public function definirCodeVerificationEmail($id, string $hash, string $expiration): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET email_verification_code_hash = :hash,
                 email_verification_expires_at = :expiration,
                 email_verification_sent_at = UTC_TIMESTAMP(),
                 email_verification_attempts = 0
             WHERE id = :id AND role = 'client' AND email_verifie = 0
               AND (email_verification_sent_at IS NULL
                    OR email_verification_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE))"
        );
        $stmt->execute([':hash' => $hash, ':expiration' => $expiration, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function confirmerEmailParCode(string $email, string $code): bool {
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT id, email_verification_code_hash
                 FROM {$this->table}
                 WHERE email = :email AND role = 'client' AND email_verifie = 0
                   AND email_verification_expires_at > UTC_TIMESTAMP()
                   AND email_verification_attempts < 5
                 LIMIT 1 FOR UPDATE"
            );
            $stmt->execute([':email' => $email]);
            $verification = $stmt->fetch();
            if (!$verification) {
                $this->conn->commit();
                return false;
            }

            if (!password_verify($code, (string) $verification['email_verification_code_hash'])) {
                $echec = $this->conn->prepare(
                    "UPDATE {$this->table}
                     SET email_verification_attempts = email_verification_attempts + 1
                     WHERE id = :id AND email_verification_attempts < 5"
                );
                $echec->execute([':id' => $verification['id']]);
                $this->conn->commit();
                return false;
            }

            $confirmation = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET email_verifie = 1,
                     email_verification_token_hash = NULL,
                     email_verification_code_hash = NULL,
                     email_verification_expires_at = NULL,
                     email_verification_sent_at = NULL,
                     email_verification_attempts = 0
                 WHERE id = :id AND email_verifie = 0"
            );
            $confirmation->execute([':id' => $verification['id']]);
            $confirme = $confirmation->rowCount() === 1;
            $this->conn->commit();
            return $confirme;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $e;
        }
    }

    public function confirmerEmailParJeton(string $hash): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET email_verifie = 1,
                 email_verification_token_hash = NULL,
                 email_verification_code_hash = NULL,
                 email_verification_expires_at = NULL,
                 email_verification_sent_at = NULL,
                 email_verification_attempts = 0
             WHERE email_verification_token_hash = :hash
               AND email_verification_expires_at > UTC_TIMESTAMP()
               AND email_verifie = 0 AND role = 'client'"
        );
        $stmt->execute([':hash' => $hash]);
        return $stmt->rowCount() === 1;
    }

    public function marquerEmailVerifie($id): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET email_verifie = 1,
                 email_verification_token_hash = NULL,
                 email_verification_code_hash = NULL,
                 email_verification_expires_at = NULL,
                 email_verification_sent_at = NULL,
                 email_verification_attempts = 0
             WHERE id = :id"
        );
        return $stmt->execute([':id' => $id]);
    }

    public function creerJetonReinitialisation($id, string $hash, string $expiration): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = :hash,
                 reinitialisation_expires_at = :expiration,
                 reinitialisation_sent_at = UTC_TIMESTAMP()
             WHERE id = :id AND role = 'client'
               AND (reinitialisation_sent_at IS NULL
                    OR reinitialisation_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE))"
        );
        $stmt->execute([':hash' => $hash, ':expiration' => $expiration, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function annulerJetonReinitialisation($id, string $hash): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE id = :id AND role = 'client'
               AND reinitialisation_token_hash = :hash"
        );
        $stmt->execute([':id' => $id, ':hash' => $hash]);
    }

    public function telephoneReinitialisationBloque($id): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE id = :id AND role = 'client'
               AND reinitialisation_phone_blocked_until > UTC_TIMESTAMP()"
        );
        $stmt->execute([':id' => $id]);
        return (bool) $stmt->fetchColumn();
    }

    public function enregistrerEchecTelephoneReinitialisation($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_blocked_until = IF(
                     reinitialisation_phone_attempts + 1 >= 5,
                     DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE),
                     reinitialisation_phone_blocked_until
                 ),
                 reinitialisation_phone_attempts = LEAST(reinitialisation_phone_attempts + 1, 5)
             WHERE id = :id AND role = 'client'
               AND (reinitialisation_phone_blocked_until IS NULL
                    OR reinitialisation_phone_blocked_until <= UTC_TIMESTAMP())"
        );
        $stmt->execute([':id' => $id]);
    }

    public function reinitialiserTentativesTelephone($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_attempts = 0,
                 reinitialisation_phone_blocked_until = NULL
             WHERE id = :id AND role = 'client'"
        );
        $stmt->execute([':id' => $id]);
    }

    public function jetonReinitialisationValide(string $hash): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP()
               AND role = 'client' LIMIT 1"
        );
        $stmt->execute([':hash' => $hash]);
        return (bool) $stmt->fetchColumn();
    }

    public function reinitialiserMotDePasseParJeton(string $hash, string $nouveauMotDePasse): bool {
        $motDePasseHash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET mot_de_passe = :mot_de_passe,
                 mdp_a_definir = 0,
                 reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP()
               AND role = 'client'"
        );
        $stmt->execute([':mot_de_passe' => $motDePasseHash, ':hash' => $hash]);
        return $stmt->rowCount() === 1;
    }

    public function findByGoogleId($googleId) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE google_id = :gid");
        $stmt->bindParam(':gid', $googleId);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function lierGoogleId($userId, $googleId) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET google_id = :gid WHERE id = :id");
        return $stmt->execute([':gid' => $googleId, ':id' => $userId]);
    }

    public function marquerMdpADefinir($id, $valeur) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET mdp_a_definir = :v WHERE id = :id");
        return $stmt->execute([':v' => $valeur ? 1 : 0, ':id' => $id]);
    }

    public function definirMotDePasse($id, $motDePasse) {
        $hash = password_hash($motDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET mot_de_passe = :mdp, mdp_a_definir = 0 WHERE id = :id");
        return $stmt->execute([':mdp' => $hash, ':id' => $id]);
    }

    public function fermerConversationEtAttribuerSuivant($clientId, $conseillerId, $attributionAutomatique, $limiteClients) {
        $this->conn->beginTransaction();
        try {
            $verrouClient = $this->conn->prepare(
                "SELECT id, role, conseiller_assigne_id, conversation_statut
                 FROM {$this->table} WHERE id = :id FOR UPDATE"
            );
            $verrouClient->execute([':id' => $clientId]);
            $client = $verrouClient->fetch();

            if (!$client || $client['role'] !== 'client'
                || (int) $client['conseiller_assigne_id'] !== (int) $conseillerId
                || $client['conversation_statut'] !== 'ouverte') {
                $this->conn->rollBack();
                return false;
            }

            $fermer = $this->conn->prepare(
                "UPDATE {$this->table}
                  SET conversation_statut = 'fermee'
                 WHERE id = :id AND conseiller_assigne_id = :conseiller_id"
            );
            $fermer->execute([':id' => $clientId, ':conseiller_id' => $conseillerId]);

            $clientSuivantId = null;
            if ($attributionAutomatique) {
                $conseiller = $this->conn->prepare(
                    "SELECT id FROM {$this->table}
                     WHERE id = :id AND role = 'conseiller' AND statut = 'actif' FOR UPDATE"
                );
                $conseiller->execute([':id' => $conseillerId]);
                $conseillerActif = $conseiller->fetch();

                $compter = $this->conn->prepare(
                    "SELECT COUNT(*) FROM {$this->table}
                                         WHERE role = 'client' AND conseiller_assigne_id = :id
                                             AND conversation_statut = 'ouverte'"
                );
                $compter->execute([':id' => $conseillerId]);
                $charge = (int) $compter->fetchColumn();

                if ($conseillerActif && ($limiteClients <= 0 || $charge < $limiteClients)) {
                    $suivant = $this->conn->query(
                        "SELECT c.id
                         FROM {$this->table} c
                         WHERE c.role = 'client' AND c.conversation_statut = 'ouverte'
                           AND c.conseiller_assigne_id IS NULL
                           AND EXISTS (SELECT 1 FROM messages m WHERE m.client_id = c.id)
                         ORDER BY (SELECT MIN(m.date_creation) FROM messages m WHERE m.client_id = c.id), c.id
                         LIMIT 1 FOR UPDATE"
                    )->fetch();

                    if ($suivant) {
                        $attribuer = $this->conn->prepare(
                            "UPDATE {$this->table} SET conseiller_assigne_id = :conseiller_id
                             WHERE id = :id AND conseiller_assigne_id IS NULL AND conversation_statut = 'ouverte'"
                        );
                        $attribuer->execute([':conseiller_id' => $conseillerId, ':id' => $suivant['id']]);
                        if ($attribuer->rowCount() > 0) $clientSuivantId = (int) $suivant['id'];
                    }
                }
            }

            $this->conn->commit();
            return ['client_suivant_id' => $clientSuivantId];
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            throw $e;
        }
    }

    public function reouvrirConversationAttribuee($clientId, $conseillerId, $limiteClients) {
        $this->conn->beginTransaction();
        try {
            $verrouClient = $this->conn->prepare(
                "SELECT id, role, conseiller_assigne_id, conversation_statut
                 FROM {$this->table} WHERE id = :id FOR UPDATE"
            );
            $verrouClient->execute([':id' => $clientId]);
            $client = $verrouClient->fetch();

            $dejaAffecteeAuConseiller = $client && $client['conseiller_assigne_id'] !== null
                && (int) $client['conseiller_assigne_id'] === (int) $conseillerId;
            $sansAffectation = $client && $client['conseiller_assigne_id'] === null;
            if (!$client || $client['role'] !== 'client'
                || (!$dejaAffecteeAuConseiller && !$sansAffectation)
                || $client['conversation_statut'] !== 'fermee') {
                $this->conn->rollBack();
                return false;
            }

            $conseiller = $this->conn->prepare(
                "SELECT id FROM {$this->table}
                 WHERE id = :id AND role = 'conseiller' AND statut = 'actif' FOR UPDATE"
            );
            $conseiller->execute([':id' => $conseillerId]);
            if (!$conseiller->fetch()) {
                $this->conn->rollBack();
                return false;
            }

            $compter = $this->conn->prepare(
                "SELECT COUNT(*) FROM {$this->table}
                 WHERE role = 'client' AND conseiller_assigne_id = :id
                   AND conversation_statut = 'ouverte'"
            );
            $compter->execute([':id' => $conseillerId]);
            if ($limiteClients > 0 && (int) $compter->fetchColumn() >= $limiteClients) {
                $this->conn->rollBack();
                return 'limite';
            }

            $ouvrir = $this->conn->prepare(
                                "UPDATE {$this->table}
                 SET conversation_statut = 'ouverte', conseiller_assigne_id = :conseiller_id_set
                 WHERE id = :id AND (conseiller_assigne_id = :conseiller_id_check OR conseiller_assigne_id IS NULL)
                                     AND conversation_statut = 'fermee'"
            );
            $ouvrir->execute([
                ':id' => $clientId,
                ':conseiller_id_set' => $conseillerId,
                ':conseiller_id_check' => $conseillerId,
            ]);
            if ($ouvrir->rowCount() !== 1) {
                $this->conn->rollBack();
                return false;
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            throw $e;
        }
    }

    private function reaffecterEtReouvrirConversationSaturee($clientId, $ancienConseillerId) {
        $this->conn->beginTransaction();
        try {
            $verrouClient = $this->conn->prepare(
                "SELECT id, role, conseiller_assigne_id, conversation_statut
                 FROM {$this->table} WHERE id = :id FOR UPDATE"
            );
            $verrouClient->execute([':id' => $clientId]);
            $client = $verrouClient->fetch();
            if (!$client || $client['role'] !== 'client'
                || (int) $client['conseiller_assigne_id'] !== (int) $ancienConseillerId
                || $client['conversation_statut'] !== 'fermee') {
                $this->conn->rollBack();
                return false;
            }

            $liberer = $this->conn->prepare(
                "UPDATE {$this->table} SET conseiller_assigne_id = NULL
                 WHERE id = :id AND conseiller_assigne_id = :conseiller_id AND conversation_statut = 'fermee'"
            );
            $liberer->execute([':id' => $clientId, ':conseiller_id' => $ancienConseillerId]);

            $nouveauConseiller = $this->assignerConseillerAutomatique($clientId);
            if (!$nouveauConseiller) {
                $this->conn->rollBack();
                return false;
            }

            $ouvrir = $this->conn->prepare(
                "UPDATE {$this->table} SET conversation_statut = 'ouverte'
                 WHERE id = :id AND conseiller_assigne_id = :conseiller_id AND conversation_statut = 'fermee'"
            );
            $ouvrir->execute([':id' => $clientId, ':conseiller_id' => $nouveauConseiller['id']]);
            if ($ouvrir->rowCount() !== 1) {
                $this->conn->rollBack();
                return false;
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            throw $e;
        }
    }

    public function fermerConversation($userId) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET conversation_statut = 'fermee' WHERE id = :id");
        return $stmt->execute([':id' => $userId]);
    }

    public function reouvrirConversation($userId) {
        $stmt = $this->conn->prepare(
            "SELECT role, conversation_statut, conseiller_assigne_id FROM {$this->table} WHERE id = :id"
        );
        $stmt->execute([':id' => $userId]);
        $client = $stmt->fetch();
        if (!$client || $client['role'] !== 'client') return false;
        if ($client['conversation_statut'] === 'ouverte') return true;

        $parametres = new Parametre();
        $conseillerId = $client['conseiller_assigne_id'] !== null ? (int) $client['conseiller_assigne_id'] : null;
        $attributionAutomatique = $parametres->attributionAutomatiqueActive();
        if ($conseillerId === null && $parametres->attributionAutomatiqueActive()) {
            $assigne = $this->assignerConseillerAutomatique($userId);
            $conseillerId = $assigne['id'] ?? $this->getConseillerAssigne($userId);
        }

        if ($conseillerId) {
            $limite = $attributionAutomatique ? $parametres->getLimiteClientsParConseiller() : 0;
            $resultat = $this->reouvrirConversationAttribuee(
                $userId,
                (int) $conseillerId,
                $limite
            );
            if ($resultat === true) return true;
            if ($resultat === 'limite' && $attributionAutomatique) {
                return $this->reaffecterEtReouvrirConversationSaturee($userId, (int) $conseillerId);
            }
            return false;
        }

        $ouvrir = $this->conn->prepare(
            "UPDATE {$this->table} SET conversation_statut = 'ouverte'
             WHERE id = :id AND role = 'client' AND conversation_statut = 'fermee'
               AND conseiller_assigne_id IS NULL"
        );
        return $ouvrir->execute([':id' => $userId]);
    }

    public function aDemandesActives($userId) {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) as total FROM demandes WHERE client_id = :id AND statut NOT IN ('terminee', 'annulee')"
        );
        $stmt->bindParam(':id', $userId);
        $stmt->execute();
        return $stmt->fetch()['total'] > 0;
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }
    
    public function compterNouveauxAujourdhui() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE role = 'client' AND DATE(date_creation) = CURDATE()");
        return $stmt->fetch()['total'];
    }

    public function getAllClients($recherche = null) {
        $sql = "SELECT u.*, 
                    (SELECT COUNT(*) FROM demandes WHERE client_id = u.id) AS nb_demandes,
                    (SELECT COUNT(*) FROM demandes WHERE client_id = u.id AND statut NOT IN ('terminee','annulee')) AS nb_actives
                FROM {$this->table} u WHERE u.role = 'client'";

        if ($recherche) {
            $sql .= " AND (u.nom LIKE :recherche1 OR u.email LIKE :recherche2 OR u.telephone LIKE :recherche3)";
        }
        $sql .= " ORDER BY u.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($recherche) {
            $termeRecherche = '%' . $recherche . '%';
            $stmt->bindParam(':recherche1', $termeRecherche);
            $stmt->bindParam(':recherche2', $termeRecherche);
            $stmt->bindParam(':recherche3', $termeRecherche);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function changerStatut($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function compterTotalClients() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE role = 'client'");
        return $stmt->fetch()['total'];
    }

    private function rolesInternesSQL() {
        return "('" . implode("','", ROLES_INTERNES) . "')";
    }

    public function getEquipe($recherche = null, $role = null) {
        $sql = "SELECT u.*,
                    (SELECT COUNT(*) FROM messages WHERE expediteur_type = 'conseiller' AND expediteur_id = u.id) AS nb_messages,
                    (SELECT COUNT(*) FROM notes_internes_client WHERE conseiller_id = u.id) AS nb_notes
                FROM {$this->table} u
                WHERE u.role IN " . $this->rolesInternesSQL();
        $params = [];

        if ($recherche) {
            $sql .= " AND (u.nom LIKE :recherche1 OR u.email LIKE :recherche2 OR u.telephone LIKE :recherche3)";
            $terme = '%' . $recherche . '%';
            $params[':recherche1'] = $terme;
            $params[':recherche2'] = $terme;
            $params[':recherche3'] = $terme;
        }
        if ($role) {
            $sql .= " AND u.role = :role";
            $params[':role'] = $role;
        }
        $sql .= " ORDER BY FIELD(u.role, 'admin', 'coordinateur', 'qualite', 'finance', 'conseiller'), u.nom";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function compterEquipe() {
        $stmt = $this->conn->query(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(role = 'admin'), 0) AS admins,
                    COALESCE(SUM(role != 'admin'), 0) AS autres,
                    COALESCE(SUM(statut = 'suspendu'), 0) AS suspendus
            FROM {$this->table} WHERE role IN " . $this->rolesInternesSQL()
        );
        return $stmt->fetch();
    }

    // Les trois méthodes suivantes ne touchent jamais un compte client, même si on leur passe son ID
    public function changerRoleMembre($id, $role) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET role = :role WHERE id = :id AND role IN " . $this->rolesInternesSQL());
        return $stmt->execute([':role' => $role, ':id' => $id]);
    }

    public function changerStatutMembre($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id AND role IN " . $this->rolesInternesSQL());
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function reinitialiserMotDePasse($id, $nouveauMotDePasse) {
        $hash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET mot_de_passe = :mdp WHERE id = :id AND role IN " . $this->rolesInternesSQL());
        return $stmt->execute([':mdp' => $hash, ':id' => $id]);
    }

    public function changerMotDePasseAdmin($id, string $motDePasseActuel, string $nouveauMotDePasse): string {
        $stmt = $this->conn->prepare(
            "SELECT mot_de_passe FROM {$this->table} WHERE id = :id AND role = 'admin' LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $hashActuel = $stmt->fetchColumn();

        if (!is_string($hashActuel) || $hashActuel === '' || !password_verify($motDePasseActuel, $hashActuel)) {
            return 'mot_de_passe_incorrect';
        }

        $nouveauHash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET mot_de_passe = :mot_de_passe
             WHERE id = :id AND role = 'admin'"
        );

        return $stmt->execute([':mot_de_passe' => $nouveauHash, ':id' => $id])
            ? 'ok'
            : 'echec';
    }

    public function getConseillersActifsAvecCharge($recherche = null) {
        $sql = "SELECT u.id, u.nom, u.matricule,
                    CASE
                        WHEN u.presence_status = 'offline'
                            OR u.presence_last_seen IS NULL
                            OR u.presence_last_seen < DATE_SUB(NOW(), INTERVAL 10 MINUTE)
                        THEN 'offline'
                        ELSE u.presence_status
                    END AS presence_status,
                    (SELECT COUNT(*) FROM users c WHERE c.conseiller_assigne_id = u.id AND c.role = 'client'
                        AND c.conversation_statut = 'ouverte') AS nb_clients
                FROM {$this->table} u
                WHERE u.role = 'conseiller' AND u.statut = 'actif'";
        $params = [];
        if ($recherche) {
            $sql .= " AND (u.nom LIKE :recherche OR u.matricule LIKE :recherche2)";
            $terme = '%' . $recherche . '%';
            $params[':recherche'] = $terme;
            $params[':recherche2'] = $terme;
        }
        $sql .= " ORDER BY nb_clients ASC, u.nom";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getPresenceConseiller(int $id): ?array {
        $stmt = $this->conn->prepare(
            "SELECT CASE
                WHEN presence_status = 'offline'
                    OR presence_last_seen IS NULL
                    OR presence_last_seen < DATE_SUB(NOW(), INTERVAL 10 MINUTE)
                THEN 'offline'
                ELSE presence_status
             END AS presence_status
             FROM {$this->table}
             WHERE id = :id AND role = 'conseiller' AND statut = 'actif'
             LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $presence = $stmt->fetch();
        return $presence ?: null;
    }

    public function definirPresenceConseiller(int $id, string $presence): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET presence_status = :presence, presence_last_seen = NOW()
             WHERE id = :id AND role = 'conseiller' AND statut = 'actif'"
        );
        return $stmt->execute([':presence' => $presence, ':id' => $id]);
    }

    public function actualiserPresenceConseiller(int $id): ?array {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET presence_last_seen = NOW()
             WHERE id = :id AND role = 'conseiller' AND statut = 'actif'
               AND presence_status IN ('online', 'pause')
               AND presence_last_seen >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)"
        );
        $stmt->execute([':id' => $id]);
        return $this->getPresenceConseiller($id);
    }

    // Le conseiller actif le moins chargé reçoit le client, dans la limite configurée.
    public function assignerConseillerAutomatique($clientId) {
        $conseillers = $this->getConseillersActifsAvecCharge();
        $limite = (new Parametre())->getLimiteClientsParConseiller();
        if ($limite > 0) {
            $conseillers = array_values(array_filter($conseillers, function ($conseiller) use ($limite) {
                return (int) $conseiller['nb_clients'] < $limite;
            }));
        }
        if (empty($conseillers)) return null;

        $choisi = $conseillers[0];
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET conseiller_assigne_id = :cid WHERE id = :id AND conseiller_assigne_id IS NULL");
        $stmt->execute([':cid' => $choisi['id'], ':id' => $clientId]);
        return $stmt->rowCount() > 0 ? $choisi : null;
    }

    public function getConseillerAssigne($clientId) {
        $stmt = $this->conn->prepare("SELECT conseiller_assigne_id FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $clientId);
        $stmt->execute();
        $r = $stmt->fetch();
        return $r ? $r['conseiller_assigne_id'] : null;
    }

    public function reassignerConseiller($clientId, $conseillerId) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET conseiller_assigne_id = :cid WHERE id = :id AND role = 'client'");
        return $stmt->execute([':cid' => $conseillerId, ':id' => $clientId]);
    }

}