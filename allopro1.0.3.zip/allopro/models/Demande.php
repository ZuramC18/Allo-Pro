<?php
require_once __DIR__ . '/../config/database.php';

class Demande {
    private $conn;
    private $table = 'demandes';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function genererNumeroDossier() {
        $annee = date('Y');
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE numero_dossier LIKE 'AP-{$annee}-%'");
        $total = $stmt->fetch()['total'] + 1;
        return "AP-{$annee}-" . str_pad($total, 6, '0', STR_PAD_LEFT);
    }

    public function create($clientId, $adresseId, $categorieId, $description, $urgence, $photoPath, $modePaiement = 'normal', $abonnementId = null, $passAchatId = null) {
        $numeroDossier = $this->genererNumeroDossier();

        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (numero_dossier, client_id, adresse_id, categorie_id, description, urgence, photo_path, mode_paiement, abonnement_id, pass_achat_id)
            VALUES (:numero, :client_id, :adresse_id, :categorie_id, :description, :urgence, :photo, :mode, :abo, :pass)"
        );
        $stmt->execute([
            ':numero' => $numeroDossier, ':client_id' => $clientId, ':adresse_id' => $adresseId,
            ':categorie_id' => $categorieId, ':description' => $description, ':urgence' => $urgence, ':photo' => $photoPath,
            ':mode' => $modePaiement, ':abo' => $abonnementId, ':pass' => $passAchatId
        ]);
        return $numeroDossier;
    }

    public function getByClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT d.*, c.nom AS categorie_nom, i.montant AS intervention_montant,
                    p.montant AS paiement_montant, p.methode AS paiement_methode,
                    p.statut AS paiement_statut
             FROM {$this->table} d 
             JOIN categories c ON d.categorie_id = c.id 
             LEFT JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN paiements p ON p.id = (
                 SELECT p2.id FROM paiements p2
                 WHERE p2.demande_id = d.id
                 ORDER BY CASE p2.statut
                     WHEN 'valide' THEN 0
                     WHEN 'en_attente' THEN 1
                     ELSE 2
                 END, p2.id DESC
                 LIMIT 1
             )
             WHERE d.client_id = :client_id 
             ORDER BY d.date_creation DESC"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getAll($statutFiltre = null) {
        $sql = "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom, u.telephone AS client_telephone,
                    a.quartier, a.ville
                FROM {$this->table} d
                JOIN categories c ON d.categorie_id = c.id
                JOIN users u ON d.client_id = u.id
                JOIN adresses a ON d.adresse_id = a.id";

        if ($statutFiltre) {
            $sql .= " WHERE d.statut = :statut";
        }
        $sql .= " ORDER BY d.urgence DESC, d.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) {
            $stmt->bindParam(':statut', $statutFiltre);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare(
            "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom, u.telephone AS client_telephone,
                    a.quartier, a.ville, a.details AS adresse_details, i.montant
            FROM {$this->table} d
            JOIN categories c ON d.categorie_id = c.id
            JOIN users u ON d.client_id = u.id
            JOIN adresses a ON d.adresse_id = a.id
            LEFT JOIN interventions i ON i.demande_id = d.id
            WHERE d.id = :id"
        );
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function mettreAJourStatut($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function fermerMessagerie($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET messagerie_statut = 'fermee' WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function reouvrirMessagerie($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET messagerie_statut = 'ouverte' WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function compterParStatutClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT statut, COUNT(*) as total FROM {$this->table} WHERE client_id = :client_id GROUP BY statut"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        $resultats = $stmt->fetchAll();

        $compteurs = ['toutes' => 0, 'nouvelle' => 0, 'attribuee' => 0, 'en_cours' => 0, 'terminee' => 0, 'annulee' => 0];
        foreach ($resultats as $r) {
            $compteurs[$r['statut']] = (int) $r['total'];
            $compteurs['toutes'] += (int) $r['total'];
        }
        return $compteurs;
    }

    public function compterAujourdhui() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE DATE(date_creation) = CURDATE()");
        return $stmt->fetch()['total'];
    }

    public function compterEnCours() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE statut IN ('attribuee', 'en_cours')");
        return $stmt->fetch()['total'];
    }

    public function compterTermineesAujourdhui() {
        $stmt = $this->conn->query(
            "SELECT COUNT(*) as total FROM {$this->table} d JOIN interventions i ON i.demande_id = d.id 
            WHERE d.statut = 'terminee' AND DATE(i.date_fin) = CURDATE()"
        );
        return $stmt->fetch()['total'];
    }

    public function getRecentes($limite = 6) {
        $stmt = $this->conn->prepare(
            "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom 
            FROM {$this->table} d 
            JOIN categories c ON d.categorie_id = c.id
            JOIN users u ON d.client_id = u.id
            ORDER BY d.date_creation DESC LIMIT :limite"
        );
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getAllAvecFiltres($recherche = null, $statutFiltre = null, $urgenceFiltre = null) {
        $sql = "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom, u.telephone AS client_telephone,
                    a.quartier, i.partenaire_id, p.nom_entreprise, t.nom AS technicien_nom
                FROM {$this->table} d
                JOIN categories c ON d.categorie_id = c.id
                JOIN users u ON d.client_id = u.id
                JOIN adresses a ON d.adresse_id = a.id
                LEFT JOIN interventions i ON i.demande_id = d.id
                LEFT JOIN partenaires p ON i.partenaire_id = p.id
                LEFT JOIN techniciens t ON i.technicien_id = t.id
                WHERE 1=1";

        if ($recherche) {
            $sql .= " AND (d.numero_dossier LIKE :recherche1 OR u.nom LIKE :recherche2)";
        }
        if ($statutFiltre) {
            $sql .= " AND d.statut = :statut";
        }
        if ($urgenceFiltre) {
            $sql .= " AND d.urgence = :urgence";
        }
        $sql .= " ORDER BY d.date_creation DESC LIMIT 200";

        $stmt = $this->conn->prepare($sql);
        if ($recherche) {
            $terme = '%' . $recherche . '%';
            $stmt->bindParam(':recherche1', $terme);
            $stmt->bindParam(':recherche2', $terme);
        }
        if ($statutFiltre) $stmt->bindParam(':statut', $statutFiltre);
        if ($urgenceFiltre) $stmt->bindParam(':urgence', $urgenceFiltre);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterParStatutGlobal() {
        $stmt = $this->conn->query("SELECT statut, COUNT(*) as total FROM {$this->table} GROUP BY statut");
        $resultats = $stmt->fetchAll();
        $compteurs = ['toutes' => 0, 'nouvelle' => 0, 'attribuee' => 0, 'en_cours' => 0, 'terminee' => 0, 'annulee' => 0];
        foreach ($resultats as $r) {
            $compteurs[$r['statut']] = (int) $r['total'];
            $compteurs['toutes'] += (int) $r['total'];
        }
        return $compteurs;
    }

}