<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/roles.php';

class RolePermission {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getMatrice() {
        $lignes = $this->conn->query("SELECT role, module FROM role_permissions")->fetchAll();
        $matrice = [];
        foreach ($lignes as $l) { $matrice[$l['role']][$l['module']] = true; }
        return $matrice;
    }

    public function compterMembresParRole() {
        $lignes = $this->conn->query("SELECT role, COUNT(*) AS total FROM users WHERE role != 'client' GROUP BY role")->fetchAll();
        return array_column($lignes, 'total', 'role');
    }

    public function enregistrer(array $permissionsParRole) {
        $modulesValides = array_keys(MODULES);

        $this->conn->beginTransaction();
        try {
            $suppr = $this->conn->prepare("DELETE FROM role_permissions WHERE role = :role");
            $ajout = $this->conn->prepare("INSERT INTO role_permissions (role, module) VALUES (:role, :module)");

            foreach (ROLES_INTERNES as $role) {
                if ($role === 'admin') continue;
                $suppr->execute([':role' => $role]);
                foreach ((array) ($permissionsParRole[$role] ?? []) as $module) {
                    if (in_array($module, $modulesValides, true)) {
                        $ajout->execute([':role' => $role, ':module' => $module]);
                    }
                }
            }
            $this->conn->commit();
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }
}