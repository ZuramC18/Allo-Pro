<?php
require_once __DIR__ . '/../config/database.php';

class Note {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId, $note, $commentaire) {
        $stmt = $this->conn->prepare(
            "INSERT INTO notes (demande_id, note, commentaire) VALUES (:demande_id, :note, :commentaire)"
        );
        return $stmt->execute([
            ':demande_id' => $demandeId,
            ':note' => $note,
            ':commentaire' => $commentaire
        ]);
    }

    public function existePour($demandeId) {
        $stmt = $this->conn->prepare("SELECT id FROM notes WHERE demande_id = :demande_id");
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return (bool) $stmt->fetch();
    }
    public function getByDemandeId($demandeId) {
        $stmt = $this->conn->prepare("SELECT * FROM notes WHERE demande_id = :demande_id");
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return $stmt->fetch();
    }
}