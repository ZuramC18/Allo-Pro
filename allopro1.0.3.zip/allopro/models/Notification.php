<?php
require_once __DIR__ . '/../config/database.php';

class Notification {
    private $conn;
    private $table = 'notifications';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($userId, $message, $lien = null) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (user_id, message, lien) VALUES (:user_id, :message, :lien)"
        );
        return $stmt->execute([':user_id' => $userId, ':message' => $message, ':lien' => $lien]);
    }

    public function getNonLues($userId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table} WHERE user_id = :user_id AND lu = 0 ORDER BY date_creation DESC"
        );
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function marquerLue($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET lu = 1 WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}