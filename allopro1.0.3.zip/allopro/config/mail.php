<?php
// Les paramètres SMTP se trouvent dans la rubrique de configuration/aide de votre fournisseur
// de messagerie (souvent intitulée « SMTP », « Serveur de courrier sortant » ou « Identifiants SMTP/API ») :
// - ALLOPRO_SMTP_HOST : nom du serveur SMTP indiqué par le fournisseur (ex. smtp.exemple.com).
// - ALLOPRO_SMTP_PORT : port indiqué pour ce serveur et ce mode de chiffrement ; souvent 587 avec TLS
//   ou 465 avec SSL. Respectez la combinaison exacte fournie par votre service.
// - ALLOPRO_SMTP_SECURITY : mode de chiffrement correspondant, « tls » ou « ssl ».
// - ALLOPRO_SMTP_USERNAME : identifiant SMTP indiqué par le fournisseur ; souvent l’adresse complète
//   de la boîte mail, mais certains services donnent un identifiant SMTP/API dédié.
// - ALLOPRO_SMTP_PASSWORD : mot de passe d’application/de boîte mail ou identifiant SMTP généré
//   depuis l’espace fournisseur. Il peut être différent du mot de passe habituel du compte.
// - ALLOPRO_MAIL_FROM : adresse d’expédition vérifiée ou autorisée dans l’espace fournisseur.
// - ALLOPRO_MAIL_FROM_NAME : nom affiché aux destinataires (par exemple « ALLÔ PRO »).
// - ALLOPRO_BASE_URL : URL publique du répertoire /public de l’application, sans barre finale
//   (ex. https://allo-pro.com/allopro/public). Définissez une URL locale dans l’environnement WAMP.
// Définissez ces valeurs dans l’environnement du processus PHP/Apache. Ne mettez jamais
// les identifiants SMTP dans le code ni dans le dépôt.
return [
    'smtp_host' => getenv('ALLOPRO_SMTP_HOST') ?: 'smtp.gmail.com',
    'smtp_port' => (int) (getenv('ALLOPRO_SMTP_PORT') ?: 587),
    'smtp_security' => strtolower(getenv('ALLOPRO_SMTP_SECURITY') ?: 'tls'),
    'smtp_username' => getenv('ALLOPRO_SMTP_USERNAME') ?: 'allopro.dakar@gmail.com',
    'smtp_password' => getenv('ALLOPRO_SMTP_PASSWORD') ?: 'ravryafgqlvmdbqo',
    'from_email' => getenv('ALLOPRO_MAIL_FROM') ?: (getenv('ALLOPRO_SMTP_USERNAME') ?: 'allopro.dakar@gmail.com'),
    'from_name' => getenv('ALLOPRO_MAIL_FROM_NAME') ?: 'ALLÔ PRO',
    'base_url' => rtrim(getenv('ALLOPRO_BASE_URL') ?: 'https://allo-pro.com/allopro/public', '/'),
];
