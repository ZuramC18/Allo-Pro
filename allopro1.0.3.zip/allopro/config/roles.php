<?php
const ROLES_INTERNES = ['conseiller', 'coordinateur', 'qualite', 'finance', 'admin'];

const LIBELLES_ROLES = [
    'client'       => 'Client',
    'conseiller'   => 'Conseiller',
    'coordinateur' => 'Coordinateur',
    'qualite'      => 'Qualité / SAV',
    'finance'      => 'Finance',
    'admin'        => 'Administrateur',
];

const DESCRIPTIONS_ROLES = [
    'conseiller'   => 'Qualifier, suivre, relancer, assister les clients',
    'coordinateur' => 'Auditer les partenaires, affecter les missions',
    'qualite'      => 'Traiter incidents, mauvaises notes et reprises',
    'finance'      => 'Paiements, reversements, marges et reporting',
    'admin'        => 'Paramétrer tout le système',
];

// Modules attribuables aux rôles
const MODULES = [
    'tableau_bord'  => 'Tableau de bord',
    'statistiques'  => 'Statistiques',
    'demandes'      => 'Demandes & attribution',
    'messagerie'    => 'Messagerie clients',
    'messagerie_interne' => 'Messagerie interne (partenaires/techniciens)',
    'coordination'  => 'Coordination des conversations',
    'interventions' => 'Interventions (supervision)',
    'sav'           => 'SAV',
    'paiements'     => 'Paiements',
    'reversements'  => 'Reversements',
    'clients'       => 'Clients',
    'partenaires'   => 'Partenaires',
    'techniciens'   => 'Techniciens',
    'categories'    => 'Catégories & tarifs',
    'abonnements'   => 'Abonnements & Pass',
];

// Jamais attribuables : sinon un rôle pourrait se promouvoir administrateur ou changer la commission
const MODULES_ADMIN_SEULEMENT = ['equipe', 'parametres', 'roles', 'audit'];
