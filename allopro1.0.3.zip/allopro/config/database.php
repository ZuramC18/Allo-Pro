<?php
// Affichage des erreurs uniquement en local — jamais en production
if (in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

class Database {
    private $host = "localhost";
    private $db_name = "allopro";
    private $username = "root";
    private $password = "";      // par défaut vide sous WAMP
    private $charset = "utf8mb4";
    public $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset={$this->charset}";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,       // les erreurs SQL lèvent des exceptions
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,  // résultats en tableaux associatifs
                PDO::ATTR_EMULATE_PREPARES => false                // vraies requêtes préparées côté MySQL
            ];
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $e) {
            die("Erreur de connexion à la base : " . $e->getMessage());
        }

        return $this->conn;
    }
}