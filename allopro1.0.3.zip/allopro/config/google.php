<?php
define('GOOGLE_CLIENT_ID', '202052966865-k9vuohvkurrf20a7qcvtjvms9cbp9hi1.apps.googleusercontent.com');
// Surcharger avec ALLOPRO_GOOGLE_LOGIN_URI pour l’environnement local ou un autre domaine.
define(
    'GOOGLE_LOGIN_URI',
    rtrim(getenv('ALLOPRO_GOOGLE_LOGIN_URI') ?: 'https://allo-pro.com/allopro/public/auth-google.php', '/')
);
