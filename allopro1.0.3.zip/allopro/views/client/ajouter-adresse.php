<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Adresse.php';

$adresseModel = new Adresse();
$userId = (int) $_SESSION['user_id'];
$erreur = '';
$succes = '';
$libelleSaisi = '';
$quartierSaisi = '';
$villeSaisie = 'Dakar';
$detailsSaisis = '';

if (empty($_SESSION['csrf_adresses'])) {
    $_SESSION['csrf_adresses'] = bin2hex(random_bytes(32));
}

if (($_GET['succes'] ?? '') === 'ajoutee') {
    $succes = 'Adresse enregistrée. Vous pourrez la sélectionner lors de votre prochaine demande.';
} elseif (($_GET['succes'] ?? '') === 'supprimee') {
    $succes = 'Adresse supprimée de votre liste.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_adresses'], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page et réessayez.';
    } elseif (($_POST['action'] ?? '') === 'supprimer') {
        $adresseId = filter_var($_POST['adresse_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($adresseId === false) {
            $erreur = 'Cette adresse ne peut pas être supprimée.';
        } elseif (!$adresseModel->supprimer($adresseId, $userId)) {
            $erreur = 'Cette adresse est introuvable ou a déjà été supprimée.';
        } else {
            header('Location: ajouter-adresse.php?succes=supprimee');
            exit;
        }
    } elseif (($_POST['action'] ?? '') === 'ajouter') {
        $libelleSaisi = trim(is_string($_POST['libelle'] ?? null) ? $_POST['libelle'] : '');
        $quartierSaisi = trim(is_string($_POST['quartier'] ?? null) ? $_POST['quartier'] : '');
        $villeSaisie = trim(is_string($_POST['ville'] ?? null) ? $_POST['ville'] : '');
        $detailsSaisis = trim(is_string($_POST['details'] ?? null) ? $_POST['details'] : '');

        if ($libelleSaisi === '' || $quartierSaisi === '' || $villeSaisie === '') {
            $erreur = 'Le libellé, le quartier et la ville sont obligatoires.';
        } elseif (mb_strlen($libelleSaisi) > 100 || mb_strlen($quartierSaisi) > 100 || mb_strlen($villeSaisie) > 100) {
            $erreur = 'Le libellé, le quartier et la ville ne doivent pas dépasser 100 caractères.';
        } else {
            if (!$adresseModel->create($userId, $libelleSaisi, $quartierSaisi, $villeSaisie, $detailsSaisis)) {
                throw new RuntimeException('L’enregistrement de l’adresse a échoué.');
            }
            header('Location: ajouter-adresse.php?succes=ajoutee');
            exit;
        }
    } else {
        $erreur = 'La demande n’a pas pu être traitée. Rechargez la page et réessayez.';
    }
}

$mesAdresses = $adresseModel->getByUser($userId);
$nombreAdresses = count($mesAdresses);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes adresses — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/adresses.css?v=<?= filemtime(__DIR__ . '/../../public/css/adresses.css') ?>">
    <link rel="stylesheet" href="../../public/css/adresses-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/adresses-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client adresses-page">
    <header class="adresses-entete">
        <div>
            <p class="adresses-entete__sur-titre">VOS LIEUX DE SERVICE</p>
            <h1>Mes adresses</h1>
            <p class="adresses-entete__description">Enregistrez vos lieux habituels pour les retrouver facilement lors d’une demande.</p>
        </div>
        <a class="adresses-entete__retour" href="profil.php">
            <span aria-hidden="true">←</span>
            Retour au profil
        </a>
    </header>

    <?php if ($succes !== ''): ?>
        <div class="adresses-alerte adresses-alerte--succes" role="status">
            <span aria-hidden="true">✓</span>
            <?= htmlspecialchars($succes, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>
    <?php if ($erreur !== ''): ?>
        <div class="adresses-alerte adresses-alerte--erreur" role="alert">
            <span aria-hidden="true">!</span>
            <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <div class="adresses-resume">
        <div class="adresses-resume__icone" aria-hidden="true">
            <svg viewBox="0 0 24 24"><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.3"/></svg>
        </div>
        <div>
            <strong><?= $nombreAdresses ?> adresse<?= $nombreAdresses === 1 ? '' : 's' ?> enregistrée<?= $nombreAdresses === 1 ? '' : 's' ?></strong>
            <span><?= $nombreAdresses > 0 ? 'Vos lieux sont prêts à être utilisés pour une nouvelle demande.' : 'Ajoutez votre domicile, votre bureau ou un autre lieu habituel.' ?></span>
        </div>
    </div>

    <div class="adresses-contenu">
        <section class="adresses-liste-carte" aria-labelledby="adresses-liste-titre">
            <div class="adresses-section-entete">
                <div>
                    <h2 id="adresses-liste-titre">Lieux enregistrés</h2>
                    <p>Consultez ou retirez une adresse de votre liste.</p>
                </div>
                <?php if ($nombreAdresses > 0): ?>
                    <span class="adresses-compteur"><?= $nombreAdresses ?></span>
                <?php endif; ?>
            </div>

            <?php if ($nombreAdresses === 0): ?>
                <div class="adresses-vide">
                    <div class="adresses-vide__icone" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.3"/></svg>
                    </div>
                    <h3>Aucun lieu enregistré pour le moment</h3>
                    <p>Ajoutez une adresse avec le formulaire. Elle sera disponible lors de vos prochaines demandes de service.</p>
                    <a href="#nouvelle-adresse" class="adresses-vide__action">Ajouter une adresse</a>
                </div>
            <?php else: ?>
                <div class="adresses-liste">
                    <?php foreach ($mesAdresses as $adr): ?>
                        <article class="adresse-item">
                            <div class="adresse-item__pin" aria-hidden="true">
                                <svg viewBox="0 0 24 24"><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.3"/></svg>
                            </div>
                            <div class="adresse-item__infos">
                                <h3 class="adresse-item__libelle"><?= htmlspecialchars((string) $adr['libelle'], ENT_QUOTES, 'UTF-8') ?></h3>
                                <p class="adresse-item__detail">
                                    <?= htmlspecialchars((string) $adr['quartier'], ENT_QUOTES, 'UTF-8') ?>
                                    <span aria-hidden="true">·</span>
                                    <?= htmlspecialchars((string) $adr['ville'], ENT_QUOTES, 'UTF-8') ?>
                                </p>
                                <?php if (!empty($adr['details'])): ?>
                                    <p class="adresse-item__notes"><?= htmlspecialchars((string) $adr['details'], ENT_QUOTES, 'UTF-8') ?></p>
                                <?php endif; ?>
                            </div>
                            <form method="POST" class="adresse-item__actions" onsubmit="return confirm('Supprimer cette adresse de votre liste ?');">
                                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_adresses'], ENT_QUOTES, 'UTF-8') ?>">
                                <input type="hidden" name="action" value="supprimer">
                                <input type="hidden" name="adresse_id" value="<?= (int) $adr['id'] ?>">
                                <button type="submit" class="adresse-item__supprimer" aria-label="Supprimer l’adresse <?= htmlspecialchars((string) $adr['libelle'], ENT_QUOTES, 'UTF-8') ?>">
                                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/></svg>
                                    <span>Supprimer</span>
                                </button>
                            </form>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="adresse-form-carte" id="nouvelle-adresse" aria-labelledby="adresse-form-titre">
            <div class="adresses-section-entete">
                <div>
                    <h2 id="adresse-form-titre">Ajouter un lieu</h2>
                    <p>Renseignez l’adresse où nos équipes pourront intervenir.</p>
                </div>
                <div class="adresse-form-carte__icone" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                </div>
            </div>

            <form method="POST" class="adresse-formulaire">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_adresses'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="action" value="ajouter">
                <div class="adresse-formulaire__rangee">
                    <div class="adresse-formulaire__champ">
                        <label for="libelle">Nom du lieu <span>Obligatoire</span></label>
                        <input type="text" id="libelle" name="libelle" placeholder="Ex. Domicile, Bureau" value="<?= htmlspecialchars($libelleSaisi, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" autocomplete="off" required>
                    </div>
                    <div class="adresse-formulaire__champ">
                        <label for="quartier">Quartier <span>Obligatoire</span></label>
                        <input type="text" id="quartier" name="quartier" placeholder="Ex. Plateau, Almadies" value="<?= htmlspecialchars($quartierSaisi, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" autocomplete="address-level3" required>
                    </div>
                </div>
                <div class="adresse-formulaire__champ">
                    <label for="ville">Ville <span>Obligatoire</span></label>
                    <input type="text" id="ville" name="ville" value="<?= htmlspecialchars($villeSaisie, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" autocomplete="address-level2" required>
                </div>
                <div class="adresse-formulaire__champ">
                    <label for="details">Précisions <span>Facultatif</span></label>
                    <textarea id="details" name="details" rows="4" placeholder="Repère proche, étage, couleur du portail…" aria-describedby="adresse-details-aide"><?= htmlspecialchars($detailsSaisis, ENT_QUOTES, 'UTF-8') ?></textarea>
                    <small id="adresse-details-aide">Ces indications aideront l’intervenant à trouver le lieu plus facilement.</small>
                </div>
                <button type="submit" class="adresse-formulaire__bouton">
                    Enregistrer l’adresse
                    <span aria-hidden="true">→</span>
                </button>
            </form>
        </section>
    </div>
</main>
</body>
</html>
