<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Paiement.php';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$reference = $_GET['reference'] ?? '';
$reference = is_string($reference) ? trim($reference) : '';
$paiement = null;

if ($reference !== '' && strlen($reference) <= 100) {
    $paiement = (new Paiement())->getByReferenceForClient($reference, (int) $_SESSION['user_id']);
}

$statut = $paiement['statut'] ?? null;
$etats = [
    'valide' => [
        'classe' => 'succes',
        'icone' => 'check',
        'tag' => 'Paiement validé',
        'titre' => 'Paiement confirmé',
        'message' => 'Votre règlement a bien été confirmé. Le paiement est enregistré pour cette intervention.',
    ],
    'en_attente' => [
        'classe' => 'attente',
        'icone' => 'clock',
        'tag' => 'Vérification en cours',
        'titre' => 'Paiement en cours de confirmation',
        'message' => 'Nous attendons la confirmation de votre paiement. Cette page se mettra à jour automatiquement.',
    ],
    'echoue' => [
        'classe' => 'echec',
        'icone' => 'cross',
        'tag' => 'Paiement non abouti',
        'titre' => 'Le paiement n’a pas abouti',
        'message' => 'Aucun règlement n’a été confirmé pour cette tentative. Vous pouvez réessayer depuis le dossier.',
    ],
];
$etat = $etats[$statut] ?? null;
$introuvable = !$paiement || !$etat;
$methode = $paiement
    ? ['wave' => 'Wave', 'orange_money' => 'Orange Money'][$paiement['methode']] ?? 'Paiement mobile'
    : '';

if ($statut === 'en_attente') {
    header('Refresh: 15');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $introuvable ? 'Paiement introuvable' : h($etat['titre']) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/paiement-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/paiement-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
</head>
<body class="page-paiement page-paiement-resultat">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client paiement-page paiement-resultat">
    <?php if ($introuvable): ?>
        <section class="paiement-resultat__carte paiement-resultat__carte--introuvable" aria-labelledby="titre-resultat">
            <span class="paiement-resultat__symbole" aria-hidden="true">
                <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5m0 4h.01"/></svg>
            </span>
            <span class="paiement-resultat__tag">Référence non reconnue</span>
            <h1 id="titre-resultat">Paiement introuvable</h1>
            <p>Cette référence ne correspond à aucun paiement de votre compte. Vérifiez le lien ou consultez vos demandes.</p>
            <a href="mes-demandes.php" class="paiement-resultat__bouton">Voir mes demandes</a>
        </section>
    <?php else: ?>
        <section class="paiement-resultat__carte paiement-resultat__carte--<?= h($etat['classe']) ?>" aria-labelledby="titre-resultat">
            <span class="paiement-resultat__symbole" aria-hidden="true">
                <?php if ($etat['icone'] === 'check'): ?>
                    <svg viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7"/></svg>
                <?php elseif ($etat['icone'] === 'clock'): ?>
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                <?php else: ?>
                    <svg viewBox="0 0 24 24"><path d="m7 7 10 10M17 7 7 17"/></svg>
                <?php endif; ?>
            </span>

            <span class="paiement-resultat__tag"><?= h($etat['tag']) ?></span>
            <h1 id="titre-resultat"><?= h($etat['titre']) ?></h1>
            <p class="paiement-resultat__message"><?= h($etat['message']) ?></p>

            <div class="paiement-resultat__details">
                <div>
                    <span>Dossier</span>
                    <strong><?= h($paiement['numero_dossier']) ?></strong>
                </div>
                <div>
                    <span>Moyen de paiement</span>
                    <strong><?= h($methode) ?></strong>
                </div>
                <div class="paiement-resultat__montant">
                    <span>Montant</span>
                    <strong><?= number_format((float) $paiement['montant'], 0, ',', ' ') ?> <small>FCFA</small></strong>
                </div>
            </div>

            <?php if ($statut === 'en_attente'): ?>
                <p class="paiement-resultat__actualisation">
                    Vérification automatique toutes les 15 secondes. Vous pouvez aussi actualiser maintenant.
                </p>
                <a href="paiement-succes.php?reference=<?= rawurlencode($reference) ?>" class="paiement-resultat__bouton">
                    Actualiser le statut
                </a>
            <?php elseif ($statut === 'echoue'): ?>
                <a href="payer.php?id=<?= (int) $paiement['demande_id'] ?>" class="paiement-resultat__bouton">
                    Réessayer le paiement
                </a>
            <?php else: ?>
                <a href="detail-demande.php?id=<?= (int) $paiement['demande_id'] ?>" class="paiement-resultat__bouton">
                    Voir le détail de ma demande
                </a>
            <?php endif; ?>

            <a href="mes-demandes.php" class="paiement-resultat__lien">Retour à mes demandes</a>
        </section>
    <?php endif; ?>
</main>
</body>
</html>
