<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/Paiement.php';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$demande = $id ? (new Demande())->getById($id) : null;

if (!$demande || (int) $demande['client_id'] !== (int) $_SESSION['user_id']) {
    http_response_code(404);
    die("Cette demande est introuvable.");
}

$paiementModel = new Paiement();
if ($demande['statut'] !== 'terminee' || $demande['mode_paiement'] !== 'normal'
    || !isset($demande['montant']) || (float) $demande['montant'] <= 0
    || $paiementModel->getPassParDemande($id)) {
    header("Location: detail-demande.php?id=" . $id);
    exit;
}

$paiementExistant = $paiementModel->getByDemandeId($id);
if ($paiementExistant && $paiementExistant['statut'] === 'valide') {
    header("Location: detail-demande.php?id=" . $id);
    exit;
}

if (empty($_SESSION['csrf_paiement'])) {
    $_SESSION['csrf_paiement'] = bin2hex(random_bytes(32));
}

$methodesPaiement = [
    'wave' => 'Wave',
    'orange_money' => 'Orange Money'
];
$erreur = '';
$methodeSelectionnee = in_array($_POST['methode'] ?? '', array_keys($methodesPaiement), true)
    ? $_POST['methode']
    : ($paiementExistant['methode'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $methode = $_POST['methode'] ?? '';

    if (!hash_equals($_SESSION['csrf_paiement'], $csrf)) {
        $erreur = "Votre session a expiré. Actualisez la page puis réessayez.";
    } elseif (!isset($methodesPaiement[$methode])) {
        $erreur = "Choisissez Wave ou Orange Money pour continuer.";
    } else {
        $methodeSelectionnee = $methode;
        $reference = $paiementExistant
            && $paiementExistant['statut'] === 'en_attente'
            && $paiementExistant['methode'] === $methode
            ? $paiementExistant['reference_transaction']
            : $paiementModel->create($id, $demande['montant'], $methode);

        $page = $methode === 'wave' ? 'simulation-wave.php' : 'simulation-orange.php';
        header("Location: /allopro/public/{$page}?reference=" . urlencode($reference)
            . "&montant=" . urlencode((string) $demande['montant']));
        exit;
    }
}

$methodeEnAttente = $paiementExistant && $paiementExistant['statut'] === 'en_attente'
    ? ($methodesPaiement[$paiementExistant['methode']] ?? null)
    : null;
$paiementEchoue = $paiementExistant && $paiementExistant['statut'] === 'echoue';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paiement de la demande <?= h($demande['numero_dossier']) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/paiement-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/paiement-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
</head>
<body class="page-paiement">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client paiement-page">
    <a class="paiement-retour" href="detail-demande.php?id=<?= (int) $id ?>">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5m7 7-7-7 7-7"/></svg>
        Retour au dossier
    </a>

    <header class="paiement-hero">
        <span class="paiement-etape">Règlement de l'intervention</span>
        <h1>Finalisez votre paiement</h1>
        <p>Choisissez votre moyen de paiement mobile pour régler cette intervention.</p>
    </header>

    <?php if ($erreur): ?>
        <div class="paiement-alerte paiement-alerte--erreur" role="alert"><?= h($erreur) ?></div>
    <?php endif; ?>

    <?php if ($methodeEnAttente): ?>
        <div class="paiement-alerte paiement-alerte--attente" role="status">
            <span class="paiement-alerte__icone" aria-hidden="true">i</span>
            <span>Un paiement avec <?= h($methodeEnAttente) ?> est déjà en attente. Vous pouvez reprendre avec ce moyen ou en choisir un autre.</span>
        </div>
    <?php elseif ($paiementEchoue): ?>
        <div class="paiement-alerte paiement-alerte--erreur" role="status">
            Le dernier paiement n'a pas abouti. Choisissez un moyen de paiement pour réessayer.
        </div>
    <?php endif; ?>

    <div class="paiement-grille">
        <section class="paiement-carte paiement-carte--choix" aria-labelledby="titre-moyen-paiement">
            <div class="paiement-section-entete">
                <span class="paiement-section-numero">1</span>
                <div>
                    <h2 id="titre-moyen-paiement">Moyen de paiement</h2>
                    <p>Sélectionnez une option ci-dessous.</p>
                </div>
            </div>

            <form method="POST" class="paiement-formulaire">
                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf_paiement']) ?>">

                <fieldset class="paiement-methodes">
                    <legend class="visuellement-cache">Choisissez votre moyen de paiement</legend>

                    <label class="paiement-methode paiement-methode--wave <?= $methodeSelectionnee === 'wave' ? 'paiement-methode--selectionnee' : '' ?>">
                        <input type="radio" name="methode" value="wave" <?= $methodeSelectionnee === 'wave' ? 'checked' : '' ?> required>
                        <span class="paiement-methode__logo paiement-methode__logo--wave" aria-hidden="true">
                            <svg viewBox="0 0 32 32"><path d="M5 17.5c3.1-5.4 6.3-5.4 9.4 0s6.3 5.4 9.4 0 3.1-5.4 4.7-5.4"/></svg>
                        </span>
                        <span class="paiement-methode__texte">
                            <strong>Wave</strong>
                            <small>Paiement mobile</small>
                        </span>
                        <span class="paiement-methode__radio" aria-hidden="true"></span>
                    </label>

                    <label class="paiement-methode paiement-methode--orange <?= $methodeSelectionnee === 'orange_money' ? 'paiement-methode--selectionnee' : '' ?>">
                        <input type="radio" name="methode" value="orange_money" <?= $methodeSelectionnee === 'orange_money' ? 'checked' : '' ?> required>
                        <span class="paiement-methode__logo paiement-methode__logo--orange" aria-hidden="true">
                            <svg viewBox="0 0 32 32"><path d="M16 4.5 27.5 16 16 27.5 4.5 16 16 4.5Z"/><path d="M16 10v12m-6-6h12"/></svg>
                        </span>
                        <span class="paiement-methode__texte">
                            <strong>Orange Money</strong>
                            <small>Paiement mobile</small>
                        </span>
                        <span class="paiement-methode__radio" aria-hidden="true"></span>
                    </label>
                </fieldset>

                <div class="paiement-securite">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 5 6v5c0 4.6 2.9 8.2 7 10 4.1-1.8 7-5.4 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/></svg>
                    <span>Le paiement est réalisé sur la page de la méthode choisie. ALLÔ PRO ne vous demandera jamais votre code secret ici.</span>
                </div>

                <button type="submit" class="paiement-bouton" id="paiement-confirmer">
                    <span>Continuer vers le paiement</span>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
                </button>
                <p class="paiement-note">Vous vérifierez le montant avant de confirmer sur l'écran suivant.</p>
            </form>
        </section>

        <aside class="paiement-carte paiement-recap" aria-labelledby="titre-recapitulatif">
            <div class="paiement-recap__entete">
                <span class="paiement-recap__icone" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><path d="M4 5.5h16v13H4z"/><path d="M4 9h16m-12 5h4"/></svg>
                </span>
                <div>
                    <span>Récapitulatif</span>
                    <h2 id="titre-recapitulatif">Votre paiement</h2>
                </div>
            </div>

            <div class="paiement-recap__dossier">
                <span>Numéro de dossier</span>
                <strong><?= h($demande['numero_dossier']) ?></strong>
            </div>
            <div class="paiement-recap__ligne">
                <span>Intervention</span>
                <strong><?= h($demande['categorie_nom']) ?></strong>
            </div>
            <div class="paiement-recap__separateur"></div>
            <div class="paiement-recap__total">
                <span>Montant à régler</span>
                <strong><?= number_format((float) $demande['montant'], 0, ',', ' ') ?><small> FCFA</small></strong>
            </div>
            <p class="paiement-recap__info">
                Ce montant a été fixé à la clôture de votre intervention. Aucun frais supplémentaire ne sera ajouté par ALLÔ PRO.
            </p>
        </aside>
    </div>

    <footer class="paiement-pied">
        <span aria-hidden="true">?</span>
        <p>Besoin d'aide ? <a href="messagerie.php">Contactez notre équipe</a>.</p>
    </footer>
</main>

<script>
document.querySelectorAll('.paiement-methode input').forEach(function (radio) {
    radio.addEventListener('change', function () {
        document.querySelectorAll('.paiement-methode').forEach(function (methode) {
            methode.classList.toggle('paiement-methode--selectionnee', methode.contains(radio) && radio.checked);
        });
    });
});

document.querySelector('.paiement-formulaire').addEventListener('submit', function () {
    var bouton = document.getElementById('paiement-confirmer');
    bouton.disabled = true;
    bouton.querySelector('span').textContent = 'Préparation du paiement…';
});
</script>
</body>
</html>
