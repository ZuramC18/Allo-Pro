<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Abonnement.php';

// Échappement HTML sûr (accepte null)
if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$abonnementModel = new Abonnement();
$clientId = (int) $_SESSION['user_id'];

// Moyens de paiement acceptés (clé envoyée par le formulaire => libellé affiché)
$methodesPaiement = ['wave' => 'Wave', 'orange_money' => 'Orange Money'];

$tousPassTypes = $abonnementModel->getPassTypes();
$erreur = null;

// ---------- Achat d'un Pass ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pass_type_id'])) {
    $passTypeId = (int) $_POST['pass_type_id'];
    $methode = $_POST['methode'] ?? '';

    // Le Pass doit exister ET être actif (on ne fait pas confiance au formulaire)
    $type = null;
    foreach ($tousPassTypes as $pt) {
        if ((int) $pt['id'] === $passTypeId && $pt['statut'] === 'actif') { $type = $pt; break; }
    }

    if (!$type) {
        $erreur = "Ce Pass n'est plus disponible.";
    } elseif (!isset($methodesPaiement[$methode])) {
        $erreur = "Choisissez un moyen de paiement.";
    } else {
        $reference = $abonnementModel->creerAchatPass($clientId, $passTypeId);
        $page = $methode === 'wave' ? 'simulation-wave.php' : 'simulation-orange.php';
        header("Location: /allopro/public/{$page}?reference=" . urlencode($reference) . "&montant=" . urlencode($type['prix']) . "&type=pass");
        exit;
    }
}

$mesPass = $abonnementModel->getPassDisponiblesClient($clientId);
$typesActifs = array_values(array_filter($tousPassTypes, fn($t) => $t['statut'] === 'actif'));
$nbTypes = count($typesActifs);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pass Intervention — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/pass-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/pass-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/pass-animations.css">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
    <script>document.documentElement.classList.add('js');</script>
</head>
<body class="page-pass">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client pass-page">

    <!-- ===== En-tête ===== -->
    <header class="pass-hero">
        <span class="pass-tag">Sans engagement</span>
        <h1 class="pass-hero__titre">Le Pass Intervention</h1>
        <p class="pass-hero__texte">Payez une intervention à l'unité, à l'avance et au meilleur prix. Idéal si vous n'avez pas d'abonnement.</p>
        <ul class="pass-garanties">
            <li><span class="pass-check">✓</span> Sans engagement</li>
            <li><span class="pass-check">✓</span> Activé dès le paiement</li>
            <li><span class="pass-check">✓</span> Wave et Orange Money</li>
        </ul>
    </header>

    <?php if (isset($_GET['succes'])): ?>
        <div class="pass-alerte pass-alerte--succes" role="status">✓ Pass activé — il sera utilisé automatiquement lors de votre prochaine intervention.</div>
    <?php endif; ?>

    <?php if ($erreur): ?>
        <div class="pass-alerte pass-alerte--erreur" role="alert"><?= h($erreur) ?></div>
    <?php endif; ?>

    <!-- ===== Pass déjà possédés ===== -->
    <?php if (!empty($mesPass)): ?>
        <section class="pass-section" aria-labelledby="titre-mes-pass">
            <div class="pass-section__entete">
                <h2 class="pass-section__titre" id="titre-mes-pass">Vos Pass disponibles</h2>
                <span class="pass-compteur" data-compte="<?= count($mesPass) ?>"><?= count($mesPass) ?></span>
            </div>
            <div class="pass-possedes">
                <?php foreach ($mesPass as $i => $p): ?>
                    <article class="pass-possede reveal" style="--i:<?= (int) $i ?>">
                        <div class="pass-possede__icone" aria-hidden="true">🎫</div>
                        <div class="pass-possede__infos">
                            <span class="pass-possede__nom"><?= h($p['nom']) ?></span>
                            <?php if (!empty($p['date_achat'])): ?>
                                <span class="pass-possede__date">Acheté le <?= date('d/m/Y', strtotime($p['date_achat'])) ?></span>
                            <?php endif; ?>
                        </div>
                        <span class="pass-pill pass-pill--ok">Disponible</span>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- ===== Comment ça marche ===== -->
    <section class="pass-section" aria-labelledby="titre-etapes">
        <h2 class="pass-section__titre pass-section__titre--centre" id="titre-etapes">Comment ça marche ?</h2>
        <ol class="pass-etapes">
            <li class="pass-etape reveal" style="--i:0">
                <h3 class="pass-etape__titre">Choisissez votre Pass</h3>
                <p class="pass-etape__texte">Sélectionnez la formule qui correspond à votre besoin.</p>
            </li>
            <li class="pass-etape reveal" style="--i:1">
                <h3 class="pass-etape__titre">Payez en quelques secondes</h3>
                <p class="pass-etape__texte">Réglez avec Wave ou Orange Money. Le Pass est activé dès la confirmation.</p>
            </li>
            <li class="pass-etape reveal" style="--i:2">
                <h3 class="pass-etape__titre">Utilisez-le automatiquement</h3>
                <p class="pass-etape__texte">À la fin de votre intervention, votre Pass est appliqué : plus rien à payer.</p>
            </li>
        </ol>
    </section>

    <!-- ===== Tarifs ===== -->
    <section class="pass-section" id="tarifs" aria-labelledby="titre-tarifs">
        <h2 class="pass-section__titre pass-section__titre--centre" id="titre-tarifs">Choisissez votre Pass</h2>

        <?php if (empty($typesActifs)): ?>
            <div class="pass-vide reveal">Aucun Pass n'est disponible pour le moment. Revenez bientôt !</div>
        <?php else: ?>
            <div class="pass-grille">
                <?php foreach ($typesActifs as $i => $t):
                    $estRecommande = $nbTypes >= 3 && $i === intdiv($nbTypes, 2);

                    // Catégories couvertes par le Pass
                    if (!empty($t['categorie_nom'])) {
                        $texteCategorie = 'Valable pour : ' . $t['categorie_nom'];
                    } elseif (empty($t['categorie_id'])) {
                        $texteCategorie = 'Toutes catégories de service';
                    } else {
                        $texteCategorie = 'Catégorie de service dédiée';
                    }
                ?>
                    <article class="pass-carte reveal <?= $estRecommande ? 'pass-carte--recommandee' : '' ?>" style="--i:<?= (int) $i ?>">
                        <?php if ($estRecommande): ?><div class="pass-carte__badge">★ Le plus choisi</div><?php endif; ?>

                        <h3 class="pass-carte__nom"><?= h($t['nom']) ?></h3>
                        <div class="pass-carte__prix">
                            <span class="pass-carte__montant"><?= number_format((float) $t['prix'], 0, ',', ' ') ?></span>
                            <span class="pass-carte__devise">FCFA</span>
                            <span class="pass-carte__periode">/ intervention</span>
                        </div>
                        <?php if (!empty($t['description'])): ?>
                            <p class="pass-carte__desc"><?= h($t['description']) ?></p>
                        <?php endif; ?>

                        <ul class="pass-carte__liste">
                            <li><span class="pass-check">✓</span> 1 intervention incluse</li>
                            <li><span class="pass-check">✓</span> <?= h($texteCategorie) ?></li>
                            <li><span class="pass-check">✓</span> Appliqué automatiquement</li>
                            <li><span class="pass-check">✓</span> Sans engagement</li>
                        </ul>

                        <form method="POST" class="pass-form">
                            <input type="hidden" name="pass_type_id" value="<?= (int) $t['id'] ?>">

                            <fieldset class="pass-methodes">
                                <legend>Payer avec</legend>
                                <?php foreach ($methodesPaiement as $cle => $libelle): $idChamp = 'methode-' . (int) $t['id'] . '-' . $cle; ?>
                                    <label class="pass-methode" for="<?= h($idChamp) ?>">
                                        <input type="radio" name="methode" id="<?= h($idChamp) ?>" value="<?= h($cle) ?>" required>
                                        <span class="pass-methode__corps pass-methode__corps--<?= h($cle) ?>"><?= h($libelle) ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </fieldset>

                            <button type="submit" class="pass-carte__bouton <?= $estRecommande ? 'pass-carte__bouton--plein' : '' ?>">Acheter ce Pass</button>
                        </form>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== FAQ ===== -->
    <section class="pass-section" aria-labelledby="titre-faq">
        <h2 class="pass-section__titre pass-section__titre--centre" id="titre-faq">Questions fréquentes</h2>
        <div class="pass-faq reveal">
            <details>
                <summary>Qu'est-ce qu'un Pass Intervention ?</summary>
                <p>C'est une intervention achetée à l'avance. Vous ne vous engagez à rien : vous payez uniquement le Pass que vous choisissez.</p>
            </details>
            <details>
                <summary>Quand mon Pass est-il utilisé ?</summary>
                <p>À la fin d'une intervention, si vous avez un Pass disponible, il est appliqué automatiquement : vous n'avez plus rien à payer. Si vous en avez plusieurs, le plus ancien est utilisé en premier.</p>
            </details>
            <details>
                <summary>Quand mon Pass est-il actif ?</summary>
                <p>Dès que votre paiement est confirmé. Il apparaît alors dans « Vos Pass disponibles » en haut de cette page.</p>
            </details>
            <details>
                <summary>Quels moyens de paiement sont acceptés ?</summary>
                <p>Vous pouvez régler votre Pass avec Wave ou Orange Money.</p>
            </details>
        </div>
    </section>
</main>

<script>
(function () {
    var reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Apparition au défilement
    var els = document.querySelectorAll('.reveal');
    if (reduit || !('IntersectionObserver' in window)) {
        els.forEach(function (e) { e.classList.add('reveal--visible'); });
    } else {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) { en.target.classList.add('reveal--visible'); io.unobserve(en.target); }
            });
        }, { threshold: 0.12 });
        els.forEach(function (e) { io.observe(e); });
    }

    // Compteur animé (nombre de Pass disponibles)
    if (!reduit) {
        document.querySelectorAll('[data-compte]').forEach(function (el) {
            var cible = parseInt(el.dataset.compte, 10) || 0, debut = null;
            if (cible < 2) return;
            el.textContent = '0';
            function pas(t) {
                if (!debut) debut = t;
                var p = Math.min((t - debut) / 800, 1);
                el.textContent = Math.round(cible * (1 - Math.pow(1 - p, 3)));
                if (p < 1) requestAnimationFrame(pas);
            }
            requestAnimationFrame(pas);
        });
    }

    // Évite le double achat : le bouton se bloque après le premier clic
    document.querySelectorAll('.pass-form').forEach(function (form) {
        var bouton = form.querySelector('button[type="submit"]');
        var texteInitial = bouton.textContent;
        form.addEventListener('submit', function () {
            bouton.disabled = true;
            bouton.classList.add('est-envoi');
            bouton.textContent = 'Redirection vers le paiement…';
        });
        // Retour arrière du navigateur : on remet le bouton en état
        window.addEventListener('pageshow', function (e) {
            if (e.persisted) { bouton.disabled = false; bouton.classList.remove('est-envoi'); bouton.textContent = texteInitial; }
        });
    });
})();
</script>
</body>
</html>