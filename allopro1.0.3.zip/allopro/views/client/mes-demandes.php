<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/Note.php';

if (!function_exists('h')) {
    function h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
}

require_once __DIR__ . '/../../includes/icones.php';

$demandeModel = new Demande();
$noteModel    = new Note();
$clientId     = (int) $_SESSION['user_id'];

$toutesLesDemandes = $demandeModel->getByClient($clientId);

$statutsValides = ['toutes', 'nouvelle', 'attribuee', 'en_cours', 'terminee', 'annulee'];
$filtre = in_array($_GET['statut'] ?? 'toutes', $statutsValides, true) ? ($_GET['statut'] ?? 'toutes') : 'toutes';

if (empty($_SESSION['csrf_avis_demandes'])) {
    $_SESSION['csrf_avis_demandes'] = bin2hex(random_bytes(32));
}

// ---------- Envoi d'un avis ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $demandeId   = (int) ($_POST['demande_id'] ?? 0);
    $note        = (int) ($_POST['note'] ?? 0);
    $commentaireBrut = $_POST['commentaire'] ?? '';
    $commentaire = is_string($commentaireBrut) ? mb_substr(trim($commentaireBrut), 0, 500) : '';
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';

    // La demande doit appartenir au client, être terminée et ne pas être déjà notée
    $demandeOk = false;
    foreach ($toutesLesDemandes as $d) {
        if ((int) $d['id'] === $demandeId && $d['statut'] === 'terminee') { $demandeOk = true; break; }
    }
    $resultat = 'erreur';
    if (hash_equals($_SESSION['csrf_avis_demandes'], $csrf)
        && $demandeOk && $note >= 1 && $note <= 5
        && !$noteModel->getByDemandeId($demandeId)) {
        if ($noteModel->create($demandeId, $note, $commentaire)) {
            $resultat = 'ok';
        }
    } elseif (!hash_equals($_SESSION['csrf_avis_demandes'], $csrf)) {
        $resultat = 'session';
    }
    if ($resultat === 'ok') {
        $_SESSION['csrf_avis_demandes'] = bin2hex(random_bytes(32));
    }
    $redirect = 'mes-demandes.php?avis=' . urlencode($resultat);
    if ($filtre !== 'toutes') {
        $redirect .= '&statut=' . urlencode($filtre);
    }
    if ($demandeId > 0) {
        $redirect .= '#demande-' . $demandeId;
    }
    header("Location: " . $redirect);
    exit;
}

// Compteurs calculés à partir de la liste
$cpt = ['toutes' => count($toutesLesDemandes), 'nouvelle' => 0, 'attribuee' => 0, 'en_cours' => 0, 'terminee' => 0, 'annulee' => 0];
foreach ($toutesLesDemandes as $d) { if (isset($cpt[$d['statut']])) $cpt[$d['statut']]++; }
$nbEnCours = $cpt['nouvelle'] + $cpt['attribuee'] + $cpt['en_cours'];

$demandesAffichees = $filtre === 'toutes'
    ? $toutesLesDemandes
    : array_values(array_filter($toutesLesDemandes, fn($d) => $d['statut'] === $filtre));

$libellesStatuts = ['nouvelle' => 'Nouvelle', 'attribuee' => 'Attribuée', 'en_cours' => 'En cours', 'terminee' => 'Terminée', 'annulee' => 'Annulée'];
$onglets = ['toutes' => 'Toutes', 'nouvelle' => 'Nouvelles', 'attribuee' => 'Attribuées', 'en_cours' => 'En cours', 'terminee' => 'Terminées', 'annulee' => 'Annulées'];
$avis = in_array($_GET['avis'] ?? '', ['ok', 'erreur', 'session'], true) ? $_GET['avis'] : '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Historique — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/adresses.css?v=<?= filemtime(__DIR__ . '/../../public/css/adresses.css') ?>">
    <link rel="stylesheet" href="../../public/css/historique.css?v=<?= filemtime(__DIR__ . '/../../public/css/historique.css') ?>">
    <link rel="stylesheet" href="../../public/css/historique-extra.css?v=<?= filemtime(__DIR__ . '/../../public/css/historique-extra.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
    <script>document.documentElement.classList.add('js');</script>
</head>
<body class="page-historique-client">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client historique-page">
    <header class="historique-hero reveal">
        <div class="historique-hero__contenu">
            <span class="historique-hero__tag">Votre espace</span>
            <h1>Mes demandes</h1>
            <p>Retrouvez le suivi, les informations et les paiements de vos interventions.</p>
        </div>
        <a href="nouvelle-demande.php" class="historique-nouvelle-demande"><?= icone('plus', 17) ?> Nouvelle demande</a>
    </header>

    <?php if ($avis === 'ok'): ?>
        <div class="hist-alerte hist-alerte--ok" role="status"><?= icone('check', 18) ?> Merci pour votre avis !</div>
    <?php elseif ($avis === 'erreur'): ?>
        <div class="hist-alerte hist-alerte--erreur" role="alert"><?= icone('alert', 18) ?> Votre avis n'a pas pu être enregistré. Vérifiez la note et assurez-vous de ne pas avoir déjà noté cette intervention.</div>
    <?php elseif ($avis === 'session'): ?>
        <div class="hist-alerte hist-alerte--erreur" role="alert"><?= icone('alert', 18) ?> Votre session a expiré. Actualisez la page puis renvoyez votre avis.</div>
    <?php endif; ?>

    <section class="stats-resume historique-stats" aria-label="Résumé de mes demandes">
        <div class="stat-carte reveal" style="--i:0">
            <div class="stat-carte__chiffre" data-compte="<?= $cpt['toutes'] ?>"><?= $cpt['toutes'] ?></div>
            <div class="stat-carte__label">Total</div>
        </div>
        <div class="stat-carte reveal" style="--i:1">
            <div class="stat-carte__chiffre stat-carte__chiffre--cours" data-compte="<?= $nbEnCours ?>"><?= $nbEnCours ?></div>
            <div class="stat-carte__label">En cours</div>
        </div>
        <div class="stat-carte reveal" style="--i:2">
            <div class="stat-carte__chiffre stat-carte__chiffre--ok" data-compte="<?= $cpt['terminee'] ?>"><?= $cpt['terminee'] ?></div>
            <div class="stat-carte__label">Terminées</div>
        </div>
        <?php if ($cpt['annulee'] > 0): ?>
        <div class="stat-carte reveal" style="--i:3">
            <div class="stat-carte__chiffre stat-carte__chiffre--off" data-compte="<?= $cpt['annulee'] ?>"><?= $cpt['annulee'] ?></div>
            <div class="stat-carte__label">Annulées</div>
        </div>
        <?php endif; ?>
    </section>

    <nav class="filtres-tabs reveal" aria-label="Filtrer les demandes">
        <?php foreach ($onglets as $cle => $libelle): ?>
            <?php if ($cle === 'annulee' && $cpt['annulee'] === 0 && $filtre !== 'annulee') continue; ?>
            <a href="?statut=<?= h($cle) ?>" class="filtre-tab <?= $filtre === $cle ? 'filtre-tab--actif' : '' ?>" <?= $filtre === $cle ? 'aria-current="page"' : '' ?>>
                <span><?= h($libelle) ?></span><span class="filtre-tab__compte"><?= $cpt[$cle] ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <?php if (!empty($demandesAffichees)): ?>
        <label class="hist-recherche reveal" for="recherche">
            <?= icone('search', 18) ?>
            <input type="search" id="recherche" placeholder="Rechercher par numéro de dossier ou catégorie…" aria-label="Rechercher une demande" autocomplete="off">
            <span class="hist-recherche__compte"><?= count($demandesAffichees) ?> résultat<?= count($demandesAffichees) > 1 ? 's' : '' ?></span>
        </label>
    <?php endif; ?>

    <section class="historique-liste" aria-label="Liste de mes demandes">
        <?php if (empty($demandesAffichees)): ?>
            <div class="historique-vide reveal">
                <div class="historique-vide__icone"><?= icone('clipboard', 40) ?></div>
                <p><?= $filtre === 'toutes' ? "Vous n'avez pas encore fait de demande." : 'Aucune demande dans cette catégorie.' ?></p>
                <?php if ($filtre === 'toutes'): ?>
                    <a href="nouvelle-demande.php" class="bouton-principal-inline"><?= icone('plus', 16) ?> Créer ma première demande</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php foreach ($demandesAffichees as $idx => $d):
            $detail = 'detail-demande.php?id=' . (int) $d['id'];
            $noteExistante = $d['statut'] === 'terminee' ? $noteModel->getByDemandeId($d['id']) : null;
            $valeurNote = is_array($noteExistante) ? (int) ($noteExistante['note'] ?? 0) : 0;
        ?>
            <?php
                $montantIntervention = (float) ($d['intervention_montant'] ?? 0);
                $couvert = $d['statut'] === 'terminee' && $d['mode_paiement'] !== 'normal';
                $paiementValide = ($d['paiement_statut'] ?? null) === 'valide';
                $paiementEnAttente = ($d['paiement_statut'] ?? null) === 'en_attente';
                $paiementEchoue = ($d['paiement_statut'] ?? null) === 'echoue';
                $rechercheTexte = mb_strtolower($d['numero_dossier'] . ' ' . $d['categorie_nom'] . ' ' . ($libellesStatuts[$d['statut']] ?? $d['statut']));
            ?>
            <article class="historique-carte reveal" id="demande-<?= (int) $d['id'] ?>" style="--i:<?= min((int) $idx, 6) ?>" data-recherche="<?= h($rechercheTexte) ?>">
                <div class="historique-carte__icone"><?= iconePole($d['categorie_nom'], 24) ?></div>

                <div class="historique-carte__corps">
                    <div class="historique-carte__haut">
                        <a href="<?= $detail ?>" class="historique-carte__numero"><?= h($d['numero_dossier']) ?></a>
                        <span class="badge badge--<?= h($d['statut']) ?>"><?= h($libellesStatuts[$d['statut']] ?? $d['statut']) ?></span>
                    </div>
                    <div class="historique-carte__categorie"><?= h($d['categorie_nom']) ?></div>
                    <div class="historique-carte__date">Créée le <?= date('d/m/Y à H:i', strtotime($d['date_creation'])) ?></div>
                    <?php if ($d['statut'] === 'terminee'): ?>
                        <?php if ($couvert): ?>
                            <div class="historique-paiement historique-paiement--couvert">
                                <span class="historique-paiement__icone" aria-hidden="true">✓</span>
                                <span>Pris en charge par <?= $d['mode_paiement'] === 'abonnement' ? "l'abonnement" : 'un Pass' ?></span>
                            </div>
                        <?php elseif ($paiementValide): ?>
                            <div class="historique-paiement historique-paiement--paye">
                                <span class="historique-paiement__icone" aria-hidden="true">✓</span>
                                <span><strong><?= number_format((float) $d['paiement_montant'], 0, ',', ' ') ?> FCFA payés</strong> · <?= h(($d['paiement_methode'] ?? '') === 'orange_money' ? 'Orange Money' : ucfirst((string) ($d['paiement_methode'] ?? ''))) ?></span>
                            </div>
                        <?php elseif ($montantIntervention > 0): ?>
                            <div class="historique-paiement historique-paiement--<?= $paiementEchoue ? 'echec' : ($paiementEnAttente ? 'attente' : 'a-payer') ?>">
                                <span class="historique-paiement__icone" aria-hidden="true"><?= $paiementEchoue ? '!' : ($paiementEnAttente ? '…' : '₣') ?></span>
                                <span><strong><?= $paiementEchoue ? 'Paiement non abouti' : ($paiementEnAttente ? 'Paiement en attente' : 'À régler') ?></strong> · <?= number_format($montantIntervention, 0, ',', ' ') ?> FCFA</span>
                            </div>
                        <?php else: ?>
                            <div class="historique-paiement historique-paiement--couvert">
                                <span class="historique-paiement__icone" aria-hidden="true">✓</span>
                                <span>Aucun montant à payer</span>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <div class="historique-carte__actions">
                    <?php if ($d['statut'] === 'terminee' && !$couvert && !$paiementValide && $montantIntervention > 0): ?>
                        <a href="payer.php?id=<?= (int) $d['id'] ?>" class="historique-carte__payer">
                            <?= $paiementEnAttente ? 'Reprendre le paiement' : ($paiementEchoue ? 'Réessayer' : 'Payer maintenant') ?>
                        </a>
                    <?php endif; ?>
                    <a href="<?= h($detail) ?>" class="historique-carte__detail">
                        Voir le détail
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
                    </a>
                </div>

                <?php if ($d['statut'] === 'terminee'): ?>
                    <?php if ($noteExistante): ?>
                        <div class="historique-carte__notation hist-avis-donne">
                            <span class="historique-carte__notation-label">Votre avis :</span>
                            <span class="hist-etoiles" aria-label="<?= $valeurNote ?> sur 5">
                                <?php for ($i = 1; $i <= 5; $i++): ?><span class="hist-etoile <?= $i <= $valeurNote ? 'hist-etoile--on' : '' ?>"><?= icone('star', 16) ?></span><?php endfor; ?>
                            </span>
                            <span class="hist-avis-donne__note"><?= $valeurNote ?>/5</span>
                            <?php if (!empty($noteExistante['commentaire'])): ?>
                                <blockquote class="hist-avis-donne__commentaire">
                                    <span class="hist-avis-donne__commentaire-titre">Votre commentaire</span>
                                    <p><?= nl2br(h($noteExistante['commentaire'])) ?></p>
                                </blockquote>
                            <?php else: ?>
                                <span class="hist-avis-donne__sans-commentaire">Aucun commentaire ajouté.</span>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="historique-carte__notation">
                            <details class="hist-avis">
                                <summary><?= icone('star', 17) ?> <span>Donner mon avis</span><span class="hist-avis__summary-aide">Note et commentaire</span></summary>
                                <form method="POST" class="hist-avis__form">
                                    <input type="hidden" name="demande_id" value="<?= (int) $d['id'] ?>">
                                    <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf_avis_demandes']) ?>">
                                    <fieldset class="hist-avis__note">
                                        <legend>Quelle note donnez-vous à cette intervention ?</legend>
                                        <div class="hist-notation" role="radiogroup" aria-label="Votre note, de 1 à 5 étoiles">
                                        <?php for ($i = 5; $i >= 1; $i--): $rid = 'note-' . (int) $d['id'] . '-' . $i; ?>
                                            <input type="radio" name="note" id="<?= $rid ?>" value="<?= $i ?>" required>
                                            <label for="<?= $rid ?>" title="<?= $i ?> étoile<?= $i > 1 ? 's' : '' ?>" aria-label="<?= $i ?> étoile<?= $i > 1 ? 's' : '' ?>"><?= icone('star', 29) ?></label>
                                        <?php endfor; ?>
                                        </div>
                                        <output class="hist-avis__note-selection" aria-live="polite">Sélectionnez une note</output>
                                    </fieldset>
                                    <label class="hist-avis__commentaire-label" for="commentaire-<?= (int) $d['id'] ?>">
                                        Votre commentaire <span>(facultatif)</span>
                                    </label>
                                    <textarea id="commentaire-<?= (int) $d['id'] ?>" name="commentaire" rows="3" maxlength="500" placeholder="Qu’avez-vous apprécié ? Que pourrait-on améliorer ?"></textarea>
                                    <div class="hist-avis__bas">
                                        <span class="hist-avis__compteur">0 / 500 caractères</span>
                                        <button type="submit" class="hist-avis__envoyer"><?= icone('message', 16) ?> Envoyer mon avis</button>
                                    </div>
                                </form>
                            </details>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>

        <div class="historique-vide hist-aucun-resultat" id="aucun-resultat" style="display:none;">
            <div class="historique-vide__icone"><?= icone('search', 40) ?></div>
            <p>Aucune demande ne correspond à votre recherche.</p>
        </div>
    </section>
</main>

<script>
(function () {
    var reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Apparition au défilement
    var els = document.querySelectorAll('.reveal');
    if (reduit || !('IntersectionObserver' in window)) {
        els.forEach(function (e) { e.classList.add('reveal--visible'); });
    } else {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('reveal--visible'); io.unobserve(en.target); } });
        }, { threshold: 0.08 });
        els.forEach(function (e) { io.observe(e); });
    }

    // Compteurs animés
    if (!reduit) {
        document.querySelectorAll('[data-compte]').forEach(function (el) {
            var cible = parseInt(el.dataset.compte, 10) || 0, debut = null;
            if (cible < 2) return;
            el.textContent = '0';
            function pas(t) {
                if (!debut) debut = t;
                var p = Math.min((t - debut) / 800, 1);
                el.textContent = Math.round(cible * (1 - Math.pow(1 - p, 3)));
                if (p < 1) requestAnimationFrame(pas);
            }
            requestAnimationFrame(pas);
        });
    }

    // Recherche instantanée (sur les demandes du filtre affiché)
    var champ = document.getElementById('recherche');
    if (champ) {
        var cartes = document.querySelectorAll('.historique-carte');
        var aucun = document.getElementById('aucun-resultat');
        champ.addEventListener('input', function () {
            var q = champ.value.trim().toLowerCase(), visibles = 0;
            cartes.forEach(function (c) {
                var ok = q === '' || c.dataset.recherche.indexOf(q) !== -1;
                c.style.display = ok ? '' : 'none';
                if (ok) visibles++;
            });
            aucun.style.display = visibles === 0 ? '' : 'none';
        });
    }

    // Avis : un seul bloc ouvert à la fois, et double envoi bloqué
    var blocs = document.querySelectorAll('.hist-avis');
    blocs.forEach(function (b) {
        b.addEventListener('toggle', function () {
            if (b.open) blocs.forEach(function (o) { if (o !== b) o.open = false; });
        });
        var form = b.querySelector('form');
        var selection = b.querySelector('.hist-avis__note-selection');
        var radios = b.querySelectorAll('input[name="note"]');
        radios.forEach(function (radio) {
            radio.addEventListener('change', function () {
                selection.textContent = radio.value + ' étoile' + (radio.value === '1' ? '' : 's') + ' sélectionnée' + (radio.value === '1' ? '' : 's');
            });
        });
        var commentaire = form.querySelector('textarea[name="commentaire"]');
        var compteur = form.querySelector('.hist-avis__compteur');
        commentaire.addEventListener('input', function () {
            compteur.textContent = commentaire.value.length + ' / 500 caractères';
        });
        form.addEventListener('submit', function (event) {
            if (!form.querySelector('input[name="note"]:checked')) {
                event.preventDefault();
                selection.textContent = 'Choisissez une note avant d’envoyer votre avis.';
                form.querySelector('input[name="note"]').focus();
                return;
            }
            var btn = b.querySelector('.hist-avis__envoyer');
            btn.disabled = true;
            btn.innerHTML = 'Envoi de votre avis…';
        });
    });
})();
</script>
</body>
</html>