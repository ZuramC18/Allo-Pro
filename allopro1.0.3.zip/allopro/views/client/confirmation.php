<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);

$numero = $_GET['numero'] ?? null;
if (!$numero) {
    header("Location: accueil.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Demande envoyée — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/confirmation.css?v=<?= filemtime(__DIR__ . '/../../public/css/confirmation.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body class="page-confirmation-client">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client conf-page">
    <div class="conf-carte">

        <div class="conf-coche" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12.5l4.5 4.5L19 7.5"/>
            </svg>
        </div>

        <p class="conf-sur-titre">Confirmation d’envoi</p>
        <h1 class="conf-titre">Demande envoyée</h1>
        <p class="conf-texte">Votre dossier a bien été enregistré. Un conseiller ALLÔ PRO va le traiter dans les plus brefs délais.</p>

        <div class="conf-numero" aria-label="Numéro de votre dossier">
            <div class="conf-numero__label">Numéro de dossier</div>
            <div class="conf-numero__ligne">
                <span class="conf-numero__valeur" id="conf-numero"><?= htmlspecialchars($numero, ENT_QUOTES, 'UTF-8') ?></span>
                <button type="button" class="conf-copier" id="conf-copier" aria-label="Copier le numéro de dossier">Copier</button>
            </div>
            <span class="conf-copier__statut" id="conf-copier-statut" role="status" aria-live="polite"></span>
        </div>

        <ol class="conf-etapes">
            <li class="conf-etapes__titre">Et maintenant ?</li>
            <li class="conf-etape">
                <span class="conf-etape__num">1</span>
                <span class="conf-etape__txt"><strong>Un conseiller étudie votre demande</strong><span>Il peut vous contacter pour préciser le besoin.</span></span>
            </li>
            <li class="conf-etape">
                <span class="conf-etape__num">2</span>
                <span class="conf-etape__txt"><strong>Un professionnel est assigné</strong><span>Vous êtes informé dès qu'un intervenant est désigné.</span></span>
            </li>
            <li class="conf-etape">
                <span class="conf-etape__num">3</span>
                <span class="conf-etape__txt"><strong>L'intervention a lieu</strong><span>Vous suivez chaque étape depuis « Mes demandes ».</span></span>
            </li>
        </ol>

        <div class="conf-actions">
            <a href="mes-demandes.php" class="bouton-principal-large">Suivre ma demande</a>
            <a href="accueil.php" class="conf-lien-secondaire">Retour à l'accueil</a>
        </div>

    </div>
</main>

<script>
document.getElementById('conf-copier').addEventListener('click', function () {
    var btn = this;
    var texte = document.getElementById('conf-numero').textContent.trim();
    var statut = document.getElementById('conf-copier-statut');
    function ok() {
        btn.textContent = 'Copié ✓';
        btn.classList.add('conf-copier--ok');
        statut.textContent = 'Numéro copié dans le presse-papiers.';
        setTimeout(function () { btn.textContent = 'Copier'; btn.classList.remove('conf-copier--ok'); }, 2000);
    }
    function erreur() {
        statut.textContent = 'Copie impossible. Vous pouvez sélectionner le numéro pour le copier.';
    }
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(texte).then(ok).catch(erreur);
    } else {
        var t = document.createElement('textarea');
        t.value = texte;
        t.setAttribute('readonly', '');
        t.style.position = 'fixed';
        t.style.opacity = '0';
        document.body.appendChild(t);
        t.select();
        var copie = false;
        try { copie = document.execCommand('copy'); } catch (e) { erreur(); }
        document.body.removeChild(t);
        if (copie) ok();
        else erreur();
    }
});
</script>
</body>
</html>