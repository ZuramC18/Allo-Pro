<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

if (!function_exists('h')) {
    function h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
}

$libellesStatut = ['ouvert' => 'Ouvert', 'en_cours' => 'En cours', 'resolu' => 'Résolu'];

// Le filtre doit être un statut connu, sinon on affiche tout
$statutFiltre = $_GET['statut'] ?? null;
if (!is_string($statutFiltre) || !isset($libellesStatut[$statutFiltre])) { $statutFiltre = null; }

// Une seule requête : on compte et on filtre en PHP
$tous = (new TicketSav())->getAll(null);

$compteurs = array_fill_keys(array_keys($libellesStatut), 0);
$sommeNotes = 0;
$nbNotes = 0;
foreach ($tous as $t) {
    if (isset($compteurs[$t['statut']])) { $compteurs[$t['statut']]++; }
    if ((int) $t['note'] > 0) { $sommeNotes += (int) $t['note']; $nbNotes++; }
}
$noteMoyenne = $nbNotes ? round($sommeNotes / $nbNotes, 1) : null;

$tickets = $statutFiltre
    ? array_values(array_filter($tous, fn($t) => $t['statut'] === $statutFiltre))
    : $tous;

// 5 étoiles en SVG : pleines jusqu'à la note, vides ensuite
function etoiles(int $note): string {
    $note = max(0, min(5, $note));
    $chemin = '<path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/>';
    $html = '<span class="etoiles" role="img" aria-label="Note : ' . $note . ' sur 5">';
    for ($i = 1; $i <= 5; $i++) {
        $html .= '<svg class="etoile ' . ($i <= $note ? 'etoile--pleine' : 'etoile--vide') . '" width="16" height="16" viewBox="0 0 24 24" stroke-linejoin="round" aria-hidden="true">' . $chemin . '</svg>';
    }
    return $html . '</span>';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SAV — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/liste-demandes.css?v=<?= filemtime(__DIR__ . '/../../public/css/liste-demandes.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-conseiller-sav">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>

    <div class="contenu">
        <div class="contenu__entete">
            <div>
                <div class="contenu__titre">Tickets SAV</div>
                <p class="liste-soustitre"><?= count($tous) ?> ticket<?= count($tous) > 1 ? 's' : '' ?> au total</p>
            </div>
        </div>

        <!-- Cartes de synthèse -->
        <div class="synthese">
            <a href="?statut=ouvert" class="synthese__carte synthese__carte--ouvert">
                <span class="synthese__nombre"><?= $compteurs['ouvert'] ?></span>
                <span class="synthese__label">À traiter</span>
            </a>
            <a href="?statut=en_cours" class="synthese__carte synthese__carte--en-cours">
                <span class="synthese__nombre"><?= $compteurs['en_cours'] ?></span>
                <span class="synthese__label">En cours</span>
            </a>
            <a href="?statut=resolu" class="synthese__carte synthese__carte--terminee">
                <span class="synthese__nombre"><?= $compteurs['resolu'] ?></span>
                <span class="synthese__label">Résolus</span>
            </a>
            <div class="synthese__carte synthese__carte--note">
                <span class="synthese__nombre">
                    <?= $noteMoyenne !== null ? number_format($noteMoyenne, 1, ',', '') : '—' ?><small>/5</small>
                </span>
                <span class="synthese__label">Note moyenne<?= $nbNotes ? ' (' . $nbNotes . ' avis)' : '' ?></span>
            </div>
        </div>

        <!-- Filtres + recherche -->
        <div class="barre-outils">
            <div class="filtres">
                <a href="?" class="filtre <?= !$statutFiltre ? 'filtre--actif' : '' ?>">Tous <span class="filtre__nb"><?= count($tous) ?></span></a>
                <?php foreach ($libellesStatut as $cle => $label): ?>
                    <a href="?statut=<?= h($cle) ?>" class="filtre <?= $statutFiltre === $cle ? 'filtre--actif' : '' ?>">
                        <?= h($label) ?>s <span class="filtre__nb"><?= $compteurs[$cle] ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <div class="recherche">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="search" id="recherche" placeholder="Dossier, client, commentaire…" aria-label="Rechercher dans les tickets">
            </div>
        </div>

        <!-- Tableau -->
        <div class="table-carte">
            <div class="table-defilement">
                <table class="table-demandes">
                    <thead>
                        <tr><th>Dossier</th><th>Client</th><th>Note</th><th>Commentaire</th><th>Statut</th><th></th></tr>
                    </thead>
                    <tbody id="corps-tableau">
                        <?php foreach ($tickets as $t): ?>
                        <tr class="<?= $t['statut'] === 'ouvert' ? 'ligne--urgente' : '' ?>"
                            data-href="traiter-sav.php?id=<?= (int) $t['id'] ?>"
                            data-recherche="<?= h(mb_strtolower($t['numero_dossier'] . ' ' . $t['client_nom'] . ' ' . $t['client_telephone'] . ' ' . ($t['commentaire'] ?? ''))) ?>">
                            <td class="cellule-dossier" data-label="Dossier"><?= h($t['numero_dossier']) ?></td>
                            <td class="cellule-client" data-label="Client">
                                <strong><?= h($t['client_nom']) ?></strong>
                                <small><?= h($t['client_telephone']) ?></small>
                            </td>
                            <td data-label="Note"><?= etoiles((int) $t['note']) ?></td>
                            <td class="cellule-commentaire" data-label="Commentaire">
                                <?php if (!empty($t['commentaire'])): ?>
                                    <span class="commentaire" title="<?= h($t['commentaire']) ?>"><?= h($t['commentaire']) ?></span>
                                <?php else: ?>
                                    <span class="texte-vide">Aucun commentaire</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="Statut"><span class="pastille pastille--<?= h($t['statut']) ?>"><?= h($libellesStatut[$t['statut']] ?? ucfirst(str_replace('_', ' ', $t['statut']))) ?></span></td>
                            <td class="cellule-action" data-label="Action">
                                <a href="traiter-sav.php?id=<?= (int) $t['id'] ?>" class="bouton-traiter">
                                    Traiter
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="liste-vide" id="liste-vide" <?= empty($tickets) ? '' : 'hidden' ?>>
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
                <p>Aucun ticket SAV à afficher.</p>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    var champ = document.getElementById('recherche');
    var lignes = document.querySelectorAll('#corps-tableau tr');
    var vide = document.getElementById('liste-vide');
    var totalInitial = lignes.length;

    // Recherche instantanée
    champ.addEventListener('input', function () {
        var q = champ.value.trim().toLowerCase();
        var visibles = 0;
        lignes.forEach(function (tr) {
            var ok = q === '' || tr.getAttribute('data-recherche').indexOf(q) !== -1;
            tr.hidden = !ok;
            if (ok) visibles++;
        });
        vide.hidden = !(totalInitial === 0 || visibles === 0);
    });

    // Ligne entière cliquable (sauf si on clique déjà sur le lien)
    lignes.forEach(function (tr) {
        tr.addEventListener('click', function (e) {
            if (e.target.closest('a')) return;
            window.location.href = tr.getAttribute('data-href');
        });
    });
})();
</script>
</body>
</html>