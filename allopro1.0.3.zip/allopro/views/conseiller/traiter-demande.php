<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('demandes');
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../models/ClotureIntervention.php';

// Échappement HTML sûr (accepte null, évite les "deprecated" de PHP 8.1+)
if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id) { header("Location: liste-demandes.php"); exit; }

$demandeModel = new Demande();
$demande = $demandeModel->getById($id);
if (!$demande) { http_response_code(404); die("Demande introuvable."); }

$partenaireModel = new Partenaire();
$partenairesActifs = $partenaireModel->getAllActifs();

$interventionModel = new Intervention();
$intervention = $interventionModel->getByDemandeId($id);

$paiementModel = new Paiement();
$paiement = $paiementModel->getByDemandeId($id);

$statutsMission = ['en_route', 'arrive', 'diagnostic', 'en_cours'];
$statutsModifiables = ['attribuee', 'en_cours'];
$erreur = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ---------- 1. Attribution ----------
    if (isset($_POST['technicien_id'])) {
        $partenaireId = (int) ($_POST['partenaire_id'] ?? 0);
        $technicienId = (int) $_POST['technicien_id'];
        $p = $partenaireModel->getById($partenaireId);
        $t = (new Technicien())->getById($technicienId);

        if ($demande['statut'] !== 'nouvelle') {
            $erreur = "Cette demande a déjà été attribuée.";
        } elseif (!$p || !$t) {
            $erreur = "Partenaire ou technicien invalide.";
        } else {
            $interventionModel->creerAvecPartenaire($id, $partenaireId, $technicienId);
            $demandeModel->mettreAJourStatut($id, 'attribuee');
            journaliser('demande.attribuee', 'demande', $id, $demande['numero_dossier'],
                'Partenaire ' . $p['matricule'] . ' (' . $p['nom_entreprise'] . ') · Technicien ' . $t['matricule'] . ' (' . $t['nom'] . ')');
            header("Location: traiter-demande.php?id=" . $id);
            exit;
        }

    // ---------- 2. Mise à jour du statut de la mission ----------
    } elseif (isset($_POST['nouveau_statut'])) {
        $nouveauStatut = $_POST['nouveau_statut'];

        if (!in_array($demande['statut'], $statutsModifiables, true) || !$intervention) {
            $erreur = "Le statut de cette mission ne peut plus être modifié.";
        } elseif (!in_array($nouveauStatut, $statutsMission, true)) {
            $erreur = "Statut invalide.";
        } else {
            $interventionModel->mettreAJourStatut($id, $nouveauStatut);
            $demandeModel->mettreAJourStatut($id, 'en_cours');
            journaliser('mission.statut_modifie', 'demande', $id, $demande['numero_dossier'], '→ ' . $nouveauStatut);
            header("Location: traiter-demande.php?id=" . $id);
            exit;
        }

    // ---------- 3. Clôture ----------
    } elseif (isset($_POST['rapport'])) {
        $rapport = trim($_POST['rapport']);

        if (!in_array($demande['statut'], $statutsModifiables, true)) {
            $erreur = "Cette intervention ne peut pas être clôturée (déjà terminée ou non attribuée).";
        } else {
            $resultatCloture = (new ClotureIntervention())->cloturer($id, $rapport, $_POST['montant'] ?? '');
            if (!$resultatCloture['ok']) {
                $erreur = $resultatCloture['erreur'];
            } else {
                $couverture = $resultatCloture['couverture'];
                $montant = $resultatCloture['montant'];
                journaliser('mission.cloturee', 'demande', $id, $demande['numero_dossier'],
                    $couverture ? 'Couvert par ' . $couverture['type'] : 'Montant : ' . number_format($montant, 0, ',', ' ') . ' F');
                require_once __DIR__ . '/../../models/Notification.php';
                $notificationModel = new Notification();
                $lienDetail = "/allopro/views/client/detail-demande.php?id=" . $id;

                if (($couverture['type'] ?? null) === 'abonnement') {
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Elle est couverte par votre abonnement — aucun paiement requis.", $lienDetail);
                } elseif (($couverture['type'] ?? null) === 'pass') {
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Elle est couverte par votre Pass — aucun paiement requis.", $lienDetail);
                } else {
                    $montantFormate = number_format($montant, 0, ',', ' ');
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Montant à payer : {$montantFormate} FCFA.", "/allopro/views/client/payer.php?id=" . $id);
                }

                header("Location: traiter-demande.php?id=" . $id);
                exit;
            }
        }
    }
}
?>
<?php
// Libellés lisibles + progression de la mission (affichage uniquement)
$libellesStatut = ['nouvelle' => 'Nouvelle', 'attribuee' => 'Attribuée', 'en_cours' => 'En cours', 'terminee' => 'Terminée'];
$libellesMission = ['en_route' => 'En route', 'arrive' => 'Arrivé', 'diagnostic' => 'Diagnostic', 'en_cours' => 'Intervention en cours'];

$etapes = ['Attribuée', 'En route', 'Arrivé', 'Diagnostic', 'En cours', 'Terminée'];
$etapeCourante = -1;   // -1 = pas encore attribuée
if ($demande['statut'] === 'terminee') {
    $etapeCourante = count($etapes) - 1;
} elseif ($intervention) {
    $pos = array_search($intervention['statut'] ?? '', array_keys($libellesMission), true);
    $etapeCourante = ($pos === false) ? 0 : $pos + 1;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dossier <?= h($demande['numero_dossier']) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/traiter-demande.css?v=<?= filemtime(__DIR__ . '/../../public/css/traiter-demande.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-traiter-demande page-traiter-demande--conseiller">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>

    <div class="contenu">

        <a href="liste-demandes.php" class="lien-retour">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>
            Retour aux demandes
        </a>

        <div class="dossier-entete">
            <div>
                <span class="dossier-entete__sur-titre">Traitement de la demande</span>
                <h1 class="dossier-entete__titre">Dossier <?= h($demande['numero_dossier']) ?></h1>
                <p class="dossier-entete__date">
                    <span><?= h($demande['categorie_nom']) ?></span>
                    <span aria-hidden="true">·</span>
                    <span>Créé le <?= date('d/m/Y à H:i', strtotime($demande['date_creation'] ?? 'now')) ?></span>
                </p>
            </div>
            <div class="dossier-entete__badges">
                <span class="pastille pastille--<?= h($demande['urgence']) ?>"><?= h(ucfirst($demande['urgence'])) ?></span>
                <span class="pastille pastille--<?= h($demande['statut']) ?>"><?= h($libellesStatut[$demande['statut']] ?? $demande['statut']) ?></span>
            </div>
        </div>

        <!-- Frise de progression -->
        <?php if ($etapeCourante >= 0): ?>
            <ol class="frise" aria-label="Progression de la mission">
                <?php foreach ($etapes as $i => $nom):
                    $etat = $i < $etapeCourante ? 'fait' : ($i === $etapeCourante ? 'courant' : 'attente');
                    if ($demande['statut'] === 'terminee') { $etat = 'fait'; } ?>
                    <li class="frise__etape frise__etape--<?= $etat ?>">
                        <span class="frise__rond">
                            <?php if ($etat === 'fait'): ?>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
                            <?php else: ?><?= $i + 1 ?><?php endif; ?>
                        </span>
                        <span class="frise__nom"><?= h($nom) ?></span>
                    </li>
                <?php endforeach; ?>
            </ol>
        <?php endif; ?>

        <div class="dossier-grille">

            <!-- ===== Colonne gauche : informations ===== -->
            <section class="carte">
                <h2 class="carte__titre">Informations du dossier</h2>

                <div class="dossier__ligne"><span>Client</span><span><strong><?= h($demande['client_nom']) ?></strong><br><a class="dossier__telephone" href="tel:<?= h($demande['client_telephone']) ?>"><?= h($demande['client_telephone']) ?></a></span></div>
                <div class="dossier__ligne"><span>Catégorie</span><span><?= h($demande['categorie_nom']) ?></span></div>
                <div class="dossier__ligne"><span>Adresse</span><span><?= h($demande['quartier'] . ', ' . $demande['ville']) ?><?php if (!empty($demande['adresse_details'])): ?><br><small class="texte-doux"><?= h($demande['adresse_details']) ?></small><?php endif; ?></span></div>
                <div class="dossier__ligne dossier__ligne--description"><span>Description</span><span><?= nl2br(h($demande['description'])) ?></span></div>

                <?php if ($paiement): ?>
                    <div class="dossier__ligne">
                        <span>Paiement</span>
                        <span>
                            <span class="pastille pastille--<?= h($paiement['statut']) ?>"><?= h(ucfirst(str_replace('_', ' ', (string) $paiement['statut']))) ?></span>
                            <strong class="montant"><?= number_format((float) $paiement['montant'], 0, ',', ' ') ?> FCFA</strong>
                            <small class="texte-doux">(<?= h(str_replace('_', ' ', (string) $paiement['methode'])) ?>)</small>
                        </span>
                    </div>
                <?php elseif ($demande['statut'] === 'terminee'): ?>
                    <div class="dossier__ligne"><span>Paiement</span><span class="texte-doux">En attente de paiement par le client</span></div>
                <?php endif; ?>

                <?php if (!empty($demande['photo_path'])): ?>
                    <div class="dossier__photo-bloc">
                        <div class="dossier__photo-label">Photo jointe</div>
                        <a href="/allopro/public/<?= h($demande['photo_path']) ?>" target="_blank" rel="noopener">
                            <img src="/allopro/public/<?= h($demande['photo_path']) ?>" class="dossier__photo" alt="Photo jointe à la demande">
                        </a>
                    </div>
                <?php endif; ?>

                <div class="dossier__ligne">
                    <a href="messagerie.php?client_id=<?= (int) $demande['client_id'] ?>" class="bouton-message--ligne">
                        <svg class="icone-msg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>
                            <circle class="icone-msg__point" cx="8.5"  cy="12" r="1" fill="currentColor" stroke="none"/>
                            <circle class="icone-msg__point" cx="12"   cy="12" r="1" fill="currentColor" stroke="none"/>
                            <circle class="icone-msg__point" cx="15.5" cy="12" r="1" fill="currentColor" stroke="none"/>
                        </svg>
                        Écrire au client
                    </a>
                </div>
            </section>

            <!-- ===== Colonne droite : actions ===== -->
            <div class="colonne-actions">

                <?php if ($erreur): ?>
                    <div class="alerte alerte--erreur" role="alert"><?= h($erreur) ?></div>
                <?php endif; ?>

                <?php if ($demande['statut'] === 'nouvelle'): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Attribuer une mission</h2>
                        <form method="POST" id="form-attribution">
                            <label class="champ-label" for="select-partenaire">Partenaire</label>
                            <select name="partenaire_id" id="select-partenaire" class="champ" required>
                                <option value="">-- Choisir --</option>
                                <?php foreach ($partenairesActifs as $p): ?>
                                    <option value="<?= (int) $p['id'] ?>"><?= h($p['nom_entreprise']) ?> (<?= h($p['zone_intervention']) ?>)</option>
                                <?php endforeach; ?>
                            </select>

                            <label class="champ-label" for="select-technicien">Technicien</label>
                            <select name="technicien_id" id="select-technicien" class="champ" required disabled aria-describedby="aide-technicien">
                                <option value="">-- Choisir d'abord un partenaire --</option>
                            </select>
                            <p class="champ-aide" id="aide-technicien" role="status" aria-live="polite">La liste des techniciens s’affichera après le choix du partenaire.</p>

                            <button type="submit" class="btn btn--principal btn--plein">Attribuer la mission</button>
                        </form>
                    </section>

                <?php elseif (in_array($demande['statut'], $statutsModifiables, true) && $intervention): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Mission en cours</h2>
                        <div class="dossier__ligne"><span>Partenaire</span><span><?= h($intervention['nom_entreprise']) ?></span></div>
                        <div class="dossier__ligne"><span>Technicien</span><span><?= h($intervention['technicien_nom_reel']) ?> <small class="texte-doux">(<?= h($intervention['technicien_metier']) ?>)</small></span></div>
                        <div class="dossier__ligne"><span>Statut mission</span><span><?= h($libellesMission[$intervention['statut']] ?? str_replace('_', ' ', (string) $intervention['statut'])) ?></span></div>
                    </section>

                    <section class="carte">
                        <h2 class="carte__titre">Mettre à jour le statut</h2>
                        <form method="POST">
                            <label class="champ-label" for="nouveau_statut">Nouvelle étape</label>
                            <select name="nouveau_statut" id="nouveau_statut" class="champ">
                                <?php foreach ($libellesMission as $cle => $label): ?>
                                    <option value="<?= h($cle) ?>" <?= ($intervention['statut'] ?? '') === $cle ? 'selected' : '' ?>><?= h($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn btn--secondaire btn--plein">Mettre à jour</button>
                        </form>
                    </section>

                    <section class="carte">
                        <h2 class="carte__titre">Clôturer l'intervention</h2>
                        <div class="alerte alerte--succes">
                            La couverture sera vérifiée à la clôture. Le montant est requis uniquement si aucun abonnement ou Pass valide ne couvre cette demande.
                        </div>
                        <form method="POST">
                            <label class="champ-label" for="rapport">Rapport d'intervention</label>
                            <textarea name="rapport" id="rapport" class="champ" rows="4" placeholder="Diagnostic, travail réalisé, pièces utilisées..." required></textarea>

                            <label class="champ-label" for="montant">Montant facturé (FCFA, si non couvert)</label>
                            <input type="number" name="montant" id="montant" class="champ" placeholder="Ex : 15000" step="1" min="1">

                            <button type="submit" class="btn btn--principal btn--plein">Clôturer l'intervention</button>
                        </form>
                    </section>

                <?php elseif ($demande['statut'] === 'terminee' && $intervention): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Intervention terminée</h2>
                        <?php if (!empty($intervention['date_fin'])): ?>
                            <p class="texte-doux" style="margin:0 0 12px;">Le <?= date('d/m/Y à H:i', strtotime($intervention['date_fin'])) ?></p>
                        <?php endif; ?>
                        <div class="rapport"><?= nl2br(h($intervention['rapport'])) ?></div>
                    </section>

                <?php else: ?>
                    <section class="carte">
                        <p class="texte-doux" style="margin:0;">Aucune action disponible pour une demande au statut « <?= h($libellesStatut[$demande['statut']] ?? $demande['statut']) ?> ».</p>
                    </section>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<script>
// Empêche le double envoi des formulaires (double clic)
document.querySelectorAll('form[method="POST"]').forEach(form => {
    form.addEventListener('submit', () => {
        const bouton = form.querySelector('button[type="submit"]');
        if (bouton) setTimeout(() => { bouton.disabled = true; }, 0);
    });
});

// Chargement des techniciens selon le partenaire choisi
const selectPartenaire = document.getElementById('select-partenaire');
if (selectPartenaire) {
    const selectTech = document.getElementById('select-technicien');
    const aideTech = document.getElementById('aide-technicien');
    let chargementEnCours = 0;

    function remplir(message, techniciens) {
        selectTech.innerHTML = '';
        selectTech.add(new Option(message, ''));
        // new Option() traite le nom comme du texte : aucun risque d'injection HTML
        (techniciens || []).forEach(t => {
            const libelle = t.categorie_nom ? `${t.nom} — ${t.categorie_nom}` : t.nom;
            selectTech.add(new Option(libelle, t.id));
        });
        selectTech.disabled = !techniciens || techniciens.length === 0;
        if (techniciens && techniciens.length > 0) {
            aideTech.textContent = `${techniciens.length} technicien${techniciens.length > 1 ? 's' : ''} disponible${techniciens.length > 1 ? 's' : ''}. Le métier est indiqué à côté du nom.`;
        }
    }

    selectPartenaire.addEventListener('change', async function () {
        const requete = ++chargementEnCours;
        if (!this.value) {
            remplir("-- Choisir d'abord un partenaire --", null);
            aideTech.textContent = 'La liste des techniciens s’affichera après le choix du partenaire.';
            return;
        }

        selectTech.disabled = true;
        aideTech.textContent = 'Chargement des techniciens…';
        remplir('Chargement…', null);
        try {
            const url = new URL('../../public/api-techniciens.php', window.location.href);
            url.searchParams.set('partenaire_id', this.value);
            const res = await fetch(url);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const techniciens = await res.json();
            if (requete !== chargementEnCours) return;
            if (!Array.isArray(techniciens) || techniciens.length === 0) {
                remplir('Aucun technicien actif', null);
                aideTech.textContent = 'Aucun technicien actif n’est associé à ce partenaire.';
            } else {
                remplir('-- Choisir --', techniciens);
            }
        } catch (e) {
            if (requete !== chargementEnCours) return;
            console.error('Impossible de charger les techniciens du partenaire.', e);
            remplir('Erreur de chargement, réessayez', null);
            aideTech.textContent = 'Le chargement a échoué. Choisissez à nouveau le partenaire pour réessayer.';
        }
    });
}
</script>
</body>
</html>