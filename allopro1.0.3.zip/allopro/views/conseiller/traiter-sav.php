<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

if (!function_exists('h')) {
    function h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
}

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id) { header("Location: sav.php"); exit; }

$ticketModel = new TicketSav();
$ticket = $ticketModel->getById($id);
if (!$ticket) { http_response_code(404); die("Ticket introuvable."); }

$libellesStatut = ['ouvert' => 'Ouvert', 'en_cours' => 'En cours', 'resolu' => 'Résolu'];
$erreur = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nouveauStatut = $_POST['statut'] ?? '';
    $notes = trim($_POST['commentaire_conseiller'] ?? '');

    if (!isset($libellesStatut[$nouveauStatut])) {
        $erreur = "Statut invalide.";
    } else {
        $ticketModel->mettreAJour($id, $nouveauStatut, $notes);
        journaliser('sav.mis_a_jour', 'ticket_sav', $id, $ticket['numero_dossier'], $ticket['statut'] . ' → ' . $nouveauStatut);
        header("Location: sav.php");
        exit;
    }
}

// Après une erreur, on garde ce que le conseiller venait de saisir
$statutAffiche = $erreur ? ($_POST['statut'] ?? $ticket['statut']) : $ticket['statut'];
$notesAffichees = $erreur ? trim($_POST['commentaire_conseiller'] ?? '') : ($ticket['commentaire_conseiller'] ?? '');

// 5 étoiles en SVG : pleines jusqu'à la note, vides ensuite
function etoiles(int $note): string {
    $note = max(0, min(5, $note));
    $chemin = '<path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/>';
    $html = '<span class="etoiles" role="img" aria-label="Note : ' . $note . ' sur 5">';
    for ($i = 1; $i <= 5; $i++) {
        $html .= '<svg class="etoile ' . ($i <= $note ? 'etoile--pleine' : 'etoile--vide') . '" width="18" height="18" viewBox="0 0 24 24" stroke-linejoin="round" aria-hidden="true">' . $chemin . '</svg>';
    }
    return $html . '</span>';
}

$note = (int) ($ticket['note'] ?? 0);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ticket SAV <?= h($ticket['numero_dossier']) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/traiter-demande.css">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>

    <div class="contenu">

        <a href="sav.php" class="lien-retour">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>
            Retour aux tickets SAV
        </a>

        <div class="dossier-entete">
            <div>
                <h1 class="dossier-entete__titre">Ticket SAV — <?= h($ticket['numero_dossier']) ?></h1>
                <p class="dossier-entete__date">Ouvert le <?= date('d/m/Y à H:i', strtotime($ticket['date_creation'])) ?></p>
            </div>
            <div class="dossier-entete__badges">
                <span class="pastille pastille--<?= h($ticket['statut']) ?>"><?= h($libellesStatut[$ticket['statut']] ?? $ticket['statut']) ?></span>
            </div>
        </div>

        <div class="dossier-grille dossier-grille--sav">

            <!-- ===== Colonne gauche : détails du ticket ===== -->
            <section class="carte">
                <h2 class="carte__titre">Détails du ticket</h2>

                <div class="dossier__ligne">
                    <span>Client</span>
                    <span><strong><?= h($ticket['client_nom']) ?></strong><br><?= h($ticket['client_telephone']) ?></span>
                </div>

                <div class="dossier__ligne">
                    <span>Description initiale</span>
                    <span><?= nl2br(h($ticket['description'])) ?></span>
                </div>

                <div class="dossier__ligne">
                    <span>Note laissée</span>
                    <span class="note-avis">
                        <?= etoiles($note) ?>
                        <strong><?= $note ?>/5</strong>
                    </span>
                </div>

                <div class="dossier__ligne">
                    <span>Commentaire client</span>
                    <span>
                        <?php if (!empty($ticket['commentaire'])): ?>
                            <span class="citation-client"><?= nl2br(h($ticket['commentaire'])) ?></span>
                        <?php else: ?>
                            <span class="texte-doux">Aucun commentaire</span>
                        <?php endif; ?>
                    </span>
                </div>

                <?php if (!empty($ticket['client_id'])): ?>
                    <div class="dossier__ligne">
                        <a href="messagerie.php?client_id=<?= (int) $ticket['client_id'] ?>" class="bouton-message--ligne">
                            <svg class="icone-msg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>
                                <circle class="icone-msg__point" cx="8.5"  cy="12" r="1" fill="currentColor" stroke="none"/>
                                <circle class="icone-msg__point" cx="12"   cy="12" r="1" fill="currentColor" stroke="none"/>
                                <circle class="icone-msg__point" cx="15.5" cy="12" r="1" fill="currentColor" stroke="none"/>
                            </svg>
                            Écrire au client
                        </a>
                    </div>
                <?php endif; ?>
            </section>

            <!-- ===== Colonne droite : traitement ===== -->
            <div class="colonne-actions">

                <?php if ($erreur): ?>
                    <div class="alerte alerte--erreur" role="alert"><?= h($erreur) ?></div>
                <?php endif; ?>

                <section class="carte">
                    <h2 class="carte__titre">Traiter ce ticket</h2>

                    <form method="POST" id="form-sav">
                        <span class="champ-label">Statut</span>
                        <div class="choix-statut" role="radiogroup" aria-label="Statut du ticket">
                            <?php foreach ($libellesStatut as $cle => $label): ?>
                                <label class="choix-statut__option choix-statut__option--<?= h($cle) ?>">
                                    <input type="radio" name="statut" value="<?= h($cle) ?>" <?= $statutAffiche === $cle ? 'checked' : '' ?>>
                                    <span><?= h($label) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>

                        <label class="champ-label" for="commentaire_conseiller">Notes internes</label>
                        <textarea name="commentaire_conseiller" id="commentaire_conseiller" class="champ" rows="6" placeholder="Ce qui a été fait, décision prise, contact avec le partenaire..."><?= h($notesAffichees) ?></textarea>
                        <p class="aide-champ">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                            Visibles uniquement par l'équipe ALLÔ PRO, jamais par le client.
                        </p>

                        <button type="submit" class="btn btn--principal btn--plein">Enregistrer</button>
                    </form>
                </section>

            </div>
        </div>
    </div>
</div>

<script>
// Empêche le double envoi du formulaire (double clic)
document.getElementById('form-sav').addEventListener('submit', function () {
    var b = this.querySelector('button[type="submit"]');
    if (b) setTimeout(function () { b.disabled = true; b.textContent = 'Enregistrement…'; }, 0);
});
</script>
</body>
</html>