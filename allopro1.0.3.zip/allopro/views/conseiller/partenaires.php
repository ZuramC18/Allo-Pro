<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('partenaires');
require_once __DIR__ . '/../../models/Partenaire.php';

if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$recherche = trim((string) ($_GET['q'] ?? ''));
$partenaires = (new Partenaire())->getAllActifs();
if ($recherche !== '') {
    $partenaires = array_values(array_filter($partenaires, static function ($partenaire) use ($recherche): bool {
        $champs = [
            $partenaire['nom_entreprise'] ?? '',
            $partenaire['email'] ?? '',
            $partenaire['telephone'] ?? '',
            $partenaire['zone_intervention'] ?? '',
        ];
        foreach ($champs as $champ) {
            if (mb_stripos((string) $champ, $recherche) !== false) {
                return true;
            }
        }
        return false;
    }));
}

$niveaux = [
    'partenaire' => 'Partenaire',
    'certifie' => 'Certifié',
    'premium' => 'Premium',
    'excellence' => 'Excellence',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Partenaires — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/conseiller-partenaires.css?v=<?= filemtime(__DIR__ . '/../../public/css/conseiller-partenaires.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-conseiller-partenaires">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>

    <main class="contenu partenaires-page">
        <header class="contenu__entete">
            <div>
                <p class="partenaires-page__eyebrow">Réseau ALLÔ PRO</p>
                <h1 class="contenu__titre">Nos partenaires</h1>
                <p class="partenaires-page__intro">Retrouvez les entreprises partenaires et leurs coordonnées.</p>
            </div>
            <span class="partenaires-page__compteur"><?= count($partenaires) ?> partenaire<?= count($partenaires) === 1 ? '' : 's' ?></span>
        </header>

        <form class="partenaires-recherche" method="get" role="search">
            <label class="partenaires-recherche__champ">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="search" name="q" value="<?= h($recherche) ?>" placeholder="Entreprise, zone, téléphone ou email…" aria-label="Rechercher un partenaire">
            </label>
            <button type="submit" class="partenaires-recherche__bouton">Rechercher</button>
            <?php if ($recherche !== ''): ?>
                <a class="partenaires-recherche__reset" href="partenaires.php">Effacer</a>
            <?php endif; ?>
        </form>

        <?php if ($partenaires): ?>
            <section class="partenaires-grille" aria-label="Partenaires actifs">
                <?php foreach ($partenaires as $partenaire): ?>
                    <?php
                    $niveau = (string) ($partenaire['niveau'] ?? '');
                    $labelNiveau = $niveaux[$niveau] ?? 'Partenaire';
                    $score = (float) ($partenaire['score'] ?? 0);
                    ?>
                    <article class="partenaire-carte">
                        <div class="partenaire-carte__entete">
                            <div class="partenaire-carte__marque" aria-hidden="true">
                                <?= h(mb_strtoupper(mb_substr((string) ($partenaire['nom_entreprise'] ?? '?'), 0, 1))) ?>
                            </div>
                            <span class="partenaire-carte__niveau partenaire-carte__niveau--<?= h($niveau ?: 'partenaire') ?>"><?= h($labelNiveau) ?></span>
                        </div>
                        <h2 class="partenaire-carte__nom"><?= h($partenaire['nom_entreprise'] ?? 'Partenaire') ?></h2>
                        <p class="partenaire-carte__zone">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg>
                            <?= h($partenaire['zone_intervention'] ?? '') ?: 'Zone non renseignée' ?>
                        </p>
                        <div class="partenaire-carte__coordonnees">
                            <?php if (!empty($partenaire['telephone'])): ?>
                                <a href="tel:<?= h(preg_replace('/[^0-9+]/', '', (string) $partenaire['telephone'])) ?>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2A19.8 19.8 0 0 1 3.09 5.18 2 2 0 0 1 5.08 3h3a2 2 0 0 1 2 1.72c.12.9.34 1.78.65 2.62a2 2 0 0 1-.45 2.11L9 10.73a16 16 0 0 0 4.27 4.27l1.28-1.28a2 2 0 0 1 2.11-.45c.84.31 1.72.53 2.62.65A2 2 0 0 1 22 16.92Z"/></svg>
                                    <?= h($partenaire['telephone']) ?>
                                </a>
                            <?php endif; ?>
                            <?php if (!empty($partenaire['email'])): ?>
                                <a href="mailto:<?= h($partenaire['email']) ?>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
                                    <?= h($partenaire['email']) ?>
                                </a>
                            <?php endif; ?>
                            <?php if (empty($partenaire['telephone']) && empty($partenaire['email'])): ?>
                                <span>Coordonnées non renseignées</span>
                            <?php endif; ?>
                        </div>
                        <div class="partenaire-carte__pied">
                            <span>Évaluation</span>
                            <strong><?= $score > 0 ? h(number_format($score, 1, ',', '')) . ' / 5' : 'Pas encore noté' ?></strong>
                        </div>
                    </article>
                <?php endforeach; ?>
            </section>
        <?php else: ?>
            <div class="partenaires-vide">
                <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                <h2><?= $recherche !== '' ? 'Aucun résultat' : 'Aucun partenaire actif' ?></h2>
                <p><?= $recherche !== '' ? 'Essayez avec un autre nom, une autre zone ou des coordonnées différentes.' : 'Les partenaires actifs apparaîtront ici.' ?></p>
            </div>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
