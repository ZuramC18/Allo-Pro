<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('coordination');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Coordination — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/coordinateur.css">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-coordinateur.php'; ?>

<div class="coord-app">
    <aside class="coord-sidebar">
        <div class="coord-sidebar__filtres">
            <button class="coord-filtre" data-filtre="non_attribuees">Non attribuées <span class="coord-filtre__badge" id="badge-non_attribuees">0</span></button>
            <button class="coord-filtre" data-filtre="attribuees">Attribuées <span class="coord-filtre__badge" id="badge-attribuees">0</span></button>
            <button class="coord-filtre coord-filtre--actif" data-filtre="toutes">Toutes <span class="coord-filtre__badge" id="badge-toutes">0</span></button>
        </div>
        <div class="coord-sidebar__liste" id="coord-liste"><p class="coord-vide">Chargement…</p></div>
    </aside>

    <main class="coord-contenu">
        <div class="coord-accueil">
            <div class="coord-accueil__icone">🔀</div>
            <h2>Coordination des conversations</h2>
            <p>Sélectionnez une conversation dans la liste pour l'attribuer à un conseiller ou en consulter le contenu.</p>
        </div>
    </main>
</div>

<div class="coord-modale-fond" id="modale-attribution">
    <div class="coord-modale">
        <div class="coord-modale__entete">
            <h3>Attribuer <span id="attrib-nom-client"></span></h3>
            <button class="coord-modale__fermer" data-fermer>✕</button>
        </div>
        <input type="text" id="attrib-recherche" placeholder="Rechercher un conseiller..." class="coord-recherche">
        <div class="coord-conseillers-liste" id="attrib-liste"></div>
    </div>
</div>

<div class="coord-modale-fond" id="modale-conversation">
    <div class="coord-modale coord-modale--large">
        <div class="coord-modale__entete">
            <div>
                <h3 id="conv-nom-client"></h3>
                <div class="coord-modale__sous-titre" id="conv-conseiller-actuel"></div>
            </div>
            <div style="display:flex; align-items:center; gap:10px;">
                <button class="coord-btn-secondaire" id="btn-changer-conseiller">Changer de conseiller</button>
                <button class="coord-modale__fermer" data-fermer>✕</button>
            </div>
        </div>
        <div class="coord-fil" id="conv-fil"></div>
    </div>
</div>

<script src="../../public/js/coordinateur.js?v=<?= filemtime(__DIR__ . '/../../public/js/coordinateur.js') ?>"></script>
</body>
</html>