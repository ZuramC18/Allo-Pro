<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('messagerie');
require_once __DIR__ . '/../../models/Message.php';
require_once __DIR__ . '/../../models/NoteInterne.php';
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/ReponseRapide.php';

$messageModel = new Message();
$noteInterneModel = new NoteInterne();
$dossiersClientModel = new Demande();

$clientId = $_GET['client_id'] ?? ($conversations[0]['id'] ?? null);

$conversations = $messageModel->getConversationsConseiller();
$notesInternes = $clientId ? $noteInterneModel->getByClient($clientId) : [];
$dossiersClient = $clientId ? $dossiersClientModel->getByClient($clientId) : [];

$messages = [];
$clientActif = null;

if ($clientId) {
    foreach ($conversations as $c) { if ($c['id'] == $clientId) $clientActif = $c; }
    $messages = $messageModel->getByClient($clientId);
    $messageModel->marquerLues($clientId, 'conseiller');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note_interne'])) {
    $noteInterneModel->create($clientId, $_SESSION['user_id'], trim($_POST['note_interne']));
    header("Location: messagerie.php?client_id=" . $clientId . "#notes");
    exit;
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messagerie — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/messagerie.css">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    
    <div class="admin-contenu" style="margin:0; padding:0; max-width:100%; height:100vh;">
        <div class="messagerie" style="height:100vh;">
            <div class="conv-liste" id="conv-liste">
                <div class="conv-liste__entete">Conversations</div>
                <?php foreach ($conversations as $c): ?>
                    <?php $initiales = strtoupper(mb_substr($c['nom'], 0, 1) . mb_substr(strrchr($c['nom'], ' ') ?: '', 1, 1)); ?>
                    <a href="messagerie.php?client_id=<?= $c['id'] ?>" class="conv-item <?= $c['id'] == $clientId ? 'conv-item--active' : '' ?> <?= $c['conversation_statut'] === 'fermee' ? 'conv-item--fermee' : '' ?>">
                        <div class="conv-item__avatar"><?= htmlspecialchars($initiales) ?></div>
                        <div class="conv-item__contenu">
                            <div class="conv-item__haut">
                                <span class="conv-item__nom"><?= htmlspecialchars($c['nom']) ?></span>
                                <div class="conv-item__date-bloc">
                                    <span class="conv-item__date"><?= date('d/m', strtotime($c['derniere_date'])) ?></span>
                                    <?php if ($c['conversation_statut'] === 'fermee'): ?>
                                        <span class="conv-item__ferme-label">Fermé</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="conv-item__apercu"><?= $c['dernier_message'] ? htmlspecialchars($c['dernier_message']) : '<em>Aucun message</em>' ?></div>
                        </div>
                        <?php if ($c['non_lus'] > 0): ?><span class="conv-item__badge"><?= $c['non_lus'] ?></span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>

            <?php if ($clientActif): ?>
                <div class="fil">
                    <div class="fil__entete">
                        <div class="fil__entete-avatar"><?= htmlspecialchars(strtoupper(mb_substr($clientActif['nom'], 0, 1))) ?></div>
                        <div class="fil__titre"><?= htmlspecialchars($clientActif['nom']) ?></div>
                    </div>
                    <div class="fil__corps" id="fil-corps" data-retour="messagerie.php" data-client-id="<?= $clientId ?>" data-viewer="conseiller" data-viewer-id="<?= $_SESSION['user_id'] ?>">
                        <?php foreach ($messages as $m): ?>
                            <div class="bulle <?= $m['expediteur_type'] === 'conseiller' ? 'bulle--moi' : 'bulle--autre' ?>"
                                data-id="<?= $m['id'] ?>"
                                data-expediteur-type="<?= htmlspecialchars($m['expediteur_type']) ?>"
                                data-expediteur-id="<?= $m['expediteur_id'] ?>"
                                data-lu="<?= $m['lu'] ?>"
                                data-lu-date="<?= htmlspecialchars($m['lu_date'] ?? '') ?>"
                                data-modifie="<?= $m['modifie'] ?>">
                                <div class="bulle__meta">
                                    <?= htmlspecialchars($m['nom_expediteur'] ?? ucfirst($m['expediteur_type'])) ?> · <?= date('d/m H:i', strtotime($m['date_creation'])) ?>
                                    <?= $m['modifie'] ? ' · <span class="bulle__modifie">modifié</span>' : '' ?>
                                </div>
                                <span class="bulle__texte"><?= nl2br(htmlspecialchars($m['contenu'])) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if ($clientActif['conversation_statut'] === 'ouverte'): ?>
                        <div class="suggestions-rr" id="suggestions-rr"></div>
                        <div class="fil__pied">
                            <textarea id="champ-message" rows="1" placeholder="Écrire un message..."></textarea>
                            <button id="btn-envoyer">➤</button>
                        </div>
                    <?php else: ?>
                        <div class="fil__fermee">Conversation clôturée — le client peut la réouvrir depuis son espace.</div>
                    <?php endif; ?>
                </div>
                <div class="reponses-rapides" id="reponses-rapides">
                    <div class="reponses-rapides__titre">
                        Réponses rapides
                        <button class="reponses-rapides__ajouter" id="rr-ouvrir-creation" title="Ajouter">+</button>
                    </div>
                    <div id="rr-liste"></div>
                </div>

                <div class="rr-modale-fond" id="rr-modale-fond">
                    <div class="rr-modale">
                        <h3 id="rr-modale-titre">Nouvelle réponse rapide</h3>
                        <input type="hidden" id="rr-id">
                        <label>Titre</label>
                        <input type="text" id="rr-champ-titre" placeholder="ex : Salutation standard">
                        <label>Catégorie</label>
                        <input type="text" id="rr-champ-categorie" placeholder="ex : Salutations">
                        <label>Mots-clés déclencheurs (séparés par des virgules)</label>
                        <input type="text" id="rr-champ-mots-cles" placeholder="ex : salutation, salut, bonjour">
                        <label>Message</label>
                        <textarea id="rr-champ-contenu" rows="4"></textarea>
                        <div class="rr-modale__actions">
                            <button class="rr-modale__supprimer" id="rr-supprimer" style="display:none;">Supprimer</button>
                            <button class="rr-modale__annuler" id="rr-annuler">Annuler</button>
                            <button class="rr-modale__valider" id="rr-valider">Enregistrer</button>
                        </div>
                    </div>
                </div>
                <?php if ($clientActif): ?>
                <div class="info-client" data-fiche-client>
                    <div class="info-client__avatar"><?= htmlspecialchars(strtoupper(mb_substr($clientActif['nom'], 0, 1))) ?></div>
                    <div class="info-client__nom"><?= htmlspecialchars($clientActif['nom']) ?></div>
                    <span class="badge badge-padding badge--<?= $clientActif['conversation_statut'] === 'ouverte' ? 'terminee' : 'annulee' ?>" style="margin-top:6px;">
                        <?= $clientActif['conversation_statut'] === 'ouverte' ? 'Conversation ouverte' : 'Conversation fermée' ?>
                    </span>
                    <div class="info-client-all">
                        <div class="info-client__section">
                            <div class="info-client__label">Téléphone</div>
                            <div class="info-client__valeur"><?= htmlspecialchars($clientActif['telephone'] ?: '—') ?></div>
                        </div>

                        <div class="info-client__section">
                            <div class="info-client__label">Email</div>
                            <div class="info-client__valeur"><?= htmlspecialchars($clientActif['email'] ?: '—') ?></div>
                        </div>

                        <div class="info-client__section">
                            <div class="info-client__label">Dossiers (<?= count($dossiersClient) ?>)</div>
                            <div class="dossiers-liste">
                                <?php if (empty($dossiersClient)): ?>
                                    <p style="font-size:13px; color:#9CA3AF;">Aucun dossier.</p>
                                <?php endif; ?>
                                <?php foreach ($dossiersClient as $d): ?>
                                    <a href="../conseiller/traiter-demande.php?id=<?= $d['id'] ?>" class="info-client__dossier">
                                        <span><?= htmlspecialchars($d['numero_dossier']) ?></span>
                                        <span class="badge badge--<?= $d['statut'] ?>" style="font-size:10px;"><?= htmlspecialchars($d['statut']) ?></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="info-client__section" id="notes">
                            <div class="info-client__label">Notes internes</div>

                            <form method="POST" style="margin-bottom:12px;">
                                <textarea name="note_interne" rows="2" placeholder="Ajouter une note (visible par l'équipe uniquement)..." required style="width:100%; padding:8px 10px; border:1px solid var(--bordure); border-radius:6px; font-family:'Inter',sans-serif; font-size:13px; resize:vertical;"></textarea>
                                <button type="submit" class="bouton bouton--secondaire" style="width:100%; margin-top:6px; padding:7px; font-size:13px;">Ajouter la note</button>
                            </form>

                            <div class="notes-liste">
                                <?php if (empty($notesInternes)): ?>
                                    <p style="font-size:12px; color:#9CA3AF;">Aucune note pour ce client.</p>
                                <?php endif; ?>
                                <?php foreach ($notesInternes as $n): ?>
                                    <div class="note-interne">
                                        <div class="note-interne__meta"><?= htmlspecialchars($n['conseiller_nom']) ?> · <?= date('d/m/Y H:i', strtotime($n['date_creation'])) ?></div>
                                        <div class="note-interne__texte"><?= nl2br(htmlspecialchars($n['contenu'])) ?></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="conv-vide">Sélectionnez une conversation</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="menu-contextuel" id="menu-contextuel">
    <button class="menu-contextuel__item" id="btn-copier">Copier le texte</button>
    <button class="menu-contextuel__item" id="btn-modifier">Modifier le message</button>
</div>

<div class="modale-fond" id="modale-fond">
    <div class="modale">
        <h3>Modifier le message</h3>
        <textarea id="modale-textarea"></textarea>
        <div class="modale__actions">
            <button class="modale__annuler" id="modale-annuler">Annuler</button>
            <button class="modale__valider" id="modale-valider">Enregistrer</button>
        </div>
    </div>
</div>

<?php $reponsesRapides = (new ReponseRapide())->getAll(); ?>
<script>
    const REPONSES_RAPIDES = <?= json_encode($reponsesRapides, JSON_UNESCAPED_UNICODE) ?>;
</script>
<script src="../../public/js/messagerie.js"></script>
<script src="../../public/js/reponses-rapides.js"></script>
</body>
</html>