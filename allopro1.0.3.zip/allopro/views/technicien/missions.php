<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../models/Tache.php';

$mesMissions = (new Intervention())->getByTechnicien($_SESSION['technicien_id']);
$filtreStatut = is_string($_GET['statut'] ?? null) ? $_GET['statut'] : '';
$filtreUrgence = is_string($_GET['urgence'] ?? null) ? $_GET['urgence'] : '';
$recherche = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
$recherche = mb_substr($recherche, 0, 100, 'UTF-8');

if (!in_array($filtreStatut, ['', 'actives', 'terminee'], true)) {
    $filtreStatut = '';
}
if (!in_array($filtreUrgence, ['', 'urgente'], true)) {
    $filtreUrgence = '';
}

$statutsLibelles = [
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Sur place',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$missionsActives = array_filter($mesMissions, static fn(array $mission): bool => !in_array($mission['statut'], ['terminee', 'annulee'], true));
$missionsTerminees = array_filter($mesMissions, static fn(array $mission): bool => $mission['statut'] === 'terminee');
$missionsUrgentes = array_filter($mesMissions, static fn(array $mission): bool => $mission['urgence'] === 'urgente');

$missionsFiltrees = array_values(array_filter($mesMissions, static function (array $mission) use ($filtreStatut, $filtreUrgence, $recherche): bool {
    $correspondStatut = $filtreStatut === ''
        || ($filtreStatut === 'actives' && !in_array($mission['statut'], ['terminee', 'annulee'], true))
        || ($filtreStatut === 'terminee' && $mission['statut'] === 'terminee');
    $correspondUrgence = $filtreUrgence === '' || $mission['urgence'] === 'urgente';
    $correspondRecherche = $recherche === ''
        || stripos((string) $mission['numero_dossier'], $recherche) !== false
        || stripos((string) $mission['categorie_nom'], $recherche) !== false
        || stripos((string) $mission['quartier'], $recherche) !== false
        || stripos((string) $mission['ville'], $recherche) !== false;
    return $correspondStatut && $correspondUrgence && $correspondRecherche;
}));

$urlFiltre = static function (array $modifications = []) use ($filtreStatut, $filtreUrgence, $recherche): string {
    $parametres = ['statut' => $filtreStatut, 'urgence' => $filtreUrgence, 'q' => $recherche];
    foreach ($modifications as $cle => $valeur) {
        $parametres[$cle] = $valeur;
    }
    return 'missions.php' . (array_filter($parametres, static fn($valeur): bool => $valeur !== '') ? '?' . http_build_query(array_filter($parametres, static fn($valeur): bool => $valeur !== '')) : '');
};
$filtreActif = $filtreStatut !== '' || $filtreUrgence !== '' || $recherche !== '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes missions — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/technicien-missions.css?v=<?= filemtime(__DIR__ . '/../../public/css/technicien-missions.css') ?>">
</head>
<body class="page-technicien-missions">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>

    <main class="contenu technicien-missions-page">
        <header class="missions-hero">
            <div class="missions-hero__texte">
                <span class="missions-hero__surtitre">Votre activité</span>
                <h1>Mes missions</h1>
                <p>Retrouvez vos interventions, suivez leur avancement et accédez rapidement à leurs détails.</p>
            </div>
            <div class="missions-hero__resume" aria-label="<?= count($missionsActives) ?> mission(s) à suivre">
                <span><?= icone('wrench', 21) ?></span>
                <strong><?= count($missionsActives) ?></strong>
                <small><?= count($missionsActives) === 1 ? 'mission à suivre' : 'missions à suivre' ?></small>
            </div>
        </header>

        <div class="missions-rappels">
            <?php include __DIR__ . '/../../includes/rappels-technicien.php'; ?>
        </div>

        <section class="missions-indicateurs" aria-label="Résumé de vos missions">
            <a class="missions-indicateur missions-indicateur--actives <?= $filtreStatut === 'actives' ? 'missions-indicateur--selectionne' : '' ?>" href="<?= $echapper($urlFiltre(['statut' => 'actives'])) ?>">
                <span class="missions-indicateur__icone"><?= icone('refresh', 18) ?></span>
                <span class="missions-indicateur__texte"><strong><?= count($missionsActives) ?></strong><small>À suivre</small></span>
                <span class="missions-indicateur__fleche"><?= icone('arrow', 15) ?></span>
            </a>
            <a class="missions-indicateur missions-indicateur--urgentes <?= $filtreUrgence === 'urgente' ? 'missions-indicateur--selectionne' : '' ?>" href="<?= $echapper($urlFiltre(['urgence' => $filtreUrgence === 'urgente' ? '' : 'urgente'])) ?>">
                <span class="missions-indicateur__icone"><?= icone('bolt', 18) ?></span>
                <span class="missions-indicateur__texte"><strong><?= count($missionsUrgentes) ?></strong><small>Urgentes</small></span>
                <span class="missions-indicateur__fleche"><?= icone('arrow', 15) ?></span>
            </a>
            <a class="missions-indicateur missions-indicateur--terminees <?= $filtreStatut === 'terminee' ? 'missions-indicateur--selectionne' : '' ?>" href="<?= $echapper($urlFiltre(['statut' => 'terminee'])) ?>">
                <span class="missions-indicateur__icone"><?= icone('check', 18) ?></span>
                <span class="missions-indicateur__texte"><strong><?= count($missionsTerminees) ?></strong><small>Terminées</small></span>
                <span class="missions-indicateur__fleche"><?= icone('arrow', 15) ?></span>
            </a>
        </section>

        <section class="missions-liste" aria-labelledby="missions-liste-titre">
            <header class="missions-liste__entete">
                <div>
                    <span class="missions-liste__surtitre">Votre portefeuille</span>
                    <h2 id="missions-liste-titre"><?= $filtreActif ? 'Résultats' : 'Toutes vos missions' ?></h2>
                    <p><?= count($missionsFiltrees) ?> <?= count($missionsFiltrees) === 1 ? 'intervention affichée' : 'interventions affichées' ?></p>
                </div>
                <form class="missions-recherche" method="GET" action="missions.php" role="search">
                    <?php if ($filtreStatut !== ''): ?><input type="hidden" name="statut" value="<?= $echapper($filtreStatut) ?>"><?php endif; ?>
                    <?php if ($filtreUrgence !== ''): ?><input type="hidden" name="urgence" value="<?= $echapper($filtreUrgence) ?>"><?php endif; ?>
                    <label class="missions-recherche__label" for="missions-recherche"><?= icone('search', 17) ?><span>Rechercher une mission</span></label>
                    <input id="missions-recherche" type="search" name="q" value="<?= $echapper($recherche) ?>" placeholder="Dossier, catégorie, quartier…" autocomplete="off">
                    <button type="submit">Rechercher</button>
                </form>
            </header>

            <nav class="missions-filtres" aria-label="Filtrer les missions">
                <a class="<?= $filtreStatut === '' && $filtreUrgence === '' ? 'missions-filtre--actif' : '' ?>" href="<?= $echapper($urlFiltre(['statut' => '', 'urgence' => ''])) ?>">Toutes <span><?= count($mesMissions) ?></span></a>
                <a class="<?= $filtreStatut === 'actives' ? 'missions-filtre--actif' : '' ?>" href="<?= $echapper($urlFiltre(['statut' => 'actives'])) ?>">À suivre <span><?= count($missionsActives) ?></span></a>
                <a class="<?= $filtreStatut === 'terminee' ? 'missions-filtre--actif' : '' ?>" href="<?= $echapper($urlFiltre(['statut' => 'terminee'])) ?>">Terminées <span><?= count($missionsTerminees) ?></span></a>
                <a class="<?= $filtreUrgence === 'urgente' ? 'missions-filtre--actif' : '' ?>" href="<?= $echapper($urlFiltre(['urgence' => $filtreUrgence === 'urgente' ? '' : 'urgente'])) ?>">Urgentes <span><?= count($missionsUrgentes) ?></span></a>
                <?php if ($filtreActif): ?><a class="missions-filtres__effacer" href="missions.php">Effacer les filtres</a><?php endif; ?>
            </nav>

            <?php if ($missionsFiltrees): ?>
                <div class="missions-cartes">
                    <?php foreach ($missionsFiltrees as $mission): ?>
                        <?php
                        $statut = (string) $mission['statut'];
                        $missionUrgente = $mission['urgence'] === 'urgente';
                        $missionEstTerminee = $statut === 'terminee';
                        $statutClasse = in_array($statut, ['acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours', 'terminee', 'annulee'], true) ? $statut : 'autre';
                        $dateDebut = !empty($mission['date_debut']) ? strtotime($mission['date_debut']) : false;
                        ?>
                        <article class="mission-carte-liste <?= $missionUrgente && !$missionEstTerminee ? 'mission-carte-liste--urgente' : '' ?>">
                            <div class="mission-carte-liste__marque <?= $missionUrgente && !$missionEstTerminee ? 'mission-carte-liste__marque--urgente' : '' ?>">
                                <?= iconePole($mission['categorie_nom'], 20) ?>
                            </div>
                            <div class="mission-carte-liste__principal">
                                <div class="mission-carte-liste__ligne">
                                    <span class="mission-carte-liste__numero"><?= $echapper($mission['numero_dossier']) ?></span>
                                    <?php if ($missionUrgente && !$missionEstTerminee): ?><span class="mission-badge-urgence"><?= icone('bolt', 12) ?> Urgente</span><?php endif; ?>
                                </div>
                                <strong class="mission-carte-liste__categorie"><?= $echapper($mission['categorie_nom']) ?></strong>
                                <span class="mission-carte-liste__lieu"><?= icone('pin', 14) ?> <?= $echapper($mission['quartier']) ?><?= !empty($mission['ville']) ? ', ' . $echapper($mission['ville']) : '' ?></span>
                            </div>
                            <div class="mission-carte-liste__meta">
                                <?php if ($dateDebut !== false): ?><span class="mission-carte-liste__date"><?= icone('clock', 14) ?> <?= date('d/m/Y', $dateDebut) ?></span><?php endif; ?>
                                <span class="mission-statut-liste mission-statut-liste--<?= $echapper($statutClasse) ?>"><i></i><?= $echapper($statutsLibelles[$statut] ?? ucfirst(str_replace('_', ' ', $statut))) ?></span>
                            </div>
                            <a class="mission-carte-liste__ouvrir" href="mission.php?id=<?= (int) $mission['id'] ?>" aria-label="Ouvrir la mission <?= $echapper($mission['numero_dossier']) ?>">
                                <span>Ouvrir</span><?= icone('arrow', 16) ?>
                            </a>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="missions-vide">
                    <span><?= icone($filtreActif ? 'search' : 'wrench', 24) ?></span>
                    <h3><?= $mesMissions ? 'Aucune mission trouvée' : 'Votre liste est encore vide' ?></h3>
                    <p><?= $mesMissions ? 'Essayez de modifier votre recherche ou vos filtres.' : 'Les interventions qui vous seront attribuées apparaîtront ici.' ?></p>
                    <?php if ($filtreActif): ?><a href="missions.php">Afficher toutes mes missions</a><?php endif; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
