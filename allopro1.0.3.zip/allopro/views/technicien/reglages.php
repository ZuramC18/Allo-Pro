<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();
require_once __DIR__ . '/../../models/Technicien.php';

$technicienId = (int) $_SESSION['technicien_id'];
$technicienModel = new Technicien();
$technicien = $technicienModel->getById($technicienId);
if (!$technicien) {
    http_response_code(404);
    exit('Compte technicien introuvable.');
}

$csrfSession = 'csrf_technicien_reglages';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}
$flashSession = 'flash_technicien_reglages';
$messageSucces = is_string($_SESSION[$flashSession] ?? null) ? $_SESSION[$flashSession] : '';
unset($_SESSION[$flashSession]);
$erreur = '';
$prenomSaisi = (string) ($technicien['prenom'] ?? '');
$nomFamilleSaisi = (string) ($technicien['nom_famille'] ?? '');
if ($prenomSaisi === '' && $nomFamilleSaisi === '') {
    $motsNomExistant = preg_split('/\s+/u', trim((string) $technicien['nom']), 2, PREG_SPLIT_NO_EMPTY) ?: [];
    $prenomSaisi = $motsNomExistant[0] ?? '';
    $nomFamilleSaisi = $motsNomExistant[1] ?? '';
}
$telephoneSaisi = (string) ($technicien['telephone'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jeton = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION[$csrfSession], $jeton)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (($_POST['action'] ?? '') === 'profil') {
        $prenomSaisi = is_string($_POST['prenom'] ?? null) ? trim($_POST['prenom']) : '';
        $nomFamilleSaisi = is_string($_POST['nom_famille'] ?? null) ? trim($_POST['nom_famille']) : '';
        $telephoneSaisi = is_string($_POST['telephone'] ?? null) ? trim($_POST['telephone']) : '';

        if ($prenomSaisi === '' || mb_strlen($prenomSaisi, 'UTF-8') > 100) {
            $erreur = 'Saisissez un prénom de 100 caractères maximum.';
        } elseif (mb_strlen($nomFamilleSaisi, 'UTF-8') > 100) {
            $erreur = 'Le nom ne peut pas dépasser 100 caractères.';
        } elseif (mb_strlen(trim($prenomSaisi . ' ' . $nomFamilleSaisi), 'UTF-8') > 100) {
            $erreur = 'Le prénom et le nom ne peuvent pas dépasser 100 caractères au total.';
        } elseif (mb_strlen($telephoneSaisi, 'UTF-8') > 30) {
            $erreur = 'Le numéro de téléphone ne peut pas dépasser 30 caractères.';
        } else {
            try {
                if ($technicienModel->updateProfil($technicienId, $prenomSaisi, $nomFamilleSaisi, $telephoneSaisi)) {
                    $_SESSION['technicien_nom'] = $prenomSaisi . ' ' . $nomFamilleSaisi;
                    $_SESSION[$flashSession] = 'Vos informations personnelles ont été mises à jour.';
                    header('Location: reglages.php');
                    exit;
                }
                $erreur = 'Vos informations n’ont pas pu être enregistrées. Réessayez.';
            } catch (PDOException $exception) {
                error_log('Mise à jour du profil technicien ' . $technicienId . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de la mise à jour de votre profil.';
            }
        }
    } elseif (($_POST['action'] ?? '') === 'photo_profil') {
        $fichier = $_FILES['photo_profil'] ?? null;
        if (!is_array($fichier) || !isset($fichier['error'])) {
            $erreur = 'Choisissez une photo avant de continuer.';
        } elseif ($fichier['error'] !== UPLOAD_ERR_OK) {
            $codeErreurUpload = (int) $fichier['error'];
            $erreur = match ($codeErreurUpload) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'La photo dépasse la taille maximale autorisée de 5 Mo.',
                UPLOAD_ERR_NO_FILE => 'Choisissez une photo avant de continuer.',
                default => 'La photo n’a pas pu être reçue. Réessayez.',
            };
        } elseif ((int) ($fichier['size'] ?? 0) > 5 * 1024 * 1024) {
            $erreur = 'La photo ne doit pas dépasser 5 Mo.';
        } elseif (!is_uploaded_file((string) ($fichier['tmp_name'] ?? ''))) {
            $erreur = 'Le fichier transmis n’est pas un téléversement valide.';
        } else {
            $image = @getimagesize($fichier['tmp_name']);
            $typesImage = [
                IMAGETYPE_JPEG => ['extension' => 'jpg', 'mime' => 'image/jpeg'],
                IMAGETYPE_PNG => ['extension' => 'png', 'mime' => 'image/png'],
                IMAGETYPE_WEBP => ['extension' => 'webp', 'mime' => 'image/webp'],
            ];
            $typeImage = is_array($image) ? ($typesImage[$image[2] ?? 0] ?? null) : null;
            $mimeDetecte = (new finfo(FILEINFO_MIME_TYPE))->file($fichier['tmp_name']);

            if (!$typeImage || $mimeDetecte !== $typeImage['mime']) {
                $erreur = 'Format invalide. Utilisez une image JPG, PNG ou WebP.';
            } elseif ((int) ($image[0] ?? 0) < 1 || (int) ($image[1] ?? 0) < 1
                || (int) $image[0] * (int) $image[1] > 25000000) {
                $erreur = 'Les dimensions de cette image ne sont pas prises en charge.';
            } else {
                $dossierPhotos = __DIR__ . '/../../public/uploads/techniciens/';
                if (!is_dir($dossierPhotos) && !mkdir($dossierPhotos, 0755, true) && !is_dir($dossierPhotos)) {
                    error_log('Création du dossier de photos de profil technicien impossible.');
                    $erreur = 'Le stockage des photos est indisponible pour le moment.';
                } else {
                    $nomFichier = bin2hex(random_bytes(16)) . '.' . $typeImage['extension'];
                    $cheminNouveau = 'uploads/techniciens/' . $nomFichier;
                    $cheminAbsoluNouveau = $dossierPhotos . $nomFichier;
                    try {
                        if (!move_uploaded_file($fichier['tmp_name'], $cheminAbsoluNouveau)) {
                            $erreur = 'La photo n’a pas pu être enregistrée. Réessayez.';
                        } elseif (!$technicienModel->updatePhotoProfil($technicienId, $cheminNouveau)) {
                            if (is_file($cheminAbsoluNouveau)) {
                                unlink($cheminAbsoluNouveau);
                            }
                            $erreur = 'La photo n’a pas pu être associée à votre compte.';
                        } else {
                            $anciennePhoto = (string) ($technicien['photo_profil'] ?? '');
                            if (preg_match('#^uploads/techniciens/[a-f0-9]{32}\.(?:jpg|png|webp)$#', $anciennePhoto)) {
                                $cheminAbsoluAncien = __DIR__ . '/../../public/' . $anciennePhoto;
                                if (is_file($cheminAbsoluAncien)) {
                                    unlink($cheminAbsoluAncien);
                                }
                            }
                            $_SESSION['technicien_photo_profil'] = $cheminNouveau;
                            $_SESSION[$flashSession] = 'Votre photo de profil a été mise à jour.';
                            header('Location: reglages.php');
                            exit;
                        }
                    } catch (PDOException $exception) {
                        if (is_file($cheminAbsoluNouveau)) {
                            unlink($cheminAbsoluNouveau);
                        }
                        error_log('Photo de profil technicien ' . $technicienId . ' : ' . $exception->getMessage());
                        $erreur = 'Une erreur est survenue lors de l’enregistrement de votre photo.';
                    }
                }
            }
        }
    } elseif (($_POST['action'] ?? '') === 'avatar_initiales') {
        $afficherInitiales = ($_POST['avatar_initiales'] ?? '0') === '1';
        try {
            if ($technicienModel->definirAvatarInitiales($technicienId, $afficherInitiales)) {
                $_SESSION['technicien_avatar_initiales'] = $afficherInitiales;
                $_SESSION[$flashSession] = $afficherInitiales
                    ? 'La photo est masquée : vos initiales seront affichées.'
                    : (preg_match('#^uploads/techniciens/[a-f0-9]{32}\.(?:jpg|png|webp)$#', (string) ($technicien['photo_profil'] ?? '')) === 1
                        ? 'L’affichage de votre photo de profil est activé.'
                        : 'Le pictogramme de profil par défaut est affiché.');
                header('Location: reglages.php');
                exit;
            }
            $erreur = 'Votre préférence d’affichage n’a pas pu être enregistrée.';
        } catch (PDOException $exception) {
            error_log('Préférence avatar technicien ' . $technicienId . ' : ' . $exception->getMessage());
            $erreur = 'Une erreur est survenue lors de l’enregistrement de votre préférence.';
        }
    } elseif (($_POST['action'] ?? '') === 'supprimer_photo') {
        try {
            if ($technicienModel->updatePhotoProfil($technicienId, null)) {
                $anciennePhoto = (string) ($technicien['photo_profil'] ?? '');
                if (preg_match('#^uploads/techniciens/[a-f0-9]{32}\.(?:jpg|png|webp)$#', $anciennePhoto)) {
                    $cheminAbsoluAncien = __DIR__ . '/../../public/' . $anciennePhoto;
                    if (is_file($cheminAbsoluAncien)) {
                        unlink($cheminAbsoluAncien);
                    }
                }
                $_SESSION['technicien_photo_profil'] = null;
                $_SESSION[$flashSession] = 'Votre photo a été supprimée. Le pictogramme par défaut sera utilisé.';
                header('Location: reglages.php');
                exit;
            }
            $erreur = 'Votre photo n’a pas pu être supprimée. Réessayez.';
        } catch (PDOException $exception) {
            error_log('Suppression photo technicien ' . $technicienId . ' : ' . $exception->getMessage());
            $erreur = 'Une erreur est survenue lors de la suppression de votre photo.';
        }
    } elseif (isset($_POST['nouveau_mot_de_passe'])) {
        $actuel = is_string($_POST['mot_de_passe_actuel'] ?? null) ? $_POST['mot_de_passe_actuel'] : '';
        $nouveau = is_string($_POST['nouveau_mot_de_passe']) ? $_POST['nouveau_mot_de_passe'] : '';
        $confirmation = is_string($_POST['confirmation_mot_de_passe'] ?? null) ? $_POST['confirmation_mot_de_passe'] : '';

        if (!password_verify($actuel, $technicien['mot_de_passe'])) {
            $erreur = 'Le mot de passe actuel est incorrect.';
        } elseif ($nouveau !== $confirmation) {
            $erreur = 'Les deux nouveaux mots de passe ne correspondent pas.';
        } elseif (strlen($nouveau) < 6) {
            $erreur = 'Le nouveau mot de passe doit contenir au moins 6 caractères.';
        } else {
            try {
                if ($technicienModel->updateMotDePasse($technicienId, $nouveau)) {
                    $_SESSION[$flashSession] = 'Votre mot de passe a été modifié avec succès.';
                    header('Location: reglages.php');
                    exit;
                }
                $erreur = 'Votre mot de passe n’a pas pu être modifié. Réessayez.';
            } catch (PDOException $exception) {
                error_log('Modification du mot de passe technicien ' . $technicienId . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de la modification du mot de passe.';
            }
        }
    } else {
        $erreur = 'Formulaire non reconnu. Rechargez la page puis réessayez.';
    }
}

$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$motsNom = preg_split('/\s+/u', trim((string) $technicien['nom']), -1, PREG_SPLIT_NO_EMPTY) ?: [];
$initiales = mb_strtoupper(
    mb_substr($motsNom[0] ?? '?', 0, 1, 'UTF-8')
        . (count($motsNom) > 1 ? mb_substr($motsNom[count($motsNom) - 1], 0, 1, 'UTF-8') : ''),
    'UTF-8'
);
$cheminPhotoProfil = (string) ($technicien['photo_profil'] ?? '');
$photoProfilValide = preg_match('#^uploads/techniciens/[a-f0-9]{32}\.(?:jpg|png|webp)$#', $cheminPhotoProfil) === 1;
$avatarInitiales = (bool) ($technicien['avatar_initiales'] ?? false);
$photoProfilAffichee = $photoProfilValide && !$avatarInitiales;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Réglages — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/technicien-reglages.css?v=<?= filemtime(__DIR__ . '/../../public/css/technicien-reglages.css') ?>">
</head>
<body class="page-technicien-reglages">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>

    <main class="contenu technicien-reglages-page">
        <header class="reglages-hero">
            <div>
                <span class="reglages-hero__surtitre">Votre espace personnel</span>
                <h1>Réglages</h1>
                <p>Gérez vos informations et protégez l’accès à votre compte.</p>
            </div>
            <div class="reglages-profil-resume">
                <span class="reglages-profil-resume__avatar <?= $photoProfilAffichee ? 'reglages-avatar--photo' : '' ?>" data-avatar-preview>
                    <?php if ($photoProfilAffichee): ?>
                        <img src="../../public/<?= $echapper($cheminPhotoProfil) ?>" alt="" decoding="async">
                    <?php elseif ($avatarInitiales): ?>
                        <?= $echapper($initiales) ?>
                    <?php else: ?>
                        <?= icone('user', 22) ?>
                    <?php endif; ?>
                </span>
                <span><strong><?= $echapper($technicien['nom']) ?></strong><small>Technicien ALLÔ PRO</small></span>
            </div>
        </header>

        <?php if ($messageSucces !== ''): ?>
            <div class="reglages-message reglages-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur !== ''): ?>
            <div class="reglages-message reglages-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <div class="reglages-grille">
            <section class="reglages-carte" aria-labelledby="reglages-profil-titre">
                <header class="reglages-carte__entete">
                    <span class="reglages-carte__icone"><?= icone('users', 19) ?></span>
                    <div><h2 id="reglages-profil-titre">Informations personnelles</h2><p>Les informations utilisées pour vous contacter.</p></div>
                </header>
                <div class="reglages-photo-profil">
                    <div class="reglages-photo-profil__apercu">
                        <span class="reglages-avatar-preview <?= $photoProfilAffichee ? 'reglages-avatar--photo' : '' ?>" data-avatar-preview>
                            <?php if ($photoProfilAffichee): ?>
                                <img src="../../public/<?= $echapper($cheminPhotoProfil) ?>" alt="" decoding="async">
                            <?php elseif ($avatarInitiales): ?>
                                <?= $echapper($initiales) ?>
                            <?php else: ?>
                                <?= icone('user', 28) ?>
                            <?php endif; ?>
                        </span>
                        <div>
                            <strong>Photo de profil</strong>
                            <p>JPG, PNG ou WebP · 5 Mo maximum</p>
                        </div>
                    </div>
                    <form method="POST" enctype="multipart/form-data" class="reglages-photo-profil__formulaire">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                        <input type="hidden" name="action" value="photo_profil">
                        <label class="reglages-choisir-photo" for="reglages-photo-input">
                            <?= icone('camera', 16) ?> <?= $photoProfilValide ? 'Choisir une nouvelle photo' : 'Choisir une photo' ?>
                        </label>
                        <input id="reglages-photo-input" type="file" name="photo_profil" accept="image/jpeg,image/png,image/webp" required>
                        <button class="reglages-bouton reglages-bouton--photo" type="submit"><?= icone('check', 15) ?> Enregistrer la photo</button>
                    </form>
                    <?php if ($photoProfilValide): ?>
                        <form method="POST" class="reglages-photo-profil__suppression" onsubmit="return confirm('Supprimer votre photo de profil ?');">
                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                            <input type="hidden" name="action" value="supprimer_photo">
                            <button type="submit"><?= icone('x', 14) ?> Supprimer la photo</button>
                        </form>
                    <?php endif; ?>
                    <form method="POST" class="reglages-avatar-toggle">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                        <input type="hidden" name="action" value="avatar_initiales">
                        <input type="hidden" name="avatar_initiales" value="0">
                        <div>
                            <strong>Afficher mes initiales</strong>
                            <small><?= $photoProfilValide ? 'Masquer la photo et utiliser vos initiales à sa place.' : 'Remplacer le pictogramme par défaut par vos initiales.' ?></small>
                        </div>
                        <label class="reglages-switch">
                            <input type="checkbox" name="avatar_initiales" value="1" role="switch" aria-label="Afficher mes initiales à la place de la photo ou du pictogramme par défaut" <?= $avatarInitiales ? 'checked' : '' ?> onchange="this.form.requestSubmit()">
                            <span aria-hidden="true"></span>
                        </label>
                    </form>
                </div>
                <form method="POST" class="reglages-formulaire">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                    <input type="hidden" name="action" value="profil">
                    <div class="reglages-champs-nom">
                        <div>
                            <label for="reglages-prenom">Prénom <span>*</span></label>
                            <input id="reglages-prenom" type="text" name="prenom" value="<?= $echapper($prenomSaisi) ?>" maxlength="100" autocomplete="given-name" required>
                        </div>
                        <div>
                            <label for="reglages-nom-famille">Nom</label>
                            <input id="reglages-nom-famille" type="text" name="nom_famille" value="<?= $echapper($nomFamilleSaisi) ?>" maxlength="100" autocomplete="family-name">
                        </div>
                    </div>

                    <label for="reglages-telephone">Téléphone</label>
                    <input id="reglages-telephone" type="tel" name="telephone" value="<?= $echapper($telephoneSaisi) ?>" maxlength="30" autocomplete="tel" placeholder="Votre numéro de téléphone">

                    <div class="reglages-champ-verrouille">
                        <div>
                            <label for="reglages-email">Adresse e-mail</label>
                            <small>Pour modifier cette adresse, contactez votre partenaire.</small>
                        </div>
                        <span><?= icone('shield', 16) ?> Protégée</span>
                    </div>
                    <input id="reglages-email" class="reglages-lecture-seule" type="email" value="<?= $echapper($technicien['email']) ?>" autocomplete="email" disabled>

                    <div class="reglages-champ-verrouille reglages-champ-verrouille--matricule">
                        <div><label for="reglages-matricule">Matricule</label><small>Votre identifiant professionnel.</small></div>
                        <span><?= icone('key', 16) ?> Attribué</span>
                    </div>
                    <input id="reglages-matricule" class="reglages-lecture-seule reglages-lecture-seule--matricule" type="text" value="<?= $echapper($technicien['matricule'] ?? '') ?>" disabled>

                    <button class="reglages-bouton reglages-bouton--principal" type="submit"><?= icone('check', 16) ?> Enregistrer les modifications</button>
                </form>
            </section>

            <section class="reglages-carte reglages-securite" aria-labelledby="reglages-securite-titre">
                <header class="reglages-carte__entete">
                    <span class="reglages-carte__icone reglages-carte__icone--securite"><?= icone('shield', 19) ?></span>
                    <div><h2 id="reglages-securite-titre">Sécurité du compte</h2><p>Choisissez un mot de passe personnel et difficile à deviner.</p></div>
                </header>
                <div class="reglages-securite__note">
                    <?= icone('key', 17) ?>
                    <p>Votre mot de passe doit contenir au moins 6 caractères. Ne le communiquez à personne.</p>
                </div>
                <form method="POST" class="reglages-formulaire reglages-formulaire--mot-de-passe">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                    <label for="reglages-mot-de-passe-actuel">Mot de passe actuel <span>*</span></label>
                    <div class="reglages-mot-de-passe">
                        <input id="reglages-mot-de-passe-actuel" type="password" name="mot_de_passe_actuel" autocomplete="current-password" required>
                        <button type="button" class="reglages-voir-mot-de-passe" aria-label="Afficher le mot de passe actuel" aria-pressed="false" data-password-target="reglages-mot-de-passe-actuel"><?= icone('eye', 17) ?><?= icone('eye-off', 17) ?></button>
                    </div>

                    <label for="reglages-nouveau-mot-de-passe">Nouveau mot de passe <span>*</span></label>
                    <div class="reglages-mot-de-passe">
                        <input id="reglages-nouveau-mot-de-passe" type="password" name="nouveau_mot_de_passe" minlength="6" autocomplete="new-password" required>
                        <button type="button" class="reglages-voir-mot-de-passe" aria-label="Afficher le nouveau mot de passe" aria-pressed="false" data-password-target="reglages-nouveau-mot-de-passe"><?= icone('eye', 17) ?><?= icone('eye-off', 17) ?></button>
                    </div>

                    <label for="reglages-confirmation-mot-de-passe">Confirmer le nouveau mot de passe <span>*</span></label>
                    <div class="reglages-mot-de-passe">
                        <input id="reglages-confirmation-mot-de-passe" type="password" name="confirmation_mot_de_passe" minlength="6" autocomplete="new-password" required>
                        <button type="button" class="reglages-voir-mot-de-passe" aria-label="Afficher la confirmation du mot de passe" aria-pressed="false" data-password-target="reglages-confirmation-mot-de-passe"><?= icone('eye', 17) ?><?= icone('eye-off', 17) ?></button>
                    </div>
                    <button class="reglages-bouton reglages-bouton--securite" type="submit"><?= icone('key', 16) ?> Modifier mon mot de passe</button>
                </form>
            </section>
        </div>
    </main>
</div>
<script>
document.querySelectorAll('[data-password-target]').forEach(function (button) {
    button.addEventListener('click', function () {
        var input = document.getElementById(button.dataset.passwordTarget);
        var visible = input.type === 'password';
        input.type = visible ? 'text' : 'password';
        button.setAttribute('aria-pressed', visible ? 'true' : 'false');
        button.setAttribute('aria-label', (visible ? 'Masquer ' : 'Afficher ') + input.labels[0].textContent.toLowerCase());
    });
});
var photoInput = document.getElementById('reglages-photo-input');
if (photoInput) {
    var apercuPhotoURL = null;
    photoInput.addEventListener('change', function () {
        var fichier = photoInput.files && photoInput.files[0];
        if (!fichier || !/^image\/(jpeg|png|webp)$/.test(fichier.type)) return;
        if (apercuPhotoURL) URL.revokeObjectURL(apercuPhotoURL);
        apercuPhotoURL = URL.createObjectURL(fichier);
        var apercu = document.querySelector('.reglages-avatar-preview');
        apercu.classList.add('reglages-avatar--photo');
        apercu.replaceChildren(Object.assign(document.createElement('img'), { src: apercuPhotoURL, alt: '' }));
        <?php if (!$avatarInitiales): ?>
        document.querySelectorAll('[data-avatar-preview]').forEach(function (avatar) {
            avatar.classList.add('reglages-avatar--photo');
            avatar.replaceChildren(Object.assign(document.createElement('img'), { src: apercuPhotoURL, alt: '' }));
        });
        <?php endif; ?>
    });
}
</script>
</body>
</html>
