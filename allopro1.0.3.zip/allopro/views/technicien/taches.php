<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();

$typeProprietaire = 'technicien';
$proprietaireId = (int) $_SESSION['technicien_id'];
$urlTaches = 'taches.php';
require_once __DIR__ . '/../../includes/taches-controleur.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes tâches — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/taches.css?v=20261005-1">
</head>
<body class="page-taches-technicien">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>
    <main class="contenu taches-page">
        <?php include __DIR__ . '/../../includes/taches-vue.php'; ?>
    </main>
</div>
</body>
</html>
