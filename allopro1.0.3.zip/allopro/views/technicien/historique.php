<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();
require_once __DIR__ . '/../../models/Intervention.php';

$technicienId = (int) $_SESSION['technicien_id'];
$interventionModel = new Intervention();
$missions = $interventionModel->getByTechnicien($technicienId);
$documentsParMission = [];
foreach ($interventionModel->getDocumentsTechnicien($technicienId) as $document) {
    $documentsParMission[(int) $document['intervention_id']][] = $document;
}
usort($missions, static function (array $a, array $b): int {
    $dateA = strtotime((string) ($a['date_fin'] ?? $a['date_debut'] ?? '')) ?: 0;
    $dateB = strtotime((string) ($b['date_fin'] ?? $b['date_debut'] ?? '')) ?: 0;
    return $dateB <=> $dateA;
});

$statuts = [
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Sur place',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$missionsTerminees = count(array_filter($missions, static fn(array $mission): bool => $mission['statut'] === 'terminee'));
$nombreDocuments = array_sum(array_map('count', $documentsParMission));
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Historique et documents — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/technicien-historique.css?v=<?= filemtime(__DIR__ . '/../../public/css/technicien-historique.css') ?>">
</head>
<body class="page-technicien-historique">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>
    <main class="contenu technicien-historique-page">
        <header class="historique-hero">
            <div>
                <span class="historique-hero__surtitre">Votre carnet d’activité</span>
                <h1>Historique et documents</h1>
                <p>Retrouvez vos interventions, rapports, photos et documents au même endroit.</p>
            </div>
            <a href="missions.php"><?= icone('wrench', 17) ?> Mes missions</a>
        </header>

        <section class="historique-resume" aria-label="Résumé de votre historique">
            <article><span><?= icone('file-text', 18) ?></span><strong><?= count($missions) ?></strong><small>intervention<?= count($missions) === 1 ? '' : 's' ?> au total</small></article>
            <article><span><?= icone('check', 18) ?></span><strong><?= $missionsTerminees ?></strong><small>terminée<?= $missionsTerminees === 1 ? '' : 's' ?></small></article>
            <article><span><?= icone('camera', 18) ?></span><strong><?= $nombreDocuments ?></strong><small>document<?= $nombreDocuments === 1 ? '' : 's' ?> ajouté<?= $nombreDocuments === 1 ? '' : 's' ?></small></article>
        </section>

        <section class="historique-liste" aria-labelledby="historique-liste-titre">
            <header class="historique-liste__entete">
                <div><span>Vos interventions</span><h2 id="historique-liste-titre">Dossiers et pièces associées</h2></div>
                <small><?= count($missions) ?> dossier<?= count($missions) === 1 ? '' : 's' ?></small>
            </header>

            <?php if (!$missions): ?>
                <div class="historique-vide">
                    <span><?= icone('file-text', 25) ?></span>
                    <h3>Votre historique apparaîtra ici</h3>
                    <p>Les interventions qui vous sont attribuées et leurs documents seront conservés dans cet espace.</p>
                    <a href="missions.php">Voir mes missions</a>
                </div>
            <?php else: ?>
                <div class="historique-cartes">
                    <?php foreach ($missions as $mission): ?>
                        <?php
                        $idMission = (int) $mission['id'];
                        $dateReference = $mission['date_fin'] ?: $mission['date_debut'];
                        $docs = $documentsParMission[$idMission] ?? [];
                        $photos = [
                            ['label' => 'Photo du client', 'chemin' => $mission['photo_path'] ?? null],
                            ['label' => 'Avant intervention', 'chemin' => $mission['photo_avant'] ?? null],
                            ['label' => 'Après intervention', 'chemin' => $mission['photo_apres'] ?? null],
                        ];
                        ?>
                        <article class="historique-carte">
                            <div class="historique-carte__entete">
                                <span class="historique-carte__icone"><?= icone($mission['statut'] === 'terminee' ? 'check' : 'wrench', 18) ?></span>
                                <div class="historique-carte__titre">
                                    <a href="mission.php?id=<?= $idMission ?>"><?= $echapper($mission['numero_dossier']) ?></a>
                                    <p><?= $echapper($mission['categorie_nom']) ?> · <?= $echapper($mission['quartier']) ?>, <?= $echapper($mission['ville']) ?></p>
                                </div>
                                <span class="historique-statut historique-statut--<?= $echapper($mission['statut']) ?>"><?= $echapper($statuts[$mission['statut']] ?? ucfirst(str_replace('_', ' ', $mission['statut']))) ?></span>
                            </div>
                            <div class="historique-carte__meta">
                                <span><?= icone('clock', 14) ?> <?= $dateReference ? $echapper(date('d/m/Y à H:i', strtotime($dateReference))) : 'Date non renseignée' ?></span>
                                <?php if ($mission['date_fin']): ?><span>Intervention clôturée</span><?php endif; ?>
                            </div>
                            <div class="historique-contenu">
                                <?php if (!empty($mission['rapport'])): ?>
                                    <details class="historique-rapport">
                                        <summary><?= icone('file-text', 15) ?> Consulter le rapport d’intervention</summary>
                                        <p><?= nl2br($echapper($mission['rapport'])) ?></p>
                                    </details>
                                <?php endif; ?>
                                <?php
                                $photosDisponibles = array_values(array_filter($photos, static fn(array $photo): bool => !empty($photo['chemin'])));
                                if ($photosDisponibles || $docs):
                                ?>
                                    <div class="historique-fichiers">
                                        <?php foreach ($photosDisponibles as $photo): ?>
                                            <a href="/allopro/public/<?= $echapper($photo['chemin']) ?>" target="_blank" rel="noopener">
                                                <?= icone('camera', 15) ?> <?= $echapper($photo['label']) ?>
                                            </a>
                                        <?php endforeach; ?>
                                        <?php foreach ($docs as $document): ?>
                                            <a href="document.php?id=<?= (int) $document['id'] ?>">
                                                <?= icone($document['mime_type'] === 'application/pdf' ? 'file-text' : 'camera', 15) ?>
                                                <?= $echapper($document['nom_original']) ?>
                                                <small><?= number_format((int) $document['taille'] / 1024, 0, ',', ' ') ?> Ko</small>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p class="historique-sans-fichier">Aucune photo ni pièce jointe n’est associée à cette intervention.</p>
                                <?php endif; ?>
                            </div>
                            <a class="historique-carte__ouvrir" href="mission.php?id=<?= $idMission ?>">Ouvrir le dossier <?= icone('arrow', 15) ?></a>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
