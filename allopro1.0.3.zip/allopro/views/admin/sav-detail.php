<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: sav.php"); exit; }

$ticketModel = new TicketSav();
$ticket = $ticketModel->getById($id);
if (!$ticket) { die("Ticket introuvable."); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticketModel->mettreAJour($id, $_POST['statut'], trim($_POST['commentaire_conseiller']));
    journaliser('sav.mis_a_jour', 'ticket_sav', $id, $ticket['numero_dossier'], $ticket['statut'] . ' → ' . $_POST['statut']);
    header("Location: sav.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ticket SAV — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="sav.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour au SAV</a>
                <div class="admin-entete__titre" style="margin-top:6px;">Ticket — <?= htmlspecialchars($ticket['numero_dossier']) ?></div>
            </div>
            <a href="../conseiller/traiter-demande.php?id=<?= $ticket['demande_id'] ?>" style="font-size:13px; color:var(--admin-violet); font-weight:600; text-decoration:none;">Voir le dossier complet →</a>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
            <div class="admin-panneau">
                <div class="admin-panneau__titre">Détails</div>
                <p style="font-size:13.5px; margin-bottom:10px;"><strong>Client :</strong> <?= htmlspecialchars($ticket['client_nom']) ?> — <?= htmlspecialchars($ticket['client_telephone']) ?></p>
                <p style="font-size:13.5px; margin-bottom:10px;"><strong>Problème initial :</strong> <?= nl2br(htmlspecialchars($ticket['description'])) ?></p>
                <p style="font-size:13.5px; margin-bottom:10px;"><strong>Note laissée :</strong> <?= str_repeat('⭐', (int) $ticket['note']) ?> (<?= $ticket['note'] ?>/5)</p>
                <p style="font-size:13.5px;"><strong>Commentaire client :</strong> <?= htmlspecialchars($ticket['commentaire'] ?: 'Aucun') ?></p>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Traitement</div>
                <form method="POST">
                    <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Statut</label>
                    <select name="statut" style="width:100%; padding:9px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:14px;">
                        <option value="ouvert" <?= $ticket['statut'] === 'ouvert' ? 'selected' : '' ?>>Ouvert</option>
                        <option value="en_cours" <?= $ticket['statut'] === 'en_cours' ? 'selected' : '' ?>>En cours</option>
                        <option value="resolu" <?= $ticket['statut'] === 'resolu' ? 'selected' : '' ?>>Résolu</option>
                    </select>

                    <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Notes internes</label>
                    <textarea name="commentaire_conseiller" rows="5" style="width:100%; padding:9px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:14px;"><?= htmlspecialchars($ticket['commentaire_conseiller'] ?? '') ?></textarea>

                    <button type="submit" style="width:100%; padding:11px; background:var(--admin-violet); color:white; border:none; border-radius:8px; font-weight:700; cursor:pointer;">Enregistrer</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>