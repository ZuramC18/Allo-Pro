<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

$ticketModel = new TicketSav();
$statutFiltre = $_GET['statut'] ?? '';
$tickets = $ticketModel->getAllAvecFiltres($statutFiltre ?: null);
$compteurs = $ticketModel->compterParStatut();
$tempsMoyen = $ticketModel->tempsMoyenResolutionHeures();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SAV — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Service après-vente</div>
                <div class="admin-entete__sous-titre">KPI cible : note ≥ 4,5/5 · reprises &lt; 5% · SLA ≥ 90%</div>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--rouge"><div class="admin-kpi-carte__icone">🔴</div><div class="admin-kpi-carte__label">Ouverts</div><div class="admin-kpi-carte__valeur"><?= $compteurs['ouvert'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone">🟠</div><div class="admin-kpi-carte__label">En cours</div><div class="admin-kpi-carte__valeur"><?= $compteurs['en_cours'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone">✓</div><div class="admin-kpi-carte__label">Résolus</div><div class="admin-kpi-carte__valeur"><?= $compteurs['resolu'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">⏱️</div><div class="admin-kpi-carte__label">Délai moyen résolution</div><div class="admin-kpi-carte__valeur"><?= $tempsMoyen ? round($tempsMoyen) . 'h' : '—' ?></div></div>
        </div>

        <div class="filtres-tabs" style="margin-bottom:20px;">
            <a href="?" class="filtre-tab <?= !$statutFiltre ? 'filtre-tab--actif' : '' ?>">Tous</a>
            <a href="?statut=ouvert" class="filtre-tab <?= $statutFiltre === 'ouvert' ? 'filtre-tab--actif' : '' ?>">Ouverts</a>
            <a href="?statut=en_cours" class="filtre-tab <?= $statutFiltre === 'en_cours' ? 'filtre-tab--actif' : '' ?>">En cours</a>
            <a href="?statut=resolu" class="filtre-tab <?= $statutFiltre === 'resolu' ? 'filtre-tab--actif' : '' ?>">Résolus</a>
        </div>

        <div class="admin-panneau">
            <table class="admin-table">
                <tr><th>Dossier</th><th>Client</th><th>Partenaire</th><th>Note</th><th>Motif client</th><th>Statut</th><th>Ouvert le</th><th></th></tr>
                <?php if (empty($tickets)): ?>
                    <tr><td colspan="8" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun ticket.</td></tr>
                <?php endif; ?>
                <?php foreach ($tickets as $t): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($t['numero_dossier']) ?></strong></td>
                    <td><?= htmlspecialchars($t['client_nom']) ?></td>
                    <td><?= htmlspecialchars($t['nom_entreprise'] ?? '—') ?></td>
                    <td><?= str_repeat('⭐', (int) $t['note']) ?></td>
                    <td style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><?= htmlspecialchars($t['commentaire'] ?: '—') ?></td>
                    <td><span class="admin-badge admin-badge--<?= $t['statut'] === 'resolu' ? 'vert' : ($t['statut'] === 'en_cours' ? 'amber' : 'rouge') ?>"><?= htmlspecialchars($t['statut']) ?></span></td>
                    <td><?= date('d/m/Y', strtotime($t['date_creation'])) ?></td>
                    <td><a href="sav-detail.php?id=<?= $t['id'] ?>" style="color:var(--admin-violet); font-weight:600; text-decoration:none; font-size:13px;">Traiter →</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>