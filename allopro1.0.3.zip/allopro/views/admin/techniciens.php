<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('techniciens');
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Categorie.php';

$technicienModel = new Technicien();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['technicien_id'], $_POST['nouveau_statut'])) {
    if (in_array($_POST['nouveau_statut'], ['actif', 'inactif'], true)) {
        $technicienModel->changerStatut((int) $_POST['technicien_id'], $_POST['nouveau_statut']);
        $t = $technicienModel->getById((int) $_POST['technicien_id']);
        journaliser('technicien.statut_modifie', 'compte', (int) $_POST['technicien_id'], $t['matricule'] ?? null, ($t['nom'] ?? '') . ' → ' . $_POST['nouveau_statut']);
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

$recherche = trim($_GET['q'] ?? '');
$partenaireFiltre = $_GET['partenaire'] ?? '';
$metierFiltre = $_GET['metier'] ?? '';
$statutFiltre = $_GET['statut'] ?? '';

$techniciens = $technicienModel->getAllAvecStats(
    $recherche ?: null,
    $partenaireFiltre ?: null,
    $metierFiltre ?: null,
    $statutFiltre ?: null
);
$global = $technicienModel->compterGlobal();
$partenaires = (new Partenaire())->getAllAvecStats();
$metiers = (new Categorie())->getSousCategories();

$filtresActifs = $recherche || $partenaireFiltre || $metierFiltre || $statutFiltre;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Techniciens — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .select-filtre { padding: 10px 14px; border: 1px solid var(--admin-bordure); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 14px; background: white; }
        .admin-recherche { flex-wrap: wrap; }
        .tech-cellule { display: flex; align-items: center; gap: 10px; }
        .tech-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; }
        .tech-inactif { opacity: 0.55; }
        .bouton-statut { border: none; background: none; cursor: pointer; font-size: 12.5px; font-weight: 600; padding: 4px 0; }
        .bouton-statut--desactiver { color: var(--admin-rouge); }
        .bouton-statut--activer { color: var(--admin-vert); }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Techniciens</div>
                <div class="admin-entete__sous-titre"><?= count($techniciens) ?> technicien<?= count($techniciens) > 1 ? 's' : '' ?> <?= $filtresActifs ? 'trouvé(s)' : 'au total' ?></div>
            </div>
        </div>

        <div class="admin-kpi-grille" style="grid-template-columns: repeat(3, 1fr);">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">🛠️</div><div class="admin-kpi-carte__label">Techniciens</div><div class="admin-kpi-carte__valeur"><?= (int) $global['total'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone">✓</div><div class="admin-kpi-carte__label">Actifs</div><div class="admin-kpi-carte__valeur"><?= (int) $global['actifs'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone">⏳</div><div class="admin-kpi-carte__label">En mission actuellement</div><div class="admin-kpi-carte__valeur"><?= (int) $global['en_mission'] ?></div></div>
        </div>

        <form method="GET" class="admin-recherche">
            <input type="text" name="q" placeholder="Nom, email ou téléphone..." value="<?= htmlspecialchars($recherche) ?>">

            <select name="partenaire" class="select-filtre" onchange="this.form.submit()">
                <option value="">Tous les partenaires</option>
                <?php foreach ($partenaires as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= $partenaireFiltre == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['nom_entreprise']) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="metier" class="select-filtre" onchange="this.form.submit()">
                <option value="">Tous les métiers</option>
                <?php foreach ($metiers as $m): ?>
                    <option value="<?= $m['id'] ?>" <?= $metierFiltre == $m['id'] ? 'selected' : '' ?>><?= htmlspecialchars($m['parent_nom'] . ' — ' . $m['nom']) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="statut" class="select-filtre" onchange="this.form.submit()">
                <option value="">Tous les statuts</option>
                <option value="actif" <?= $statutFiltre === 'actif' ? 'selected' : '' ?>>Actifs</option>
                <option value="inactif" <?= $statutFiltre === 'inactif' ? 'selected' : '' ?>>Inactifs</option>
                <option value="corbeille" <?= $statutFiltre === 'corbeille' ? 'selected' : '' ?>>En corbeille</option>
            </select>

            <button type="submit">Rechercher</button>
            <?php if ($filtresActifs): ?><a href="techniciens.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau">
            <table class="admin-table">
                <tr><th>Technicien</th><th>Partenaire</th><th>Métier</th><th>Missions</th><th>Note</th><th>Statut</th><th></th></tr>
                <?php if (empty($techniciens)): ?>
                    <tr><td colspan="7" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun technicien trouvé.</td></tr>
                <?php endif; ?>
                <?php foreach ($techniciens as $t): $actif = $t['statut'] === 'actif'; ?>
                <tr class="<?= $actif ? '' : 'tech-inactif' ?>">
                    <td>
                        <div class="tech-cellule">
                            <div class="tech-avatar"><?= htmlspecialchars(strtoupper(mb_substr($t['nom'], 0, 1))) ?></div>
                            <div>
                                <strong><?= htmlspecialchars($t['nom']) ?></strong><br>
                                <span style="color:var(--admin-texte-discret); font-size:12px;"><?= htmlspecialchars($t['telephone'] ?: $t['email']) ?></span>
                            </div>
                        </div>
                    </td>
                    <td><a href="partenaire-detail.php?id=<?= $t['partenaire_id'] ?>" style="color:var(--admin-violet); text-decoration:none; font-weight:600;"><?= htmlspecialchars($t['nom_entreprise']) ?></a></td>
                    <td><?= $t['metier'] ? '<span class="admin-badge admin-badge--violet">' . htmlspecialchars($t['metier']) . '</span>' : '<span style="color:var(--admin-texte-discret);">Non renseigné</span>' ?></td>
                    <td>
                        <?= $t['nb_missions'] ?>
                        <?php if ($t['nb_actives'] > 0): ?><span style="color:var(--admin-amber); font-weight:600; font-size:12px;">(<?= $t['nb_actives'] ?> en cours)</span><?php endif; ?>
                    </td>
                    <td><?= $t['note_moyenne'] !== null ? number_format($t['note_moyenne'], 1) . '/5' : '—' ?></td>
                    <td><span class="admin-badge admin-badge--<?= $actif ? 'vert' : 'gris' ?>"><?= $t['statut'] === 'corbeille' ? 'Corbeille' : ($actif ? 'Actif' : 'Inactif') ?></span></td>
                    <td>
                        <?php
                        $messageConfirm = $actif
                            ? ($t['nb_actives'] > 0
                                ? "Ce technicien a {$t['nb_actives']} mission(s) en cours. Le désactiver l'empêchera de se connecter et de les terminer. Continuer ?"
                                : "Désactiver ce technicien ? Il ne pourra plus se connecter.")
                            : "Réactiver ce technicien ?";
                        ?>
                        <form method="POST" onsubmit="return confirm(<?= htmlspecialchars(json_encode($messageConfirm), ENT_QUOTES) ?>);">
                            <input type="hidden" name="technicien_id" value="<?= $t['id'] ?>">
                            <input type="hidden" name="nouveau_statut" value="<?= $actif ? 'inactif' : 'actif' ?>">
                            <button type="submit" class="bouton-statut <?= $actif ? 'bouton-statut--desactiver' : 'bouton-statut--activer' ?>">
                                <?= $actif ? 'Désactiver' : 'Réactiver' ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>