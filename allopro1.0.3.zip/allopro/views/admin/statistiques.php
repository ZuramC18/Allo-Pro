<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('statistiques');
require_once __DIR__ . '/../../models/Statistique.php';

// ===== Fonctions utilitaires =====
function tendance($actuel, $precedent) {
    if ($precedent == 0 && $actuel == 0) return ['—', 'neutre'];
    if ($precedent == 0) return ['Nouveau', 'hausse'];
    $pct = round(($actuel - $precedent) / $precedent * 100);
    if ($pct > 0) return ['▲ +' . $pct . '%', 'hausse'];
    if ($pct < 0) return ['▼ ' . $pct . '%', 'baisse'];
    return ['= 0%', 'neutre'];
}

function formaterDuree($minutes) {
    if ($minutes === null) return '—';
    $minutes = (int) round($minutes);
    if ($minutes < 60) return $minutes . ' min';
    return floor($minutes / 60) . 'h' . sprintf('%02d', $minutes % 60);
}

// Complète les jours/mois sans donnée avec 0, pour un axe continu
function remplirSerie($map, $debut, $parMois) {
    $labels = [];
    $valeurs = [];
    if ($parMois) {
        $cur = new DateTime($debut);
        $fin = new DateTime('first day of this month midnight');
        while ($cur <= $fin) {
            $labels[] = $cur->format('m/Y');
            $valeurs[] = (float) ($map[$cur->format('Y-m')] ?? 0);
            $cur->modify('+1 month');
        }
    } else {
        $cur = new DateTime($debut);
        $fin = new DateTime('today');
        while ($cur <= $fin) {
            $labels[] = $cur->format('d/m');
            $valeurs[] = (float) ($map[$cur->format('Y-m-d')] ?? 0);
            $cur->modify('+1 day');
        }
    }
    return ['labels' => $labels, 'valeurs' => $valeurs];
}

// ===== Période choisie =====
$libellesPeriodes = ['7j' => '7 jours', '30j' => '30 jours', '90j' => '90 jours', '12m' => '12 mois'];
$periode = $_GET['periode'] ?? '30j';
if (!isset($libellesPeriodes[$periode])) $periode = '30j';

$fin = date('Y-m-d', strtotime('+1 day'));
if ($periode === '12m') {
    $parMois = true;
    $debut = date('Y-m-d', strtotime('first day of -11 months'));
    $debutPrec = date('Y-m-d', strtotime('first day of -23 months'));
} else {
    $parMois = false;
    $jours = ['7j' => 7, '30j' => 30, '90j' => 90][$periode];
    $debut = date('Y-m-d', strtotime('-' . ($jours - 1) . ' days'));
    $debutPrec = date('Y-m-d', strtotime('-' . (2 * $jours - 1) . ' days'));
}
$finPrec = $debut;

// ===== Données =====
$stat = new Statistique();

$nbDemandes = $stat->compterDemandes($debut, $fin);
$nbDemandesPrec = $stat->compterDemandes($debutPrec, $finPrec);
$nbTerminees = $stat->compterTerminees($debut, $fin);
$nbUrgentes = $stat->compterUrgentes($debut, $fin);
$ca = $stat->caEncaisse($debut, $fin);
$caPrec = $stat->caEncaisse($debutPrec, $finPrec);
$marge = $stat->margeRealisee($debut, $fin);
$noteMoy = $stat->noteMoyenne($debut, $fin);
$nbNotes = $stat->compterNotes($debut, $fin);
$nbSav = $stat->compterSav($debut, $fin);
$dureeMoy = $stat->dureeMoyenneMinutes($debut, $fin);

$tauxCompletion = $nbDemandes > 0 ? round($nbTerminees / $nbDemandes * 100) : 0;
$tauxUrgence = $nbDemandes > 0 ? round($nbUrgentes / $nbDemandes * 100) : 0;
$tauxSav = $nbTerminees > 0 ? round($nbSav / $nbTerminees * 100, 1) : 0;

$tendanceDemandes = tendance($nbDemandes, $nbDemandesPrec);
$tendanceCA = tendance($ca, $caPrec);

$serieDemandes = remplirSerie($stat->serieDemandes($debut, $fin, $parMois), $debut, $parMois);
$serieCA = remplirSerie($stat->serieCA($debut, $fin, $parMois), $debut, $parMois);

$poles = $stat->repartitionPoles($debut, $fin);
$statuts = $stat->repartitionStatuts($debut, $fin);
$notesMap = $stat->repartitionNotes($debut, $fin);
$notesValeurs = array_map(fn($n) => (int) ($notesMap[$n] ?? 0), [1, 2, 3, 4, 5]);

$quartiers = $stat->topQuartiers($debut, $fin);
$maxQuartier = $quartiers ? max(array_column($quartiers, 'total')) : 1;
$partenaires = $stat->topPartenaires($debut, $fin);

$libellesStatuts = ['nouvelle' => 'Nouvelle', 'attribuee' => 'Attribuée', 'en_cours' => 'En cours', 'terminee' => 'Terminée', 'annulee' => 'Annulée'];
$labelsNiveaux = ['partenaire' => ['Partenaire', 'gris'], 'certifie' => ['Certifié', 'violet'], 'premium' => ['Premium', 'amber'], 'excellence' => ['Excellence', 'vert']];

$donneesJS = [
    'demandes' => $serieDemandes,
    'ca' => $serieCA,
    'poles' => ['labels' => array_column($poles, 'pole'), 'valeurs' => array_map('intval', array_column($poles, 'total'))],
    'statuts' => [
        'labels' => array_map(fn($s) => $libellesStatuts[$s['statut']] ?? $s['statut'], $statuts),
        'cles' => array_column($statuts, 'statut'),
        'valeurs' => array_map('intval', array_column($statuts, 'total'))
    ],
    'notes' => $notesValeurs
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Statistiques — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .stats-ligne { display: grid; gap: 20px; margin-bottom: 20px; }
        .stats-ligne--2 { grid-template-columns: repeat(2, 1fr); }
        .stats-ligne--3 { grid-template-columns: repeat(3, 1fr); }
        .chart-conteneur { position: relative; height: 250px; }
        .chart-vide { display: flex; align-items: center; justify-content: center; height: 100%; color: var(--admin-texte-discret); font-size: 13px; }
        .kpi-sous { font-size: 11.5px; color: var(--admin-texte-discret); margin-top: 4px; font-weight: 500; }
        .quartier-ligne { margin-bottom: 12px; }
        .quartier-ligne__haut { display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 5px; }
        .quartier-ligne__barre { background: #F1F0F6; border-radius: 10px; height: 8px; overflow: hidden; }
        .quartier-ligne__remplissage { background: var(--admin-violet); height: 100%; border-radius: 10px; }
        @media (max-width: 1100px) { .stats-ligne--2, .stats-ligne--3 { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Statistiques</div>
                <div class="admin-entete__sous-titre">Du <?= date('d/m/Y', strtotime($debut)) ?> à aujourd'hui · comparé à la période précédente de même durée</div>
            </div>
            <div class="filtres-tabs">
                <?php foreach ($libellesPeriodes as $cle => $libelle): ?>
                    <a href="?periode=<?= $cle ?>" class="filtre-tab <?= $periode === $cle ? 'filtre-tab--actif' : '' ?>"><?= $libelle ?></a>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet">
                <div class="admin-kpi-carte__icone">📥</div>
                <div class="admin-kpi-carte__label">Demandes reçues</div>
                <div class="admin-kpi-carte__valeur"><?= $nbDemandes ?></div>
                <div class="admin-kpi-carte__tendance admin-kpi-carte__tendance--<?= $tendanceDemandes[1] ?>"><?= $tendanceDemandes[0] ?></div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--vert">
                <div class="admin-kpi-carte__icone">💰</div>
                <div class="admin-kpi-carte__label">CA encaissé</div>
                <div class="admin-kpi-carte__valeur"><?= number_format($ca, 0, ',', ' ') ?> F</div>
                <div class="admin-kpi-carte__tendance admin-kpi-carte__tendance--<?= $tendanceCA[1] ?>"><?= $tendanceCA[0] ?></div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--vert">
                <div class="admin-kpi-carte__icone">✓</div>
                <div class="admin-kpi-carte__label">Taux de complétion</div>
                <div class="admin-kpi-carte__valeur"><?= $tauxCompletion ?>%</div>
                <div class="kpi-sous"><?= $nbTerminees ?> terminée(s) sur <?= $nbDemandes ?></div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--amber">
                <div class="admin-kpi-carte__icone">⭐</div>
                <div class="admin-kpi-carte__label">Note moyenne</div>
                <div class="admin-kpi-carte__valeur"><?= $noteMoy !== null ? number_format($noteMoy, 1) . '/5' : '—' ?></div>
                <div class="kpi-sous"><?= $nbNotes ?> avis · cible ≥ 4,5</div>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet">
                <div class="admin-kpi-carte__icone">📊</div>
                <div class="admin-kpi-carte__label">Marge ALLÔ PRO</div>
                <div class="admin-kpi-carte__valeur"><?= number_format($marge, 0, ',', ' ') ?> F</div>
                <div class="kpi-sous">Sur les reversements créés</div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--<?= $tauxSav <= 5 ? 'vert' : 'rouge' ?>">
                <div class="admin-kpi-carte__icone">🎧</div>
                <div class="admin-kpi-carte__label">Taux de SAV</div>
                <div class="admin-kpi-carte__valeur"><?= $tauxSav ?>%</div>
                <div class="kpi-sous"><?= $nbSav ?> ticket(s) · cible &lt; 5%</div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--amber">
                <div class="admin-kpi-carte__icone">⏱️</div>
                <div class="admin-kpi-carte__label">Durée moyenne d'une mission</div>
                <div class="admin-kpi-carte__valeur"><?= formaterDuree($dureeMoy) ?></div>
                <div class="kpi-sous">De l'attribution à la clôture</div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--rouge">
                <div class="admin-kpi-carte__icone">⚡</div>
                <div class="admin-kpi-carte__label">Demandes urgentes</div>
                <div class="admin-kpi-carte__valeur"><?= $tauxUrgence ?>%</div>
                <div class="kpi-sous"><?= $nbUrgentes ?> demande(s)</div>
            </div>
        </div>

        <div class="stats-ligne stats-ligne--2">
            <div class="admin-panneau" style="margin-bottom:0;">
                <div class="admin-panneau__titre">Demandes <?= $parMois ? 'par mois' : 'par jour' ?></div>
                <div class="chart-conteneur"><canvas id="chart-demandes"></canvas></div>
            </div>
            <div class="admin-panneau" style="margin-bottom:0;">
                <div class="admin-panneau__titre">CA encaissé <?= $parMois ? 'par mois' : 'par jour' ?></div>
                <div class="chart-conteneur"><canvas id="chart-ca"></canvas></div>
            </div>
        </div>

        <div class="stats-ligne stats-ligne--3">
            <div class="admin-panneau" style="margin-bottom:0;">
                <div class="admin-panneau__titre">Répartition par pôle</div>
                <div class="chart-conteneur"><canvas id="chart-poles"></canvas></div>
            </div>
            <div class="admin-panneau" style="margin-bottom:0;">
                <div class="admin-panneau__titre">Répartition par statut</div>
                <div class="chart-conteneur"><canvas id="chart-statuts"></canvas></div>
            </div>
            <div class="admin-panneau" style="margin-bottom:0;">
                <div class="admin-panneau__titre">Répartition des notes</div>
                <div class="chart-conteneur"><canvas id="chart-notes"></canvas></div>
            </div>
        </div>

        <div class="stats-ligne stats-ligne--2">
            <div class="admin-panneau" style="margin-bottom:0;">
                <div class="admin-panneau__titre">Partenaires les plus actifs</div>
                <table class="admin-table">
                    <tr><th>Partenaire</th><th>Missions</th><th>CA généré</th><th>Score</th><th>Niveau</th></tr>
                    <?php if (empty($partenaires)): ?>
                        <tr><td colspan="5" style="text-align:center; color:var(--admin-texte-discret); padding:20px;">Aucune mission sur cette période.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($partenaires as $p): $niv = $labelsNiveaux[$p['niveau']] ?? ['—', 'gris']; ?>
                    <tr>
                        <td><a href="partenaire-detail.php?id=<?= $p['id'] ?>" style="color:var(--admin-texte); font-weight:600; text-decoration:none;"><?= htmlspecialchars($p['nom_entreprise']) ?></a></td>
                        <td><?= $p['missions'] ?></td>
                        <td><?= number_format($p['ca'], 0, ',', ' ') ?> F</td>
                        <td><?= $p['score'] > 0 ? number_format($p['score'], 1) : '—' ?></td>
                        <td><span class="admin-badge admin-badge--<?= $niv[1] ?>"><?= $niv[0] ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>

            <div class="admin-panneau" style="margin-bottom:0;">
                <div class="admin-panneau__titre">Quartiers les plus demandeurs</div>
                <?php if (empty($quartiers)): ?>
                    <p style="font-size:13px; color:var(--admin-texte-discret);">Aucune demande sur cette période.</p>
                <?php endif; ?>
                <?php foreach ($quartiers as $q): ?>
                    <div class="quartier-ligne">
                        <div class="quartier-ligne__haut"><span><?= htmlspecialchars($q['quartier']) ?></span><strong><?= $q['total'] ?></strong></div>
                        <div class="quartier-ligne__barre"><div class="quartier-ligne__remplissage" style="width:<?= round($q['total'] / $maxQuartier * 100) ?>%;"></div></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
const donnees = <?= json_encode($donneesJS, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?>;

const COULEURS = { violet: '#6C5CE7', violetClair: '#8B7EF0', vert: '#16A34A', amber: '#D97706', rouge: '#DC2626', gris: '#8A8D9A' };
const COULEURS_STATUTS = { nouvelle: COULEURS.violet, attribuee: COULEURS.amber, en_cours: '#F59E0B', terminee: COULEURS.vert, annulee: COULEURS.gris };

function afficherVide(canvasId) {
    const conteneur = document.getElementById(canvasId).parentElement;
    conteneur.innerHTML = '<div class="chart-vide">Aucune donnée sur cette période.</div>';
}

if (typeof Chart === 'undefined') {
    // Filet de sécurité : si Chart.js ne charge pas (hors ligne, CDN bloqué), la page reste utilisable
    document.querySelectorAll('.chart-conteneur').forEach(el => {
        el.innerHTML = '<div class="chart-vide">Graphiques indisponibles (Chart.js n\'a pas pu être chargé).</div>';
    });
} else {
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = '#8A8D9A';

    const formaterFCFA = (n) => Math.round(n).toLocaleString('fr-FR') + ' F';
    const somme = (tab) => tab.reduce((a, b) => a + b, 0);

    // Demandes dans le temps
    if (somme(donnees.demandes.valeurs) === 0) { afficherVide('chart-demandes'); }
    else {
        new Chart(document.getElementById('chart-demandes'), {
            type: 'line',
            data: {
                labels: donnees.demandes.labels,
                datasets: [{
                    data: donnees.demandes.valeurs,
                    borderColor: COULEURS.violet,
                    backgroundColor: 'rgba(108,92,231,0.12)',
                    fill: true, tension: 0.35, pointRadius: donnees.demandes.labels.length > 40 ? 0 : 3
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false }, ticks: { maxTicksLimit: 10 } } }
            }
        });
    }

    // CA dans le temps
    if (somme(donnees.ca.valeurs) === 0) { afficherVide('chart-ca'); }
    else {
        new Chart(document.getElementById('chart-ca'), {
            type: 'bar',
            data: {
                labels: donnees.ca.labels,
                datasets: [{ data: donnees.ca.valeurs, backgroundColor: COULEURS.vert, borderRadius: 4 }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false }, tooltip: { callbacks: { label: (ctx) => formaterFCFA(ctx.parsed.y) } } },
                scales: { y: { beginAtZero: true, ticks: { callback: (v) => v.toLocaleString('fr-FR') } }, x: { grid: { display: false }, ticks: { maxTicksLimit: 10 } } }
            }
        });
    }

    // Pôles
    if (donnees.poles.valeurs.length === 0) { afficherVide('chart-poles'); }
    else {
        new Chart(document.getElementById('chart-poles'), {
            type: 'doughnut',
            data: {
                labels: donnees.poles.labels,
                datasets: [{ data: donnees.poles.valeurs, backgroundColor: [COULEURS.violet, COULEURS.amber, COULEURS.vert, COULEURS.rouge, COULEURS.violetClair, COULEURS.gris], borderWidth: 2 }]
            },
            options: { responsive: true, maintainAspectRatio: false, cutout: '62%', plugins: { legend: { position: 'bottom' } } }
        });
    }

    // Statuts
    if (donnees.statuts.valeurs.length === 0) { afficherVide('chart-statuts'); }
    else {
        new Chart(document.getElementById('chart-statuts'), {
            type: 'doughnut',
            data: {
                labels: donnees.statuts.labels,
                datasets: [{ data: donnees.statuts.valeurs, backgroundColor: donnees.statuts.cles.map(c => COULEURS_STATUTS[c] || COULEURS.gris), borderWidth: 2 }]
            },
            options: { responsive: true, maintainAspectRatio: false, cutout: '62%', plugins: { legend: { position: 'bottom' } } }
        });
    }

    // Notes
    if (somme(donnees.notes) === 0) { afficherVide('chart-notes'); }
    else {
        new Chart(document.getElementById('chart-notes'), {
            type: 'bar',
            data: {
                labels: ['1 ★', '2 ★', '3 ★', '4 ★', '5 ★'],
                datasets: [{ data: donnees.notes, backgroundColor: [COULEURS.rouge, '#F97316', COULEURS.amber, '#65A30D', COULEURS.vert], borderRadius: 4 }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } }
            }
        });
    }
}
</script>
</body>
</html>