<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/Reversement.php';

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: reversements.php"); exit; }

$reversementModel = new Reversement();
$reversement = $reversementModel->getById($id);
if (!$reversement) { die("Reversement introuvable."); }

if (empty($_SESSION['csrf_reversement'])) {
    $_SESSION['csrf_reversement'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['marquer_paye'])) {
    if (!hash_equals($_SESSION['csrf_reversement'], (string) ($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        die('La session a expiré. Rechargez la page puis réessayez.');
    }
    $reversementModel->marquerPaye($id);
    journaliser('reversement.paye', 'reversement', $id, $reversement['nom_entreprise'], number_format($reversement['montant_du'], 0, ',', ' ') . ' F versés');
    header("Location: reversement-detail.php?id=" . $id);
    exit;
}

$details = $reversementModel->getDetails($id);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reversement — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="reversements.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour aux reversements</a>
                <div class="admin-entete__titre" style="margin-top:6px;"><?= htmlspecialchars($reversement['nom_entreprise']) ?></div>
                <div class="admin-entete__sous-titre">Période du <?= date('d/m/Y', strtotime($reversement['periode_debut'])) ?> au <?= date('d/m/Y', strtotime($reversement['periode_fin'])) ?></div>
            </div>
            <span class="admin-badge admin-badge--<?= $reversement['statut'] === 'paye' ? 'vert' : 'amber' ?>" style="font-size:13px; padding:6px 14px;">
                <?= $reversement['statut'] === 'paye' ? 'Payé' : 'En attente' ?>
            </span>
        </div>

        <div class="admin-panneau">
            <div class="admin-panneau__titre">
                Détail des missions
                <span style="font-family:'Space Grotesk',sans-serif; font-weight:800; font-size:20px; color:var(--admin-violet);"><?= number_format($reversement['montant_du'], 0, ',', ' ') ?> F</span>
            </div>
            <table class="admin-table">
                <tr><th>Dossier</th><th>Origine</th><th>Base répartie</th><th>Commission</th><th>Partenaire</th></tr>
                <?php foreach ($details as $d): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($d['numero_dossier']) ?></strong></td>
                    <td><?= $d['mode_paiement'] === 'pass' ? 'Pass' : ($d['mode_paiement'] === 'abonnement' ? 'Abonnement · 1 crédit' : 'Paiement direct') ?></td>
                    <td><?= number_format($d['montant_paiement'], 0, ',', ' ') ?> F</td>
                    <td><?= number_format($d['marge_allopro'], 0, ',', ' ') ?> F (<?= number_format($d['taux_commission'], 1, ',', ' ') ?> %)</td>
                    <td><?= number_format($d['montant'], 0, ',', ' ') ?> F</td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <?php if ($reversement['statut'] === 'en_attente'): ?>
            <form method="POST" onsubmit="return confirm('Confirmer que ce reversement a bien été payé au partenaire (ex : transfert Wave effectué) ?');">
                <input type="hidden" name="marquer_paye" value="1">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_reversement'], ENT_QUOTES, 'UTF-8') ?>">
                <button type="submit" style="padding:13px 28px; background:var(--admin-vert); color:white; border:none; border-radius:8px; font-weight:700; cursor:pointer;">
                    Marquer comme payé
                </button>
            </form>
        <?php else: ?>
            <p style="color:var(--admin-texte-discret); font-size:13px;">Payé le <?= date('d/m/Y à H:i', strtotime($reversement['date_paiement'])) ?>.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>