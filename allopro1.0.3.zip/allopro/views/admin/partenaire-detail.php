<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('partenaires');
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Technicien.php';

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: partenaires.php"); exit; }

$partenaireModel = new Partenaire();
$partenaire = $partenaireModel->getById($id);
if (!$partenaire) { die("Partenaire introuvable."); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['changer_statut'])) {
        $partenaireModel->changerStatutActivation($id, $_POST['changer_statut']);
        journaliser('partenaire.statut_modifie', 'compte', $id, $partenaire['matricule'], $partenaire['nom_entreprise'] . ' → ' . $_POST['changer_statut']);
    } elseif (isset($_POST['changer_niveau'])) {
        $partenaireModel->changerNiveauManuel($id, $_POST['changer_niveau']);
        journaliser('partenaire.niveau_modifie', 'compte', $id, $partenaire['matricule'], $partenaire['niveau'] . ' → ' . $_POST['changer_niveau']);
    }
    header("Location: partenaire-detail.php?id=" . $id);
    exit;
}

$techniciens = (new Technicien())->getByPartenaire($id);
$missions = $partenaireModel->getMissionsRecentes($id);

$labelsNiveaux = ['partenaire' => 'Partenaire', 'certifie' => 'Certifié', 'premium' => 'Premium', 'excellence' => 'Excellence'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($partenaire['nom_entreprise']) ?> — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .fiche-client { display: grid; grid-template-columns: 320px 1fr; gap: 20px; }
        .fiche-profil__avatar { width: 70px; height: 70px; border-radius: 16px; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-family:'Space Grotesk',sans-serif; font-weight: 800; font-size: 24px; margin: 0 auto 14px; }
        .fiche-profil__nom { font-family:'Space Grotesk',sans-serif; font-weight: 700; font-size: 16px; text-align:center; }
        .fiche-profil__ligne { display: flex; justify-content: space-between; padding: 10px 0; border-top: 1px solid #F1F0F6; font-size: 13.5px; }
        .fiche-profil__ligne span:first-child { color: var(--admin-texte-discret); }
        .select-inline { width: 100%; padding: 9px 10px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-family:'Inter',sans-serif; font-size: 13px; margin-top: 4px; }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="partenaires.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour aux partenaires</a>
                <div class="admin-entete__titre" style="margin-top:6px;"><?= htmlspecialchars($partenaire['nom_entreprise']) ?></div>
            </div>
        </div>

        <div class="fiche-client">
            <div>
                <div class="admin-panneau" style="text-align:center;">
                    <div class="fiche-profil__avatar"><?= htmlspecialchars(strtoupper(mb_substr($partenaire['nom_entreprise'], 0, 1))) ?></div>
                    <div class="fiche-profil__nom"><?= htmlspecialchars($partenaire['nom_entreprise']) ?></div>
                    <span class="admin-badge admin-badge--<?= $partenaire['statut'] === 'actif' ? 'vert' : 'rouge' ?>" style="margin-top:8px; display:inline-block;">
                        <?= $partenaire['statut'] === 'actif' ? 'Actif' : 'Inactif' ?>
                    </span>

                    <div class="fiche-profil__ligne"><span>Téléphone</span><span><?= htmlspecialchars($partenaire['telephone'] ?: '—') ?></span></div>
                    <div class="fiche-profil__ligne"><span>Email</span><span><?= htmlspecialchars($partenaire['email']) ?></span></div>
                    <div class="fiche-profil__ligne"><span>Zone</span><span><?= htmlspecialchars($partenaire['zone_intervention'] ?: '—') ?></span></div>
                    <div class="fiche-profil__ligne"><span>Score</span><span><?= $partenaire['score'] > 0 ? number_format($partenaire['score'], 1) . '/5' : '—' ?></span></div>
                    <div class="fiche-profil__ligne"><span>Inscrit le</span><span><?= date('d/m/Y', strtotime($partenaire['date_creation'])) ?></span></div>

                    <form method="POST" style="margin-top:16px; text-align:left;">
                        <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret);">Niveau (ajustement manuel)</label>
                        <select name="changer_niveau" class="select-inline" onchange="this.form.submit()">
                            <?php foreach ($labelsNiveaux as $val => $label): ?>
                                <option value="<?= $val ?>" <?= $partenaire['niveau'] === $val ? 'selected' : '' ?>><?= $label ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>

                    <form method="POST" style="margin-top:12px;">
                        <input type="hidden" name="changer_statut" value="<?= $partenaire['statut'] === 'actif' ? 'inactif' : 'actif' ?>">
                        <button type="submit" style="width:100%; text-align:center; background:<?= $partenaire['statut'] === 'actif' ? '#FDECEC' : '#E6F7ED' ?>; color:<?= $partenaire['statut'] === 'actif' ? 'var(--admin-rouge)' : 'var(--admin-vert)' ?>; border:none; border-radius:6px; padding:9px; cursor:pointer; font-weight:600; font-size:13px;">
                            <?= $partenaire['statut'] === 'actif' ? 'Désactiver le partenaire' : 'Réactiver le partenaire' ?>
                        </button>
                    </form>
                </div>

                <div class="admin-panneau">
                    <div class="admin-panneau__titre">Techniciens (<?= count($techniciens) ?>)</div>
                    <?php if (empty($techniciens)): ?>
                        <p style="font-size:13px; color:var(--admin-texte-discret);">Aucun technicien.</p>
                    <?php endif; ?>
                    <?php foreach ($techniciens as $t): ?>
                        <div style="display:flex; justify-content:space-between; padding:9px 0; border-bottom:1px solid #F1F0F6; font-size:13.5px;">
                            <span><?= htmlspecialchars($t['nom']) ?></span>
                            <span>
                                <span class="admin-badge admin-badge--<?= $t['statut'] === 'actif' ? 'vert' : 'gris' ?>"><?= htmlspecialchars($t['categorie_nom'] ?? '—') ?></span>
                                <?php if ($t['statut'] === 'corbeille'): ?><span class="admin-badge admin-badge--gris">Corbeille</span><?php endif; ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Missions récentes</div>
                <table class="admin-table">
                    <tr><th>Dossier</th><th>Catégorie</th><th>Technicien</th><th>Statut</th></tr>
                    <?php if (empty($missions)): ?>
                        <tr><td colspan="4" style="text-align:center; color:var(--admin-texte-discret); padding:20px;">Aucune mission.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($missions as $m): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($m['numero_dossier']) ?></strong></td>
                        <td><?= htmlspecialchars($m['categorie_nom']) ?></td>
                        <td><?= htmlspecialchars($m['technicien_nom'] ?? '—') ?></td>
                        <td><span class="admin-badge admin-badge--<?= $m['statut'] === 'terminee' ? 'vert' : 'amber' ?>"><?= htmlspecialchars($m['statut']) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>