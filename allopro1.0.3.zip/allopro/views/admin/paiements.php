<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('paiements');
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/Partenaire.php';

$paiementModel = new Paiement();
$statutFiltre = $_GET['statut'] ?? '';
$methodeFiltre = $_GET['methode'] ?? '';

$paiements = $paiementModel->getAllAvecFiltres($statutFiltre ?: null, $methodeFiltre ?: null);
$sommes = $paiementModel->sommeParStatut();
$sommeMois = $paiementModel->sommeMoisEnCours();
$parMethode = $paiementModel->sommeParMethode();
$reversementsDus = (new Partenaire())->getReversementsDus();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paiements — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Paiements & Finance</div>
                <div class="admin-entete__sous-titre">Transactions, statuts et reversements partenaires</div>
            </div>
            <a href="partage-benefices.php" style="padding:10px 14px; color:var(--admin-violet); border:1px solid var(--admin-bordure); border-radius:9px; font-size:13px; font-weight:700; text-decoration:none;">Gérer le partage Pass & abonnements →</a>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone">💰</div><div class="admin-kpi-carte__label">CA du mois</div><div class="admin-kpi-carte__valeur"><?= number_format($sommeMois, 0, ',', ' ') ?> F</div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone">✓</div><div class="admin-kpi-carte__label">Validés (<?= $sommes['valide']['nb'] ?>)</div><div class="admin-kpi-carte__valeur"><?= number_format($sommes['valide']['total'], 0, ',', ' ') ?> F</div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone">⏳</div><div class="admin-kpi-carte__label">En attente (<?= $sommes['en_attente']['nb'] ?>)</div><div class="admin-kpi-carte__valeur"><?= number_format($sommes['en_attente']['total'], 0, ',', ' ') ?> F</div></div>
            <div class="admin-kpi-carte admin-kpi-carte--rouge"><div class="admin-kpi-carte__icone">✕</div><div class="admin-kpi-carte__label">Échoués (<?= $sommes['echoue']['nb'] ?>)</div><div class="admin-kpi-carte__valeur"><?= number_format($sommes['echoue']['total'], 0, ',', ' ') ?> F</div></div>
            <?php require_once __DIR__ . '/../../models/Reversement.php'; $margeMois = (new Reversement())->margeMoisEnCours(); ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">📊</div><div class="admin-kpi-carte__label">Marge du mois</div><div class="admin-kpi-carte__valeur"><?= number_format($margeMois, 0, ',', ' ') ?> F</div></div>
        </div>

        <div style="display:grid; grid-template-columns:2fr 1fr; gap:20px; align-items:start;">
            <div>
                <form method="GET" class="admin-recherche">
                    <select name="statut" onchange="this.form.submit()" style="padding:10px 14px; border:1px solid var(--admin-bordure); border-radius:8px; font-size:14px;">
                        <option value="">Tous les statuts</option>
                        <option value="valide" <?= $statutFiltre === 'valide' ? 'selected' : '' ?>>Validé</option>
                        <option value="en_attente" <?= $statutFiltre === 'en_attente' ? 'selected' : '' ?>>En attente</option>
                        <option value="echoue" <?= $statutFiltre === 'echoue' ? 'selected' : '' ?>>Échoué</option>
                    </select>
                    <select name="methode" onchange="this.form.submit()" style="padding:10px 14px; border:1px solid var(--admin-bordure); border-radius:8px; font-size:14px;">
                        <option value="">Toutes méthodes</option>
                        <option value="wave" <?= $methodeFiltre === 'wave' ? 'selected' : '' ?>>Wave</option>
                        <option value="orange_money" <?= $methodeFiltre === 'orange_money' ? 'selected' : '' ?>>Orange Money</option>
                    </select>
                    <?php if ($statutFiltre || $methodeFiltre): ?><a href="paiements.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
                </form>

                <div class="admin-panneau">
                    <table class="admin-table">
                        <tr><th>Référence</th><th>Dossier</th><th>Client</th><th>Méthode</th><th>Montant</th><th>Statut</th><th>Date</th></tr>
                        <?php if (empty($paiements)): ?>
                            <tr><td colspan="7" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun paiement.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($paiements as $p): ?>
                        <tr>
                            <td style="font-size:12px; color:var(--admin-texte-discret);"><?= htmlspecialchars($p['reference_transaction']) ?></td>
                            <td><strong><?= htmlspecialchars($p['numero_dossier']) ?></strong></td>
                            <td><?= htmlspecialchars($p['client_nom']) ?></td>
                            <td><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $p['methode']))) ?></td>
                            <td><?= number_format($p['montant'], 0, ',', ' ') ?> F</td>
                            <td><span class="admin-badge admin-badge--<?= $p['statut'] === 'valide' ? 'vert' : ($p['statut'] === 'en_attente' ? 'amber' : 'rouge') ?>"><?= htmlspecialchars($p['statut']) ?></span></td>
                            <td><?= date('d/m/Y H:i', strtotime($p['date_paiement'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>

            <div>
                <div class="admin-panneau">
                    <div class="admin-panneau__titre">Répartition par méthode</div>
                    <?php foreach ($parMethode as $m): ?>
                        <div style="display:flex; justify-content:space-between; padding:9px 0; border-bottom:1px solid #F1F0F6; font-size:13.5px;">
                            <span><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $m['methode']))) ?></span>
                            <strong><?= number_format($m['total'], 0, ',', ' ') ?> F</strong>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($parMethode)): ?><p style="font-size:13px; color:var(--admin-texte-discret);">Aucune donnée.</p><?php endif; ?>
                </div>

                <div class="admin-panneau">
                    <div class="admin-panneau__titre">Reversements dus</div>
                    <?php if (empty($reversementsDus)): ?>
                        <p style="font-size:13px; color:var(--admin-texte-discret);">Rien à reverser actuellement.</p>
                    <?php endif; ?>
                    <?php foreach ($reversementsDus as $r): ?>
                        <div style="display:flex; justify-content:space-between; align-items:center; padding:9px 0; border-bottom:1px solid #F1F0F6; font-size:13px;">
                            <span><?= htmlspecialchars($r['nom_entreprise']) ?><br><span style="color:var(--admin-texte-discret); font-size:11px;"><?= $r['nb_missions'] ?> mission(s)</span></span>
                            <a href="creer-reversement.php?partenaire_id=<?= $r['id'] ?>" style="color:var(--admin-violet); font-weight:700; text-decoration:none; font-size:13px;"><?= number_format($r['montant_du'], 0, ',', ' ') ?> F →</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>