<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('equipe');
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$userModel = new User();
$moiId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $flash = null;

    if ($action === 'creer') {
        $nom = trim($_POST['nom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $motDePasse = $_POST['mot_de_passe'] ?? '';
        $role = $_POST['role'] ?? '';

        if ($nom === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $flash = ['erreur', "Nom et email valides obligatoires."];
        } elseif (!in_array($role, ROLES_INTERNES, true)) {
            $flash = ['erreur', "Rôle invalide."];
        } elseif (strlen($motDePasse) < 8) {
            $flash = ['erreur', "Le mot de passe doit contenir au moins 8 caractères."];
        } elseif ($userModel->findByEmail($email)) {
            $flash = ['erreur', "Cet email est déjà utilisé."];
        } else {
            $nouvelId = $userModel->create($prenom, $nom, $email, $motDePasse, $telephone, $role);
            $nouveau = $userModel->getById($nouvelId);
            journaliser('compte.cree', 'compte', $nouvelId, $nouveau['matricule'], $nom . ' — ' . LIBELLES_ROLES[$role]);
        }
    } else {
        $cibleId = (int) ($_POST['membre_id'] ?? 0);
        $cible = $userModel->getById($cibleId);

        if (!$cible || !in_array($cible['role'], ROLES_INTERNES, true)) {
            $flash = ['erreur', "Membre introuvable."];
        } elseif ($cibleId === $moiId) {
            $flash = ['erreur', "Vous ne pouvez pas modifier votre propre compte depuis cette page."];
        } elseif ($action === 'changer_role' && in_array($_POST['role'] ?? '', ROLES_INTERNES, true)) {
            $userModel->changerRoleMembre($cibleId, $_POST['role']);
            journaliser('compte.role_modifie', 'compte', $cibleId, $cible['matricule'], $cible['nom'] . ' : ' . LIBELLES_ROLES[$cible['role']] . ' → ' . LIBELLES_ROLES[$_POST['role']]);
            $flash = ['succes', "{$cible['nom']} est maintenant : " . LIBELLES_ROLES[$_POST['role']] . "."];
        } elseif ($action === 'changer_statut' && in_array($_POST['statut'] ?? '', ['actif', 'suspendu'], true)) {
            $userModel->changerStatutMembre($cibleId, $_POST['statut']);
            journaliser($_POST['statut'] === 'suspendu' ? 'compte.suspendu' : 'compte.reactive', 'compte', $cibleId, $cible['matricule'], $cible['nom']);
            $flash = ['succes', $_POST['statut'] === 'suspendu' ? "{$cible['nom']} a été suspendu(e)." : "{$cible['nom']} a été réactivé(e)."];
        } elseif ($action === 'reset_mdp') {
            $temporaire = bin2hex(random_bytes(5));
            journaliser('compte.mdp_reinitialise', 'compte', $cibleId, $cible['matricule'], $cible['nom']);
            $userModel->reinitialiserMotDePasse($cibleId, $temporaire);
            $flash = ['mdp', $cible['nom'], $temporaire];
        }
    }

    $_SESSION['flash_equipe'] = $flash;
    header("Location: utilisateurs.php");
    exit;
}

$flash = $_SESSION['flash_equipe'] ?? null;
unset($_SESSION['flash_equipe']);

$recherche = trim($_GET['q'] ?? '');
$roleFiltre = in_array($_GET['role'] ?? '', ROLES_INTERNES, true) ? $_GET['role'] : '';
$membres = $userModel->getEquipe($recherche ?: null, $roleFiltre ?: null);
$stats = $userModel->compterEquipe();
$filtresActifs = $recherche || $roleFiltre;
$couleursRoles = ['admin' => 'violet', 'coordinateur' => 'amber', 'qualite' => 'rouge', 'finance' => 'vert', 'conseiller' => 'gris'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Équipe ALLÔ PRO — Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .select-filtre { padding: 10px 14px; border: 1px solid var(--admin-bordure); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 14px; background: white; }
        .membre-cellule { display: flex; align-items: center; gap: 10px; }
        .membre-avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
        .membre-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .membre-avatar svg { width: 19px; height: 19px; fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.7; }
        .membre-avatar--autre { background: #1D5670; }
        .membre-suspendu { opacity: 0.55; }
        .select-role { padding: 5px 8px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-size: 12.5px; font-family: 'Inter', sans-serif; background: white; }
        .lien-action { border: none; background: none; cursor: pointer; font-size: 12.5px; font-weight: 600; padding: 3px 0; font-family: 'Inter', sans-serif; }
        .lien-action--rouge { color: var(--admin-rouge); }
        .lien-action--vert { color: var(--admin-vert); }
        .lien-action--violet { color: var(--admin-violet); }
        .actions-cellule { display: flex; flex-direction: column; align-items: flex-start; gap: 2px; }
        .flash { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; }
        .flash--succes { background: #E6F7ED; color: var(--admin-vert); }
        .flash--erreur { background: #FDECEC; color: var(--admin-rouge); }
        .flash--mdp { background: #FEF3E2; color: #92400E; border: 1px solid #F5D9A8; }
        .flash__mdp-code { display: inline-block; margin: 6px 0; padding: 6px 12px; background: white; border-radius: 6px; font-family: monospace; font-size: 16px; font-weight: 700; letter-spacing: 0.05em; color: var(--admin-texte); user-select: all; }
        .champ-equipe { margin-bottom: 12px; }
        .champ-equipe label { display: block; font-size: 12px; font-weight: 600; color: var(--admin-texte-discret); margin-bottom: 4px; }
        .champ-equipe input, .champ-equipe select { width: 100%; padding: 9px 12px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-family: 'Inter', sans-serif; font-size: 13.5px; }
        .legende-roles { font-size: 12px; color: var(--admin-texte-discret); line-height: 1.6; margin-bottom: 14px; }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Équipe ALLÔ PRO</div>
                <div class="admin-entete__sous-titre">Comptes internes ayant accès au back-office</div>
            </div>
            <a href="roles.php" style="font-size:13px; color:var(--admin-violet); font-weight:600; text-decoration:none;">Configurer les permissions →</a>
        </div>

        <?php if ($flash): ?>
            <?php if ($flash[0] === 'mdp'): ?>
                <div class="flash flash--mdp">
                    Mot de passe temporaire de <strong><?= htmlspecialchars($flash[1]) ?></strong> :<br>
                    <span class="flash__mdp-code"><?= htmlspecialchars($flash[2]) ?></span><br>
                    Il n'est affiché qu'une seule fois. Transmettez-le par un canal sûr.
                </div>
            <?php else: ?>
                <div class="flash flash--<?= $flash[0] ?>"><?= htmlspecialchars($flash[1]) ?></div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">👥</div><div class="admin-kpi-carte__label">Membres</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['total'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">🔑</div><div class="admin-kpi-carte__label">Administrateurs</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['admins'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone">🎧</div><div class="admin-kpi-carte__label">Autres rôles</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['autres'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--rouge"><div class="admin-kpi-carte__icone">⏸️</div><div class="admin-kpi-carte__label">Suspendus</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['suspendus'] ?></div></div>
        </div>

        <div style="display:grid; grid-template-columns:2fr 1fr; gap:20px; align-items:start;">
            <div>
                <form method="GET" class="admin-recherche" style="flex-wrap:wrap;">
                    <input type="text" name="q" placeholder="Nom, email ou téléphone..." value="<?= htmlspecialchars($recherche) ?>">
                    <select name="role" class="select-filtre" onchange="this.form.submit()">
                        <option value="">Tous les rôles</option>
                        <?php foreach (ROLES_INTERNES as $r): ?>
                            <option value="<?= $r ?>" <?= $roleFiltre === $r ? 'selected' : '' ?>><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Rechercher</button>
                    <?php if ($filtresActifs): ?><a href="utilisateurs.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
                </form>

                <div class="admin-panneau">
                    <table class="admin-table">
                        <tr><th>Membre</th><th>Rôle</th><th>Activité</th><th>Statut</th><th>Actions</th></tr>
                        <?php if (empty($membres)): ?>
                            <tr><td colspan="5" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun membre trouvé.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($membres as $m):
                            $estMoi = (int) $m['id'] === $moiId;
                            $suspendu = $m['statut'] === 'suspendu';
                            $photoMembre = AvatarProfil::estValide($m['photo_profil'] ?? null, 'equipe')
                                ? (string) $m['photo_profil']
                                : null;
                            $initialesMembre = AvatarProfil::initiales(trim((string) ($m['prenom'] ?? '') . ' ' . (string) ($m['nom'] ?? '')));
                        ?>
                        <tr class="<?= $suspendu ? 'membre-suspendu' : '' ?>">
                            <td>
                                <div class="membre-cellule">
                                    <div class="membre-avatar <?= $m['role'] !== 'admin' ? 'membre-avatar--autre' : '' ?>">
                                        <?php if (empty($m['avatar_initiales']) && $photoMembre !== null): ?>
                                            <img src="../../public/<?= htmlspecialchars($photoMembre, ENT_QUOTES, 'UTF-8') ?>" alt="">
                                        <?php elseif (!empty($m['avatar_initiales'])): ?>
                                            <?= htmlspecialchars($initialesMembre, ENT_QUOTES, 'UTF-8') ?>
                                        <?php else: ?>
                                            <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <strong><?= htmlspecialchars($m['nom'] ?? '') ?></strong> <strong><?= htmlspecialchars($m['prenom'] ?? '') ?></strong>
                                        <?php if ($estMoi): ?><span class="admin-badge admin-badge--violet" style="margin-left:4px;">Vous</span><?php endif; ?><br>
                                        <span style="color:var(--admin-texte-discret); font-size:12px;"><span class="matricule-badge"><?= htmlspecialchars($m['matricule'] ?? '—') ?></span> · <?= htmlspecialchars($m['email']) ?></span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php if ($estMoi): ?>
                                    <span class="admin-badge admin-badge--<?= $couleursRoles[$m['role']] ?? 'gris' ?>"><?= htmlspecialchars(LIBELLES_ROLES[$m['role']] ?? $m['role']) ?></span>
                                <?php else: ?>
                                    <form method="POST" onsubmit="return confirm(<?= htmlspecialchars(json_encode('Changer le rôle de ' . $m['nom'] . ' ?'), ENT_QUOTES) ?>);">
                                        <input type="hidden" name="action" value="changer_role">
                                        <input type="hidden" name="membre_id" value="<?= $m['id'] ?>">
                                        <select name="role" class="select-role" onchange="this.form.requestSubmit()">
                                            <?php foreach (ROLES_INTERNES as $r): ?>
                                                <option value="<?= $r ?>" <?= $m['role'] === $r ? 'selected' : '' ?>><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </form>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:12.5px; color:var(--admin-texte-discret);">
                                <?= (int) $m['nb_messages'] ?> message(s)<br><?= (int) $m['nb_notes'] ?> note(s) interne(s)
                            </td>
                            <td><span class="admin-badge admin-badge--<?= $suspendu ? 'rouge' : 'vert' ?>"><?= $suspendu ? 'Suspendu' : 'Actif' ?></span></td>
                            <td>
                                <?php if ($estMoi): ?>
                                    <span style="font-size:12px; color:var(--admin-texte-discret);">—</span>
                                <?php else: ?>
                                    <div class="actions-cellule">
                                        <form method="POST" onsubmit="return confirm(<?= htmlspecialchars(json_encode($suspendu ? "Réactiver ce compte ?" : "Suspendre ce compte ? La personne ne pourra plus se connecter."), ENT_QUOTES) ?>);">
                                            <input type="hidden" name="action" value="changer_statut">
                                            <input type="hidden" name="membre_id" value="<?= $m['id'] ?>">
                                            <input type="hidden" name="statut" value="<?= $suspendu ? 'actif' : 'suspendu' ?>">
                                            <button type="submit" class="lien-action <?= $suspendu ? 'lien-action--vert' : 'lien-action--rouge' ?>"><?= $suspendu ? 'Réactiver' : 'Suspendre' ?></button>
                                        </form>
                                        <form method="POST" onsubmit="return confirm('Générer un nouveau mot de passe temporaire ? L\'ancien ne fonctionnera plus.');">
                                            <input type="hidden" name="action" value="reset_mdp">
                                            <input type="hidden" name="membre_id" value="<?= $m['id'] ?>">
                                            <button type="submit" class="lien-action lien-action--violet">Réinitialiser le mot de passe</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Ajouter un membre</div>
                <p class="legende-roles">
                    <?php foreach (ROLES_INTERNES as $r): ?>
                        <strong><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></strong> : <?= htmlspecialchars(DESCRIPTIONS_ROLES[$r]) ?><br>
                    <?php endforeach; ?>
                </p>
                <form method="POST">
                    <input type="hidden" name="action" value="creer">
                    <div class="champ-equipe"><label>Nom</label><input type="text" name="nom" required></div>
                    <div class="champ-equipe"><label>Prénom</label><input type="text" name="prenom" required></div>
                    <div class="champ-equipe"><label>Email</label><input type="email" name="email" required></div>
                    <div class="champ-equipe"><label>Téléphone</label><input type="tel" name="telephone"></div>
                    <div class="champ-equipe">
                        <label>Rôle</label>
                        <select name="role" required>
                            <?php foreach (ROLES_INTERNES as $r): ?>
                                <option value="<?= $r ?>"><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="champ-equipe"><label>Mot de passe initial (8 caractères min.)</label><input type="password" name="mot_de_passe" minlength="8" required></div>
                    <button type="submit" style="width:100%; padding:11px; background:var(--admin-violet); color:white; border:none; border-radius:8px; font-weight:700; cursor:pointer; margin-top:4px;">Créer le compte</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>