<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('coordination');
require_once __DIR__ . '/../../includes/icones.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Coordination — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
</head>
<body>

<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="contenu">
        <div class="contenu__entete">
            <div>
                <div class="contenu__titre">Coordination des conversations</div>
                <p class="liste-soustitre">Attribuez les conversations aux conseillers et suivez leur traitement.</p>
                <nav class="coord-vues" role="tablist" aria-label="Vue de coordination">
                    <button type="button" class="coord-vue coord-vue--actif" role="tab" aria-selected="true" data-vue="clients">Client</button>
                    <button type="button" class="coord-vue" role="tab" aria-selected="false" data-vue="conseillers">Conseiller</button>
                </nav>
            </div>
        </div>

        <div class="coord-contenu">
            <aside class="coord-sidebar">
                <div class="coord-sidebar__filtres">
                    <button class="coord-filtre" data-filtre="non_attribuees">Non attribuées <span class="coord-filtre__badge" id="badge-non_attribuees">0</span></button>
                    <button class="coord-filtre" data-filtre="attribuees">Attribuées <span class="coord-filtre__badge" id="badge-attribuees">0</span></button>
                    <button class="coord-filtre coord-filtre--actif" data-filtre="toutes">Toutes <span class="coord-filtre__badge" id="badge-toutes">0</span></button>
                </div>
                <div class="coord-sidebar__liste" id="coord-liste"><p class="coord-vide">Chargement…</p></div>
            </aside>

            <main class="coord-contenu" id="coord-detail">
                <div class="coord-accueil">
                    <div class="coord-accueil__icone"><?= icone('shuffle', 30) ?></div>
                    <h2>Coordination des conversations</h2>
                    <p>Sélectionnez une conversation dans la liste pour l'attribuer à un conseiller ou en consulter le contenu.</p>
                </div>
            </main>
        </div>

        <div class="coord-modale-fond" id="modale-attribution">
            <div class="coord-modale" role="dialog" aria-modal="true" aria-labelledby="attrib-titre">
                <div class="coord-modale__entete">
                    <h3 id="attrib-titre">Attribuer <span id="attrib-nom-client"></span></h3>
                    <button class="coord-modale__fermer" data-fermer aria-label="Fermer"><?= icone('x', 18) ?></button>
                </div>
                <input type="text" id="attrib-recherche" placeholder="Rechercher un conseiller..." class="coord-recherche">
                <div class="coord-conseillers-liste" id="attrib-liste"></div>
            </div>
        </div>

        <div class="coord-modale-fond" id="modale-conversation">
            <div class="coord-modale coord-modale--large" role="dialog" aria-modal="true" aria-labelledby="conv-nom-client">
                <div class="coord-modale__entete">
                    <div>
                        <h3 id="conv-nom-client"></h3>
                        <div class="coord-modale__sous-titre" id="conv-conseiller-actuel"></div>
                    </div>
                    <div class="coord-modale__actions">
                        <button class="coord-btn-secondaire" id="btn-changer-conseiller">Changer de conseiller</button>
                        <button class="coord-modale__fermer" data-fermer aria-label="Fermer"><?= icone('x', 18) ?></button>
                    </div>
                </div>
                <div class="coord-fil" id="conv-fil"></div>
            </div>
        </div>
    </div>
</div>

<script src="../../public/js/coordinateur.js?v=<?= filemtime(__DIR__ . '/../../public/js/coordinateur.js') ?>"></script>
</body>
</html>