<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('clients');
require_once __DIR__ . '/../../models/User.php';

$userModel = new User();
$recherche = trim($_GET['q'] ?? '');
$clients = $userModel->getAllClients($recherche ?: null);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clients — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Clients</div>
                <div class="admin-entete__sous-titre"><?= count($clients) ?> client<?= count($clients) > 1 ? 's' : '' ?> <?= $recherche ? 'trouvé(s)' : 'au total' ?></div>
            </div>
        </div>

        <form method="GET" class="admin-recherche">
            <input type="text" name="q" placeholder="Rechercher par nom, email ou téléphone..." value="<?= htmlspecialchars($recherche) ?>">
            <button type="submit">Rechercher</button>
            <?php if ($recherche): ?><a href="clients.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau">
            <table class="admin-table">
                <tr>
                    <th>Client</th><th>Contact</th><th>Dossiers</th><th>En cours</th><th>Inscrit le</th><th>Statut</th><th></th>
                </tr>
                <?php if (empty($clients)): ?>
                    <tr><td colspan="7" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun client trouvé.</td></tr>
                <?php endif; ?>
                <?php foreach ($clients as $c): ?>
                <tr>
                    <td>
                        <div style="display:flex; align-items:center; gap:10px;">
                            <div style="width:32px; height:32px; border-radius:50%; background:var(--admin-violet); color:white; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:700; flex-shrink:0;">
                                <?= htmlspecialchars(strtoupper(mb_substr($c['nom'], 0, 1))) ?>
                            </div>
                            <strong><?= htmlspecialchars($c['nom']) ?></strong><strong><?= htmlspecialchars($c['prenom']) ?></strong>
                        </div>
                    </td>
                    <td><?= htmlspecialchars($c['telephone'] ?: '—') ?><br><span style="color:var(--admin-texte-discret); font-size:12px;"><?= htmlspecialchars($c['email']) ?></span></td>
                    <td><?= $c['nb_demandes'] ?></td>
                    <td><?= $c['nb_actives'] > 0 ? "<span class='admin-badge admin-badge--amber'>{$c['nb_actives']}</span>" : '—' ?></td>
                    <td><?= date('d/m/Y', strtotime($c['date_creation'])) ?></td>
                    <td><span class="admin-badge admin-badge--<?= $c['statut'] === 'actif' ? 'vert' : 'rouge' ?>"><?= $c['statut'] === 'actif' ? 'Actif' : 'Suspendu' ?></span></td>
                    <td><a href="client-detail.php?id=<?= $c['id'] ?>" style="color:var(--admin-violet); font-weight:600; text-decoration:none; font-size:13px;">Voir →</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>