<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('abonnements');
require_once __DIR__ . '/../../models/Abonnement.php';
require_once __DIR__ . '/../../models/Categorie.php';

$abonnementModel = new Abonnement();
$categorieModel = new Categorie();

$id = $_GET['id'] ?? null;
$formule = $id ? $abonnementModel->getFormuleById($id) : null;
$categoriesEligiblesActuelles = $id ? array_column($abonnementModel->getCategoriesEligibles($id), 'id') : [];

if ($id && !$formule) { die("Formule introuvable."); }

$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['supprimer']) && $id) {
        if (!$abonnementModel->supprimerFormule($id)) {
            $erreur = "Impossible de supprimer : des clients sont déjà abonnés à cette formule. Désactivez-la plutôt.";
        } else {
            journaliser('formule.supprimee', 'formule', $id, $formule['nom']);
            header("Location: abonnements.php");
            exit;
        }
    } else {
        $nom = trim($_POST['nom']);
        $prix = $_POST['prix'];
        $credits = $_POST['credits'];
        $description = trim($_POST['description']);
        $categoriesChoisies = $_POST['categories'] ?? [];

        if ($id) {
            $abonnementModel->modifierFormuleComplete($id, $nom, $prix, $credits, $description, $categoriesChoisies);
            journaliser('formule.modifiee', 'formule', $id, $nom, 'Prix : ' . $formule['prix'] . ' → ' . $prix . ' F · Crédits : ' . $formule['nombre_credits'] . ' → ' . $credits);
        } else {
            $id = $abonnementModel->creerFormuleComplete($nom, $prix, $credits, $description, $categoriesChoisies);
            journaliser('formule.creee', 'formule', $id, $nom, $prix . ' F · ' . $credits . ' crédit(s)');
        }
        header("Location: abonnements.php");
        exit;
    }
}

$categoriesParPole = [];
foreach ($categorieModel->getSousCategories() as $c) {
    $categoriesParPole[$c['parent_nom']][] = $c;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $formule ? 'Modifier' : 'Créer' ?> une formule — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .champ-admin { margin-bottom: 16px; }
        .champ-admin label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; }
        .champ-admin input, .champ-admin textarea { width: 100%; padding: 10px 12px; border: 1px solid var(--admin-bordure); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 14px; }
        .pole-checkbox-groupe { margin-bottom: 14px; }
        .pole-checkbox-groupe__titre { font-size: 12.5px; font-weight: 700; color: var(--admin-texte-discret); text-transform: uppercase; margin-bottom: 6px; }
        .checkbox-ligne { display: flex; align-items: center; gap: 8px; padding: 6px 0; font-size: 13.5px; }
        .formule-detail-erreur { background:#FDECEC; color:var(--admin-rouge); padding:12px 16px; border-radius:8px; margin-bottom:18px; font-size:14px; }
    </style>
</head>
<body class="page-formule-detail">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu" style="max-width: 640px;">
        <div class="admin-entete">
            <div>
                <a href="abonnements.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour aux abonnements</a>
                <div class="admin-entete__titre" style="margin-top:6px;"><?= $formule ? 'Modifier' : 'Créer' ?> une formule</div>
            </div>
        </div>

        <?php if ($erreur): ?><div class="formule-detail-erreur"><?= htmlspecialchars($erreur) ?></div><?php endif; ?>

        <div class="admin-panneau">
            <form method="POST">
                <div class="champ-admin">
                    <label>Nom de la formule</label>
                    <input type="text" name="nom" value="<?= htmlspecialchars($formule['nom'] ?? '') ?>" required>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                    <div class="champ-admin">
                        <label>Prix mensuel (FCFA)</label>
                        <input type="number" name="prix" value="<?= $formule['prix'] ?? '' ?>" step="500" required>
                    </div>
                    <div class="champ-admin">
                        <label>Nombre d'interventions incluses</label>
                        <input type="number" name="credits" value="<?= $formule['nombre_credits'] ?? '' ?>" min="1" required>
                    </div>
                </div>

                <div class="champ-admin">
                    <label>Description (affichée au client)</label>
                    <textarea name="description" rows="2"><?= htmlspecialchars($formule['description'] ?? '') ?></textarea>
                </div>

                <div class="champ-admin">
                    <label>Catégories éligibles</label>
                    <p style="font-size:12px; color:var(--admin-texte-discret); margin-bottom:10px;">Aucune case cochée = toutes les catégories sont couvertes par cette formule.</p>

                    <?php foreach ($categoriesParPole as $poleNom => $sousCats): ?>
                        <div class="pole-checkbox-groupe">
                            <div class="pole-checkbox-groupe__titre"><?= htmlspecialchars($poleNom) ?></div>
                            <?php foreach ($sousCats as $sc): ?>
                                <label class="checkbox-ligne">
                                    <input type="checkbox" name="categories[]" value="<?= $sc['id'] ?>" <?= in_array($sc['id'], $categoriesEligiblesActuelles) ? 'checked' : '' ?>>
                                    <?= htmlspecialchars($sc['nom']) ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <button type="submit" style="width:100%; padding:12px; background:var(--admin-violet); color:white; border:none; border-radius:8px; font-weight:700; cursor:pointer; margin-top:8px;">
                    <?= $formule ? 'Enregistrer les modifications' : 'Créer la formule' ?>
                </button>
            </form>

            <?php if ($formule): ?>
                <form method="POST" onsubmit="return confirm('Supprimer définitivement cette formule ?');" style="margin-top:10px;">
                    <input type="hidden" name="supprimer" value="1">
                    <button type="submit" style="width:100%; padding:10px; background:none; border:1px solid var(--admin-rouge); color:var(--admin-rouge); border-radius:8px; font-weight:600; cursor:pointer;">Supprimer cette formule</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>