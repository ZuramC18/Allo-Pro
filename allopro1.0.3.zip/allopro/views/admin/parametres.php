<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('parametres');
require_once __DIR__ . '/../../models/Parametre.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$parametreModel = new Parametre();
$userModel = new User();
if (empty($_SESSION['csrf_parametres'])) {
    $_SESSION['csrf_parametres'] = bin2hex(random_bytes(32));
}

$erreur = '';
$messageSucces = $_SESSION['flash_parametres'] ?? '';
unset($_SESSION['flash_parametres']);
$valeurs = $parametreModel->getAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string) ($_POST['csrf'] ?? '');
    if (!hash_equals($_SESSION['csrf_parametres'], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (in_array($_POST['action'] ?? '', ['photo_profil', 'supprimer_photo', 'avatar_initiales'], true)) {
        $idAdmin = (int) $_SESSION['user_id'];
        try {
            if ($_POST['action'] === 'photo_profil') {
                $nouveauChemin = AvatarProfil::stocker($_FILES['photo_profil'] ?? [], 'equipe');
                if (!$userModel->mettreAJourPhotoProfilInterne($idAdmin, $nouveauChemin)) {
                    AvatarProfil::supprimer($nouveauChemin);
                    throw new RuntimeException('La photo n’a pas pu être associée au compte.');
                }
                AvatarProfil::supprimer($_SESSION['photo_profil'] ?? null);
                $_SESSION['photo_profil'] = $nouveauChemin;
                $_SESSION['avatar_initiales'] = false;
                $_SESSION['flash_parametres'] = 'Votre photo de profil a été mise à jour.';
            } elseif ($_POST['action'] === 'supprimer_photo') {
                if (!$userModel->supprimerPhotoProfilInterne($idAdmin)) {
                    throw new RuntimeException('La photo n’a pas pu être supprimée.');
                }
                AvatarProfil::supprimer($_SESSION['photo_profil'] ?? null);
                $_SESSION['photo_profil'] = null;
                $_SESSION['flash_parametres'] = 'Votre photo a été supprimée.';
            } else {
                $afficherInitiales = ($_POST['avatar_initiales'] ?? '') === '1';
                if (!$userModel->definirAvatarInitialesInterne($idAdmin, $afficherInitiales)) {
                    throw new RuntimeException('La préférence d’affichage n’a pas pu être enregistrée.');
                }
                $_SESSION['avatar_initiales'] = $afficherInitiales;
                $_SESSION['flash_parametres'] = $afficherInitiales
                    ? 'Les initiales seront affichées à la place de la photo.'
                    : 'La photo sera affichée lorsqu’elle est disponible.';
            }
            header('Location: parametres.php');
            exit;
        } catch (RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Mise à jour avatar admin ' . $idAdmin . ' : ' . $exception->getMessage());
            if (isset($nouveauChemin)) AvatarProfil::supprimer($nouveauChemin);
            $erreur = 'La photo de profil n’a pas pu être enregistrée. Réessayez.';
        }
    } elseif (isset($_POST['changer_mot_de_passe'])) {
        $motDePasseActuel = is_string($_POST['mot_de_passe_actuel'] ?? null) ? $_POST['mot_de_passe_actuel'] : '';
        $nouveauMotDePasse = is_string($_POST['nouveau_mot_de_passe'] ?? null) ? $_POST['nouveau_mot_de_passe'] : '';
        $confirmationMotDePasse = is_string($_POST['confirmation_mot_de_passe'] ?? null) ? $_POST['confirmation_mot_de_passe'] : '';

        if ($motDePasseActuel === '' || $nouveauMotDePasse === '' || $confirmationMotDePasse === '') {
            $erreur = 'Veuillez remplir tous les champs du changement de mot de passe.';
        } elseif (strlen($nouveauMotDePasse) < 8) {
            $erreur = 'Le nouveau mot de passe doit contenir au moins 8 caractères.';
        } elseif ($nouveauMotDePasse !== $confirmationMotDePasse) {
            $erreur = 'La confirmation ne correspond pas au nouveau mot de passe.';
        } else {
            $resultat = $userModel->changerMotDePasseAdmin(
                (int) $_SESSION['user_id'],
                $motDePasseActuel,
                $nouveauMotDePasse
            );

            if ($resultat === 'mot_de_passe_incorrect') {
                $erreur = 'Le mot de passe actuel est incorrect.';
            } elseif ($resultat === 'ok') {
                journaliser('admin.mot_de_passe_modifie', 'utilisateur', (int) $_SESSION['user_id'], 'Mot de passe administrateur');
                $_SESSION['flash_parametres'] = 'Votre mot de passe a été modifié.';
                header('Location: parametres.php');
                exit;
            } else {
                $erreur = 'Le mot de passe n’a pas pu être modifié. Veuillez réessayer.';
            }
        }
    } else {
        $tauxBrut = trim((string) ($_POST['taux_commission'] ?? ''));
        $taux = filter_var($tauxBrut, FILTER_VALIDATE_FLOAT);
        $limiteBrute = trim((string) ($_POST['limite_clients_par_conseiller'] ?? ''));
        $limite = filter_var($limiteBrute, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 10000]]);

        if ($taux === false || $taux < 0 || $taux > 100 || abs($taux * 2 - round($taux * 2)) > 0.00001) {
            $erreur = 'La commission doit être comprise entre 0 et 100 %, par pas de 0,5 %.';
        } elseif ($limite === false) {
            $erreur = 'Le plafond doit être un nombre entier compris entre 0 et 10 000.';
        } else {
            $anciens = $valeurs;
            $nouveaux = [
                'taux_commission' => number_format((float) $taux, 1, '.', ''),
                'attribution_automatique' => isset($_POST['attribution_automatique']) ? '1' : '0',
                'limite_clients_par_conseiller' => (string) $limite,
            ];

            if ($parametreModel->setMultiple($nouveaux)) {
                if ((float) $anciens['taux_commission'] !== (float) $nouveaux['taux_commission']) {
                    journaliser('parametre.commission_modifiee', 'parametre', null, 'taux_commission', $anciens['taux_commission'] . ' % → ' . $nouveaux['taux_commission'] . ' %');
                }
                if ($anciens['attribution_automatique'] !== $nouveaux['attribution_automatique']) {
                    journaliser('parametre.attribution_modifiee', 'parametre', null, 'attribution_automatique', $nouveaux['attribution_automatique'] === '1' ? 'Activée' : 'Désactivée');
                }
                if ((int) $anciens['limite_clients_par_conseiller'] !== (int) $nouveaux['limite_clients_par_conseiller']) {
                    journaliser('parametre.limite_attribution_modifiee', 'parametre', null, 'limite_clients_par_conseiller', $anciens['limite_clients_par_conseiller'] . ' → ' . $nouveaux['limite_clients_par_conseiller']);
                }
                $_SESSION['flash_parametres'] = 'Les paramètres ont été enregistrés.';
                header('Location: parametres.php');
                exit;
            }

            $erreur = 'Les paramètres n’ont pas pu être enregistrés.';
        }

        $valeurs['taux_commission'] = $tauxBrut;
        $valeurs['attribution_automatique'] = isset($_POST['attribution_automatique']) ? '1' : '0';
        $valeurs['limite_clients_par_conseiller'] = $limiteBrute;
    }
}

$echapper = static fn($valeur) => htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
$admin = $userModel->getById((int) $_SESSION['user_id']);
$nomAdmin = trim((string) ($admin['prenom'] ?? '') . ' ' . (string) ($admin['nom'] ?? ''));
$initialesAdmin = AvatarProfil::initiales($nomAdmin);
$photoAdmin = AvatarProfil::estValide($admin['photo_profil'] ?? null, 'equipe')
    ? (string) $admin['photo_profil']
    : null;
$avatarInitialesAdmin = !empty($admin['avatar_initiales']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paramètres — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/parametres-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/parametres-admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/avatar-profil.css?v=<?= filemtime(__DIR__ . '/../../public/css/avatar-profil.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <main class="admin-contenu parametres-page">
        <header class="admin-entete">
            <div>
                <div class="admin-entete__titre">Paramètres de la plateforme</div>
                <p class="admin-entete__sous-titre">Réglez les commissions et les règles de répartition des nouveaux clients.</p>
            </div>
        </header>

        <?php if ($messageSucces): ?>
            <div class="parametres-message parametres-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur): ?>
            <div class="parametres-message parametres-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <section class="admin-panneau parametres-section parametres-avatar" aria-labelledby="parametres-avatar-titre">
            <header class="parametres-section__entete">
                <div class="parametres-section__numero">01</div>
                <div><h2 id="parametres-avatar-titre">Photo de votre profil</h2><p>Personnalisez votre identité dans l’espace ALLÔ PRO.</p></div>
            </header>
            <div class="avatar-profil">
                <div class="avatar-profil__entete">
                    <div><h2><?= $echapper($nomAdmin !== '' ? $nomAdmin : 'Mon compte') ?></h2><p>JPG, PNG ou WebP · 5 Mo maximum</p></div>
                    <div class="avatar-profil__apercu" aria-hidden="true">
                        <?php if (!$avatarInitialesAdmin && $photoAdmin !== null): ?>
                            <img src="../../public/<?= $echapper($photoAdmin) ?>" alt="">
                        <?php elseif ($avatarInitialesAdmin): ?>
                            <?= $echapper($initialesAdmin) ?>
                        <?php else: ?>
                            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                        <?php endif; ?>
                    </div>
                </div>
                <form method="POST" enctype="multipart/form-data" class="avatar-profil__formulaire">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
                    <input type="hidden" name="action" value="photo_profil">
                    <input type="hidden" name="MAX_FILE_SIZE" value="5242880">
                    <input class="avatar-profil__input-fichier" id="photo-profil-admin" type="file" name="photo_profil" accept="image/jpeg,image/png,image/webp" aria-label="Choisir une photo de profil" required>
                    <label class="avatar-profil__fichier" for="photo-profil-admin">Choisir une photo</label>
                    <button type="submit" class="avatar-profil__bouton">Enregistrer la photo</button>
                </form>
                <?php if ($photoAdmin !== null): ?>
                    <form method="POST" class="avatar-profil__action">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
                        <input type="hidden" name="action" value="supprimer_photo">
                        <button type="submit" class="avatar-profil__lien">Supprimer la photo</button>
                    </form>
                <?php endif; ?>
                <form method="POST" class="avatar-profil__bascule">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
                    <input type="hidden" name="action" value="avatar_initiales">
                    <input type="hidden" name="avatar_initiales" value="0">
                    <label for="avatar-initiales-admin">Afficher mes initiales à la place de la photo</label>
                    <input id="avatar-initiales-admin" type="checkbox" name="avatar_initiales" value="1" <?= $avatarInitialesAdmin ? 'checked' : '' ?> onchange="this.form.querySelector('input[type=hidden][name=avatar_initiales]').disabled = this.checked; this.form.submit()">
                </form>
            </div>
        </section>

        <form method="POST" class="parametres-form">
            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">

            <section class="admin-panneau parametres-section" aria-labelledby="parametres-finance-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">02</div>
                    <div><h2 id="parametres-finance-titre">Finance</h2><p>Commissions appliquées aux reversements à venir.</p></div>
                </header>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="taux-commission">Commission ALLÔ PRO</label>
                        <p>Pourcentage retenu avant le reversement au partenaire. Les reversements déjà créés ne sont pas recalculés.</p>
                    </div>
                    <div class="parametres-taux">
                        <input id="taux-commission" type="number" name="taux_commission" value="<?= $echapper($valeurs['taux_commission']) ?>" min="0" max="100" step="0.5" inputmode="decimal" required>
                        <span>%</span>
                    </div>
                </div>
            </section>

            <section class="admin-panneau parametres-section" aria-labelledby="parametres-conversations-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">03</div>
                    <div><h2 id="parametres-conversations-titre">Attribution des clients</h2><p>Contrôlez la répartition des nouvelles conversations.</p></div>
                </header>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="attribution-automatique">Attribution automatique</label>
                        <p>Au premier message envoyé par un client, l’affecter au conseiller actif le moins chargé.</p>
                    </div>
                    <label class="parametres-switch" for="attribution-automatique">
                        <input id="attribution-automatique" type="checkbox" name="attribution_automatique" value="1" role="switch" <?= $valeurs['attribution_automatique'] === '1' ? 'checked' : '' ?>>
                        <span class="parametres-switch__piste" aria-hidden="true"></span>
                        <span class="parametres-switch__etat"><?= $valeurs['attribution_automatique'] === '1' ? 'Activée' : 'Désactivée' ?></span>
                    </label>
                </div>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="limite-clients">Plafond par conseiller</label>
                        <p>Limite les nouvelles affectations. Les clients déjà attribués restent en place. Saisissez 0 pour ne pas fixer de plafond.</p>
                    </div>
                    <div class="parametres-limite">
                        <input id="limite-clients" type="number" name="limite_clients_par_conseiller" value="<?= $echapper($valeurs['limite_clients_par_conseiller']) ?>" min="0" max="10000" step="1" inputmode="numeric" required>
                        <span>clients</span>
                    </div>
                </div>
            </section>

            <div class="parametres-actions">
                <p>Les changements s’appliquent aux prochaines opérations.</p>
                <button type="submit" class="parametres-enregistrer">Enregistrer les paramètres</button>
            </div>
        </form>

        <form method="POST" class="parametres-form">
            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
            <section class="admin-panneau parametres-section" aria-labelledby="parametres-securite-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">04</div>
                    <div><h2 id="parametres-securite-titre">Sécurité</h2><p>Modifiez le mot de passe utilisé pour vous connecter à votre compte administrateur.</p></div>
                </header>
                <div class="parametres-password-fields">
                    <div>
                        <label for="mot-de-passe-actuel">Mot de passe actuel</label>
                        <input id="mot-de-passe-actuel" type="password" name="mot_de_passe_actuel" autocomplete="current-password" required>
                    </div>
                    <div>
                        <label for="nouveau-mot-de-passe">Nouveau mot de passe</label>
                        <input id="nouveau-mot-de-passe" type="password" name="nouveau_mot_de_passe" autocomplete="new-password" minlength="8" required>
                    </div>
                    <div>
                        <label for="confirmation-mot-de-passe">Confirmer le nouveau mot de passe</label>
                        <input id="confirmation-mot-de-passe" type="password" name="confirmation_mot_de_passe" autocomplete="new-password" minlength="8" required>
                    </div>
                </div>
                <div class="parametres-actions parametres-actions--securite">
                    <p>Utilisez au moins 8 caractères.</p>
                    <button type="submit" name="changer_mot_de_passe" value="1" class="parametres-enregistrer">Modifier le mot de passe</button>
                </div>
            </section>
        </form>
    </main>
</div>
<script>
document.getElementById('attribution-automatique').addEventListener('change', function () {
    document.querySelector('.parametres-switch__etat').textContent = this.checked ? 'Activée' : 'Désactivée';
});
</script>
</body>
</html>