<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('audit');
require_once __DIR__ . '/../../models/Audit.php';

$auditModel = new Audit();

// ===== Filtres =====
$periodes = ['jour' => "Aujourd'hui", '7j' => '7 jours', '30j' => '30 jours', 'tout' => 'Tout'];
$periode = $_GET['periode'] ?? '7j';
if (!isset($periodes[$periode])) $periode = '7j';
$debut = ['jour' => date('Y-m-d'), '7j' => date('Y-m-d', strtotime('-6 days')), '30j' => date('Y-m-d', strtotime('-29 days')), 'tout' => ''][$periode];

$matricule = trim($_GET['matricule'] ?? '');
if (!preg_match('/^([A-Z]{2}-\d{5}|SYSTEME)$/', $matricule)) $matricule = '';

$filtres = [
    'debut' => $debut,
    'acteur_type' => trim($_GET['acteur_type'] ?? ''),
    'matricule' => $matricule,
    'categorie' => trim($_GET['categorie'] ?? ''),
    'q' => trim($_GET['q'] ?? ''),
];

// ===== Export CSV (respecte les filtres ; l'export lui-même est journalisé) =====
if (isset($_GET['export'])) {
    $lignes = $auditModel->rechercher($filtres, 5000, 0);
    journaliser('audit.exporte', 'audit', null, null, count($lignes) . ' ligne(s) exportée(s)');

    // Neutralise les cellules qu'Excel interpréterait comme une formule (ex. un nom de compte commençant par "=")
    $sur = fn($v) => (is_string($v) && preg_match('/^[=+\-@\t\r]/', $v)) ? "'" . $v : $v;

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="audit-allopro-' . date('Ymd-His') . '.csv"');
    $sortie = fopen('php://output', 'w');
    fwrite($sortie, "\xEF\xBB\xBF");
    fputcsv($sortie, ['Date', 'Matricule', 'Nom', 'Type', 'Action', 'Entité', 'Cible', 'Détail', 'IP'], ';');
    foreach ($lignes as $l) {
        fputcsv($sortie, array_map($sur, [$l['date_creation'], $l['acteur_matricule'], $l['acteur_nom'], $l['acteur_type'], $l['action'], $l['entite'], $l['cible'], $l['detail'], $l['ip']]), ';');
    }
    fclose($sortie);
    exit;
}

// ===== Données =====
$parPage = 50;
$total = $auditModel->compter($filtres);
$nbPages = max(1, (int) ceil($total / $parPage));
$page = min(max(1, (int) ($_GET['page'] ?? 1)), $nbPages);
$evenements = $auditModel->rechercher($filtres, $parPage, ($page - 1) * $parPage);
$stats = $auditModel->stats();
$categories = $auditModel->categories();
$typesActeurs = $auditModel->typesActeurs();

$libellesActions = [
    'connexion.reussie' => 'Connexion', 'connexion.echec' => 'Échec de connexion', 'connexion.refusee' => 'Connexion refusée',
    'compte.cree' => 'Compte créé', 'compte.role_modifie' => 'Rôle modifié', 'compte.suspendu' => 'Compte suspendu',
    'compte.reactive' => 'Compte réactivé', 'compte.mdp_reinitialise' => 'Mot de passe réinitialisé',
    'permissions.modifiees' => 'Permissions modifiées', 'parametre.commission_modifiee' => 'Commission modifiée',
    'parametre.attribution_modifiee' => 'Attribution automatique modifiée', 'parametre.limite_attribution_modifiee' => 'Plafond de conseillers modifié',
    'reversement.cree' => 'Reversement créé', 'reversement.paye' => 'Reversement payé',
    'client.suspendu' => 'Client suspendu', 'client.reactive' => 'Client réactivé',
    'partenaire.statut_modifie' => 'Statut partenaire modifié', 'partenaire.niveau_modifie' => 'Niveau partenaire modifié',
    'technicien.statut_modifie' => 'Statut technicien modifié',
    'demande.attribuee' => 'Mission attribuée', 'mission.statut_modifie' => 'Statut de mission modifié', 'mission.cloturee' => 'Mission clôturée',
    'sav.mis_a_jour' => 'Ticket SAV mis à jour', 'message.modifie' => 'Message modifié',
    'formule.creee' => 'Formule créée', 'formule.modifiee' => 'Formule modifiée', 'formule.supprimee' => 'Formule supprimée',
    'paiement.valide' => 'Paiement validé', 'abonnement.active' => 'Abonnement activé', 'audit.exporte' => 'Journal exporté',
    'session.coupee' => 'Session coupée (suspension)', 'session.role_actualise' => 'Rôle actualisé en session',
    'conversation.reassignee' => 'Conversation réassignée',
    'conversation.fermee' => 'Conversation clôturée',
    'conversation.reouverte' => 'Conversation réouverte',
    'conversation.attribuee' => 'Conversation attribuée', 'conversation.reassignee' => 'Conversation réassignée',
];
$libellesTypes = LIBELLES_ROLES + ['partenaire' => 'Partenaire', 'technicien' => 'Technicien', 'systeme' => 'Système', 'inconnu' => 'Non identifié'];

function couleurAction($action) {
    if (in_array($action, ['connexion.echec', 'connexion.refusee', 'compte.suspendu', 'client.suspendu', 'formule.supprimee'], true)) return 'rouge';
    $categorie = explode('.', $action)[0];
    return ['compte' => 'amber', 'permissions' => 'amber', 'parametre' => 'amber', 'reversement' => 'violet', 'paiement' => 'violet', 'formule' => 'violet', 'abonnement' => 'violet'][$categorie] ?? 'gris';
}

function urlAudit(array $modif = []) {
    $p = array_filter(array_merge($_GET, $modif), fn($v) => $v !== '' && $v !== null);
    return '?' . http_build_query($p);
}

$nomFiltre = '';
if ($matricule && !empty($evenements)) {
    foreach ($evenements as $e) { if ($e['acteur_matricule'] === $matricule) { $nomFiltre = $e['acteur_nom']; break; } }
}
$filtresActifs = $filtres['acteur_type'] || $matricule || $filtres['categorie'] || $filtres['q'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Journal d'audit — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .page-audit { --audit-surface: #FFFFFF; --audit-accent-fond: #EFEBFD; --audit-accent-texte: var(--admin-violet); --audit-echec-fond: #FEF6F6; }
        .audit-filtres { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 18px; }
        .audit-filtres input, .audit-filtres select { padding: 10px 14px; border: 1px solid var(--admin-bordure); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 13.5px; background: var(--audit-surface); }
        .audit-filtres button { padding: 10px 20px; background: var(--admin-violet); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; }
        .matricule-badge { display: inline-block; font-family: monospace; font-size: 12px; font-weight: 700; background: var(--audit-accent-fond); color: var(--audit-accent-texte); padding: 2px 8px; border-radius: 6px; text-decoration: none; }
        .matricule-badge:hover { background: var(--admin-violet); color: white; }
        .audit-detail { font-size: 12.5px; color: var(--admin-texte-discret); max-width: 340px; line-height: 1.5; }
        .audit-cible { font-size: 13px; }
        .audit-cible a { color: var(--admin-texte); text-decoration: none; border-bottom: 1px dotted var(--admin-texte-discret); }
        .ligne-echec td { background: var(--audit-echec-fond); }
        .bandeau-filtre { background: var(--audit-accent-fond); color: var(--audit-accent-texte); padding: 11px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 13.5px; display: flex; justify-content: space-between; align-items: center; }
        .bandeau-filtre a { color: var(--audit-accent-texte); font-weight: 700; text-decoration: none; }
        .pagination-audit { display: flex; justify-content: space-between; align-items: center; margin-top: 16px; font-size: 13px; color: var(--admin-texte-discret); }
        .pagination-audit a { padding: 7px 14px; border: 1px solid var(--admin-bordure); border-radius: 6px; text-decoration: none; color: var(--admin-texte); background: var(--audit-surface); font-weight: 600; }
        .btn-export { padding: 9px 18px; border: 1px solid var(--admin-bordure); background: var(--audit-surface); border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--admin-texte); text-decoration: none; }
    </style>
</head>
<body class="page-audit">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Journal d'audit</div>
                <div class="admin-entete__sous-titre">Qui a fait quoi, quand, et depuis où — journal en lecture seule</div>
            </div>
            <a href="<?= htmlspecialchars(urlAudit(['export' => 1, 'page' => null])) ?>" class="btn-export">⬇ Exporter en CSV</a>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">📜</div><div class="admin-kpi-carte__label">Actions aujourd'hui</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['aujourdhui'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">📅</div><div class="admin-kpi-carte__label">Actions sur 7 jours</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['sept_jours'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--<?= $stats['echecs_24h'] > 5 ? 'rouge' : 'vert' ?>"><div class="admin-kpi-carte__icone">🔒</div><div class="admin-kpi-carte__label">Connexions échouées (24 h)</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['echecs_24h'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone">👤</div><div class="admin-kpi-carte__label">Acteurs distincts (7 j)</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['acteurs_7j'] ?></div></div>
        </div>

        <div class="filtres-tabs" style="margin-bottom:16px;">
            <?php foreach ($periodes as $cle => $libelle): ?>
                <a href="<?= htmlspecialchars(urlAudit(['periode' => $cle, 'page' => null])) ?>" class="filtre-tab <?= $periode === $cle ? 'filtre-tab--actif' : '' ?>"><?= $libelle ?></a>
            <?php endforeach; ?>
        </div>

        <form method="GET" class="audit-filtres">
            <input type="hidden" name="periode" value="<?= htmlspecialchars($periode) ?>">
            <input type="text" name="matricule" placeholder="Matricule (ex : EQ-00003)" value="<?= htmlspecialchars($matricule) ?>" style="width:190px;">
            <select name="acteur_type" onchange="this.form.submit()">
                <option value="">Tous les types d'acteurs</option>
                <?php foreach ($typesActeurs as $t): ?>
                    <option value="<?= htmlspecialchars($t) ?>" <?= $filtres['acteur_type'] === $t ? 'selected' : '' ?>><?= htmlspecialchars($libellesTypes[$t] ?? $t) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="categorie" onchange="this.form.submit()">
                <option value="">Toutes les actions</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>" <?= $filtres['categorie'] === $c ? 'selected' : '' ?>><?= htmlspecialchars(ucfirst($c)) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="q" placeholder="Rechercher (cible, détail, nom)..." value="<?= htmlspecialchars($filtres['q']) ?>" style="flex:1; min-width:200px;">
            <button type="submit">Filtrer</button>
            <?php if ($filtresActifs): ?><a href="?periode=<?= htmlspecialchars($periode) ?>" class="admin-recherche__reset" style="align-self:center;">Réinitialiser</a><?php endif; ?>
        </form>

        <?php if ($matricule): ?>
            <div class="bandeau-filtre">
                <span>Actions de <strong><?= htmlspecialchars($nomFiltre ?: $matricule) ?></strong> · <span class="matricule-badge"><?= htmlspecialchars($matricule) ?></span></span>
                <a href="<?= htmlspecialchars(urlAudit(['matricule' => null, 'page' => null])) ?>">Voir tout le monde ×</a>
            </div>
        <?php endif; ?>

        <div class="admin-panneau">
            <table class="admin-table">
                <tr><th>Date</th><th>Acteur</th><th>Action</th><th>Cible</th><th>Détail</th><th>IP</th></tr>
                <?php if (empty($evenements)): ?>
                    <tr><td colspan="6" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun événement sur cette période.</td></tr>
                <?php endif; ?>
                <?php foreach ($evenements as $e): ?>
                <tr class="<?= $e['action'] === 'connexion.echec' ? 'ligne-echec' : '' ?>">
                    <td style="white-space:nowrap; font-size:12.5px;"><?= date('d/m/Y', strtotime($e['date_creation'])) ?><br><span style="color:var(--admin-texte-discret);"><?= date('H:i:s', strtotime($e['date_creation'])) ?></span></td>
                    <td>
                        <?php if ($e['acteur_matricule']): ?>
                            <strong><?= htmlspecialchars($e['acteur_nom'] ?? '—') ?></strong><br>
                            <a href="<?= htmlspecialchars(urlAudit(['matricule' => $e['acteur_matricule'], 'page' => null])) ?>" class="matricule-badge" title="Voir toutes ses actions"><?= htmlspecialchars($e['acteur_matricule']) ?></a>
                            <span style="font-size:11.5px; color:var(--admin-texte-discret);"><?= htmlspecialchars($libellesTypes[$e['acteur_type']] ?? $e['acteur_type']) ?></span>
                        <?php else: ?>
                            <span style="color:var(--admin-texte-discret);"><?= htmlspecialchars($libellesTypes[$e['acteur_type']] ?? $e['acteur_type']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td><span class="admin-badge admin-badge--<?= couleurAction($e['action']) ?>"><?= htmlspecialchars($libellesActions[$e['action']] ?? $e['action']) ?></span></td>
                    <td class="audit-cible">
                        <?php if ($e['cible']): ?><a href="<?= htmlspecialchars(urlAudit(['q' => $e['cible'], 'page' => null])) ?>"><?= htmlspecialchars($e['cible']) ?></a><?php else: ?>—<?php endif; ?>
                    </td>
                    <td class="audit-detail"><?= $e['detail'] ? nl2br(htmlspecialchars($e['detail'])) : '—' ?></td>
                    <td style="font-size:12px; color:var(--admin-texte-discret);"><?= htmlspecialchars($e['ip'] ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
            </table>

            <div class="pagination-audit">
                <span><?= number_format($total, 0, ',', ' ') ?> événement<?= $total > 1 ? 's' : '' ?> · page <?= $page ?> / <?= $nbPages ?></span>
                <span style="display:flex; gap:8px;">
                    <?php if ($page > 1): ?><a href="<?= htmlspecialchars(urlAudit(['page' => $page - 1])) ?>">← Précédent</a><?php endif; ?>
                    <?php if ($page < $nbPages): ?><a href="<?= htmlspecialchars(urlAudit(['page' => $page + 1])) ?>">Suivant →</a><?php endif; ?>
                </span>
            </div>
        </div>
    </div>
</div>
</body>
</html>