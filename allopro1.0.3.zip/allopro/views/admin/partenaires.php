<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('partenaires');
require_once __DIR__ . '/../../models/Partenaire.php';

$partenaireModel = new Partenaire();
$recherche = trim($_GET['q'] ?? '');
$niveauFiltre = $_GET['niveau'] ?? '';
$partenaires = $partenaireModel->getAllAvecStats($recherche ?: null, $niveauFiltre ?: null);

$labelsNiveaux = ['partenaire' => ['Partenaire', 'gris'], 'certifie' => ['Certifié', 'violet'], 'premium' => ['Premium', 'amber'], 'excellence' => ['Excellence', 'vert']];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Partenaires — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Partenaires</div>
                <div class="admin-entete__sous-titre"><?= count($partenaires) ?> partenaire<?= count($partenaires) > 1 ? 's' : '' ?></div>
            </div>
        </div>

        <form method="GET" class="admin-recherche">
            <input type="text" name="q" placeholder="Rechercher par entreprise ou email..." value="<?= htmlspecialchars($recherche) ?>">
            <select name="niveau" onchange="this.form.submit()" style="padding:10px 14px; border:1px solid var(--admin-bordure); border-radius:8px; font-family:'Inter',sans-serif; font-size:14px;">
                <option value="">Tous les niveaux</option>
                <?php foreach ($labelsNiveaux as $val => $l): ?>
                    <option value="<?= $val ?>" <?= $niveauFiltre === $val ? 'selected' : '' ?>><?= $l[0] ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Rechercher</button>
            <?php if ($recherche || $niveauFiltre): ?><a href="partenaires.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau">
            <table class="admin-table">
                <tr><th>Entreprise</th><th>Zone</th><th>Techniciens</th><th>Missions</th><th>Score</th><th>Niveau</th><th>Statut</th><th></th></tr>
                <?php if (empty($partenaires)): ?>
                    <tr><td colspan="8" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun partenaire trouvé.</td></tr>
                <?php endif; ?>
                <?php foreach ($partenaires as $p): $niv = $labelsNiveaux[$p['niveau']] ?? ['—','gris']; ?>
                <tr>
                    <td><strong><?= htmlspecialchars($p['nom_entreprise']) ?></strong><br><span style="color:var(--admin-texte-discret); font-size:12px;"><?= htmlspecialchars($p['email']) ?></span></td>
                    <td><?= htmlspecialchars($p['zone_intervention'] ?: '—') ?></td>
                    <td><?= $p['nb_techniciens'] ?></td>
                    <td><?= $p['nb_missions'] ?> <?= $p['nb_missions_actives'] > 0 ? "<span style='color:var(--admin-amber); font-weight:600;'>({$p['nb_missions_actives']} en cours)</span>" : '' ?></td>
                    <td><?= $p['score'] > 0 ? number_format($p['score'], 1) . '/5' : '—' ?></td>
                    <td><span class="admin-badge admin-badge--<?= $niv[1] ?>"><?= $niv[0] ?></span></td>
                    <td><span class="admin-badge admin-badge--<?= $p['statut'] === 'actif' ? 'vert' : 'rouge' ?>"><?= $p['statut'] === 'actif' ? 'Actif' : 'Inactif' ?></span></td>
                    <td><a href="partenaire-detail.php?id=<?= $p['id'] ?>" style="color:var(--admin-violet); font-weight:600; text-decoration:none; font-size:13px;">Voir →</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>