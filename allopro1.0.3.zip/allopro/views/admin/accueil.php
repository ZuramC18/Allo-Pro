<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('tableau_bord');
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/TicketSav.php';

$demandeModel = new Demande();
$userModel = new User();
$partenaireModel = new Partenaire();
$paiementModel = new Paiement();
$ticketModel = new TicketSav();

$demandesAujourdhui = $demandeModel->compterAujourdhui();
$enCours = $demandeModel->compterEnCours();
$termineesAujourdhui = $demandeModel->compterTermineesAujourdhui();
$savOuverts = $ticketModel->compterOuverts();
$nouveauxClients = $userModel->compterNouveauxAujourdhui();
$partenairesActifs = $partenaireModel->compterActifs();
$caJour = $paiementModel->sommeAujourdhui();

$demandesRecentes = $demandeModel->getRecentes(6);
$libellesStatuts = ['nouvelle' => ['Nouvelle', 'violet'], 'attribuee' => ['Attribuée', 'amber'], 'en_cours' => ['En cours', 'amber'], 'terminee' => ['Terminée', 'vert'], 'annulee' => ['Annulée', 'gris']];
$joursFrancais = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
$moisFrancais = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
$maintenant = new DateTimeImmutable('now');
$dateFrancaise = $joursFrancais[(int) $maintenant->format('w')] . ' ' . $maintenant->format('j') . ' ' . $moisFrancais[(int) $maintenant->format('n')] . ' ' . $maintenant->format('Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tableau de bord — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Tableau de bord</div>
                <div class="admin-entete__sous-titre"><?= htmlspecialchars($dateFrancaise, ENT_QUOTES, 'UTF-8') ?></div>
            </div>
            <div class="admin-badge-role">
                <div class="admin-badge-role__avatar"><?= htmlspecialchars(strtoupper(mb_substr($_SESSION['nom'] ?? 'A', 0, 1))) ?></div>
                <?= htmlspecialchars($_SESSION['nom'] ?? 'Admin') ?>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <?php if (peut('interventions') || peut('demandes')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13.5V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5.5"/><path d="m16 10-4 4-4-4"/><path d="M12 14V3"/></svg></div><div class="admin-kpi-carte__label">Demandes aujourd'hui</div><div class="admin-kpi-carte__valeur"><?= $demandesAujourdhui ?></div></div>
            <?php endif; ?>
            <?php if (peut('interventions')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div><div class="admin-kpi-carte__label">Interventions en cours</div><div class="admin-kpi-carte__valeur"><?= $enCours ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/><circle cx="12" cy="12" r="9"/></svg></div><div class="admin-kpi-carte__label">Terminées aujourd'hui</div><div class="admin-kpi-carte__valeur"><?= $termineesAujourdhui ?></div></div>
            <?php endif; ?>
            <?php if (peut('sav')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--rouge"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13v-2a8 8 0 0 1 16 0v2"/><path d="M4 13H3a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h3v-6H4Zm16 0h1a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-3v-6h2Z"/><path d="M16 19a4 4 0 0 1-4 2h-1"/></svg></div><div class="admin-kpi-carte__label">Tickets SAV ouverts</div><div class="admin-kpi-carte__valeur"><?= $savOuverts ?></div></div>
            <?php endif; ?>
        </div>

        <div class="admin-kpi-grille">
            <?php if (peut('clients')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M3 21v-2a6 6 0 0 1 12 0v2"/><path d="M19 8v6m-3-3h6"/></svg></div><div class="admin-kpi-carte__label">Nouveaux clients</div><div class="admin-kpi-carte__valeur"><?= $nouveauxClients ?></div></div>
            <?php endif; ?>
            <?php if (peut('partenaires')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/><path d="M19 21V11l-6-4"/><path d="M8 9v.01M8 12v.01M8 15v.01M8 18v.01M16 14v.01M16 17v.01"/></svg></div><div class="admin-kpi-carte__label">Partenaires actifs</div><div class="admin-kpi-carte__valeur"><?= $partenairesActifs ?></div></div>
            <?php endif; ?>
            <?php if (peut('paiements')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg></div><div class="admin-kpi-carte__label">CA du jour</div><div class="admin-kpi-carte__valeur"><?= number_format($caJour, 0, ',', ' ') ?> F</div></div>
            <?php endif; ?>
            <?php if (peut('interventions')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m7 14 4-4 4 4 6-7"/></svg></div><div class="admin-kpi-carte__label">Total demandes</div><div class="admin-kpi-carte__valeur"><?= $demandeModel->compterParStatutGlobal()['toutes'] ?></div></div>
            <?php endif; ?>
        </div>

        <?php if (peut('interventions')): ?>
        <div class="admin-panneau">
            <div class="admin-panneau__titre">
                Demandes récentes
                <a href="interventions.php" class="admin-lien-voir-tout">Voir tout →</a>
            </div>
            <table class="admin-table">
                <tr><th>Dossier</th><th>Client</th><th>Catégorie</th><th>Statut</th><th>Date</th></tr>
                <?php foreach ($demandesRecentes as $d): $s = $libellesStatuts[$d['statut']] ?? ['—', 'gris']; ?>
                <tr>
                    <td><strong><?= htmlspecialchars($d['numero_dossier']) ?></strong></td>
                    <td><?= htmlspecialchars($d['client_nom']) ?></td>
                    <td><?= htmlspecialchars($d['categorie_nom']) ?></td>
                    <td><span class="admin-badge admin-badge--<?= $s[1] ?>"><?= $s[0] ?></span></td>
                    <td><?= date('d/m H:i', strtotime($d['date_creation'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>

    </div>
</div>
</body>
</html>