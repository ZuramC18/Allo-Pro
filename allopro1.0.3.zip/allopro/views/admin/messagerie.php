<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('messagerie');
require_once __DIR__ . '/../../models/Message.php';
require_once __DIR__ . '/../../models/NoteInterne.php';
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/ReponseRapide.php';
require_once __DIR__ . '/../../models/User.php';

// Échappement HTML sûr (accepte null)
if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

// --- CSRF minimal (la session est déjà démarrée par auth.php) ---
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function csrfValide(): bool {
    return isset($_POST['csrf']) && hash_equals($_SESSION['csrf'], (string) $_POST['csrf']);
}

$messageModel     = new Message();
$userModel        = new User();
$noteInterneModel = new NoteInterne();

$estCoordinateurOuAdmin = in_array($_SESSION['role'], ['coordinateur', 'admin'], true);
$userId = (int) $_SESSION['user_id'];

// --- Réaffectation (coordinateur/admin uniquement), avant le calcul de la liste ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reassigner_conseiller_id']) && $estCoordinateurOuAdmin) {
    if (!csrfValide()) {
        http_response_code(403);
        die('Requête invalide.');
    }
    $cibleClientId = filter_var($_POST['client_id'] ?? null, FILTER_VALIDATE_INT) ?: null;
    $nouveauId     = filter_var($_POST['reassigner_conseiller_id'], FILTER_VALIDATE_INT) ?: null; // "" => null

    if ($cibleClientId) {
        $userModel->reassignerConseiller($cibleClientId, $nouveauId);
        journaliser(
            'conversation.reassignee', 'compte', $cibleClientId, null,
            $nouveauId ? 'Nouveau conseiller : ID ' . $nouveauId : 'Conversation désaffectée'
        );
    }
    header('Location: messagerie.php' . ($cibleClientId ? '?client_id=' . $cibleClientId : ''));
    exit;
}

// --- Liste filtrée par rôle : elle fait office de contrôle d'accès ---
$conversations = $_SESSION['role'] === 'conseiller'
    ? $messageModel->getConversationsPourConseiller($_SESSION['user_id'])
    : $messageModel->getConversationsToutes(); // garde l'ancienne méthode telle quelle pour l'admin

// Aucune conversation n'est ouverte automatiquement (évite de marquer comme lu au rechargement)
$clientId = filter_var($_GET['client_id'] ?? null, FILTER_VALIDATE_INT) ?: null;

$clientActif = null;
if ($clientId) {
    foreach ($conversations as $conv) {
        if ((int) $conv['id'] === $clientId) { $clientActif = $conv; break; }
    }
    if (!$clientActif) {
        $clientCible = $userModel->getById($clientId);
        $roleCourant = $_SESSION['role'] ?? '';
        $estGestionnaire = in_array($roleCourant, ['admin', 'coordinateur'], true);
        $estConseillerAutorise = $roleCourant === 'conseiller'
            && $clientCible
            && ($clientCible['conseiller_assigne_id'] === null
                || (int) $clientCible['conseiller_assigne_id'] === $userId);

        if ($clientCible
            && ($clientCible['role'] ?? '') === 'client'
            && ($clientCible['statut'] ?? '') === 'actif'
            && ($estGestionnaire || $estConseillerAutorise)) {
            $clientActif = [
                'id' => (int) $clientCible['id'],
                'prenom' => $clientCible['prenom'],
                'nom' => $clientCible['nom'],
                'nom_complet' => trim((string) ($clientCible['prenom'] ?? '') . ' ' . (string) ($clientCible['nom'] ?? '')),
                'telephone' => $clientCible['telephone'],
                'email' => $clientCible['email'],
                'conversation_statut' => $clientCible['conversation_statut'] ?? 'ouverte',
                'conseiller_assigne_id' => $clientCible['conseiller_assigne_id'] ?? null,
                'conseiller_nom' => null,
                'conseiller_matricule' => null,
                'dernier_message' => null,
                'derniere_date' => null,
                'non_lus' => 0,
            ];
            array_unshift($conversations, $clientActif);
        }
    }
    if (!$clientActif) { $clientId = null; }
}

// --- Ajout d'une note interne ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note_interne'])) {
    if (!csrfValide()) {
        http_response_code(403);
        die('Requête invalide.');
    }
    $contenuNote = trim($_POST['note_interne']);
    if ($clientActif && $contenuNote !== '') {
        $noteInterneModel->create($clientId, $userId, mb_substr($contenuNote, 0, 2000));
    }
    header('Location: messagerie.php' . ($clientId ? '?client_id=' . $clientId . '#notes' : ''));
    exit;
}

$conseillersActifs = $estCoordinateurOuAdmin ? $userModel->getConseillersActifsAvecCharge() : [];

$messages       = [];
$notesInternes  = [];
$dossiersClient = [];

if ($clientActif) {
    $messages = $messageModel->getByClient($clientId);

    // Seul le conseiller marque comme lu : un admin qui consulte ne vide pas ses notifications
    if (!$estCoordinateurOuAdmin) {
        $messageModel->marquerLues($clientId, 'conseiller');
    }

    $notesInternes  = $noteInterneModel->getByClient($clientId);
    $dossiersClient = (new Demande())->getByClient($clientId);
}

$conversationOuverte = $clientActif && (($clientActif['conversation_statut'] ?? 'ouverte') === 'ouverte');
$roleCourant = $_SESSION['role'] ?? '';
$estAdminCoord = in_array($roleCourant, ['admin', 'coordinateur'], true);
$estConseillerProprietaire = $roleCourant === 'conseiller'
    && (int) ($clientActif['conseiller_assigne_id'] ?? 0) === $userId;
$peutGererConversation = $clientActif && (
    ($conversationOuverte && !empty($clientActif['conseiller_assigne_id']) && ($estAdminCoord || $estConseillerProprietaire))
    || (!$conversationOuverte && ($estAdminCoord || $estConseillerProprietaire || ($roleCourant === 'conseiller' && empty($clientActif['conseiller_assigne_id']))))
);

// Toujours une liste indexée 0..n (sinon json_encode produit un objet)
$reponsesRapides = array_values((array) ((new ReponseRapide())->getAll() ?: []));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messages — ALLÔ PRO Conseiller</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/messagerie.css?v=<?= filemtime(__DIR__ . '/../../public/css/messagerie.css') ?>">
    <link rel="stylesheet" href="../../public/css/messagerie-options.css?v=<?= filemtime(__DIR__ . '/../../public/css/messagerie-options.css') ?>">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="messagerie-conseiller<?= $clientActif ? ' a-conversation' : '' ?>">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="mc-contenu">
        <div class="messagerie">

            <!-- ===== Liste des conversations ===== -->
            <div class="conv-liste" id="conv-liste" aria-label="Liste des conversations">
                <div class="conv-liste__entete">Conversations</div>
                <?php if (empty($conversations)): ?>
                    <p class="conv-liste__vide">Aucune conversation pour le moment.</p>
                <?php endif; ?>

                <?php foreach ($conversations as $conv): ?>
                    <?php $nomConversation = trim((string) ($conv['nom_complet'] ?? '')) ?: (string) ($conv['nom'] ?? 'Client'); ?>
                          <a href="messagerie.php?client_id=<?= (int) $conv['id'] ?>"
                              class="conv-item <?= (int) $conv['id'] === (int) $clientId ? 'conv-item--active' : '' ?> <?= ($conv['conversation_statut'] ?? '') === 'fermee' ? 'conv-item--fermee' : '' ?>">
                        <div class="conv-item__avatar"><?= h(strtoupper(mb_substr($nomConversation, 0, 1))) ?></div>
                        <div class="conv-item__contenu">
                            <div class="conv-item__haut">
                                <span class="conv-item__nom"><?= h($nomConversation) ?></span>
                                <?php if (!empty($conv['derniere_date'])): ?>
                                    <span class="conv-item__date"><?= h(tempsRelatifConversation($conv['derniere_date'])) ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="conv-item__apercu">
                                <?= !empty($conv['dernier_message']) ? h($conv['dernier_message']) : '<em>Aucun message</em>' ?>
                            </div>
                            <?php if (($conv['conversation_statut'] ?? '') === 'fermee'): ?>
                                <span class="conv-item__etat"><?= empty($conv['conseiller_assigne_id']) ? 'Fermée · À reprendre' : 'Conversation fermée' ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ((int) $conv['non_lus'] > 0): ?>
                            <span class="conv-item__badge"><?= (int) $conv['non_lus'] ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>

            <?php if ($clientActif): ?>

                <!-- ===== Fil de discussion ===== -->
                <div class="fil">
                    <div class="fil__entete fil__entete--espace">
                        <div class="fil__entete-groupe">
                            <button type="button" class="fil__retour" aria-label="Retour aux conversations" title="Retour aux conversations">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/><path d="M9 12h12"/></svg>
                            </button>
                            <?php $nomClientActif = trim((string) ($clientActif['nom_complet'] ?? '')) ?: trim((string) ($clientActif['prenom'] ?? '') . ' ' . (string) ($clientActif['nom'] ?? '')); ?>
                            <?php $nomClientActif = $nomClientActif !== '' ? $nomClientActif : (string) ($clientActif['nom'] ?? 'Client'); ?>
                            <div class="fil__entete-avatar"><?= h(strtoupper(mb_substr($nomClientActif, 0, 1))) ?></div>
                            <div class="fil__titre"><?= h($nomClientActif) ?></div>
                            <?php if ($peutGererConversation): ?>
                                <div class="conversation-options">
                                    <button type="button" class="conversation-options__toggle" id="btn-options-conversation" aria-label="Options de la conversation" aria-haspopup="menu" aria-expanded="false" aria-controls="menu-options-conversation" title="Options de la conversation">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>
                                    </button>
                                    <div class="conversation-options__menu" id="menu-options-conversation" role="menu" hidden>
                                        <button type="button" id="btn-action-conversation" role="menuitem" class="<?= $conversationOuverte ? '' : 'conversation-options__action--reouvrir' ?>" data-action="<?= $conversationOuverte ? 'fermer_conversation' : 'reouvrir_conversation' ?>" data-client-id="<?= (int) $clientId ?>" data-conseiller-id="<?= (int) ($clientActif['conseiller_assigne_id'] ?? ($roleCourant === 'conseiller' ? $userId : 0)) ?>" data-csrf="<?= h($_SESSION['csrf']) ?>">
                                            <?php if ($conversationOuverte): ?>
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m19 6-1 14H6L5 6"/><path d="M10 11v5M14 11v5"/></svg>
                                                <span>Clôturer la conversation</span>
                                            <?php else: ?>
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 2.64-6.36L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/></svg>
                                                <span>Réouvrir la conversation</span>
                                            <?php endif; ?>
                                        </button>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if ($estCoordinateurOuAdmin): ?>
                            <form method="POST" class="form-reaffectation">
                                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
                                <input type="hidden" name="client_id" value="<?= (int) $clientId ?>">
                                <select name="reassigner_conseiller_id" onchange="this.form.submit()" class="select-reaffectation"
                                        aria-label="Réaffecter la conversation">
                                    <option value="">— Non affectée —</option>
                                    <?php foreach ($conseillersActifs as $cons): ?>
                                        <option value="<?= (int) $cons['id'] ?>"
                                            <?= (int) ($clientActif['conseiller_assigne_id'] ?? 0) === (int) $cons['id'] ? 'selected' : '' ?>>
                                            <?= h($cons['nom']) ?> (<?= (int) $cons['nb_clients'] ?> client<?= (int) $cons['nb_clients'] > 1 ? 's' : '' ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </form>
                        <?php endif; ?>
                    </div>

                    <div class="fil__corps" id="fil-corps" role="log" aria-live="polite" aria-label="Messages de la conversation"
                         data-retour="messagerie.php"
                         data-client-id="<?= (int) $clientId ?>"
                         data-viewer="conseiller"
                         data-viewer-id="<?= $userId ?>"
                         data-csrf="<?= h($_SESSION['csrf']) ?>"
                         data-can-disable-client="<?= ($_SESSION['role'] ?? '') === 'admin' ? '1' : '0' ?>">
                        <?php $jourPrecedent = null; ?>
                        <?php foreach ($messages as $m): ?>
                            <?php $jourCourant = date('Y-m-d', strtotime($m['date_creation'])); ?>
                            <?php if ($jourCourant !== $jourPrecedent): ?>
                                <div class="fil__separateur-jour"><span><?= h(libelleJourConversation($m['date_creation'])) ?></span></div>
                                <?php $jourPrecedent = $jourCourant; ?>
                            <?php endif; ?>
                            <div class="bulle <?= $m['expediteur_type'] === 'conseiller' ? 'bulle--moi' : 'bulle--autre' ?>"
                                 data-id="<?= (int) $m['id'] ?>"
                                 data-jour="<?= h($jourCourant) ?>"
                                 data-expediteur-type="<?= h($m['expediteur_type']) ?>"
                                 data-expediteur-id="<?= (int) $m['expediteur_id'] ?>"
                                 data-lu="<?= (int) $m['lu'] ?>"
                                 data-lu-date="<?= h($m['lu_date'] ?? '') ?>"
                                 data-modifie="<?= (int) $m['modifie'] ?>">
                                <div class="bulle__meta">
                                    <?= h($m['nom_expediteur'] ?? ucfirst($m['expediteur_type'])) ?> · <?= h(date('H:i', strtotime($m['date_creation']))) ?>
                                    <?= !empty($m['modifie']) ? ' · <span class="bulle__modifie">modifié</span>' : '' ?>
                                </div>
                                <?php if (!empty($m['image_path'])): ?>
                                    <a class="bulle__piece-jointe" href="../../public/<?= h($m['image_path']) ?>" target="_blank" rel="noopener">
                                        <img class="bulle__image" src="../../public/<?= h($m['image_path']) ?>" alt="Image jointe au message" loading="lazy">
                                    </a>
                                <?php endif; ?>
                                <?php if (!empty($m['audio_path'])): ?>
                                    <audio class="bulle__audio" controls preload="metadata" aria-label="Lire la note vocale" title="Note vocale" src="../../public/<?= h($m['audio_path']) ?>"></audio>
                                <?php endif; ?>
                                <?php if (trim((string) $m['contenu']) !== ''): ?><div class="bulle__texte"><?= nl2br(h($m['contenu'])) ?></div><?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($conversationOuverte): ?>
                        <div class="suggestions-rr" id="suggestions-rr"></div>
                        <div class="fil__pied">
                            <div class="composer__image-apercu" id="apercu-image" hidden>
                                <img id="apercu-image-img" alt="Aperçu de l’image jointe">
                                <span id="apercu-image-nom"></span>
                                <button type="button" id="retirer-image" aria-label="Retirer l’image jointe" title="Retirer l’image">×</button>
                            </div>
                            <div class="composer__voice-apercu" id="apercu-voice" hidden>
                                <div class="composer__voice-meta">
                                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a3 3 0 0 1 3 3v6a3 3 0 1 1-6 0V6a3 3 0 0 1 3-3Z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v3"/><path d="M8 21h8"/></svg>
                                    <span id="apercu-voice-nom" aria-live="polite">Note vocale</span>
                                    <span id="apercu-voice-duree" class="composer__voice-duree" aria-label="Durée">00:00</span>
                                </div>
                                <audio id="apercu-voice-audio" controls preload="metadata"></audio>
                                <button type="button" id="retirer-voice" aria-label="Retirer la note vocale" title="Retirer">×</button>
                            </div>
                            <div class="composer">
                                <div class="composer__media-wrap">
                                    <button type="button" id="btn-plus-media" class="composer__plus" aria-label="Ajouter un média" title="Ajouter une image ou une note vocale">
                                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
                                    </button>
                                    <div class="composer__media-actions" id="media-actions" hidden>
                                        <label class="composer__joindre" title="Joindre une image">
                                            <input type="file" id="champ-image" class="composer__image-input" accept="image/jpeg,image/png,image/webp" aria-label="Choisir une image à joindre">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h13A2.5 2.5 0 0 1 21 7.5v9A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5v-9Z"/><path d="M8.5 14.5 11 12l2.5 3 2.5-3 3 4.5"/><circle cx="9" cy="9" r="1.5"/></svg>
                                        </label>
                                        <button type="button" id="btn-enregistrer-audio" class="composer__btn-voice" aria-label="Enregistrer une note vocale" title="Note vocale">
                                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a3 3 0 0 1 3 3v6a3 3 0 1 1-6 0V6a3 3 0 0 1 3-3Z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v3"/><path d="M8 21h8"/></svg>
                                        </button>
                                    </div>
                                </div>
                                <div class="composer__champ-wrap">
                                    <textarea id="champ-message" rows="1" maxlength="2000" placeholder="Écrire un message..."
                                              aria-label="Votre message" autocomplete="off" enterkeyhint="send"></textarea>
                                    <span class="composer__placeholder" aria-hidden="true">Écrire un message...</span>
                                </div>
                                <span class="composer__compteur" id="compteur-message" aria-live="polite" hidden></span>
                                <button type="button" id="btn-envoyer" aria-label="Envoyer le message" title="Envoyer (Entrée)">➤</button>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="fil__fermee">Conversation clôturée — le client, le conseiller ou l’admin peut la réouvrir.</div>
                    <?php endif; ?>
                </div>

                <!-- ===== Réponses rapides ===== -->
                <aside class="reponses-rapides" id="reponses-rapides" aria-label="Réponses rapides">
                    <div class="reponses-rapides__titre">
                        <span>Réponses rapides</span>
                        <button type="button" class="reponses-rapides__ajouter" id="rr-ouvrir-creation"
                                title="Ajouter une réponse rapide" aria-label="Ajouter une réponse rapide">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
                        </button>
                    </div>
                    <div id="rr-liste"></div>
                </aside>

                <!-- ===== Informations du client ===== -->
                <aside class="info-client" data-fiche-client aria-label="Informations du client">
                    <div class="info-client__avatar"><?= h(strtoupper(mb_substr($nomClientActif, 0, 1))) ?></div>
                    <div class="info-client__nom"><?= h($nomClientActif) ?></div>
                    <span class="badge badge-padding badge--<?= $conversationOuverte ? 'terminee' : 'annulee' ?> info-client__statut">
                        <?= $conversationOuverte ? 'Conversation ouverte' : 'Conversation fermée' ?>
                    </span>

                    <div class="info-client-all">
                        <div class="info-client__section">
                            <div class="info-client__label">Téléphone</div>
                            <div class="info-client__valeur"><?= h($clientActif['telephone'] ?? '') ?: '—' ?></div>
                        </div>

                        <div class="info-client__section">
                            <div class="info-client__label">Email</div>
                            <div class="info-client__valeur"><?= h($clientActif['email'] ?? '') ?: '—' ?></div>
                        </div>

                        <div class="info-client__section">
                            <div class="info-client__label">Dossiers (<?= count($dossiersClient) ?>)</div>
                            <div class="dossiers-liste">
                                <?php if (empty($dossiersClient)): ?>
                                    <p class="info-client__vide">Aucun dossier.</p>
                                <?php endif; ?>
                                <?php foreach ($dossiersClient as $d): ?>
                                    <a href="traiter-demande.php?id=<?= (int) $d['id'] ?>" class="info-client__dossier">
                                        <span><?= h($d['numero_dossier']) ?></span>
                                        <span class="badge badge--petit badge--<?= h($d['statut']) ?>"><?= h($d['statut']) ?></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="info-client__section" id="notes">
                            <div class="info-client__label">Notes internes</div>

                            <form method="POST" class="note-form">
                                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
                                <textarea name="note_interne" rows="2" maxlength="2000" required class="note-form__champ"
                                          aria-label="Nouvelle note interne"
                                          placeholder="Ajouter une note (visible par l'équipe uniquement)..."></textarea>
                                <button type="submit" class="bouton bouton--secondaire note-form__bouton">Ajouter la note</button>
                            </form>

                            <div class="notes-liste">
                                <?php if (empty($notesInternes)): ?>
                                    <p class="info-client__vide info-client__vide--petit">Aucune note pour ce client.</p>
                                <?php endif; ?>
                                <?php foreach ($notesInternes as $n): ?>
                                    <div class="note-interne">
                                        <div class="note-interne__meta"><?= h($n['conseiller_nom']) ?> · <?= h(date('d/m/Y H:i', strtotime($n['date_creation']))) ?></div>
                                        <div class="note-interne__texte"><?= nl2br(h($n['contenu'])) ?></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </aside>

            <?php else: ?>
                <div class="conv-vide">Sélectionnez une conversation</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Menu contextuel (clic droit / appui long sur un message) -->
<div class="menu-contextuel" id="menu-contextuel" role="menu" hidden>
    <button type="button" role="menuitem" class="menu-contextuel__item" id="btn-copier">Copier le texte</button>
    <button type="button" role="menuitem" class="menu-contextuel__item menu-contextuel__item--danger" id="btn-desactiver-client" hidden>Désactiver ce client</button>
</div>

<!-- Modale : créer / modifier une réponse rapide -->
<div class="rr-modale-fond" id="rr-modale-fond">
    <div class="rr-modale" role="dialog" aria-modal="true" aria-labelledby="rr-modale-titre">
        <h3 id="rr-modale-titre">Nouvelle réponse rapide</h3>
        <input type="hidden" id="rr-id">

        <label for="rr-champ-titre">Titre</label>
        <input type="text" id="rr-champ-titre" maxlength="100" placeholder="ex : Salutation standard" autocomplete="off">

        <label for="rr-champ-categorie">Catégorie</label>
        <input type="text" id="rr-champ-categorie" maxlength="60" list="rr-categories" placeholder="ex : Salutations" autocomplete="off">
        <datalist id="rr-categories"></datalist>

        <label for="rr-champ-mots-cles">Mots-clés déclencheurs <small>(séparés par des virgules)</small></label>
        <input type="text" id="rr-champ-mots-cles" maxlength="255" placeholder="ex : salutation, salut, bonjour" autocomplete="off">

        <label for="rr-champ-contenu">Message</label>
        <textarea id="rr-champ-contenu" rows="5" maxlength="2000" placeholder="Le texte qui sera inséré dans votre message"></textarea>

        <p class="rr-modale__erreur" id="rr-erreur" role="alert" hidden></p>

        <div class="rr-modale__actions">
            <button type="button" class="rr-modale__supprimer" id="rr-supprimer" hidden>Supprimer</button>
            <span class="rr-modale__espace"></span>
            <button type="button" class="rr-modale__annuler" id="rr-annuler">Annuler</button>
            <button type="button" class="rr-modale__valider" id="rr-valider">Enregistrer</button>
        </div>
    </div>
</div>

<!-- Les données doivent être définies AVANT les scripts qui les utilisent -->
<script>
    const REPONSES_RAPIDES = <?= json_encode($reponsesRapides, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP) ?: '[]' ?>;
    const RR_CONTEXTE = {
        userId: <?= $userId ?>,
        gestionnaire: <?= $estCoordinateurOuAdmin ? 'true' : 'false' ?>,
        csrf: <?= json_encode($_SESSION['csrf']) ?>
    };
</script>
<script src="../../public/js/messagerie-adm.js?v=<?= filemtime(__DIR__ . '/../../public/js/messagerie-adm.js') ?>"></script>
<script src="../../public/js/messagerie-options.js?v=<?= filemtime(__DIR__ . '/../../public/js/messagerie-options.js') ?>"></script>
</body>
</html>