<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Reversement.php';

$partenaireId = $_GET['partenaire_id'] ?? null;
if (!$partenaireId) { header("Location: paiements.php"); exit; }

$partenaireModel = new Partenaire();
$partenaire = $partenaireModel->getById($partenaireId);
if (!$partenaire) { die("Partenaire introuvable."); }

$reversementModel = new Reversement();
$missionsDues = $reversementModel->getMissionsDuesParPartenaire($partenaireId);
$erreur = '';
if (empty($_SESSION['csrf_reversement'])) {
    $_SESSION['csrf_reversement'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_reversement'], (string) ($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        $erreur = 'La session a expiré. Rechargez la page puis réessayez.';
    } elseif (empty($missionsDues)) {
        $erreur = 'Aucune intervention n’est actuellement disponible pour ce partenaire.';
    } else {
        try {
            $idCree = $reversementModel->create($partenaireId, $missionsDues);
            journaliser('reversement.cree', 'reversement', $idCree, $partenaire['nom_entreprise'] . ' (' . $partenaire['matricule'] . ')',
                count($missionsDues) . ' intervention(s), reversé : ' . number_format(array_sum(array_column($missionsDues, 'montant_partenaire')), 0, ',', ' ') . ' F');
            header("Location: reversement-detail.php?id=" . $idCree);
            exit;
        } catch (Throwable $e) {
            error_log('Création de reversement échouée : ' . $e->getMessage());
            http_response_code(409);
            $erreur = $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Le reversement n’a pas pu être créé. Vérifiez les données et réessayez.';
            $missionsDues = $reversementModel->getMissionsDuesParPartenaire($partenaireId);
        }
    }
}

require_once __DIR__ . '/../../models/Parametre.php';
$montantTotalPaiements = array_sum(array_column($missionsDues, 'montant'));
$margeTotale = array_sum(array_column($missionsDues, 'marge_allopro'));
$montantPourPartenaire = array_sum(array_column($missionsDues, 'montant_partenaire'));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Créer un reversement — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="paiements.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour aux paiements</a>
                <div class="admin-entete__titre" style="margin-top:6px;">Reversement — <?= htmlspecialchars($partenaire['nom_entreprise']) ?></div>
            </div>
        </div>

        <?php if ($erreur): ?>
            <div role="alert" style="margin-bottom:16px; padding:12px 15px; color:#991B1B; background:#FEF2F2; border:1px solid #FECACA; border-radius:8px;"><?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <?php if (empty($missionsDues)): ?>
            <div class="admin-panneau">
                <p style="color:var(--admin-texte-discret);">Aucune mission en attente de reversement pour ce partenaire.</p>
            </div>
        <?php else: ?>
            <div class="admin-panneau">
                <div class="admin-panneau__titre"><?= count($missionsDues) ?> mission(s) à reverser</div>
                <table class="admin-table">
                    <tr><th>Dossier</th><th>Origine</th><th>Base répartie</th><th>Commission ALLÔ PRO</th><th>Versé au partenaire</th></tr>
                    <?php foreach ($missionsDues as $m): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($m['numero_dossier']) ?></strong></td>
                        <td><?= $m['mode_paiement'] === 'pass' ? 'Pass' : ($m['mode_paiement'] === 'abonnement' ? 'Abonnement · 1 crédit' : 'Paiement direct') ?></td>
                        <td><?= number_format($m['montant'], 0, ',', ' ') ?> F</td>
                        <td style="color:var(--admin-violet);"><?= number_format($m['marge_allopro'], 0, ',', ' ') ?> F (<?= number_format($m['taux_commission'], 1, ',', ' ') ?> %)</td>
                        <td><?= number_format($m['montant_partenaire'], 0, ',', ' ') ?> F</td>
                    </tr>
                    <?php endforeach; ?>
                </table>

                <div style="display:flex; justify-content:space-between; padding-top:16px; margin-top:10px; border-top:2px solid var(--admin-bordure);">
                    <div><span style="color:var(--admin-texte-discret); font-size:13px;">Total encaissé</span><br><strong style="font-size:18px;"><?= number_format($montantTotalPaiements, 0, ',', ' ') ?> F</strong></div>
                    <div><span style="color:var(--admin-texte-discret); font-size:13px;">Marge ALLÔ PRO</span><br><strong style="font-size:18px; color:var(--admin-violet);"><?= number_format($margeTotale, 0, ',', ' ') ?> F</strong></div>
                    <div><span style="color:var(--admin-texte-discret); font-size:13px;">À reverser au partenaire</span><br><strong style="font-size:18px; color:var(--admin-vert);"><?= number_format($montantPourPartenaire, 0, ',', ' ') ?> F</strong></div>
                </div>
            </div>

            <form method="POST" onsubmit="return confirm('Confirmer la création de ce reversement de <?= number_format($montantPourPartenaire, 0, ',', ' ') ?> F (commission ALLÔ PRO : <?= number_format($margeTotale, 0, ',', ' ') ?> F) ?');">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_reversement'], ENT_QUOTES, 'UTF-8') ?>">
                <button type="submit" style="padding:13px 28px; background:var(--admin-violet); color:white; border:none; border-radius:8px; font-weight:700; cursor:pointer; margin-top:16px;">
                    Confirmer le reversement
                </button>
            </form>

        <?php endif; ?>
    </div>
</div>
</body>
</html>