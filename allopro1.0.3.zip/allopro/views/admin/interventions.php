<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('interventions');
require_once __DIR__ . '/../../models/Demande.php';

$demandeModel = new Demande();
$recherche = trim($_GET['q'] ?? '');
$statutFiltre = $_GET['statut'] ?? '';
$urgenceFiltre = $_GET['urgence'] ?? '';

$demandes = $demandeModel->getAllAvecFiltres($recherche ?: null, $statutFiltre ?: null, $urgenceFiltre ?: null);
$compteurs = $demandeModel->compterParStatutGlobal();

$labelsStatuts = ['nouvelle' => ['Nouvelle', 'violet'], 'attribuee' => ['Attribuée', 'amber'], 'en_cours' => ['En cours', 'amber'], 'terminee' => ['Terminée', 'vert'], 'annulee' => ['Annulée', 'gris']];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Interventions — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Interventions</div>
                <div class="admin-entete__sous-titre">Vue d'ensemble de tous les dossiers</div>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone">📋</div><div class="admin-kpi-carte__label">Total</div><div class="admin-kpi-carte__valeur"><?= $compteurs['toutes'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone">🆕</div><div class="admin-kpi-carte__label">Nouvelles</div><div class="admin-kpi-carte__valeur"><?= $compteurs['nouvelle'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone">⏳</div><div class="admin-kpi-carte__label">En cours</div><div class="admin-kpi-carte__valeur"><?= $compteurs['attribuee'] + $compteurs['en_cours'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone">✓</div><div class="admin-kpi-carte__label">Terminées</div><div class="admin-kpi-carte__valeur"><?= $compteurs['terminee'] ?></div></div>
        </div>

        <form method="GET" class="admin-recherche">
            <input type="text" name="q" placeholder="Numéro de dossier ou nom du client..." value="<?= htmlspecialchars($recherche) ?>">
            <select name="statut" onchange="this.form.submit()" style="padding:10px 14px; border:1px solid var(--admin-bordure); border-radius:8px; font-size:14px;">
                <option value="">Tous les statuts</option>
                <?php foreach ($labelsStatuts as $val => $l): ?>
                    <option value="<?= $val ?>" <?= $statutFiltre === $val ? 'selected' : '' ?>><?= $l[0] ?></option>
                <?php endforeach; ?>
            </select>
            <select name="urgence" onchange="this.form.submit()" style="padding:10px 14px; border:1px solid var(--admin-bordure); border-radius:8px; font-size:14px;">
                <option value="">Urgence : toutes</option>
                <option value="urgente" <?= $urgenceFiltre === 'urgente' ? 'selected' : '' ?>>Urgente</option>
                <option value="normale" <?= $urgenceFiltre === 'normale' ? 'selected' : '' ?>>Normale</option>
            </select>
            <button type="submit">Filtrer</button>
            <?php if ($recherche || $statutFiltre || $urgenceFiltre): ?><a href="interventions.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau">
            <table class="admin-table">
                <tr><th>Dossier</th><th>Client</th><th>Catégorie</th><th>Partenaire</th><th>Technicien</th><th>Urgence</th><th>Statut</th><th>Date</th></tr>
                <?php if (empty($demandes)): ?>
                    <tr><td colspan="8" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun résultat.</td></tr>
                <?php endif; ?>
                <?php foreach ($demandes as $d): $s = $labelsStatuts[$d['statut']] ?? ['—','gris']; ?>
                <tr>
                    <td><strong><?= htmlspecialchars($d['numero_dossier']) ?></strong></td>
                    <td><?= htmlspecialchars($d['client_nom']) ?></td>
                    <td><?= htmlspecialchars($d['categorie_nom']) ?></td>
                    <td><?= htmlspecialchars($d['nom_entreprise'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($d['technicien_nom'] ?? '—') ?></td>
                    <td><span class="admin-badge admin-badge--<?= $d['urgence'] === 'urgente' ? 'rouge' : 'gris' ?>"><?= htmlspecialchars($d['urgence']) ?></span></td>
                    <td><span class="admin-badge admin-badge--<?= $s[1] ?>"><?= $s[0] ?></span></td>
                    <td><?= date('d/m/Y', strtotime($d['date_creation'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>