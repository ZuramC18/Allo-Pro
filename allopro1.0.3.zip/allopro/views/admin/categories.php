<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('categories');
require_once __DIR__ . '/../../models/Categorie.php';

$categorieModel = new Categorie();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['creer_pole'])) {
        $categorieModel->create(trim($_POST['nom_pole']), null);
    } elseif (isset($_POST['creer_sous_categorie'])) {
        $categorieModel->create(trim($_POST['nom_sous_categorie']), $_POST['parent_id'], $_POST['tarif_base'] ?: null);
    } elseif (isset($_POST['toggle_statut'])) {
        $cat = $categorieModel->getById($_POST['categorie_id']);
        $categorieModel->changerStatut($_POST['categorie_id'], $cat['statut'] === 'active' ? 'inactive' : 'active');
    }
    header("Location: categories.php");
    exit;
}

$poles = $categorieModel->getParentes();
$sousCategories = $categorieModel->getSousCategories();

// Regroupe les sous-catégories par pôle pour l'affichage
$sousParPole = [];
foreach ($sousCategories as $sc) {
    $sousParPole[$sc['parent_id']][] = $sc;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Catégories — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .pole-carte { margin-bottom: 20px; }
        .pole-carte__entete { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .pole-carte__nom { font-family:'Space Grotesk',sans-serif; font-weight: 700; font-size: 15px; }
        .sous-cat-ligne { display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; background: var(--admin-fond-ligne, #FAFAFB); border-radius: 8px; margin-bottom: 6px; font-size: 13.5px; }
        .sous-cat-ligne--inactive { opacity: 0.5; }
        .form-inline-admin { display: flex; gap: 10px; align-items: flex-end; flex-wrap: wrap; }
        .form-inline-admin label { display: block; font-size: 12px; font-weight: 600; color: var(--admin-texte-discret); margin-bottom: 4px; }
        .form-inline-admin input, .form-inline-admin select { padding: 9px 12px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-size: 13.5px; }
    </style>
</head>
<body class="page-categories">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Catégories & Tarifs</div>
                <div class="admin-entete__sous-titre">Pôles de service, sous-catégories et tarifs de base</div>
            </div>
        </div>

        <div style="display:grid; grid-template-columns:2fr 1fr; gap:20px; align-items:start;">
            <div>
                <?php foreach ($poles as $pole): ?>
                <div class="admin-panneau pole-carte">
                    <div class="pole-carte__entete">
                        <div class="pole-carte__nom">🗂️ <?= htmlspecialchars($pole['nom']) ?></div>
                        <span class="admin-badge admin-badge--gris"><?= count($sousParPole[$pole['id']] ?? []) ?> sous-catégorie(s)</span>
                    </div>

                    <?php foreach ($sousParPole[$pole['id']] ?? [] as $sc): ?>
                        <div class="sous-cat-ligne <?= $sc['statut'] === 'inactive' ? 'sous-cat-ligne--inactive' : '' ?>">
                            <span><?= htmlspecialchars($sc['nom']) ?></span>
                            <span style="display:flex; align-items:center; gap:14px;">
                                <span style="color:var(--admin-texte-discret);"><?= $sc['tarif_base'] ? number_format($sc['tarif_base'], 0, ',', ' ') . ' F' : 'Tarif non défini' ?></span>
                                <span class="admin-badge admin-badge--<?= $sc['statut'] === 'active' ? 'vert' : 'rouge' ?>"><?= $sc['statut'] === 'active' ? 'Active' : 'Inactive' ?></span>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="categorie_id" value="<?= $sc['id'] ?>">
                                    <button type="submit" name="toggle_statut" value="1" style="border:none; background:none; color:var(--admin-violet); cursor:pointer; font-size:12px; font-weight:600;">
                                        <?= $sc['statut'] === 'active' ? 'Désactiver' : 'Activer' ?>
                                    </button>
                                </form>
                            </span>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($sousParPole[$pole['id']])): ?>
                        <p style="font-size:13px; color:var(--admin-texte-discret);">Aucune sous-catégorie.</p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>

            <div>
                <div class="admin-panneau">
                    <div class="admin-panneau__titre">Nouveau pôle</div>
                    <form method="POST" class="form-inline-admin">
                        <div style="flex:1;">
                            <label>Nom du pôle</label>
                            <input type="text" name="nom_pole" placeholder="ex : Auto/Deux-Roues" required style="width:100%;">
                        </div>
                        <button type="submit" name="creer_pole" value="1" style="padding:10px 16px; background:var(--admin-violet); color:white; border:none; border-radius:6px; font-weight:600; cursor:pointer;">Ajouter</button>
                    </form>
                </div>

                <div class="admin-panneau">
                    <div class="admin-panneau__titre">Nouvelle sous-catégorie</div>
                    <form method="POST">
                        <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret); display:block; margin-bottom:4px;">Pôle parent</label>
                        <select name="parent_id" required style="width:100%; padding:9px 12px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:12px;">
                            <?php foreach ($poles as $pole): ?>
                                <option value="<?= $pole['id'] ?>"><?= htmlspecialchars($pole['nom']) ?></option>
                            <?php endforeach; ?>
                        </select>

                        <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret); display:block; margin-bottom:4px;">Nom</label>
                        <input type="text" name="nom_sous_categorie" placeholder="ex : Serrurerie" required style="width:100%; padding:9px 12px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:12px;">

                        <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret); display:block; margin-bottom:4px;">Tarif de base (FCFA, optionnel)</label>
                        <input type="number" name="tarif_base" placeholder="ex : 15000" step="500" style="width:100%; padding:9px 12px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:14px;">

                        <button type="submit" name="creer_sous_categorie" value="1" style="width:100%; padding:10px; background:var(--admin-violet); color:white; border:none; border-radius:6px; font-weight:700; cursor:pointer;">Ajouter la sous-catégorie</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>