<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('clients');
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/NoteInterne.php';

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: clients.php"); exit; }

$userModel = new User();
$client = $userModel->getById($id);
if (!$client || $client['role'] !== 'client') { die("Client introuvable."); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['changer_statut'])) {
        $userModel->changerStatut($id, $_POST['changer_statut']);
        journaliser($_POST['changer_statut'] === 'suspendu' ? 'client.suspendu' : 'client.reactive', 'compte', $id, $client['matricule'], $client['nom']);
        header("Location: client-detail.php?id=" . $id);
        exit;
    }
    if (isset($_POST['note_interne'])) {
        (new NoteInterne())->create($id, $_SESSION['user_id'], trim($_POST['note_interne']));
        header("Location: client-detail.php?id=" . $id . "#notes");
        exit;
    }
}

$demandeModel = new Demande();
$dossiers = $demandeModel->getByClient($id);
$notesInternes = (new NoteInterne())->getByClient($id);

$libellesStatuts = ['nouvelle' => ['Nouvelle', 'violet'], 'attribuee' => ['Attribuée', 'amber'], 'en_cours' => ['En cours', 'amber'], 'terminee' => ['Terminée', 'vert'], 'annulee' => ['Annulée', 'gris']];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($client['nom']) ?> — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .fiche-client { display: grid; grid-template-columns: 320px 1fr; gap: 20px; }
        .fiche-profil { text-align: center; }
        .fiche-profil__avatar { width: 70px; height: 70px; border-radius: 50%; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-family:'Space Grotesk',sans-serif; font-weight: 800; font-size: 26px; margin: 0 auto 14px; }
        .fiche-profil__nom { font-family:'Space Grotesk',sans-serif; font-weight: 700; font-size: 17px; }
        .fiche-profil__ligne { display: flex; justify-content: space-between; padding: 10px 0; border-top: 1px solid #F1F0F6; font-size: 13.5px; margin-top: 14px; }
        .fiche-profil__ligne span:first-child { color: var(--admin-texte-discret); }
        .note-interne-admin { background: #FBF7EC; border: 1px solid #EEE0B0; border-radius: 8px; padding: 10px 12px; margin-bottom: 8px; font-size: 13px; }
        .note-interne-admin__meta { font-size: 11px; color: #92752E; font-weight: 600; margin-bottom: 3px; }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="clients.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour aux clients</a>
                <div class="admin-entete__titre" style="margin-top:6px;"><?= htmlspecialchars($client['nom']) ?></div>
            </div>
        </div>

        <div class="fiche-client">
            <div>
                <div class="admin-panneau fiche-profil">
                    <div class="fiche-profil__avatar"><?= htmlspecialchars(strtoupper(mb_substr($client['nom'], 0, 1))) ?></div>
                    <div class="fiche-profil__nom"><?= htmlspecialchars($client['nom']) ?></div>
                    <span class="admin-badge admin-badge--<?= $client['statut'] === 'actif' ? 'vert' : 'rouge' ?>" style="margin-top:8px; display:inline-block;">
                        <?= $client['statut'] === 'actif' ? 'Compte actif' : 'Compte suspendu' ?>
                    </span>

                    <div class="fiche-profil__ligne"><span>Téléphone</span><span><?= htmlspecialchars($client['telephone'] ?: '—') ?></span></div>
                    <div class="fiche-profil__ligne"><span>Email</span><span><?= htmlspecialchars($client['email']) ?></span></div>
                    <div class="fiche-profil__ligne"><span>Inscrit le</span><span><?= date('d/m/Y', strtotime($client['date_creation'])) ?></span></div>
                    <div class="fiche-profil__ligne"><span>Total dossiers</span><span><?= count($dossiers) ?></span></div>

                    <form method="POST" style="margin-top:16px;">
                        <input type="hidden" name="changer_statut" value="<?= $client['statut'] === 'actif' ? 'suspendu' : 'actif' ?>">
                        <button type="submit" class="bouton-principal-inline" style="width:100%; text-align:center; background:<?= $client['statut'] === 'actif' ? '#FDECEC' : '#E6F7ED' ?>; color:<?= $client['statut'] === 'actif' ? 'var(--admin-rouge)' : 'var(--admin-vert)' ?>; border:none; cursor:pointer;">
                            <?= $client['statut'] === 'actif' ? 'Suspendre le compte' : 'Réactiver le compte' ?>
                        </button>
                    </form>
                </div>

                <div class="admin-panneau" id="notes">
                    <div class="admin-panneau__titre">Notes internes</div>
                    <form method="POST" style="margin-bottom:12px;">
                        <textarea name="note_interne" rows="2" placeholder="Ajouter une note (visible équipe uniquement)..." required style="width:100%; padding:8px 10px; border:1px solid var(--admin-bordure); border-radius:6px; font-family:'Inter',sans-serif; font-size:13px; resize:vertical;"></textarea>
                        <button type="submit" style="width:100%; margin-top:6px; padding:7px; font-size:13px; background:var(--admin-violet); color:white; border:none; border-radius:6px; cursor:pointer; font-weight:600;">Ajouter</button>
                    </form>
                    <div style="max-height:220px; overflow-y:auto;">
                        <?php if (empty($notesInternes)): ?><p style="font-size:12px; color:var(--admin-texte-discret);">Aucune note.</p><?php endif; ?>
                        <?php foreach ($notesInternes as $n): ?>
                            <div class="note-interne-admin">
                                <div class="note-interne-admin__meta"><?= htmlspecialchars($n['conseiller_nom']) ?> · <?= date('d/m/Y H:i', strtotime($n['date_creation'])) ?></div>
                                <?= nl2br(htmlspecialchars($n['contenu'])) ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Historique des dossiers</div>
                <table class="admin-table">
                    <tr><th>Dossier</th><th>Catégorie</th><th>Statut</th><th>Date</th></tr>
                    <?php if (empty($dossiers)): ?>
                        <tr><td colspan="4" style="text-align:center; color:var(--admin-texte-discret); padding:20px;">Aucun dossier.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($dossiers as $d): $s = $libellesStatuts[$d['statut']] ?? ['—','gris']; ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($d['numero_dossier']) ?></strong></td>
                        <td><?= htmlspecialchars($d['categorie_nom']) ?></td>
                        <td><span class="admin-badge admin-badge--<?= $s[1] ?>"><?= $s[0] ?></span></td>
                        <td><?= date('d/m/Y', strtotime($d['date_creation'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>