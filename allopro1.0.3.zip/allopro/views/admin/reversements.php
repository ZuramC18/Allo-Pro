<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/Reversement.php';

$statutFiltre = $_GET['statut'] ?? '';
$reversements = (new Reversement())->getAll($statutFiltre ?: null);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reversements — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Reversements partenaires</div>
                <div class="admin-entete__sous-titre">Historique des montants dus et payés</div>
            </div>
            <a href="paiements.php" style="font-size:13px; color:var(--admin-violet); font-weight:600; text-decoration:none;">← Voir les montants encore dus</a>
        </div>

        <div class="filtres-tabs" style="margin-bottom:20px;">
            <a href="?" class="filtre-tab <?= !$statutFiltre ? 'filtre-tab--actif' : '' ?>">Tous</a>
            <a href="?statut=en_attente" class="filtre-tab <?= $statutFiltre === 'en_attente' ? 'filtre-tab--actif' : '' ?>">En attente</a>
            <a href="?statut=paye" class="filtre-tab <?= $statutFiltre === 'paye' ? 'filtre-tab--actif' : '' ?>">Payés</a>
        </div>

        <div class="admin-panneau">
            <table class="admin-table">
                <tr><th>Partenaire</th><th>Période</th><th>Montant</th><th>Statut</th><th></th></tr>
                <?php if (empty($reversements)): ?>
                    <tr><td colspan="5" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun reversement créé pour l'instant.</td></tr>
                <?php endif; ?>
                <?php foreach ($reversements as $r): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($r['nom_entreprise']) ?></strong></td>
                    <td><?= date('d/m/Y', strtotime($r['periode_debut'])) ?> → <?= date('d/m/Y', strtotime($r['periode_fin'])) ?></td>
                    <td><?= number_format($r['montant_du'], 0, ',', ' ') ?> F</td>
                    <td><span class="admin-badge admin-badge--<?= $r['statut'] === 'paye' ? 'vert' : 'amber' ?>"><?= $r['statut'] === 'paye' ? 'Payé' : 'En attente' ?></span></td>
                    <td><a href="reversement-detail.php?id=<?= $r['id'] ?>" style="color:var(--admin-violet); font-weight:600; text-decoration:none; font-size:13px;">Voir →</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</div>
</body>
</html>