<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Technicien.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$technicienId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$retourMessagerie = ($_GET['retour'] ?? '') === 'messagerie';
$technicien = false;
$missions = [];
$erreurAction = '';
$csrfSession = 'csrf_partenaire_detail_technicien';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}
$messageSucces = is_string($_SESSION['flash_detail_technicien'] ?? null) ? $_SESSION['flash_detail_technicien'] : '';
unset($_SESSION['flash_detail_technicien']);
$cleMotDePasseGenere = 'flash_mot_de_passe_technicien_' . (int) ($technicienId ?: 0);
$motDePasseGenere = is_string($_SESSION[$cleMotDePasseGenere] ?? null)
    ? $_SESSION[$cleMotDePasseGenere]
    : '';
unset($_SESSION[$cleMotDePasseGenere]);
if ($motDePasseGenere !== '') {
    header('Cache-Control: no-store, private');
    header('Pragma: no-cache');
}

if ($technicienId !== false && $technicienId !== null && $technicienId > 0) {
    $technicienModel = new Technicien();
    $technicien = $technicienModel->getDetailsByIdEtPartenaire($technicienId, $partenaireId);
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $technicien) {
        $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
        $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';

        if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
            http_response_code(403);
            $erreurAction = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
        } elseif ($action === 'reinitialiser_mot_de_passe') {
            $motDePassePartenaire = is_string($_POST['mot_de_passe_partenaire'] ?? null)
                ? $_POST['mot_de_passe_partenaire']
                : '';

            if ($technicien['statut'] === 'corbeille') {
                $erreurAction = 'Le mot de passe d’un technicien placé dans la corbeille ne peut pas être réinitialisé.';
            } elseif ($motDePassePartenaire === '') {
                $erreurAction = 'Saisissez le mot de passe de votre compte pour confirmer cette action.';
            } elseif (strlen($motDePassePartenaire) > 4096) {
                $erreurAction = 'Le mot de passe saisi est invalide.';
            } else {
                try {
                    $partenaireModel = new Partenaire();
                    if (!$partenaireModel->verifierMotDePasse($partenaireId, $motDePassePartenaire)) {
                        $erreurAction = 'Le mot de passe de confirmation est incorrect. Aucun changement n’a été effectué.';
                    } else {
                        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_';
                        $nouveauMotDePasse = '';
                        for ($i = 0; $i < 20; $i++) {
                            $nouveauMotDePasse .= $alphabet[random_int(0, strlen($alphabet) - 1)];
                        }

                        if ($technicienModel->reinitialiserMotDePasseParPartenaire($technicienId, $partenaireId, $nouveauMotDePasse)) {
                            $messageAction = 'Le mot de passe de ' . $technicien['nom'] . ' a été réinitialisé.';
                            journaliser(
                                'technicien.mot_de_passe_reinitialise',
                                'compte',
                                $technicienId,
                                $technicien['matricule'] ?? null,
                                'Mot de passe réinitialisé par le partenaire propriétaire'
                            );
                            $_SESSION['flash_detail_technicien'] = $messageAction;
                            $_SESSION['flash_mot_de_passe_technicien_' . $technicienId] = $nouveauMotDePasse;
                            header('Location: detail-technicien.php?id=' . $technicienId . ($retourMessagerie ? '&retour=messagerie' : ''));
                            exit;
                        }
                        $erreurAction = 'Le mot de passe n’a pas pu être modifié. Vérifiez que ce technicien appartient toujours à votre équipe, puis réessayez.';
                    }
                } catch (PDOException $exception) {
                    error_log('Réinitialisation mot de passe technicien ' . $technicienId . ' par partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
                    $erreurAction = 'Une erreur est survenue pendant la réinitialisation du mot de passe.';
                }
            }
        } else {
            $modifie = false;
            $messageAction = '';
            if ($action === 'suspendre' && $technicien['statut'] === 'actif') {
                $modifie = $technicienModel->changerStatutParPartenaire($technicienId, $partenaireId, 'inactif');
                $messageAction = 'Le technicien a été suspendu. Vous pourrez le réactiver depuis cette fiche.';
            } elseif ($action === 'reactiver' && $technicien['statut'] === 'inactif') {
                $modifie = $technicienModel->changerStatutParPartenaire($technicienId, $partenaireId, 'actif');
                $messageAction = 'Le technicien a été réactivé.';
            } elseif ($action === 'corbeille' && in_array($technicien['statut'], ['actif', 'inactif'], true)) {
                if ((int) $technicien['nb_en_cours'] > 0) {
                    $erreurAction = 'Redistribuez ou terminez les missions en cours avant de placer ce technicien dans la corbeille.';
                } else {
                    $modifie = $technicienModel->mettreEnCorbeille($technicienId, $partenaireId);
                    $messageAction = 'Le technicien a été placé dans la corbeille. Son historique est conservé.';
                }
            } elseif ($action === 'restaurer' && $technicien['statut'] === 'corbeille') {
                $modifie = $technicienModel->restaurerDeLaCorbeille($technicienId, $partenaireId);
                $messageAction = 'Le technicien a été restauré dans votre équipe comme compte suspendu.';
            } else {
                $erreurAction = 'Cette action ne peut pas être effectuée sur le statut actuel du technicien.';
            }

            if ($modifie) {
                journaliser(
                    'technicien.' . $action,
                    'compte',
                    $technicienId,
                    $technicien['matricule'] ?? null,
                    $messageAction
                );
                $_SESSION['flash_detail_technicien'] = $messageAction;
                $suffixeCorbeille = $action === 'corbeille' || $action === 'restaurer' ? '&corbeille=1' : '';
                header('Location: detail-technicien.php?id=' . $technicienId . $suffixeCorbeille . ($retourMessagerie ? '&retour=messagerie' : ''));
                exit;
            }
            if ($erreurAction === '') {
                $erreurAction = 'Le statut du technicien n’a pas été modifié. Rechargez la page puis réessayez.';
            }
        }
        $technicien = $technicienModel->getDetailsByIdEtPartenaire($technicienId, $partenaireId);
    }
    if ($technicien) {
        $missions = $technicienModel->getMissionsRecentesParTechnicien($technicienId, $partenaireId);
    }
}

if (!$technicien) {
    http_response_code(404);
}

$statutsLibelles = [
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$libelleStatut = static fn(string $cle): string => $statutsLibelles[$cle] ?? ucfirst(str_replace('_', ' ', $cle));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $technicien ? 'Profil de ' . $echapper($technicien['nom']) : 'Technicien introuvable' ?> — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-detail-technicien.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-detail-technicien.css') ?>">
</head>
<body class="page-partenaire-detail-technicien">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <a class="detail-retour" href="<?= $retourMessagerie ? 'messagerie.php?restaurer_conversation=1' : ($technicien && $technicien['statut'] === 'corbeille' ? 'techniciens.php?corbeille=1' : 'techniciens.php') ?>"><?= icone('arrow', 16) ?> <?= $retourMessagerie ? 'Retour à la conversation' : 'Retour à mes techniciens' ?></a>
        <?php if (!$technicien): ?>
            <section class="detail-introuvable">
                <span class="detail-introuvable__icone"><?= icone('alert', 25) ?></span>
                <h1>Technicien introuvable</h1>
                <p>Ce profil n’existe pas ou n’appartient pas à votre équipe.</p>
                <a href="techniciens.php">Revenir à mon équipe</a>
            </section>
        <?php else: ?>
            <?php $actif = $technicien['statut'] === 'actif'; ?>
            <?php if ($messageSucces !== ''): ?>
                <div class="technicien-action-message technicien-action-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
            <?php endif; ?>
            <?php if ($motDePasseGenere !== ''): ?>
                <section class="detail-mot-de-passe-resultat" aria-labelledby="mot-de-passe-resultat-titre">
                    <span class="detail-mot-de-passe-resultat__icone"><?= icone('key', 19) ?></span>
                    <div>
                        <h2 id="mot-de-passe-resultat-titre">Nouveau mot de passe prêt à transmettre</h2>
                        <p>Communiquez-le directement au technicien. Pour sa sécurité, il ne sera affiché qu’une seule fois.</p>
                        <code><?= $echapper($motDePasseGenere) ?></code>
                    </div>
                </section>
            <?php endif; ?>
            <?php if ($erreurAction !== ''): ?>
                <div class="technicien-action-message technicien-action-message--erreur" role="alert"><?= $echapper($erreurAction) ?></div>
            <?php endif; ?>
            <header class="detail-entete">
                <div class="detail-identite">
                    <span class="detail-avatar"><?= $echapper(mb_strtoupper(mb_substr($technicien['nom'] ?? '?', 0, 1))) ?></span>
                    <div>
                        <div class="detail-sur-titre">Fiche technicien · <?= $echapper($technicien['matricule'] ?? 'Sans matricule') ?></div>
                        <h1><?= $echapper($technicien['nom']) ?></h1>
                        <span class="detail-statut <?= $technicien['statut'] === 'corbeille' ? 'detail-statut--corbeille' : ($actif ? 'detail-statut--actif' : 'detail-statut--inactif') ?>">
                            <span></span><?= $technicien['statut'] === 'corbeille' ? 'En corbeille' : ($actif ? 'Compte actif' : 'Compte suspendu') ?>
                        </span>
                    </div>
                </div>
                <span class="detail-metier"><?= iconePole($technicien['categorie_nom'] ?? null, 18) ?> <?= $echapper($technicien['categorie_nom'] ?? 'Métier non défini') ?></span>
            </header>

            <section class="detail-actions" aria-label="Gestion du compte technicien">
                <?php if ($technicien['statut'] === 'corbeille'): ?>
                    <div>
                        <strong>Ce technicien est dans la corbeille</strong>
                        <p>Son compte est désactivé et masqué de la liste de l’équipe. Son historique est conservé.</p>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                        <input type="hidden" name="action" value="restaurer">
                        <button class="detail-action-bouton detail-action-bouton--restaurer" type="submit"><?= icone('refresh', 17) ?> Restaurer dans l’équipe</button>
                    </form>
                <?php else: ?>
                    <div>
                        <strong>Gestion de l’accès</strong>
                        <p><?= $actif ? 'Suspendez temporairement son accès ou placez son compte dans la corbeille.' : 'Ce compte est suspendu. Réactivez-le ou placez-le dans la corbeille.' ?><?php if ((int) $technicien['nb_en_cours'] > 0): ?> <?= (int) $technicien['nb_en_cours'] ?> mission<?= (int) $technicien['nb_en_cours'] === 1 ? '' : 's' ?> en cours : le technicien ne pourra plus se connecter pour les traiter s’il est suspendu.<?php endif; ?></p>
                    </div>
                    <div class="detail-actions__boutons">
                        <form method="POST" <?= $actif && (int) $technicien['nb_en_cours'] > 0 ? 'onsubmit="return confirm(\'Ce technicien a des missions en cours. Sa suspension l’empêchera de se connecter pour les traiter. Continuer ?\');"' : '' ?>>
                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                            <input type="hidden" name="action" value="<?= $actif ? 'suspendre' : 'reactiver' ?>">
                            <button class="detail-action-bouton <?= $actif ? 'detail-action-bouton--suspendre' : 'detail-action-bouton--restaurer' ?>" type="submit">
                                <?= $actif ? icone('clock', 17) : icone('check', 17) ?> <?= $actif ? 'Suspendre le technicien' : 'Réactiver le technicien' ?>
                            </button>
                        </form>
                        <?php if ((int) $technicien['nb_en_cours'] > 0): ?>
                            <p class="detail-actions__avertissement">Redistribuez ou terminez les missions en cours avant de mettre le technicien en corbeille.</p>
                        <?php else: ?>
                        <form method="POST" onsubmit="return confirm('Placer ce technicien dans la corbeille ? Son compte sera désactivé, mais son historique sera conservé. Vous pourrez le restaurer plus tard.');">
                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                            <input type="hidden" name="action" value="corbeille">
                            <button class="detail-action-bouton detail-action-bouton--corbeille" type="submit"><?= icone('folder', 17) ?> Mettre en corbeille</button>
                        </form>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </section>

            <?php if ($technicien['statut'] !== 'corbeille'): ?>
                <section class="detail-carte detail-reinitialisation" aria-labelledby="reinitialisation-titre">
                    <header class="detail-carte__entete">
                        <span><?= icone('key', 18) ?></span>
                        <div>
                            <h2 id="reinitialisation-titre">Réinitialiser son mot de passe</h2>
                            <p>Un nouveau mot de passe sera généré pour ce technicien.</p>
                        </div>
                    </header>
                    <div class="detail-reinitialisation__corps">
                        <p>Confirmez l’opération avec le mot de passe de votre compte partenaire. Le nouveau mot de passe sera affiché une seule fois afin que vous puissiez le transmettre au technicien.</p>
                        <form method="POST" class="detail-reinitialisation__formulaire" onsubmit="return confirm('Réinitialiser le mot de passe de ce technicien ? Son mot de passe actuel ne fonctionnera plus.');">
                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                            <input type="hidden" name="action" value="reinitialiser_mot_de_passe">
                            <label for="mot-de-passe-partenaire">Votre mot de passe partenaire</label>
                            <div class="detail-reinitialisation__ligne">
                                <input id="mot-de-passe-partenaire" type="password" name="mot_de_passe_partenaire" autocomplete="current-password" maxlength="4096" required>
                                <button class="detail-action-bouton detail-action-bouton--reinitialiser" type="submit"><?= icone('refresh', 16) ?> Générer un nouveau mot de passe</button>
                            </div>
                        </form>
                    </div>
                </section>
            <?php endif; ?>

            <section class="detail-indicateurs" aria-label="Activité du technicien">
                <article class="detail-indicateur">
                    <span class="detail-indicateur__icone"><?= icone('clipboard', 19) ?></span>
                    <strong><?= (int) $technicien['nb_missions'] ?></strong>
                    <span>Missions attribuées</span>
                </article>
                <article class="detail-indicateur">
                    <span class="detail-indicateur__icone detail-indicateur__icone--actif"><?= icone('bolt', 19) ?></span>
                    <strong><?= (int) $technicien['nb_en_cours'] ?></strong>
                    <span>Missions en cours</span>
                </article>
                <article class="detail-indicateur">
                    <span class="detail-indicateur__icone detail-indicateur__icone--termine"><?= icone('check', 19) ?></span>
                    <strong><?= (int) $technicien['nb_terminees'] ?></strong>
                    <span>Missions terminées</span>
                </article>
                <article class="detail-indicateur">
                    <span class="detail-indicateur__icone detail-indicateur__icone--avis"><?= icone('star', 19) ?></span>
                    <strong><?= $technicien['note_moyenne'] !== null ? number_format((float) $technicien['note_moyenne'], 1, ',', ' ') . '/5' : '—' ?></strong>
                    <span><?= (int) $technicien['nb_avis'] ?> avis client<?= (int) $technicien['nb_avis'] === 1 ? '' : 's' ?></span>
                </article>
            </section>

            <div class="detail-contenu">
                <section class="detail-carte detail-coordonnees" aria-labelledby="coordonnees-titre">
                    <header class="detail-carte__entete">
                        <span><?= icone('users', 18) ?></span>
                        <div><h2 id="coordonnees-titre">Coordonnées</h2><p>Informations du membre de votre équipe</p></div>
                    </header>
                    <dl class="detail-coordonnees__liste">
                        <div>
                            <dt>Adresse e-mail</dt>
                            <dd><a href="mailto:<?= $echapper($technicien['email']) ?>"><?= $echapper($technicien['email']) ?></a></dd>
                        </div>
                        <div>
                            <dt>Téléphone</dt>
                            <dd>
                                <?php if (!empty($technicien['telephone'])): ?>
                                    <a href="tel:<?= $echapper(preg_replace('/[^0-9+]/', '', $technicien['telephone'])) ?>"><?= $echapper($technicien['telephone']) ?></a>
                                <?php else: ?>
                                    <span class="detail-non-renseigne">Non renseigné</span>
                                <?php endif; ?>
                            </dd>
                        </div>
                        <div>
                            <dt>Métier principal</dt>
                            <dd><?= $echapper($technicien['categorie_nom'] ?? 'Non défini') ?></dd>
                        </div>
                        <div>
                            <dt>Identifiant équipe</dt>
                            <dd><?= $echapper($technicien['matricule'] ?? 'Non attribué') ?></dd>
                        </div>
                    </dl>
                </section>

                <section class="detail-carte detail-missions" aria-labelledby="missions-titre">
                    <header class="detail-carte__entete">
                        <span><?= icone('clipboard', 18) ?></span>
                        <div><h2 id="missions-titre">Missions récentes</h2><p>Les 10 dernières interventions attribuées</p></div>
                    </header>
                    <?php if (!$missions): ?>
                        <div class="detail-missions__vide">
                            <span><?= icone('inbox', 23) ?></span>
                            <strong>Aucune mission attribuée</strong>
                            <p>Les interventions confiées à ce technicien apparaîtront ici.</p>
                        </div>
                    <?php else: ?>
                        <div class="detail-missions__liste">
                            <?php foreach ($missions as $mission): ?>
                                <article class="detail-mission">
                                    <span class="detail-mission__icone"><?= icone('wrench', 17) ?></span>
                                    <div class="detail-mission__infos">
                                        <strong><?= $echapper($mission['categorie_nom']) ?></strong>
                                        <span><?= $echapper($mission['numero_dossier']) ?> · <?= $mission['date_debut'] ? $echapper(date('d/m/Y', strtotime($mission['date_debut']))) : 'Date non renseignée' ?></span>
                                        <?php if ($mission['note'] !== null): ?>
                                            <span class="detail-mission__avis">Note client : <?= number_format((float) $mission['note'], 1, ',', ' ') ?>/5<?php if (!empty($mission['commentaire'])): ?> · « <?= $echapper($mission['commentaire']) ?> »<?php endif; ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <span class="detail-mission__statut detail-mission__statut--<?= $echapper($mission['statut']) ?>"><?= $echapper($libelleStatut((string) $mission['statut'])) ?></span>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            </div>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
