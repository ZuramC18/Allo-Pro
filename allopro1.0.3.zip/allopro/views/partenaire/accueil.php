<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Tache.php';

$partenaireModel = new Partenaire();
$partenaire = $partenaireModel->getById($_SESSION['partenaire_id']);
$nbTechniciens = (int) $partenaireModel->compterTechniciens($_SESSION['partenaire_id']);

$rappelsTaches = [];
$erreurRappelsTaches = false;
try {
    $tacheModel = new Tache();
    $rappelsTaches = $tacheModel->getRappelsPour('partenaire', (int) $_SESSION['partenaire_id']);
} catch (PDOException $exception) {
    error_log('Lecture des rappels de tâches partenaire ' . (int) $_SESSION['partenaire_id'] . ' : ' . $exception->getMessage());
    $erreurRappelsTaches = true;
}

$nomEntreprise = (string) ($partenaire['nom_entreprise'] ?? 'votre entreprise');
$niveau = ucfirst((string) ($partenaire['niveau'] ?? 'partenaire'));
$score = (float) ($partenaire['score'] ?? 0);
$zone = trim((string) ($partenaire['zone_intervention'] ?? ''));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Accueil — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-accueil.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-accueil.css') ?>">
</head>
<body>
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu partenaire-accueil">
        <section class="accueil-hero" aria-labelledby="accueil-titre">
            <div class="accueil-hero__contenu">
                <span class="accueil-hero__surtitre">Votre espace professionnel</span>
                <h1 id="accueil-titre">Bonjour, <?= htmlspecialchars($nomEntreprise, ENT_QUOTES, 'UTF-8') ?></h1>
                <p>Retrouvez ici l’essentiel de votre activité et accédez rapidement à vos outils.</p>
                <div class="accueil-hero__actions">
                    <a class="accueil-bouton accueil-bouton--principal" href="missions.php">
                        Voir mes missions <?= icone('arrow', 17) ?>
                    </a>
                    <a class="accueil-bouton accueil-bouton--secondaire" href="techniciens.php">
                        Gérer mes techniciens
                    </a>
                </div>
            </div>
            <div class="accueil-hero__embleme" aria-hidden="true">
                <span><?= icone('building', 42) ?></span>
                <i></i>
                <i></i>
            </div>
            <span class="accueil-niveau"><?= htmlspecialchars($niveau, ENT_QUOTES, 'UTF-8') ?></span>
        </section>

        <section class="accueil-rappels <?= $erreurRappelsTaches ? 'accueil-rappels--erreur' : (count($rappelsTaches) > 0 ? 'accueil-rappels--actif' : 'accueil-rappels--vide') ?>" aria-labelledby="accueil-rappels-titre">
            <span class="accueil-rappels__icone"><?= icone($erreurRappelsTaches || $rappelsTaches ? 'alert' : 'check', 20) ?></span>
            <div class="accueil-rappels__contenu">
                <div class="accueil-rappels__entete">
                    <div>
                        <span class="accueil-rappels__surtitre">Rappels</span>
                        <h2 id="accueil-rappels-titre">
                            <?= $erreurRappelsTaches
                                ? 'Notifications de tâches indisponibles'
                                : (count($rappelsTaches) > 0 ? count($rappelsTaches) . ' tâche' . (count($rappelsTaches) > 1 ? 's' : '') . ' à suivre' : 'Aucun rappel en attente') ?>
                        </h2>
                    </div>
                    <a href="taches.php">Mes tâches <?= icone('arrow', 16) ?></a>
                </div>
                <?php if ($erreurRappelsTaches): ?>
                    <p class="accueil-rappels__message" role="alert">Impossible de charger vos rappels pour le moment. Réessayez plus tard.</p>
                <?php elseif ($rappelsTaches): ?>
                    <ul class="accueil-rappels__liste">
                        <?php foreach (array_slice($rappelsTaches, 0, 3) as $rappel): ?>
                            <?php
                            $echeanceRappel = new DateTimeImmutable($rappel['date_echeance']);
                            $estEnRetard = $echeanceRappel < new DateTimeImmutable();
                            ?>
                            <li>
                                <span class="accueil-rappels__point" aria-hidden="true"></span>
                                <span class="accueil-rappels__titre"><?= htmlspecialchars((string) $rappel['titre'], ENT_QUOTES, 'UTF-8') ?></span>
                                <span class="accueil-rappels__echeance <?= $estEnRetard ? 'accueil-rappels__echeance--retard' : '' ?>">
                                    <?= $estEnRetard ? 'En retard' : 'Aujourd’hui' ?>
                                    <time datetime="<?= htmlspecialchars($echeanceRappel->format(DateTimeInterface::ATOM), ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($echeanceRappel->format('d/m à H:i'), ENT_QUOTES, 'UTF-8') ?></time>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if (count($rappelsTaches) > 3): ?>
                        <p class="accueil-rappels__plus">Et <?= count($rappelsTaches) - 3 ?> autre<?= count($rappelsTaches) - 3 > 1 ? 's' : '' ?> rappel<?= count($rappelsTaches) - 3 > 1 ? 's' : '' ?> à consulter dans <a href="taches.php">Mes tâches</a>.</p>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="accueil-rappels__message">Les échéances du jour et en retard apparaîtront ici.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="accueil-section" aria-labelledby="accueil-bilan">
            <div class="accueil-section__entete">
                <div>
                    <span class="accueil-section__surtitre">En un coup d’œil</span>
                    <h2 id="accueil-bilan">Votre activité</h2>
                </div>
                <a class="accueil-lien" href="profil.php">Voir mon profil <?= icone('arrow', 16) ?></a>
            </div>

            <div class="accueil-indicateurs">
                <article class="accueil-indicateur">
                    <span class="accueil-indicateur__icone accueil-indicateur__icone--techniciens"><?= icone('users', 21) ?></span>
                    <div class="accueil-indicateur__texte">
                        <span class="accueil-indicateur__label">Techniciens</span>
                        <strong><?= $nbTechniciens ?></strong>
                        <span class="accueil-indicateur__aide">rattachés à votre espace</span>
                    </div>
                    <a class="accueil-indicateur__lien" href="techniciens.php" aria-label="Gérer mes techniciens"></a>
                </article>

                <article class="accueil-indicateur">
                    <span class="accueil-indicateur__icone accueil-indicateur__icone--score"><?= icone('star', 21) ?></span>
                    <div class="accueil-indicateur__texte">
                        <span class="accueil-indicateur__label">Votre score</span>
                        <strong><?= $score > 0 ? htmlspecialchars(number_format($score, 1, ',', ' '), ENT_QUOTES, 'UTF-8') . '<small> / 5</small>' : '—' ?></strong>
                        <span class="accueil-indicateur__aide"><?= $score > 0 ? 'note moyenne reçue' : 'aucune note pour le moment' ?></span>
                    </div>
                </article>

                <article class="accueil-indicateur">
                    <span class="accueil-indicateur__icone accueil-indicateur__icone--zone"><?= icone('pin', 21) ?></span>
                    <div class="accueil-indicateur__texte">
                        <span class="accueil-indicateur__label">Zone d’intervention</span>
                        <strong class="accueil-indicateur__valeur"><?= htmlspecialchars($zone !== '' ? $zone : 'À renseigner', ENT_QUOTES, 'UTF-8') ?></strong>
                        <span class="accueil-indicateur__aide">votre secteur d’activité</span>
                    </div>
                    <a class="accueil-indicateur__lien" href="profil.php" aria-label="Modifier ma zone d’intervention"></a>
                </article>
            </div>
        </section>

        <?php if ($nbTechniciens === 0): ?>
            <aside class="accueil-conseil" aria-labelledby="accueil-conseil-titre">
                <span class="accueil-conseil__icone"><?= icone('wrench', 21) ?></span>
                <div>
                    <h2 id="accueil-conseil-titre">Préparez votre espace à recevoir des missions</h2>
                    <p>Ajoutez un technicien pour organiser votre équipe et pouvoir recevoir des missions.</p>
                </div>
                <a href="techniciens.php">Ajouter un technicien <?= icone('arrow', 16) ?></a>
            </aside>
        <?php endif; ?>

        <section class="accueil-section accueil-raccourcis" aria-labelledby="accueil-raccourcis-titre">
            <div class="accueil-section__entete">
                <div>
                    <span class="accueil-section__surtitre">Accès rapide</span>
                    <h2 id="accueil-raccourcis-titre">Que souhaitez-vous faire ?</h2>
                </div>
            </div>
            <div class="accueil-raccourcis__grille">
                <a class="accueil-raccourci" href="missions.php">
                    <span class="accueil-raccourci__icone accueil-raccourci__icone--missions"><?= icone('receipt', 21) ?></span>
                    <span class="accueil-raccourci__texte"><strong>Mes missions</strong><small>Consulter et suivre vos missions</small></span>
                    <?= icone('arrow', 17) ?>
                </a>
                <a class="accueil-raccourci" href="techniciens.php">
                    <span class="accueil-raccourci__icone accueil-raccourci__icone--techniciens"><?= icone('users', 21) ?></span>
                    <span class="accueil-raccourci__texte"><strong>Mes techniciens</strong><small>Gérer votre équipe</small></span>
                    <?= icone('arrow', 17) ?>
                </a>
                <a class="accueil-raccourci" href="taches.php">
                    <span class="accueil-raccourci__icone accueil-raccourci__icone--taches"><?= icone('clipboard', 21) ?></span>
                    <span class="accueil-raccourci__texte"><strong>Mes tâches</strong><small>Garder le fil de vos actions</small></span>
                    <?= icone('arrow', 17) ?>
                </a>
                <a class="accueil-raccourci" href="messagerie.php">
                    <span class="accueil-raccourci__icone accueil-raccourci__icone--messages"><?= icone('messages', 21) ?></span>
                    <span class="accueil-raccourci__texte"><strong>Messagerie interne</strong><small>Échanger avec votre équipe</small></span>
                    <?= icone('arrow', 17) ?>
                </a>
            </div>
        </section>
    </main>
</div>
</body>
</html>
