<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$partenaireModel = new Partenaire();
$partenaire = $partenaireModel->getById($partenaireId);
if (!$partenaire) {
    http_response_code(404);
    exit('Profil partenaire introuvable.');
}

$csrfSession = 'csrf_partenaire_profil';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}

$erreur = '';
$action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
$messageSucces = is_string($_SESSION['flash_partenaire_profil'] ?? null) ? $_SESSION['flash_partenaire_profil'] : '';
unset($_SESSION['flash_partenaire_profil']);

$profil = [
    'nom_entreprise' => (string) $partenaire['nom_entreprise'],
    'telephone' => (string) ($partenaire['telephone'] ?? ''),
    'zone_intervention' => (string) ($partenaire['zone_intervention'] ?? ''),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (in_array($action, ['photo_profil', 'supprimer_photo', 'avatar_initiales'], true)) {
        try {
            if ($action === 'photo_profil') {
                $nouveauChemin = AvatarProfil::stocker($_FILES['photo_profil'] ?? [], 'partenaires');
                if (!$partenaireModel->mettreAJourPhotoProfil($partenaireId, $nouveauChemin)) {
                    AvatarProfil::supprimer($nouveauChemin);
                    throw new RuntimeException('La photo n’a pas pu être associée au compte.');
                }
                AvatarProfil::supprimer($partenaire['photo_profil'] ?? null);
                $_SESSION['partenaire_photo_profil'] = $nouveauChemin;
                $_SESSION['flash_partenaire_profil'] = 'La photo de profil a été mise à jour.';
            } elseif ($action === 'supprimer_photo') {
                if (!$partenaireModel->supprimerPhotoProfil($partenaireId)) {
                    throw new RuntimeException('La photo n’a pas pu être supprimée.');
                }
                AvatarProfil::supprimer($partenaire['photo_profil'] ?? null);
                $_SESSION['partenaire_photo_profil'] = null;
                $_SESSION['flash_partenaire_profil'] = 'La photo a été supprimée.';
            } else {
                $afficherInitiales = ($_POST['avatar_initiales'] ?? '') === '1';
                if (!$partenaireModel->definirAvatarInitiales($partenaireId, $afficherInitiales)) {
                    throw new RuntimeException('La préférence d’affichage n’a pas pu être enregistrée.');
                }
                $_SESSION['partenaire_avatar_initiales'] = $afficherInitiales;
                $_SESSION['flash_partenaire_profil'] = $afficherInitiales
                    ? 'Les initiales seront affichées à la place de la photo.'
                    : 'La photo sera affichée lorsqu’elle est disponible.';
            }
            header('Location: profil.php');
            exit;
        } catch (RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Mise à jour avatar partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
            if (isset($nouveauChemin)) AvatarProfil::supprimer($nouveauChemin);
            $erreur = 'La photo de profil n’a pas pu être enregistrée. Réessayez.';
        }
    } elseif ($action === 'profil') {
        foreach (array_keys($profil) as $champ) {
            $profil[$champ] = is_string($_POST[$champ] ?? null) ? trim($_POST[$champ]) : '';
        }

        if ($profil['nom_entreprise'] === '' || mb_strlen($profil['nom_entreprise']) > 150) {
            $erreur = 'Le nom de l’entreprise est obligatoire (150 caractères maximum).';
        } elseif (mb_strlen($profil['telephone']) > 20) {
            $erreur = 'Le numéro de téléphone ne peut pas dépasser 20 caractères.';
        } elseif (mb_strlen($profil['zone_intervention']) > 150) {
            $erreur = 'La zone d’intervention ne peut pas dépasser 150 caractères.';
        } else {
            try {
                if ($partenaireModel->mettreAJourProfil(
                    $partenaireId,
                    $profil['nom_entreprise'],
                    $profil['telephone'],
                    $profil['zone_intervention']
                )) {
                    $_SESSION['partenaire_nom'] = $profil['nom_entreprise'];
                    $_SESSION['flash_partenaire_profil'] = 'Les informations du profil ont été mises à jour.';
                    header('Location: profil.php');
                    exit;
                }
                $erreur = 'Le profil n’a pas pu être mis à jour. Réessayez.';
            } catch (PDOException $exception) {
                error_log('Mise à jour profil partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de la mise à jour du profil.';
            }
        }
    } elseif ($action === 'mot_de_passe') {
        $motDePasseActuel = is_string($_POST['mot_de_passe_actuel'] ?? null) ? $_POST['mot_de_passe_actuel'] : '';
        $nouveauMotDePasse = is_string($_POST['nouveau_mot_de_passe'] ?? null) ? $_POST['nouveau_mot_de_passe'] : '';
        $confirmation = is_string($_POST['confirmation_mot_de_passe'] ?? null) ? $_POST['confirmation_mot_de_passe'] : '';

        if ($motDePasseActuel === '' || $nouveauMotDePasse === '' || $confirmation === '') {
            $erreur = 'Remplissez tous les champs du changement de mot de passe.';
        } elseif (strlen($nouveauMotDePasse) < 8) {
            $erreur = 'Le nouveau mot de passe doit contenir au moins 8 caractères.';
        } elseif ($nouveauMotDePasse !== $confirmation) {
            $erreur = 'La confirmation ne correspond pas au nouveau mot de passe.';
        } elseif ($nouveauMotDePasse === $motDePasseActuel) {
            $erreur = 'Choisissez un mot de passe différent de l’actuel.';
        } else {
            try {
                if ($partenaireModel->changerMotDePasse($partenaireId, $motDePasseActuel, $nouveauMotDePasse)) {
                    journaliser('partenaire.mot_de_passe_modifie', 'partenaire', $partenaireId, $partenaire['matricule'] ?? null, 'Mot de passe partenaire modifié');
                    $_SESSION['flash_partenaire_profil'] = 'Votre mot de passe a été modifié.';
                    header('Location: profil.php');
                    exit;
                }
                $erreur = 'Le mot de passe actuel est incorrect ou le changement n’a pas pu être enregistré.';
            } catch (PDOException $exception) {
                error_log('Changement mot de passe partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors du changement de mot de passe.';
            }
        }
    } else {
        http_response_code(400);
        $erreur = 'Action de formulaire invalide.';
    }
}

$nombreTechniciens = (int) $partenaireModel->compterTechniciens($partenaireId);
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$initiales = AvatarProfil::initiales($profil['nom_entreprise']);
$photoProfil = AvatarProfil::estValide($partenaire['photo_profil'] ?? null, 'partenaires')
    ? (string) $partenaire['photo_profil']
    : null;
$avatarInitiales = !empty($partenaire['avatar_initiales']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mon profil — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-profil.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-profil.css') ?>">
    <link rel="stylesheet" href="../../public/css/avatar-profil.css?v=<?= filemtime(__DIR__ . '/../../public/css/avatar-profil.css') ?>">
</head>
<body class="page-partenaire-profil">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <header class="contenu__entete profil-entete">
            <div>
                <h1 class="contenu__titre">Mon profil</h1>
                <p>Gérez les informations de votre entreprise et sécurisez votre accès partenaire.</p>
            </div>
        </header>

        <?php if ($messageSucces !== ''): ?>
            <div class="profil-message profil-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur !== ''): ?>
            <div class="profil-message profil-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <section class="profil-identite" aria-label="Résumé du compte partenaire">
            <span class="profil-identite__avatar">
                <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                    <img src="../../public/<?= $echapper($photoProfil) ?>" alt="">
                <?php elseif ($avatarInitiales): ?>
                    <?= $echapper($initiales) ?>
                <?php else: ?>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                <?php endif; ?>
            </span>
            <div class="profil-identite__texte">
                <span class="profil-identite__surtitre">Espace partenaire</span>
                <h2><?= $echapper($profil['nom_entreprise']) ?></h2>
                <span class="profil-identite__matricule"><?= $echapper($partenaire['matricule'] ?? 'Partenaire') ?></span>
            </div>
            <div class="profil-identite__badges">
                <span class="profil-badge <?= !empty($partenaire['email_verifie']) ? 'profil-badge--verifie' : 'profil-badge--attente' ?>">
                    <?= !empty($partenaire['email_verifie']) ? 'E-mail vérifié' : 'E-mail à vérifier' ?>
                </span>
                <span class="profil-badge profil-badge--niveau"><?= $echapper(ucfirst($partenaire['niveau'] ?? 'partenaire')) ?></span>
            </div>
        </section>

        <div class="profil-grille">
            <section class="profil-carte" aria-labelledby="profil-informations-titre">
                <section class="avatar-profil" aria-labelledby="avatar-partenaire-titre">
                    <div class="avatar-profil__entete">
                        <div>
                            <h2 id="avatar-partenaire-titre">Photo de profil</h2>
                            <p>JPG, PNG ou WebP · 5 Mo maximum</p>
                        </div>
                        <div class="avatar-profil__apercu" aria-hidden="true">
                            <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                                <img src="../../public/<?= $echapper($photoProfil) ?>" alt="">
                            <?php elseif ($avatarInitiales): ?>
                                <?= $echapper($initiales) ?>
                            <?php else: ?>
                                <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                            <?php endif; ?>
                        </div>
                    </div>
                    <form method="POST" enctype="multipart/form-data" class="avatar-profil__formulaire">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                        <input type="hidden" name="action" value="photo_profil">
                        <input type="hidden" name="MAX_FILE_SIZE" value="5242880">
                        <input class="avatar-profil__input-fichier" id="photo-profil-partenaire" type="file" name="photo_profil" accept="image/jpeg,image/png,image/webp" aria-label="Choisir une photo de profil" required>
                        <label class="avatar-profil__fichier" for="photo-profil-partenaire">Choisir une photo</label>
                        <button type="submit" class="avatar-profil__bouton">Enregistrer la photo</button>
                    </form>
                    <?php if ($photoProfil !== null): ?>
                        <form method="POST" class="avatar-profil__action">
                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                            <input type="hidden" name="action" value="supprimer_photo">
                            <button type="submit" class="avatar-profil__lien">Supprimer la photo</button>
                        </form>
                    <?php endif; ?>
                    <form method="POST" class="avatar-profil__bascule">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                        <input type="hidden" name="action" value="avatar_initiales">
                        <input type="hidden" name="avatar_initiales" value="0">
                        <label for="avatar-initiales-partenaire">Afficher les initiales à la place de la photo</label>
                        <input id="avatar-initiales-partenaire" type="checkbox" name="avatar_initiales" value="1" <?= $avatarInitiales ? 'checked' : '' ?> onchange="this.form.querySelector('input[type=hidden][name=avatar_initiales]').disabled = this.checked; this.form.submit()">
                    </form>
                </section>
                <header class="profil-carte__entete">
                    <span><?= icone('building', 19) ?></span>
                    <div><h2 id="profil-informations-titre">Informations de l’entreprise</h2><p>Ces informations sont utilisées pour votre espace et vos missions.</p></div>
                </header>
                <form method="POST" class="profil-formulaire">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                    <input type="hidden" name="action" value="profil">
                    <div class="profil-champ">
                        <label for="profil-entreprise">Nom de l’entreprise</label>
                        <input id="profil-entreprise" type="text" name="nom_entreprise" value="<?= $echapper($profil['nom_entreprise']) ?>" maxlength="150" autocomplete="organization" required>
                    </div>
                    <div class="profil-champ">
                        <label for="profil-email">Adresse e-mail de connexion</label>
                        <input id="profil-email" type="email" value="<?= $echapper($partenaire['email']) ?>" readonly>
                        <small>L’adresse e-mail sert à la connexion et n’est pas modifiable depuis cette page.</small>
                    </div>
                    <div class="profil-champ">
                        <label for="profil-telephone">Téléphone</label>
                        <input id="profil-telephone" type="tel" name="telephone" value="<?= $echapper($profil['telephone']) ?>" maxlength="20" autocomplete="tel" placeholder="+221 77 000 00 00">
                    </div>
                    <div class="profil-champ">
                        <label for="profil-zone">Zone d’intervention</label>
                        <input id="profil-zone" type="text" name="zone_intervention" value="<?= $echapper($profil['zone_intervention']) ?>" maxlength="150" placeholder="Ex. Dakar et sa région">
                    </div>
                    <button class="profil-bouton" type="submit"><?= icone('check', 17) ?> Enregistrer les informations</button>
                </form>
            </section>

            <div class="profil-colonne-secondaire">
                <section class="profil-carte profil-apercu" aria-labelledby="profil-apercu-titre">
                    <header class="profil-carte__entete">
                        <span><?= icone('chart', 19) ?></span>
                        <div><h2 id="profil-apercu-titre">Votre compte</h2><p>Quelques repères sur votre espace</p></div>
                    </header>
                    <dl class="profil-apercu__liste">
                        <div><dt>Techniciens dans l’équipe</dt><dd><?= $nombreTechniciens ?></dd></div>
                        <div><dt>Niveau partenaire</dt><dd><?= $echapper(ucfirst($partenaire['niveau'] ?? 'partenaire')) ?></dd></div>
                        <div><dt>Évaluation moyenne</dt><dd><?= isset($partenaire['score']) ? number_format((float) $partenaire['score'], 1, ',', ' ') . '/5' : '—' ?></dd></div>
                        <div><dt>Membre depuis</dt><dd><?= !empty($partenaire['date_creation']) ? $echapper(date('d/m/Y', strtotime($partenaire['date_creation']))) : '—' ?></dd></div>
                    </dl>
                </section>

                <section class="profil-carte" aria-labelledby="profil-securite-titre">
                    <header class="profil-carte__entete">
                        <span><?= icone('shield', 19) ?></span>
                        <div><h2 id="profil-securite-titre">Sécurité du compte</h2><p>Changez votre mot de passe de connexion.</p></div>
                    </header>
                    <form method="POST" class="profil-formulaire">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                        <input type="hidden" name="action" value="mot_de_passe">
                        <div class="profil-champ">
                            <label for="profil-mot-de-passe-actuel">Mot de passe actuel</label>
                            <input id="profil-mot-de-passe-actuel" type="password" name="mot_de_passe_actuel" autocomplete="current-password" required>
                        </div>
                        <div class="profil-champ">
                            <label for="profil-nouveau-mot-de-passe">Nouveau mot de passe</label>
                            <input id="profil-nouveau-mot-de-passe" type="password" name="nouveau_mot_de_passe" minlength="8" autocomplete="new-password" required>
                            <small>8 caractères minimum.</small>
                        </div>
                        <div class="profil-champ">
                            <label for="profil-confirmation-mot-de-passe">Confirmer le nouveau mot de passe</label>
                            <input id="profil-confirmation-mot-de-passe" type="password" name="confirmation_mot_de_passe" minlength="8" autocomplete="new-password" required>
                        </div>
                        <button class="profil-bouton profil-bouton--secondaire" type="submit"><?= icone('key', 17) ?> Modifier le mot de passe</button>
                    </form>
                </section>
            </div>
        </div>
    </main>
</div>
</body>
</html>
