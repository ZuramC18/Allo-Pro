<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messagerie — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/messagerie-interne.css?v=<?= filemtime(__DIR__ . '/../../public/css/messagerie-interne.css') ?>">
</head>
<body class="page-partenaire-messagerie-interne">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>
    <main class="contenu contenu-messagerie">
        <?php include __DIR__ . '/../../includes/messagerie-interne-corps.php'; ?>
    </main>
</div>
<script src="../../public/js/messagerie-interne.js?v=<?= filemtime(__DIR__ . '/../../public/js/messagerie-interne.js') ?>"></script>
</body>
</html>