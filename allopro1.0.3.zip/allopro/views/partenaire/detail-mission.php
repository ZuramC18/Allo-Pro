<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../models/Technicien.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$interventionId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$interventionModel = new Intervention();
$technicienModel = new Technicien();
$mission = false;
$techniciens = [];
$erreur = '';
$csrfSession = 'csrf_partenaire_detail_mission';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}

if ($interventionId !== false && $interventionId !== null && $interventionId > 0) {
    $mission = $interventionModel->getMissionByIdEtPartenaire($interventionId, $partenaireId);
}

if ($mission && $mission['intervention_statut'] === 'acceptee') {
    $techniciens = $technicienModel->getActifsByPartenaire($partenaireId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mission) {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $technicienId = filter_var($_POST['technicien_id'] ?? null, FILTER_VALIDATE_INT);

    if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
        http_response_code(403);
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($mission['intervention_statut'] !== 'acceptee') {
        $erreur = 'Cette mission ne peut être redistribuée que lorsqu’elle est acceptée.';
    } elseif ($technicienId === false || $technicienId === null || $technicienId < 1) {
        $erreur = 'Sélectionnez un technicien valide.';
    } elseif ((int) ($mission['technicien_id'] ?? 0) === $technicienId) {
        $erreur = 'Sélectionnez un technicien différent de celui déjà affecté.';
    } else {
        try {
            if ($interventionModel->redistribuerMission($interventionId, $partenaireId, $technicienId)) {
                header('Location: detail-mission.php?id=' . $interventionId . '&redistribuee=1');
                exit;
            }
            $erreur = 'La mission n’a pas été redistribuée. Vérifiez son statut et le technicien sélectionné, puis réessayez.';
        } catch (PDOException $exception) {
            error_log('Redistribution mission ' . $interventionId . ' partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
            $erreur = 'Une erreur est survenue pendant la redistribution. Réessayez dans un instant.';
        }
    }
}

if (!$mission) {
    http_response_code(404);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $mission['intervention_statut'] === 'acceptee') {
    $techniciens = $technicienModel->getActifsByPartenaire($partenaireId);
}
$techniciensAlternatifs = array_values(array_filter(
    $techniciens,
    static fn($technicien) => (int) $technicien['id'] !== (int) ($mission['technicien_id'] ?? 0)
));

$statutsLibelles = [
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$libelleStatut = static fn(string $cle): string => $statutsLibelles[$cle] ?? ucfirst(str_replace('_', ' ', $cle));
$messageSucces = ($_GET['redistribuee'] ?? '') === '1';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $mission ? 'Mission ' . $echapper($mission['numero_dossier']) : 'Mission introuvable' ?> — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-detail-mission.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-detail-mission.css') ?>">
</head>
<body class="page-partenaire-detail-mission">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <a class="mission-detail-retour" href="missions.php"><?= icone('arrow', 16) ?> Retour à mes missions</a>
        <?php if (!$mission): ?>
            <section class="mission-detail-introuvable">
                <span><?= icone('alert', 25) ?></span>
                <h1>Mission introuvable</h1>
                <p>Cette mission n’existe pas ou n’appartient pas à votre entreprise.</p>
                <a href="missions.php">Revenir à mes missions</a>
            </section>
        <?php else: ?>
            <?php $statut = (string) $mission['intervention_statut']; ?>
            <?php if ($messageSucces): ?>
                <div class="mission-detail-message mission-detail-message--succes" role="status">La mission a bien été redistribuée au technicien sélectionné.</div>
            <?php endif; ?>
            <?php if ($erreur !== ''): ?>
                <div class="mission-detail-message mission-detail-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
            <?php endif; ?>
            <header class="mission-detail-entete">
                <div>
                    <div class="mission-detail-sur-titre">Détail de la mission</div>
                    <h1><?= $echapper($mission['numero_dossier']) ?></h1>
                    <p><?= $echapper($mission['categorie_nom']) ?><?php if (($mission['urgence'] ?? '') === 'urgente'): ?> <span class="mission-detail-urgence">Urgente</span><?php endif; ?></p>
                </div>
                <span class="mission-detail-statut mission-detail-statut--<?= $echapper($statut) ?>"><?= $echapper($libelleStatut($statut)) ?></span>
            </header>

            <div class="mission-detail-grille">
                <section class="mission-detail-carte" aria-labelledby="mission-infos-titre">
                    <header class="mission-detail-carte__entete">
                        <span><?= icone('clipboard', 18) ?></span>
                        <div><h2 id="mission-infos-titre">Informations de l’intervention</h2><p>Résumé de la demande du client</p></div>
                    </header>
                    <dl class="mission-detail-liste">
                        <div><dt>Client</dt><dd><?= $echapper($mission['client_nom']) ?></dd></div>
                        <div><dt>Adresse</dt><dd><?= $echapper(trim(($mission['quartier'] ?? '') . (!empty($mission['ville']) ? ', ' . $mission['ville'] : ''))) ?: 'Non renseignée' ?></dd></div>
                        <?php if (!empty($mission['adresse_details'])): ?><div><dt>Précisions d’accès</dt><dd><?= $echapper($mission['adresse_details']) ?></dd></div><?php endif; ?>
                        <div><dt>Créée le</dt><dd><?= !empty($mission['date_creation']) ? $echapper(date('d/m/Y à H:i', strtotime($mission['date_creation']))) : 'Non renseignée' ?></dd></div>
                        <div><dt>Début d’intervention</dt><dd><?= !empty($mission['date_debut']) ? $echapper(date('d/m/Y à H:i', strtotime($mission['date_debut']))) : 'Non renseigné' ?></dd></div>
                        <div><dt>Mode de paiement</dt><dd><?= $echapper(ucfirst(str_replace('_', ' ', (string) ($mission['mode_paiement'] ?? 'normal')))) ?></dd></div>
                        <div class="mission-detail-liste__description"><dt>Description</dt><dd><?= $echapper($mission['description'] ?? '') ?: 'Aucune description fournie.' ?></dd></div>
                    </dl>
                    <div class="mission-detail-client">
                        <strong>Contacter le client</strong>
                        <div>
                            <?php if (!empty($mission['client_telephone'])): ?><a href="tel:<?= $echapper(preg_replace('/[^0-9+]/', '', $mission['client_telephone'])) ?>"><?= icone('messages', 16) ?> <?= $echapper($mission['client_telephone']) ?></a><?php endif; ?>
                            <?php if (!empty($mission['client_email'])): ?><a href="mailto:<?= $echapper($mission['client_email']) ?>"><?= icone('message', 16) ?> <?= $echapper($mission['client_email']) ?></a><?php endif; ?>
                        </div>
                    </div>
                </section>

                <aside class="mission-detail-carte mission-detail-affectation" aria-labelledby="affectation-titre">
                    <header class="mission-detail-carte__entete">
                        <span><?= icone('users', 18) ?></span>
                        <div><h2 id="affectation-titre">Technicien affecté</h2><p>Affectation actuelle de la mission</p></div>
                    </header>
                    <div class="mission-detail-technicien">
                        <span class="mission-detail-technicien__avatar"><?= $echapper(mb_strtoupper(mb_substr($mission['technicien_nom'] ?? '?', 0, 1))) ?></span>
                        <div>
                            <strong><?= $echapper($mission['technicien_nom'] ?? 'Aucun technicien affecté') ?></strong>
                            <span><?= $mission['technicien_id'] ? 'Technicien de votre équipe' : 'Affectation à compléter' ?></span>
                        </div>
                    </div>
                    <?php if ($statut === 'acceptee'): ?>
                        <?php if (!$techniciensAlternatifs): ?>
                            <p class="mission-detail-info">Aucun autre technicien actif dans votre équipe ne peut recevoir cette mission.</p>
                        <?php else: ?>
                            <form method="POST" class="mission-detail-form">
                                <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                <label for="technicien-id">Redistribuer à</label>
                                <select id="technicien-id" name="technicien_id" required>
                                    <option value="">Choisir un technicien actif</option>
                                    <?php foreach ($techniciensAlternatifs as $technicien): ?>
                                        <option value="<?= (int) $technicien['id'] ?>" <?= (string) ($_POST['technicien_id'] ?? '') === (string) $technicien['id'] ? 'selected' : '' ?>>
                                            <?= $echapper($technicien['nom']) ?><?= !empty($technicien['categorie_nom']) ? ' · ' . $echapper($technicien['categorie_nom']) : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p>La redistribution est disponible tant que la mission est encore acceptée.</p>
                                <button type="submit"><?= icone('refresh', 17) ?> Redistribuer la mission</button>
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="mission-detail-info">La redistribution n’est possible que lorsque la mission est au statut « Acceptée ».</p>
                    <?php endif; ?>
                </aside>
            </div>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
