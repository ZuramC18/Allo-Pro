ALTER TABLE tickets_sav
    ADD COLUMN categorie_qualite ENUM(
        'mauvaise_experience',
        'reclamation',
        'incident',
        'retard',
        'intervention_incomplete',
        'reintervention',
        'litige',
        'remboursement'
    ) NOT NULL DEFAULT 'reclamation' AFTER motif;

CREATE TABLE remboursements_sav (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    ticket_sav_id INT NOT NULL,
    montant_demande DECIMAL(12, 2) NOT NULL,
    motif TEXT NOT NULL,
    statut ENUM('en_attente', 'autorise', 'refuse') NOT NULL DEFAULT 'en_attente',
    demande_par_user_id INT NOT NULL,
    date_demande TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    decide_par_user_id INT NULL,
    date_decision DATETIME NULL,
    commentaire_decision TEXT NULL,
    PRIMARY KEY (id),
    INDEX idx_remboursements_sav_statut (statut, date_demande),
    INDEX idx_remboursements_sav_ticket (ticket_sav_id, date_demande),
    CONSTRAINT fk_remboursements_sav_ticket
        FOREIGN KEY (ticket_sav_id) REFERENCES tickets_sav(id) ON DELETE CASCADE,
    CONSTRAINT fk_remboursements_sav_demandeur
        FOREIGN KEY (demande_par_user_id) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_remboursements_sav_decideur
        FOREIGN KEY (decide_par_user_id) REFERENCES users(id) ON DELETE SET NULL
);

INSERT IGNORE INTO role_permissions (role, module) VALUES
    ('qualite', 'sav'),
    ('qualite', 'tableau_bord'),
    ('finance', 'remboursements_sav');
