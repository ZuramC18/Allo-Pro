CREATE TABLE notes_automatiques_interventions (
    id INT NOT NULL AUTO_INCREMENT,
    client_id INT NOT NULL,
    demande_id INT NOT NULL,
    intervention_id INT NOT NULL,
    contenu TEXT NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_notes_auto_intervention (intervention_id),
    KEY idx_notes_auto_client_date (client_id, date_creation),
    CONSTRAINT fk_notes_auto_client
        FOREIGN KEY (client_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_notes_auto_demande
        FOREIGN KEY (demande_id) REFERENCES demandes (id) ON DELETE CASCADE,
    CONSTRAINT fk_notes_auto_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
