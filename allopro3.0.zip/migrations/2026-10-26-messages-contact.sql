CREATE TABLE IF NOT EXISTS messages_contact (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nom VARCHAR(120) NOT NULL,
    email VARCHAR(254) NOT NULL,
    telephone VARCHAR(30) NULL,
    raison VARCHAR(60) NOT NULL,
    sujet VARCHAR(160) NOT NULL,
    message TEXT NOT NULL,
    statut ENUM('nouveau', 'lu') NOT NULL DEFAULT 'nouveau',
    date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_lecture DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_messages_contact_statut_date (statut, date_creation),
    KEY idx_messages_contact_date (date_creation)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
