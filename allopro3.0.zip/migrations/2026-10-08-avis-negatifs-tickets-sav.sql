INSERT INTO tickets_sav (demande_id, motif, statut, origine)
SELECT n.demande_id, CONCAT('Avis client négatif (', n.note, '/5)'), 'ouvert', 'client'
FROM notes n
JOIN demandes d ON d.id = n.demande_id AND d.statut = 'terminee'
WHERE n.note <= 2
  AND NOT EXISTS (
      SELECT 1
      FROM tickets_sav t
      WHERE t.demande_id = n.demande_id
  );
