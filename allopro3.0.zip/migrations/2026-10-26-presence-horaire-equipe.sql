CREATE TABLE IF NOT EXISTS temps_presence_conseillers (
    conseiller_id INT NOT NULL,
    date_presence DATE NOT NULL,
    secondes_en_ligne INT UNSIGNED NOT NULL DEFAULT 0,
    secondes_en_pause INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (conseiller_id, date_presence),
    KEY idx_temps_presence_date (date_presence),
    CONSTRAINT fk_temps_presence_conseiller
        FOREIGN KEY (conseiller_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS temps_presence_equipe_heures (
    user_id INT NOT NULL,
    date_presence DATE NOT NULL,
    heure TINYINT UNSIGNED NOT NULL,
    secondes_en_ligne INT UNSIGNED NOT NULL DEFAULT 0,
    secondes_en_pause INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, date_presence, heure),
    KEY idx_presence_equipe_heures_date (date_presence, heure),
    CONSTRAINT fk_presence_equipe_heures_user
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
