CREATE TABLE IF NOT EXISTS partenaire_zones (
    partenaire_id INT NOT NULL,
    zone_id INT NOT NULL,
    PRIMARY KEY (partenaire_id, zone_id),
    KEY idx_partenaire_zones_zone (zone_id),
    CONSTRAINT fk_partenaire_zones_partenaire
        FOREIGN KEY (partenaire_id) REFERENCES partenaires (id) ON DELETE CASCADE,
    CONSTRAINT fk_partenaire_zones_zone
        FOREIGN KEY (zone_id) REFERENCES zones (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO partenaire_zones (partenaire_id, zone_id)
SELECT p.id, z.id
FROM partenaires p
JOIN zones z
  ON z.type IN ('zone', 'quartier')
 AND z.statut = 'active'
 AND (
     LOWER(TRIM(z.nom)) = LOWER(TRIM(p.zone_intervention))
     OR LOWER(TRIM(z.nom)) = CONCAT(LOWER(TRIM(p.zone_intervention)), 's')
 );

INSERT IGNORE INTO partenaire_zones (partenaire_id, zone_id)
SELECT p.id, z.id
FROM partenaires p
JOIN zones z ON z.type IN ('zone', 'quartier') AND z.statut = 'active'
WHERE LOWER(TRIM(p.zone_intervention)) IN (
    'dakar',
    'region de dakar',
    'dakar et sa region',
    'dakar et sa banlieue',
    'toute la region de dakar'
);

ALTER TABLE partenaires
    DROP COLUMN zone_intervention;
