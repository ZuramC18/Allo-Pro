ALTER TABLE entreprises_b2b_membres ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS entreprises_b2b_membres_permissions (
    entreprise_b2b_id INT NOT NULL,
    user_id INT NOT NULL,
    permission_key VARCHAR(32) NOT NULL,
    autorise TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (entreprise_b2b_id, user_id, permission_key),
    INDEX idx_entreprises_b2b_permissions_membre (entreprise_b2b_id, user_id, autorise),
    CONSTRAINT fk_entreprises_b2b_permissions_entreprise
        FOREIGN KEY (entreprise_b2b_id) REFERENCES entreprises_b2b(id) ON DELETE CASCADE,
    CONSTRAINT fk_entreprises_b2b_permissions_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO entreprises_b2b_membres_permissions
    (entreprise_b2b_id, user_id, permission_key, autorise)
SELECT m.entreprise_b2b_id, m.user_id, p.permission_key,
       IF(p.permission_key IN ('accueil', 'sites', 'demandes', 'devis', 'interventions', 'historique', 'documents'), 1, 0)
FROM entreprises_b2b_membres m
CROSS JOIN (
    SELECT 'accueil' AS permission_key
    UNION ALL SELECT 'sites'
    UNION ALL SELECT 'demandes'
    UNION ALL SELECT 'devis'
    UNION ALL SELECT 'tickets'
    UNION ALL SELECT 'interventions'
    UNION ALL SELECT 'contrats'
    UNION ALL SELECT 'factures'
    UNION ALL SELECT 'paiements'
    UNION ALL SELECT 'rapports'
    UNION ALL SELECT 'historique'
    UNION ALL SELECT 'documents'
    UNION ALL SELECT 'parametres'
) p
WHERE m.statut = 'actif' AND m.role = 'membre';

UPDATE entreprises_b2b_membres_permissions p
JOIN entreprises_b2b_membres m
  ON m.entreprise_b2b_id = p.entreprise_b2b_id AND m.user_id = p.user_id
SET p.autorise = 1
WHERE m.statut = 'actif' AND m.role = 'membre'
  AND p.permission_key IN ('accueil', 'sites', 'demandes', 'devis', 'interventions', 'historique', 'documents');
