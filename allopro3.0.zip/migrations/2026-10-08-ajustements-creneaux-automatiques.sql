CREATE TABLE IF NOT EXISTS ajustements_creneaux_automatiques (
    id INT NOT NULL AUTO_INCREMENT,
    demande_id INT NOT NULL,
    intervention_id INT NOT NULL,
    technicien_id INT NOT NULL,
    date_creneau_demande DATE NOT NULL,
    heure_creneau_demandee TINYINT UNSIGNED NOT NULL,
    date_creneau_attribue DATE NOT NULL,
    heure_creneau_attribuee TINYINT UNSIGNED NOT NULL,
    statut ENUM('a_traiter', 'traitee') NOT NULL DEFAULT 'a_traiter',
    traitee_par INT NULL,
    date_traitement TIMESTAMP NULL DEFAULT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_ajustements_creneaux_statut_date (statut, date_creation),
    KEY idx_ajustements_creneaux_demande (demande_id, date_creation),
    CONSTRAINT fk_ajustements_creneaux_demande
        FOREIGN KEY (demande_id) REFERENCES demandes (id) ON DELETE CASCADE,
    CONSTRAINT fk_ajustements_creneaux_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE CASCADE,
    CONSTRAINT fk_ajustements_creneaux_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id) ON DELETE RESTRICT,
    CONSTRAINT fk_ajustements_creneaux_utilisateur
        FOREIGN KEY (traitee_par) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
