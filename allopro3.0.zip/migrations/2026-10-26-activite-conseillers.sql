CREATE TABLE IF NOT EXISTS activites_conseillers (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    conseiller_id INT NOT NULL,
    type ENUM('page', 'presence', 'deconnexion') NOT NULL,
    cible VARCHAR(120) NOT NULL,
    detail VARCHAR(255) NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_activites_conseiller_date (conseiller_id, date_creation),
    KEY idx_activites_type_date (type, date_creation),
    CONSTRAINT fk_activites_conseiller
        FOREIGN KEY (conseiller_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
