-- Complément OpenStreetMap (ODbL 1.0, © contributeurs) : secteurs et quartiers
-- cartographiés sous forme de polygones dans l'emprise de la région de Dakar.
INSERT INTO zones (nom, ville, pays, statut, type, osm_id)
SELECT osm.nom, 'Région de Dakar', 'Sénégal', 'active', osm.zone_type, osm.osm_id
FROM (
    SELECT 'BAGDAD' AS nom, 'quartier' AS zone_type, 1463235739 AS osm_id
    UNION ALL SELECT 'BGAZELLE I', 'quartier', 1463235730
    UNION ALL SELECT 'Cité ASECNA Ouakam', 'quartier', 402218397
    UNION ALL SELECT 'Cité ASECNA Yoff', 'quartier', 401505180
    UNION ALL SELECT 'Cité Barry et Ly', 'quartier', 385869090
    UNION ALL SELECT 'CITE BASTOS I', 'quartier', 1463235752
    UNION ALL SELECT 'CITE BASTOS II VILLA', 'quartier', 1463235766
    UNION ALL SELECT 'Cité Biagui', 'quartier', 369004243
    UNION ALL SELECT 'Cité Cheikh Amar', 'quartier', 860670561
    UNION ALL SELECT 'Cité des enseignants du supérieur', 'quartier', 808086798
    UNION ALL SELECT 'Cité Djily Mbaye', 'quartier', 368797974
    UNION ALL SELECT 'Cité du Golf', 'quartier', 5386793
    UNION ALL SELECT 'Cité Institut Pasteur de Fass Mbao', 'quartier', 546917868
    UNION ALL SELECT 'CITE KERETOU', 'quartier', 1463235733
    UNION ALL SELECT 'Cité Mixta', 'quartier', 478147734
    UNION ALL SELECT 'Cité SICA SIPRES II', 'quartier', 402222105
    UNION ALL SELECT 'CITE SIPRES I', 'quartier', 1463235762
    UNION ALL SELECT 'CITE SIPRES II SICA', 'quartier', 1463235709
    UNION ALL SELECT 'CITE SONATEL I', 'quartier', 1463235760
    UNION ALL SELECT 'DAROU SALAM II', 'quartier', 1463235757
    UNION ALL SELECT 'DAROU SALAM III', 'quartier', 1463235723
    UNION ALL SELECT 'DAROURAKHMANE I', 'quartier', 1463235737
    UNION ALL SELECT 'DAROURAKHMANE II', 'quartier', 1463235749
    UNION ALL SELECT 'Diamalaye', 'quartier', 369004246
    UNION ALL SELECT 'DJEDDAH', 'quartier', 1463235718
    UNION ALL SELECT 'GRAND YOFF LEONA', 'quartier', 1463235741
    UNION ALL SELECT 'HAMO GRAND YOFF', 'quartier', 1463235753
    UNION ALL SELECT 'HLM GRAND YOFF I', 'quartier', 1463235750
    UNION ALL SELECT 'HLM GRAND YOFF II', 'quartier', 1463235742
    UNION ALL SELECT 'HLM GRAND YOFF II (CITE ASSANE DIOP)', 'quartier', 1463235720
    UNION ALL SELECT 'HLM GRAND YOFF III', 'quartier', 1463235706
    UNION ALL SELECT 'HLM PATTE D''OIE', 'quartier', 1463235745
    UNION ALL SELECT 'HLM SHELTER II', 'quartier', 1463235712
    UNION ALL SELECT 'KHAR YALLA I', 'quartier', 1463235759
    UNION ALL SELECT 'KHAR YALLA II', 'quartier', 1463235710
    UNION ALL SELECT 'Liberté 6 Extension', 'zone', 279672623
    UNION ALL SELECT 'MAKA II', 'quartier', 1463235748
    UNION ALL SELECT 'MAKA III', 'quartier', 1463235735
    UNION ALL SELECT 'Mbao', 'quartier', 539987186
    UNION ALL SELECT 'MISSRAH', 'quartier', 1463235711
    UNION ALL SELECT 'Nord Foire', 'quartier', 369004250
    UNION ALL SELECT 'Ouest Foire', 'quartier', 369004252
    UNION ALL SELECT 'Quartier Marième Faye Sall', 'quartier', 509326788
    UNION ALL SELECT 'Sacré Coeur 2', 'zone', 279672169
    UNION ALL SELECT 'Sacré Coeur 3', 'zone', 279672366
    UNION ALL SELECT 'Sacré Coeur 3 Pyrotechnie', 'zone', 279672170
    UNION ALL SELECT 'Sacré Cœur 3 VDN', 'quartier', 5386698
    UNION ALL SELECT 'Sacré-Cœur 1', 'zone', 54269408
    UNION ALL SELECT 'SANTHIABA', 'quartier', 1463235740
    UNION ALL SELECT 'Scat Urbam', 'quartier', 1463235703
    UNION ALL SELECT 'SCAT URBAM (CITE CONACHAP)', 'quartier', 1463235724
    UNION ALL SELECT 'SCAT URBAM (CITE FOUGEROLLE)', 'quartier', 1463235738
    UNION ALL SELECT 'SCAT URBAM (CITE KEUR KHADIM II)', 'quartier', 1463235767
    UNION ALL SELECT 'SCAT URBAM (ILOT B)', 'quartier', 1463235732
    UNION ALL SELECT 'SCAT URBAM (ILOT C)', 'quartier', 1463235728
    UNION ALL SELECT 'SCAT URBAM (ILOT D)', 'quartier', 1463235729
    UNION ALL SELECT 'SCAT URBAM (ILOT F)', 'quartier', 1463235758
    UNION ALL SELECT 'SCAT URBAM (ILOT G)', 'quartier', 1463235743
    UNION ALL SELECT 'SCAT URBAM (ILOT M)', 'quartier', 1463235721
    UNION ALL SELECT 'SCAT URBAM (ILOT N)', 'quartier', 1463235761
    UNION ALL SELECT 'SCAT URBAM ARAFAT', 'quartier', 1463235727
    UNION ALL SELECT 'SHELTER (ZONE COMMERCIALE)', 'quartier', 1463235713
    UNION ALL SELECT 'SUD FOIRE (CITE CSE)', 'quartier', 1463235725
    UNION ALL SELECT 'SUD FOIRE (CITE LIBASSE NIANG)', 'quartier', 1463235719
    UNION ALL SELECT 'SUD FOIRE (CITE SONATEL II)', 'quartier', 1463235751
    UNION ALL SELECT 'SUD FOIRE (CITE SONATEL III)', 'quartier', 1463235765
    UNION ALL SELECT 'TAIBA I', 'quartier', 1463235716
    UNION ALL SELECT 'TAIBA II', 'quartier', 1463235717
    UNION ALL SELECT 'TAIBA IV', 'quartier', 1463235731
    UNION ALL SELECT 'Unite 14', 'quartier', 545141978
    UNION ALL SELECT 'unite 17', 'quartier', 545141977
    UNION ALL SELECT 'Unite 18', 'quartier', 545141976
    UNION ALL SELECT 'Unite 23', 'quartier', 545141971
    UNION ALL SELECT 'Yoff Layéne', 'quartier', 7132804
    UNION ALL SELECT 'Yoff Mbenguéne', 'quartier', 7006930
    UNION ALL SELECT 'Yoff Ndeungagne', 'quartier', 7006931
    UNION ALL SELECT 'Yoff Ngaparou', 'quartier', 7132805
    UNION ALL SELECT 'Yoff Tonghor', 'quartier', 369004272
    UNION ALL SELECT 'Yyoff Apecsy', 'quartier', 369004275
    UNION ALL SELECT 'Zone De Captage', 'quartier', 1463235744
) AS osm
WHERE NOT EXISTS (
    SELECT 1
    FROM zones existante
    WHERE existante.osm_id = osm.osm_id
       OR (existante.parent_id = (SELECT id FROM zones WHERE osm_id = 2892079)
           AND existante.nom = osm.nom)
);

UPDATE zones enfants
JOIN zones ville ON ville.osm_id = 2892079
SET enfants.parent_id = ville.id
WHERE enfants.osm_id IS NOT NULL AND enfants.osm_id <> 2892079;
