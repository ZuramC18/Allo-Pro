CREATE TABLE IF NOT EXISTS reversements_techniciens (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    intervention_id INT NOT NULL,
    partenaire_id INT NOT NULL,
    technicien_id INT NOT NULL,
    montant DECIMAL(10,2) NOT NULL,
    methode ENUM('especes', 'wave', 'orange_money', 'virement', 'autre') NOT NULL,
    reference VARCHAR(100) NULL,
    date_paiement DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_reversements_techniciens_intervention (intervention_id),
    KEY idx_reversements_techniciens_partenaire_date (partenaire_id, date_paiement),
    KEY idx_reversements_techniciens_technicien_date (technicien_id, date_paiement),
    CONSTRAINT fk_reversements_techniciens_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE RESTRICT,
    CONSTRAINT fk_reversements_techniciens_partenaire
        FOREIGN KEY (partenaire_id) REFERENCES partenaires (id) ON DELETE RESTRICT,
    CONSTRAINT fk_reversements_techniciens_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id) ON DELETE RESTRICT,
    CONSTRAINT chk_reversements_techniciens_montant CHECK (montant > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
