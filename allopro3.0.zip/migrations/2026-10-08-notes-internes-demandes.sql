CREATE TABLE IF NOT EXISTS notes_demandes (
    id INT NOT NULL AUTO_INCREMENT,
    demande_id INT NOT NULL,
    auteur_id INT NOT NULL,
    note TEXT NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_notes_demandes_demande_date (demande_id, date_creation),
    CONSTRAINT fk_notes_demandes_demande
        FOREIGN KEY (demande_id) REFERENCES demandes (id) ON DELETE CASCADE,
    CONSTRAINT fk_notes_demandes_auteur
        FOREIGN KEY (auteur_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
