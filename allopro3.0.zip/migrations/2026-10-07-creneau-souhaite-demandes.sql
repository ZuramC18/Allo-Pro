ALTER TABLE demandes
    ADD COLUMN date_creneau_souhaite DATE NULL AFTER urgence,
    ADD COLUMN heure_creneau_souhaitee TINYINT UNSIGNED NULL AFTER date_creneau_souhaite;
