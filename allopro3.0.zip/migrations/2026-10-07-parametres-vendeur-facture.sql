CREATE TABLE parametres_facturation (
    id TINYINT UNSIGNED NOT NULL,
    vendeur_nom VARCHAR(150) NOT NULL DEFAULT 'ALLÔ PRO',
    vendeur_identifiant VARCHAR(100) NULL,
    vendeur_adresse VARCHAR(255) NULL,
    vendeur_telephone VARCHAR(30) NULL,
    vendeur_email VARCHAR(150) NULL,
    modifie_par INT NULL,
    date_modification TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_parametres_facturation_admin
        FOREIGN KEY (modifie_par) REFERENCES users(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO parametres_facturation (id, vendeur_nom)
VALUES (1, 'ALLÔ PRO');
