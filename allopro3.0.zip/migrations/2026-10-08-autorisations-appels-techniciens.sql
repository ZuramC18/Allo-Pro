ALTER TABLE messagerie_appels_web
    DROP FOREIGN KEY fk_appels_web_appelant,
    MODIFY appelant_id INT NULL,
    ADD appelant_technicien_id INT NULL AFTER appelant_id,
    ADD intervention_id INT NULL AFTER client_id,
    ADD KEY idx_appels_web_intervention (intervention_id),
    ADD KEY idx_appels_web_appelant_technicien (appelant_technicien_id, statut),
    ADD CONSTRAINT fk_appels_web_appelant_user
        FOREIGN KEY (appelant_id) REFERENCES users (id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_appels_web_appelant_technicien
        FOREIGN KEY (appelant_technicien_id) REFERENCES techniciens (id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_appels_web_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE SET NULL;

ALTER TABLE messagerie_appels_web_signaux
    DROP FOREIGN KEY fk_appels_web_signaux_user,
    MODIFY expediteur_id INT NULL,
    ADD expediteur_technicien_id INT NULL AFTER expediteur_id,
    ADD KEY idx_appels_web_signaux_technicien (expediteur_technicien_id),
    ADD CONSTRAINT fk_appels_web_signaux_technicien
        FOREIGN KEY (expediteur_technicien_id) REFERENCES techniciens (id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_appels_web_signaux_user_new
        FOREIGN KEY (expediteur_id) REFERENCES users (id) ON DELETE CASCADE;

ALTER TABLE messagerie_appels_web_presence
    DROP FOREIGN KEY fk_appels_web_presence_user,
    DROP PRIMARY KEY,
    MODIFY user_id INT NULL,
    ADD technicien_id INT NULL AFTER user_id,
    ADD presence_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST,
    ADD UNIQUE KEY uq_appels_web_presence_user (user_id),
    ADD UNIQUE KEY uq_appels_web_presence_technicien (technicien_id),
    ADD CONSTRAINT fk_appels_web_presence_user_new
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_appels_web_presence_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id) ON DELETE CASCADE;

CREATE TABLE autorisations_appels_web_techniciens (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    intervention_id INT NOT NULL,
    client_id INT NOT NULL,
    technicien_id INT NOT NULL,
    autorise_par INT NOT NULL,
    autorise_par_role ENUM('admin', 'coordinateur') NOT NULL,
    date_autorisation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revoque_par INT NULL,
    date_revocation DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_autorisation_appel_intervention (intervention_id),
    KEY idx_autorisation_appel_active (technicien_id, date_revocation),
    CONSTRAINT fk_autorisation_appel_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE CASCADE,
    CONSTRAINT fk_autorisation_appel_client
        FOREIGN KEY (client_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_autorisation_appel_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id) ON DELETE CASCADE,
    CONSTRAINT fk_autorisation_appel_auteur
        FOREIGN KEY (autorise_par) REFERENCES users (id),
    CONSTRAINT fk_autorisation_appel_revocation
        FOREIGN KEY (revoque_par) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
