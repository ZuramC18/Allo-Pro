CREATE TABLE entreprises_b2b_invitations (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    entreprise_b2b_id INT NOT NULL,
    invitee_user_id INT NOT NULL,
    invite_par_user_id INT NULL,
    statut ENUM('en_attente', 'acceptee', 'refusee', 'annulee') NOT NULL DEFAULT 'en_attente',
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_reponse DATETIME NULL,
    PRIMARY KEY (id),
    INDEX idx_entreprises_b2b_invitations_invitee (invitee_user_id, statut, date_creation),
    INDEX idx_entreprises_b2b_invitations_entreprise (entreprise_b2b_id, statut, date_creation),
    CONSTRAINT fk_entreprises_b2b_invitations_entreprise
        FOREIGN KEY (entreprise_b2b_id) REFERENCES entreprises_b2b(id) ON DELETE CASCADE,
    CONSTRAINT fk_entreprises_b2b_invitations_invitee
        FOREIGN KEY (invitee_user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_entreprises_b2b_invitations_auteur
        FOREIGN KEY (invite_par_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
