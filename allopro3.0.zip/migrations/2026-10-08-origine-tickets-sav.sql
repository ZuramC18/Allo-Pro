ALTER TABLE tickets_sav
    ADD COLUMN origine ENUM(
        'client',
        'conseiller',
        'coordinateur',
        'entreprise',
        'historique'
    ) NOT NULL DEFAULT 'historique' AFTER statut,
    ADD INDEX idx_tickets_sav_origine_date (origine, date_creation);
