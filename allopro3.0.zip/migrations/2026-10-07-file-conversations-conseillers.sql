-- Configure public/cron-attribution-conversations.php to run with PHP CLI every minute.
ALTER TABLE users
    ADD COLUMN conversation_en_attente_depuis DATETIME NULL DEFAULT NULL;

UPDATE users c
SET c.conversation_en_attente_depuis = COALESCE(
    (
        SELECT MIN(m.date_creation)
        FROM messages m
        WHERE m.client_id = c.id AND m.expediteur_type = 'client'
    ),
    NOW()
)
WHERE c.role = 'client'
  AND c.conversation_statut = 'ouverte'
  AND c.conseiller_assigne_id IS NULL;
