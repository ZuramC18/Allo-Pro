ALTER TABLE taches
    DROP CHECK chk_taches_un_proprietaire,
    ADD finance_id INT NULL AFTER coordinateur_id,
    ADD INDEX idx_taches_finance_id (finance_id),
    ADD CONSTRAINT taches_ibfk_finance
        FOREIGN KEY (finance_id) REFERENCES users (id) ON DELETE CASCADE,
    ADD CONSTRAINT chk_taches_un_proprietaire CHECK (
        (technicien_id IS NOT NULL AND partenaire_id IS NULL AND coordinateur_id IS NULL AND finance_id IS NULL)
        OR (technicien_id IS NULL AND partenaire_id IS NOT NULL AND coordinateur_id IS NULL AND finance_id IS NULL)
        OR (technicien_id IS NULL AND partenaire_id IS NULL AND coordinateur_id IS NOT NULL AND finance_id IS NULL)
        OR (technicien_id IS NULL AND partenaire_id IS NULL AND coordinateur_id IS NULL AND finance_id IS NOT NULL)
    );
