CREATE TABLE IF NOT EXISTS technicien_competences (
    technicien_id INT NOT NULL,
    categorie_id INT NOT NULL,
    PRIMARY KEY (technicien_id, categorie_id),
    KEY idx_technicien_competences_categorie (categorie_id),
    CONSTRAINT fk_technicien_competences_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id) ON DELETE CASCADE,
    CONSTRAINT fk_technicien_competences_categorie
        FOREIGN KEY (categorie_id) REFERENCES categories (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO technicien_competences (technicien_id, categorie_id)
SELECT id, categorie_id
FROM techniciens
WHERE categorie_id IS NOT NULL;

ALTER TABLE techniciens
    DROP FOREIGN KEY fk_technicien_categorie,
    DROP COLUMN categorie_id;
