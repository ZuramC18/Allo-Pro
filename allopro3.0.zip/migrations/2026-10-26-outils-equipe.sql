CREATE TABLE IF NOT EXISTS outils_equipe_taches (
    id INT NOT NULL AUTO_INCREMENT,
    titre VARCHAR(160) NOT NULL,
    description TEXT NULL,
    assigne_a INT NOT NULL,
    cree_par INT NOT NULL,
    date_echeance DATE NULL,
    statut ENUM('a_faire', 'terminee') NOT NULL DEFAULT 'a_faire',
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_completion DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_outils_taches_assigne_statut (assigne_a, statut, date_echeance),
    KEY idx_outils_taches_auteur (cree_par),
    CONSTRAINT fk_outils_taches_assigne FOREIGN KEY (assigne_a) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_outils_taches_auteur FOREIGN KEY (cree_par) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS passations_demandes (
    id INT NOT NULL AUTO_INCREMENT,
    demande_id INT NOT NULL,
    auteur_id INT NOT NULL,
    note TEXT NOT NULL,
    prochaine_action VARCHAR(500) NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_passations_demande_date (demande_id, date_creation),
    CONSTRAINT fk_passations_demande FOREIGN KEY (demande_id) REFERENCES demandes (id) ON DELETE CASCADE,
    CONSTRAINT fk_passations_auteur FOREIGN KEY (auteur_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS procedures_equipe (
    id INT NOT NULL AUTO_INCREMENT,
    titre VARCHAR(160) NOT NULL,
    contenu MEDIUMTEXT NOT NULL,
    auteur_id INT NOT NULL,
    modifie_par INT NOT NULL,
    publie TINYINT(1) NOT NULL DEFAULT 1,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_procedures_publie_titre (publie, titre),
    CONSTRAINT fk_procedures_auteur FOREIGN KEY (auteur_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_procedures_modifie_par FOREIGN KEY (modifie_par) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS annonces_equipe (
    id INT NOT NULL AUTO_INCREMENT,
    titre VARCHAR(160) NOT NULL,
    contenu MEDIUMTEXT NOT NULL,
    auteur_id INT NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_annonces_equipe_date (date_creation),
    CONSTRAINT fk_annonces_equipe_auteur FOREIGN KEY (auteur_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS annonces_equipe_lectures (
    id INT NOT NULL AUTO_INCREMENT,
    annonce_id INT NOT NULL,
    user_id INT NOT NULL,
    date_lecture TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_annonce_lecture_user (annonce_id, user_id),
    KEY idx_annonce_lectures_user (user_id, date_lecture),
    CONSTRAINT fk_annonce_lectures_annonce FOREIGN KEY (annonce_id) REFERENCES annonces_equipe (id) ON DELETE CASCADE,
    CONSTRAINT fk_annonce_lectures_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE reponses_rapides
    ADD COLUMN est_prive TINYINT(1) NOT NULL DEFAULT 0 AFTER cree_par_id,
    ADD KEY idx_reponses_rapides_visibilite (est_prive, cree_par_type, cree_par_id);
