CREATE TABLE parametres_email (
    id TINYINT UNSIGNED NOT NULL,
    compte_google VARCHAR(254) NOT NULL,
    mot_de_passe_chiffre VARCHAR(255) NOT NULL,
    modifie_par INT NULL,
    date_modification TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_parametres_email_admin
        FOREIGN KEY (modifie_par) REFERENCES users(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
