ALTER TABLE interventions
    MODIFY COLUMN statut ENUM(
        'en_attente',
        'acceptee',
        'en_route',
        'arrive',
        'diagnostic',
        'en_cours',
        'terminee',
        'refusee',
        'annulee'
    ) NOT NULL DEFAULT 'en_attente',
    ADD COLUMN date_decision_technicien DATETIME NULL AFTER date_debut;

UPDATE interventions
SET statut = 'en_attente'
WHERE statut = '';

CREATE TABLE IF NOT EXISTS file_attente_interventions (
    id INT NOT NULL AUTO_INCREMENT,
    intervention_id INT NOT NULL,
    technicien_id INT NOT NULL,
    motif TEXT NULL,
    statut ENUM('en_attente', 'traitee') NOT NULL DEFAULT 'en_attente',
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_traitement DATETIME NULL,
    coordinateur_id INT NULL,
    PRIMARY KEY (id),
    KEY idx_file_attente_interventions_statut_date (statut, date_creation),
    KEY idx_file_attente_interventions_intervention (intervention_id),
    KEY idx_file_attente_interventions_technicien (technicien_id),
    CONSTRAINT fk_file_attente_interventions_intervention
        FOREIGN KEY (intervention_id) REFERENCES interventions (id) ON DELETE CASCADE,
    CONSTRAINT fk_file_attente_interventions_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id),
    CONSTRAINT fk_file_attente_interventions_coordinateur
        FOREIGN KEY (coordinateur_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
