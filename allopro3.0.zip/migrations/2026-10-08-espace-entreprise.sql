ALTER TABLE entreprises_b2b
    ADD COLUMN cree_par_user_id INT NULL AFTER interlocuteur_email,
    ADD INDEX idx_entreprises_b2b_createur (cree_par_user_id),
    ADD CONSTRAINT fk_entreprises_b2b_createur
        FOREIGN KEY (cree_par_user_id) REFERENCES users(id) ON DELETE SET NULL;

CREATE TABLE entreprises_b2b_membres (
    entreprise_b2b_id INT NOT NULL,
    user_id INT NOT NULL,
    role ENUM('admin', 'membre') NOT NULL DEFAULT 'membre',
    statut ENUM('actif', 'revoque') NOT NULL DEFAULT 'actif',
    ajoute_par_user_id INT NULL,
    date_ajout TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_revocation DATETIME NULL,
    PRIMARY KEY (entreprise_b2b_id, user_id),
    INDEX idx_entreprises_b2b_membres_user (user_id, statut),
    CONSTRAINT fk_entreprises_b2b_membres_entreprise
        FOREIGN KEY (entreprise_b2b_id) REFERENCES entreprises_b2b(id) ON DELETE CASCADE,
    CONSTRAINT fk_entreprises_b2b_membres_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_entreprises_b2b_membres_ajoute_par
        FOREIGN KEY (ajoute_par_user_id) REFERENCES users(id) ON DELETE SET NULL
);

ALTER TABLE sites_b2b
    ADD COLUMN adresse_id INT NULL AFTER entreprise_b2b_id,
    ADD COLUMN details TEXT NULL AFTER ville,
    ADD COLUMN telephone_contact VARCHAR(20) NULL AFTER details,
    ADD COLUMN email_contact VARCHAR(150) NULL AFTER telephone_contact,
    ADD COLUMN statut ENUM('actif', 'inactif') NOT NULL DEFAULT 'actif' AFTER email_contact,
    ADD INDEX idx_sites_b2b_adresse (adresse_id),
    ADD CONSTRAINT fk_sites_b2b_adresse
        FOREIGN KEY (adresse_id) REFERENCES adresses(id) ON DELETE SET NULL;

ALTER TABLE contrats_b2b
    ADD COLUMN sla_urgent_minutes INT UNSIGNED NOT NULL DEFAULT 120 AFTER credits_utilises,
    ADD COLUMN sla_normal_minutes INT UNSIGNED NOT NULL DEFAULT 1440 AFTER sla_urgent_minutes;

CREATE TABLE devis_b2b (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    entreprise_b2b_id INT NOT NULL,
    demande_id INT NULL,
    cree_par_user_id INT NOT NULL,
    numero VARCHAR(32) NULL,
    description TEXT NOT NULL,
    montant DECIMAL(12, 2) NULL,
    details TEXT NULL,
    statut ENUM('demande', 'emis', 'accepte', 'refuse', 'expire') NOT NULL DEFAULT 'demande',
    date_validite DATE NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_emission DATETIME NULL,
    date_reponse DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_devis_b2b_numero (numero),
    INDEX idx_devis_b2b_entreprise (entreprise_b2b_id, date_creation),
    INDEX idx_devis_b2b_demande (demande_id),
    CONSTRAINT fk_devis_b2b_entreprise
        FOREIGN KEY (entreprise_b2b_id) REFERENCES entreprises_b2b(id) ON DELETE CASCADE,
    CONSTRAINT fk_devis_b2b_demande
        FOREIGN KEY (demande_id) REFERENCES demandes(id) ON DELETE SET NULL,
    CONSTRAINT fk_devis_b2b_createur
        FOREIGN KEY (cree_par_user_id) REFERENCES users(id) ON DELETE RESTRICT
);
