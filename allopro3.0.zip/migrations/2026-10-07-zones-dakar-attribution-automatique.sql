-- Référentiel initial des lieux de la région de Dakar.
-- Source des lieux nommés : OpenStreetMap, ODbL 1.0 (© contributeurs).
-- Extrait du 06/10/2026 dans l'emprise de la région ; les points cartographiés
-- ne garantissent ni l'exhaustivité du catalogue ni des limites officielles.
-- Les lieux peuvent être complétés au fil des relevés.
ALTER TABLE zones
    ADD COLUMN type ENUM('ville', 'zone', 'quartier', 'localite') NOT NULL DEFAULT 'quartier' AFTER nom,
    ADD COLUMN parent_id INT NULL AFTER type,
    ADD COLUMN osm_id BIGINT UNSIGNED NULL AFTER parent_id,
    ADD KEY idx_zones_parent_id (parent_id),
    ADD UNIQUE KEY uq_zones_parent_nom (parent_id, nom),
    ADD UNIQUE KEY uq_zones_osm_id (osm_id);

ALTER TABLE interventions
    ADD COLUMN attribution_mode ENUM('manuel', 'automatique') NOT NULL DEFAULT 'manuel',
    ADD COLUMN score_attribution SMALLINT UNSIGNED NULL,
    ADD COLUMN details_attribution VARCHAR(500) NULL,
    ADD UNIQUE KEY uq_interventions_demande_id (demande_id);

INSERT INTO zones (nom, ville, pays, statut, type, osm_id)
VALUES ('Région de Dakar', 'Région de Dakar', 'Sénégal', 'active', 'ville', 2892079);

UPDATE zones
SET type = 'ville', parent_id = NULL
WHERE osm_id = 2892079;

UPDATE zones
SET type = 'quartier', osm_id = 2214678829
WHERE nom = 'Almadies' AND ville = 'Dakar' AND osm_id IS NULL
LIMIT 1;

UPDATE zones
SET type = 'quartier', osm_id = 4271813664
WHERE nom = 'Parcelles Assainies' AND ville = 'Dakar' AND osm_id IS NULL
LIMIT 1;

UPDATE zones
SET type = 'quartier', osm_id = 1778280492
WHERE nom = 'Plateau' AND ville = 'Dakar' AND osm_id IS NULL
LIMIT 1;

UPDATE zones
SET type = 'quartier', osm_id = 2214676190
WHERE nom = 'Sacré-Cœur' AND ville = 'Dakar' AND osm_id IS NULL
LIMIT 1;

INSERT IGNORE INTO zones (nom, ville, pays, statut, type, osm_id) VALUES
    ('Almadie 2', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 12004527628),
    ('Amitié', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564633241),
    ('Amitié 1', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564612946),
    ('Amitié 2', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564612947),
    ('Arafat', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 569663800),
    ('Bayal', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 12484462337),
    ('Bel Air', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 566697488),
    ('Biscuiterie', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8929314327),
    ('Bopp', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564722139),
    ('Cambérène', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 8928322722),
    ('Camille Basse', 'Région de Dakar', 'Sénégal', 'active', 'zone', 2270628840),
    ('Castor', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 569663704),
    ('Chef de quartier Bagdad', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 12270660325),
    ('Cite Avion', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 13830662040),
    ('Cité Biagui 2', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 3666292248),
    ('Cité Douane', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564729124),
    ('Cité Doudou Basse', 'Région de Dakar', 'Sénégal', 'active', 'zone', 2577986604),
    ('Cité Gendarmerie', 'Région de Dakar', 'Sénégal', 'active', 'zone', 2965962948),
    ('Cité Marine', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 569663781),
    ('Cité Millionnaire', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 569663820),
    ('Cité Port', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564729121),
    ('Cité Sidak', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 8848178583),
    ('Cité SOFRACO', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 3666233439),
    ('Citée Total', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 2439016292),
    ('Colobane', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 2639671389),
    ('Dalifort', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 4958532745),
    ('Derklé', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 569663720),
    ('Dieuppeul-Derklé', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8929314333),
    ('Djida Thiaroye Kaw', 'Région de Dakar', 'Sénégal', 'active', 'zone', 4958547350),
    ('Dougar AITHIA', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 9215098337),
    ('Fann', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 299640752),
    ('Fann Hock', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 560861397),
    ('Fann Mermoz', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 562878240),
    ('Fann Résidence', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 561541348),
    ('Fann-Point E-Amitié', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8929614185),
    ('Fass Delorme', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 560764199),
    ('Gardien', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 13844210070),
    ('Gibraltar', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 560764202),
    ('Golf Sud (Cité Aliou SOW)', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 8047907843),
    ('Gorée', 'Région de Dakar', 'Sénégal', 'active', 'zone', 281943225),
    ('Gouye Sor', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 13830688151),
    ('Grand Yoff', 'Région de Dakar', 'Sénégal', 'active', 'zone', 569663803),
    ('Grand-Dakar', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8929314328),
    ('Gueule Tapée', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 560764203),
    ('Gueule Tapée-Fass-Colobane', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8929614186),
    ('Hamo 6', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 3666295353),
    ('Hann Bel-Air', 'Région de Dakar', 'Sénégal', 'active', 'zone', 565575051),
    ('Hann Equip', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 566699849),
    ('Hann Marinas', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 566699844),
    ('Hann Maristes 1', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 1596287972),
    ('HLM', 'Région de Dakar', 'Sénégal', 'active', 'zone', 565562211),
    ('HLM 2', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 565574443),
    ('HLM 3', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 565562212),
    ('HLM 4', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 565562210),
    ('HLM 5', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 565562209),
    ('HLM 6', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 565562215),
    ('HLM Fass', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 560523361),
    ('HLM Grand Yoff', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 1596287974),
    ('HLM Nimzatt', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 560521487),
    ('Keur Damel', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 568345178),
    ('Khar Yalla', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 299636298),
    ('Liberté', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 299636310),
    ('Mamelles', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 3499062423),
    ('Medina', 'Région de Dakar', 'Sénégal', 'active', 'zone', 560430201),
    ('Mermoz', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 562878265),
    ('Mermoz-Sacré-Cœur', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8929257489),
    ('Miname', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 4819981364),
    ('Ngor', 'Région de Dakar', 'Sénégal', 'active', 'zone', 3662979628),
    ('Ouagou Niayes', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564723358),
    ('Ouakam', 'Région de Dakar', 'Sénégal', 'active', 'zone', 1760524533),
    ('Patte d''Oie', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8928322736),
    ('Pikine Ouest', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 1785921300),
    ('Plan Jaxaay 01', 'Région de Dakar', 'Sénégal', 'active', 'zone', 2965962949),
    ('Plan Jaxaay 02', 'Région de Dakar', 'Sénégal', 'active', 'zone', 2965962950),
    ('Point E', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 299636390),
    ('Quartier Demba Seck', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 5292517652),
    ('Rebeuss', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 560743288),
    ('Rufisque Est', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8928159026),
    ('Rufisque Nord', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8928159005),
    ('Rufisque Ouest', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8928159004),
    ('Sentenac', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 3666297212),
    ('Sicap-Liberté', 'Région de Dakar', 'Sénégal', 'active', 'zone', 8929314334),
    ('Soutrack Mermoz', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 13195387034),
    ('Sud Foire', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 1596282880),
    ('Touba Ndar Fall JUS', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 8773863819),
    ('Village Grand Médine', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 299636278),
    ('Yoff', 'Région de Dakar', 'Sénégal', 'active', 'zone', 299636277),
    ('Zone B', 'Région de Dakar', 'Sénégal', 'active', 'quartier', 564612945);

UPDATE zones enfants
JOIN zones ville ON ville.osm_id = 2892079
SET enfants.parent_id = ville.id
WHERE enfants.osm_id IS NOT NULL AND enfants.osm_id <> 2892079;

INSERT INTO parametres (cle, valeur)
VALUES ('attribution_automatique_demandes', '0')
ON DUPLICATE KEY UPDATE cle = VALUES(cle);
