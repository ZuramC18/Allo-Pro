ALTER TABLE contrats_b2b
    ADD COLUMN montant_total DECIMAL(12, 2) NOT NULL DEFAULT 0 AFTER credits_utilises,
    ADD COLUMN conditions TEXT NULL AFTER montant_total,
    ADD COLUMN cree_par_admin_id INT NULL AFTER conditions,
    ADD CONSTRAINT fk_contrats_b2b_createur
        FOREIGN KEY (cree_par_admin_id) REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE demandes
    ADD COLUMN contrat_b2b_id INT NULL AFTER site_b2b_id,
    ADD INDEX idx_demandes_contrat_b2b_statut (contrat_b2b_id, statut),
    ADD CONSTRAINT fk_demandes_contrat_b2b
        FOREIGN KEY (contrat_b2b_id) REFERENCES contrats_b2b(id) ON DELETE RESTRICT;

CREATE TABLE contrats_b2b_consommations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    contrat_b2b_id INT NOT NULL,
    demande_id INT NOT NULL,
    credits INT UNSIGNED NOT NULL DEFAULT 1,
    date_consommation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_contrats_b2b_consommations_demande (demande_id),
    KEY idx_contrats_b2b_consommations_contrat (contrat_b2b_id, date_consommation),
    CONSTRAINT fk_contrats_b2b_consommations_contrat
        FOREIGN KEY (contrat_b2b_id) REFERENCES contrats_b2b(id) ON DELETE RESTRICT,
    CONSTRAINT fk_contrats_b2b_consommations_demande
        FOREIGN KEY (demande_id) REFERENCES demandes(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE paiements_contrats_b2b (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    contrat_b2b_id INT NOT NULL,
    montant DECIMAL(12, 2) NOT NULL,
    methode ENUM('wave', 'orange_money', 'virement', 'cheque', 'especes', 'autre') NOT NULL,
    reference_transaction VARCHAR(100) NULL,
    enregistre_par_admin_id INT NOT NULL,
    date_paiement DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_paiements_contrats_b2b_contrat (contrat_b2b_id, date_paiement),
    CONSTRAINT fk_paiements_contrats_b2b_contrat
        FOREIGN KEY (contrat_b2b_id) REFERENCES contrats_b2b(id) ON DELETE RESTRICT,
    CONSTRAINT fk_paiements_contrats_b2b_admin
        FOREIGN KEY (enregistre_par_admin_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
