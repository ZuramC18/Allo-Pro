INSERT IGNORE INTO role_permissions (role, module) VALUES
    ('qualite', 'messagerie'),
    ('qualite', 'messagerie_interne'),
    ('qualite', 'clients');
