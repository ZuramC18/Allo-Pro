INSERT INTO parametres (cle, valeur)
VALUES
    ('heure_debut_indisponibilites', '8'),
    ('heure_fin_indisponibilites', '20')
ON DUPLICATE KEY UPDATE valeur = valeur;

CREATE TABLE IF NOT EXISTS technicien_indisponibilites (
    id INT NOT NULL AUTO_INCREMENT,
    technicien_id INT NOT NULL,
    date_indisponibilite DATE NOT NULL,
    heure_debut TINYINT UNSIGNED NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_technicien_indisponibilite_creneau (technicien_id, date_indisponibilite, heure_debut),
    KEY idx_technicien_indisponibilites_date (date_indisponibilite, heure_debut),
    CONSTRAINT fk_technicien_indisponibilites_technicien
        FOREIGN KEY (technicien_id) REFERENCES techniciens (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
