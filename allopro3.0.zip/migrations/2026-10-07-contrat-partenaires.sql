ALTER TABLE partenaires
    ADD COLUMN nom_representant VARCHAR(150) NULL AFTER nom_entreprise,
    ADD COLUMN contrat_signe_at DATETIME NULL,
    ADD COLUMN contrat_version VARCHAR(40) NULL,
    ADD COLUMN contrat_contenu LONGTEXT NULL,
    ADD COLUMN contrat_ip_signature VARCHAR(45) NULL,
    ADD COLUMN contrat_agent_utilisateur VARCHAR(500) NULL;
