ALTER TABLE interventions
    ADD date_creneau_planifie DATE NULL AFTER technicien_id,
    ADD heure_creneau_planifie TINYINT UNSIGNED NULL AFTER date_creneau_planifie,
    ADD INDEX idx_interventions_technicien_creneau
        (technicien_id, date_creneau_planifie, heure_creneau_planifie);
