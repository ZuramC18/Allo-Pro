INSERT IGNORE INTO role_permissions (role, module) VALUES
    ('finance', 'paiements'),
    ('finance', 'reversements'),
    ('finance', 'remboursements_sav'),
    ('finance', 'devis_entreprises'),
    ('finance', 'tableau_bord');
