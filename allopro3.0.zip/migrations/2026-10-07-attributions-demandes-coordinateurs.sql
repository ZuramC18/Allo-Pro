CREATE TABLE IF NOT EXISTS attributions_demandes_coordinateurs (
    id INT NOT NULL AUTO_INCREMENT,
    demande_id INT NOT NULL,
    conseiller_id INT NOT NULL,
    commentaire_interne TEXT NOT NULL,
    coordinateur_id INT NULL,
    statut ENUM('en_attente', 'traitee') NOT NULL DEFAULT 'en_attente',
    date_attribution TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_traitement DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_attributions_demandes_coordinateurs_demande (demande_id),
    KEY idx_attributions_demandes_coordinateurs_statut_date (statut, date_attribution),
    CONSTRAINT fk_attributions_demandes_coordinateurs_demande
        FOREIGN KEY (demande_id) REFERENCES demandes (id) ON DELETE CASCADE,
    CONSTRAINT fk_attributions_demandes_coordinateurs_conseiller
        FOREIGN KEY (conseiller_id) REFERENCES users (id),
    CONSTRAINT fk_attributions_demandes_coordinateurs_coordinateur
        FOREIGN KEY (coordinateur_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
