CREATE TABLE IF NOT EXISTS attribution_demandes_configuration (
    cle VARCHAR(60) NOT NULL,
    valeur VARCHAR(20) NOT NULL,
    modifie_le TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (cle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO attribution_demandes_configuration (cle, valeur) VALUES
    ('limite_charge_active', '1'),
    ('charge_maximale', '3'),
    ('score_zone_active', '1'),
    ('score_zone_quartier', '45'),
    ('score_zone_elargie', '34'),
    ('score_zone_ville', '28'),
    ('score_competence_active', '1'),
    ('score_competence_exacte', '25'),
    ('score_competence_compatible', '15'),
    ('score_reputation_active', '1'),
    ('score_reputation_par_point', '4'),
    ('score_niveau_active', '1'),
    ('score_niveau_certifie', '4'),
    ('score_niveau_premium', '7'),
    ('score_niveau_excellence', '10'),
    ('score_charge_active', '1'),
    ('penalite_charge', '12'),
    ('priorite_urgence_active', '1'),
    ('priorite_abonnement_active', '1'),
    ('priorite_anciennete_active', '1'),
    ('horizon_creneaux_active', '1'),
    ('horizon_creneaux_jours', '30');
