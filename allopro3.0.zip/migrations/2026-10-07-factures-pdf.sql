ALTER TABLE abonnements_clients
    ADD COLUMN date_paiement DATETIME NULL AFTER date_creation;

UPDATE abonnements_clients
SET date_paiement = COALESCE(date_debut, date_creation)
WHERE statut <> 'en_attente' AND date_paiement IS NULL;

ALTER TABLE pass_achats
    ADD COLUMN date_paiement DATETIME NULL AFTER date_achat;

UPDATE pass_achats
SET date_paiement = date_achat
WHERE statut <> 'en_attente' AND date_paiement IS NULL;

CREATE TABLE factures (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    numero VARCHAR(32) NULL,
    reference_source VARCHAR(100) NOT NULL,
    type_operation ENUM('intervention', 'abonnement', 'pass') NOT NULL,
    client_id INT NOT NULL,
    libelle VARCHAR(500) NOT NULL,
    montant DECIMAL(10,2) NOT NULL,
    devise VARCHAR(8) NOT NULL DEFAULT 'FCFA',
    email_destinataire VARCHAR(150) NOT NULL,
    chemin_fichier VARCHAR(255) NOT NULL DEFAULT '',
    email_statut ENUM('en_attente', 'envoye', 'echec') NOT NULL DEFAULT 'en_attente',
    email_envoye_at DATETIME NULL,
    email_erreur TEXT NULL,
    date_emission TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_factures_numero (numero),
    UNIQUE KEY uq_factures_reference_source (reference_source),
    KEY idx_factures_client_date (client_id, date_emission),
    CONSTRAINT fk_factures_client FOREIGN KEY (client_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
