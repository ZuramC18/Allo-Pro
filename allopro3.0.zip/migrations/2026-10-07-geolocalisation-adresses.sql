ALTER TABLE adresses
    ADD COLUMN adresse_google VARCHAR(500) NULL AFTER details,
    ADD COLUMN latitude DECIMAL(10,7) NULL AFTER adresse_google,
    ADD COLUMN longitude DECIMAL(10,7) NULL AFTER latitude;
