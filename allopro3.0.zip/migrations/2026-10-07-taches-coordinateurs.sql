ALTER TABLE taches
    DROP CHECK chk_taches_un_proprietaire,
    ADD coordinateur_id INT NULL AFTER partenaire_id,
    ADD INDEX idx_taches_coordinateur_id (coordinateur_id),
    ADD CONSTRAINT taches_ibfk_coordinateur
        FOREIGN KEY (coordinateur_id) REFERENCES users (id) ON DELETE CASCADE,
    ADD CONSTRAINT chk_taches_un_proprietaire CHECK (
        (technicien_id IS NOT NULL AND partenaire_id IS NULL AND coordinateur_id IS NULL)
        OR (technicien_id IS NULL AND partenaire_id IS NOT NULL AND coordinateur_id IS NULL)
        OR (technicien_id IS NULL AND partenaire_id IS NULL AND coordinateur_id IS NOT NULL)
    );
