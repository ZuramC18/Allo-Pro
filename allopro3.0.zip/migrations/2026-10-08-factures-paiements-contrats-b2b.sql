CREATE TABLE factures_contrats_b2b (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    paiement_contrat_b2b_id BIGINT UNSIGNED NOT NULL,
    contrat_b2b_id INT NOT NULL,
    numero VARCHAR(40) NOT NULL,
    email_destinataire VARCHAR(150) NULL,
    chemin_fichier VARCHAR(255) NOT NULL DEFAULT '',
    email_statut ENUM('en_attente', 'envoye', 'echec') NOT NULL DEFAULT 'en_attente',
    email_envoye_at DATETIME NULL,
    email_erreur TEXT NULL,
    date_emission TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_factures_contrats_b2b_paiement (paiement_contrat_b2b_id),
    UNIQUE KEY uq_factures_contrats_b2b_numero (numero),
    KEY idx_factures_contrats_b2b_contrat_date (contrat_b2b_id, date_emission),
    CONSTRAINT fk_factures_contrats_b2b_paiement
        FOREIGN KEY (paiement_contrat_b2b_id) REFERENCES paiements_contrats_b2b(id) ON DELETE RESTRICT,
    CONSTRAINT fk_factures_contrats_b2b_contrat
        FOREIGN KEY (contrat_b2b_id) REFERENCES contrats_b2b(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
