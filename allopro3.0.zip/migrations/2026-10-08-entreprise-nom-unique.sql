ALTER TABLE entreprises_b2b
    ADD COLUMN nom_normalise VARCHAR(150) NULL AFTER nom;

UPDATE entreprises_b2b
SET nom_normalise = LOWER(TRIM(nom));

ALTER TABLE entreprises_b2b
    MODIFY COLUMN nom_normalise VARCHAR(150) NOT NULL,
    ADD UNIQUE KEY uq_entreprises_b2b_nom_normalise (nom_normalise);
