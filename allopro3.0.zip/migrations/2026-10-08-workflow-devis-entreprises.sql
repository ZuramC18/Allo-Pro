ALTER TABLE devis_b2b
    ADD COLUMN qualite_statut ENUM('a_traiter', 'valide', 'a_preciser') NOT NULL DEFAULT 'a_traiter' AFTER statut,
    ADD COLUMN qualite_commentaire TEXT NULL AFTER qualite_statut,
    ADD COLUMN qualite_par_user_id INT NULL AFTER qualite_commentaire,
    ADD COLUMN qualite_le DATETIME NULL AFTER qualite_par_user_id,
    ADD INDEX idx_devis_b2b_qualification (statut, qualite_statut, date_creation),
    ADD CONSTRAINT fk_devis_b2b_qualite_user
        FOREIGN KEY (qualite_par_user_id) REFERENCES users(id) ON DELETE SET NULL;

INSERT IGNORE INTO role_permissions (role, module) VALUES
    ('qualite', 'devis_entreprises'),
    ('finance', 'devis_entreprises');
