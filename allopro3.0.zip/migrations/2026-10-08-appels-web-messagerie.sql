CREATE TABLE messagerie_appels_web (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    client_id INT NOT NULL,
    appelant_id INT NOT NULL,
    appelant_role VARCHAR(30) NOT NULL,
    statut ENUM('sonnerie', 'accepte', 'refuse', 'termine', 'expire') NOT NULL DEFAULT 'sonnerie',
    date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_maj DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_appels_web_client_statut (client_id, statut, date_creation),
    KEY idx_appels_web_appelant_statut (appelant_id, statut),
    CONSTRAINT fk_appels_web_client FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_appels_web_appelant FOREIGN KEY (appelant_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE messagerie_appels_web_signaux (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    appel_id BIGINT UNSIGNED NOT NULL,
    expediteur_id INT NOT NULL,
    type_signal ENUM('offre', 'reponse', 'candidat') NOT NULL,
    contenu MEDIUMTEXT NOT NULL,
    date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_appels_web_signaux_appel (appel_id, id),
    CONSTRAINT fk_appels_web_signaux_appel FOREIGN KEY (appel_id) REFERENCES messagerie_appels_web(id) ON DELETE CASCADE,
    CONSTRAINT fk_appels_web_signaux_user FOREIGN KEY (expediteur_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE messagerie_appels_web_presence (
    user_id INT NOT NULL,
    role VARCHAR(30) NOT NULL,
    dernier_ping DATETIME NOT NULL,
    PRIMARY KEY (user_id),
    KEY idx_appels_web_presence_role_ping (role, dernier_ping),
    CONSTRAINT fk_appels_web_presence_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
