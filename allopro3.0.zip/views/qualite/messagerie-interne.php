<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('messagerie_interne');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messagerie interne — Qualité / SAV</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/messagerie-interne.css?v=<?= filemtime(__DIR__ . '/../../public/css/messagerie-interne.css') ?>">
</head>
<body class="page-messagerie-interne">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?>
    <div class="admin-contenu">
        <?php include __DIR__ . '/../../includes/messagerie-interne-corps.php'; ?>
    </div>
</div>
<script src="../../public/js/messagerie-interne.js?v=<?= filemtime(__DIR__ . '/../../public/js/messagerie-interne.js') ?>"></script>
</body>
</html>