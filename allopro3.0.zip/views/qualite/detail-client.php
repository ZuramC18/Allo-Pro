<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('clients');
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/NoteInterne.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($id === false) { header('Location: recherche-clients.php'); exit; }

$userModel = new User();
$client = $userModel->getById($id);
if (!$client || $client['role'] !== 'client') { http_response_code(404); exit('Client introuvable.'); }
$photoProfil = AvatarProfil::estValide($client['photo_profil'] ?? null, 'clients')
    ? (string) $client['photo_profil']
    : null;
$avatarInitiales = !empty($client['avatar_initiales']);
$initialesClient = AvatarProfil::initiales(trim((string) ($client['prenom'] ?? '') . ' ' . (string) ($client['nom'] ?? '')));

$csrfKey = 'csrf_qualite_note_client';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}
$erreur = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note_interne'])) {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $contenu = is_string($_POST['note_interne']) ? trim($_POST['note_interne']) : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'La session a expiré. Rechargez la page puis réessayez.';
    } elseif ($contenu === '' || mb_strlen($contenu) > 2000) {
        $erreur = 'La note doit contenir entre 1 et 2 000 caractères.';
    } else {
        (new NoteInterne())->create((int) $id, (int) $_SESSION['user_id'], $contenu);
        header('Location: detail-client.php?id=' . (int) $id . '#notes');
        exit;
    }
}

$demandeModel = new Demande();
$dossiers = $demandeModel->getByClient($id);
$notesInternes = (new NoteInterne())->getByClient($id);

$libellesStatuts = ['nouvelle' => ['Nouvelle', 'violet'], 'attribuee' => ['Attribuée', 'amber'], 'en_cours' => ['En cours', 'amber'], 'terminee' => ['Terminée', 'vert'], 'annulee' => ['Annulée', 'gris']];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($client['prenom'] . ' ' . $client['nom'], ENT_QUOTES, 'UTF-8') ?> — Qualité / SAV</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <style>
        .fiche-client { display: grid; grid-template-columns: minmax(0, 320px) minmax(0, 1fr); gap: 20px; min-width: 0; }
        .fiche-client > * { min-width: 0; }
        .fiche-profil { text-align: center; }
        .fiche-profil__avatar { width: 70px; height: 70px; overflow: hidden; border-radius: 50%; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-family:'Space Grotesk',sans-serif; font-weight: 800; font-size: 22px; margin: 0 auto 14px; }
        .fiche-profil__avatar img { width: 100%; height: 100%; object-fit: cover; }
        .fiche-profil__avatar svg { width: 31px; height: 31px; fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.7; }
        .fiche-profil__avatar--cliquable { padding: 0; border: 0; cursor: zoom-in; }
        .fiche-profil__avatar--cliquable:focus-visible { outline: 3px solid var(--admin-violet); outline-offset: 4px; }
        .photo-client-apercu { width: min(100%, 260px); margin: 0 auto 16px; padding: 10px; border: 1px solid var(--admin-bordure); border-radius: 12px; background: var(--admin-carte, #fff); }
        .photo-client-apercu[hidden] { display: none; }
        .photo-client-apercu__titre { margin-bottom: 8px; color: var(--admin-texte-discret); font-size: 12px; font-weight: 600; }
        .photo-client-apercu__image { display: block; width: 100%; max-height: 260px; object-fit: contain; border-radius: 8px; }
        .photo-client-apercu__fermer { margin-top: 8px; padding: 7px 10px; border: 1px solid var(--admin-bordure); border-radius: 7px; color: var(--admin-texte); background: transparent; font: inherit; font-size: 12px; cursor: pointer; }
        .photo-client-apercu__fermer:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: 2px; }
        .fiche-profil__nom { font-family:'Space Grotesk',sans-serif; font-weight: 700; font-size: 17px; }
        .fiche-profil__ligne { display: flex; justify-content: space-between; padding: 10px 0; border-top: 1px solid #F1F0F6; font-size: 13.5px; margin-top: 14px; }
        .fiche-profil__ligne span:first-child { color: var(--admin-texte-discret); }
        .note-interne-admin { background: #FBF7EC; border: 1px solid #EEE0B0; border-radius: 8px; padding: 10px 12px; margin-bottom: 8px; font-size: 13px; }
        .note-interne-admin__meta { font-size: 11px; color: #92752E; font-weight: 600; margin-bottom: 3px; }
        .historique-dossiers { min-width: 0; }
        .historique-dossiers__lien { color: var(--admin-violet); font-weight: 650; text-decoration: none; }
        .historique-dossiers__lien:hover { text-decoration: underline; }
        .historique-dossiers__lien:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: 3px; border-radius: 3px; }
        @media (max-width: 700px) {
            .fiche-client { grid-template-columns: minmax(0, 1fr); gap: 0; }
            .fiche-client > div { min-width: 0; }
            .fiche-client .admin-panneau { min-width: 0; padding: 16px 14px; }
            .fiche-profil__ligne { gap: 12px; align-items: flex-start; text-align: left; }
            .fiche-profil__ligne span:last-child { min-width: 0; overflow-wrap: anywhere; text-align: right; }
            .historique-dossiers.admin-table { display: block; width: 100%; min-width: 0; }
            .historique-dossiers thead { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }
            .historique-dossiers tbody { display: grid; gap: 10px; }
            .historique-dossiers tbody tr.historique-dossiers__ligne { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); padding: 8px 10px; border: 1px solid var(--admin-bordure); border-radius: 10px; }
            .historique-dossiers tbody tr.historique-dossiers__ligne td { min-width: 0; padding: 9px 5px; border: 0; font-size: 12px; overflow-wrap: anywhere; }
            .historique-dossiers__ligne td:first-child,
            .historique-dossiers__ligne td:last-child { grid-column: 1 / -1; }
            .historique-dossiers__ligne td:first-child { border-bottom: 1px solid var(--admin-bordure); }
            .historique-dossiers__ligne td[data-label]::before { display: block; margin-bottom: 4px; color: var(--admin-texte-discret); font-size: 10px; font-weight: 500; content: attr(data-label); }
            .historique-dossiers__ligne td:last-child { border-top: 1px solid var(--admin-bordure); }
            .historique-dossiers__lien--action { display: flex; align-items: center; justify-content: space-between; min-height: 40px; padding: 0 10px; border-radius: 7px; background: rgba(108, 92, 231, .09); }
            .historique-dossiers__vide { display: block; padding: 20px 12px !important; text-align: center; }
            :root[data-theme="dark"] .historique-dossiers tbody tr.historique-dossiers__ligne { background: var(--admin-carte, #1d202b); }
        }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="recherche-clients.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour à la recherche</a>
                <div class="admin-entete__titre" style="margin-top:6px;"><?= htmlspecialchars(trim($client['prenom'] . ' ' . $client['nom']), ENT_QUOTES, 'UTF-8') ?></div>
            </div>
            <?php if ($client['statut'] === 'actif'): ?>
                <a class="admin-bouton admin-bouton--principal" href="messagerie.php?client_id=<?= (int) $id ?>">Ouvrir la messagerie</a>
            <?php endif; ?>
        </div>

        <div class="fiche-client">
            <div>
                <div class="admin-panneau fiche-profil">
                    <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                        <button type="button" class="fiche-profil__avatar fiche-profil__avatar--cliquable" aria-label="Afficher l’aperçu de la photo de profil de <?= htmlspecialchars($client['nom'], ENT_QUOTES, 'UTF-8') ?>" aria-expanded="false" aria-controls="photo-client-apercu">
                            <img src="../../public/<?= htmlspecialchars($photoProfil, ENT_QUOTES, 'UTF-8') ?>" alt="">
                        </button>
                        <div class="photo-client-apercu" id="photo-client-apercu" hidden>
                            <div class="photo-client-apercu__titre">Aperçu de la photo</div>
                            <img class="photo-client-apercu__image" src="../../public/<?= htmlspecialchars($photoProfil, ENT_QUOTES, 'UTF-8') ?>" alt="Photo de profil agrandie de <?= htmlspecialchars($client['nom'], ENT_QUOTES, 'UTF-8') ?>">
                            <button type="button" class="photo-client-apercu__fermer">Fermer l’aperçu</button>
                        </div>
                    <?php else: ?>
                        <div class="fiche-profil__avatar" aria-hidden="true">
                        <?php if ($avatarInitiales): ?>
                            <?= htmlspecialchars($initialesClient, ENT_QUOTES, 'UTF-8') ?>
                        <?php else: ?>
                            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                        <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="fiche-profil__nom"><?= htmlspecialchars($client['nom']) ?></div>
                    <span class="admin-badge admin-badge--<?= $client['statut'] === 'actif' ? 'vert' : 'rouge' ?>" style="margin-top:8px; display:inline-block;">
                        <?= $client['statut'] === 'actif' ? 'Compte actif' : 'Compte suspendu' ?>
                    </span>

                    <div class="fiche-profil__ligne"><span>Téléphone</span><span><?= htmlspecialchars($client['telephone'] ?: '—') ?></span></div>
                    <div class="fiche-profil__ligne"><span>Email</span><span><?= htmlspecialchars($client['email']) ?></span></div>
                    <div class="fiche-profil__ligne"><span>Inscrit le</span><span><?= date('d/m/Y', strtotime($client['date_creation'])) ?></span></div>
                    <div class="fiche-profil__ligne"><span>Total dossiers</span><span><?= count($dossiers) ?></span></div>

                </div>

                <div class="admin-panneau" id="notes">
                    <div class="admin-panneau__titre">Notes internes</div>
                    <?php if ($erreur !== ''): ?><div class="alerte alerte--erreur" role="alert"><?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
                    <form method="POST" style="margin-bottom:12px;">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION[$csrfKey], ENT_QUOTES, 'UTF-8') ?>">
                        <textarea name="note_interne" rows="2" maxlength="2000" placeholder="Ajouter une note (visible équipe uniquement)..." required style="width:100%; padding:8px 10px; border:1px solid var(--admin-bordure); border-radius:6px; font-family:'Inter',sans-serif; font-size:13px; resize:vertical;"></textarea>
                        <button type="submit" style="width:100%; margin-top:6px; padding:7px; font-size:13px; background:var(--admin-violet); color:white; border:none; border-radius:6px; cursor:pointer; font-weight:600;">Ajouter</button>
                    </form>
                    <div style="max-height:220px; overflow-y:auto;">
                        <?php if (empty($notesInternes)): ?><p style="font-size:12px; color:var(--admin-texte-discret);">Aucune note.</p><?php endif; ?>
                        <?php foreach ($notesInternes as $n): ?>
                            <div class="note-interne-admin">
                                <div class="note-interne-admin__meta"><?= htmlspecialchars($n['conseiller_nom']) ?> · <?= date('d/m/Y H:i', strtotime($n['date_creation'])) ?></div>
                                <?= nl2br(htmlspecialchars($n['contenu'])) ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Historique des dossiers</div>
                <table class="admin-table historique-dossiers">
                    <thead><tr><th scope="col">Dossier</th><th scope="col">Catégorie</th><th scope="col">Statut</th><th scope="col">Date</th><th scope="col" aria-label="Action"></th></tr></thead>
                    <tbody>
                    <?php if (empty($dossiers)): ?>
                        <tr><td colspan="5" class="historique-dossiers__vide" style="text-align:center; color:var(--admin-texte-discret); padding:20px;">Aucun dossier.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($dossiers as $d): $s = $libellesStatuts[$d['statut']] ?? ['—','gris']; ?>
                    <tr class="historique-dossiers__ligne">
                        <td><strong><a class="historique-dossiers__lien" href="demande.php?id=<?= (int) $d['id'] ?>&amp;client_id=<?= (int) $id ?>"><?= htmlspecialchars($d['numero_dossier']) ?></a></strong></td>
                        <td data-label="Catégorie"><?= htmlspecialchars($d['categorie_nom']) ?></td>
                        <td data-label="Statut"><span class="admin-badge admin-badge--<?= $s[1] ?>"><?= $s[0] ?></span></td>
                        <td data-label="Date"><?= date('d/m/Y', strtotime($d['date_creation'])) ?></td>
                        <td><a class="historique-dossiers__lien historique-dossiers__lien--action" href="demande.php?id=<?= (int) $d['id'] ?>&amp;client_id=<?= (int) $id ?>">Ouvrir le dossier <span aria-hidden="true">→</span></a></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php if (!$avatarInitiales && $photoProfil !== null): ?>
<script>
    (() => {
        const declencheur = document.querySelector('.fiche-profil__avatar--cliquable');
        const apercu = document.getElementById('photo-client-apercu');
        const boutonFermer = apercu.querySelector('.photo-client-apercu__fermer');
        const fermerApercu = () => {
            apercu.hidden = true;
            declencheur.setAttribute('aria-expanded', 'false');
            declencheur.focus();
        };

        declencheur.addEventListener('click', () => {
            apercu.hidden = !apercu.hidden;
            declencheur.setAttribute('aria-expanded', String(!apercu.hidden));
        });
        boutonFermer.addEventListener('click', fermerApercu);
        apercu.addEventListener('keydown', (evenement) => {
            if (evenement.key === 'Escape') fermerApercu();
        });
    })();
</script>
<?php endif; ?>
</body>
</html>