<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';
require_once __DIR__ . '/../../models/EntrepriseB2B.php';

$ticketModel = new TicketSav();
$resume = $ticketModel->getResumeQualite();
$compteursCategorie = $ticketModel->compterParCategorieQualite();
$ticketsRecents = $ticketModel->getTicketsRecentsQualite();
$devisAQualifier = (new EntrepriseB2B())->getDevisB2BPourQualite();
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$libellesStatuts = ['ouvert' => 'Ouvert', 'en_cours' => 'En cours', 'resolu' => 'Résolu'];
$libellesCategories = [
    'mauvaise_experience' => 'Mauvaise expérience',
    'reclamation' => 'Réclamation',
    'incident' => 'Incident',
    'retard' => 'Retard',
    'intervention_incomplete' => 'Intervention incomplète',
    'reintervention' => 'Réintervention',
    'litige' => 'Litige',
    'remboursement' => 'Remboursement',
];
$mois = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
$maintenant = new DateTimeImmutable('now');
$date = $maintenant->format('j') . ' ' . $mois[(int) $maintenant->format('n')] . ' ' . $maintenant->format('Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Accueil Qualité / SAV — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/sav-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/sav-admin.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-admin-sav">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?>
    <main class="admin-contenu">
        <header class="admin-entete sav-entete">
            <div>
                <h1 class="admin-entete__titre">Espace Qualité / SAV</h1>
                <p class="admin-entete__sous-titre"><?= $e($date) ?> · Suivi des expériences, réclamations et interventions</p>
            </div>
            <a class="admin-bouton admin-bouton--principal" href="sav.php">Ouvrir la file SAV</a>
        </header>

        <section class="admin-kpi-grille sav-kpis" aria-label="Résumé qualité et service après-vente">
            <a class="admin-kpi-carte admin-kpi-carte--rouge" href="sav.php?statut=ouvert">
                <div class="admin-kpi-carte__label">À traiter</div><div class="admin-kpi-carte__valeur"><?= (int) $resume['ouverts'] ?></div>
            </a>
            <a class="admin-kpi-carte admin-kpi-carte--amber" href="sav.php?statut=en_cours">
                <div class="admin-kpi-carte__label">En cours</div><div class="admin-kpi-carte__valeur"><?= (int) $resume['en_cours'] ?></div>
            </a>
            <a class="admin-kpi-carte admin-kpi-carte--violet" href="sav.php">
                <div class="admin-kpi-carte__label">Réinterventions actives</div><div class="admin-kpi-carte__valeur"><?= (int) $resume['reinterventions'] ?></div>
            </a>
            <a class="admin-kpi-carte admin-kpi-carte--amber" href="sav.php">
                <div class="admin-kpi-carte__label">Remboursements en attente Finance</div><div class="admin-kpi-carte__valeur"><?= (int) $resume['remboursements_en_attente'] ?></div>
            </a>
            <a class="admin-kpi-carte admin-kpi-carte--violet" href="sav.php?note_max=2">
                <div class="admin-kpi-carte__label">Avis faibles à surveiller (≤ 2/5)</div><div class="admin-kpi-carte__valeur"><?= (int) $resume['avis_faibles'] ?></div>
            </a>
        </section>

        <section class="admin-panneau sav-panneau" aria-labelledby="qualite-categories-titre">
            <header class="sav-panneau__entete"><h2 id="qualite-categories-titre">Dossiers par catégorie</h2><a href="sav.php">Voir tous les dossiers →</a></header>
            <div class="qualite-categories">
                <?php foreach ($libellesCategories as $categorie => $libelle): ?>
                    <a href="sav.php?categorie=<?= rawurlencode($categorie) ?>" class="qualite-categorie">
                        <span><?= $e($libelle) ?></span>
                        <strong><?= (int) ($compteursCategorie[$categorie] ?? 0) ?></strong>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="admin-panneau sav-panneau" aria-labelledby="qualite-actions-titre">
            <header class="sav-panneau__entete"><h2 id="qualite-actions-titre">Vos priorités</h2></header>
            <div class="qualite-accueil-actions">
                <a href="sav.php"><strong>Traiter les dossiers SAV</strong><span>Réclamations, incidents, retards, interventions incomplètes, litiges et preuves.</span></a>
                <a href="devis-entreprises.php"><strong>Qualifier les devis entreprise</strong><span><?= count($devisAQualifier) ?> demande<?= count($devisAQualifier) === 1 ? '' : 's' ?> en attente d’analyse technique.</span></a>
                <a href="sav.php"><strong>Soumettre un remboursement</strong><span>Proposez un montant et une justification depuis la fiche SAV ; Finance conserve l’autorisation finale.</span></a>
            </div>
        </section>

        <section class="admin-panneau sav-panneau">
            <header class="sav-panneau__entete"><h2>Dossiers SAV prioritaires</h2><a href="sav.php">Voir tous les dossiers →</a></header>
            <div class="sav-table-scroll">
                <table class="admin-table sav-table">
                    <thead><tr><th>Dossier</th><th>Client</th><th>Catégorie</th><th>Motif</th><th>Statut</th><th>Note interne</th><th>Ouvert le</th><th></th></tr></thead>
                    <tbody>
                    <?php if (!$ticketsRecents): ?><tr class="sav-vide"><td colspan="8">Aucun dossier SAV pour le moment.</td></tr><?php endif; ?>
                    <?php foreach ($ticketsRecents as $ticket): ?>
                        <tr>
                            <td><strong><?= $e($ticket['numero_dossier']) ?></strong></td>
                            <td><?= $e($ticket['client_nom']) ?></td>
                            <td><?= $e($libellesCategories[$ticket['categorie_qualite']] ?? 'Réclamation') ?></td>
                            <td class="sav-motif"><?= $e($ticket['motif']) ?></td>
                            <td><?= $e($libellesStatuts[$ticket['statut']] ?? $ticket['statut']) ?></td>
                            <td><?= (int) ($ticket['note'] ?? 0) > 0 ? (int) $ticket['note'] . ' / 5' : '—' ?></td>
                            <td class="sav-date"><?= $e(date('d/m/Y', strtotime($ticket['date_creation']))) ?></td>
                            <td class="sav-action"><a href="sav-detail.php?id=<?= (int) $ticket['id'] ?>&amp;categorie=<?= rawurlencode((string) $ticket['categorie_qualite']) ?>">Ouvrir →</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="qualite-accueil-privacy">Les notes de satisfaction sont des données internes Qualité ; elles ne sont pas visibles par les clients.</p>
        </section>
    </main>
</div>
<style>
.qualite-accueil-actions { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; padding: 18px 20px; }
.qualite-accueil-actions a { display: grid; gap: 8px; padding: 17px; border: 1px solid var(--admin-bordure); border-radius: 10px; color: var(--admin-texte); text-decoration: none; }
.qualite-accueil-actions a:hover { border-color: var(--admin-violet); background: rgba(108, 92, 231, .04); }
.qualite-accueil-actions strong { font-size: 14px; }
.qualite-accueil-actions span, .qualite-accueil-privacy { color: var(--admin-texte-discret); font-size: 12px; line-height: 1.5; }
.qualite-accueil-privacy { margin: 0; padding: 0 20px 16px; }
.qualite-categories { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; padding: 16px 20px; }
.qualite-categorie { display: flex; min-width: 0; align-items: center; justify-content: space-between; gap: 10px; padding: 12px 14px; border: 1px solid var(--admin-bordure); border-radius: 9px; color: var(--admin-texte); text-decoration: none; font-size: 12px; }
.qualite-categorie:hover { border-color: var(--admin-violet); background: rgba(108, 92, 231, .04); }
.qualite-categorie span { min-width: 0; }
.qualite-categorie strong { display: grid; min-width: 25px; height: 25px; place-items: center; border-radius: 50%; background: rgba(108, 92, 231, .12); color: var(--admin-violet); }
@media (max-width: 760px) { .qualite-accueil-actions { grid-template-columns: 1fr; padding: 14px; } }
@media (max-width: 900px) { .qualite-categories { grid-template-columns: repeat(2, minmax(0, 1fr)); padding: 14px; } }
@media (max-width: 420px) { .qualite-categories { grid-template-columns: 1fr; } }
</style>
</body>
</html>
