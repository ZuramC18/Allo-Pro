<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('clients');

$demandeId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($demandeId === false) {
    http_response_code(404);
    exit('Dossier introuvable.');
}

$clientId = filter_var($_GET['client_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$urlRetourConsultation = $clientId === false || $clientId === null
    ? 'recherche-clients.php'
    : 'detail-client.php?id=' . $clientId;
$libelleRetourConsultation = $clientId === false || $clientId === null
    ? 'Retour à la recherche clients'
    : 'Retour à la fiche client';
$messageConsultationDossier = 'Cette fiche est consultable par Qualité / SAV. Les actions de traitement restent réservées aux équipes concernées.';
$consultationDossierInterne = true;
$_GET['id'] = (string) $demandeId;
require __DIR__ . '/../conseiller/traiter-demande.php';
