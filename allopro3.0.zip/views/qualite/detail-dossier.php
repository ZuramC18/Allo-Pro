<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite', 'finance', 'admin']);
verifierAcces('devis_entreprises');
require_once __DIR__ . '/../../models/EntrepriseB2B.php';

$devisId = filter_var($_GET['devis_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($devisId === false) {
    http_response_code(404);
    exit('Dossier introuvable.');
}

$modeleEntreprise = new EntrepriseB2B();
$demandeId = $modeleEntreprise->getDemandeIdPourConsultationDevisB2B(
    (int) $devisId,
    (string) ($_SESSION['role'] ?? '')
);
if ($demandeId === null) {
    http_response_code(404);
    exit('Dossier introuvable ou non associé à ce devis.');
}

$_GET['id'] = (string) $demandeId;
$consultationDossierInterne = true;
require __DIR__ . '/../conseiller/traiter-demande.php';
