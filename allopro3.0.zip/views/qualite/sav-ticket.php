<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

$ticketId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($ticketId === false) {
    http_response_code(404);
    exit('Ticket SAV introuvable.');
}
$ticketModel = new TicketSav();
$ticket = $ticketModel->getById((int) $ticketId);
if (!$ticket) {
    http_response_code(404);
    exit('Ticket SAV introuvable.');
}
$historiqueMission = $ticketModel->getHistoriqueMission((int) $ticket['demande_id']);
$preuves = $ticketModel->getPreuvesMission((int) $ticket['demande_id']);
$remboursements = $ticketModel->getRemboursementsSav((int) $ticketId);
$categories = [
    'mauvaise_experience' => 'Mauvaise expérience',
    'reclamation' => 'Réclamation',
    'incident' => 'Incident',
    'retard' => 'Retard',
    'intervention_incomplete' => 'Intervention incomplète',
    'reintervention' => 'Demande de réintervention',
    'litige' => 'Litige',
    'remboursement' => 'Remboursement',
];
$categorieRetour = is_string($_GET['categorie'] ?? null) && array_key_exists($_GET['categorie'], $categories)
    ? $_GET['categorie']
    : '';
$statutRetour = is_string($_GET['statut'] ?? null) && in_array($_GET['statut'], ['ouvert', 'en_cours', 'resolu'], true)
    ? $_GET['statut']
    : '';
$noteMaxRetourBrute = filter_var($_GET['note_max'] ?? null, FILTER_VALIDATE_INT);
$noteMaxRetour = $noteMaxRetourBrute !== false && $noteMaxRetourBrute >= 1 && $noteMaxRetourBrute <= 5
    ? $noteMaxRetourBrute
    : null;
$origineRetour = is_string($_GET['origine'] ?? null)
    && in_array($_GET['origine'], ['client', 'equipe', 'entreprise', 'historique'], true)
    ? $_GET['origine']
    : '';
$parametresRetour = array_filter([
    'statut' => $statutRetour,
    'note_max' => $noteMaxRetour,
    'origine' => $origineRetour,
    'categorie' => $categorieRetour,
], static fn($valeur): bool => $valeur !== '' && $valeur !== null);
$queryRetour = $parametresRetour ? '&' . http_build_query($parametresRetour) : '';
$urlRetourSAV = 'sav.php' . ($parametresRetour ? '?' . http_build_query($parametresRetour) : '');
$statuts = ['ouvert' => 'Ouvert', 'en_cours' => 'En cours', 'resolu' => 'Résolu'];
$erreur = '';
$csrfKey = 'csrf_qualite_sav';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'La session a expiré. Rechargez la page puis réessayez.';
    } else {
        try {
            $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
            if ($action === 'traiter') {
                $statut = is_string($_POST['statut'] ?? null) ? $_POST['statut'] : '';
                $categorie = is_string($_POST['categorie_qualite'] ?? null) ? $_POST['categorie_qualite'] : '';
                $notes = is_string($_POST['commentaire_conseiller'] ?? null) ? $_POST['commentaire_conseiller'] : '';
                if (!$ticketModel->mettreAJourQualite((int) $ticketId, (int) $_SESSION['user_id'], $statut, $categorie, $notes)) {
                    throw new RuntimeException('Le ticket n’a pas été modifié.');
                }
                journaliser('qualite.sav_mis_a_jour', 'ticket_sav', (int) $ticketId, $ticket['numero_dossier'], $statut . ' · ' . $categorie);
                header('Location: sav-detail.php?id=' . (int) $ticketId . '&maj=1' . $queryRetour);
                exit;
            }
            if ($action === 'demander_remboursement') {
                $montant = filter_var($_POST['montant_demande'] ?? null, FILTER_VALIDATE_FLOAT);
                $motif = is_string($_POST['motif_remboursement'] ?? null) ? $_POST['motif_remboursement'] : '';
                if ($montant === false) {
                    throw new InvalidArgumentException('Le montant proposé est invalide.');
                }
                $remboursementId = $ticketModel->demanderRemboursement(
                    (int) $ticketId,
                    (int) $_SESSION['user_id'],
                    (float) $montant,
                    $motif
                );
                journaliser('qualite.remboursement_soumis', 'remboursement_sav', $remboursementId, $ticket['numero_dossier']);
                header('Location: sav-detail.php?id=' . (int) $ticketId . '&remboursement=1' . $queryRetour);
                exit;
            }
            throw new InvalidArgumentException('Action SAV invalide.');
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Traitement qualité SAV #' . (int) $ticketId . ' : ' . $exception->getMessage());
            $erreur = 'Le traitement SAV n’a pas pu être enregistré. Réessayez.';
        }
        $ticket = $ticketModel->getById((int) $ticketId);
        $remboursements = $ticketModel->getRemboursementsSav((int) $ticketId);
    }
}
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$libelleCategorie = $categories[$ticket['categorie_qualite']] ?? 'Réclamation';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Qualité / SAV — <?= $e($ticket['numero_dossier']) ?></title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/sav-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/sav-admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/qualite-sav-detail.css?v=<?= filemtime(__DIR__ . '/../../public/css/qualite-sav-detail.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-admin-sav page-admin-sav-detail page-qualite-sav-detail">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?>
    <main class="admin-contenu qualite-sav-detail">
        <div class="admin-entete sav-detail-entete">
            <div><a href="<?= $e($urlRetourSAV) ?>" class="sav-detail-retour">← Retour à Qualité / SAV</a><h1 class="admin-entete__titre">Dossier <?= $e($ticket['numero_dossier']) ?></h1><?php if (!empty($ticket['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($ticket['entreprise_b2b_nom']) ? ' · ' . $e($ticket['entreprise_b2b_nom']) : '' ?></span><?php endif; ?><p><?= $e($libelleCategorie) ?> · ouvert le <?= $e(date('d/m/Y H:i', strtotime($ticket['date_creation']))) ?></p></div>
        </div>
        <?php if ($erreur !== ''): ?><div class="alerte alerte--erreur" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
        <?php if (($_GET['maj'] ?? '') === '1'): ?><div class="alerte alerte--succes" role="status">Le suivi qualité a été enregistré.</div><?php endif; ?>
        <?php if (($_GET['remboursement'] ?? '') === '1'): ?><div class="alerte alerte--succes" role="status">La demande de remboursement a été soumise à Finance pour autorisation.</div><?php endif; ?>

        <div class="sav-detail-grille">
            <section class="admin-panneau sav-detail-panneau">
                <header class="sav-detail-panneau__entete"><h2>Retour et réclamation</h2></header>
                <dl class="sav-detail-infos">
                    <div class="sav-detail-info"><dt>Client</dt><dd><?= $e($ticket['client_nom']) ?> · <?= $e($ticket['client_telephone']) ?></dd></div>
                    <div class="sav-detail-info"><dt>Motif</dt><dd><?= $e($ticket['motif']) ?></dd></div>
                    <div class="sav-detail-info sav-detail-info--large"><dt>Description initiale</dt><dd><?= nl2br($e($ticket['description'])) ?></dd></div>
                    <div class="sav-detail-info"><dt>Note de satisfaction — interne</dt><dd><?php $note = max(0, min(5, (int) $ticket['note'])); ?><?= $note ? $note . ' / 5' : 'Aucune note' ?></dd></div>
                    <div class="sav-detail-info sav-detail-info--large"><dt>Commentaire de satisfaction — interne</dt><dd><?= nl2br($e($ticket['commentaire'] ?: 'Aucun commentaire transmis.')) ?></dd></div>
                </dl>
                <p>Ces éléments de satisfaction sont réservés à l’équipe Qualité / SAV et ne sont pas affichés dans les espaces client ou entreprise.</p>
            </section>
            <section class="admin-panneau sav-detail-panneau sav-detail-traitement">
                <header class="sav-detail-panneau__entete"><h2>Traitement qualité</h2></header>
                <form method="post" class="sav-detail-form">
                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="traiter">
                    <label for="sav-categorie">Nature du dossier</label>
                    <select id="sav-categorie" name="categorie_qualite"><?php foreach ($categories as $key => $label): ?><option value="<?= $e($key) ?>" <?= $ticket['categorie_qualite'] === $key ? 'selected' : '' ?>><?= $e($label) ?></option><?php endforeach; ?></select>
                    <label for="sav-statut">Statut</label>
                    <select id="sav-statut" name="statut"><?php foreach ($statuts as $key => $label): ?><option value="<?= $e($key) ?>" <?= $ticket['statut'] === $key ? 'selected' : '' ?>><?= $e($label) ?></option><?php endforeach; ?></select>
                    <label for="sav-note-interne">Notes internes Qualité / SAV</label>
                    <textarea id="sav-note-interne" name="commentaire_conseiller" rows="5" maxlength="5000"><?= $e($ticket['commentaire_conseiller']) ?></textarea>
                    <button type="submit" class="sav-detail-enregistrer">Enregistrer le suivi</button>
                </form>
            </section>
        </div>

        <section class="admin-panneau sav-detail-panneau">
            <header class="sav-detail-panneau__entete"><h2>Historique de la mission</h2></header>
            <?php if (!$historiqueMission): ?><p>Aucune intervention enregistrée sur ce dossier.</p><?php else: ?>
                <?php foreach ($historiqueMission as $mission): ?>
                    <article class="sav-mission-history"><h3>Mission #<?= (int) $mission['id'] ?> · <?= $e(ucfirst(str_replace('_', ' ', $mission['statut']))) ?></h3>
                        <p>Technicien : <?= $e($mission['technicien_nom'] ?: '—') ?> · Partenaire : <?= $e($mission['partenaire_nom'] ?: '—') ?></p>
                        <p>Créneau : <?= $mission['date_creneau_planifie'] ? $e(date('d/m/Y', strtotime($mission['date_creneau_planifie']))) : '—' ?> · Début : <?= $mission['date_debut'] ? $e(date('d/m/Y H:i', strtotime($mission['date_debut']))) : '—' ?> · Fin : <?= $mission['date_fin'] ? $e(date('d/m/Y H:i', strtotime($mission['date_fin']))) : '—' ?></p>
                        <?php if ($mission['rapport']): ?><p><strong>Rapport :</strong><br><?= nl2br($e($mission['rapport'])) ?></p><?php endif; ?>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
        <section class="admin-panneau sav-detail-panneau">
            <header class="sav-detail-panneau__entete"><h2>Preuves et documents</h2></header>
            <?php if (!$preuves): ?><p>Aucune preuve jointe à la mission.</p><?php else: ?><ul><?php foreach ($preuves as $preuve): ?><li><?= $e($preuve['nom_original']) ?> · <?= $e(date('d/m/Y H:i', strtotime($preuve['date_creation']))) ?> — <a href="document-intervention.php?id=<?= (int) $preuve['id'] ?>">Télécharger</a></li><?php endforeach; ?></ul><?php endif; ?>
        </section>
        <section class="admin-panneau sav-detail-panneau">
            <header class="sav-detail-panneau__entete"><h2>Remboursements — autorisation Finance requise</h2></header>
            <?php if ($remboursements): ?><ul><?php foreach ($remboursements as $remboursement): ?><li><?= number_format((float) $remboursement['montant_demande'], 0, ',', ' ') ?> FCFA · <?= $e(ucfirst(str_replace('_', ' ', $remboursement['statut']))) ?> · <?= $e($remboursement['motif']) ?><?php if ($remboursement['commentaire_decision']): ?><br>Décision Finance : <?= $e($remboursement['commentaire_decision']) ?><?php endif; ?></li><?php endforeach; ?></ul><?php endif; ?>
            <?php if (!$remboursements || end($remboursements)['statut'] !== 'en_attente'): ?>
                <form method="post" class="sav-detail-form">
                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="demander_remboursement">
                    <label for="montant-remboursement">Montant proposé (FCFA)</label><input id="montant-remboursement" type="number" name="montant_demande" min="1" max="9999999999" step="0.01" required>
                    <label for="motif-remboursement">Justification à soumettre à Finance</label><textarea id="motif-remboursement" name="motif_remboursement" maxlength="3000" required></textarea>
                    <button class="sav-detail-enregistrer" type="submit">Soumettre pour autorisation</button>
                </form>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
