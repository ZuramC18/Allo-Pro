<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('clients');
require __DIR__ . '/../../includes/fiche-client-equipe.php';
