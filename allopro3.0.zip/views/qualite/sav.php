<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

$ticketModel = new TicketSav();
$statutFiltre = is_string($_GET['statut'] ?? null) ? $_GET['statut'] : '';
if (!in_array($statutFiltre, ['ouvert', 'en_cours', 'resolu'], true)) {
    $statutFiltre = '';
}
$noteMaxBrut = filter_var($_GET['note_max'] ?? null, FILTER_VALIDATE_INT);
$noteMax = $noteMaxBrut !== false && $noteMaxBrut >= 1 && $noteMaxBrut <= 5 ? $noteMaxBrut : null;
$origineFiltre = is_string($_GET['origine'] ?? null) ? $_GET['origine'] : '';
if (!in_array($origineFiltre, ['client', 'equipe', 'entreprise', 'historique'], true)) {
    $origineFiltre = '';
}
$categorieFiltre = is_string($_GET['categorie'] ?? null) ? $_GET['categorie'] : '';
$libellesCategories = [
    'mauvaise_experience' => 'Mauvaise expérience',
    'reclamation' => 'Réclamation',
    'incident' => 'Incident',
    'retard' => 'Retard',
    'intervention_incomplete' => 'Intervention incomplète',
    'reintervention' => 'Demande de réintervention',
    'litige' => 'Litige',
    'remboursement' => 'Remboursement',
];
if (!array_key_exists($categorieFiltre, $libellesCategories)) {
    $categorieFiltre = '';
}
$tickets = $ticketModel->getAllAvecFiltres(
    $statutFiltre ?: null,
    $noteMax,
    $origineFiltre ?: null,
    $categorieFiltre ?: null
);
$compteurs = $ticketModel->compterParStatut();
$compteursOrigine = $ticketModel->compterParOrigine();
$compteursCategorie = $ticketModel->compterParCategorieQualite();
$tempsMoyen = $ticketModel->tempsMoyenResolutionHeures();
$urlAvecFiltres = static function (array $changements = []) use ($statutFiltre, $noteMax, $origineFiltre, $categorieFiltre): string {
    $parametres = [];
    if ($statutFiltre !== '') {
        $parametres['statut'] = $statutFiltre;
    }
    if ($noteMax !== null) {
        $parametres['note_max'] = $noteMax;
    }
    if ($origineFiltre !== '') {
        $parametres['origine'] = $origineFiltre;
    }
    if ($categorieFiltre !== '') {
        $parametres['categorie'] = $categorieFiltre;
    }
    foreach ($changements as $cle => $valeur) {
        if ($valeur === null || $valeur === '') {
            unset($parametres[$cle]);
        } else {
            $parametres[$cle] = $valeur;
        }
    }
    return '?' . http_build_query($parametres);
};
$origineLibelles = [
    'client' => 'Client',
    'conseiller' => 'Conseiller',
    'coordinateur' => 'Coordinateur',
    'entreprise' => 'Entreprise',
    'historique' => 'Ancien ticket · origine inconnue',
];
$parametresRetourTicket = ltrim($urlAvecFiltres(), '?');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Qualité / SAV — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/sav-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/sav-admin.css') ?>">
</head>
<body class="page-admin-sav">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?>

    <main class="admin-contenu">
        <div class="admin-entete sav-entete">
            <div>
                <h1 class="admin-entete__titre">Espace Qualité / SAV</h1>
                <p class="admin-entete__sous-titre">Analysez les retours, incidents et reprises ; les avis de satisfaction sont réservés à l’équipe.</p>
                <?php if ($noteMax !== null): ?><p class="admin-entete__sous-titre">Filtre : notes de satisfaction ≤ <?= (int) $noteMax ?>/5 · <a href="<?= htmlspecialchars($urlAvecFiltres(['note_max' => null]), ENT_QUOTES, 'UTF-8') ?>">Effacer</a></p><?php endif; ?>
            </div>
        </div>

        <section class="admin-kpi-grille sav-kpis" aria-label="Indicateurs du service après-vente">
            <article class="admin-kpi-carte admin-kpi-carte--rouge">
                <div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M12 8v4m0 4h.01"/></svg></div>
                <div class="admin-kpi-carte__label">Ouverts</div><div class="admin-kpi-carte__valeur"><?= (int) $compteurs['ouvert'] ?></div>
            </article>
            <article class="admin-kpi-carte admin-kpi-carte--amber">
                <div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg></div>
                <div class="admin-kpi-carte__label">En cours</div><div class="admin-kpi-carte__valeur"><?= (int) $compteurs['en_cours'] ?></div>
            </article>
            <article class="admin-kpi-carte admin-kpi-carte--vert">
                <div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg></div>
                <div class="admin-kpi-carte__label">Résolus</div><div class="admin-kpi-carte__valeur"><?= (int) $compteurs['resolu'] ?></div>
            </article>
            <article class="admin-kpi-carte admin-kpi-carte--violet">
                <div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg></div>
                <div class="admin-kpi-carte__label">Délai moyen de résolution</div><div class="admin-kpi-carte__valeur"><?= $tempsMoyen ? round($tempsMoyen) . 'h' : '—' ?></div>
            </article>
        </section>

        <nav class="filtres-tabs sav-filtres" aria-label="Filtrer les tickets SAV">
            <a href="<?= htmlspecialchars($urlAvecFiltres(['statut' => null]), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= !$statutFiltre ? 'filtre-tab--actif' : '' ?>">Tous les statuts</a>
            <a href="<?= htmlspecialchars($urlAvecFiltres(['statut' => 'ouvert']), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $statutFiltre === 'ouvert' ? 'filtre-tab--actif' : '' ?>">Ouverts</a>
            <a href="<?= htmlspecialchars($urlAvecFiltres(['statut' => 'en_cours']), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $statutFiltre === 'en_cours' ? 'filtre-tab--actif' : '' ?>">En cours</a>
            <a href="<?= htmlspecialchars($urlAvecFiltres(['statut' => 'resolu']), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $statutFiltre === 'resolu' ? 'filtre-tab--actif' : '' ?>">Résolus</a>
        </nav>

        <nav class="filtres-tabs sav-filtres sav-filtres--origine" aria-label="Filtrer par avis client négatif ou origine du ticket">
            <a href="<?= htmlspecialchars($urlAvecFiltres(['origine' => null]), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= !$origineFiltre ? 'filtre-tab--actif' : '' ?>">Toutes les origines</a>
            <a href="<?= htmlspecialchars($urlAvecFiltres(['origine' => 'client']), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $origineFiltre === 'client' ? 'filtre-tab--actif' : '' ?>">Avis clients faibles (≤ 2/5) <span><?= (int) $compteursOrigine['client'] ?></span></a>
            <a href="<?= htmlspecialchars($urlAvecFiltres(['origine' => 'equipe']), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $origineFiltre === 'equipe' ? 'filtre-tab--actif' : '' ?>">Conseillers / coordinateurs <span><?= (int) $compteursOrigine['equipe'] ?></span></a>
            <a href="<?= htmlspecialchars($urlAvecFiltres(['origine' => 'entreprise']), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $origineFiltre === 'entreprise' ? 'filtre-tab--actif' : '' ?>">Entreprises <span><?= (int) $compteursOrigine['entreprise'] ?></span></a>
            <a href="<?= htmlspecialchars($urlAvecFiltres(['origine' => 'historique']), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $origineFiltre === 'historique' ? 'filtre-tab--actif' : '' ?>">Origine non enregistrée <span><?= (int) $compteursOrigine['historique'] ?></span></a>
        </nav>

        <nav class="filtres-tabs sav-filtres sav-filtres--categories" aria-label="Filtrer les dossiers par catégorie">
            <a href="<?= htmlspecialchars($urlAvecFiltres(['categorie' => null]), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $categorieFiltre === '' ? 'filtre-tab--actif' : '' ?>">Toutes les catégories</a>
            <?php foreach ($libellesCategories as $categorie => $libelle): ?>
                <a href="<?= htmlspecialchars($urlAvecFiltres(['categorie' => $categorie]), ENT_QUOTES, 'UTF-8') ?>" class="filtre-tab <?= $categorieFiltre === $categorie ? 'filtre-tab--actif' : '' ?>">
                    <?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?> <span><?= (int) $compteursCategorie[$categorie] ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <section class="admin-panneau sav-panneau" aria-label="Liste des tickets SAV">
            <header class="sav-panneau__entete">
                <h2><?= $categorieFiltre !== '' ? htmlspecialchars($libellesCategories[$categorieFiltre], ENT_QUOTES, 'UTF-8') : 'Tickets de service après-vente' ?></h2>
                <span><?= number_format(count($tickets), 0, ',', ' ') ?> ticket<?= count($tickets) === 1 ? '' : 's' ?></span>
            </header>
            <div class="sav-table-scroll">
                <table class="admin-table sav-table">
                    <thead>
                        <tr><th>Dossier</th><th>Client</th><th>Origine</th><th>Partenaire</th><th>Note interne</th><th>Nature qualité</th><th>Motif client</th><th>Statut</th><th>Ouvert le</th><th aria-label="Action"></th></tr>
                    </thead>
                    <tbody>
                    <?php if (empty($tickets)): ?>
                        <tr class="sav-vide"><td colspan="10">Aucun ticket.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($tickets as $t): ?>
                    <?php $note = max(0, min(5, (int) $t['note'])); ?>
                    <tr>
                        <td data-label="Dossier"><strong><?= htmlspecialchars($t['numero_dossier']) ?></strong><?php if (!empty($t['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($t['entreprise_b2b_nom']) ? ' · ' . htmlspecialchars($t['entreprise_b2b_nom'], ENT_QUOTES, 'UTF-8') : '' ?></span><?php endif; ?></td>
                        <td data-label="Client"><?= htmlspecialchars($t['client_nom']) ?></td>
                        <td data-label="Origine"><?= htmlspecialchars($origineLibelles[$t['origine'] ?? 'historique'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td data-label="Partenaire"><?= htmlspecialchars($t['nom_entreprise'] ?? '—') ?></td>
                        <td data-label="Note">
                            <?php if ($note > 0): ?>
                                <span class="sav-note" role="img" aria-label="<?= $note ?> sur 5">
                                    <?php for ($i = 0; $i < $note; $i++): ?>
                                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2 2.9 6 6.6 1-4.8 4.7 1.1 6.6-5.8-3.1-5.8 3.1 1.1-6.6L2.5 9l6.6-1L12 2Z"/></svg>
                                    <?php endfor; ?>
                                </span>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td data-label="Nature qualité"><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $t['categorie_qualite'] ?? 'reclamation')), ENT_QUOTES, 'UTF-8') ?></td>
                        <td data-label="Motif client" class="sav-motif"><?= htmlspecialchars($t['commentaire'] ?: '—') ?></td>
                        <td data-label="Statut"><span class="admin-badge admin-badge--<?= $t['statut'] === 'resolu' ? 'vert' : ($t['statut'] === 'en_cours' ? 'amber' : 'rouge') ?>"><?= htmlspecialchars($t['statut'] === 'resolu' ? 'Résolu' : ucfirst(str_replace('_', ' ', $t['statut']))) ?></span></td>
                        <td data-label="Ouvert le" class="sav-date"><?= date('d/m/Y', strtotime($t['date_creation'])) ?></td>
                        <td class="sav-action"><a href="sav-detail.php?id=<?= (int) $t['id'] ?><?= $parametresRetourTicket !== '' ? '&amp;' . htmlspecialchars($parametresRetourTicket, ENT_QUOTES, 'UTF-8') : '' ?>">Traiter <span aria-hidden="true">→</span></a></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
</body>
</html>