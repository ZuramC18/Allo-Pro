<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('devis_entreprises');
require_once __DIR__ . '/../../models/EntrepriseB2B.php';

$modeleEntreprise = new EntrepriseB2B();
$erreur = '';
$csrfKey = 'csrf_devis_entreprise_qualite';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $devisId = filter_var($_POST['devis_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($devisId === false) {
        $erreur = 'Le devis sélectionné est invalide.';
    } else {
        try {
            if ($action === 'qualifier') {
                $decision = is_string($_POST['decision'] ?? null) ? $_POST['decision'] : '';
                $commentaire = is_string($_POST['commentaire_qualite'] ?? null) ? $_POST['commentaire_qualite'] : '';
                if (!$modeleEntreprise->traiterQualificationDevis((int) $devisId, (int) $_SESSION['user_id'], $decision, $commentaire)) {
                    throw new RuntimeException('Cette demande a déjà été prise en charge ou est introuvable.');
                }
                journaliser('devis_entreprise.qualite_' . $decision, 'devis_b2b', (int) $devisId, null, $commentaire);
                header('Location: devis-entreprises.php?qualifie=1');
                exit;
            }
            throw new RuntimeException('Vous ne disposez pas des droits nécessaires pour cette action.');
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Traitement devis entreprise #' . (int) $devisId . ' par utilisateur ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
            $erreur = 'Le devis n’a pas pu être enregistré. Réessayez.';
        }
    }
}
$devisQualite = $modeleEntreprise->getDevisB2BPourQualite();
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Devis entreprises — Qualité / SAV</title><link rel="stylesheet" href="../../public/css/admin.css"><link rel="stylesheet" href="../../public/css/entreprise-b2b.css"></head>
<body><div class="admin-app"><?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?><main class="admin-contenu b2b-main">
<header class="b2b-header"><div><h1>Devis entreprises</h1><p>Vérifiez le périmètre technique et la faisabilité avant la proposition financière.</p></div></header>
    <?php if (($_GET['qualifie'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">La qualification technique a été enregistrée.</div><?php endif; ?>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
        <h2>À qualifier — Qualité / SAV</h2>
        <?php if (!$devisQualite): ?><section class="b2b-panel"><div class="b2b-empty">Aucune demande de devis à qualifier.</div></section>
        <?php else: foreach ($devisQualite as $ligne): ?><section class="b2b-panel">
            <h3><?= $e($ligne['numero']) ?> · <?= $e($ligne['entreprise_nom']) ?></h3>
            <?php if (!empty($ligne['numero_dossier'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise · <?= $e($ligne['entreprise_nom']) ?></span><?php endif; ?>
            <p><?= $ligne['numero_dossier'] ? 'Dossier ' . $e($ligne['numero_dossier']) . ' · ' : '' ?><?= nl2br($e($ligne['description'])) ?></p>
            <?php if (!empty($ligne['numero_dossier'])): ?><div class="b2b-actions"><a class="b2b-button b2b-button--secondary" href="detail-dossier.php?devis_id=<?= (int) $ligne['id'] ?>">Consulter le dossier <?= $e($ligne['numero_dossier']) ?></a></div><?php endif; ?>
            <?php if ($ligne['qualite_commentaire']): ?><p><strong>Précédente demande de précision :</strong><br><?= nl2br($e($ligne['qualite_commentaire'])) ?></p><?php endif; ?>
            <form method="post" class="b2b-form">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="devis_id" value="<?= (int) $ligne['id'] ?>"><input type="hidden" name="action" value="qualifier">
                <label>Note technique ou précisions attendues<textarea name="commentaire_qualite" maxlength="3000" required placeholder="Ex. : vérifier le câblage réseau, préciser les équipements à remplacer et signaler les informations manquantes."></textarea></label>
                <div class="b2b-actions"><button class="b2b-button" name="decision" value="valide" type="submit">Valider pour chiffrage</button><button class="b2b-button b2b-button--secondary" name="decision" value="a_preciser" type="submit">Demander des précisions</button></div>
            </form>
        </section><?php endforeach; endif; ?>
</main></div></body></html>
