<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['qualite']);
verifierAcces('clients');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Recherche clients — Qualité / SAV</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/clients-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/clients-admin.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?>

    <main class="admin-contenu">
        <header class="admin-entete">
            <div>
                <h1 class="admin-entete__titre">Recherche de clients</h1>
                <p class="admin-entete__sous-titre" id="clients-resultats-compte" aria-live="polite">Saisissez au moins 2 caractères pour lancer la recherche.</p>
            </div>
        </header>

        <form method="get" class="admin-recherche clients-recherche" id="clients-recherche-form" role="search">
            <label class="visually-hidden" for="clients-recherche-q">Nom, email ou téléphone</label>
            <input type="search" name="q" id="clients-recherche-q" aria-label="Rechercher un client" placeholder="Nom, email ou téléphone…" autocomplete="off">
            <button type="submit">Rechercher</button>
            <button type="button" class="admin-recherche__reset" id="clients-recherche-reset" hidden>Effacer</button>
        </form>

        <section class="admin-panneau clients-panneau" aria-label="Résultats de recherche clients" aria-busy="false">
            <table class="admin-table clients-table">
                <thead>
                    <tr>
                        <th scope="col">Client</th><th scope="col">Contact</th><th scope="col">Dossiers</th><th scope="col">En cours</th><th scope="col">Inscrit le</th><th scope="col">Statut</th><th scope="col"><span class="visually-hidden">Action</span></th>
                    </tr>
                </thead>
                <tbody id="clients-resultats">
                    <tr class="clients-table__empty"><td colspan="7">Les résultats apparaîtront ici après votre recherche.</td></tr>
                </tbody>
            </table>
        </section>
    </main>
</div>
<script src="../../public/js/recherche-clients-qualite.js?v=<?= filemtime(__DIR__ . '/../../public/js/recherche-clients-qualite.js') ?>" defer></script>
</body>
</html>
