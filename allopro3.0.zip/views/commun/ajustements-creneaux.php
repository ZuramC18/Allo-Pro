<?php
require_once __DIR__ . '/../../models/AjustementCreneauAutomatique.php';
require_once __DIR__ . '/../../includes/audit.php';

$modeleAjustements = new AjustementCreneauAutomatique();
$csrfKeyAjustements = 'csrf_ajustements_creneaux';
if (empty($_SESSION[$csrfKeyAjustements])) {
    $_SESSION[$csrfKeyAjustements] = bin2hex(random_bytes(32));
}
$erreurAjustements = '';
$succesAjustements = is_string($_SESSION['flash_ajustements_creneaux'] ?? null)
    ? $_SESSION['flash_ajustements_creneaux']
    : '';
unset($_SESSION['flash_ajustements_creneaux']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $ajustementId = filter_var($_POST['ajustement_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!in_array($rolePageCreneaux, ['admin', 'coordinateur'], true)) {
        http_response_code(403);
        $erreurAjustements = 'Seuls le coordinateur et l’administrateur peuvent traiter une alerte.';
    } elseif (!hash_equals($_SESSION[$csrfKeyAjustements], $csrf)) {
        http_response_code(403);
        $erreurAjustements = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($ajustementId === false) {
        $erreurAjustements = 'Cette alerte n’est pas valide.';
    } elseif ($modeleAjustements->marquerTraitee((int) $ajustementId, (int) $_SESSION['user_id'])) {
        journaliser(
            'creneau.ajustement_traite',
            'ajustement_creneau',
            (int) $ajustementId,
            (string) $ajustementId,
            'Le changement automatique de créneau a été pris en compte.'
        );
        $_SESSION['flash_ajustements_creneaux'] = 'L’alerte a été marquée comme traitée.';
        header('Location: ajustements-creneaux.php');
        exit;
    } else {
        $erreurAjustements = 'Cette alerte a déjà été traitée ou n’existe plus. Actualisez la page.';
    }
}

$ajustements = $modeleAjustements->getRecentes();
$nombreAjustementsOuverts = $modeleAjustements->compterATraiter();
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$formatDateCreneau = static fn(string $date, int $heure): string => date('d/m/Y', strtotime($date))
    . ' à ' . sprintf('%02d:00', $heure);
$titreRole = $rolePageCreneaux === 'coordinateur'
    ? 'Coordination'
    : ($rolePageCreneaux === 'conseiller' ? 'Espace conseiller' : 'Administration');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Changements de créneaux — ALLÔ PRO</title>
    <?php if ($rolePageCreneaux === 'admin'): ?>
        <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <?php elseif ($rolePageCreneaux === 'coordinateur'): ?>
        <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
        <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php else: ?>
        <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="../../public/css/ajustements-creneaux.css?v=<?= filemtime(__DIR__ . '/../../public/css/ajustements-creneaux.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<?php if ($rolePageCreneaux === 'admin'): ?>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu">
<?php elseif ($rolePageCreneaux === 'coordinateur'): ?>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main"><div class="coord-page">
<?php else: ?>
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>
    <main class="contenu">
<?php endif; ?>
        <section class="ajustements-page">
            <header class="ajustements-entete">
                <div>
                    <span class="ajustements-surtitre"><?= $e($titreRole) ?> · Suivi des demandes</span>
                    <h1>Changements automatiques de créneau</h1>
                    <p>Le système a réservé le premier créneau libre après la préférence du client. Les alertes ouvertes nécessitent un suivi de l’équipe.</p>
                </div>
                <div class="ajustements-compteur">
                    <strong><?= $nombreAjustementsOuverts ?></strong>
                    <span>alerte<?= $nombreAjustementsOuverts === 1 ? '' : 's' ?> à traiter</span>
                </div>
            </header>

            <?php if ($succesAjustements !== ''): ?><div class="ajustements-message ajustements-message--succes" role="status"><?= $e($succesAjustements) ?></div><?php endif; ?>
            <?php if ($erreurAjustements !== ''): ?><div class="ajustements-message ajustements-message--erreur" role="alert"><?= $e($erreurAjustements) ?></div><?php endif; ?>

            <?php if (!$ajustements): ?>
                <div class="ajustements-vide">
                    <strong>Aucun changement automatique enregistré</strong>
                    <p>Les demandes avec un créneau respecté ou sans créneau souhaité ne génèrent pas d’alerte.</p>
                </div>
            <?php else: ?>
                <div class="ajustements-liste">
                    <?php foreach ($ajustements as $ajustement): ?>
                        <article class="ajustement-carte <?= $ajustement['statut'] === 'a_traiter' ? 'ajustement-carte--ouverte' : '' ?>">
                            <div class="ajustement-carte__entete">
                                <div>
                                    <a class="ajustement-dossier" href="traiter-demande.php?id=<?= (int) $ajustement['demande_id'] ?>">Dossier <?= $e($ajustement['numero_dossier']) ?> ↗</a>
                                    <h2>Créneau automatiquement déplacé</h2>
                                </div>
                                <span class="ajustement-etat <?= $ajustement['statut'] === 'a_traiter' ? 'ajustement-etat--ouvert' : 'ajustement-etat--traite' ?>">
                                    <?= $ajustement['statut'] === 'a_traiter' ? 'À traiter' : 'Traité' ?>
                                </span>
                            </div>
                            <p class="ajustement-message">
                                Le créneau demandé par le client,
                                <strong><?= $e($formatDateCreneau($ajustement['date_creneau_demande'], (int) $ajustement['heure_creneau_demandee'])) ?></strong>,
                                n’étant pas disponible, le système a réservé le
                                <strong><?= $e($formatDateCreneau($ajustement['date_creneau_attribue'], (int) $ajustement['heure_creneau_attribuee'])) ?></strong>
                                avec <strong><?= $e($ajustement['technicien_nom']) ?></strong>.
                            </p>
                            <footer class="ajustement-carte__pied">
                                <span>Créé le <?= $e(date('d/m/Y à H:i', strtotime($ajustement['date_creation']))) ?></span>
                                <?php if ($ajustement['statut'] === 'traitee'): ?>
                                    <span>Pris en compte<?= $ajustement['traiteur_nom'] ? ' par ' . $e($ajustement['traiteur_nom']) : '' ?><?= $ajustement['date_traitement'] ? ' le ' . $e(date('d/m/Y à H:i', strtotime($ajustement['date_traitement']))) : '' ?></span>
                                <?php elseif (in_array($rolePageCreneaux, ['admin', 'coordinateur'], true)): ?>
                                    <form method="post">
                                        <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKeyAjustements]) ?>">
                                        <input type="hidden" name="ajustement_id" value="<?= (int) $ajustement['id'] ?>">
                                        <button class="ajustement-action" type="submit">Marquer comme traité</button>
                                    </form>
                                <?php endif; ?>
                            </footer>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
<?php if ($rolePageCreneaux === 'coordinateur'): ?>
    </div></main>
<?php else: ?>
    </main>
<?php endif; ?>
</div>
<script src="../../public/js/ajustements-creneaux-notifications.js?v=<?= filemtime(__DIR__ . '/../../public/js/ajustements-creneaux-notifications.js') ?>" defer></script>
</body>
</html>
