<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Partenaire.php';

$partenaire = (new Partenaire())->getById((int) $_SESSION['partenaire_id']);
if (!$partenaire) {
    http_response_code(404);
    exit('Compte partenaire introuvable.');
}
$sections = sectionsConditionsGeneralesPartenaire();
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Conditions générales — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-documents-legaux.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-documents-legaux.css') ?>">
</head>
<body class="page-partenaire-document">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>
    <main class="contenu partenaire-document-page">
        <a class="partenaire-document__retour" href="profil.php"><?= icone('arrow', 15) ?> Retour au profil</a>
        <header class="partenaire-document__hero">
            <span>Espace partenaire · <?= $echapper($partenaire['nom_entreprise']) ?></span>
            <h1>Conditions générales d’utilisation</h1>
            <p>Version de travail <?= VERSION_DOCUMENTS_PARTENAIRE ?> · Consultation en lecture seule</p>
        </header>
        <div class="partenaire-document__avertissement">
            <strong>Projet à compléter et à faire valider</strong>
            <p>Ces conditions constituent une première trame modifiable. Elles ne sont pas une version juridique finale.</p>
        </div>
        <article class="partenaire-document__feuille">
            <?php foreach ($sections as $section): ?>
                <section class="partenaire-document__section">
                    <h2><?= $echapper($section['titre']) ?></h2>
                    <?php foreach ($section['paragraphes'] as $paragraphe): ?>
                        <p><?= $echapper($paragraphe) ?></p>
                    <?php endforeach; ?>
                </section>
            <?php endforeach; ?>
        </article>
    </main>
</div>
</body>
</html>
