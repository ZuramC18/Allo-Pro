<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/ReversementTechnicien.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$technicienId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$reversementModel = new ReversementTechnicien();
$technicien = $technicienId !== false && $technicienId !== null && $technicienId > 0
    ? $reversementModel->getTechnicienParPartenaire($technicienId, $partenaireId)
    : false;
$missions = $technicien
    ? $reversementModel->getMissionsParTechnicien((int) $technicien['id'], $partenaireId)
    : [];

$csrfSession = 'csrf_reversement_technicien';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}

$erreur = '';
$succes = is_string($_SESSION['flash_reversement_technicien'] ?? null)
    ? $_SESSION['flash_reversement_technicien']
    : '';
unset($_SESSION['flash_reversement_technicien']);

$methodes = [
    'especes' => 'Espèces',
    'wave' => 'Wave',
    'orange_money' => 'Orange Money',
    'virement' => 'Virement bancaire',
    'autre' => 'Autre',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $technicien) {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $interventionId = filter_var($_POST['intervention_id'] ?? null, FILTER_VALIDATE_INT);
    $montant = is_string($_POST['montant'] ?? null) ? trim($_POST['montant']) : '';
    $methode = is_string($_POST['methode'] ?? null) ? $_POST['methode'] : '';
    $reference = is_string($_POST['reference'] ?? null) ? trim($_POST['reference']) : '';

    if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($interventionId === false || $interventionId === null || $interventionId < 1) {
        http_response_code(400);
        $erreur = 'L’intervention sélectionnée est invalide.';
    } elseif (!preg_match('/\A\d{1,8}(?:[.,]\d{1,2})?\z/', $montant) || (float) str_replace(',', '.', $montant) <= 0) {
        $erreur = 'Saisissez un montant supérieur à zéro, avec deux décimales au maximum.';
    } elseif (!isset($methodes[$methode])) {
        $erreur = 'Sélectionnez un moyen de paiement valide.';
    } elseif (mb_strlen($reference) > 100) {
        $erreur = 'La référence de paiement ne peut pas dépasser 100 caractères.';
    } else {
        try {
            $reversementId = $reversementModel->enregistrerPaiement(
                $interventionId,
                $partenaireId,
                (int) $technicien['id'],
                $montant,
                $methode,
                $reference
            );
            journaliser(
                'reversement_technicien.enregistre',
                'reversement_technicien',
                $reversementId,
                $technicien['matricule'] ?? $technicien['nom'],
                number_format((float) str_replace(',', '.', $montant), 2, '.', '') . ' F CFA · ' . $methodes[$methode]
            );
            $_SESSION['flash_reversement_technicien'] = 'Le paiement du technicien a été enregistré.';
            header('Location: reversement-technicien.php?id=' . (int) $technicien['id']);
            exit;
        } catch (RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000' && (int) ($exception->errorInfo[1] ?? 0) === 1062) {
                $erreur = 'Un paiement est déjà enregistré pour cette intervention.';
            } else {
                error_log('Enregistrement reversement technicien, partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
                $erreur = 'Le paiement n’a pas pu être enregistré. Vérifiez les informations puis réessayez.';
            }
        }
    }
    $missions = $reversementModel->getMissionsParTechnicien((int) $technicien['id'], $partenaireId);
}

if (!$technicien) {
    http_response_code(404);
}
$nomComplet = $technicien
    ? (trim(implode(' ', array_filter([$technicien['prenom'] ?? '', $technicien['nom_famille'] ?? '']))) ?: (string) $technicien['nom'])
    : '';
$missionsEnAttente = array_filter($missions, static fn(array $mission): bool => $mission['reversement_id'] === null);
$missionsPayees = array_filter($missions, static fn(array $mission): bool => $mission['reversement_id'] !== null);
$totalVerse = array_sum(array_map(static fn(array $mission): float => (float) $mission['montant_verse'], $missionsPayees));
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$formaterMontant = static fn($montant): string => number_format((float) $montant, 0, ',', ' ') . ' F CFA';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $technicien ? 'Paiements de ' . $echapper($nomComplet) : 'Technicien introuvable' ?> — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-reversement-techniciens.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-reversement-techniciens.css') ?>">
</head>
<body class="page-partenaire-reversement-techniciens">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <a class="reversement-retour" href="reversement.php"><?= icone('arrow', 16) ?> Retour à la liste des techniciens</a>
        <?php if (!$technicien): ?>
            <section class="reversement-carte reversement-introuvable">
                <h1>Technicien introuvable</h1>
                <p>Ce technicien n’existe pas ou n’appartient pas à votre équipe.</p>
                <a href="reversement.php">Revenir à la liste des techniciens</a>
            </section>
        <?php else: ?>
            <header class="contenu__entete reversement-entete">
                <div>
                    <h1 class="contenu__titre"><?= $echapper($nomComplet) ?></h1>
                    <p><?= $echapper($technicien['matricule'] ?? 'Technicien') ?> · Paiements de ses interventions terminées</p>
                </div>
            </header>

            <?php if ($succes !== ''): ?>
                <div class="reversement-message reversement-message--succes" role="status"><?= $echapper($succes) ?></div>
            <?php endif; ?>
            <?php if ($erreur !== ''): ?>
                <div class="reversement-message reversement-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
            <?php endif; ?>

            <section class="reversement-resume" aria-label="Résumé des paiements du technicien">
                <article><span>Interventions terminées</span><strong><?= count($missions) ?></strong></article>
                <article><span>À payer</span><strong><?= count($missionsEnAttente) ?></strong></article>
                <article><span>Total versé</span><strong><?= $formaterMontant($totalVerse) ?></strong></article>
            </section>

            <section class="reversement-carte" aria-labelledby="reversement-interventions-titre">
                <header class="reversement-carte__entete">
                    <div>
                        <h2 id="reversement-interventions-titre">Interventions effectuées</h2>
                        <p>Le montant facturé au client est indicatif ; saisissez le montant réellement versé au technicien.</p>
                    </div>
                    <span class="reversement-compteur"><?= count($missions) ?></span>
                </header>
                <?php if ($missions): ?>
                    <div class="reversement-liste">
                        <?php foreach ($missions as $mission): ?>
                            <article class="reversement-mission">
                                <div class="reversement-mission__infos">
                                    <span class="reversement-mission__dossier"><?= $echapper($mission['numero_dossier']) ?></span>
                                    <h3><?= $echapper($mission['categorie_nom'] ?? 'Intervention') ?></h3>
                                    <p>Terminée le <?= !empty($mission['date_fin']) ? $echapper(date('d/m/Y', strtotime($mission['date_fin']))) : 'Date inconnue' ?></p>
                                    <small>Montant facturé au client : <strong><?= $mission['montant_intervention'] !== null ? $formaterMontant($mission['montant_intervention']) : 'Non renseigné' ?></strong></small>
                                </div>
                                <?php if ($mission['reversement_id'] === null): ?>
                                    <form method="POST" class="reversement-formulaire" onsubmit="return confirm('Confirmez-vous que ce paiement au technicien a bien été effectué ?');">
                                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                        <input type="hidden" name="intervention_id" value="<?= (int) $mission['intervention_id'] ?>">
                                        <label>
                                            <span>Montant versé (F CFA)</span>
                                            <input type="number" name="montant" min="0.01" max="99999999.99" step="0.01" inputmode="decimal" placeholder="Ex. 25 000" required>
                                        </label>
                                        <label>
                                            <span>Moyen de paiement</span>
                                            <select name="methode" required>
                                                <option value="">Choisir</option>
                                                <?php foreach ($methodes as $cle => $libelle): ?>
                                                    <option value="<?= $echapper($cle) ?>"><?= $echapper($libelle) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </label>
                                        <label>
                                            <span>Référence (facultatif)</span>
                                            <input type="text" name="reference" maxlength="100" placeholder="Référence du transfert">
                                        </label>
                                        <button type="submit"><?= icone('check', 16) ?> Enregistrer le paiement</button>
                                    </form>
                                <?php else: ?>
                                    <div class="reversement-paiement-enregistre">
                                        <span class="paiement-statut paiement-statut--paye">Payé le <?= $echapper(date('d/m/Y', strtotime($mission['date_paiement']))) ?></span>
                                        <strong><?= $formaterMontant($mission['montant_verse']) ?></strong>
                                        <small><?= $echapper($methodes[$mission['methode']] ?? 'Autre') ?><?= !empty($mission['reference']) ? ' · Réf. ' . $echapper($mission['reference']) : '' ?></small>
                                    </div>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="reversement-vide">
                        <span><?= icone('inbox', 24) ?></span>
                        <strong>Aucune intervention terminée pour ce technicien.</strong>
                        <p>Les interventions terminées seront listées ici.</p>
                    </div>
                <?php endif; ?>
            </section>
            <p class="reversement-note">L’enregistrement confirme un paiement déjà réalisé et ne déclenche pas de transfert automatique. Un seul versement peut être associé à chaque intervention.</p>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
