<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/ReversementTechnicien.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$techniciens = (new ReversementTechnicien())->getTechniciensPartenaire($partenaireId);
$succes = is_string($_SESSION['flash_reversement_technicien'] ?? null)
    ? $_SESSION['flash_reversement_technicien']
    : '';
unset($_SESSION['flash_reversement_technicien']);
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$formaterMontant = static fn($montant): string => number_format((float) $montant, 0, ',', ' ') . ' F CFA';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paiements des techniciens — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-reversement-techniciens.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-reversement-techniciens.css') ?>">
</head>
<body class="page-partenaire-reversement-techniciens">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <header class="contenu__entete reversement-entete">
            <div>
                <h1 class="contenu__titre">Paiements des techniciens</h1>
                <p>Sélectionnez un technicien pour consulter ses interventions terminées et enregistrer ses paiements.</p>
            </div>
        </header>

        <?php if ($succes !== ''): ?>
            <div class="reversement-message reversement-message--succes" role="status"><?= $echapper($succes) ?></div>
        <?php endif; ?>

        <section class="reversement-techniciens" aria-label="Liste des techniciens">
            <?php if ($techniciens): ?>
                <?php foreach ($techniciens as $technicien): ?>
                    <?php $nomComplet = trim(implode(' ', array_filter([
                        $technicien['prenom'] ?? '',
                        $technicien['nom_famille'] ?? '',
                    ]))) ?: (string) $technicien['nom']; ?>
                    <a class="reversement-technicien" href="reversement-technicien.php?id=<?= (int) $technicien['id'] ?>">
                        <span class="reversement-technicien__avatar"><?= $echapper(mb_strtoupper(mb_substr($nomComplet, 0, 1))) ?></span>
                        <span class="reversement-technicien__identite">
                            <strong><?= $echapper($nomComplet) ?></strong>
                            <small><?= $echapper($technicien['matricule'] ?? 'Technicien') ?> · <?= $technicien['statut'] === 'actif' ? 'Actif' : 'Inactif' ?></small>
                        </span>
                        <span class="reversement-technicien__stats">
                            <span><strong><?= (int) $technicien['nombre_interventions'] ?></strong> intervention<?= (int) $technicien['nombre_interventions'] === 1 ? '' : 's' ?></span>
                            <?php if ((int) $technicien['nombre_a_payer'] > 0): ?>
                                <span class="reversement-technicien__a-payer"><?= (int) $technicien['nombre_a_payer'] ?> à payer</span>
                            <?php else: ?>
                                <span class="reversement-technicien__paye">À jour</span>
                            <?php endif; ?>
                            <small><?= $formaterMontant($technicien['total_verse']) ?> versés</small>
                        </span>
                        <span class="reversement-technicien__fleche"><?= icone('arrow', 18) ?></span>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="reversement-vide">
                    <span><?= icone('users', 24) ?></span>
                    <strong>Aucun technicien dans votre équipe.</strong>
                    <p>Ajoutez un technicien pour consulter et suivre ses paiements.</p>
                </div>
            <?php endif; ?>
        </section>
        <p class="reversement-note">Les montants enregistrés correspondent aux paiements déclarés par le partenaire. Aucun transfert automatique n’est effectué depuis cette page.</p>
    </main>
</div>
</body>
</html>
