<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Partenaire.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$partenaireModel = new Partenaire();
$partenaire = $partenaireModel->getById($partenaireId);
if (!$partenaire) {
    http_response_code(404);
    exit('Compte partenaire introuvable.');
}

$csrfCle = 'csrf_contrat_partenaire';
if (empty($_SESSION[$csrfCle])) {
    $_SESSION[$csrfCle] = bin2hex(random_bytes(32));
}
$erreur = '';
$messageSucces = '';
$version = (string) ($partenaire['contrat_version'] ?? VERSION_DOCUMENTS_PARTENAIRE);
$sections = sectionsContratPartenaire($partenaire);

if (!empty($partenaire['contrat_signe_at'])) {
    $contenuSigne = json_decode((string) ($partenaire['contrat_contenu'] ?? ''), true);
    if (is_array($contenuSigne) && isset($contenuSigne['sections']) && is_array($contenuSigne['sections'])) {
        $sections = $contenuSigne['sections'];
        $version = (string) ($contenuSigne['version'] ?? $version);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    if (!hash_equals($_SESSION[$csrfCle], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($action !== 'signer') {
        http_response_code(400);
        $erreur = 'Action de formulaire invalide.';
    } elseif (!empty($partenaire['contrat_signe_at'])) {
        $messageSucces = 'Ce contrat a déjà été signé et ne peut pas être modifié.';
    } elseif (trim((string) ($partenaire['nom_representant'] ?? '')) === '') {
        $erreur = 'Renseignez d’abord le nom du représentant dans votre profil avant de signer le contrat.';
    } elseif (($_POST['accepter_contrat'] ?? '') !== '1') {
        $erreur = 'Vous devez confirmer avoir lu et accepter le contrat pour le signer.';
    } else {
        $sections = sectionsContratPartenaire($partenaire);
        $contenu = json_encode(
            ['version' => VERSION_DOCUMENTS_PARTENAIRE, 'sections' => $sections],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
        $ip = is_string($_SERVER['REMOTE_ADDR'] ?? null) ? $_SERVER['REMOTE_ADDR'] : '';
        $agentUtilisateur = is_string($_SERVER['HTTP_USER_AGENT'] ?? null)
            ? mb_substr($_SERVER['HTTP_USER_AGENT'], 0, 500, 'UTF-8')
            : '';

        try {
            if ($partenaireModel->signerContrat(
                $partenaireId,
                trim((string) $partenaire['nom_representant']),
                VERSION_DOCUMENTS_PARTENAIRE,
                $contenu,
                $ip,
                $agentUtilisateur
            )) {
                journaliser(
                    'partenaire.contrat_signe',
                    'partenaire',
                    $partenaireId,
                    $partenaire['matricule'] ?? null,
                    'Contrat partenaire ' . VERSION_DOCUMENTS_PARTENAIRE . ' signé par ' . $partenaire['nom_representant']
                );
                $_SESSION['flash_contrat_partenaire'] = 'Votre signature a été enregistrée. Le contrat signé reste disponible en lecture seule dans votre profil.';
                header('Location: contrat.php');
                exit;
            }
            $erreur = 'Le contrat a déjà été signé ou n’a pas pu être enregistré. Rechargez la page.';
        } catch (PDOException $exception) {
            error_log('Signature contrat partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
            $erreur = 'Une erreur est survenue lors de l’enregistrement de la signature.';
        }
    }
}

$messageSucces = $messageSucces !== ''
    ? $messageSucces
    : (is_string($_SESSION['flash_contrat_partenaire'] ?? null) ? $_SESSION['flash_contrat_partenaire'] : '');
unset($_SESSION['flash_contrat_partenaire']);
$estSigne = !empty($partenaire['contrat_signe_at']);
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contrat de partenariat — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-documents-legaux.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-documents-legaux.css') ?>">
</head>
<body class="page-partenaire-document">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>
    <main class="contenu partenaire-document-page">
        <a class="partenaire-document__retour" href="profil.php"><?= icone('arrow', 15) ?> Retour au profil</a>
        <header class="partenaire-document__hero">
            <span>Partenariat ALLÔ PRO</span>
            <h1>Contrat de partenariat</h1>
            <p>Version <?= $echapper($version) ?> · Document lié au compte <?= $echapper($partenaire['matricule'] ?? '') ?></p>
        </header>

        <?php if ($messageSucces !== ''): ?><div class="partenaire-document__message partenaire-document__message--succes" role="status"><?= $echapper($messageSucces) ?></div><?php endif; ?>
        <?php if ($erreur !== ''): ?><div class="partenaire-document__message partenaire-document__message--erreur" role="alert"><?= $echapper($erreur) ?></div><?php endif; ?>

        <?php if (!$estSigne): ?>
            <div class="partenaire-document__avertissement">
                <strong>Projet de contrat à personnaliser</strong>
                <p>Cette première trame est fournie pour être modifiée et complétée. Faites vérifier les clauses et renseignez les conditions commerciales définitives avant de la faire signer.</p>
            </div>
        <?php endif; ?>

        <article class="partenaire-document__feuille">
            <div class="partenaire-document__parties">
                <p><strong>Plateforme :</strong> ALLÔ PRO</p>
                <p><strong>Partenaire :</strong> <?= $echapper($partenaire['nom_entreprise']) ?></p>
                <p><strong>Représentant :</strong> <?= $echapper($partenaire['nom_representant'] ?? '') ?: 'À renseigner dans le profil' ?></p>
            </div>
            <?php foreach ($sections as $section): ?>
                <?php if (!is_array($section) || !isset($section['titre'], $section['paragraphes']) || !is_array($section['paragraphes'])): continue; endif; ?>
                <section class="partenaire-document__section">
                    <h2><?= $echapper($section['titre']) ?></h2>
                    <?php foreach ($section['paragraphes'] as $paragraphe): ?>
                        <p><?= $echapper($paragraphe) ?></p>
                    <?php endforeach; ?>
                </section>
            <?php endforeach; ?>
        </article>

        <?php if ($estSigne): ?>
            <section class="partenaire-document__signature" aria-label="Preuve de signature">
                <span><?= icone('check', 18) ?></span>
                <div>
                    <strong>Contrat signé en ligne par <?= $echapper($partenaire['nom_representant']) ?></strong>
                    <p>Enregistré le <?= $echapper(date('d/m/Y à H:i', strtotime((string) $partenaire['contrat_signe_at']))) ?> · Version <?= $echapper($version) ?></p>
                    <small>Copie conservée avec l’horodatage, l’identifiant du partenaire et l’empreinte technique de la session.</small>
                </div>
            </section>
        <?php elseif (trim((string) ($partenaire['nom_representant'] ?? '')) === ''): ?>
            <div class="partenaire-document__action">
                <p>Renseignez le nom du représentant légal ou de l’administrateur dans votre profil avant de signer.</p>
                <a class="partenaire-document__bouton" href="profil.php">Compléter mon profil <?= icone('arrow', 15) ?></a>
            </div>
        <?php else: ?>
            <form method="POST" class="partenaire-document__action">
                <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfCle]) ?>">
                <input type="hidden" name="action" value="signer">
                <label>
                    <input type="checkbox" name="accepter_contrat" value="1" required>
                    <span>Je confirme avoir lu le présent projet de contrat et, en tant que représentant de <strong><?= $echapper($partenaire['nom_entreprise']) ?></strong>, j’accepte et signe cette version.</span>
                </label>
                <button class="partenaire-document__bouton" type="submit"><?= icone('check', 16) ?> Signer le contrat</button>
            </form>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
