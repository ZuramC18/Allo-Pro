<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Zone.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$partenaireModel = new Partenaire();
$zoneModel = new Zone();
$csrfSession = 'csrf_partenaire_zones_intervention';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}

$recherche = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
$erreur = '';
$messageSucces = is_string($_SESSION['flash_partenaire_zones'] ?? null)
    ? $_SESSION['flash_partenaire_zones']
    : '';
unset($_SESSION['flash_partenaire_zones']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    $zoneId = filter_var($_POST['zone_id'] ?? null, FILTER_VALIDATE_INT);
    $recherchePostee = is_string($_POST['q'] ?? null) ? trim($_POST['q']) : '';

    if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($zoneId === false || $zoneId < 1) {
        $erreur = 'Le quartier sélectionné est invalide.';
    } elseif ($action === 'ajouter' && $partenaireModel->ajouterZoneIntervention($partenaireId, $zoneId)) {
        $_SESSION['flash_partenaire_zones'] = 'Le quartier a été ajouté à vos zones d’intervention.';
        header('Location: zones-intervention.php' . ($recherchePostee !== '' ? '?q=' . rawurlencode($recherchePostee) : ''));
        exit;
    } elseif ($action === 'retirer' && $partenaireModel->retirerZoneIntervention($partenaireId, $zoneId)) {
        $_SESSION['flash_partenaire_zones'] = 'Le quartier a été retiré de vos zones d’intervention.';
        header('Location: zones-intervention.php' . ($recherchePostee !== '' ? '?q=' . rawurlencode($recherchePostee) : ''));
        exit;
    } else {
        $erreur = 'Cette action n’a pas pu être effectuée. Actualisez la page puis réessayez.';
    }
}

$zonesSelectionnees = $partenaireModel->getZonesIntervention($partenaireId);
$idsSelectionnes = array_fill_keys(array_map('intval', array_column($zonesSelectionnees, 'id')), true);
$quartiers = $zoneModel->rechercherQuartiers(null, '', 'active', 'ville_asc');
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Zones d’intervention — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-zones-intervention.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-zones-intervention.css') ?>">
</head>
<body class="page-partenaire-zones">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <header class="contenu__entete zones-entete">
            <div>
                <h1 class="contenu__titre">Zones d’intervention</h1>
                <p>Choisissez les quartiers où votre équipe peut intervenir. Cliquez sur un quartier pour l’ajouter.</p>
            </div>
        </header>

        <?php if ($messageSucces !== ''): ?>
            <div class="zones-message zones-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur !== ''): ?>
            <div class="zones-message zones-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <div class="zones-grille">
            <section class="zones-carte" aria-labelledby="zones-selectionnees-titre">
                <header class="zones-carte__entete">
                    <div><h2 id="zones-selectionnees-titre">Mes quartiers</h2><p><?= count($zonesSelectionnees) ?> sélectionné<?= count($zonesSelectionnees) === 1 ? '' : 's' ?></p></div>
                </header>
                <?php if (!$zonesSelectionnees): ?>
                    <p class="zones-vide">Aucun quartier sélectionné. Ajoutez les zones couvertes par votre équipe pour recevoir des demandes correspondantes.</p>
                <?php else: ?>
                    <ul class="zones-selection-liste">
                        <?php foreach ($zonesSelectionnees as $zone): ?>
                            <li>
                                <span class="zones-puce-icone" aria-hidden="true"><?= icone('pin', 16) ?></span>
                                <span class="zones-selection-liste__nom"><strong><?= $echapper($zone['nom']) ?></strong><small><?= $echapper($zone['ville_nom']) ?></small></span>
                                <form method="POST">
                                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                    <input type="hidden" name="action" value="retirer">
                                    <input type="hidden" name="zone_id" value="<?= (int) $zone['id'] ?>">
                                    <input type="hidden" name="q" value="<?= $echapper($recherche) ?>">
                                    <button class="zones-retirer" type="submit" aria-label="Retirer <?= $echapper($zone['nom']) ?>">Retirer</button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>

            <section class="zones-carte zones-recherche" aria-labelledby="zones-disponibles-titre">
                <header class="zones-carte__entete">
                    <div><h2 id="zones-disponibles-titre">Ajouter un quartier</h2><p>Recherchez dans les quartiers disponibles puis cliquez pour ajouter.</p></div>
                </header>
                <label class="zones-recherche__champ" for="recherche-quartier">
                    <?= icone('search', 18) ?>
                    <span class="sr-only">Rechercher un quartier ou une ville</span>
                    <input id="recherche-quartier" type="search" value="<?= $echapper($recherche) ?>" placeholder="Ex. Plateau, Almadies…" autocomplete="off">
                </label>
                <div class="zones-disponibles" id="quartiers-disponibles">
                    <?php foreach ($quartiers as $quartier): ?>
                        <?php if (isset($idsSelectionnes[(int) $quartier['id']])) continue; ?>
                        <form method="POST" class="zones-option" data-recherche="<?= $echapper(mb_strtolower($quartier['nom'] . ' ' . $quartier['ville_nom'], 'UTF-8')) ?>">
                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                            <input type="hidden" name="action" value="ajouter">
                            <input type="hidden" name="zone_id" value="<?= (int) $quartier['id'] ?>">
                            <input type="hidden" name="q" value="<?= $echapper($recherche) ?>">
                            <button type="submit">
                                <span><strong><?= $echapper($quartier['nom']) ?></strong><small><?= $echapper($quartier['ville_nom']) ?></small></span>
                                <span class="zones-option__ajouter" aria-hidden="true">+</span>
                            </button>
                        </form>
                    <?php endforeach; ?>
                    <p class="zones-vide zones-disponibles__aucun" id="aucun-quartier" hidden>Aucun quartier ne correspond à votre recherche.</p>
                </div>
            </section>
        </div>
    </main>
</div>
<script>
(function () {
    var recherche = document.getElementById('recherche-quartier');
    var options = Array.from(document.querySelectorAll('.zones-option'));
    var aucun = document.getElementById('aucun-quartier');
    function filtrer() {
        var terme = recherche.value.trim().toLocaleLowerCase('fr');
        var visibles = 0;
        options.forEach(function (option) {
            var correspond = option.dataset.recherche.toLocaleLowerCase('fr').includes(terme);
            option.hidden = !correspond;
            if (correspond) visibles++;
        });
        aucun.hidden = visibles > 0;
    }
    recherche.addEventListener('input', filtrer);
    filtrer();
})();
</script>
</body>
</html>
