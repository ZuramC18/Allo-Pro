<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/IndisponibiliteTechnicien.php';
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../models/Parametre.php';
require_once __DIR__ . '/../../includes/icones.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$dateDemandee = is_string($_GET['semaine'] ?? null) ? $_GET['semaine'] : '';
$dateSemaine = DateTimeImmutable::createFromFormat('!Y-m-d', $dateDemandee);
if (!$dateSemaine || $dateSemaine->format('Y-m-d') !== $dateDemandee) {
    $dateSemaine = new DateTimeImmutable('today');
}
$debutSemaine = $dateSemaine->modify('monday this week');
$finSemaine = $debutSemaine->modify('+6 days');
$dateDebut = $debutSemaine->format('Y-m-d');
$dateFin = $finSemaine->format('Y-m-d');
$libellesJours = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
$libellesMois = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
$jours = [];
for ($jour = 0; $jour < 7; $jour++) {
    $date = $debutSemaine->modify('+' . $jour . ' days');
    $jours[] = [
        'cle' => $date->format('Y-m-d'),
        'date' => $date,
        'libelle' => ucfirst($libellesJours[(int) $date->format('w')]),
        'date_courte' => $date->format('j') . ' ' . $libellesMois[(int) $date->format('n')],
    ];
}
$parametres = new Parametre();
$heureDebut = max(0, min(23, (int) $parametres->get('heure_debut_indisponibilites', '8')));
$heureFin = max($heureDebut + 1, min(24, (int) $parametres->get('heure_fin_indisponibilites', '20')));
$modeleCalendrier = new IndisponibiliteTechnicien();
$techniciens = (new Technicien())->getEquipePartenaire($partenaireId);
$missionsParCreneau = [];
foreach ($modeleCalendrier->getMissionsEquipeParPeriode($partenaireId, $dateDebut, $dateFin) as $mission) {
    $cleCreneau = $mission['date_creneau_planifie'] . '-' . (int) $mission['heure_creneau_planifie'];
    $missionsParCreneau[$cleCreneau][] = $mission;
}
$indisponibilitesParCreneau = [];
foreach ($modeleCalendrier->getIndisponibilitesEquipeParPeriode($partenaireId, $dateDebut, $dateFin) as $indisponibilite) {
    $cleCreneau = $indisponibilite['date_indisponibilite'] . '-' . (int) $indisponibilite['heure_debut'];
    $indisponibilitesParCreneau[$cleCreneau][] = $indisponibilite;
}
$missionsSansCreneau = $modeleCalendrier->getMissionsEquipeSansCreneau($partenaireId);
$semainePrecedente = $debutSemaine->modify('-7 days')->format('Y-m-d');
$semaineSuivante = $debutSemaine->modify('+7 days')->format('Y-m-d');
$aujourdhui = new DateTimeImmutable('today');
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$libellesStatuts = [
    'en_attente' => 'À confirmer',
    'acceptee' => 'Acceptée',
    'refusee' => 'En attente coordinateur',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Calendrier équipe — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/partenaire-calendrier.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-calendrier.css') ?>">
</head>
<body class="page-partenaire-calendrier">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>
    <main class="contenu partenaire-calendrier">
        <header class="calendrier-entete">
            <div>
                <span class="calendrier-entete__sur-titre">Organisation de l’équipe</span>
                <h1>Calendrier des techniciens</h1>
                <p>Consultez les missions attribuées et les indisponibilités de vos techniciens.</p>
            </div>
            <nav class="calendrier-navigation" aria-label="Navigation du calendrier">
                <a href="calendrier.php?semaine=<?= $echapper($semainePrecedente) ?>" aria-label="Semaine précédente"><?= icone('arrow', 17) ?></a>
                <strong><?= $echapper($debutSemaine->format('d/m')) ?> – <?= $echapper($finSemaine->format('d/m/Y')) ?></strong>
                <a class="calendrier-navigation__suivant" href="calendrier.php?semaine=<?= $echapper($semaineSuivante) ?>" aria-label="Semaine suivante"><?= icone('arrow', 17) ?></a>
                <?php if ($dateDebut !== $aujourdhui->modify('monday this week')->format('Y-m-d')): ?>
                    <a class="calendrier-navigation__aujourdhui" href="calendrier.php">Cette semaine</a>
                <?php endif; ?>
            </nav>
        </header>

        <section class="calendrier-legende" aria-label="Légende">
            <span><i class="calendrier-legende__mission"></i>Mission attribuée</span>
            <span><i class="calendrier-legende__indisponible"></i>Indisponibilité</span>
            <small><?= count($techniciens) ?> technicien<?= count($techniciens) === 1 ? '' : 's' ?> · <?= sprintf('%02d:00', $heureDebut) ?> – <?= $heureFin === 24 ? '00' : sprintf('%02d', $heureFin) ?>:00</small>
        </section>

        <?php if (!$techniciens): ?>
            <section class="calendrier-vide">
                <span><?= icone('users', 28) ?></span>
                <h2>Aucun technicien dans votre équipe</h2>
                <p>Ajoutez un technicien pour consulter ses missions et ses disponibilités dans ce calendrier.</p>
                <a href="techniciens.php">Gérer mes techniciens</a>
            </section>
        <?php else: ?>
            <section class="calendrier-grille-defilement" aria-label="Calendrier hebdomadaire">
                <table class="calendrier-grille">
                    <thead>
                    <tr>
                        <th scope="col" class="calendrier-grille__heure-entete">Heure</th>
                        <?php foreach ($jours as $jour): ?>
                            <th scope="col" class="<?= $jour['cle'] === $aujourdhui->format('Y-m-d') ? 'calendrier-grille__aujourdhui' : '' ?>">
                                <span><?= $echapper($jour['libelle']) ?></span>
                                <strong><?= $echapper($jour['date_courte']) ?></strong>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php for ($heure = $heureDebut; $heure < $heureFin; $heure++): ?>
                        <tr>
                            <th scope="row" class="calendrier-grille__heure"><?= sprintf('%02d:00', $heure) ?></th>
                            <?php foreach ($jours as $jour):
                                $cleCreneau = $jour['cle'] . '-' . $heure;
                                $missions = $missionsParCreneau[$cleCreneau] ?? [];
                                $indisponibilites = $indisponibilitesParCreneau[$cleCreneau] ?? [];
                            ?>
                                <td class="<?= $jour['cle'] === $aujourdhui->format('Y-m-d') ? 'calendrier-grille__cellule--aujourdhui' : '' ?>">
                                    <div class="calendrier-creneau">
                                        <?php foreach ($missions as $mission): ?>
                                            <a class="calendrier-evenement calendrier-evenement--mission" href="detail-mission.php?id=<?= (int) $mission['intervention_id'] ?>" title="Voir la mission <?= $echapper($mission['numero_dossier']) ?>">
                                                <strong><?= $echapper($mission['technicien_nom']) ?></strong>
                                                <span><?= $echapper($mission['numero_dossier']) ?> · <?= $echapper($mission['categorie_nom']) ?></span>
                                                <small><?= $echapper($libellesStatuts[$mission['intervention_statut']] ?? ucfirst(str_replace('_', ' ', $mission['intervention_statut']))) ?></small>
                                            </a>
                                        <?php endforeach; ?>
                                        <?php foreach ($indisponibilites as $indisponibilite): ?>
                                            <div class="calendrier-evenement calendrier-evenement--indisponible">
                                                <strong><?= $echapper($indisponibilite['technicien_nom']) ?></strong>
                                                <span>Indisponible</span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endfor; ?>
                    </tbody>
                </table>
            </section>
        <?php endif; ?>

        <section class="calendrier-sans-creneau" aria-labelledby="calendrier-sans-creneau-titre">
            <header>
                <div>
                    <h2 id="calendrier-sans-creneau-titre">Missions attribuées sans créneau planifié</h2>
                    <p>Ces missions n’ont pas encore de date et d’heure visibles dans le calendrier.</p>
                </div>
                <span><?= count($missionsSansCreneau) ?></span>
            </header>
            <?php if ($missionsSansCreneau): ?>
                <ul>
                    <?php foreach ($missionsSansCreneau as $mission): ?>
                        <li>
                            <div><strong><?= $echapper($mission['technicien_nom']) ?></strong><span><?= $echapper($mission['numero_dossier']) ?> · <?= $echapper($mission['categorie_nom']) ?></span></div>
                            <span class="calendrier-sans-creneau__statut"><?= $echapper($libellesStatuts[$mission['intervention_statut']] ?? ucfirst(str_replace('_', ' ', $mission['intervention_statut']))) ?></span>
                            <a href="detail-mission.php?id=<?= (int) $mission['intervention_id'] ?>">Voir la mission <?= icone('arrow', 15) ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="calendrier-sans-creneau__vide">Aucune mission en attente de planification.</p>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
