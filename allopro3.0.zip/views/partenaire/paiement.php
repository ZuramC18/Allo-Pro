<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Reversement.php';

$partenaireId = (int) $_SESSION['partenaire_id'];
$reversementModel = new Reversement();
$dateDebutSaisie = is_string($_GET['date_debut'] ?? null) ? trim($_GET['date_debut']) : '';
$dateFinSaisie = is_string($_GET['date_fin'] ?? null) ? trim($_GET['date_fin']) : '';
$dateDebut = null;
$dateFin = null;
$erreurPeriode = '';
$validerDate = static function (string $valeur): ?DateTimeImmutable {
    if ($valeur === '') {
        return null;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $valeur);
    return $date !== false && $date->format('Y-m-d') === $valeur ? $date : null;
};

if ($dateDebutSaisie !== '') {
    $dateDebutObjet = $validerDate($dateDebutSaisie);
    if ($dateDebutObjet === null) {
        $erreurPeriode = 'La date de début est invalide.';
    } else {
        $dateDebut = $dateDebutObjet->format('Y-m-d');
    }
}
if ($dateFinSaisie !== '') {
    $dateFinObjet = $validerDate($dateFinSaisie);
    if ($dateFinObjet === null) {
        $erreurPeriode = 'La date de fin est invalide.';
    } else {
        $dateFin = $dateFinObjet->format('Y-m-d');
    }
}
if ($erreurPeriode === '' && $dateDebut !== null && $dateFin !== null && $dateDebut > $dateFin) {
    $erreurPeriode = 'La date de début doit être antérieure ou égale à la date de fin.';
}
if ($erreurPeriode !== '') {
    http_response_code(400);
    $missions = [];
} else {
    $missions = $reversementModel->getMissionsFinancieresParPartenaire($partenaireId, $dateDebut, $dateFin);
}
$chiffreAffaires = 0.0;
$partPartenaire = 0.0;
$montantVerse = 0.0;
$montantEnAttente = 0.0;
$commissionAllopro = 0.0;
foreach ($missions as $mission) {
    $chiffreAffaires += (float) $mission['montant_brut'];
    $partPartenaire += (float) $mission['montant_partenaire'];
    $commissionAllopro += (float) $mission['commission_allopro'];
    if ($mission['reversement_statut'] === 'paye') {
        $montantVerse += (float) $mission['montant_partenaire'];
    } else {
        $montantEnAttente += (float) $mission['montant_partenaire'];
    }
}

$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$formaterMontant = static fn($montant): string => number_format((float) $montant, 0, ',', ' ') . ' F CFA';
$libelleModePaiement = static fn(string $mode): string => match ($mode) {
    'pass' => 'Pass',
    'abonnement' => 'Abonnement',
    default => 'Paiement direct',
};
$periodeLibelle = $dateDebut === null && $dateFin === null
    ? 'Toutes les périodes'
    : ($dateDebut !== null && $dateFin !== null
        ? 'Du ' . date('d/m/Y', strtotime($dateDebut)) . ' au ' . date('d/m/Y', strtotime($dateFin))
        : ($dateDebut !== null
            ? 'Depuis le ' . date('d/m/Y', strtotime($dateDebut))
            : 'Jusqu’au ' . date('d/m/Y', strtotime((string) $dateFin))));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paiements — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-paiement.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-paiement.css') ?>">
</head>
<body class="page-partenaire-paiement">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <header class="contenu__entete paiement-entete">
            <div>
                <h1 class="contenu__titre">Paiements et chiffre d’affaires</h1>
                <p>Consultez le chiffre d’affaires de vos interventions terminées, les montants reversés et ceux en attente.</p>
            </div>
        </header>

        <form class="paiement-periode" method="GET" aria-label="Filtrer le chiffre d’affaires par période">
            <div class="paiement-periode__intro">
                <span><?= icone('calendar', 19) ?></span>
                <div><strong>Choisir une période</strong><small>Filtrez les montants par date de paiement ou d’achat.</small></div>
            </div>
            <label>
                <span>Du</span>
                <input type="date" name="date_debut" value="<?= $echapper($dateDebutSaisie) ?>">
            </label>
            <label>
                <span>Au</span>
                <input type="date" name="date_fin" value="<?= $echapper($dateFinSaisie) ?>">
            </label>
            <div class="paiement-periode__actions">
                <button type="submit"><?= icone('search', 16) ?> Afficher</button>
                <a href="paiement.php">Tout l’historique</a>
            </div>
        </form>
        <?php if ($erreurPeriode !== ''): ?>
            <div class="paiement-erreur" role="alert"><?= $echapper($erreurPeriode) ?></div>
        <?php endif; ?>

        <?php if ($erreurPeriode === ''): ?>
        <section class="paiement-resume" aria-label="Résumé financier">
            <p class="paiement-resume__periode"><?= $echapper($periodeLibelle) ?> · <?= count($missions) ?> intervention<?= count($missions) === 1 ? '' : 's' ?></p>
            <article class="paiement-indicateur paiement-indicateur--principal">
                <span class="paiement-indicateur__label">Chiffre d’affaires brut</span>
                <strong><?= $formaterMontant($chiffreAffaires) ?></strong>
                <small>Interventions terminées et financées sur la période</small>
            </article>
            <article class="paiement-indicateur">
                <span class="paiement-indicateur__label">Part partenaire</span>
                <strong><?= $formaterMontant($partPartenaire) ?></strong>
                <small>Après commission ALLÔ PRO</small>
            </article>
            <article class="paiement-indicateur paiement-indicateur--verse">
                <span class="paiement-indicateur__label">Déjà reversé</span>
                <strong><?= $formaterMontant($montantVerse) ?></strong>
                <small>Reversements marqués comme payés</small>
            </article>
            <article class="paiement-indicateur paiement-indicateur--attente">
                <span class="paiement-indicateur__label">À recevoir</span>
                <strong><?= $formaterMontant($montantEnAttente) ?></strong>
                <small>En attente de reversement</small>
            </article>
        </section>
        <?php endif; ?>

        <section class="paiement-section" aria-labelledby="paiement-historique-titre">
            <header class="paiement-section__entete">
                <div>
                    <h2 id="paiement-historique-titre">Détail du chiffre d’affaires</h2>
                    <p>Montants des interventions dont le paiement ou l’achat est compris dans la période.</p>
                </div>
            </header>
            <?php if ($erreurPeriode !== ''): ?>
                <div class="paiement-vide"><strong>Corrigez les dates pour afficher les résultats.</strong></div>
            <?php elseif ($missions): ?>
                <div class="paiement-table-scroll">
                    <table class="paiement-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Dossier</th>
                                <th>Mode de paiement</th>
                                <th>Chiffre d’affaires</th>
                                <th>Commission</th>
                                <th>Part partenaire</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($missions as $mission): ?>
                                <tr>
                                    <td data-label="Date"><?= $echapper(date('d/m/Y', strtotime($mission['date_operation']))) ?></td>
                                    <td data-label="Dossier"><strong><?= $echapper($mission['numero_dossier']) ?></strong></td>
                                    <td data-label="Mode de paiement"><?= $echapper($libelleModePaiement((string) $mission['mode_paiement'])) ?></td>
                                    <td data-label="Chiffre d’affaires"><?= $formaterMontant($mission['montant_brut']) ?></td>
                                    <td data-label="Commission"><?= $formaterMontant($mission['commission_allopro']) ?></td>
                                    <td data-label="Part partenaire" class="paiement-table__montant"><?= $formaterMontant($mission['montant_partenaire']) ?></td>
                                    <td data-label="Statut">
                                        <span class="paiement-statut <?= $mission['reversement_statut'] === 'paye' ? 'paiement-statut--paye' : 'paiement-statut--attente' ?>">
                                            <?= $mission['reversement_statut'] === 'paye' ? 'Reversé' : 'En attente' ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="paiement-vide">
                    <span><?= icone('wallet', 24) ?></span>
                    <strong>Aucune intervention sur cette période</strong>
                    <p>Essayez une autre période ou affichez tout l’historique.</p>
                </div>
            <?php endif; ?>
        </section>
        <p class="paiement-note">
            Le filtre porte sur la date de paiement ou d’achat. Pour les interventions réglées par pass ou abonnement, le chiffre d’affaires correspond à la part attribuée à la mission.
        </p>
    </main>
</div>
</body>
</html>
