<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Partenaire.php';

$partenaireModel = new Partenaire();
$partenaireId = (int) $_SESSION['partenaire_id'];
$statutsLibelles = [
    'en_attente' => 'À confirmer',
    'acceptee' => 'Acceptée',
    'refusee' => 'En attente coordinateur',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$statut = is_string($_GET['statut'] ?? null) ? $_GET['statut'] : '';
if ($statut !== '' && !isset($statutsLibelles[$statut])) {
    $statut = '';
}
$recherche = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
$recherche = mb_substr($recherche, 0, 100);

$compteurs = $partenaireModel->compterMissionsParStatut($partenaireId);
$totalMissions = array_sum($compteurs);
$totalFiltre = $partenaireModel->compterMissionsFiltrees($partenaireId, $statut !== '' ? $statut : null, $recherche);
$parPage = 30;
$nbPages = max(1, (int) ceil($totalFiltre / $parPage));
$page = min(max(1, filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT) ?: 1), $nbPages);
$missions = $partenaireModel->getMissionsPartenaire(
    $partenaireId,
    $statut !== '' ? $statut : null,
    $recherche,
    $parPage,
    ($page - 1) * $parPage
);
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$libelleStatut = static fn(string $cle): string => $statutsLibelles[$cle] ?? ucfirst(str_replace('_', ' ', $cle));
$urlMissions = static function (array $modifications = []) use ($statut, $recherche): string {
    $parametres = ['statut' => $statut, 'q' => $recherche, 'page' => null];
    foreach ($modifications as $cle => $valeur) {
        $parametres[$cle] = $valeur;
    }
    $parametres = array_filter($parametres, static fn($valeur) => $valeur !== '' && $valeur !== null);
    return 'missions.php' . ($parametres ? '?' . http_build_query($parametres) : '');
};
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes missions — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-missions.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-missions.css') ?>">
</head>
<body class="page-partenaire-missions">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <header class="contenu__entete missions-entete">
            <div>
                <h1 class="contenu__titre">Mes missions</h1>
                <p class="missions-sous-titre">Suivez les interventions confiées à votre entreprise et à vos techniciens.</p>
            </div>
            <span class="missions-total"><?= $totalMissions ?> mission<?= $totalMissions === 1 ? '' : 's' ?></span>
        </header>

        <section class="missions-resume" aria-label="Résumé des missions">
            <a class="missions-resume__carte <?= $statut === '' ? 'missions-resume__carte--active' : '' ?>" href="missions.php">
                <span class="missions-resume__nombre"><?= $totalMissions ?></span>
                <span class="missions-resume__libelle">Toutes les missions</span>
            </a>
            <a class="missions-resume__carte missions-resume__carte--active-work <?= $statut === 'en_cours' ? 'missions-resume__carte--active' : '' ?>" href="<?= $echapper($urlMissions(['statut' => 'en_cours'])) ?>">
                <span class="missions-resume__nombre"><?= (int) ($compteurs['en_cours'] ?? 0) ?></span>
                <span class="missions-resume__libelle">En cours</span>
            </a>
            <a class="missions-resume__carte missions-resume__carte--done <?= $statut === 'terminee' ? 'missions-resume__carte--active' : '' ?>" href="<?= $echapper($urlMissions(['statut' => 'terminee'])) ?>">
                <span class="missions-resume__nombre"><?= (int) ($compteurs['terminee'] ?? 0) ?></span>
                <span class="missions-resume__libelle">Terminées</span>
            </a>
        </section>

        <nav class="missions-filtres" aria-label="Filtrer les missions">
            <a href="<?= $echapper($urlMissions(['statut' => ''])) ?>" class="<?= $statut === '' ? 'missions-filtre--actif' : '' ?>">Toutes <span><?= $totalMissions ?></span></a>
            <?php foreach ($statutsLibelles as $cle => $libelle): ?>
                <?php if (empty($compteurs[$cle])) continue; ?>
                <a href="<?= $echapper($urlMissions(['statut' => $cle])) ?>" class="<?= $statut === $cle ? 'missions-filtre--actif' : '' ?>" <?= $statut === $cle ? 'aria-current="page"' : '' ?>>
                    <?= $echapper($libelle) ?> <span><?= (int) $compteurs[$cle] ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <form class="missions-recherche" method="GET" role="search">
            <?php if ($statut !== ''): ?><input type="hidden" name="statut" value="<?= $echapper($statut) ?>"><?php endif; ?>
            <label class="missions-recherche__champ">
                <span class="sr-only">Rechercher dans mes missions</span>
                <?= icone('search', 18) ?>
                <input type="search" name="q" value="<?= $echapper($recherche) ?>" placeholder="Dossier, client, technicien, quartier…" maxlength="100">
            </label>
            <button type="submit">Rechercher</button>
            <?php if ($recherche !== ''): ?><a href="<?= $echapper($urlMissions(['q' => ''])) ?>">Effacer</a><?php endif; ?>
        </form>

        <section class="missions-liste" aria-label="Liste de mes missions">
            <div class="missions-liste__entete">
                <strong><?= number_format($totalFiltre, 0, ',', ' ') ?> résultat<?= $totalFiltre === 1 ? '' : 's' ?></strong>
                <?php if ($nbPages > 1): ?><span>Page <?= $page ?> / <?= $nbPages ?></span><?php endif; ?>
            </div>
            <?php if (!$missions): ?>
                <div class="missions-vide">
                    <span class="missions-vide__icone"><?= icone('inbox', 28) ?></span>
                    <strong><?= $recherche !== '' || $statut !== '' ? 'Aucune mission ne correspond à votre recherche.' : 'Aucune mission ne vous a encore été confiée.' ?></strong>
                    <p>Les missions attribuées à votre entreprise apparaîtront ici.</p>
                    <?php if ($recherche !== '' || $statut !== ''): ?><a href="missions.php">Afficher toutes les missions</a><?php endif; ?>
                </div>
            <?php else: ?>
                <div class="missions-table-wrap">
                    <table class="missions-table">
                        <thead>
                            <tr>
                                <th>Dossier</th><th>Intervention</th><th>Client</th><th>Lieu</th><th>Technicien</th><th>Statut</th><th>Créée le</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($missions as $mission): ?>
                                <tr class="mission-ligne-cliquable" data-detail-url="detail-mission.php?id=<?= (int) $mission['intervention_id'] ?>" tabindex="0" aria-label="Afficher le détail de la mission <?= $echapper($mission['numero_dossier']) ?>">
                                    <td data-label="Dossier"><strong class="missions-dossier"><?= $echapper($mission['numero_dossier']) ?></strong><?php if (!empty($mission['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($mission['entreprise_b2b_nom']) ? ' · ' . $echapper($mission['entreprise_b2b_nom']) : '' ?></span><?php endif; ?></td>
                                    <td data-label="Intervention">
                                        <strong><?= $echapper($mission['categorie_nom']) ?></strong>
                                        <?php if (!empty($mission['description'])): ?><small class="missions-description"><?= $echapper($mission['description']) ?></small><?php endif; ?>
                                        <?php if (($mission['urgence'] ?? '') === 'urgente'): ?><span class="missions-urgence">Urgente</span><?php endif; ?>
                                    </td>
                                    <td data-label="Client"><?= $echapper($mission['client_nom']) ?></td>
                                    <td data-label="Lieu"><?= $echapper(trim(($mission['quartier'] ?? '') . (!empty($mission['ville']) ? ', ' . $mission['ville'] : ''))) ?: '—' ?></td>
                                    <td data-label="Technicien"><?= $echapper($mission['technicien_nom'] ?? '') ?: 'À désigner' ?></td>
                                    <td data-label="Statut"><span class="missions-statut missions-statut--<?= $echapper($mission['intervention_statut']) ?>"><?= $echapper($libelleStatut($mission['intervention_statut'])) ?></span></td>
                                    <td data-label="Créée le"><?= !empty($mission['date_creation']) ? date('d/m/Y', strtotime($mission['date_creation'])) : '—' ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($nbPages > 1): ?>
                    <nav class="missions-pagination" aria-label="Pagination des missions">
                        <?php if ($page > 1): ?><a href="<?= $echapper($urlMissions(['page' => $page - 1])) ?>">← Précédent</a><?php else: ?><span></span><?php endif; ?>
                        <span>Page <?= $page ?> sur <?= $nbPages ?></span>
                        <?php if ($page < $nbPages): ?><a href="<?= $echapper($urlMissions(['page' => $page + 1])) ?>">Suivant →</a><?php else: ?><span></span><?php endif; ?>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </section>
    </main>
</div>
<script>
(function () {
    document.querySelectorAll('.mission-ligne-cliquable').forEach(function (ligne) {
        ligne.addEventListener('click', function (event) {
            if (event.target.closest('a, button, input, select, textarea, label')) return;
            window.location.assign(ligne.dataset.detailUrl);
        });
        ligne.addEventListener('keydown', function (event) {
            if (event.target === ligne && event.key === 'Enter') {
                event.preventDefault();
                window.location.assign(ligne.dataset.detailUrl);
            }
        });
    });
})();
</script>
</body>
</html>
