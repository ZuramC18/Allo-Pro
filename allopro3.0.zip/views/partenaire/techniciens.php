<?php
require_once __DIR__ . '/../../includes/auth-partenaire.php';
verifierPartenaireConnecte();
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../models/Categorie.php';

$technicienModel = new Technicien();
$partenaireId = (int) $_SESSION['partenaire_id'];
$csrfSession = 'csrf_partenaire_techniciens';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}

$erreur = '';
$donnees = [
    'nom' => '',
    'email' => '',
    'telephone' => '',
    'competence_ids' => [],
];
$categories = array_values(array_filter(
    (new Categorie())->getSousCategories(),
    static fn($categorie) => ($categorie['statut'] ?? 'active') === 'active'
));
$categoriesActives = array_fill_keys(array_map('intval', array_column($categories, 'id')), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
        http_response_code(403);
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } else {
        foreach (['nom', 'email', 'telephone'] as $champ) {
            $donnees[$champ] = is_string($_POST[$champ] ?? null) ? trim($_POST[$champ]) : '';
        }
        $competencesPostees = $_POST['competence_ids'] ?? [];
        $competenceSaisieInvalide = !is_array($competencesPostees);
        if ($competenceSaisieInvalide) {
            $competencesPostees = [];
        }
        foreach ($competencesPostees as $competencePostee) {
            if (!is_string($competencePostee) && !is_int($competencePostee)) {
                $competenceSaisieInvalide = true;
                continue;
            }
            $competenceId = filter_var($competencePostee, FILTER_VALIDATE_INT);
            if ($competenceId !== false && $competenceId > 0) {
                $donnees['competence_ids'][] = $competenceId;
            } else {
                $competenceSaisieInvalide = true;
            }
        }
        $donnees['competence_ids'] = array_values(array_unique($donnees['competence_ids']));
        $motDePasse = is_string($_POST['mot_de_passe'] ?? null) ? $_POST['mot_de_passe'] : '';

        if ($donnees['nom'] === '' || mb_strlen($donnees['nom']) > 150) {
            $erreur = 'Saisissez un nom complet valide (150 caractères maximum).';
        } elseif (!filter_var($donnees['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($donnees['email']) > 190) {
            $erreur = 'Saisissez une adresse e-mail valide.';
        } elseif (mb_strlen($donnees['telephone']) > 40) {
            $erreur = 'Le numéro de téléphone ne peut pas dépasser 40 caractères.';
        } elseif (strlen($motDePasse) < 8) {
            $erreur = 'Le mot de passe temporaire doit contenir au moins 8 caractères.';
        } elseif ($competenceSaisieInvalide || !$donnees['competence_ids']) {
            $erreur = 'Sélectionnez au moins une compétence.';
        } elseif (count(array_filter($donnees['competence_ids'], static fn($id) => isset($categoriesActives[$id]))) !== count($donnees['competence_ids'])) {
            $erreur = 'Une ou plusieurs compétences sélectionnées ne sont plus disponibles.';
        } elseif ($technicienModel->findByEmail($donnees['email'])) {
            $erreur = 'Cette adresse e-mail est déjà utilisée par un technicien.';
        } else {
            try {
                $technicienModel->create(
                    $partenaireId,
                    $donnees['nom'],
                    $donnees['email'],
                    $motDePasse,
                    $donnees['telephone'],
                    $donnees['competence_ids']
                );
                header('Location: techniciens.php?ajoute=1');
                exit;
            } catch (PDOException $exception) {
                error_log('Création technicien partenaire ' . $partenaireId . ' : ' . $exception->getMessage());
                $erreur = ($exception->errorInfo[1] ?? null) === 1062
                    ? 'Cette adresse e-mail est déjà utilisée par un technicien.'
                    : 'Le technicien n’a pas pu être ajouté. Réessayez dans un instant.';
            } catch (InvalidArgumentException $exception) {
                $erreur = 'Une ou plusieurs compétences ne sont plus disponibles. Actualisez la page puis réessayez.';
            }
        }
    }
}

$vueCorbeille = ($_GET['corbeille'] ?? '') === '1';
$mesTechniciens = $technicienModel->getEquipePartenaire($partenaireId, $vueCorbeille);
$nombreEnCorbeille = count($technicienModel->getEquipePartenaire($partenaireId, true));
$totalTechniciens = count($mesTechniciens);
$techniciensActifs = count(array_filter($mesTechniciens, static fn($technicien) => $technicien['statut'] === 'actif'));
$techniciensInactifs = $totalTechniciens - $techniciensActifs;
$messageSucces = ($_GET['ajoute'] ?? '') === '1' ? 'Le technicien a bien été ajouté à votre équipe.' : '';
$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes techniciens — ALLÔ PRO Partenaire</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/partenaire-techniciens.css?v=<?= filemtime(__DIR__ . '/../../public/css/partenaire-techniciens.css') ?>">
</head>
<body class="page-partenaire-techniciens">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-partenaire.php'; ?>

    <main class="contenu">
        <header class="contenu__entete techniciens-entete">
            <div>
                <h1 class="contenu__titre"><?= $vueCorbeille ? 'Corbeille des techniciens' : 'Mes techniciens' ?></h1>
                <p class="techniciens-sous-titre"><?= $vueCorbeille ? 'Consultez et restaurez les techniciens retirés de votre équipe.' : 'Gérez les membres de votre équipe et leurs compétences.' ?></p>
            </div>
            <div class="techniciens-entete__actions">
                <a class="techniciens-corbeille-lien <?= $vueCorbeille ? 'techniciens-corbeille-lien--actif' : '' ?>" href="<?= $vueCorbeille ? 'techniciens.php' : 'techniciens.php?corbeille=1' ?>">
                    <?= $vueCorbeille ? 'Retour à mon équipe' : 'Corbeille (' . $nombreEnCorbeille . ')' ?>
                </a>
                <?php if (!$vueCorbeille): ?><a class="techniciens-ajout-rapide" href="#ajouter-technicien"><?= icone('plus', 17) ?> Ajouter un technicien</a><?php endif; ?>
            </div>
        </header>

        <?php if ($messageSucces): ?>
            <div class="techniciens-message techniciens-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur): ?>
            <div class="techniciens-message techniciens-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <?php if ($vueCorbeille): ?>
            <div class="techniciens-corbeille-info">Les techniciens ici sont masqués de l’équipe, mais leurs fiches et leur historique sont conservés. Vous pouvez les restaurer depuis leur fiche.</div>
        <?php else: ?>
        <section class="techniciens-resume" aria-label="Résumé de l'équipe">
            <article class="techniciens-resume__carte">
                <span class="techniciens-resume__icone techniciens-resume__icone--equipe"><?= icone('users', 19) ?></span>
                <span class="techniciens-resume__valeur"><?= $totalTechniciens ?></span>
                <span class="techniciens-resume__libelle">Technicien<?= $totalTechniciens === 1 ? '' : 's' ?> au total</span>
            </article>
            <article class="techniciens-resume__carte">
                <span class="techniciens-resume__icone techniciens-resume__icone--actif"><?= icone('check', 19) ?></span>
                <span class="techniciens-resume__valeur"><?= $techniciensActifs ?></span>
                <span class="techniciens-resume__libelle">Actif<?= $techniciensActifs === 1 ? '' : 's' ?></span>
            </article>
            <article class="techniciens-resume__carte">
                <span class="techniciens-resume__icone techniciens-resume__icone--inactif"><?= icone('clock', 19) ?></span>
                <span class="techniciens-resume__valeur"><?= $techniciensInactifs ?></span>
                <span class="techniciens-resume__libelle">Inactif<?= $techniciensInactifs === 1 ? '' : 's' ?></span>
            </article>
        </section>
        <?php endif; ?>

        <?php if ($vueCorbeille): ?>
        <section class="techniciens-equipe techniciens-equipe--corbeille" aria-labelledby="techniciens-liste-titre">
            <header class="techniciens-equipe__entete">
                <div><h2 id="techniciens-liste-titre">Corbeille</h2><p><?= $totalTechniciens ?> technicien<?= $totalTechniciens === 1 ? '' : 's' ?></p></div>
                <?php if ($totalTechniciens > 0): ?>
                    <label class="techniciens-recherche">
                        <?= icone('search', 17) ?><span class="sr-only">Rechercher un technicien</span>
                        <input id="recherche-technicien" type="search" placeholder="Nom, compétence, e-mail…" autocomplete="off">
                    </label>
                <?php endif; ?>
            </header>
            <?php if (!$mesTechniciens): ?>
                <div class="techniciens-vide">
                    <span class="techniciens-vide__icone"><?= icone('folder', 25) ?></span>
                    <strong>La corbeille est vide</strong>
                    <p>Les techniciens mis en corbeille apparaîtront ici.</p>
                </div>
            <?php else: ?>
                <div class="techniciens-table-wrap">
                    <table class="techniciens-table">
                        <thead><tr><th>Technicien</th><th>Compétences</th><th>Contact</th><th>Statut</th></tr></thead>
                        <tbody id="liste-techniciens">
                        <?php foreach ($mesTechniciens as $technicien):
                            $termeRecherche = mb_strtolower(implode(' ', [$technicien['nom'] ?? '', $technicien['competences'] ?? '', $technicien['email'] ?? '', $technicien['telephone'] ?? '', $technicien['matricule'] ?? '']));
                        ?>
                            <tr class="technicien-ligne-cliquable" data-recherche="<?= $echapper($termeRecherche) ?>" data-detail-url="detail-technicien.php?id=<?= (int) $technicien['id'] ?>&corbeille=1" tabindex="0" aria-label="Afficher le détail de <?= $echapper($technicien['nom']) ?>">
                                <td data-label="Technicien"><div class="technicien-identite"><span class="technicien-avatar" aria-hidden="true"><?= $echapper(mb_strtoupper(mb_substr($technicien['nom'] ?? '?', 0, 1))) ?></span><span><strong><?= $echapper($technicien['nom']) ?></strong><small><?= $echapper($technicien['matricule'] ?? 'Technicien') ?></small></span></div></td>
                                <td data-label="Compétences"><?php foreach (array_filter(explode(', ', (string) ($technicien['competences'] ?? ''))) as $competence): ?><span class="technicien-competence"><?= $echapper($competence) ?></span><?php endforeach; ?><?php if (empty($technicien['competences'])): ?><span>Non renseignées</span><?php endif; ?></td>
                                <td data-label="Contact"><span class="technicien-contact"><span><?= $echapper($technicien['email']) ?></span><?php if (!empty($technicien['telephone'])): ?><small><?= $echapper($technicien['telephone']) ?></small><?php endif; ?></span></td>
                                <td data-label="Statut"><span class="technicien-statut technicien-statut--corbeille"><span aria-hidden="true"></span>En corbeille</span></td>
                            </tr>
                        <?php endforeach; ?>
                            <tr class="techniciens-aucun-resultat" id="aucun-technicien-trouve" hidden><td colspan="4">Aucun technicien ne correspond à votre recherche.</td></tr>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
        <?php else: ?>
        <div class="techniciens-mise-en-page">
            <section class="techniciens-equipe" aria-labelledby="techniciens-liste-titre">
                <header class="techniciens-equipe__entete">
                    <div>
                        <h2 id="techniciens-liste-titre">Votre équipe</h2>
                        <p><?= $totalTechniciens ?> membre<?= $totalTechniciens === 1 ? '' : 's' ?></p>
                    </div>
                    <?php if ($totalTechniciens > 0): ?>
                        <label class="techniciens-recherche">
                            <?= icone('search', 17) ?>
                            <span class="sr-only">Rechercher un technicien</span>
                            <input id="recherche-technicien" type="search" placeholder="Nom, compétence, e-mail…" autocomplete="off">
                        </label>
                    <?php endif; ?>
                </header>

                <?php if (empty($mesTechniciens)): ?>
                    <div class="techniciens-vide">
                        <span class="techniciens-vide__icone"><?= icone('users', 25) ?></span>
                        <strong>Votre équipe commence ici</strong>
                        <p>Ajoutez votre premier technicien pour pouvoir organiser et recevoir des missions.</p>
                        <a href="#ajouter-technicien">Ajouter un technicien</a>
                    </div>
                <?php else: ?>
                    <div class="techniciens-table-wrap">
                        <table class="techniciens-table">
                            <thead>
                                <tr><th>Technicien</th><th>Compétences</th><th>Contact</th><th>Statut</th></tr>
                            </thead>
                            <tbody id="liste-techniciens">
                                <?php foreach ($mesTechniciens as $technicien):
                                    $actif = $technicien['statut'] === 'actif';
                                    $termeRecherche = mb_strtolower(implode(' ', [
                                        $technicien['nom'] ?? '',
                                        $technicien['competences'] ?? '',
                                        $technicien['email'] ?? '',
                                        $technicien['telephone'] ?? '',
                                        $technicien['matricule'] ?? '',
                                    ]));
                                ?>
                                    <tr class="technicien-ligne-cliquable" data-recherche="<?= $echapper($termeRecherche) ?>" data-detail-url="detail-technicien.php?id=<?= (int) $technicien['id'] ?>" tabindex="0" aria-label="Afficher le détail de <?= $echapper($technicien['nom']) ?>">
                                        <td data-label="Technicien">
                                            <div class="technicien-identite">
                                                <span class="technicien-avatar" aria-hidden="true"><?= $echapper(mb_strtoupper(mb_substr($technicien['nom'] ?? '?', 0, 1))) ?></span>
                                                <span>
                                                    <strong><a class="technicien-identite__lien" href="detail-technicien.php?id=<?= (int) $technicien['id'] ?>"><?= $echapper($technicien['nom']) ?></a></strong>
                                                    <small><?= $echapper($technicien['matricule'] ?? 'Technicien') ?></small>
                                                </span>
                                            </div>
                                        </td>
                                        <td data-label="Compétences"><?php foreach (array_filter(explode(', ', (string) ($technicien['competences'] ?? ''))) as $competence): ?><span class="technicien-competence"><?= $echapper($competence) ?></span><?php endforeach; ?><?php if (empty($technicien['competences'])): ?><span>Non renseignées</span><?php endif; ?></td>
                                        <td data-label="Contact">
                                            <span class="technicien-contact">
                                                <a href="mailto:<?= $echapper($technicien['email']) ?>"><?= $echapper($technicien['email']) ?></a>
                                                <?php if (!empty($technicien['telephone'])): ?><a href="tel:<?= $echapper(preg_replace('/[^0-9+]/', '', $technicien['telephone'])) ?>"><?= $echapper($technicien['telephone']) ?></a><?php else: ?><small>Téléphone non renseigné</small><?php endif; ?>
                                            </span>
                                        </td>
                                        <td data-label="Statut">
                                            <span class="technicien-statut <?= $actif ? 'technicien-statut--actif' : 'technicien-statut--inactif' ?>">
                                                <span aria-hidden="true"></span><?= $actif ? 'Actif' : 'Inactif' ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr class="techniciens-aucun-resultat" id="aucun-technicien-trouve" hidden>
                                    <td colspan="4">Aucun technicien ne correspond à votre recherche.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>

            <aside class="technicien-formulaire" id="ajouter-technicien">
                <div class="technicien-formulaire__entete">
                    <span class="technicien-formulaire__icone"><?= icone('plus', 19) ?></span>
                    <div><h2>Ajouter à l’équipe</h2><p>Créez l’accès d’un technicien.</p></div>
                </div>
                <form method="POST" class="technicien-form">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                    <div class="technicien-form__champ">
                        <label for="technicien-nom">Nom complet</label>
                        <input id="technicien-nom" type="text" name="nom" value="<?= $echapper($donnees['nom']) ?>" maxlength="150" autocomplete="name" placeholder="Ex. Amadou Diop" required>
                    </div>
                    <div class="technicien-form__champ">
                        <label for="technicien-email">Adresse e-mail</label>
                        <input id="technicien-email" type="email" name="email" value="<?= $echapper($donnees['email']) ?>" maxlength="190" autocomplete="email" placeholder="nom@exemple.com" required>
                    </div>
                    <div class="technicien-form__champ">
                        <label for="technicien-mot-de-passe">Mot de passe temporaire</label>
                        <input id="technicien-mot-de-passe" type="password" name="mot_de_passe" minlength="8" autocomplete="new-password" placeholder="8 caractères minimum" required>
                        <small>Le technicien pourra ensuite le modifier.</small>
                    </div>
                    <div class="technicien-form__champ">
                        <label for="technicien-telephone">Téléphone <span>(facultatif)</span></label>
                        <input id="technicien-telephone" type="tel" name="telephone" value="<?= $echapper($donnees['telephone']) ?>" maxlength="40" autocomplete="tel" placeholder="+221 77 000 00 00">
                    </div>
                    <div class="technicien-form__champ">
                        <span class="technicien-form__etiquette">Compétences <span>(sélectionnez-en au moins une)</span></span>
                        <div class="technicien-competences">
                            <?php foreach ($categories as $categorie): ?>
                                <label class="technicien-competences__option">
                                    <input type="checkbox" name="competence_ids[]" value="<?= (int) $categorie['id'] ?>" <?= in_array((int) $categorie['id'], $donnees['competence_ids'], true) ? 'checked' : '' ?>>
                                    <span><?= $echapper($categorie['nom']) ?><small><?= $echapper($categorie['parent_nom']) ?></small></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" class="technicien-form__envoyer">Ajouter le technicien <?= icone('arrow', 17) ?></button>
                    <p class="technicien-form__note">Les informations de connexion sont liées à ce technicien.</p>
                </form>
            </aside>
        </div>
        <?php endif; ?>
    </main>
</div>
<script>
(function () {
    var recherche = document.getElementById('recherche-technicien');
    var lignes = Array.from(document.querySelectorAll('#liste-techniciens tr[data-recherche]'));
    var vide = document.getElementById('aucun-technicien-trouve');
    lignes.forEach(function (ligne) {
        ligne.addEventListener('click', function (event) {
            if (event.target.closest('a, button, input, select, textarea, label')) return;
            window.location.assign(ligne.dataset.detailUrl);
        });
        ligne.addEventListener('keydown', function (event) {
            if (event.target === ligne && event.key === 'Enter') {
                event.preventDefault();
                window.location.assign(ligne.dataset.detailUrl);
            }
        });
    });
    if (!recherche) return;

    recherche.addEventListener('input', function () {
        var terme = this.value.trim().toLocaleLowerCase('fr');
        var visibles = 0;
        lignes.forEach(function (ligne) {
            var correspond = ligne.dataset.recherche.toLocaleLowerCase('fr').includes(terme);
            ligne.hidden = !correspond;
            if (correspond) visibles++;
        });
        vide.hidden = visibles > 0;
    });
})();
</script>
</body>
</html>
