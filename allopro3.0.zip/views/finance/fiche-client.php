<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
verifierAcces('paiements');
require __DIR__ . '/../../includes/fiche-client-equipe.php';
