<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/Reversement.php';

$reversementsDus = (new Reversement())->getReversementsDus();
$totalDu = array_sum(array_map(static fn(array $ligne): float => (float) $ligne['montant_du'], $reversementsDus));
$nombreMissionsDues = array_sum(array_map(static fn(array $ligne): int => (int) $ligne['nb_missions'], $reversementsDus));
$echapper = static fn($valeur): string => htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paiements à effectuer — ALLÔ PRO Finance</title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/finance-paiements-a-effectuer.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-paiements-a-effectuer.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu finance-paiements-dus">
        <header class="finance-paiements-dus__hero">
            <span class="finance-paiements-dus__eyebrow">Suivi des partenaires</span>
            <h1>Paiements à effectuer</h1>
            <p>Préparez les reversements dus pour les interventions terminées et payées.</p>
        </header>
        <section class="finance-paiements-dus__kpis" aria-label="Résumé des paiements dus">
            <article class="finance-paiements-dus__kpi finance-paiements-dus__kpi--partenaires">
                <span>Partenaires à payer</span>
                <strong><?= number_format(count($reversementsDus), 0, ',', ' ') ?></strong>
                <p>Reversements encore à préparer</p>
            </article>
            <article class="finance-paiements-dus__kpi finance-paiements-dus__kpi--missions">
                <span>Missions à reverser</span>
                <strong><?= number_format($nombreMissionsDues, 0, ',', ' ') ?></strong>
                <p>Interventions éligibles au paiement</p>
            </article>
            <article class="finance-paiements-dus__kpi finance-paiements-dus__kpi--montant">
                <span>Total à reverser</span>
                <strong><?= number_format($totalDu, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p>Montant net destiné aux partenaires</p>
            </article>
        </section>
        <section class="finance-paiements-dus__panel" aria-label="Reversements dus">
            <header class="finance-paiements-dus__panel-header">
                <div>
                    <h2>Reversements à préparer</h2>
                    <p><?= number_format(count($reversementsDus), 0, ',', ' ') ?> partenaire<?= count($reversementsDus) === 1 ? '' : 's' ?> en attente</p>
                </div>
                <span class="finance-paiements-dus__compteur"><?= number_format(count($reversementsDus), 0, ',', ' ') ?> à payer</span>
            </header>
            <?php if (!$reversementsDus): ?>
                <div class="finance-paiements-dus__vide">
                    <span aria-hidden="true">✓</span>
                    <strong>Aucun reversement à préparer</strong>
                    <p>Les partenaires apparaîtront ici lorsque des interventions payées seront terminées.</p>
                </div>
            <?php else: ?>
                <div class="admin-table-wrapper" tabindex="0" role="region" aria-label="Liste des partenaires à payer">
                    <table class="admin-table finance-paiements-dus__table">
                        <thead><tr><th>Partenaire</th><th>Missions</th><th>Montant dû</th><th><span class="finance-paiements-dus__visually-hidden">Action</span></th></tr></thead>
                        <tbody>
                        <?php foreach ($reversementsDus as $reversement): ?>
                            <tr>
                                <td><strong><?= $echapper($reversement['nom_entreprise']) ?></strong></td>
                                <td><span class="finance-paiements-dus__missions"><?= number_format((int) $reversement['nb_missions'], 0, ',', ' ') ?> mission<?= (int) $reversement['nb_missions'] === 1 ? '' : 's' ?></span></td>
                                <td><strong class="finance-paiements-dus__montant"><?= number_format((float) $reversement['montant_du'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong></td>
                                <td><a class="finance-paiements-dus__action" href="../admin/creer-reversement.php?partenaire_id=<?= (int) $reversement['id'] ?>">Préparer le reversement <span aria-hidden="true">→</span></a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
