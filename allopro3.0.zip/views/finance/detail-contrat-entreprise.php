<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('devis_entreprises');
require __DIR__ . '/../admin/detail-contrat-entreprise.php';
