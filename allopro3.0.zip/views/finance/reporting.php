<?php
$financeRapportMode = 'reporting';
require __DIR__ . '/reporting-commun.php';
