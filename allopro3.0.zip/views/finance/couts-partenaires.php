<?php
$financeTitrePage = 'Coûts partenaires';
$_GET['categorie'] = 'reversement';
require __DIR__ . '/livre-comptes.php';
