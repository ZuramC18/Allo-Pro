<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('paiements');

$typeProprietaire = 'finance';
$proprietaireId = (int) $_SESSION['user_id'];
$urlTaches = 'taches.php';
require_once __DIR__ . '/../../includes/taches-controleur.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes tâches — ALLÔ PRO Finance</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/taches.css?v=20261005-1">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu taches-page">
        <?php include __DIR__ . '/../../includes/taches-vue.php'; ?>
    </main>
</div>
</body>
</html>
