<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require __DIR__ . '/../admin/creer-reversement.php';
