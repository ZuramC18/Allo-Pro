<?php
$_GET['statut'] = 'echoue';
require __DIR__ . '/paiements.php';
