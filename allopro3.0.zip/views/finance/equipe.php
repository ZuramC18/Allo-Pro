<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../models/OutilsEquipe.php';
require_once __DIR__ . '/../../models/ReponseRapide.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$role = (string) $_SESSION['role'];
$userId = (int) $_SESSION['user_id'];
$section = is_string($_GET['section'] ?? null) ? $_GET['section'] : 'journee';
$sections = ['journee', 'taches', 'recherche', 'passations', 'agenda', 'procedures', 'annonces', 'reponses'];
if (!in_array($section, $sections, true)) {
    $section = 'journee';
}
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$dateValide = static function (string $value): bool {
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
};
$erreur = '';
$succes = (string) ($_SESSION['equipe_succes'] ?? '');
unset($_SESSION['equipe_succes']);
$outil = new OutilsEquipe();
$reponsesModel = new ReponseRapide();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $succes = '';
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'], (string) $_POST['csrf'])) {
        http_response_code(403);
        $erreur = 'Votre session a expiré. Rechargez la page puis réessayez.';
    } else {
        $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
        try {
            switch ($action) {
                case 'creer_tache':
                    $titre = trim((string) ($_POST['titre'] ?? ''));
                    $description = trim((string) ($_POST['description'] ?? ''));
                    $assigneA = filter_var($_POST['assigne_a'] ?? null, FILTER_VALIDATE_INT);
                    $echeance = trim((string) ($_POST['date_echeance'] ?? ''));
                    if ($titre === '' || mb_strlen($titre) > 160 || mb_strlen($description) > 4000
                        || !$assigneA || ($echeance !== '' && !$dateValide($echeance))) {
                        throw new InvalidArgumentException('Vérifiez le titre, le collègue et la date d’échéance.');
                    }
                    if (!$outil->creerTache($titre, $description, (int) $assigneA, $echeance ?: null, $userId)) {
                        throw new InvalidArgumentException('Le collègue choisi n’est pas disponible pour recevoir cette tâche.');
                    }
                    $succes = 'Tâche attribuée.';
                    $section = 'taches';
                    break;

                case 'terminer_tache':
                    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
                    if (!$id || !$outil->terminerTache((int) $id, $userId)) {
                        throw new InvalidArgumentException('Cette tâche ne peut pas être terminée depuis votre compte.');
                    }
                    $succes = 'Tâche marquée comme terminée.';
                    $section = 'taches';
                    break;

                case 'reouvrir_tache':
                    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
                    if (!$id || !$outil->reouvrirTache((int) $id, $userId)) {
                        throw new InvalidArgumentException('Cette tâche ne peut pas être remise à faire depuis votre compte.');
                    }
                    $succes = 'Tâche remise à faire.';
                    $section = 'taches';
                    break;

                case 'annuler_tache':
                    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
                    if (!$id || !$outil->annulerTache((int) $id, $userId)) {
                        throw new InvalidArgumentException('Seule la personne qui a attribué une tâche encore à faire peut l’annuler.');
                    }
                    $succes = 'Tâche annulée.';
                    $section = 'taches';
                    break;

                case 'creer_passation':
                    $numero = trim((string) ($_POST['numero_dossier'] ?? ''));
                    $note = trim((string) ($_POST['note'] ?? ''));
                    $prochaineAction = trim((string) ($_POST['prochaine_action'] ?? ''));
                    $dossier = $outil->getDossier($numero);
                    if ($numero === '' || mb_strlen($numero) > 40 || !$dossier || $note === '' || $prochaineAction === ''
                        || mb_strlen($note) > 4000 || mb_strlen($prochaineAction) > 500) {
                        throw new InvalidArgumentException('Indiquez un dossier existant, une note et la prochaine action.');
                    }
                    if (!$outil->creerPassation((int) $dossier['id'], $userId, $note, $prochaineAction)) {
                        throw new InvalidArgumentException('Le dossier n’est plus disponible pour cette passation.');
                    }
                    $succes = 'Passation ajoutée au dossier ' . $dossier['numero_dossier'] . '.';
                    $section = 'passations';
                    $_GET['dossier'] = $dossier['numero_dossier'];
                    break;

                case 'enregistrer_procedure':
                    $titre = trim((string) ($_POST['titre'] ?? ''));
                    $contenu = trim((string) ($_POST['contenu'] ?? ''));
                    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
                    $id = $id ? (int) $id : null;
                    if ($titre === '' || $contenu === '' || mb_strlen($titre) > 160 || mb_strlen($contenu) > 50000) {
                        throw new InvalidArgumentException('Le titre et le contenu sont obligatoires (50 000 caractères maximum).');
                    }
                    if (!$outil->enregistrerProcedure($titre, $contenu, $userId, $id)) {
                        throw new InvalidArgumentException('Cette procédure est introuvable ou vous ne pouvez pas la modifier.');
                    }
                    $succes = 'Procédure enregistrée.';
                    $section = 'procedures';
                    break;

                case 'creer_annonce':
                    $titre = trim((string) ($_POST['titre'] ?? ''));
                    $contenu = trim((string) ($_POST['contenu'] ?? ''));
                    if ($titre === '' || $contenu === '' || mb_strlen($titre) > 160 || mb_strlen($contenu) > 50000) {
                        throw new InvalidArgumentException('Le titre et le contenu de l’annonce sont obligatoires.');
                    }
                    if (!$outil->creerAnnonce($titre, $contenu, $userId)) {
                        throw new RuntimeException('Publication indisponible.');
                    }
                    $succes = 'Annonce publiée à l’équipe.';
                    $section = 'annonces';
                    break;

                case 'lire_annonces':
                    $outil->marquerAnnoncesLues($userId);
                    $succes = 'Annonces marquées comme lues.';
                    $section = 'annonces';
                    break;

                case 'enregistrer_reponse':
                    $titre = trim((string) ($_POST['titre'] ?? ''));
                    $contenu = trim((string) ($_POST['contenu'] ?? ''));
                    $categorie = trim((string) ($_POST['categorie'] ?? ''));
                    $motsCles = implode(', ', array_filter(array_map('trim', explode(',', (string) ($_POST['mots_cles'] ?? ''))), 'strlen'));
                    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
                    if ($titre === '' || $contenu === '' || mb_strlen($titre) > 100 || mb_strlen($contenu) > 2000
                        || mb_strlen($categorie) > 60 || mb_strlen($motsCles) > 255) {
                        throw new InvalidArgumentException('Vérifiez les champs de réponse rapide (titre 100, message 2 000 caractères maximum).');
                    }
                    if ($id) {
                        if (!$reponsesModel->modifierPrive((int) $id, $titre, $contenu, $motsCles, $categorie, $role, $userId)) {
                            throw new InvalidArgumentException('Vous ne pouvez modifier que vos propres réponses privées.');
                        }
                    } else {
                        if (!$reponsesModel->createPrive($titre, $contenu, $motsCles, $categorie, $role, $userId)) {
                            throw new RuntimeException('Enregistrement indisponible.');
                        }
                    }
                    $succes = 'Réponse rapide enregistrée. Elle est visible uniquement par vous.';
                    $section = 'reponses';
                    break;

                case 'supprimer_reponse':
                    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
                    if (!$id || !$reponsesModel->supprimerPrive((int) $id, $role, $userId)) {
                        throw new InvalidArgumentException('Vous ne pouvez supprimer que vos propres réponses privées.');
                    }
                    $succes = 'Réponse rapide supprimée.';
                    $section = 'reponses';
                    break;

                default:
                    throw new InvalidArgumentException('Action inconnue.');
            }
        } catch (InvalidArgumentException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Outils équipe utilisateur ' . $userId . ' : ' . $exception->getMessage());
            $erreur = 'Enregistrement impossible pour le moment. Réessayez dans quelques instants.';
        } catch (RuntimeException $exception) {
            error_log('Outils équipe utilisateur ' . $userId . ' : ' . $exception->getMessage());
            $erreur = 'Enregistrement impossible pour le moment. Réessayez dans quelques instants.';
        }
        if ($erreur === '' && $succes !== '') {
            $_SESSION['equipe_succes'] = $succes;
            $retour = 'equipe?section=' . rawurlencode($section);
            if ($section === 'passations' && !empty($_GET['dossier'])) {
                $retour .= '&dossier=' . rawurlencode((string) $_GET['dossier']);
            }
            header('Location: ' . $retour);
            exit;
        }
    }
}

$collegues = [];
$taches = [];
$agenda = [];
$annonces = [];
$procedures = [];
$passations = [];
$dossierPassationInvalide = false;
$mesReponses = [];
$resultatsRecherche = [];
$tachesJour = [];
$resumeTachesJour = ['total' => 0, 'en_retard' => 0];
$nouvellesDemandes = 0;
$annoncesNonLues = 0;
try {
    $collegues = $outil->getCollegues();
    $annoncesNonLues = $outil->compterAnnoncesNonLues($userId);
    if ($section === 'journee') {
        $nouvellesDemandes = $outil->compterNouvellesDemandes();
    }
    if ($section === 'journee' || $section === 'taches') {
        $taches = $outil->getTachesPourUtilisateur($userId);
        $tachesJour = $outil->getTachesAujourdhui($userId);
        if ($section === 'journee') {
            $resumeTachesJour = $outil->getResumeTachesAujourdhui($userId);
        }
    }
    if ($section === 'journee' || $section === 'agenda') {
        $agenda = $outil->getAgenda();
    }
    if ($section === 'journee' || $section === 'annonces') {
        $annonces = $outil->getAnnonces($userId);
    }
    if ($section === 'procedures') {
        $procedures = $outil->getProcedures();
    }
    if ($section === 'passations') {
        $numeroFiltre = is_string($_GET['dossier'] ?? null) ? trim($_GET['dossier']) : '';
        $dossierFiltre = $numeroFiltre !== '' ? $outil->getDossier($numeroFiltre) : false;
        $dossierPassationInvalide = $numeroFiltre !== '' && !$dossierFiltre;
        $passations = $dossierPassationInvalide ? [] : $outil->getPassations($dossierFiltre ? (int) $dossierFiltre['id'] : null);
    }
    if ($section === 'reponses') {
        $mesReponses = $reponsesModel->getPriveesPourUtilisateur($role, $userId);
    }
    if ($section === 'recherche') {
        $terme = is_string($_GET['q'] ?? null) ? trim(mb_substr($_GET['q'], 0, 100)) : '';
        if ($terme !== '') {
            $resultatsRecherche = $outil->rechercher($terme);
        }
    }
} catch (PDOException $exception) {
    error_log('Chargement outils équipe utilisateur ' . $userId . ' : ' . $exception->getMessage());
    $erreur = 'Les outils partagés sont temporairement indisponibles. Vérifiez que la migration des outils d’équipe a été installée.';
}

$fichierSidebar = [
    'admin' => 'sidebar-admin.php',
    'conseiller' => 'sidebar-conseiller.php',
    'coordinateur' => 'sidebar-coordinateur.php',
    'finance' => 'sidebar-admin.php',
    'qualite' => 'sidebar-qualite.php',
][$role];
$titreSection = [
    'journee' => 'Ma journée',
    'taches' => 'Tâches d’équipe',
    'recherche' => 'Recherche globale',
    'passations' => 'Passations de dossiers',
    'agenda' => 'Agenda partagé',
    'procedures' => 'Procédures internes',
    'annonces' => 'Annonces d’équipe',
    'reponses' => 'Mes réponses rapides',
][$section];
$agendaAujourdhui = array_values(array_filter($agenda, static fn(array $item): bool => $item['date_creneau'] === date('Y-m-d')));
$tachesEnRetard = (int) $resumeTachesJour['en_retard'];
$lienDemandes = [
    'admin' => 'liste-demandes.php',
    'conseiller' => 'liste-demandes.php',
    'coordinateur' => 'demandes.php',
    'finance' => 'accueil.php',
    'qualite' => 'sav.php',
][$role];
$heureAffichee = static function ($heure): string {
    $debut = (int) $heure;
    return sprintf('%02d:00–%02d:00', $debut, ($debut + 1) % 24);
};
$routeDossier = $role === 'qualite' ? 'demande.php?id=' : ($role === 'finance' ? '../admin/traiter-demande.php?id=' : 'traiter-demande.php?id=');
$routeClient = [
    'admin' => 'fiche-client?id=',
    'conseiller' => 'fiche-client?id=',
    'coordinateur' => 'fiche-client?id=',
    'finance' => 'fiche-client?id=',
    'qualite' => 'fiche-client?id=',
][$role];
$roleDossier = $role;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="./">
    <title><?= $e($titreSection) ?> — ALLÔ PRO</title>
    <?php if (in_array($role, ['admin', 'qualite', 'finance'], true)): ?>
        <link rel="stylesheet" href="../../public/css/admin.css">
    <?php elseif ($role === 'coordinateur'): ?>
        <link rel="stylesheet" href="../../public/css/coordinateur.css">
        <link rel="stylesheet" href="../../public/css/coordinateur-espace.css">
    <?php else: ?>
        <link rel="stylesheet" href="../../public/css/dashboard.css">
    <?php endif; ?>
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
    <link rel="stylesheet" href="../../public/css/employee-tools.css?v=<?= filemtime(__DIR__ . '/../../public/css/employee-tools.css') ?>">
</head>
<body>
<?php if ($role === 'coordinateur'): ?>
<div class="coord-shell"><?php include __DIR__ . '/../../includes/' . $fichierSidebar; ?><main class="coord-main"><div class="equipe-page">
<?php elseif ($role === 'admin'): ?>
<div class="admin-app"><?php include __DIR__ . '/../../includes/' . $fichierSidebar; ?><main class="admin-contenu"><div class="equipe-page">
<?php elseif (in_array($role, ['qualite', 'finance'], true)): ?>
<div class="admin-app"><?php include __DIR__ . '/../../includes/' . $fichierSidebar; ?><main class="admin-contenu"><div class="equipe-page">
<?php else: ?>
<div class="app"><?php include __DIR__ . '/../../includes/' . $fichierSidebar; ?><main class="contenu"><div class="equipe-page">
<?php endif; ?>
    <header class="equipe-entete">
        <div><p class="equipe-surtitre">Espace collaboratif · <?= $e($_SESSION['nom'] ?? '') ?></p><h1><?= $e($titreSection) ?></h1>
            <p>Vos repères de la journée et les outils communs de l’équipe ALLÔ PRO.</p></div>
        <a class="equipe-bouton equipe-bouton--principal" href="equipe?section=taches">+ Attribuer une tâche</a>
    </header>
    <nav class="equipe-nav" aria-label="Outils d’équipe">
        <?php foreach (['journee' => 'Ma journée', 'taches' => 'Tâches', 'recherche' => 'Recherche', 'passations' => 'Passations', 'agenda' => 'Agenda', 'procedures' => 'Procédures', 'annonces' => 'Annonces', 'reponses' => 'Réponses rapides'] as $cle => $libelle): ?>
            <a href="equipe?section=<?= $e($cle) ?>" <?= $section === $cle ? 'aria-current="page"' : '' ?>><?= $e($libelle) ?><?php if ($cle === 'annonces' && $annoncesNonLues): ?><span class="equipe-compteur"><?= (int) $annoncesNonLues ?></span><?php endif; ?></a>
        <?php endforeach; ?>
    </nav>
    <?php if ($erreur !== ''): ?><div class="equipe-alerte equipe-alerte--erreur" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
    <?php if ($succes !== ''): ?><div class="equipe-alerte equipe-alerte--succes" role="status"><?= $e($succes) ?></div><?php endif; ?>

    <?php if ($section === 'journee'): ?>
        <section class="equipe-kpis" aria-label="Résumé de la journée">
            <a href="equipe?section=taches" class="equipe-kpi"><strong><?= (int) $resumeTachesJour['total'] ?></strong><span>Tâche<?= (int) $resumeTachesJour['total'] === 1 ? '' : 's' ?> à faire</span></a>
            <a href="equipe?section=taches" class="equipe-kpi <?= $tachesEnRetard ? 'equipe-kpi--alerte' : '' ?>"><strong><?= $tachesEnRetard ?></strong><span>En retard</span></a>
            <a href="equipe?section=agenda" class="equipe-kpi"><strong><?= count($agendaAujourdhui) ?></strong><span>Créneau<?= count($agendaAujourdhui) === 1 ? '' : 'x' ?> aujourd’hui</span></a>
            <a href="equipe?section=annonces" class="equipe-kpi <?= $annoncesNonLues ? 'equipe-kpi--attention' : '' ?>"><strong><?= $annoncesNonLues ?></strong><span>Annonce<?= $annoncesNonLues === 1 ? '' : 's' ?> non lue<?= $annoncesNonLues === 1 ? '' : 's' ?></span></a>
            <a href="equipe?section=taches" class="equipe-kpi"><strong><?= count($collegues) ?></strong><span>Collègues actifs</span></a>
        </section>
        <div class="equipe-grille">
            <section class="equipe-carte"><header><h2>À faire aujourd’hui</h2><a href="equipe?section=taches">Toutes les tâches →</a></header>
                <?php if (!$tachesJour): ?><p class="equipe-vide">Aucune tâche urgente ou échue à afficher.</p><?php endif; ?>
                <?php foreach ($tachesJour as $task): ?><article class="equipe-ligne <?= !empty($task['en_retard']) ? 'equipe-ligne--retard' : '' ?>"><div><strong><?= $e($task['titre']) ?></strong><small><?= !empty($task['date_echeance']) ? ($task['en_retard'] ? 'En retard · ' : 'Échéance · ') . $e(date('d/m/Y', strtotime($task['date_echeance']))) : 'Sans échéance' ?></small></div><a href="equipe?section=taches">Ouvrir</a></article><?php endforeach; ?>
            </section>
            <section class="equipe-carte"><header><h2>Agenda du jour</h2><a href="equipe?section=agenda">Agenda partagé →</a></header>
                <?php if (!$agendaAujourdhui): ?><p class="equipe-vide">Aucun créneau partagé aujourd’hui.</p><?php endif; ?>
                <?php foreach (array_slice($agendaAujourdhui, 0, 6) as $event): ?><article class="equipe-ligne"><div><strong><?= $e($heureAffichee($event['heure_creneau'])) ?> · <?= $e($event['numero_dossier']) ?></strong><small><?= $e($event['client_nom']) ?> · <?= $e($event['categorie']) ?></small></div></article><?php endforeach; ?>
            </section>
        </div>
        <section class="equipe-carte equipe-raccourcis"><header><h2>Accès rapide</h2></header><div class="equipe-raccourcis__grille">
            <a href="equipe?section=recherche">Rechercher un client, dossier ou ticket</a><a href="equipe?section=passations">Ajouter une passation de dossier</a>
            <a href="equipe?section=procedures">Consulter les procédures</a><a href="equipe?section=reponses">Gérer mes messages rapides privés</a>
        </div></section>
        <?php if ($annonces): ?><section class="equipe-carte"><header><h2>Dernières annonces</h2><a href="equipe?section=annonces">Toutes les annonces →</a></header>
            <?php foreach (array_slice($annonces, 0, 3) as $announcement): ?><article class="equipe-annonce"><h3><?= $e($announcement['titre']) ?></h3><p><?= nl2br($e($announcement['contenu'])) ?></p><small>Par <?= $e($announcement['auteur_nom']) ?> · <?= $e(date('d/m/Y H:i', strtotime($announcement['date_creation']))) ?></small></article><?php endforeach; ?>
        </section><?php endif; ?>

    <?php elseif ($section === 'taches'): ?>
        <div class="equipe-grille equipe-grille--taches">
            <section class="equipe-carte"><header><h2>Attribuer une tâche</h2></header>
                <form method="post" action="equipe?section=taches" class="equipe-form">
                    <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="creer_tache">
                    <label>Titre <input name="titre" maxlength="160" required></label>
                    <label>À attribuer à <select name="assigne_a" required><option value="">Choisir un collègue</option><?php foreach ($collegues as $collegue): ?><option value="<?= (int) $collegue['id'] ?>"><?= $e($collegue['nom']) ?> · <?= $e($collegue['role']) ?></option><?php endforeach; ?></select></label>
                    <label>Échéance <input type="date" name="date_echeance" min="<?= date('Y-m-d') ?>"></label>
                    <label>Détails <textarea name="description" maxlength="4000" rows="3"></textarea></label>
                    <button class="equipe-bouton equipe-bouton--principal">Attribuer la tâche</button>
                </form>
            </section>
            <section class="equipe-carte"><header><h2>Mes tâches et tâches confiées</h2><span><?= count($taches) ?> au total</span></header>
                <?php if (!$taches): ?><p class="equipe-vide">Aucune tâche pour le moment.</p><?php endif; ?>
                <?php foreach ($taches as $task): ?><article class="equipe-tache <?= !empty($task['en_retard']) ? 'equipe-tache--retard' : '' ?>">
                    <div><strong><?= $e($task['titre']) ?></strong><p><?= nl2br($e($task['description'])) ?></p><small>Assignée à <?= $e($task['assigne_nom']) ?> · créée par <?= $e($task['auteur_nom']) ?><?= $task['date_echeance'] ? ' · échéance ' . $e(date('d/m/Y', strtotime($task['date_echeance']))) : '' ?></small>
                        <?php if (!empty($task['en_retard'])): ?><span class="equipe-badge equipe-badge--retard">En retard</span><?php endif; ?><?php if ($task['statut'] === 'terminee'): ?><span class="equipe-badge">Terminée</span><?php endif; ?></div>
                    <div class="equipe-tache__actions">
                        <?php if ($task['statut'] === 'a_faire' && (int) $task['assigne_a'] === $userId): ?>
                            <form method="post" action="equipe?section=taches"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="terminer_tache"><input type="hidden" name="id" value="<?= (int) $task['id'] ?>"><button class="equipe-bouton equipe-bouton--secondaire">Terminer</button></form>
                        <?php elseif ($task['statut'] === 'terminee' && (int) $task['assigne_a'] === $userId): ?>
                            <form method="post" action="equipe?section=taches"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="reouvrir_tache"><input type="hidden" name="id" value="<?= (int) $task['id'] ?>"><button class="equipe-bouton equipe-bouton--secondaire">Annuler « Terminer »</button></form>
                        <?php endif; ?>
                        <?php if ($task['statut'] === 'a_faire' && (int) $task['cree_par'] === $userId): ?>
                            <form method="post" action="equipe?section=taches" onsubmit="return confirm('Annuler cette tâche envoyée ? Elle sera supprimée de la liste du collègue.')"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="annuler_tache"><input type="hidden" name="id" value="<?= (int) $task['id'] ?>"><button class="equipe-bouton equipe-bouton--danger">Annuler l’envoi</button></form>
                        <?php endif; ?>
                    </div>
                </article><?php endforeach; ?>
            </section>
        </div>

    <?php elseif ($section === 'recherche'): ?>
        <section class="equipe-carte"><form method="get" action="equipe" class="equipe-recherche"><input type="hidden" name="section" value="recherche"><label for="q">Client, e-mail, téléphone, identifiant CLIENT-123, dossier AP-2026-000001, ticket SAV-123 ou mots de la description</label><div><input id="q" name="q" value="<?= $e($_GET['q'] ?? '') ?>" maxlength="100" required placeholder="Tous les mots saisis doivent correspondre"><button class="equipe-bouton equipe-bouton--principal">Rechercher</button></div></form></section>
        <section class="equipe-carte"><header><h2>Résultats</h2><span><?= count($resultatsRecherche) ?> résultat<?= count($resultatsRecherche) === 1 ? '' : 's' ?></span></header>
            <?php if (!$resultatsRecherche && !empty($_GET['q'])): ?><p class="equipe-vide">Aucun résultat trouvé.</p><?php endif; ?>
            <?php foreach ($resultatsRecherche as $resultat): ?><article class="equipe-ligne equipe-recherche__resultat"><div><strong><?= $e($resultat['reference']) ?> · <?= $e($resultat['client']) ?></strong><small><?= $e($resultat['type'] === 'ticket' ? 'Ticket SAV' : ($resultat['type'] === 'client' ? 'Client' : 'Dossier')) ?> · <?= $e($resultat['sujet']) ?> · <?= $e($resultat['statut']) ?> · <?= $e(date('d/m/Y', strtotime($resultat['date_creation']))) ?></small><small><?= $e($resultat['telephone'] ?: 'Téléphone non renseigné') ?><?= !empty($resultat['email']) ? ' · ' . $e($resultat['email']) : '' ?></small></div><div class="equipe-recherche__actions"><?php if ($resultat['type'] !== 'client'): ?><a href="<?= $e($routeDossier) ?><?= (int) $resultat['id'] ?>">Ouvrir le dossier</a><?php endif; ?><a href="<?= $e($routeClient) ?><?= (int) $resultat['client_id'] ?>">Fiche complète du client</a><?php if (!empty($resultat['numero_dossier'])): ?><a href="equipe?section=passations&amp;dossier=<?= rawurlencode($resultat['numero_dossier']) ?>">Passations</a><?php endif; ?></div></article><?php endforeach; ?>
        </section>

    <?php elseif ($section === 'passations'): ?>
        <div class="equipe-grille equipe-grille--passations">
            <section class="equipe-carte"><header><h2>Nouvelle passation</h2></header><form method="post" action="equipe?section=passations" class="equipe-form">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="creer_passation">
                <label>Numéro du dossier <input name="numero_dossier" maxlength="40" required value="<?= $e($_GET['dossier'] ?? '') ?>" placeholder="AP-2026-000001"></label>
                <label>Note de passation <textarea name="note" maxlength="4000" rows="4" required></textarea></label>
                <label>Prochaine action <textarea name="prochaine_action" maxlength="500" rows="2" required></textarea></label>
                <button class="equipe-bouton equipe-bouton--principal">Ajouter la passation</button>
            </form></section>
            <section class="equipe-carte"><header><h2>Historique des passations</h2><span>50 plus récentes</span></header>
                <?php if ($dossierPassationInvalide): ?><p class="equipe-alerte equipe-alerte--erreur">Dossier introuvable.</p><?php endif; ?>
                <?php if (!$passations): ?><p class="equipe-vide">Aucune passation trouvée.</p><?php endif; ?>
                <?php foreach ($passations as $handoff): ?><article class="equipe-annonce"><h3><?= $e($handoff['numero_dossier']) ?></h3><p><?= nl2br($e($handoff['note'])) ?></p><p><strong>Prochaine action :</strong> <?= nl2br($e($handoff['prochaine_action'])) ?></p><small><?= $e($handoff['auteur_nom']) ?> · <?= $e(date('d/m/Y H:i', strtotime($handoff['date_creation']))) ?></small></article><?php endforeach; ?>
            </section>
        </div>

    <?php elseif ($section === 'agenda'): ?>
        <section class="equipe-carte"><header><h2>Créneaux à venir</h2><span><?= count($agenda) ?> entrée<?= count($agenda) === 1 ? '' : 's' ?></span></header>
            <p class="equipe-aide">Seules les interventions acceptées par un technicien et les nouvelles demandes avec un créneau complet sont affichées.</p>
            <?php if (!$agenda): ?><p class="equipe-vide">Aucun créneau à venir.</p><?php endif; ?>
            <?php foreach ($agenda as $event): ?><article class="equipe-ligne"><div><strong><?= $e(date('d/m/Y', strtotime($event['date_creneau']))) ?> · <?= $e($heureAffichee($event['heure_creneau'])) ?> · <?= $e($event['numero_dossier']) ?></strong><small><?= $e($event['client_nom']) ?> · <?= $e($event['categorie']) ?></small></div><div><span class="equipe-badge <?= $event['source'] === 'intervention' ? 'equipe-badge--ok' : '' ?>"><?= $event['source'] === 'intervention' ? 'Intervention acceptée' : 'Nouvelle demande' ?></span></div></article><?php endforeach; ?>
        </section>

    <?php elseif ($section === 'procedures'): ?>
        <section class="equipe-carte"><header><h2>Base de connaissances</h2><a href="equipe?section=procedures&amp;nouvelle=1">+ Ajouter une procédure</a></header>
            <?php if (isset($_GET['nouvelle']) || isset($_GET['modifier'])):
                $procedureEdit = isset($_GET['modifier']) ? $outil->getProcedure((int) $_GET['modifier']) : false;
                if ($procedureEdit && (int) $procedureEdit['auteur_id'] !== $userId && $role !== 'admin') $procedureEdit = false;
            ?>
            <form method="post" action="equipe?section=procedures" class="equipe-form equipe-form--large">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="enregistrer_procedure">
                <input type="hidden" name="id" value="<?= (int) ($procedureEdit['id'] ?? 0) ?>">
                <label>Titre <input name="titre" maxlength="160" required value="<?= $e($procedureEdit['titre'] ?? '') ?>"></label>
                <label>Contenu <textarea name="contenu" maxlength="50000" rows="10" required><?= $e($procedureEdit['contenu'] ?? '') ?></textarea></label>
                <button class="equipe-bouton equipe-bouton--principal">Publier la procédure</button>
            </form>
            <?php endif; ?>
            <?php if (!$procedures): ?><p class="equipe-vide">La base de connaissances est encore vide.</p><?php endif; ?>
            <?php foreach ($procedures as $procedure): ?><article class="equipe-annonce"><h3><?= $e($procedure['titre']) ?></h3><p><?= nl2br($e($procedure['contenu'])) ?></p><small>Par <?= $e($procedure['auteur_nom']) ?> · mise à jour <?= $e(date('d/m/Y H:i', strtotime($procedure['date_modification']))) ?></small><?php if ((int) $procedure['auteur_id'] === $userId || $role === 'admin'): ?><a href="equipe?section=procedures&amp;modifier=<?= (int) $procedure['id'] ?>">Modifier</a><?php endif; ?></article><?php endforeach; ?>
        </section>

    <?php elseif ($section === 'annonces'): ?>
        <div class="equipe-grille equipe-grille--passations">
            <section class="equipe-carte"><header><h2>Publier une annonce</h2></header><form method="post" action="equipe?section=annonces" class="equipe-form"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="creer_annonce"><label>Titre <input name="titre" maxlength="160" required></label><label>Message <textarea name="contenu" maxlength="50000" rows="6" required></textarea></label><button class="equipe-bouton equipe-bouton--principal">Publier à l’équipe</button></form></section>
            <section class="equipe-carte"><header><h2>Annonces d’équipe</h2><span><?= $annoncesNonLues ?> non lue<?= $annoncesNonLues === 1 ? '' : 's' ?></span></header>
                <?php if ($annoncesNonLues): ?><form method="post" action="equipe?section=annonces"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="lire_annonces"><button class="equipe-bouton equipe-bouton--secondaire">Marquer toutes comme lues</button></form><?php endif; ?>
                <?php foreach ($annonces as $announcement): ?><article class="equipe-annonce"><h3><?= $e($announcement['titre']) ?></h3><p><?= nl2br($e($announcement['contenu'])) ?></p><small>Par <?= $e($announcement['auteur_nom']) ?> · <?= $e(date('d/m/Y H:i', strtotime($announcement['date_creation']))) ?></small><p class="equipe-lecture"><?= $announcement['date_lecture'] ? 'Lu le ' . $e(date('d/m/Y H:i', strtotime($announcement['date_lecture']))) : 'Non lu' ?> · <?= (int) $announcement['nombre_lectures'] ?> lecture<?= (int) $announcement['nombre_lectures'] === 1 ? '' : 's' ?></p><?php if ($role === 'admin' || (int) $announcement['auteur_id'] === $userId): ?><details><summary>Voir les accusés de lecture</summary><?php foreach ($outil->getLecturesAnnonce((int) $announcement['id']) as $lecture): ?><p class="equipe-aide"><?= $e($lecture['nom']) ?> · <?= $e($lecture['role']) ?> · <?= $e(date('d/m/Y H:i', strtotime($lecture['date_lecture']))) ?></p><?php endforeach; ?></details><?php endif; ?></article><?php endforeach; ?>
            </section>
        </div>

    <?php elseif ($section === 'reponses'): ?>
        <div class="equipe-grille equipe-grille--passations">
            <section class="equipe-carte"><header><h2>Ajouter un message privé</h2></header><p class="equipe-aide">Ces réponses apparaissent dans votre interface de messagerie uniquement. Les réponses partagées existantes restent disponibles.</p>
                <form method="post" action="equipe?section=reponses" class="equipe-form"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="enregistrer_reponse"><label>Titre <input name="titre" maxlength="100" required></label><label>Catégorie <input name="categorie" maxlength="60"></label><label>Mots-clés (séparés par des virgules) <input name="mots_cles" maxlength="255"></label><label>Message <textarea name="contenu" maxlength="2000" rows="5" required></textarea></label><button class="equipe-bouton equipe-bouton--principal">Enregistrer ma réponse</button></form>
            </section>
            <section class="equipe-carte"><header><h2>Mes réponses privées</h2><span><?= count($mesReponses) ?></span></header>
                <?php if (!$mesReponses): ?><p class="equipe-vide">Vous n’avez pas encore créé de message rapide privé.</p><?php endif; ?>
                <?php foreach ($mesReponses as $reply): ?><article class="equipe-annonce"><h3><?= $e($reply['titre']) ?></h3><p><?= nl2br($e($reply['contenu'])) ?></p><small><?= $e($reply['categorie']) ?><?= $reply['mots_cles'] ? ' · ' . $e($reply['mots_cles']) : '' ?></small><details><summary>Modifier</summary><form method="post" action="equipe?section=reponses" class="equipe-form"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="enregistrer_reponse"><input type="hidden" name="id" value="<?= (int) $reply['id'] ?>"><label>Titre <input name="titre" maxlength="100" required value="<?= $e($reply['titre']) ?>"></label><label>Catégorie <input name="categorie" maxlength="60" value="<?= $e($reply['categorie']) ?>"></label><label>Mots-clés <input name="mots_cles" maxlength="255" value="<?= $e($reply['mots_cles']) ?>"></label><label>Message <textarea name="contenu" maxlength="2000" required><?= $e($reply['contenu']) ?></textarea></label><button class="equipe-bouton equipe-bouton--secondaire">Enregistrer</button></form><form method="post" action="equipe?section=reponses" onsubmit="return confirm('Supprimer cette réponse rapide ?')"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="supprimer_reponse"><input type="hidden" name="id" value="<?= (int) $reply['id'] ?>"><button class="equipe-bouton equipe-bouton--danger">Supprimer</button></form></details></article><?php endforeach; ?>
            </section>
        </div>
    <?php endif; ?>
</div></main></div>
</body>
</html>
