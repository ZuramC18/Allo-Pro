<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('paiements');
require_once __DIR__ . '/../../models/Facture.php';

$idFacture = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if (!$idFacture || $idFacture < 1) {
    http_response_code(404);
    exit('Facture introuvable.');
}

try {
    $facture = (new Facture())->getFichierPourFinance((int) $idFacture);
} catch (RuntimeException $exception) {
    http_response_code(404);
    exit('Le PDF de cette facture est indisponible.');
}
if (!$facture) {
    http_response_code(404);
    exit('Facture introuvable.');
}

header('Content-Type: application/pdf');
header('Content-Length: ' . (string) filesize($facture['chemin_absolu']));
header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $facture['numero']) . '.pdf"');
header('X-Content-Type-Options: nosniff');
readfile($facture['chemin_absolu']);
exit;
