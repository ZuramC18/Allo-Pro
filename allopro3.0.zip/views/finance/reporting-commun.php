<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/LivreComptes.php';
require_once __DIR__ . '/../../models/Reversement.php';
require_once __DIR__ . '/../../models/Statistique.php';

$modeMarges = ($financeRapportMode ?? 'reporting') === 'marges';
$aujourdhui = date('Y-m-d');
$debutDefaut = date('Y-m-01');
$validerDate = static function ($valeur, string $defaut): string {
    if (!is_string($valeur) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $valeur)) {
        return $defaut;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $valeur);
    return $date && $date->format('Y-m-d') === $valeur ? $valeur : $defaut;
};
$debut = $validerDate($_GET['debut'] ?? $debutDefaut, $debutDefaut);
$fin = $validerDate($_GET['fin'] ?? $aujourdhui, $aujourdhui);
if ($debut > $fin) {
    $debut = $debutDefaut;
    $fin = $aujourdhui;
}
$livre = new LivreComptes();
$ecritures = $livre->getEcritures($debut, $fin);
$credits = 0.0;
$debits = 0.0;
$parCategorie = [];
$detailsCategories = [];
foreach ($ecritures as $ecriture) {
    $credit = (float) $ecriture['montant_credit'];
    $debit = (float) $ecriture['montant_debit'];
    $credits += $credit;
    $debits += $debit;
    $parCategorie[$ecriture['categorie']] = ($parCategorie[$ecriture['categorie']] ?? 0.0) + $credit - $debit;
    if (!isset($detailsCategories[$ecriture['categorie']])) {
        $detailsCategories[$ecriture['categorie']] = ['nombre' => 0, 'credits' => 0.0, 'debits' => 0.0];
    }
    $detailsCategories[$ecriture['categorie']]['nombre']++;
    $detailsCategories[$ecriture['categorie']]['credits'] += $credit;
    $detailsCategories[$ecriture['categorie']]['debits'] += $debit;
}
$finExclusive = (new DateTimeImmutable($fin))->modify('+1 day')->format('Y-m-d');
$margeCalculee = $modeMarges ? (new Statistique())->margeRealisee($debut, $finExclusive) : 0.0;
$tauxMargeRevenus = $credits > 0 ? ($margeCalculee / $credits) * 100 : 0;
$nombreJours = (int) (new DateTimeImmutable($debut))->diff(new DateTimeImmutable($fin))->days + 1;
$reversementsDus = (new Reversement())->getReversementsDus();
$synthesePartenaires = $livre->getSynthesePartenaires();
$echapper = static fn($valeur): string => htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
$titreFinanceRapport = $modeMarges ? 'Marges' : 'Reporting financier';
$libellesCategories = [
    'paiement' => 'Paiements de services',
    'pass' => 'Pass',
    'abonnement' => 'Abonnements',
    'reversement' => 'Reversements partenaires',
];
$urlExportRapport = '../finance/export-donnees.php?' . http_build_query([
    'debut' => $debut,
    'fin' => $fin,
    'categorie' => 'toutes',
]);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $echapper($titreFinanceRapport) ?> — ALLÔ PRO Finance</title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <?php if ($modeMarges): ?>
        <link rel="stylesheet" href="../../public/css/finance-marges.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-marges.css') ?>">
    <?php else: ?>
        <link rel="stylesheet" href="../../public/css/finance-reporting.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-reporting.css') ?>">
    <?php endif; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu<?= $modeMarges ? ' finance-marges' : ' finance-reporting' ?>">
        <?php if ($modeMarges): ?>
        <header class="finance-marges__hero">
            <span class="finance-marges__eyebrow">Performance financière</span>
            <h1><?= $echapper($titreFinanceRapport) ?></h1>
            <p>Suivez la marge comptabilisée, les revenus et les reversements sur la période sélectionnée.</p>
        </header>
        <form class="finance-marges__periode" method="get" aria-label="Période d’analyse des marges">
            <div class="finance-marges__periode-intro">
                <strong>Période d’analyse</strong>
                <span><?= number_format($nombreJours, 0, ',', ' ') ?> jour<?= $nombreJours === 1 ? '' : 's' ?></span>
            </div>
            <label>Du <input type="date" name="debut" value="<?= $echapper($debut) ?>" required></label>
            <label>Au <input type="date" name="fin" value="<?= $echapper($fin) ?>" required></label>
            <button type="submit">Actualiser</button>
        </form>
        <section class="finance-marges__kpis" aria-label="Indicateurs de marge">
            <article class="finance-marges__kpi finance-marges__kpi--revenus">
                <span>Revenus encaissés</span>
                <strong><?= number_format($credits, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p>Paiements validés sur la période</p>
            </article>
            <article class="finance-marges__kpi finance-marges__kpi--marge">
                <span>Marge comptabilisée</span>
                <strong><?= number_format($margeCalculee, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p>Selon la période de fin des reversements</p>
            </article>
            <article class="finance-marges__kpi finance-marges__kpi--taux">
                <span>Marge / revenus encaissés</span>
                <strong><?= number_format($tauxMargeRevenus, 1, ',', ' ') ?><small>%</small></strong>
                <p>Part de la marge dans les revenus de la période</p>
            </article>
            <article class="finance-marges__kpi finance-marges__kpi--reversements">
                <span>Reversements payés</span>
                <strong><?= number_format($debits, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p><?= number_format($synthesePartenaires['a_reverser'], 0, ',', ' ') ?> F&nbsp;CFA restent à reverser</p>
            </article>
        </section>
        <?php else: ?>
        <header class="finance-reporting__hero">
            <div>
                <span class="finance-reporting__eyebrow">Pilotage financier</span>
                <h1><?= $echapper($titreFinanceRapport) ?></h1>
                <p>Une synthèse des encaissements et reversements réellement payés sur la période choisie.</p>
            </div>
            <a class="finance-reporting__export" href="<?= $echapper($urlExportRapport) ?>">Exporter cette période <span aria-hidden="true">→</span></a>
        </header>
        <form class="finance-reporting__periode" method="get" aria-label="Période du reporting">
            <div class="finance-reporting__periode-intro">
                <strong>Période du rapport</strong>
                <span><?= number_format($nombreJours, 0, ',', ' ') ?> jour<?= $nombreJours === 1 ? '' : 's' ?></span>
            </div>
            <label>Du <input type="date" name="debut" value="<?= $echapper($debut) ?>" required></label>
            <label>Au <input type="date" name="fin" value="<?= $echapper($fin) ?>" required></label>
            <button type="submit">Actualiser</button>
        </form>
        <section class="finance-reporting__kpis" aria-label="Résumé financier">
            <article class="finance-reporting__kpi finance-reporting__kpi--revenus">
                <span>Revenus encaissés</span>
                <strong><?= number_format($credits, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p><?= number_format(count(array_filter($ecritures, static fn(array $ecriture): bool => (float) $ecriture['montant_credit'] > 0)), 0, ',', ' ') ?> opérations créditrices sur la période</p>
            </article>
            <article class="finance-reporting__kpi finance-reporting__kpi--reversements">
                <span>Reversements payés</span>
                <strong><?= number_format($debits, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p><?= number_format($detailsCategories['reversement']['nombre'] ?? 0, 0, ',', ' ') ?> reversement<?= ($detailsCategories['reversement']['nombre'] ?? 0) === 1 ? '' : 's' ?> enregistré<?= ($detailsCategories['reversement']['nombre'] ?? 0) === 1 ? '' : 's' ?></p>
            </article>
            <article class="finance-reporting__kpi finance-reporting__kpi--solde">
                <span>Solde net de la période</span>
                <strong><?= number_format($credits - $debits, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p>Revenus moins reversements payés</p>
            </article>
            <article class="finance-reporting__kpi finance-reporting__kpi--commission">
                <span>Commissions calculées</span>
                <strong><?= number_format((float) $synthesePartenaires['commissions_calculees'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p>Cumul enregistré et à reverser, tous exercices</p>
            </article>
            <article class="finance-reporting__kpi finance-reporting__kpi--du">
                <span>À reverser aux partenaires</span>
                <strong><?= number_format((float) $synthesePartenaires['a_reverser'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p><?= number_format(count($reversementsDus), 0, ',', ' ') ?> partenaire<?= count($reversementsDus) === 1 ? '' : 's' ?> attendent la préparation d’un reversement</p>
            </article>
        </section>
        <?php endif; ?>
        <section class="<?= $modeMarges ? 'admin-panneau' : 'finance-reporting__detail' ?>">
            <div class="admin-panneau__titre"><?= $modeMarges ? 'Activité financière par catégorie' : 'Détail par type d’opération' ?> · <?= count($ecritures) ?> écritures</div>
            <div class="admin-table-wrapper" tabindex="0" role="region" aria-label="Détail financier par catégorie">
                <table class="admin-table">
                    <thead>
                    <?php if ($modeMarges): ?>
                        <tr><th>Catégorie</th><th>Écritures</th><th>Revenus</th><th>Reversements</th><th>Solde net</th></tr>
                    <?php else: ?>
                        <tr><th>Type d’opération</th><th>Écritures</th><th>Crédits</th><th>Débits</th><th>Solde net</th></tr>
                    <?php endif; ?>
                    </thead>
                    <tbody>
                    <?php if (!$parCategorie): ?>
                        <tr><td colspan="5">Aucune opération sur cette période.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($parCategorie as $categorie => $montant): ?>
                        <tr>
                            <td><?= $echapper($libellesCategories[$categorie] ?? ucfirst($categorie)) ?></td>
                            <?php if ($modeMarges): ?>
                                <td><?= number_format($detailsCategories[$categorie]['nombre'], 0, ',', ' ') ?></td>
                                <td><?= number_format($detailsCategories[$categorie]['credits'], 0, ',', ' ') ?> F&nbsp;CFA</td>
                                <td><?= number_format($detailsCategories[$categorie]['debits'], 0, ',', ' ') ?> F&nbsp;CFA</td>
                            <?php else: ?>
                                <td><?= number_format($detailsCategories[$categorie]['nombre'], 0, ',', ' ') ?></td>
                                <td><?= number_format($detailsCategories[$categorie]['credits'], 0, ',', ' ') ?> F&nbsp;CFA</td>
                                <td><?= number_format($detailsCategories[$categorie]['debits'], 0, ',', ' ') ?> F&nbsp;CFA</td>
                            <?php endif; ?>
                            <td><?= number_format($montant, 0, ',', ' ') ?> F&nbsp;CFA</td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <?php if ($parCategorie): ?>
                    <tfoot>
                        <tr><th>Total période</th><th><?= number_format(count($ecritures), 0, ',', ' ') ?></th><th><?= number_format($credits, 0, ',', ' ') ?> F&nbsp;CFA</th><th><?= number_format($debits, 0, ',', ' ') ?> F&nbsp;CFA</th><th><?= number_format($credits - $debits, 0, ',', ' ') ?> F&nbsp;CFA</th></tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
            <?php if ($modeMarges): ?>
                <p class="finance-marges__note">La marge est calculée à partir des commissions enregistrées dans les reversements dont la date de fin appartient à la période. Le montant à reverser est un solde courant, indépendant des dates sélectionnées.</p>
            <?php else: ?>
                <p class="finance-reporting__note">Les crédits et débits du tableau correspondent aux écritures de la période. Les commissions et le montant à reverser sont des cumuls courants, indépendants de la période sélectionnée.</p>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
