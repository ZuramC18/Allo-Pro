<?php
$financeTitrePage = 'Revenus';
$_GET['categorie'] = 'revenus';
require __DIR__ . '/livre-comptes.php';
