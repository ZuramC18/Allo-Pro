<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('paiements');
require_once __DIR__ . '/../../models/Facture.php';

$idFacture = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if (!$idFacture || $idFacture < 1) {
    http_response_code(404);
    exit('Facture introuvable.');
}

$facture = (new Facture())->getPourFinanceParId((int) $idFacture);
if (!$facture) {
    http_response_code(404);
    exit('Facture introuvable.');
}
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$statuts = ['envoye' => ['Envoyée', 'vert'], 'en_attente' => ['En attente', 'amber'], 'echec' => ['Échec', 'rouge']];
$statut = $statuts[$facture['email_statut']] ?? [$facture['email_statut'], 'gris'];
$types = ['intervention' => 'Intervention', 'abonnement' => 'Abonnement', 'pass' => 'Pass'];
$client = trim((string) $facture['client_prenom'] . ' ' . (string) $facture['client_nom']);
$pdfDisponible = trim((string) $facture['chemin_fichier']) !== '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $echapper($facture['numero'] ?: 'Détail facture') ?> — ALLÔ PRO Finance</title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/finance-factures.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-factures.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu finance-factures">
        <a class="facture-retour" href="factures.php">← Retour aux factures</a>
        <header class="facture-detail-entete">
            <div>
                <span class="factures-entete__eyebrow">Détail de la facture</span>
                <h1><?= $echapper($facture['numero'] ?: 'Facture #' . (int) $facture['id']) ?></h1>
                <p>Émise le <?= $echapper(date('d/m/Y à H:i', strtotime($facture['date_emission']))) ?></p>
            </div>
            <span class="admin-badge admin-badge--<?= $echapper($statut[1]) ?> facture-detail-entete__statut"><?= $echapper($statut[0]) ?></span>
        </header>

        <section class="facture-detail-total" aria-label="Montant de la facture">
            <span>Montant total</span>
            <strong><?= number_format((float) $facture['montant'], 0, ',', ' ') ?> <small><?= $echapper($facture['devise']) ?></small></strong>
            <span class="facture-detail-total__libelle"><?= $echapper($facture['libelle']) ?></span>
        </section>

        <div class="facture-detail-grille">
            <section class="facture-detail-panel">
                <h2>Informations de facturation</h2>
                <dl class="facture-detail-liste">
                    <div><dt>Numéro de facture</dt><dd><?= $echapper($facture['numero'] ?: 'Facture #' . (int) $facture['id']) ?></dd></div>
                    <div><dt>Type d’opération</dt><dd><?= $echapper($types[$facture['type_operation']] ?? ucfirst((string) $facture['type_operation'])) ?></dd></div>
                    <div><dt>Désignation</dt><dd><?= $echapper($facture['libelle']) ?></dd></div>
                    <div><dt>Référence de transaction</dt><dd><?= $echapper($facture['reference_source']) ?></dd></div>
                    <div><dt>Date d’émission</dt><dd><?= $echapper(date('d/m/Y à H:i', strtotime($facture['date_emission']))) ?></dd></div>
                </dl>
            </section>

            <section class="facture-detail-panel">
                <h2>Client</h2>
                <dl class="facture-detail-liste">
                    <div><dt>Nom</dt><dd><?= $echapper($client !== '' ? $client : 'Client') ?></dd></div>
                    <div><dt>E-mail du compte</dt><dd><?= $echapper($facture['client_email'] ?: '—') ?></dd></div>
                    <div><dt>Téléphone</dt><dd><?= $echapper($facture['client_telephone'] ?: '—') ?></dd></div>
                    <div><dt>Facture envoyée à</dt><dd><?= $echapper($facture['email_destinataire']) ?></dd></div>
                </dl>
            </section>

            <section class="facture-detail-panel facture-detail-panel--envoi">
                <h2>État de l’envoi</h2>
                <dl class="facture-detail-liste">
                    <div><dt>Statut</dt><dd><span class="admin-badge admin-badge--<?= $echapper($statut[1]) ?>"><?= $echapper($statut[0]) ?></span></dd></div>
                    <div><dt>Envoyée le</dt><dd><?= $facture['email_envoye_at'] ? $echapper(date('d/m/Y à H:i', strtotime($facture['email_envoye_at']))) : 'Pas encore envoyée' ?></dd></div>
                </dl>
                <?php if ($facture['email_statut'] === 'echec' && trim((string) $facture['email_erreur']) !== ''): ?>
                    <p class="facture-detail-erreur"><strong>Information sur l’échec</strong><?= nl2br($echapper($facture['email_erreur'])) ?></p>
                <?php endif; ?>
            </section>
        </div>

        <footer class="facture-detail-actions">
            <?php if ($pdfDisponible): ?>
                <a class="facture-detail-action facture-detail-action--primaire" href="telecharger-facture.php?id=<?= (int) $facture['id'] ?>" target="_blank" rel="noopener">Télécharger le PDF <span aria-hidden="true">↓</span></a>
            <?php else: ?>
                <span class="facture-detail-pdf-indisponible">Le PDF n’est pas encore archivé.</span>
            <?php endif; ?>
            <a class="facture-detail-action" href="paiements-clients.php">Voir les paiements clients</a>
        </footer>
    </main>
</div>
</body>
</html>
