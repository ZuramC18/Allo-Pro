<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
$financeTitrePage = 'Rémunérations partenaires';
require __DIR__ . '/../admin/reversements.php';
