<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
$financeTitrePage = 'Commissions partenaires';
require __DIR__ . '/../admin/partage-benefices.php';
