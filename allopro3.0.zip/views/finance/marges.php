<?php
$financeRapportMode = 'marges';
require __DIR__ . '/reporting-commun.php';
