<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('paiements');
require_once __DIR__ . '/../../models/Facture.php';

$factureModel = new Facture();
$statutsAutorises = ['envoye', 'en_attente', 'echec'];
$typesAutorises = ['intervention', 'abonnement', 'pass'];
$recherche = is_string($_GET['recherche'] ?? null) ? trim(mb_substr($_GET['recherche'], 0, 100)) : '';
$statutFiltre = is_string($_GET['statut'] ?? null) && in_array($_GET['statut'], $statutsAutorises, true)
    ? $_GET['statut']
    : '';
$typeFiltre = is_string($_GET['type'] ?? null) && in_array($_GET['type'], $typesAutorises, true)
    ? $_GET['type']
    : '';
$parPage = 25;
$totalFactures = $factureModel->compterPourFinance($recherche ?: null, $statutFiltre ?: null, $typeFiltre ?: null);
$nombrePages = max(1, (int) ceil($totalFactures / $parPage));
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = max(1, min($nombrePages, $page ?: 1));
$decalage = ($page - 1) * $parPage;
$factures = $factureModel->getAllPourFinance(
    $parPage,
    $decalage,
    $recherche ?: null,
    $statutFiltre ?: null,
    $typeFiltre ?: null
);
$statistiques = $factureModel->getStatistiquesFinance();
$filtres = array_filter([
    'recherche' => $recherche,
    'statut' => $statutFiltre,
    'type' => $typeFiltre,
], static fn($valeur) => $valeur !== '');
$urlPage = static fn(int $numero): string => '?' . http_build_query($filtres + ['page' => $numero]);
$premierResultat = $totalFactures > 0 ? $decalage + 1 : 0;
$dernierResultat = min($decalage + $parPage, $totalFactures);
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$statuts = ['envoye' => ['Envoyée', 'vert'], 'en_attente' => ['En attente', 'amber'], 'echec' => ['Échec', 'rouge']];
$types = ['intervention' => 'Intervention', 'abonnement' => 'Abonnement', 'pass' => 'Pass'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Factures — ALLÔ PRO Finance</title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/finance-factures.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-factures.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu finance-factures">
        <header class="factures-entete">
            <div>
                <span class="factures-entete__eyebrow">Gestion documentaire</span>
                <h1 class="admin-entete__titre">Factures</h1>
                <p class="admin-entete__sous-titre">Consultez les factures émises, leur montant et le statut de leur envoi.</p>
            </div>
            <a class="factures-entete__action" href="historique-financier.php">Historique financier <span aria-hidden="true">→</span></a>
        </header>

        <section class="factures-resume" aria-label="Résumé des factures">
            <article class="facture-stat">
                <span class="facture-stat__label">Factures émises</span>
                <strong><?= number_format($statistiques['nombre'], 0, ',', ' ') ?></strong>
                <span class="facture-stat__note">Sur l’ensemble de la période</span>
            </article>
            <article class="facture-stat facture-stat--montant">
                <span class="facture-stat__label">Montant total facturé</span>
                <strong><?= number_format($statistiques['montant_total'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <span class="facture-stat__note">Toutes les factures émises</span>
            </article>
            <article class="facture-stat facture-stat--envoyees">
                <span class="facture-stat__label">Envoyées par e-mail</span>
                <strong><?= number_format($statistiques['envoyees'], 0, ',', ' ') ?></strong>
                <span class="facture-stat__note">Envoi confirmé</span>
            </article>
            <article class="facture-stat facture-stat--attention">
                <span class="facture-stat__label">À vérifier</span>
                <strong><?= number_format($statistiques['echecs'] + $statistiques['en_attente'], 0, ',', ' ') ?></strong>
                <span class="facture-stat__note"><?= number_format($statistiques['echecs'], 0, ',', ' ') ?> échec<?= $statistiques['echecs'] === 1 ? '' : 's' ?> · <?= number_format($statistiques['en_attente'], 0, ',', ' ') ?> en attente</span>
            </article>
        </section>

        <section class="factures-panel" aria-label="Liste des factures">
            <header class="factures-panel__entete">
                <div>
                    <h2>Registre des factures</h2>
                    <p><?= number_format($totalFactures, 0, ',', ' ') ?> résultat<?= $totalFactures === 1 ? '' : 's' ?><?= $filtres ? ' pour les filtres sélectionnés' : '' ?></p>
                </div>
                <span class="factures-panel__compte"><?= number_format($premierResultat, 0, ',', ' ') ?>–<?= number_format($dernierResultat, 0, ',', ' ') ?> / <?= number_format($totalFactures, 0, ',', ' ') ?></span>
            </header>

            <form class="factures-filtres" method="get" role="search">
                <label class="factures-filtres__recherche">
                    <span>Rechercher</span>
                    <input type="search" name="recherche" value="<?= $echapper($recherche) ?>" maxlength="100" placeholder="Numéro, client, e-mail ou libellé">
                </label>
                <label>
                    <span>Statut d’envoi</span>
                    <select name="statut">
                        <option value="">Tous les statuts</option>
                        <?php foreach ($statuts as $valeur => [$libelle]): ?>
                            <option value="<?= $echapper($valeur) ?>" <?= $statutFiltre === $valeur ? 'selected' : '' ?>><?= $echapper($libelle) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>
                    <span>Type de facture</span>
                    <select name="type">
                        <option value="">Tous les types</option>
                        <?php foreach ($types as $valeur => $libelle): ?>
                            <option value="<?= $echapper($valeur) ?>" <?= $typeFiltre === $valeur ? 'selected' : '' ?>><?= $echapper($libelle) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="submit">Filtrer</button>
                <?php if ($filtres): ?><a class="factures-filtres__reset" href="factures.php">Effacer</a><?php endif; ?>
            </form>

            <div class="factures-table-wrapper" role="region" aria-label="Factures émises, défilement horizontal possible" tabindex="0">
                <table class="admin-table factures-table">
                    <thead>
                    <tr><th>Facture</th><th>Client</th><th>Type &amp; détail</th><th>Montant</th><th>Envoi e-mail</th><th>Émise le</th></tr>
                    </thead>
                    <tbody>
                    <?php if (!$factures): ?>
                        <tr><td colspan="6" class="factures-vide">
                            <strong><?= $filtres ? 'Aucune facture correspondante' : 'Aucune facture pour le moment' ?></strong>
                            <span><?= $filtres ? 'Essayez d’élargir votre recherche ou de modifier les filtres.' : 'Les factures archivées apparaîtront ici après émission.' ?></span>
                        </td></tr>
                    <?php endif; ?>
                    <?php foreach ($factures as $facture):
                        $statut = $statuts[$facture['email_statut']] ?? [$facture['email_statut'], 'gris'];
                        $type = $types[$facture['type_operation']] ?? ucfirst((string) $facture['type_operation']);
                        $client = trim((string) $facture['client_prenom'] . ' ' . (string) $facture['client_nom']);
                        $numero = $facture['numero'] ?: 'Facture #' . (int) $facture['id'];
                    ?>
                        <tr class="factures-table__ligne" data-href="detail-facture.php?id=<?= (int) $facture['id'] ?>" tabindex="0" aria-label="Ouvrir la facture <?= $echapper($numero) ?>">
                            <td>
                                <a class="factures-table__numero" href="detail-facture.php?id=<?= (int) $facture['id'] ?>"><?= $echapper($numero) ?></a>
                                <small class="factures-table__reference"><?= $echapper($facture['email_destinataire']) ?></small>
                            </td>
                            <td><strong><?= $echapper($client !== '' ? $client : 'Client') ?></strong></td>
                            <td><span class="factures-type"><?= $echapper($type) ?></span><span class="factures-table__libelle"><?= $echapper($facture['libelle']) ?></span></td>
                            <td class="factures-table__montant"><?= number_format((float) $facture['montant'], 0, ',', ' ') ?><small><?= $echapper($facture['devise']) ?></small></td>
                            <td><span class="admin-badge admin-badge--<?= $echapper($statut[1]) ?>"><?= $echapper($statut[0]) ?></span></td>
                            <td><?= $echapper(date('d/m/Y', strtotime($facture['date_emission']))) ?><small class="factures-table__heure"><?= $echapper(date('H:i', strtotime($facture['date_emission']))) ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($nombrePages > 1): ?>
                <nav class="factures-pagination" aria-label="Pagination des factures">
                    <span>Page <?= $page ?> sur <?= $nombrePages ?></span>
                    <div>
                        <?php if ($page > 1): ?><a href="<?= $echapper($urlPage($page - 1)) ?>">← Précédente</a><?php endif; ?>
                        <?php if ($page < $nombrePages): ?><a href="<?= $echapper($urlPage($page + 1)) ?>">Suivante →</a><?php endif; ?>
                    </div>
                </nav>
            <?php endif; ?>
        </section>
    </main>
</div>
<script src="../../public/js/finance-factures.js?v=<?= filemtime(__DIR__ . '/../../public/js/finance-factures.js') ?>" defer></script>
</body>
</html>
