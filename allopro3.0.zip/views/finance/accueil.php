<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('paiements');
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/Reversement.php';
require_once __DIR__ . '/../../models/LivreComptes.php';

$paiementModel = new Paiement();
$reversementModel = new Reversement();
$statuts = $paiementModel->sommeParStatut();
$livre = new LivreComptes();
$synthese = $livre->getSynthesePartenaires();
$revenusMois = array_sum(array_map(
    static fn(array $ecriture): float => (float) $ecriture['montant_credit'],
    $livre->getEcritures(date('Y-m-01'), date('Y-m-d'), 'revenus')
));
$margeMois = $reversementModel->margeMoisEnCours();
$paiementsRecents = $paiementModel->getHistoriqueAvecFiltres(null, null, 6, 0);
$paiementsParMethode = $paiementModel->sommeParMethode();
$reversementsDus = $reversementModel->getReversementsDus();
$totalReversementsDus = array_sum(array_map(
    static fn(array $reversement): float => (float) $reversement['montant_du'],
    $reversementsDus
));
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$libellesMethodes = ['wave' => 'Wave', 'orange_money' => 'Orange Money', 'especes' => 'Espèces'];
$dateDuJour = new DateTimeImmutable('now');
$moisFrancais = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
$moisCourant = $moisFrancais[(int) $dateDuJour->format('n')] . ' ' . $dateDuJour->format('Y');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tableau de bord Finance — ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/finance-dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-dashboard.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu finance-dashboard">
        <header class="finance-hero">
            <div>
                <span class="finance-hero__eyebrow"><?= $echapper($dateDuJour->format('d')) ?> <?= $echapper($moisFrancais[(int) $dateDuJour->format('n')]) ?> <?= $echapper($dateDuJour->format('Y')) ?></span>
                <h1>Vue d’ensemble financière</h1>
                <p>Suivez vos encaissements, marges et paiements partenaires depuis un seul endroit.</p>
            </div>
            <a class="finance-hero__action" href="export-donnees.php"><?= icone('file-text', 17) ?> Exporter les données</a>
        </header>

        <div class="finance-dashboard__section-heading">
            <div><h2>Indicateurs clés</h2><p>Résumé de votre activité · <?= $echapper(ucfirst($moisCourant)) ?></p></div>
            <a href="reporting.php">Voir le reporting <span aria-hidden="true">→</span></a>
        </div>
        <section class="finance-kpis" aria-label="Indicateurs financiers">
            <article class="finance-kpi finance-kpi--revenue">
                <span class="finance-kpi__icon" aria-hidden="true"><?= icone('chart', 19) ?></span>
                <span class="finance-kpi__label">Revenus encaissés</span>
                <strong class="finance-kpi__value"><?= number_format($revenusMois, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <span class="finance-kpi__note">Depuis le début du mois</span>
            </article>
            <article class="finance-kpi finance-kpi--commission">
                <span class="finance-kpi__icon" aria-hidden="true"><?= icone('wallet', 19) ?></span>
                <span class="finance-kpi__label">Commissions calculées</span>
                <strong class="finance-kpi__value"><?= number_format((float) $synthese['commissions_calculees'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <a class="finance-kpi__link" href="commissions.php">Détails des commissions <span aria-hidden="true">→</span></a>
            </article>
            <article class="finance-kpi finance-kpi--margin">
                <span class="finance-kpi__icon" aria-hidden="true"><?= icone('receipt', 19) ?></span>
                <span class="finance-kpi__label">Marge du mois</span>
                <strong class="finance-kpi__value"><?= number_format((float) $margeMois, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <a class="finance-kpi__link" href="marges.php">Consulter les marges <span aria-hidden="true">→</span></a>
            </article>
            <a class="finance-kpi finance-kpi--payable" href="paiements-a-effectuer.php">
                <span class="finance-kpi__icon" aria-hidden="true"><?= icone('card', 19) ?></span>
                <span class="finance-kpi__label">À reverser aux partenaires</span>
                <strong class="finance-kpi__value"><?= number_format((float) $synthese['a_reverser'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <span class="finance-kpi__link">Voir les paiements à effectuer <span aria-hidden="true">→</span></span>
            </a>
            <a class="finance-kpi finance-kpi--failed" href="paiements-echoues.php">
                <span class="finance-kpi__icon" aria-hidden="true"><?= icone('alert', 19) ?></span>
                <span class="finance-kpi__label">Paiements échoués</span>
                <strong class="finance-kpi__value"><?= number_format((int) $statuts['echoue']['nb'], 0, ',', ' ') ?></strong>
                <span class="finance-kpi__note"><?= number_format((float) $statuts['echoue']['total'], 0, ',', ' ') ?> F&nbsp;CFA concernés · traiter <span aria-hidden="true">→</span></span>
            </a>
        </section>

        <div class="finance-dashboard__section-heading finance-dashboard__section-heading--actions">
            <div><h2>Raccourcis</h2><p>Accédez rapidement aux opérations courantes.</p></div>
        </div>
        <nav class="finance-actions" aria-label="Raccourcis Finance">
            <a href="paiements-clients.php" class="finance-action">
                <span class="finance-action__icon finance-action__icon--purple"><?= icone('card', 19) ?></span>
                <span><strong>Paiements clients</strong><small>Consulter les encaissements</small></span>
                <span class="finance-action__arrow" aria-hidden="true">→</span>
            </a>
            <a href="paiements-a-effectuer.php" class="finance-action">
                <span class="finance-action__icon finance-action__icon--orange"><?= icone('refresh', 19) ?></span>
                <span><strong>Paiements à effectuer</strong><small><?= count($reversementsDus) ?> partenaire<?= count($reversementsDus) === 1 ? '' : 's' ?> · <?= number_format($totalReversementsDus, 0, ',', ' ') ?> F&nbsp;CFA</small></span>
                <span class="finance-action__arrow" aria-hidden="true">→</span>
            </a>
            <a href="factures.php" class="finance-action">
                <span class="finance-action__icon finance-action__icon--blue"><?= icone('file-text', 19) ?></span>
                <span><strong>Factures</strong><small>Consulter les factures émises</small></span>
                <span class="finance-action__arrow" aria-hidden="true">→</span>
            </a>
        </nav>

        <section class="finance-dashboard__lower">
            <article class="finance-panel finance-panel--transactions">
                <header class="finance-panel__header">
                    <div><h2>Dernières transactions</h2><p>Activité récente sur les paiements clients</p></div>
                    <a href="historique-paiements.php">Tout voir <span aria-hidden="true">→</span></a>
                </header>
                <?php if (!$paiementsRecents): ?>
                    <p class="finance-empty">Aucune transaction récente.</p>
                <?php else: ?>
                    <div class="finance-transactions">
                        <?php foreach ($paiementsRecents as $paiement):
                            $statutPaiement = [
                                'valide' => ['Validé', 'success'],
                                'en_attente' => ['En attente', 'pending'],
                                'echoue' => ['Échoué', 'failed'],
                            ][$paiement['statut']] ?? [$paiement['statut'], 'pending'];
                        ?>
                            <div class="finance-transaction">
                                <span class="finance-transaction__icon"><?= icone('card', 17) ?></span>
                                <span class="finance-transaction__details">
                                    <strong><?= $echapper($paiement['client_nom'] ?? '') ?: 'Client' ?></strong>
                                    <small><?= $echapper($paiement['numero_dossier'] ?? '—') ?> · <?= $echapper($libellesMethodes[$paiement['methode']] ?? (trim((string) $paiement['methode']) !== '' ? ucfirst(str_replace('_', ' ', (string) $paiement['methode'])) : 'Autre méthode')) ?> · <?= $echapper(date('d/m/Y', strtotime($paiement['date_paiement']))) ?></small>
                                </span>
                                <span class="finance-transaction__amount"><?= number_format((float) $paiement['montant'], 0, ',', ' ') ?> F</span>
                                <span class="finance-status finance-status--<?= $echapper($statutPaiement[1]) ?>"><?= $echapper($statutPaiement[0]) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </article>

            <aside class="finance-panel finance-panel--methods">
                <header class="finance-panel__header">
                    <div><h2>Modes d’encaissement</h2><p>Total des paiements validés</p></div>
                </header>
                <?php
                $totalParMethode = array_sum(array_map(static fn(array $ligne): float => (float) $ligne['total'], $paiementsParMethode));
                $couleursMethodes = ['wave' => 'wave', 'orange_money' => 'orange', 'especes' => 'cash'];
                ?>
                <?php if (!$paiementsParMethode): ?>
                    <p class="finance-empty">Aucun encaissement validé.</p>
                <?php else: ?>
                    <div class="finance-methods">
                        <?php foreach ($paiementsParMethode as $methode):
                            $part = $totalParMethode > 0 ? (float) $methode['total'] / $totalParMethode * 100 : 0;
                            $cleMethode = (string) $methode['methode'];
                        ?>
                            <div class="finance-method">
                                <div class="finance-method__meta">
                                    <span><?= $echapper($libellesMethodes[$cleMethode] ?? (trim($cleMethode) !== '' ? ucfirst(str_replace('_', ' ', $cleMethode)) : 'Autre méthode')) ?></span>
                                    <strong><?= number_format((float) $methode['total'], 0, ',', ' ') ?> F</strong>
                                </div>
                                <div class="finance-method__track" role="img" aria-label="<?= $echapper(number_format($part, 1, ',', ' ')) ?> %">
                                    <span class="finance-method__bar finance-method__bar--<?= $echapper($couleursMethodes[$cleMethode] ?? 'other') ?>" style="width: <?= $echapper(number_format($part, 2, '.', '')) ?>%"></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <footer class="finance-methods__total"><span>Total encaissé</span><strong><?= number_format($totalParMethode, 0, ',', ' ') ?> F&nbsp;CFA</strong></footer>
                <?php endif; ?>
            </aside>
        </section>
    </main>
</div>
</body>
</html>
