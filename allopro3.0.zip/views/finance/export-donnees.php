<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['finance']);
require_once __DIR__ . '/../../includes/permissions.php';
verifierAcces('paiements');
verifierAcces('reversements');
require_once __DIR__ . '/../../models/LivreComptes.php';

$aujourdhui = date('Y-m-d');
$debutParDefaut = date('Y-m-01');
$normaliserDate = static function ($valeur, string $defaut): string {
    if (!is_string($valeur) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $valeur)) {
        return $defaut;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $valeur);
    return $date && $date->format('Y-m-d') === $valeur ? $valeur : $defaut;
};
$debut = $normaliserDate($_GET['debut'] ?? $debutParDefaut, $debutParDefaut);
$fin = $normaliserDate($_GET['fin'] ?? $aujourdhui, $aujourdhui);
$categorie = is_string($_GET['categorie'] ?? null) ? $_GET['categorie'] : 'toutes';
$categories = ['toutes', 'revenus', 'paiement', 'pass', 'abonnement', 'reversement'];
if (!in_array($categorie, $categories, true)) {
    $categorie = 'toutes';
}
if ($debut > $fin) {
    http_response_code(400);
    exit('La date de début doit précéder ou égaler la date de fin.');
}

$livreComptes = new LivreComptes();
if (($_GET['telecharger'] ?? '') === 'csv') {
    $ecritures = $livreComptes->getEcritures($debut, $fin, $categorie);
    $nettoyerCsv = static function ($valeur): string {
        $texte = (string) $valeur;
        return preg_match('/^[\s]*[=+\-@]/u', $texte) ? "'" . $texte : $texte;
    };
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="historique-financier-' . $debut . '-' . $fin . '.csv"');
    $sortie = fopen('php://output', 'wb');
    if ($sortie === false) {
        throw new RuntimeException('Impossible de créer le fichier CSV.');
    }
    fwrite($sortie, "\xEF\xBB\xBF");
    fputcsv($sortie, ['Date', 'Catégorie', 'Libellé', 'Tiers', 'Référence', 'Crédit (F CFA)', 'Débit (F CFA)'], ';');
    foreach ($ecritures as $ecriture) {
        fputcsv($sortie, [
            $nettoyerCsv($ecriture['date_operation']),
            $nettoyerCsv($ecriture['categorie']),
            $nettoyerCsv($ecriture['libelle']),
            $nettoyerCsv($ecriture['tiers']),
            $nettoyerCsv($ecriture['reference']),
            number_format((float) $ecriture['montant_credit'], 2, ',', ''),
            number_format((float) $ecriture['montant_debit'], 2, ',', ''),
        ], ';');
    }
    fclose($sortie);
    exit;
}

$ecritures = $livreComptes->getEcritures($debut, $fin, $categorie);
$nombreEcritures = count($ecritures);
$totalCredits = array_sum(array_map(static fn(array $ligne): float => (float) $ligne['montant_credit'], $ecritures));
$totalDebits = array_sum(array_map(static fn(array $ligne): float => (float) $ligne['montant_debit'], $ecritures));
$ecrituresApercu = array_slice(array_reverse($ecritures), 0, 8);
$libellesCategories = [
    'toutes' => 'Toutes les opérations',
    'revenus' => 'Tous les revenus',
    'paiement' => 'Paiements de services',
    'pass' => 'Pass',
    'abonnement' => 'Abonnements',
    'reversement' => 'Reversements partenaires',
];
$urlCsv = '?' . http_build_query([
    'debut' => $debut,
    'fin' => $fin,
    'categorie' => $categorie,
    'telecharger' => 'csv',
]);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Export des données — ALLÔ PRO Finance</title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/finance-export.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-export.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu finance-export">
        <header class="finance-export__hero">
            <span class="finance-export__eyebrow">Données financières</span>
            <h1>Export des données</h1>
            <p>Filtrez, vérifiez et téléchargez les écritures du journal financier au format CSV.</p>
        </header>
        <form class="finance-export__filtres" method="get" aria-label="Critères de l’export financier">
            <div class="finance-export__filtres-entete">
                <div>
                    <h2>Personnaliser l’export</h2>
                    <p>Choisissez la période et les opérations à inclure.</p>
                </div>
                <span class="finance-export__format">CSV · Excel compatible</span>
            </div>
            <div class="finance-export__champs">
                <label>Du
                    <input type="date" name="debut" value="<?= htmlspecialchars($debut, ENT_QUOTES, 'UTF-8') ?>" required>
                </label>
                <label>Au
                    <input type="date" name="fin" value="<?= htmlspecialchars($fin, ENT_QUOTES, 'UTF-8') ?>" required>
                </label>
                <label class="finance-export__categorie">Type d’opération
                <select name="categorie">
                    <?php foreach ($libellesCategories as $valeur => $libelle): ?>
                        <option value="<?= htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8') ?>" <?= $categorie === $valeur ? 'selected' : '' ?>><?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?></option>
                    <?php endforeach; ?>
                </select>
                </label>
                <button class="finance-export__appliquer" type="submit">Afficher l’aperçu</button>
            </div>
        </form>
        <section class="finance-export__indicateurs" aria-label="Résumé de l’export">
            <article class="finance-export__indicateur finance-export__indicateur--ecritures">
                <span>Écritures correspondantes</span>
                <strong><?= number_format($nombreEcritures, 0, ',', ' ') ?></strong>
                <p><?= htmlspecialchars($libellesCategories[$categorie], ENT_QUOTES, 'UTF-8') ?></p>
            </article>
            <article class="finance-export__indicateur finance-export__indicateur--credits">
                <span>Total des crédits</span>
                <strong><?= number_format($totalCredits, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p>Montants entrants sur la période</p>
            </article>
            <article class="finance-export__indicateur finance-export__indicateur--debits">
                <span>Total des débits</span>
                <strong><?= number_format($totalDebits, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                <p>Reversements comptabilisés</p>
            </article>
        </section>
        <section class="finance-export__apercu" aria-label="Aperçu des écritures exportées">
            <header class="finance-export__apercu-entete">
                <div>
                    <h2>Aperçu des données</h2>
                    <p><?= $nombreEcritures === 0 ? 'Aucune écriture pour ces critères.' : 'Les ' . number_format(count($ecrituresApercu), 0, ',', ' ') . ' écritures les plus récentes sur ' . number_format($nombreEcritures, 0, ',', ' ') . ' seront représentées ci-dessous.' ?></p>
                </div>
                <a class="finance-export__telecharger" href="<?= htmlspecialchars($urlCsv, ENT_QUOTES, 'UTF-8') ?>">
                    <span aria-hidden="true">↓</span> Télécharger le CSV
                </a>
            </header>
            <?php if ($ecrituresApercu): ?>
                <div class="admin-table-wrapper" tabindex="0" role="region" aria-label="Aperçu des écritures financières">
                    <table class="admin-table finance-export__table">
                        <thead>
                            <tr><th>Date</th><th>Catégorie</th><th>Libellé</th><th>Tiers</th><th>Référence</th><th>Crédit</th><th>Débit</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($ecrituresApercu as $ecriture): ?>
                            <tr>
                                <td><?= htmlspecialchars(date('d/m/Y', strtotime($ecriture['date_operation'])), ENT_QUOTES, 'UTF-8') ?></td>
                                <td><span class="finance-export__badge"><?= htmlspecialchars(ucfirst($ecriture['categorie']), ENT_QUOTES, 'UTF-8') ?></span></td>
                                <td><?= htmlspecialchars($ecriture['libelle'], ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars($ecriture['tiers'], ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars($ecriture['reference'] ?? '—', ENT_QUOTES, 'UTF-8') ?></td>
                                <td class="finance-export__montant"><?= number_format((float) $ecriture['montant_credit'], 0, ',', ' ') ?></td>
                                <td class="finance-export__montant"><?= number_format((float) $ecriture['montant_debit'], 0, ',', ' ') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="finance-export__vide">
                    <span aria-hidden="true">⌕</span>
                    <strong>Aucune donnée à exporter</strong>
                    <p>Essayez une autre période ou un autre type d’opération.</p>
                </div>
            <?php endif; ?>
            <p class="finance-export__securite">Les champs texte du CSV sont neutralisés pour éviter l’exécution de formules dans un tableur. Les montants sont exportés avec deux décimales.</p>
        </section>
    </main>
</div>
</body>
</html>
