<?php
require __DIR__ . '/paiements.php';
