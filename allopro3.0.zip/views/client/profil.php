<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../includes/icones.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/EntrepriseB2B.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/email-verification.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$userModel = new User();
$userId = (int) $_SESSION['user_id'];
$moi = $userModel->getById($userId);
$entreprisesClient = (new EntrepriseB2B())->getEntreprisesParMembre($userId);
if (!$moi || ($moi['role'] ?? '') !== 'client') {
    http_response_code(404);
    exit('Compte introuvable.');
}

if (empty($_SESSION['csrf_profil'])) {
    $_SESSION['csrf_profil'] = bin2hex(random_bytes(32));
}

$erreur = '';
$succes = '';
$prenomSaisi = (string) ($moi['prenom'] ?? '');
$nomSaisi = (string) ($moi['nom'] ?? '');
$emailSaisi = (string) ($moi['email'] ?? '');
$telephoneSaisi = (string) ($moi['telephone'] ?? '');

if (($_GET['succes'] ?? '') === 'infos') {
    $succes = 'Vos informations personnelles ont été mises à jour.';
} elseif (($_GET['succes'] ?? '') === 'verification') {
    $succes = 'Vos informations ont été enregistrées. Un code de vérification a été envoyé à votre nouvelle adresse e-mail.';
} elseif (($_GET['succes'] ?? '') === 'verification_echec') {
    $succes = 'Vos informations ont été enregistrées, mais le code de vérification n’a pas pu être envoyé. Vous pourrez le redemander depuis la page de vérification.';
} elseif (($_GET['succes'] ?? '') === 'mdp') {
    $succes = 'Votre mot de passe a été modifié.';
}
if (!empty($_SESSION['flash_profil_avatar'])) {
    $succes = (string) $_SESSION['flash_profil_avatar'];
    unset($_SESSION['flash_profil_avatar']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_profil'], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page et réessayez.';
    } elseif (in_array($_POST['action'] ?? '', ['photo_profil', 'supprimer_photo', 'avatar_initiales'], true)) {
        $actionAvatar = (string) $_POST['action'];
        try {
            if ($actionAvatar === 'photo_profil') {
                $nouveauChemin = AvatarProfil::stocker($_FILES['photo_profil'] ?? [], 'clients');
                if (!$userModel->mettreAJourPhotoProfilClient($userId, $nouveauChemin)) {
                    AvatarProfil::supprimer($nouveauChemin);
                    throw new RuntimeException('La photo n’a pas pu être associée au compte.');
                }
                AvatarProfil::supprimer($moi['photo_profil'] ?? null);
                $_SESSION['photo_profil'] = $nouveauChemin;
                $_SESSION['flash_profil_avatar'] = 'Votre photo de profil a été mise à jour.';
            } elseif ($actionAvatar === 'supprimer_photo') {
                if (!$userModel->supprimerPhotoProfilClient($userId)) {
                    throw new RuntimeException('La photo n’a pas pu être supprimée.');
                }
                AvatarProfil::supprimer($moi['photo_profil'] ?? null);
                $_SESSION['photo_profil'] = null;
                $_SESSION['flash_profil_avatar'] = 'Votre photo a été supprimée.';
            } else {
                $afficherInitiales = ($_POST['avatar_initiales'] ?? '') === '1';
                if (!$userModel->definirAvatarInitialesClient($userId, $afficherInitiales)) {
                    throw new RuntimeException('La préférence d’affichage n’a pas pu être enregistrée.');
                }
                $_SESSION['avatar_initiales'] = $afficherInitiales;
                $_SESSION['flash_profil_avatar'] = $afficherInitiales
                    ? 'Les initiales seront affichées à la place de la photo.'
                    : 'La photo de profil sera affichée lorsqu’elle est disponible.';
            }
            header('Location: profil.php');
            exit;
        } catch (RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Mise à jour avatar client ' . $userId . ' : ' . $exception->getMessage());
            if (isset($nouveauChemin)) AvatarProfil::supprimer($nouveauChemin);
            $erreur = 'La photo de profil n’a pas pu être enregistrée. Réessayez.';
        }
    } elseif (($_POST['action'] ?? '') === 'maj_infos') {
        $prenomSaisi = trim(is_string($_POST['prenom'] ?? null) ? $_POST['prenom'] : '');
        $nomSaisi = trim(is_string($_POST['nom'] ?? null) ? $_POST['nom'] : '');
        $emailSaisi = trim(is_string($_POST['email'] ?? null) ? $_POST['email'] : '');
        $telephoneSaisi = trim(is_string($_POST['telephone'] ?? null) ? $_POST['telephone'] : '');

        if ($prenomSaisi === '' || $nomSaisi === '' || $emailSaisi === '') {
            $erreur = 'Le prénom, le nom et l’adresse email sont obligatoires.';
        } elseif (mb_strlen($prenomSaisi) > 100 || mb_strlen($nomSaisi) > 100) {
            $erreur = 'Le prénom et le nom ne doivent pas dépasser 100 caractères.';
        } elseif (mb_strlen($emailSaisi) > 150 || !filter_var($emailSaisi, FILTER_VALIDATE_EMAIL)) {
            $erreur = 'Saisissez une adresse email valide (150 caractères maximum).';
        } elseif (mb_strlen($telephoneSaisi) > 20) {
            $erreur = 'Le numéro de téléphone ne doit pas dépasser 20 caractères.';
        } elseif ($userModel->emailUtiliseParAutreCompteClient($emailSaisi, $userId)) {
            $erreur = 'Cette adresse email est déjà utilisée par un autre compte.';
        } else {
            $telephone = $telephoneSaisi !== '' ? $telephoneSaisi : null;
            $emailModifie = strcasecmp((string) $moi['email'], $emailSaisi) !== 0;
            try {
                if (!$userModel->mettreAJourProfilClient($userId, $prenomSaisi, $nomSaisi, $emailSaisi, $telephone)) {
                    throw new RuntimeException('La mise à jour du profil a échoué.');
                }
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') {
                    $erreur = 'Cette adresse email est déjà utilisée par un autre compte.';
                } else {
                    throw $e;
                }
            }

            if ($erreur === '') {
                $_SESSION['prenom'] = $prenomSaisi;
                $_SESSION['nom_famille'] = $nomSaisi;
                $_SESSION['nom'] = nomComplet($prenomSaisi, $nomSaisi);
                if ($emailModifie) {
                    try {
                        $codeEnvoye = envoyerCodeVerificationEmail(
                            $userModel,
                            $userId,
                            $emailSaisi,
                            nomComplet($prenomSaisi, $nomSaisi),
                            'client'
                        );
                        $_SESSION['verification_email_type'] = 'client';
                        $_SESSION['verification_email_adresse'] = $emailSaisi;
                        $_SESSION['verification_email_notice'] = $codeEnvoye ? 'modifiee' : 'echec';
                    } catch (RuntimeException $e) {
                        error_log('Échec de l’envoi du code après modification de l’adresse client : ' . $e->getMessage());
                        $_SESSION['verification_email_type'] = 'client';
                        $_SESSION['verification_email_adresse'] = $emailSaisi;
                        $_SESSION['verification_email_notice'] = 'echec';
                    }
                    header('Location: ../../public/verification-email.php');
                } else {
                    header('Location: profil.php?succes=infos');
                }
                exit;
            }
        }
    } elseif (($_POST['action'] ?? '') === 'changer_mdp') {
        $actuel = is_string($_POST['mdp_actuel'] ?? null) ? $_POST['mdp_actuel'] : '';
        $nouveau = is_string($_POST['mdp_nouveau'] ?? null) ? $_POST['mdp_nouveau'] : '';
        $confirmation = is_string($_POST['mdp_confirmation'] ?? null) ? $_POST['mdp_confirmation'] : '';

        if (!$userModel->verifierMotDePasseClient($userId, $actuel)) {
            $erreur = 'Le mot de passe actuel est incorrect.';
        } elseif (strlen($nouveau) < 8) {
            $erreur = 'Le nouveau mot de passe doit contenir au moins 8 caractères.';
        } elseif ($nouveau !== $confirmation) {
            $erreur = 'Les deux nouveaux mots de passe ne correspondent pas.';
        } elseif ($nouveau === $actuel) {
            $erreur = 'Choisissez un mot de passe différent de votre mot de passe actuel.';
        } elseif (!$userModel->changerMotDePasseClient($userId, $nouveau)) {
            throw new RuntimeException('La mise à jour du mot de passe a échoué.');
        } else {
            header('Location: profil.php?succes=mdp');
            exit;
        }
    } else {
        $erreur = 'La demande n’a pas pu être traitée. Rechargez la page et réessayez.';
    }
}

$nomComplet = nomComplet($moi['prenom'] ?? '', $moi['nom'] ?? '');
$initiales = mb_strtoupper(
    mb_substr((string) ($moi['prenom'] ?? ''), 0, 1)
    . mb_substr((string) ($moi['nom'] ?? ''), 0, 1)
);
$dateInscription = !empty($moi['date_creation'])
    ? date('d/m/Y', strtotime($moi['date_creation']))
    : null;
$motDePasseDefini = !empty($moi['mot_de_passe']) && empty($moi['mdp_a_definir']);
$photoProfil = AvatarProfil::estValide($moi['photo_profil'] ?? null, 'clients')
    ? (string) $moi['photo_profil']
    : null;
$avatarInitiales = !empty($moi['avatar_initiales']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mon profil — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/profil-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/profil-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/avatar-profil.css?v=<?= filemtime(__DIR__ . '/../../public/css/avatar-profil.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client profil-client">
    <header class="profil-entete">
        <div>
            <p class="profil-entete__sur-titre">MON ESPACE</p>
            <h1>Mon profil</h1>
            <p class="profil-entete__description">Retrouvez vos informations et gérez la sécurité de votre compte.</p>
        </div>
        <a class="profil-entete__adresses" href="ajouter-adresse.php">
            <?= icone('pin', 18) ?>
            Gérer mes adresses
        </a>
    </header>

    <?php if ($succes !== ''): ?>
        <div class="profil-alerte profil-alerte--succes" role="status">
            <span class="profil-alerte__icone" aria-hidden="true"><?= icone('check', 12) ?></span>
            <?= htmlspecialchars($succes, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>
    <?php if ($erreur !== ''): ?>
        <div class="profil-alerte profil-alerte--erreur" role="alert">
        <span class="profil-alerte__icone" aria-hidden="true"><?= icone('alert', 12) ?></span>
            <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>
    <?php if (($_GET['succes'] ?? '') === 'verification_echec'): ?>
        <a class="profil-verification-renvoi" href="../../public/verification-email.php?type=client&amp;email=<?= rawurlencode((string) $moi['email']) ?>">Renvoyer un code de vérification</a>
    <?php endif; ?>

    <section class="profil-hero" aria-label="Résumé du compte">
        <div class="profil-avatar" aria-hidden="true">
            <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                <img src="../../public/<?= htmlspecialchars($photoProfil, ENT_QUOTES, 'UTF-8') ?>" alt="">
            <?php elseif ($avatarInitiales): ?>
                <?= htmlspecialchars($initiales, ENT_QUOTES, 'UTF-8') ?>
            <?php else: ?>
                <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
            <?php endif; ?>
        </div>
        <div class="profil-hero__identite">
            <h2><?= htmlspecialchars($nomComplet !== '' ? $nomComplet : 'Mon compte', ENT_QUOTES, 'UTF-8') ?></h2>
            <p><?= htmlspecialchars((string) $moi['email'], ENT_QUOTES, 'UTF-8') ?></p>
        </div>
        <div class="profil-hero__details">
            <span class="profil-statut"><span aria-hidden="true"></span> Compte actif</span>
            <?php if ($dateInscription !== null): ?>
                <span class="profil-inscription">Membre depuis le <?= htmlspecialchars($dateInscription, ENT_QUOTES, 'UTF-8') ?></span>
            <?php endif; ?>
        </div>
    </section>

    <div class="profil-grille">
        <section class="profil-carte" id="profil-parametres" aria-labelledby="profil-infos-titre">
            <section class="avatar-profil" aria-labelledby="avatar-client-titre">
                <div class="avatar-profil__entete">
                    <div>
                        <h2 id="avatar-client-titre">Photo de profil</h2>
                        <p>JPG, PNG ou WebP · 5 Mo maximum</p>
                    </div>
                    <div class="avatar-profil__apercu" aria-hidden="true">
                        <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                            <img src="../../public/<?= htmlspecialchars($photoProfil, ENT_QUOTES, 'UTF-8') ?>" alt="">
                        <?php elseif ($avatarInitiales): ?>
                            <?= htmlspecialchars($initiales, ENT_QUOTES, 'UTF-8') ?>
                        <?php else: ?>
                            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                        <?php endif; ?>
                    </div>
                </div>
                <form method="POST" enctype="multipart/form-data" class="avatar-profil__formulaire">
                    <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_profil'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="action" value="photo_profil">
                    <input type="hidden" name="MAX_FILE_SIZE" value="5242880">
                    <input class="avatar-profil__input-fichier" id="photo-profil-client" type="file" name="photo_profil" accept="image/jpeg,image/png,image/webp" aria-label="Choisir une photo de profil" aria-describedby="photo-profil-client-message" required>
                    <label class="avatar-profil__fichier" for="photo-profil-client">Choisir une photo</label>
                    <span id="photo-profil-client-message" class="avatar-profil__message" role="status" aria-live="polite"></span>
                    <button type="submit" class="avatar-profil__bouton">Enregistrer la photo</button>
                </form>
                <?php if ($photoProfil !== null): ?>
                    <form method="POST" class="avatar-profil__action">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_profil'], ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="action" value="supprimer_photo">
                        <button type="submit" class="avatar-profil__lien">Supprimer la photo</button>
                    </form>
                <?php endif; ?>
                <form method="POST" class="avatar-profil__bascule">
                    <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_profil'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="action" value="avatar_initiales">
                    <input type="hidden" name="avatar_initiales" value="0">
                    <label for="avatar-initiales-client">Afficher mes initiales à la place de la photo</label>
                    <input id="avatar-initiales-client" type="checkbox" name="avatar_initiales" value="1" <?= $avatarInitiales ? 'checked' : '' ?> onchange="this.form.querySelector('input[type=hidden][name=avatar_initiales]').disabled = this.checked; this.form.submit()">
                </form>
            </section>
            <div class="profil-carte__entete">
                <div class="profil-carte__icone profil-carte__icone--infos" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                </div>
                <div>
                    <h2 id="profil-infos-titre">Informations personnelles</h2>
                    <p>Gardez vos coordonnées à jour pour être joignable.</p>
                </div>
            </div>

            <form method="POST" class="profil-formulaire">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_profil'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="action" value="maj_infos">
                <div class="profil-formulaire__rangee">
                    <div class="profil-champ">
                        <label for="prenom">Prénom</label>
                        <input type="text" id="prenom" name="prenom" value="<?= htmlspecialchars($prenomSaisi, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" autocomplete="given-name" required>
                    </div>
                    <div class="profil-champ">
                        <label for="nom">Nom</label>
                        <input type="text" id="nom" name="nom" value="<?= htmlspecialchars($nomSaisi, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" autocomplete="family-name" required>
                    </div>
                </div>
                <div class="profil-champ">
                    <label for="email">Adresse email</label>
                    <div class="profil-champ__avec-icone">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="14" rx="2"/><path d="m4.5 7 7.5 6 7.5-6"/></svg>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($emailSaisi, ENT_QUOTES, 'UTF-8') ?>" maxlength="150" autocomplete="email" required>
                    </div>
                    <?php if (!empty($moi['email_verifie'])): ?>
                        <span class="profil-champ__aide profil-champ__aide--ok">Adresse vérifiée</span>
                    <?php else: ?>
                        <span class="profil-champ__aide">Adresse non vérifiée</span>
                    <?php endif; ?>
                </div>
                <div class="profil-champ">
                    <label for="telephone">Téléphone <span>(facultatif)</span></label>
                    <div class="profil-champ__avec-icone">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5h10a1.5 1.5 0 0 1 1.5 1.5v14a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 19V5A1.5 1.5 0 0 1 7 3.5Z"/><path d="M10 17.5h4"/></svg>
                        <input type="tel" id="telephone" name="telephone" value="<?= htmlspecialchars($telephoneSaisi, ENT_QUOTES, 'UTF-8') ?>" maxlength="20" autocomplete="tel" inputmode="tel">
                    </div>
                </div>
                <button type="submit" class="profil-bouton profil-bouton--principal">
                    Enregistrer les modifications
                    <span aria-hidden="true">→</span>
                </button>
            </form>
        </section>

        <section class="profil-carte" aria-labelledby="profil-securite-titre">
            <div class="profil-carte__entete">
                <div class="profil-carte__icone profil-carte__icone--securite" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 1 1 8 0v3M12 14v3"/></svg>
                </div>
                <div>
                    <h2 id="profil-securite-titre">Sécurité du compte</h2>
                    <p><?= $motDePasseDefini ? 'Changez votre mot de passe régulièrement.' : 'Ajoutez un mot de passe pour sécuriser votre accès.' ?></p>
                </div>
            </div>

            <?php if (!$motDePasseDefini): ?>
                <div class="profil-securite-note">
                    <span aria-hidden="true">i</span>
                    Votre compte n’a pas encore de mot de passe défini.
                </div>
                <a class="profil-bouton profil-bouton--principal profil-bouton--lien" href="../../public/definir-mot-de-passe.php">
                    Définir un mot de passe
                    <span aria-hidden="true">→</span>
                </a>
            <?php else: ?>
                <form method="POST" class="profil-formulaire">
                    <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_profil'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="action" value="changer_mdp">
                    <div class="profil-champ">
                        <label for="mdp_actuel">Mot de passe actuel</label>
                        <input type="password" id="mdp_actuel" name="mdp_actuel" class="auth-password-field" autocomplete="current-password" required>
                        <label class="profil-password-toggle"><input type="checkbox" class="auth-password-toggle"> Afficher le mot de passe</label>
                    </div>
                    <div class="profil-champ">
                        <label for="mdp_nouveau">Nouveau mot de passe</label>
                        <input type="password" id="mdp_nouveau" name="mdp_nouveau" class="auth-password-field" minlength="8" autocomplete="new-password" aria-describedby="profil-mdp-aide" required>
                        <label class="profil-password-toggle"><input type="checkbox" class="auth-password-toggle"> Afficher le mot de passe</label>
                    </div>
                    <div class="profil-champ">
                        <label for="mdp_confirmation">Confirmer le nouveau mot de passe</label>
                        <input type="password" id="mdp_confirmation" name="mdp_confirmation" class="auth-password-field" minlength="8" autocomplete="new-password" required>
                        <label class="profil-password-toggle"><input type="checkbox" class="auth-password-toggle"> Afficher le mot de passe</label>
                    </div>
                    <p class="profil-mdp-aide" id="profil-mdp-aide">Utilisez au moins 8 caractères et choisissez un mot de passe différent de l’actuel.</p>
                    <button type="submit" class="profil-bouton profil-bouton--secondaire">Mettre à jour le mot de passe</button>
                </form>
            <?php endif; ?>

            <div class="profil-securite-pied">
                <?= icone('check', 16) ?>
                Vos informations sont protégées et accessibles uniquement depuis votre compte.
            </div>
        </section>
    </div>
    <section class="profil-carte profil-entreprise" aria-labelledby="profil-entreprise-titre">
        <div class="profil-carte__entete">
            <div class="profil-carte__icone profil-carte__icone--entreprise" aria-hidden="true">
                <svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v16M9 7h3M9 11h3M9 15h3M16 9h2a2 2 0 0 1 2 2v10"/></svg>
            </div>
            <div>
                <h2 id="profil-entreprise-titre"><?= $entreprisesClient ? 'Votre espace entreprise' : 'Passer à un compte entreprise' ?></h2>
                <p><?= $entreprisesClient
                    ? 'Votre compte entreprise est activé et accessible depuis la barre de navigation.'
                    : 'Créez un espace professionnel tout en conservant votre compte client personnel.' ?></p>
            </div>
        </div>
        <?php if ($entreprisesClient): ?>
            <div class="profil-entreprise__espaces">
                <?php foreach ($entreprisesClient as $espaceEntreprise): ?>
                    <a class="profil-entreprise__espace" href="../entreprise/accueil.php?entreprise_id=<?= (int) $espaceEntreprise['id'] ?>">
                        <span><strong><?= htmlspecialchars((string) $espaceEntreprise['nom'], ENT_QUOTES, 'UTF-8') ?></strong><small><?= $espaceEntreprise['role_membre'] === 'admin' ? 'Administrateur' : 'Membre autorisé' ?></small></span>
                        <span aria-hidden="true">→</span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="profil-entreprise__description">Vous pourrez centraliser les demandes professionnelles, gérer vos sites et donner accès à vos collaborateurs. L’activation ne modifie pas vos informations ni vos demandes personnelles.</p>
            <a class="profil-bouton profil-bouton--principal profil-entreprise__action" href="activer-compte-entreprise.php">
                Découvrir et activer mon compte entreprise
                <span aria-hidden="true">→</span>
            </a>
        <?php endif; ?>
    </section>
</main>
<script>
    (function () {
        var photoInput = document.getElementById('photo-profil-client');
        var apercu = document.querySelector('.avatar-profil__apercu');
        var message = document.getElementById('photo-profil-client-message');
        var apercuPhotoURL = null;
        var typesAutorises = ['image/jpeg', 'image/png', 'image/webp'];

        if (!photoInput || !apercu || !message) return;

        var apercuInitial = Array.from(apercu.childNodes).map(function (noeud) {
            return noeud.cloneNode(true);
        });

        photoInput.addEventListener('change', function () {
            var fichier = photoInput.files && photoInput.files[0];
            if (!fichier) return;

            if (typesAutorises.indexOf(fichier.type) === -1 || fichier.size < 1 || fichier.size > 5 * 1024 * 1024) {
                photoInput.value = '';
                if (apercuPhotoURL) URL.revokeObjectURL(apercuPhotoURL);
                apercuPhotoURL = null;
                apercu.replaceChildren.apply(apercu, apercuInitial.map(function (noeud) {
                    return noeud.cloneNode(true);
                }));
                message.classList.add('avatar-profil__message--erreur');
                if (fichier.size > 5 * 1024 * 1024) {
                    message.textContent = 'La photo dépasse la taille maximale de 5 Mo.';
                } else if (fichier.size < 1) {
                    message.textContent = 'Le fichier sélectionné est vide.';
                } else {
                    message.textContent = 'Choisissez une image au format JPG, PNG ou WebP.';
                }
                return;
            }

            if (apercuPhotoURL) URL.revokeObjectURL(apercuPhotoURL);
            apercuPhotoURL = URL.createObjectURL(fichier);
            apercu.replaceChildren(Object.assign(document.createElement('img'), {
                src: apercuPhotoURL,
                alt: ''
            }));
            message.classList.remove('avatar-profil__message--erreur');
            message.textContent = 'Aperçu de la photo sélectionnée.';
        });

        window.addEventListener('pagehide', function () {
            if (apercuPhotoURL) URL.revokeObjectURL(apercuPhotoURL);
        });
    })();
</script>
<script src="../../public/js/auth.js?v=<?= filemtime(__DIR__ . '/../../public/js/auth.js') ?>" defer></script>
</body>
</html>
