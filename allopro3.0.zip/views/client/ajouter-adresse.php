<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Adresse.php';
require_once __DIR__ . '/../../includes/icones.php';

$adresseModel = new Adresse();
$userId = (int) $_SESSION['user_id'];
$erreur = '';
$succes = '';
$libelleSaisi = '';
$villeIdSaisi = 0;
$zoneIdSaisie = 0;
$detailsSaisis = '';
$adresseGoogleSaisie = '';
$latitudeSaisie = null;
$longitudeSaisie = null;
$villesDisponibles = $adresseModel->getVillesActives();
if ($villesDisponibles) {
    $villeIdSaisi = (int) $villesDisponibles[0]['id'];
}

if (empty($_SESSION['csrf_adresses'])) {
    $_SESSION['csrf_adresses'] = bin2hex(random_bytes(32));
}

if (($_GET['succes'] ?? '') === 'ajoutee') {
    $succes = 'Adresse enregistrée. Vous pourrez la sélectionner lors de votre prochaine demande.';
} elseif (($_GET['succes'] ?? '') === 'supprimee') {
    $succes = 'Adresse supprimée de votre liste.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_adresses'], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page et réessayez.';
    } elseif (($_POST['action'] ?? '') === 'supprimer') {
        $adresseId = filter_var($_POST['adresse_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($adresseId === false) {
            $erreur = 'Cette adresse ne peut pas être supprimée.';
        } elseif (!$adresseModel->supprimer($adresseId, $userId)) {
            $erreur = 'Cette adresse est introuvable ou a déjà été supprimée.';
        } else {
            header('Location: ajouter-adresse.php?succes=supprimee');
            exit;
        }
    } elseif (($_POST['action'] ?? '') === 'ajouter') {
        $libelleSaisi = trim(is_string($_POST['libelle'] ?? null) ? $_POST['libelle'] : '');
        $villeIdPost = filter_var($_POST['ville_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $zoneIdPost = filter_var($_POST['zone_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($villeIdPost !== false) {
            $villeIdSaisi = (int) $villeIdPost;
        }
        if ($zoneIdPost !== false) {
            $zoneIdSaisie = (int) $zoneIdPost;
        }
        $detailsSaisis = trim(is_string($_POST['details'] ?? null) ? $_POST['details'] : '');
        $adresseGoogleSaisie = trim(is_string($_POST['adresse_google'] ?? null) ? $_POST['adresse_google'] : '');
        $latitudeBrute = trim(is_string($_POST['latitude'] ?? null) ? $_POST['latitude'] : '');
        $longitudeBrute = trim(is_string($_POST['longitude'] ?? null) ? $_POST['longitude'] : '');
        $latitudeSaisie = $latitudeBrute === '' ? null : filter_var($latitudeBrute, FILTER_VALIDATE_FLOAT);
        $longitudeSaisie = $longitudeBrute === '' ? null : filter_var($longitudeBrute, FILTER_VALIDATE_FLOAT);
        $coordonneesValides = ($latitudeBrute === '' && $longitudeBrute === '')
            || (
                $latitudeSaisie !== false && $longitudeSaisie !== false
                && $latitudeSaisie !== null && $longitudeSaisie !== null
                && is_finite((float) $latitudeSaisie) && is_finite((float) $longitudeSaisie)
                && $latitudeSaisie >= 12 && $latitudeSaisie <= 17
                && $longitudeSaisie >= -18 && $longitudeSaisie <= -11
                && $adresseGoogleSaisie !== '' && mb_strlen($adresseGoogleSaisie) <= 500
            );

        $villeValide = $villeIdPost !== false
            && in_array((int) $villeIdPost, array_map('intval', array_column($villesDisponibles, 'id')), true);
        $zonesVille = $villeValide ? $adresseModel->getZonesActivesParVille($villeIdSaisi) : [];
        $zoneValide = $zoneIdPost !== false
            && in_array((int) $zoneIdPost, array_map('intval', array_column($zonesVille, 'id')), true);

        if ($libelleSaisi === '') {
            $erreur = 'Donnez un nom à ce lieu, par exemple « Domicile » ou « Bureau ».';
        } elseif (mb_strlen($libelleSaisi) > 100) {
            $erreur = 'Le libellé ne doit pas dépasser 100 caractères.';
        } elseif (!$villeValide) {
            $erreur = 'Choisissez une ville ou une région dans la liste.';
        } elseif (!$zoneValide) {
            $erreur = 'Choisissez un quartier ou une zone disponible pour cette ville.';
        } elseif (!$coordonneesValides) {
            $erreur = 'La position GPS est invalide. Relancez la localisation ou effacez-la pour enregistrer sans GPS.';
        } else {
            if (!$adresseModel->create(
                $userId,
                $libelleSaisi,
                $villeIdSaisi,
                (int) $zoneIdPost,
                $detailsSaisis,
                $adresseGoogleSaisie !== '' ? $adresseGoogleSaisie : null,
                $latitudeSaisie !== null ? (float) $latitudeSaisie : null,
                $longitudeSaisie !== null ? (float) $longitudeSaisie : null
            )) {
                throw new RuntimeException('L’enregistrement de l’adresse a échoué.');
            }
            header('Location: ajouter-adresse.php?succes=ajoutee');
            exit;
        }
    } else {
        $erreur = 'La demande n’a pas pu être traitée. Rechargez la page et réessayez.';
    }
}

$mesAdresses = $adresseModel->getByUser($userId);
$nombreAdresses = count($mesAdresses);
$zonesDisponibles = [];
$nomZoneSaisie = '';
$zonesPourRecherche = [];
foreach ($villesDisponibles as $ville) {
    $zonesDisponibles[(int) $ville['id']] = $adresseModel->getZonesActivesParVille((int) $ville['id']);
    foreach ($zonesDisponibles[(int) $ville['id']] as $zone) {
        $zonesPourRecherche[] = [
            'id' => (int) $zone['id'],
            'ville_id' => (int) $ville['id'],
            'nom' => (string) $zone['nom'],
        ];
        if ((int) $zone['id'] === $zoneIdSaisie) {
            $nomZoneSaisie = (string) $zone['nom'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes adresses — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/adresses.css?v=<?= filemtime(__DIR__ . '/../../public/css/adresses.css') ?>">
    <link rel="stylesheet" href="../../public/css/adresses-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/adresses-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client adresses-page">
    <header class="adresses-entete">
        <div>
            <p class="adresses-entete__sur-titre">VOS LIEUX DE SERVICE</p>
            <h1>Où pouvons-nous intervenir&nbsp;?</h1>
            <p class="adresses-entete__description">Enregistrez vos lieux habituels pour les retrouver facilement lors d’une demande.</p>
        </div>
        <a class="adresses-entete__retour" href="profil.php">
            <span aria-hidden="true">←</span>
            Retour au profil
        </a>
    </header>

    <?php if ($succes !== ''): ?>
        <div class="adresses-alerte adresses-alerte--succes" role="status">
            <?= icone('check', 16) ?>
            <?= htmlspecialchars($succes, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>
    <?php if ($erreur !== ''): ?>
        <div class="adresses-alerte adresses-alerte--erreur" role="alert">
            <?= icone('alert', 16) ?>
            <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <div class="adresses-resume">
        <div class="adresses-resume__icone" aria-hidden="true">
            <svg viewBox="0 0 24 24"><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.3"/></svg>
        </div>
        <div>
            <strong><?= $nombreAdresses ?> adresse<?= $nombreAdresses === 1 ? '' : 's' ?> enregistrée<?= $nombreAdresses === 1 ? '' : 's' ?></strong>
            <span><?= $nombreAdresses > 0 ? 'Vos lieux sont prêts à être utilisés pour une nouvelle demande.' : 'Ajoutez votre domicile, votre bureau ou un autre lieu habituel.' ?></span>
        </div>
    </div>

    <div class="adresses-contenu">
        <section class="adresses-liste-carte" aria-labelledby="adresses-liste-titre">
            <div class="adresses-section-entete">
                <div>
                    <span class="adresses-etape">VOS LIEUX</span>
                    <h2 id="adresses-liste-titre">Adresses enregistrées</h2>
                    <p>Gérez les endroits où vous demandez des interventions.</p>
                </div>
                <?php if ($nombreAdresses > 0): ?>
                    <span class="adresses-compteur"><?= $nombreAdresses ?></span>
                <?php endif; ?>
            </div>

            <?php if ($nombreAdresses === 0): ?>
                <div class="adresses-vide">
                    <div class="adresses-vide__icone" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.3"/></svg>
                    </div>
                    <h3>Ajoutez votre premier lieu</h3>
                    <p>Ajoutez une adresse avec le formulaire. Elle sera disponible lors de vos prochaines demandes de service.</p>
                    <a href="#nouvelle-adresse" class="adresses-vide__action">Ajouter une adresse</a>
                </div>
            <?php else: ?>
                <div class="adresses-liste">
                    <?php foreach ($mesAdresses as $adr): ?>
                        <article class="adresse-item">
                            <div class="adresse-item__pin" aria-hidden="true">
                                <svg viewBox="0 0 24 24"><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.3"/></svg>
                            </div>
                            <div class="adresse-item__infos">
                                <h3 class="adresse-item__libelle"><?= htmlspecialchars((string) $adr['libelle'], ENT_QUOTES, 'UTF-8') ?></h3>
                                <p class="adresse-item__detail">
                                    <?= htmlspecialchars((string) $adr['quartier'], ENT_QUOTES, 'UTF-8') ?>
                                    <span aria-hidden="true">·</span>
                                    <?= htmlspecialchars((string) $adr['ville'], ENT_QUOTES, 'UTF-8') ?>
                                </p>
                                <?php if (!empty($adr['details'])): ?>
                                    <p class="adresse-item__notes"><?= htmlspecialchars((string) $adr['details'], ENT_QUOTES, 'UTF-8') ?></p>
                                <?php endif; ?>
                                <?php if (!empty($adr['adresse_google'])): ?>
                                    <p class="adresse-item__notes"><?= htmlspecialchars((string) $adr['adresse_google'], ENT_QUOTES, 'UTF-8') ?></p>
                                <?php endif; ?>
                                <?php if ($adr['latitude'] !== null && $adr['longitude'] !== null): ?>
                                    <a class="adresse-item__carte" href="https://www.google.com/maps/search/?api=1&amp;query=<?= rawurlencode((string) $adr['latitude'] . ',' . (string) $adr['longitude']) ?>" target="_blank" rel="noopener noreferrer">Voir le point sur la carte</a>
                                <?php endif; ?>
                            </div>
                            <form method="POST" class="adresse-item__actions" onsubmit="return confirm('Supprimer cette adresse de votre liste ?');">
                                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_adresses'], ENT_QUOTES, 'UTF-8') ?>">
                                <input type="hidden" name="action" value="supprimer">
                                <input type="hidden" name="adresse_id" value="<?= (int) $adr['id'] ?>">
                                <button type="submit" class="adresse-item__supprimer" aria-label="Supprimer l’adresse <?= htmlspecialchars((string) $adr['libelle'], ENT_QUOTES, 'UTF-8') ?>">
                                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/></svg>
                                    <span>Supprimer</span>
                                </button>
                            </form>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="adresse-form-carte" id="nouvelle-adresse" aria-labelledby="adresse-form-titre">
            <div class="adresses-section-entete">
                <div>
                    <span class="adresses-etape">NOUVELLE ADRESSE</span>
                    <h2 id="adresse-form-titre">Ajouter un lieu</h2>
                    <p>Indiquez où et comment notre équipe pourra vous retrouver.</p>
                </div>
                <div class="adresse-form-carte__icone" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
                </div>
            </div>

            <form method="POST" class="adresse-formulaire" id="formulaire-adresse">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_adresses'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="action" value="ajouter">
                <input type="hidden" id="latitude" name="latitude" value="<?= htmlspecialchars($latitudeSaisie !== null && $latitudeSaisie !== false ? (string) $latitudeSaisie : '', ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" id="longitude" name="longitude" value="<?= htmlspecialchars($longitudeSaisie !== null && $longitudeSaisie !== false ? (string) $longitudeSaisie : '', ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" id="csrf-geolocalisation" value="<?= htmlspecialchars($_SESSION['csrf_adresses'], ENT_QUOTES, 'UTF-8') ?>">
                <div class="adresse-formulaire__localisation">
                    <button type="button" id="btn-ma-position" class="adresse-formulaire__localiser">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3"/><circle cx="12" cy="12" r="8"/></svg>
                        <span>Utiliser ma position actuelle</span>
                    </button>
                    <p id="localisation-message" class="adresse-formulaire__localisation-message" role="status" aria-live="polite">Après votre autorisation, le GPS de votre appareil transmettra sa position à Nominatim (OpenStreetMap) pour proposer l’adresse. Vérifiez les informations avant de les enregistrer.</p>
                    <small class="adresse-formulaire__attribution">Géocodage : <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">© contributeurs OpenStreetMap</a></small>
                </div>
                <div class="adresse-formulaire__rangee">
                    <div class="adresse-formulaire__champ">
                        <label for="libelle">Comment l’appeler&nbsp;? <span>Obligatoire</span></label>
                        <input type="text" id="libelle" name="libelle" placeholder="Ex. Domicile, Bureau, Boutique" value="<?= htmlspecialchars($libelleSaisi, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" autocomplete="off" aria-describedby="libelle-aide" required>
                        <small id="libelle-aide">Ce nom vous aidera à retrouver le lieu lors de vos prochaines demandes.</small>
                    </div>
                    <div class="adresse-formulaire__champ">
                        <label for="ville_id">Ville ou région <span>Obligatoire</span></label>
                        <select id="ville_id" name="ville_id" autocomplete="address-level2" required>
                            <option value="">Choisir une ville ou une région</option>
                            <?php foreach ($villesDisponibles as $ville): ?>
                                <option value="<?= (int) $ville['id'] ?>" <?= $villeIdSaisi === (int) $ville['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars((string) $ville['nom'], ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="adresse-formulaire__champ">
                    <label for="adresse_google">Adresse précise ou repère <span>Facultatif</span></label>
                    <input type="text" id="adresse_google" name="adresse_google" value="<?= htmlspecialchars($adresseGoogleSaisie, ENT_QUOTES, 'UTF-8') ?>" maxlength="500" autocomplete="street-address" placeholder="Ex. avenue, numéro, bâtiment ou repère">
                    <small>Ces précisions aident le technicien à trouver le lieu. Elles sont communiquées uniquement pour l’intervention concernée.</small>
                </div>
                <div class="adresse-formulaire__champ">
                    <label for="zone-recherche">Quartier ou zone <span>Obligatoire</span></label>
                    <div class="adresse-zone-recherche">
                        <span class="adresse-zone-recherche__icone" aria-hidden="true">
                            <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/></svg>
                        </span>
                        <input type="search" id="zone-recherche" value="<?= htmlspecialchars($nomZoneSaisie, ENT_QUOTES, 'UTF-8') ?>" placeholder="Rechercher votre quartier…" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="zone-suggestions" aria-describedby="zone-recherche-aide" required>
                        <button type="button" class="adresse-zone-recherche__effacer" id="zone-recherche-effacer" aria-label="Effacer le quartier" hidden>×</button>
                        <div class="adresse-zone-suggestions" id="zone-suggestions" role="listbox" hidden></div>
                    </div>
                    <input type="hidden" id="zone_id" name="zone_id" value="<?= $zoneIdSaisie > 0 ? $zoneIdSaisie : '' ?>">
                    <small id="zone-recherche-aide" class="adresse-zone-recherche__aide">Choisissez d’abord une ville, puis saisissez quelques lettres pour afficher les quartiers correspondants.</small>
                    <small id="zone-recherche-erreur" class="adresse-zone-recherche__erreur" role="alert" hidden>Choisissez un quartier dans les suggestions.</small>
                    <small>Vous ne trouvez pas votre quartier&nbsp;? Choisissez la zone la plus proche et précisez le lieu ci-dessous. Catalogue <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>.</small>
                </div>
                <div class="adresse-formulaire__champ">
                    <label for="details">Instructions pour nous trouver <span>Facultatif</span></label>
                    <textarea id="details" name="details" rows="4" placeholder="Repère proche, étage, entrée, couleur du portail…" aria-describedby="adresse-details-aide"><?= htmlspecialchars($detailsSaisis, ENT_QUOTES, 'UTF-8') ?></textarea>
                    <small id="adresse-details-aide">Ajoutez un repère utile à l’intervenant, sans inclure de code d’accès confidentiel.</small>
                </div>
                <button type="submit" class="adresse-formulaire__bouton">
                    Enregistrer cette adresse
                    <span aria-hidden="true">→</span>
                </button>
            </form>
        </section>
    </div>
</main>
<script>
(function () {
    var ville = document.getElementById('ville_id');
    var zone = document.getElementById('zone_id');
    var recherche = document.getElementById('zone-recherche');
    var listeSuggestions = document.getElementById('zone-suggestions');
    var aideRecherche = document.getElementById('zone-recherche-aide');
    var erreurRecherche = document.getElementById('zone-recherche-erreur');
    var boutonEffacerRecherche = document.getElementById('zone-recherche-effacer');
    var boutonPosition = document.getElementById('btn-ma-position');
    var messagePosition = document.getElementById('localisation-message');
    var adressePrecise = document.getElementById('adresse_google');
    var latitude = document.getElementById('latitude');
    var longitude = document.getElementById('longitude');
    var formulaire = document.getElementById('formulaire-adresse');
    if (!ville || !zone || !recherche || !boutonPosition || !messagePosition) return;
    var zones = <?= json_encode($zonesPourRecherche, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;
    function normaliser(valeur) {
        return valeur.toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }
    function fermerSuggestions() {
        listeSuggestions.hidden = true;
        listeSuggestions.replaceChildren();
        recherche.setAttribute('aria-expanded', 'false');
    }
    function afficherSuggestions() {
        var villeId = ville.value;
        var terme = normaliser(recherche.value.trim());
        zone.value = '';
        boutonEffacerRecherche.hidden = recherche.value === '';
        listeSuggestions.replaceChildren();
        listeSuggestions.hidden = true;
        recherche.setAttribute('aria-expanded', 'false');
        recherche.setAttribute('aria-invalid', 'false');
        erreurRecherche.hidden = true;

        if (!villeId) {
            aideRecherche.textContent = 'Choisissez d’abord une ville ou une région.';
            return;
        }
        if (terme.length < 2) {
            aideRecherche.textContent = 'Saisissez au moins deux lettres pour afficher les quartiers correspondants.';
            return;
        }

        var resultats = zones.filter(function (element) {
            return String(element.ville_id) === villeId
                && normaliser(element.nom).indexOf(terme) !== -1;
        }).slice(0, 8);
        if (!resultats.length) {
            aideRecherche.textContent = 'Aucun quartier trouvé. Essayez un autre nom ou choisissez la zone la plus proche.';
            return;
        }

        aideRecherche.textContent = resultats.length === 8
            ? 'Voici les 8 premiers résultats. Affinez votre recherche pour préciser le quartier.'
            : resultats.length + ' quartier' + (resultats.length === 1 ? '' : 's') + ' trouvé' + (resultats.length === 1 ? '' : 's') + '.';
        resultats.forEach(function (element) {
            var option = document.createElement('button');
            option.type = 'button';
            option.className = 'adresse-zone-suggestions__option';
            option.setAttribute('role', 'option');
            option.setAttribute('aria-selected', 'false');
            option.textContent = element.nom;
            option.addEventListener('click', function () {
                zone.value = String(element.id);
                recherche.value = element.nom;
                boutonEffacerRecherche.hidden = false;
                aideRecherche.textContent = 'Quartier sélectionné : ' + element.nom + '.';
                fermerSuggestions();
                zone.dispatchEvent(new Event('change', { bubbles: true }));
                recherche.focus();
            });
            listeSuggestions.appendChild(option);
        });
        listeSuggestions.hidden = false;
        recherche.setAttribute('aria-expanded', 'true');
    }
    var localisationEnCours = false;
    function invaliderCoordonneesManuelles() {
        if (localisationEnCours || !latitude.value || !longitude.value) return;
        latitude.value = '';
        longitude.value = '';
        messagePosition.textContent = 'La ville, le quartier ou l’adresse a été modifié. Relancez « Ma position actuelle » pour actualiser le point GPS.';
    }
    function selectionnerCorrespondance(select, candidats) {
        var valeurs = candidats.map(normaliser);
        var option = Array.prototype.slice.call(select.options).find(function (element) {
            var nom = normaliser(element.text);
            return element.value !== '' && valeurs.some(function (valeur) {
                return valeur && (nom === valeur || nom.indexOf(valeur) !== -1 || valeur.indexOf(nom) !== -1);
            });
        });
        if (!option) return false;
        select.value = option.value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
    }
    function selectionnerQuartierCorrespondant(candidats) {
        var valeurs = candidats.map(normaliser);
        var quartier = zones.find(function (element) {
            return String(element.ville_id) === ville.value && valeurs.some(function (valeur) {
                var nom = normaliser(element.nom);
                return valeur && (nom === valeur || nom.indexOf(valeur) !== -1 || valeur.indexOf(nom) !== -1);
            });
        });
        if (!quartier) return false;
        zone.value = String(quartier.id);
        recherche.value = quartier.nom;
        boutonEffacerRecherche.hidden = false;
        aideRecherche.textContent = 'Quartier proposé par OpenStreetMap : ' + quartier.nom + '.';
        fermerSuggestions();
        zone.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
    }
    boutonPosition.addEventListener('click', function () {
        if (!window.isSecureContext) {
            messagePosition.textContent = 'La localisation nécessite une connexion sécurisée HTTPS. Vous pouvez renseigner votre adresse manuellement.';
            return;
        }
        if (!navigator.geolocation) {
            messagePosition.textContent = 'La géolocalisation n’est pas disponible sur cet appareil ou navigateur.';
            return;
        }
        boutonPosition.disabled = true;
        messagePosition.textContent = 'Recherche de votre position…';
        navigator.geolocation.getCurrentPosition(async function (position) {
            try {
                var reponse = await fetch('../../public/api-geolocalisation-adresse.php', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify({
                        csrf: document.getElementById('csrf-geolocalisation').value,
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    })
                });
                var resultat = await reponse.json();
                if (!reponse.ok) throw new Error(resultat.erreur || 'La conversion de la position en adresse a échoué.');

                latitude.value = resultat.latitude;
                longitude.value = resultat.longitude;
                localisationEnCours = true;
                adressePrecise.value = resultat.adresse;
                var villeTrouvee = selectionnerCorrespondance(ville, resultat.villes || []);
                if (villeTrouvee) afficherSuggestions();
                var quartierTrouve = villeTrouvee && selectionnerQuartierCorrespondant(resultat.quartiers || []);
                if (!quartierTrouve && resultat.quartiers && resultat.quartiers.length) {
                    recherche.value = resultat.quartiers[0];
                    afficherSuggestions();
                }
                var libelle = document.getElementById('libelle');
                if (!libelle.value.trim()) libelle.value = 'Ma position actuelle';
                localisationEnCours = false;

                messagePosition.textContent = villeTrouvee && quartierTrouve
                    ? 'Position trouvée avec OpenStreetMap : adresse, ville et quartier ont été renseignés. Vérifiez les champs avant d’enregistrer.'
                    : 'Adresse trouvée avec OpenStreetMap. Choisissez ou vérifiez la ville et le quartier proposés avant d’enregistrer.';
            } catch (erreur) {
                localisationEnCours = false;
                messagePosition.textContent = erreur.message;
            } finally {
                boutonPosition.disabled = false;
            }
        }, function (erreur) {
            var messages = {
                1: 'Autorisez l’accès à la position pour utiliser cette fonction.',
                2: 'Votre position n’a pas pu être déterminée. Vérifiez le GPS et réessayez.',
                3: 'La recherche de position a expiré. Réessayez.'
            };
            messagePosition.textContent = messages[erreur.code] || 'La position actuelle n’a pas pu être obtenue.';
            boutonPosition.disabled = false;
        }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
    });
    ville.addEventListener('change', function () {
        recherche.value = '';
        zone.value = '';
        boutonEffacerRecherche.hidden = true;
        aideRecherche.textContent = ville.value
            ? 'Saisissez au moins deux lettres pour afficher les quartiers correspondants.'
            : 'Choisissez d’abord une ville ou une région.';
        erreurRecherche.hidden = true;
        fermerSuggestions();
    });
    ville.addEventListener('change', invaliderCoordonneesManuelles);
    zone.addEventListener('change', invaliderCoordonneesManuelles);
    adressePrecise.addEventListener('input', invaliderCoordonneesManuelles);
    recherche.addEventListener('input', afficherSuggestions);
    recherche.addEventListener('focus', function () {
        if (recherche.value && !zone.value) afficherSuggestions();
    });
    recherche.addEventListener('keydown', function (event) {
        var options = listeSuggestions.querySelectorAll('[role="option"]');
        if (event.key === 'ArrowDown' && options.length) {
            event.preventDefault();
            options[0].focus();
        } else if (event.key === 'Enter' && listeSuggestions.hidden === false && options.length) {
            event.preventDefault();
            options[0].click();
        } else if (event.key === 'Escape') {
            fermerSuggestions();
        }
    });
    listeSuggestions.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            fermerSuggestions();
            recherche.focus();
        } else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            var options = Array.prototype.slice.call(listeSuggestions.querySelectorAll('[role="option"]'));
            var index = options.indexOf(document.activeElement);
            var prochain = event.key === 'ArrowDown' ? Math.min(index + 1, options.length - 1) : Math.max(index - 1, 0);
            if (options[prochain]) {
                event.preventDefault();
                options[prochain].focus();
            }
        }
    });
    boutonEffacerRecherche.addEventListener('click', function () {
        recherche.value = '';
        zone.value = '';
        boutonEffacerRecherche.hidden = true;
        afficherSuggestions();
        recherche.focus();
    });
    document.addEventListener('click', function (event) {
        if (!listeSuggestions.parentElement.contains(event.target)) fermerSuggestions();
    });
    formulaire.addEventListener('submit', function (event) {
        if (!zone.value) {
            event.preventDefault();
            erreurRecherche.hidden = false;
            recherche.setAttribute('aria-invalid', 'true');
            recherche.focus();
            return;
        }
        var bouton = formulaire.querySelector('.adresse-formulaire__bouton');
        bouton.disabled = true;
        bouton.textContent = 'Enregistrement…';
    });
    if (zone.value) {
        aideRecherche.textContent = 'Quartier sélectionné : ' + recherche.value + '.';
        boutonEffacerRecherche.hidden = false;
    }
    window.addEventListener('pageshow', function (event) {
        if (!event.persisted) return;
        var bouton = formulaire.querySelector('.adresse-formulaire__bouton');
        bouton.disabled = false;
        bouton.innerHTML = 'Enregistrer cette adresse <span aria-hidden="true">→</span>';
    });
})();
</script>
</body>
</html>
