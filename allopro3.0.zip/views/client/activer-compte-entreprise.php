<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../includes/icones.php';
require_once __DIR__ . '/../../models/EntrepriseB2B.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../includes/audit.php';

$userId = (int) $_SESSION['user_id'];
$entrepriseModele = new EntrepriseB2B();
$entreprisesActives = $entrepriseModele->getEntreprisesParMembre($userId);
if ($entreprisesActives) {
    header('Location: ../entreprise/accueil.php?entreprise_id=' . (int) $entreprisesActives[0]['id']);
    exit;
}

if (empty($_SESSION['csrf_entreprise_activation'])) {
    $_SESSION['csrf_entreprise_activation'] = bin2hex(random_bytes(32));
}

$client = (new User())->getById($userId);
$nomEntreprise = '';
$erreur = '';
$nomExisteErreur = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $nomEntreprise = trim(is_string($_POST['nom'] ?? null) ? $_POST['nom'] : '');
    $confirmation = ($_POST['confirmation_entreprise'] ?? '') === '1';

    if (!hash_equals($_SESSION['csrf_entreprise_activation'], $csrf)) {
        $erreur = 'La page a expiré. Rechargez-la puis confirmez à nouveau.';
    } elseif (!$confirmation) {
        $erreur = 'Cochez la confirmation pour créer votre compte entreprise.';
    } else {
        try {
            $entrepriseId = $entrepriseModele->creerPourClient($userId, $nomEntreprise);
            journaliser('entreprise.compte_cree', 'entreprise_b2b', $entrepriseId, $nomEntreprise);
            header('Location: ../entreprise/accueil.php?entreprise_id=' . $entrepriseId);
            exit;
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
            $nomExisteErreur = str_contains($erreur, 'porte déjà ce nom');
        } catch (PDOException $exception) {
            error_log('Activation espace entreprise par client ' . $userId . ' : ' . $exception->getMessage());
            $erreur = 'La création du compte entreprise a échoué. Réessayez.';
        }
    }
}

$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Passer à un compte entreprise — ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
    <script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script>
    <?php include __DIR__ . '/../../includes/event-theme-head.php'; ?>
</head>
<body>
<main class="b2b-main">
    <header class="b2b-header b2b-header--welcome">
        <div class="b2b-header__copy">
            <span class="b2b-eyebrow">VOTRE ESPACE PROFESSIONNEL</span>
            <h1>Passer à un compte entreprise</h1>
            <p>Votre compte client personnel reste actif. Vous ajoutez simplement un espace pour gérer l’activité de votre entreprise.</p>
        </div>
        <a class="b2b-button b2b-button--secondary" href="profil.php">Retour au profil <span aria-hidden="true">↗</span></a>
    </header>

    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>

    <section class="b2b-create-layout">
        <div class="b2b-create-aside">
            <span class="b2b-create-aside__icon" aria-hidden="true"><?= icone('sparkles', 18) ?></span>
            <span class="b2b-eyebrow">CE QUI VA CHANGER</span>
            <h2>Un espace pro, sans remplacer votre compte client.</h2>
            <ul>
                <li><?= icone('check', 14) ?> Vous créez l’espace au nom de votre entreprise.</li>
                <li><?= icone('check', 14) ?> Vous en devenez l’administrateur principal.</li>
                <li><?= icone('check', 14) ?> Vous pourrez ensuite ajouter des membres et gérer les demandes par site.</li>
                <li><?= icone('check', 14) ?> Vos demandes personnelles et vos informations restent inchangées.</li>
            </ul>
        </div>
        <div class="b2b-panel b2b-create-panel">
            <span class="b2b-eyebrow">CONFIRMATION REQUISE</span>
            <h2>Créer mon compte entreprise</h2>
            <?php if (empty($client['email_verifie'])): ?>
                <div class="b2b-alert" role="alert">
                    Vérifiez d’abord votre adresse e-mail pour activer l’espace entreprise.
                    <a href="../../public/verification-email.php?type=client&amp;email=<?= rawurlencode((string) ($client['email'] ?? '')) ?>">Vérifier mon adresse</a>
                </div>
            <?php endif; ?>
            <form method="post" class="b2b-form" id="form-entreprise" data-verification-url="../../public/api-entreprise-nom.php">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_entreprise_activation']) ?>">
                <label for="entreprise-nom">Nom légal ou usuel de l’entreprise
                    <input id="entreprise-nom" name="nom" type="text" value="<?= $e($nomEntreprise) ?>" minlength="2" maxlength="150" autocomplete="organization" aria-describedby="entreprise-nom-aide entreprise-nom-statut" aria-invalid="<?= $nomExisteErreur ? 'true' : 'false' ?>" required>
                </label>
                <small id="entreprise-nom-aide" class="b2b-field-hint">Le nom doit être unique dans ALLÔ PRO.</small>
                <div id="entreprise-nom-statut" class="b2b-name-status" role="status" aria-live="polite"><?= $nomExisteErreur ? $e($erreur) : '' ?></div>
                <label class="b2b-confirmation">
                    <input type="checkbox" name="confirmation_entreprise" value="1" required>
                    Je confirme vouloir créer et activer un espace entreprise au nom indiqué.
                </label>
                <button class="b2b-button b2b-button--create" type="submit" id="entreprise-creer" <?= empty($client['email_verifie']) ? 'disabled' : '' ?>>
                    Confirmer et activer mon compte entreprise <span aria-hidden="true">→</span>
                </button>
            </form>
            <p class="b2b-privacy-note"><span aria-hidden="true">●</span> Cette activation ne supprime pas votre compte client ni vos données personnelles.</p>
        </div>
    </section>
</main>
</body>
</html>
