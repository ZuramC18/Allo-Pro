<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Demande.php';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$vueDemandee = $_GET['vue'] ?? 'toutes';
$vue = in_array($vueDemandee, ['toutes', 'suivi'], true) ? $vueDemandee : 'toutes';
$demandes = (new Demande())->getByClient((int) $_SESSION['user_id']);
$interventions = array_values(array_filter($demandes, static function (array $demande) use ($vue): bool {
    if (empty($demande['intervention_id'])) {
        return false;
    }
    return $vue !== 'suivi' || in_array($demande['intervention_statut'], ['en_attente', 'refusee', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours'], true);
}));
$libellesStatuts = [
    'en_attente' => 'En attente de réponse du technicien',
    'refusee' => 'Réaffectation en attente du coordinateur',
    'acceptee' => 'Mission acceptée',
    'en_route' => 'Technicien en route',
    'arrive' => 'Technicien arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'Intervention en cours',
    'terminee' => 'Terminée',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $vue === 'suivi' ? 'Suivi d’intervention' : 'Mes interventions' ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/portail-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/portail-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>
<main class="page-client portail-client">
    <header class="portail-entete">
        <div>
            <p class="portail-sur-titre">VOTRE ACTIVITÉ</p>
            <h1><?= $vue === 'suivi' ? 'Suivi d’intervention' : 'Mes interventions' ?></h1>
            <p><?= $vue === 'suivi' ? 'Suivez les missions en cours et ouvrez leur dossier pour consulter les détails.' : 'Retrouvez les interventions associées à vos demandes.' ?></p>
        </div>
        <a class="portail-action" href="nouvelle-demande.php">Nouvelle demande</a>
    </header>

    <nav class="portail-filtres" aria-label="Filtrer les interventions">
        <a href="mes-interventions.php" <?= $vue === 'toutes' ? 'aria-current="page"' : '' ?>>Toutes les interventions</a>
        <a href="mes-interventions.php?vue=suivi" <?= $vue === 'suivi' ? 'aria-current="page"' : '' ?>>En cours de suivi</a>
    </nav>

    <?php if ($interventions): ?>
        <section class="portail-liste" aria-label="Liste des interventions">
            <?php foreach ($interventions as $demande): ?>
                <?php $statut = $demande['intervention_statut'] ?? ''; ?>
                <article class="portail-carte">
                    <div class="portail-carte__contenu">
                        <div class="portail-carte__ligne">
                            <h2><?= h($demande['numero_dossier']) ?></h2>
                            <span class="portail-statut"><?= h($libellesStatuts[$statut] ?? 'En attente de mise à jour') ?></span>
                        </div>
                        <p><?= h($demande['categorie_nom']) ?> · <?= date('d/m/Y', strtotime($demande['date_creation'])) ?></p>
                    </div>
                    <a class="portail-action portail-action--secondaire" href="detail-demande.php?id=<?= (int) $demande['id'] ?>">Voir le suivi</a>
                </article>
            <?php endforeach; ?>
        </section>
    <?php else: ?>
        <section class="portail-vide">
            <h2><?= $vue === 'suivi' ? 'Aucune intervention en cours' : 'Aucune intervention pour le moment' ?></h2>
            <p><?= $vue === 'suivi' ? 'Les interventions actives apparaîtront ici dès qu’un technicien sera affecté.' : 'Une intervention apparaîtra ici lorsqu’une demande aura été attribuée.' ?></p>
            <a class="portail-action" href="mes-demandes.php">Voir mes demandes</a>
        </section>
    <?php endif; ?>
</main>
</body>
</html>
