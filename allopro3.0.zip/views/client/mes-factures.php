<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Facture.php';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

if (empty($_SESSION['csrf_factures'])) {
    $_SESSION['csrf_factures'] = bin2hex(random_bytes(32));
}

$factureModel = new Facture();
$erreur = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $idFacture = filter_var($_POST['facture_id'] ?? null, FILTER_VALIDATE_INT);
    if (!hash_equals($_SESSION['csrf_factures'], $csrf)) {
        $erreur = 'Votre session a expire. Rechargez la page puis reessayez.';
    } elseif (!$idFacture) {
        $erreur = 'La facture demandee est invalide.';
    } else {
        try {
            $factureRenvoyee = $factureModel->renvoyerPourClient((int) $idFacture, (int) $_SESSION['user_id']);
            header('Location: mes-factures.php?envoi=' . ($factureRenvoyee['email_statut'] === 'envoye' ? 'ok' : 'echec'));
            exit;
        } catch (Throwable $e) {
            error_log('Nouvelle tentative d’envoi de facture client impossible : ' . $e->getMessage());
            $erreur = 'La facture est archivée, mais son envoi a échoué. Vérifiez la configuration de messagerie puis réessayez.';
        }
    }
}

$factures = $factureModel->getPourClient((int) $_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes factures — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/portail-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/portail-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>
<main class="page-client portail-client">
    <header class="portail-entete">
        <div>
            <p class="portail-sur-titre">PAIEMENTS & AVANTAGES</p>
            <h1>Mes factures</h1>
            <p>Retrouvez ici les documents de facturation liés à votre compte.</p>
        </div>
        <a class="portail-action portail-action--secondaire" href="mes-paiements.php">Consulter mes paiements</a>
    </header>

    <?php if (($_GET['envoi'] ?? '') === 'ok'): ?>
        <div class="portail-alerte portail-alerte--succes" role="status">La facture a été envoyée par e-mail.</div>
    <?php endif; ?>
    <?php if (($_GET['envoi'] ?? '') === 'echec'): ?>
        <div class="portail-alerte" role="alert">La facture est archivée, mais son envoi e-mail a échoué. Vérifiez la configuration de messagerie et réessayez.</div>
    <?php endif; ?>
    <?php if ($erreur !== ''): ?>
        <div class="portail-alerte" role="alert"><?= h($erreur) ?></div>
    <?php endif; ?>

    <?php if ($factures): ?>
        <section class="portail-liste" aria-label="Factures archivées">
            <?php foreach ($factures as $facture): ?>
                <article class="portail-carte">
                    <div class="portail-carte__contenu">
                        <div class="portail-carte__ligne">
                            <h2><?= h($facture['numero']) ?></h2>
                            <span class="portail-statut"><?= $facture['email_statut'] === 'envoye' ? 'Envoyée par e-mail' : ($facture['email_statut'] === 'echec' ? 'Envoi e-mail à réessayer' : 'Envoi en cours') ?></span>
                        </div>
                        <p><?= h($facture['libelle']) ?></p>
                        <p><?= date('d/m/Y', strtotime($facture['date_emission'])) ?> · <?= number_format((float) $facture['montant'], 0, ',', ' ') ?> <?= h($facture['devise']) ?></p>
                    </div>
                    <div class="portail-facture-actions">
                        <a class="portail-action portail-action--secondaire" href="telecharger-facture.php?id=<?= (int) $facture['id'] ?>">Télécharger le PDF</a>
                        <?php if ($facture['email_statut'] !== 'envoye'): ?>
                            <form method="post">
                                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf_factures']) ?>">
                                <input type="hidden" name="facture_id" value="<?= (int) $facture['id'] ?>">
                                <button class="portail-action" type="submit">Renvoyer par e-mail</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php else: ?>
        <section class="portail-vide">
            <h2>Aucune facture pour le moment</h2>
            <p>Une facture PDF sera créée et archivée après confirmation d’un paiement. Elle sera également envoyée à l’adresse e-mail de votre compte.</p>
            <a class="portail-action" href="mes-paiements.php">Voir mes paiements</a>
        </section>
    <?php endif; ?>
</main>
</body>
</html>
