<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Abonnement.php';

// Échappement HTML sûr (accepte null)
if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$abonnementModel = new Abonnement();
$clientId = (int) $_SESSION['user_id'];

$abonnementActif = $abonnementModel->getActifParClient($clientId);
$idActif = $abonnementActif ? (int) $abonnementActif['id'] : 0;
$historique = $abonnementModel->getHistoriqueParClient($clientId);

// Libellés des statuts (tout statut inconnu est mis en forme automatiquement : « en_attente » => « En attente »)
$libellesStatuts = ['actif' => 'Actif', 'en_attente' => 'En attente', 'expire' => 'Expiré', 'epuise' => 'Épuisé', 'annule' => 'Annulé', 'termine' => 'Terminé'];
$libelleStatut = fn(string $s): string => $libellesStatuts[$s] ?? ucfirst(str_replace('_', ' ', $s));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Historique de mes abonnements — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/abonnement-client.css">
    <link rel="stylesheet" href="../../public/css/portail-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/portail-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/abonnement-historique.css">
    <link rel="stylesheet" href="../../public/css/theme.css">
    <script>document.documentElement.classList.add('js');</script>
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client">

    <a href="abonnement.php" class="abo-retour">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>
        Retour à mon abonnement
    </a>

    <div class="page-entete reveal">
        <div>
            <h1 class="page-entete__titre">Historique de mes abonnements</h1>
            <p class="page-entete__sous-titre">
                <?php if (!empty($historique)): ?>
                    <?= count($historique) ?> abonnement<?= count($historique) > 1 ? 's' : '' ?> au total, du plus récent au plus ancien.
                <?php else: ?>
                    Retrouvez ici tous vos abonnements passés et en cours.
                <?php endif; ?>
            </p>
        </div>
    </div>

    <?php if (empty($historique)): ?>
        <div class="abo-hist-vide reveal">
            <h2>Aucun abonnement pour le moment</h2>
            <p>Dès que vous aurez souscrit une formule, elle apparaîtra ici avec son détail.</p>
            <a href="abonnement.php" class="abo-btn abo-btn--plein">Découvrir les formules</a>
        </div>
    <?php else: ?>
        <section class="portail-section" aria-label="Liste de mes abonnements">
            <div class="portail-liste">
                <?php foreach ($historique as $i => $a):
                    $estActif = (int) $a['id'] === $idActif;
                    $statut = $estActif ? 'actif' : (string) ($a['statut'] ?? '');
                ?>
                    <article class="portail-carte reveal <?= $estActif ? 'abo-hist-carte--actif' : '' ?>" style="--i:<?= min((int) $i, 8) ?>">
                        <div class="portail-carte__contenu">
                            <div class="portail-carte__ligne">
                                <h3><?= h($a['formule_nom']) ?></h3>
                                <span class="portail-statut <?= $estActif ? 'abo-hist-statut--ok' : '' ?>"><?= h($libelleStatut($statut)) ?></span>
                            </div>

                            <p>
                                <?= number_format((float) ($a['montant_achat'] ?? 0), 0, ',', ' ') ?> F CFA
                                ·
                                <?php if (isset($a['nombre_credits'])): ?>
                                    <?= (int) $a['credits_restants'] ?> / <?= (int) $a['nombre_credits'] ?> crédit(s) restant(s)
                                <?php else: ?>
                                    <?= (int) $a['credits_restants'] ?> crédit(s) restant(s)
                                <?php endif; ?>
                            </p>
                            <p>
                                Acheté le <?= date('d/m/Y', strtotime($a['date_creation'])) ?>
                                <?php if (!empty($a['date_fin'])): ?>
                                    · Valable jusqu'au <?= date('d/m/Y', strtotime($a['date_fin'])) ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
</main>

<script>
(function () {
    // Apparition au défilement
    var reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var els = document.querySelectorAll('.reveal');
    if (reduit || !('IntersectionObserver' in window)) {
        els.forEach(function (e) { e.classList.add('reveal--visible'); });
        return;
    }
    var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
            if (en.isIntersecting) { en.target.classList.add('reveal--visible'); io.unobserve(en.target); }
        });
    }, { threshold: 0.1 });
    els.forEach(function (e) { io.observe(e); });
})();
</script>
</body>
</html>