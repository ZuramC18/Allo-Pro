<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/TicketSav.php';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

if (empty($_SESSION['csrf_sav_client'])) {
    $_SESSION['csrf_sav_client'] = bin2hex(random_bytes(32));
}

$clientId = (int) $_SESSION['user_id'];
$sav = new TicketSav();
$erreur = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $demandeId = filter_var($_POST['demande_id'] ?? null, FILTER_VALIDATE_INT);
    $motif = is_string($_POST['motif'] ?? null) ? trim($_POST['motif']) : '';

    if (!hash_equals($_SESSION['csrf_sav_client'], $csrf)) {
        $erreur = 'Votre session a expiré. Rechargez la page puis réessayez.';
    } elseif (!$demandeId || $motif === '' || mb_strlen($motif) > 100) {
        $erreur = 'Choisissez un dossier et indiquez un motif de 100 caractères maximum.';
    } elseif ($sav->creerPourClient((int) $demandeId, $clientId, $motif)) {
        $_SESSION['csrf_sav_client'] = bin2hex(random_bytes(32));
        header('Location: sav.php?ticket=cree');
        exit;
    } else {
        $erreur = 'Ce dossier ne permet pas de créer un ticket SAV ou possède déjà un ticket.';
    }
}

$tickets = $sav->getByClient($clientId);
$demandesEligibles = $sav->getDemandesEligibleClient($clientId);
$libellesStatuts = ['ouvert' => 'Ouvert', 'en_cours' => 'En cours', 'resolu' => 'Résolu'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mon SAV — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/portail-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/portail-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>
<main class="page-client portail-client">
    <header class="portail-entete">
        <div>
            <p class="portail-sur-titre">BESOIN D’AIDE</p>
            <h1>Mon SAV</h1>
            <p>Ouvrez un ticket à propos d’une intervention terminée et suivez son état d’avancement.</p>
        </div>
        <a class="portail-action portail-action--secondaire" href="messagerie.php">Écrire à l’assistance</a>
    </header>

    <?php if (($_GET['ticket'] ?? '') === 'cree'): ?>
        <div class="portail-alerte portail-alerte--succes" role="status">Votre demande SAV a été transmise.</div>
    <?php endif; ?>
    <?php if ($erreur !== ''): ?>
        <div class="portail-alerte" role="alert"><?= h($erreur) ?></div>
    <?php endif; ?>

    <?php if ($demandesEligibles): ?>
        <section class="portail-formulaire">
            <h2>Créer une demande SAV</h2>
            <form method="post">
                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf_sav_client']) ?>">
                <label for="demande-id">Intervention concernée</label>
                <select id="demande-id" name="demande_id" required>
                    <option value="">Choisir un dossier</option>
                    <?php foreach ($demandesEligibles as $demande): ?>
                        <option value="<?= (int) $demande['id'] ?>"><?= !empty($demande['est_demande_entreprise']) ? 'Demande venant d’une entreprise · ' : '' ?>Dossier <?= h($demande['numero_dossier']) ?> — <?= h($demande['categorie_nom']) ?></option>
                    <?php endforeach; ?>
                </select>
                <label for="motif-sav">Motif</label>
                <input id="motif-sav" name="motif" type="text" maxlength="100" required placeholder="Décrivez brièvement votre demande">
                <button class="portail-action" type="submit">Envoyer au SAV</button>
            </form>
        </section>
    <?php endif; ?>

    <section class="portail-section" aria-labelledby="tickets-titre">
        <h2 id="tickets-titre">Mes tickets</h2>
        <?php if ($tickets): ?>
            <div class="portail-liste">
                <?php foreach ($tickets as $ticket): ?>
                    <article class="portail-carte portail-carte--ticket">
                        <div class="portail-carte__contenu">
                            <div class="portail-carte__ligne">
                                <h3>Dossier <?= h($ticket['numero_dossier']) ?> · <?= h($ticket['categorie_nom']) ?></h3>
                                <?php if (!empty($ticket['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($ticket['entreprise_b2b_nom']) ? ' · ' . h($ticket['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                                <span class="portail-statut"><?= h($libellesStatuts[$ticket['statut']] ?? 'En cours') ?></span>
                            </div>
                            <p><strong>Motif :</strong> <?= h($ticket['motif']) ?></p>
                            <p>Ouvert le <?= date('d/m/Y', strtotime($ticket['date_creation'])) ?></p>
                        </div>
                        <a class="portail-action portail-action--secondaire" href="detail-demande.php?id=<?= (int) $ticket['demande_id'] ?>">Voir le dossier</a>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="portail-vide">
                <h3>Aucun ticket SAV</h3>
                <p>Les tickets créés apparaîtront ici. Un dossier ne peut avoir qu’un seul ticket SAV.</p>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
