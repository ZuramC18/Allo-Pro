<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Notification.php';

if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

function destinationNotificationClient(array $notification): string {
    $lien = is_string($notification['lien'] ?? null) ? $notification['lien'] : '';
    $url = parse_url($lien);
    $chemin = is_array($url) ? (string) ($url['path'] ?? '') : '';

    if (basename($chemin) === 'payer.php') {
        parse_str((string) ($url['query'] ?? ''), $parametres);
        $demandeId = filter_var($parametres['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($demandeId !== false && $demandeId !== null) {
            return '../client/detail-demande.php?id=' . $demandeId;
        }
    }

    return $lien !== '' ? $lien : '../client/notifications.php';
}

$notifications = (new Notification())->getToutesPourUtilisateur((int) $_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes notifications — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
    <link rel="stylesheet" href="../../public/css/notifications-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/notifications-client.css') ?>">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>
<main class="page-client">
    <section class="notifications-page" aria-labelledby="notifications-titre">
        <div class="notifications-page__entete">
            <div>
                <p class="notifications-page__surtitre">Votre espace</p>
                <h1 id="notifications-titre">Mes notifications</h1>
                <p>Invitations, demandes de paiement, confirmations et actualités de vos interventions.</p>
            </div>
            <a href="accueil.php" class="notifications-page__retour">Retour au tableau de bord</a>
        </div>

        <?php if (!$notifications): ?>
            <div class="notifications-page__vide">
                <span aria-hidden="true">
                    <svg viewBox="0 0 24 24"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>
                </span>
                <h2>Vous êtes à jour</h2>
                <p>Vos nouvelles notifications apparaîtront ici.</p>
            </div>
        <?php else: ?>
            <div class="notifications-page__liste">
                <?php foreach ($notifications as $notification):
                    $lienNotification = '../../public/marquer-notification-lue.php?' . http_build_query([
                        'id' => (int) $notification['id'],
                        'redirection' => destinationNotificationClient($notification),
                    ]);
                    $dateNotification = strtotime((string) $notification['date_creation']);
                ?>
                    <a class="notifications-page__item<?= (int) $notification['lu'] === 0 ? ' notifications-page__item--non-lue' : '' ?>"
                       href="<?= h($lienNotification) ?>">
                        <span class="notifications-page__icone" aria-hidden="true">
                            <svg viewBox="0 0 24 24"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>
                        </span>
                        <span class="notifications-page__texte">
                            <span><?= h($notification['message']) ?></span>
                            <?php if ($dateNotification !== false): ?>
                                <time datetime="<?= h(date(DATE_ATOM, $dateNotification)) ?>"><?= h(date('d/m/Y à H:i', $dateNotification)) ?></time>
                            <?php endif; ?>
                        </span>
                        <?php if ((int) $notification['lu'] === 0): ?><span class="notifications-page__nouvelle">Non lue</span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
