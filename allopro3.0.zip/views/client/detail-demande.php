<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/Note.php';
require_once __DIR__ . '/../../includes/icones.php';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$demande = $id ? (new Demande())->getById($id) : null;

if (!$demande || $demande['site_b2b_id'] !== null || (int) $demande['client_id'] !== (int) $_SESSION['user_id']) {
    http_response_code(404);
    die("Cette demande est introuvable.");
}

$intervention = (new Intervention())->getByDemandeId($id);
$paiement = (new Paiement())->getByDemandeId($id);
$avisEnvoye = (new Note())->existePour($id);

$libellesStatuts = [
    'nouvelle' => 'Nouvelle',
    'attribuee' => 'Attribuée',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$libellesMissions = [
    'en_attente' => 'En attente de réponse du technicien',
    'acceptee' => 'Mission acceptée',
    'refusee' => 'Réaffectation en attente du coordinateur',
    'en_route' => 'Technicien en route',
    'arrive' => 'Technicien arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'Intervention en cours',
    'terminee' => 'Intervention terminée',
];
$etapes = [
    ['statut' => 'nouvelle', 'titre' => 'Demande envoyée'],
    ['statut' => 'attribuee', 'titre' => 'Technicien attribué'],
    ['statut' => 'en_cours', 'titre' => 'Intervention en cours'],
    ['statut' => 'terminee', 'titre' => 'Intervention terminée'],
];
$indexEtape = array_search($demande['statut'], array_column($etapes, 'statut'), true);
$demandeAnnulee = $demande['statut'] === 'annulee';
$paiementCouvert = $demande['statut'] === 'terminee' && $demande['mode_paiement'] !== 'normal';
$montantIntervention = isset($demande['montant']) ? (float) $demande['montant'] : 0.0;
$doitPayer = $demande['statut'] === 'terminee' && !$paiementCouvert && $montantIntervention > 0;
$paiementValide = $paiement && $paiement['statut'] === 'valide';
$paiementEnAttente = $paiement && $paiement['statut'] === 'en_attente';
$paiementEchoue = $paiement && $paiement['statut'] === 'echoue';
$libellesMoyens = ['wave' => 'Wave', 'orange_money' => 'Orange Money'];
$methodePaiement = $paiement
    ? ($libellesMoyens[$paiement['methode']] ?? 'Paiement mobile')
    : null;
$nomTechnicien = $intervention['technicien_nom_reel'] ?? $intervention['technicien_nom'] ?? null;
$adresse = trim(($demande['quartier'] ?? '') . ', ' . ($demande['ville'] ?? ''), ', ');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dossier <?= h($demande['numero_dossier']) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/detail-demande-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/detail-demande-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
</head>
<body class="page-detail-demande">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client detail-demande">
    <a class="detail-retour" href="mes-demandes.php">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5m7 7-7-7 7-7"/></svg>
        Retour à mes demandes
    </a>

    <header class="detail-hero">
        <div class="detail-hero__contenu">
            <span class="detail-hero__sur-titre">Suivi de votre intervention</span>
            <h1><?= h($demande['numero_dossier']) ?></h1>
            <p><?= h($demande['categorie_nom']) ?> <span aria-hidden="true">·</span> Créée le <?= date('d/m/Y à H:i', strtotime($demande['date_creation'])) ?></p>
        </div>
        <span class="detail-statut detail-statut--<?= h($demande['statut']) ?>">
            <span class="detail-statut__point" aria-hidden="true"></span>
            <?= h($libellesStatuts[$demande['statut']] ?? ucfirst(str_replace('_', ' ', $demande['statut']))) ?>
        </span>
    </header>

    <?php if ($demandeAnnulee): ?>
        <div class="detail-annulation" role="status">
            <strong>Cette demande a été annulée.</strong>
            Si vous avez besoin d’une intervention, vous pouvez créer une nouvelle demande.
        </div>
    <?php else: ?>
        <section class="detail-progression" aria-label="Progression de la demande">
            <?php foreach ($etapes as $index => $etape):
                $etatEtape = $indexEtape !== false
                    && ($index < $indexEtape || $demande['statut'] === 'terminee')
                    ? 'terminee'
                    : ($index === $indexEtape ? 'active' : 'a-venir');
            ?>
                <div class="detail-progression__etape detail-progression__etape--<?= $etatEtape ?>">
                    <span class="detail-progression__repere" aria-hidden="true">
                        <?php if ($etatEtape === 'terminee'): ?>
                            <svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg>
                        <?php else: ?>
                            <?= $index + 1 ?>
                        <?php endif; ?>
                    </span>
                    <span class="detail-progression__titre"><?= h($etape['titre']) ?></span>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <div class="detail-grille">
        <div class="detail-colonne">
            <section class="detail-carte" aria-labelledby="titre-demande">
                <div class="detail-carte__entete">
                    <span class="detail-carte__icone" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M5 4h14v16H5z"/><path d="M8 8h8m-8 4h8m-8 4h5"/></svg>
                    </span>
                    <div>
                        <h2 id="titre-demande">Votre demande</h2>
                        <p>Les informations transmises à notre équipe</p>
                    </div>
                </div>

                <dl class="detail-infos">
                    <div class="detail-info">
                        <dt>Catégorie</dt>
                        <dd><?= h($demande['categorie_nom']) ?></dd>
                    </div>
                    <div class="detail-info">
                        <dt>Adresse d’intervention</dt>
                        <dd><?= h($adresse ?: 'Adresse non précisée') ?>
                            <?php if (!empty($demande['adresse_details'])): ?>
                                <small><?= h($demande['adresse_details']) ?></small>
                            <?php endif; ?>
                        </dd>
                    </div>
                    <div class="detail-info">
                        <dt>Niveau d’urgence</dt>
                        <dd><span class="detail-urgence detail-urgence--<?= h($demande['urgence']) ?>"><?= h(ucfirst($demande['urgence'])) ?></span></dd>
                    </div>
                    <?php if (!empty($demande['date_creneau_souhaite']) && $demande['heure_creneau_souhaitee'] !== null): ?>
                        <div class="detail-info">
                            <dt>Créneau souhaité</dt>
                            <dd><?= h(date('d/m/Y', strtotime($demande['date_creneau_souhaite']))) ?> · <?= sprintf('%02d:00–%02d:00', (int) $demande['heure_creneau_souhaitee'], (int) $demande['heure_creneau_souhaitee'] + 1) ?> <small>À confirmer par l’équipe</small></dd>
                        </div>
                    <?php endif; ?>
                    <div class="detail-info detail-info--description">
                        <dt>Description du problème</dt>
                        <dd><?= nl2br(h($demande['description'])) ?></dd>
                    </div>
                </dl>

                <?php if (!empty($demande['photo_path'])): ?>
                    <div class="detail-photo">
                        <h3>Photo jointe à la demande</h3>
                        <a href="/allopro/public/<?= h($demande['photo_path']) ?>" target="_blank" rel="noopener">
                            <img src="/allopro/public/<?= h($demande['photo_path']) ?>" alt="Photo jointe à votre demande">
                            <span>Ouvrir la photo</span>
                        </a>
                    </div>
                <?php endif; ?>
            </section>

            <?php if ($intervention): ?>
                <section class="detail-carte" aria-labelledby="titre-intervention">
                    <div class="detail-carte__entete">
                        <span class="detail-carte__icone detail-carte__icone--equipe" aria-hidden="true">
                            <svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0m3-9v6m-3-3h6"/></svg>
                        </span>
                        <div>
                            <h2 id="titre-intervention">Votre intervention</h2>
                            <p>Informations de suivi de la mission</p>
                        </div>
                    </div>

                    <dl class="detail-infos">
                        <div class="detail-info">
                            <dt>Technicien</dt>
                            <dd><?= h($nomTechnicien ?: 'En cours d’attribution') ?></dd>
                        </div>
                        <?php if (!empty($intervention['nom_entreprise'])): ?>
                            <div class="detail-info">
                                <dt>Partenaire</dt>
                                <dd><?= h($intervention['nom_entreprise']) ?></dd>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($intervention['statut'])): ?>
                            <div class="detail-info">
                                <dt>Étape de la mission</dt>
                                <dd><span class="detail-mission-statut"><?= h($libellesMissions[$intervention['statut']] ?? ucfirst(str_replace('_', ' ', $intervention['statut']))) ?></span></dd>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($intervention['date_debut'])): ?>
                            <div class="detail-info">
                                <dt>Début de la mission</dt>
                                <dd><?= date('d/m/Y à H:i', strtotime($intervention['date_debut'])) ?></dd>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($intervention['date_fin'])): ?>
                            <div class="detail-info">
                                <dt>Intervention terminée le</dt>
                                <dd><?= date('d/m/Y à H:i', strtotime($intervention['date_fin'])) ?></dd>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($intervention['rapport'])): ?>
                            <div class="detail-info detail-info--description">
                                <dt>Compte rendu du technicien</dt>
                                <dd><?= nl2br(h($intervention['rapport'])) ?></dd>
                            </div>
                        <?php endif; ?>
                    </dl>

                    <?php if (!empty($intervention['photo_avant']) || !empty($intervention['photo_apres'])): ?>
                        <div class="detail-photos-mission">
                            <?php foreach (['photo_avant' => 'Avant intervention', 'photo_apres' => 'Après intervention'] as $clePhoto => $titrePhoto): ?>
                                <?php if (!empty($intervention[$clePhoto])): ?>
                                    <a href="/allopro/public/<?= h($intervention[$clePhoto]) ?>" target="_blank" rel="noopener">
                                        <img src="/allopro/public/<?= h($intervention[$clePhoto]) ?>" alt="<?= h($titrePhoto) ?>">
                                        <span><?= h($titrePhoto) ?></span>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>
        </div>

        <aside class="detail-colonne detail-colonne--secondaire">
            <section class="detail-carte detail-facturation" aria-labelledby="titre-facturation">
                <div class="detail-carte__entete">
                    <span class="detail-carte__icone detail-carte__icone--paiement" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path d="M4 5h16v14H4z"/><path d="M4 9h16m-12 5h4"/></svg>
                    </span>
                    <div>
                        <h2 id="titre-facturation">Paiement</h2>
                        <p>Récapitulatif de facturation</p>
                    </div>
                </div>

                <?php if ($paiementCouvert): ?>
                    <div class="detail-facturation__etat detail-facturation__etat--couvert">
                        <?= icone('check', 16) ?>
                        <div>
                            <strong>Aucun paiement à effectuer</strong>
                            <p>Cette intervention est couverte par <?= $demande['mode_paiement'] === 'abonnement' ? 'votre abonnement' : 'votre Pass' ?>.</p>
                        </div>
                    </div>
                <?php elseif ($paiementValide): ?>
                    <div class="detail-facturation__etat detail-facturation__etat--paye">
                        <?= icone('check', 16) ?>
                        <div>
                            <strong>Paiement confirmé</strong>
                            <p>Votre intervention a été réglée.</p>
                        </div>
                    </div>
                    <div class="detail-facturation__montant">
                        <span>Montant payé</span>
                        <strong><?= number_format((float) $paiement['montant'], 0, ',', ' ') ?><small> FCFA</small></strong>
                    </div>
                    <div class="detail-facturation__methode">
                        <span>Moyen de paiement</span>
                        <strong><?= h($methodePaiement) ?></strong>
                    </div>
                <?php elseif ($doitPayer): ?>
                    <div class="detail-facturation__etat detail-facturation__etat--<?= $paiementEchoue ? 'erreur' : ($paiementEnAttente ? 'attente' : 'a-payer') ?>">
                        <?= icone($paiementEchoue ? 'alert' : ($paiementEnAttente ? 'clock' : 'wallet'), 16) ?>
                        <div>
                            <strong><?= $paiementEchoue ? 'Paiement non abouti' : ($paiementEnAttente ? 'Paiement en attente' : 'Paiement requis') ?></strong>
                            <p>
                                <?= $paiementEchoue
                                    ? 'La dernière tentative n’a pas été confirmée. Vous pouvez réessayer.'
                                    : ($paiementEnAttente
                                        ? 'Votre paiement via ' . $methodePaiement . ' est en cours de confirmation.'
                                        : 'Le montant de l’intervention est à régler.') ?>
                            </p>
                        </div>
                    </div>
                    <div class="detail-facturation__montant">
                        <span>Montant à régler</span>
                        <strong><?= number_format($montantIntervention, 0, ',', ' ') ?><small> FCFA</small></strong>
                    </div>
                    <?php if ($paiementEnAttente): ?>
                        <div class="detail-facturation__methode">
                            <span>Moyen sélectionné</span>
                            <strong><?= h($methodePaiement) ?></strong>
                        </div>
                    <?php endif; ?>
                    <a class="detail-action-paiement" href="payer.php?id=<?= (int) $id ?>">
                        <?= $paiementEnAttente ? 'Reprendre le paiement' : ($paiementEchoue ? 'Réessayer le paiement' : 'Payer maintenant') ?>
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
                    </a>
                <?php elseif ($demande['statut'] === 'terminee'): ?>
                    <div class="detail-facturation__etat detail-facturation__etat--couvert">
                        <?= icone('check', 16) ?>
                        <div>
                            <strong>Aucun paiement à effectuer</strong>
                            <p>Aucun montant n’a été facturé pour cette intervention.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="detail-facturation__etat detail-facturation__etat--information">
                        <span aria-hidden="true">i</span>
                        <div>
                            <strong>Aucun paiement demandé pour le moment</strong>
                            <p>Les frais éventuels seront indiqués à la clôture de l’intervention.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </section>

            <section class="detail-aide">
                <span class="detail-aide__icone" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/></svg>
                </span>
                <div>
                    <strong>Une question sur votre demande ?</strong>
                    <p>Notre équipe peut vous aider à suivre votre intervention.</p>
                    <a href="messagerie.php">Contacter l’équipe <span aria-hidden="true">→</span></a>
                </div>
            </section>
        </aside>
    </div>

    <?php if ($avisEnvoye): ?>
        <div class="detail-avis-invitation" role="status">
            <span>Merci, votre avis a bien été transmis.</span>
        </div>
    <?php elseif ($demande['statut'] === 'terminee'): ?>
        <div class="detail-avis-invitation" id="laisser-avis">
            <span>Votre intervention est terminée. Votre retour nous aide à améliorer le service.</span>
            <a href="mes-demandes.php?statut=terminee#demande-<?= (int) $id ?>">Laisser un avis</a>
        </div>
    <?php endif; ?>
</main>
</body>
</html>
