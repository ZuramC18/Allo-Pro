<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Message.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../includes/icones.php';

// Échappement HTML sûr (accepte null)
if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$clientId = (int) $_SESSION['user_id'];

$userModel = new User();
$moi = $userModel->getById($clientId);

$messageModel = new Message();
$messages = $messageModel->getByClient($clientId);
$messageModel->marquerLues($clientId, 'client');

$conversationOuverte = ($moi['conversation_statut'] ?? '') === 'ouverte';
$conversationEnAttente = $conversationOuverte && empty($moi['conseiller_assigne_id']);
$erreurReouverture = ($_GET['erreur'] ?? '') === 'reouverture';

// Zone de saisie : un seul gabarit, utilisé à l'affichage ET pour la réouverture dynamique (voir <template>)
$saisieHtml = <<<'HTML'
<div class="fil__pied">
    <div class="composer__image-apercu" id="apercu-image" hidden>
        <img id="apercu-image-img" alt="Aperçu de l’image jointe">
        <span id="apercu-image-nom"></span>
        <button type="button" id="retirer-image" aria-label="Retirer l’image jointe" title="Retirer l’image">×</button>
    </div>
    <div class="composer__voice-apercu" id="apercu-voice" hidden>
        <div class="composer__voice-meta">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a3 3 0 0 1 3 3v6a3 3 0 1 1-6 0V6a3 3 0 0 1 3-3Z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v3"/><path d="M8 21h8"/></svg>
            <span id="apercu-voice-nom" aria-live="polite">Note vocale</span>
            <span id="apercu-voice-duree" class="composer__voice-duree" aria-label="Durée">00:00</span>
        </div>
        <audio id="apercu-voice-audio" controls controlsList="nodownload noplaybackrate" playsinline preload="metadata"></audio>
        <button type="button" id="retirer-voice" aria-label="Retirer la note vocale" title="Retirer">×</button>
    </div>
    <div class="composer">
        <div class="composer__media-wrap">
            <button type="button" id="btn-plus-media" class="composer__plus" aria-label="Ajouter un média" title="Ajouter une image ou une note vocale">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
            </button>
            <div class="composer__media-actions" id="media-actions" hidden>
                <label class="composer__joindre" title="Joindre une image">
                    <input type="file" id="champ-image" class="composer__image-input" accept="image/jpeg,image/png,image/webp" aria-label="Choisir une image à joindre">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h13A2.5 2.5 0 0 1 21 7.5v9A2.5 2.5 0 0 1 18.5 19h-13A2.5 2.5 0 0 1 3 16.5v-9Z"/><path d="M8.5 14.5 11 12l2.5 3 2.5-3 3 4.5"/><circle cx="9" cy="9" r="1.5"/></svg>
                </label>
            </div>
        </div>
        <button type="button" id="btn-enregistrer-audio" class="composer__btn-voice" aria-label="Enregistrer une note vocale" title="Note vocale">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a3 3 0 0 1 3 3v6a3 3 0 1 1-6 0V6a3 3 0 0 1 3-3Z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v3"/><path d="M8 21h8"/></svg>
        </button>
        <textarea id="champ-message" rows="1" maxlength="2000" placeholder="Écrire un message..."
                  aria-label="Votre message" aria-describedby="aide-saisie" autocomplete="off" enterkeyhint="send"></textarea>
        <span class="composer__compteur" id="compteur-message" aria-live="polite" hidden></span>
        <button type="button" id="btn-envoyer" aria-label="Envoyer le message" title="Envoyer (Entrée)">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/></svg>
        </button>
    </div>
    <p class="composer__aide" id="aide-saisie"><kbd>Entrée</kbd> pour envoyer · <kbd>Maj</kbd> + <kbd>Entrée</kbd> pour passer à la ligne</p>
</div>
HTML;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messages — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/messagerie-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/messagerie-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/lecteur-note-vocale.css?v=<?= filemtime(__DIR__ . '/../../public/css/lecteur-note-vocale.css') ?>">
    <link rel="stylesheet" href="../../public/css/appels-web.css?v=<?= filemtime(__DIR__ . '/../../public/css/appels-web.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
</head>
<body class="messagerie-page">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client page-messagerie-client">
    <div class="messagerie">
        <section class="fil" aria-label="Conversation avec l'assistance">

            <header class="fil__entete">
                <div class="fil__entete-avatar" aria-hidden="true">AP</div>
                <div>
                    <div class="fil__titre">ALLÔ PRO — Assistance</div>
                    <div class="fil__soustitre">Un conseiller vous répond généralement sous quelques minutes</div>
                </div>
            </header>
            <div class="fil__attente" id="statut-conversation" role="status" aria-live="polite" <?= $conversationEnAttente ? '' : 'hidden' ?>>
                Votre conversation est en attente d’un conseiller. Vous pouvez déjà écrire votre message.
            </div>
            <?php if ($erreurReouverture): ?>
                <div class="fil__attente fil__attente--erreur" role="alert">La conversation n’a pas pu être rouverte. Réessayez ou contactez notre équipe.</div>
            <?php endif; ?>

            <div class="fil__zone">
                <div class="fil__corps" id="fil-corps" role="log" aria-live="polite" aria-label="Messages"
                     data-retour="dashboard.php"
                     data-conversation-ouverte="<?= $conversationOuverte ? '1' : '0' ?>"
                     data-client-id="<?= $clientId ?>"
                     data-viewer="client"
                     data-viewer-id="<?= $clientId ?>"
                     data-csrf="<?= h($_SESSION['csrf']) ?>">

                    <?php if (empty($messages)): ?>
                        <div class="fil-vide" id="fil-vide">
                            <div class="fil-vide__icone" aria-hidden="true"><?= icone('messages', 34) ?></div>
                            <h2 class="fil-vide__titre">Une question ? Écrivez-nous</h2>
                            <p class="fil-vide__texte">Nos conseillers vous aident pour le suivi de vos interventions, vos paiements et vos demandes.</p>
                            <?php if ($conversationOuverte): ?>
                                <div class="fil-vide__suggestions">
                                    <button type="button" class="fil-vide__puce" data-suggestion="Bonjour, j'aimerais avoir des nouvelles de ma demande.">Suivi de ma demande</button>
                                    <button type="button" class="fil-vide__puce" data-suggestion="Bonjour, j'ai une question concernant le paiement.">Question de paiement</button>
                                    <button type="button" class="fil-vide__puce" data-suggestion="Bonjour, je souhaite modifier ma demande.">Modifier ma demande</button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php $jourPrecedent = null; ?>
                    <?php foreach ($messages as $m): ?>
                        <?php $jourCourant = date('Y-m-d', strtotime($m['date_creation'])); ?>
                        <?php if ($jourCourant !== $jourPrecedent): ?>
                            <div class="fil__separateur-jour"><span><?= h(libelleJourConversation($m['date_creation'])) ?></span></div>
                            <?php $jourPrecedent = $jourCourant; ?>
                        <?php endif; ?>
                        <div class="bulle <?= $m['expediteur_type'] === 'client' ? 'bulle--moi' : 'bulle--autre' ?>"
                            data-id="<?= (int) $m['id'] ?>"
                            data-jour="<?= h($jourCourant) ?>"
                            data-expediteur-type="<?= h($m['expediteur_type']) ?>"
                            data-expediteur-id="<?= (int) $m['expediteur_id'] ?>"
                            data-lu="<?= (int) $m['lu'] ?>"
                            data-lu-date="<?= h($m['lu_date'] ?? '') ?>"
                            data-modifie="<?= (int) $m['modifie'] ?>">
                            <div class="bulle__meta">
                                <?= h($m['nom_expediteur'] ?? ucfirst($m['expediteur_type'])) ?> · <?= date('H:i', strtotime($m['date_creation'])) ?>
                                <?= $m['modifie'] ? ' · <span class="bulle__modifie">modifié</span>' : '' ?>
                            </div>
                            <?php if (!empty($m['image_path'])): ?>
                                <a class="bulle__piece-jointe" href="../../public/<?= h($m['image_path']) ?>" target="_blank" rel="noopener">
                                    <img class="bulle__image" src="../../public/<?= h($m['image_path']) ?>" alt="Image jointe au message" loading="lazy">
                                </a>
                            <?php endif; ?>
                            <?php if (!empty($m['audio_path'])): ?>
                                <audio class="bulle__audio" playsinline preload="metadata" aria-label="Lire la note vocale" title="Note vocale" src="../../public/<?= h($m['audio_path']) ?>"></audio>
                            <?php endif; ?>
                            <?php if (trim((string) $m['contenu']) !== ''): ?><div class="bulle__texte"><?= nl2br(h($m['contenu'])) ?></div><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <button type="button" class="btn-nouveaux" id="btn-nouveaux" hidden>↓ Nouveau message</button>
            </div>

            <div id="zone-saisie">
                <?php if ($conversationOuverte): ?>
                    <?= $saisieHtml ?>
                <?php else: ?>
                    <div class="fil__fermee">
                        <p>Cette conversation est clôturée.</p>
                        <form method="POST" action="../../public/reouvrir-conversation.php" id="form-reouvrir">
                            <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
                            <button type="submit" class="fil__reouvrir">Réouvrir la conversation</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!$conversationOuverte): ?>
                <!-- Gabarit injecté par le JS quand le client réouvre la conversation, sans recharger la page -->
                <template id="tpl-saisie"><?= $saisieHtml ?></template>
            <?php endif; ?>
        </section>
    </div>
</main>

<!-- Menu contextuel (clic droit / appui long sur un message) -->
<div class="menu-contextuel" id="menu-contextuel" role="menu" style="display:none;">
    <button type="button" role="menuitem" class="menu-contextuel__item" id="btn-copier">Copier le texte</button>
</div>

<?php include __DIR__ . '/../../includes/messagerie-appel-interface.php'; ?>
<script src="../../public/js/messagerie.js?v=<?= filemtime(__DIR__ . '/../../public/js/messagerie.js') ?>"></script>
<script src="../../public/js/conversation-status.js?v=<?= filemtime(__DIR__ . '/../../public/js/conversation-status.js') ?>"></script>
<script src="../../public/js/lecteur-note-vocale.js?v=<?= filemtime(__DIR__ . '/../../public/js/lecteur-note-vocale.js') ?>"></script>
<script src="../../public/js/appels-web.js?v=<?= filemtime(__DIR__ . '/../../public/js/appels-web.js') ?>"></script>
</body>
</html>