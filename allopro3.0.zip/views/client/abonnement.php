<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Abonnement.php';
require_once __DIR__ . '/../../includes/icones.php';

$abonnementModel = new Abonnement();
$erreur = '';
$methodesValides = ['wave', 'orange_money'];

$abonnementActif = $abonnementModel->getActifParClient($_SESSION['user_id']);
$nbHistorique = count($abonnementModel->getHistoriqueParClient((int) $_SESSION['user_id']));

// Plus de crédit : le client peut choisir un nouvel abonnement ou acheter un Pass
$creditsEpuises = $abonnementActif && (int)$abonnementActif['credits_restants'] <= 0;
$peutSouscrire  = !$abonnementActif || $creditsEpuises;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formuleId = filter_input(INPUT_POST, 'formule_id', FILTER_VALIDATE_INT);
    $methode   = $_POST['methode'] ?? '';
    $formule   = $formuleId ? $abonnementModel->getFormuleById($formuleId) : null;

    if ($abonnementActif && !$creditsEpuises) {
        $erreur = "Vous avez déjà un abonnement actif.";
    } elseif (!$formule) {
        $erreur = "Cette formule n'existe pas ou n'est plus disponible.";
    } elseif (!in_array($methode, $methodesValides, true)) {
        $erreur = "Choisissez Wave ou Orange Money pour continuer.";
    } else {
        $reference = $abonnementModel->creerDemandeSouscription($_SESSION['user_id'], $formuleId);
        $page = $methode === 'wave' ? 'simulation-wave.php' : 'simulation-orange.php';
        header("Location: /allopro/public/{$page}?reference=" . urlencode($reference)
            . "&montant=" . urlencode($formule['prix']) . "&type=abonnement");
        exit;
    }
}

$formules = $abonnementModel->getFormulesActives();
$nbFormules = count($formules);

// Données de l'abonnement actif
if ($abonnementActif) {
    $total      = max(1, (int)$abonnementActif['nombre_credits']);
    $restants   = (int)$abonnementActif['credits_restants'];
    $utilises   = $total - $restants;
    $pourcent   = max(0, min(100, ($restants / $total) * 100));
    $joursRest  = max(0, (int)ceil((strtotime($abonnementActif['date_fin']) - time()) / 86400));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mon abonnement — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/adresses.css">
    <link rel="stylesheet" href="../../public/css/abonnement-client.css">
    <link rel="stylesheet" href="../../public/css/portail-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/portail-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
    <link rel="stylesheet" href="../../public/css/abonnement-historique.css">
    <script>document.documentElement.classList.add('js');</script>
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client" <?= !$abonnementActif ? 'id="credits-restants"' : '' ?>>
    <div class="page-entete reveal">
        <div>
            <a href="abonnement-historique.php" class="abo-historique-lien">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/></svg>
                Historique de mes abonnements
                <?php if ($nbHistorique > 0): ?><span class="abo-historique-lien__nb"><?= $nbHistorique ?></span><?php endif; ?>
            </a>
            <h1 class="page-entete__titre">Mon abonnement</h1>
            <p class="page-entete__sous-titre">Des interventions plafonnées, payées une fois par mois. Plus de mauvaise surprise sur la facture.</p>
        </div>
    </div>

    <?php if (isset($_GET['succes'])): ?>
        <div class="bandeau-succes"><?= icone('check', 16) ?> Abonnement activé avec succès ! Vous pouvez réserver dès maintenant.</div>
    <?php endif; ?>
    <?php if ($erreur): ?>
        <div class="abo-alerte" role="alert"><?= htmlspecialchars($erreur) ?></div>
    <?php endif; ?>

    <?php if ($abonnementActif): ?>
        <!-- ===== ABONNEMENT ACTIF ===== -->
        <section class="abo-actif reveal">
            <div class="abo-actif__haut">
                <div>
                    <span class="abo-actif__statut">● Actif</span>
                    <h2 class="abo-actif__formule"><?= htmlspecialchars($abonnementActif['formule_nom']) ?></h2>
                    <p class="abo-actif__expire">Valable jusqu'au <?= date('d/m/Y', strtotime($abonnementActif['date_fin'])) ?></p>
                </div>
                <a href="/allopro/public/index.php#services" class="abo-btn abo-btn--clair">Réserver une intervention</a>
            </div>

            <div class="abo-actif__stats" id="credits-restants">
                <div class="abo-stat"><strong data-compte="<?= $restants ?>"><?= $restants ?></strong><span>crédit<?= $restants > 1 ? 's' : '' ?> restant<?= $restants > 1 ? 's' : '' ?></span></div>
                <div class="abo-stat"><strong data-compte="<?= $utilises ?>"><?= $utilises ?></strong><span>utilisé<?= $utilises > 1 ? 's' : '' ?></span></div>
                <div class="abo-stat"><strong data-compte="<?= $joursRest ?>"><?= $joursRest ?></strong><span>jour<?= $joursRest > 1 ? 's' : '' ?> restant<?= $joursRest > 1 ? 's' : '' ?></span></div>
            </div>

            <div class="progress-bar" role="progressbar" aria-valuenow="<?= $restants ?>" aria-valuemin="0" aria-valuemax="<?= $total ?>">
                <div class="progress-bar__remplissage" style="--cible:<?= round($pourcent, 1) ?>%;"></div>
            </div>
            <p class="abo-actif__label"><?= $restants ?> crédit(s) restant(s) sur <?= $total ?></p>

            <?php if ($creditsEpuises): ?>
                <p class="abo-actif__alerte">Tous vos crédits sont utilisés. Deux solutions ci-dessous pour continuer.</p>
            <?php elseif ($joursRest <= 5): ?>
                <p class="abo-actif__alerte">Votre abonnement se termine bientôt.</p>
            <?php endif; ?>
        </section>

        <?php if ($creditsEpuises): ?>
            <!-- ===== Lien vers le Pass ===== -->
            <aside class="abo-pass reveal">
                <div class="abo-pass__icone" aria-hidden="true"><?= icone('ticket', 28) ?></div>
                <div class="abo-pass__texte">
                    <strong>Besoin d'une intervention maintenant ?</strong>
                    <p>Achetez un Pass Intervention à l'unité, sans attendre le renouvellement de votre abonnement.</p>
                </div>
                <a href="pass.php" class="abo-btn abo-btn--plein">Acheter un Pass →</a>
            </aside>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($peutSouscrire): ?>
        <!-- ===== CHOIX DE FORMULE ===== -->
        <?php if ($nbFormules === 0): ?>
            <div class="abo-vide reveal">
                <h2>Aucune formule disponible pour le moment</h2>
                <p>Les formules d'abonnement reviendront bientôt. En attendant, vous pouvez réserver une intervention à l'unité.</p>
                <a href="/allopro/public/index.php#services" class="abo-btn abo-btn--plein">Voir les services</a>
            </div>
        <?php else: ?>
            <?php if ($creditsEpuises): ?>
                <h2 class="abo-titre-section" id="formules">Ou souscrivez à un nouvel abonnement</h2>
                <p class="abo-intro">Rechargez vos crédits avec une nouvelle formule, sans engagement.</p>
            <?php else: ?>
                <p class="abo-intro">Sans engagement, résiliable à tout moment. Choisissez la formule qui correspond à votre rythme.</p>
            <?php endif; ?>

            <div class="pricing-grille">
                <?php foreach ($formules as $i => $f):
                    $estRecommandee = $nbFormules >= 3 && $i === intdiv($nbFormules, 2);
                    $cats = $abonnementModel->getCategoriesEligibles($f['id']);
                    $nb = (int)$f['nombre_credits'];
                ?>
                    <div class="pricing-carte reveal <?= $estRecommandee ? 'pricing-carte--recommandee' : '' ?>" style="--i:<?= $i ?>;">
                        <?php if ($estRecommandee): ?><div class="pricing-carte__badge"><?= icone('star', 14) ?> Le plus choisi</div><?php endif; ?>

                        <h3 class="pricing-carte__nom"><?= htmlspecialchars($f['nom']) ?></h3>
                        <div class="pricing-carte__prix">
                            <?= number_format($f['prix'], 0, ',', ' ') ?>
                            <span class="pricing-carte__devise">FCFA</span>
                            <span class="pricing-carte__periode">/mois</span>
                        </div>
                        <p class="pricing-carte__desc"><?= htmlspecialchars($f['description']) ?></p>

                        <ul class="pricing-carte__liste">
                            <li><span class="pricing-check"><?= icone('check', 14) ?></span> <?= $nb ?> intervention<?= $nb > 1 ? 's' : '' ?> incluse<?= $nb > 1 ? 's' : '' ?></li>
                            <li><span class="pricing-check"><?= icone('check', 14) ?></span>
                                <?= empty($cats)
                                    ? 'Toutes catégories de service'
                                    : implode(', ', array_map(fn($c) => htmlspecialchars($c['nom']), $cats)) ?>
                            </li>
                            <li><span class="pricing-check"><?= icone('check', 14) ?></span> Support prioritaire</li>
                            <li><span class="pricing-check"><?= icone('check', 14) ?></span> Sans engagement</li>
                        </ul>

                        <form method="POST" class="pricing-carte__form">
                            <input type="hidden" name="formule_id" value="<?= (int)$f['id'] ?>">
                            <fieldset class="paiement">
                                <legend>Payer avec</legend>
                                <label class="paiement__choix paiement__choix--wave">
                                    <input type="radio" name="methode" value="wave" required>
                                    <span><img src="../../public/images/paiements/wave-logo.png" alt="">Wave</span>
                                </label>
                                <label class="paiement__choix paiement__choix--orange">
                                    <input type="radio" name="methode" value="orange_money" required>
                                    <span><img src="../../public/images/paiements/orange-money-logo.svg" alt="">Orange Money</span>
                                </label>
                            </fieldset>
                            <button type="submit" class="pricing-carte__bouton <?= $estRecommandee ? 'pricing-carte__bouton--plein' : '' ?>">
                                Souscrire pour <?= number_format($f['prix'], 0, ',', ' ') ?> FCFA
                            </button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- ===== COMMENT ÇA MARCHE ===== -->
            <section class="abo-etapes reveal">
                <h2>Comment ça marche</h2>
                <ol>
                    <li><strong>Choisissez</strong> une formule et réglez avec Wave ou Orange Money.</li>
                    <li><strong>Réservez</strong> vos interventions : chacune consomme un crédit.</li>
                    <li><strong>Suivez</strong> vos crédits et la date de fin depuis cette page.</li>
                </ol>
            </section>

            <!-- ===== FAQ ===== -->
            <section class="abo-faq reveal">
                <h2>Questions fréquentes</h2>
                <details>
                    <summary>Que se passe-t-il si je n'utilise pas tous mes crédits ?</summary>
                    <p>Les crédits sont valables pendant la durée de l'abonnement. Ils expirent à sa date de fin.</p>
                </details>
                <details>
                    <summary>Mon abonnement est-il renouvelé automatiquement ?</summary>
                    <p>Non. À la fin de la période, vous choisissez de souscrire à nouveau ou non.</p>
                </details>
                <details>
                    <summary>Mon paiement est-il sécurisé ?</summary>
                    <p>Le paiement passe par Wave ou Orange Money. Nous ne conservons aucun code secret.</p>
                </details>
                <details>
                    <summary>Quels services sont couverts ?</summary>
                    <p>Chaque formule indique les catégories de service éligibles dans sa liste d'avantages.</p>
                </details>
            </section>
        <?php endif; ?>
    <?php endif; ?>
</main>

<script>
(function () {
    var reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Apparition au défilement
    var els = document.querySelectorAll('.reveal');
    if (reduit || !('IntersectionObserver' in window)) {
        els.forEach(function (e) { e.classList.add('reveal--visible'); });
    } else {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) { en.target.classList.add('reveal--visible'); io.unobserve(en.target); }
            });
        }, { threshold: 0.12 });
        els.forEach(function (e) { io.observe(e); });
    }

    // Compteurs animés (crédits / jours)
    if (!reduit) {
        document.querySelectorAll('[data-compte]').forEach(function (el) {
            var cible = parseInt(el.dataset.compte, 10) || 0, debut = null, duree = 900;
            if (cible === 0) return;
            el.textContent = '0';
            function pas(t) {
                if (!debut) debut = t;
                var p = Math.min((t - debut) / duree, 1);
                el.textContent = Math.round(cible * (1 - Math.pow(1 - p, 3)));
                if (p < 1) requestAnimationFrame(pas);
            }
            requestAnimationFrame(pas);
        });
    }

    // Bouton : état « chargement » à l'envoi
    document.querySelectorAll('.pricing-carte__form').forEach(function (f) {
        f.addEventListener('submit', function () {
            var b = f.querySelector('button[type=submit]');
            if (b) { b.classList.add('est-envoi'); b.textContent = 'Redirection vers le paiement…'; }
        });
    });
})();
</script>
</body>
</html>