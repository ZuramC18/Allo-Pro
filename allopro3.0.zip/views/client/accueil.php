<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/Abonnement.php';
require_once __DIR__ . '/../../includes/icones.php';

if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$clientId = (int) $_SESSION['user_id'];
$mesDemandes   = (new Demande())->getByClient($clientId);

$abonnementModel = new Abonnement();
$abonnementActif = $abonnementModel->getActifParClient($clientId);
$mesPass         = $abonnementModel->getPassDisponiblesClient($clientId);
$nbPass          = count($mesPass);

$enCours   = array_values(array_filter($mesDemandes, fn($d) => !in_array($d['statut'], ['terminee', 'annulee'])));
$terminees = array_filter($mesDemandes, fn($d) => $d['statut'] === 'terminee');
$recentes  = array_slice($mesDemandes, 0, 5);

// Formulation du statut : "en_attente" => "En attente"
$libelleStatut = fn($s) => ucfirst(str_replace('_', ' ', (string) $s));

// Salutation selon l'heure
$heure = (int) date('G');
$salut = $heure >= 18 || $heure < 5 ? 'Bonsoir' : 'Bonjour';

// Abonnement
if ($abonnementActif) {
    $total    = max(1, (int) $abonnementActif['nombre_credits']);
    $restants = max(0, (int) $abonnementActif['credits_restants']);
    $pourcent = min(100, ($restants / $total) * 100);
    $joursRest = max(0, (int) ceil((strtotime($abonnementActif['date_fin']) - time()) / 86400));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mon espace — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/accueil-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/accueil-client.css') ?>">
    <script>document.documentElement.classList.add('js');</script>
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>
<main class="page-client">
<div class="contenu">

    <!-- ===== En-tête ===== -->
    <div class="contenu__entete reveal">
        <div>
            <div class="contenu__titre"><?= $salut ?> <?= h($_SESSION['nom']) ?> <?= h($_SESSION['prenom']) ?></div>
            <p class="acc-soustitre">
                <?php if (count($enCours) > 0): ?>
                    Vous avez <strong><?= count($enCours) ?></strong> demande<?= count($enCours) > 1 ? 's' : '' ?> en cours.
                <?php else: ?>
                    Aucune demande en cours. Besoin d'un coup de main ?
                <?php endif; ?>
            </p>
        </div>
        <a href="nouvelle-demande.php" class="bouton bouton--principal acc-btn-nouveau">+ Nouvelle demande</a>
    </div>

    <!-- ===== Statistiques ===== -->
    <div class="acc-stats">
        <div class="acc-stat reveal" style="--i:0"><span>Total des demandes</span><strong data-compte="<?= count($mesDemandes) ?>"><?= count($mesDemandes) ?></strong></div>
        <div class="acc-stat reveal" style="--i:1"><span>En cours</span><strong data-compte="<?= count($enCours) ?>"><?= count($enCours) ?></strong></div>
        <div class="acc-stat reveal" style="--i:2"><span>Terminées</span><strong data-compte="<?= count($terminees) ?>"><?= count($terminees) ?></strong></div>
        <div class="acc-stat reveal" style="--i:3"><span>Pass disponibles</span><strong data-compte="<?= $nbPass ?>"><?= $nbPass ?></strong></div>
    </div>

    <!-- ===== Abonnement + Pass ===== -->
    <div class="acc-duo">
        <section class="acc-abo reveal" style="--i:0">
            <?php if ($abonnementActif): ?>
                <span class="acc-abo__tag">● Abonnement actif</span>
                <h2 class="acc-abo__nom"><?= h($abonnementActif['formule_nom']) ?></h2>
                <div class="acc-bar"><div class="acc-bar__fill" style="--cible:<?= round($pourcent, 1) ?>%"></div></div>
                <p class="acc-abo__info">
                    <strong><?= $restants ?></strong> crédit<?= $restants > 1 ? 's' : '' ?> sur <?= $total ?>
                    · <?= $joursRest ?> jour<?= $joursRest > 1 ? 's' : '' ?> restant<?= $joursRest > 1 ? 's' : '' ?>
                    (fin le <?= date('d/m/Y', strtotime($abonnementActif['date_fin'])) ?>)
                </p>
                <?php if ($restants === 0): ?>
                    <p class="acc-abo__alerte">Plus de crédit : prenez un Pass ou un nouvel abonnement.</p>
                <?php endif; ?>
                <a href="abonnement.php" class="acc-abo__lien">Gérer mon abonnement →</a>
            <?php else: ?>
                <span class="acc-abo__tag acc-abo__tag--off">Aucun abonnement</span>
                <h2 class="acc-abo__nom">Passez à l'abonnement</h2>
                <p class="acc-abo__info">Des interventions plafonnées chaque mois, sans mauvaise surprise sur la facture.</p>
                <a href="abonnement.php" class="acc-abo__lien">Voir les formules →</a>
            <?php endif; ?>
        </section>

        <section class="acc-pass reveal" style="--i:1">
            <div class="acc-pass__icone" aria-hidden="true"><?= icone('ticket', 28) ?></div>
            <h2 class="acc-pass__titre">Pass Intervention</h2>
            <p class="acc-pass__texte">
                <?php if ($nbPass > 0): ?>
                    Vous avez <strong><?= $nbPass ?></strong> Pass disponible<?= $nbPass > 1 ? 's' : '' ?>. Il sera appliqué automatiquement à votre prochaine intervention.
                <?php else: ?>
                    Payez une intervention à l'unité, à l'avance. Idéal sans abonnement.
                <?php endif; ?>
            </p>
            <a href="pass.php" class="acc-pass__lien"><?= $nbPass > 0 ? 'Voir mes Pass' : 'Acheter un Pass' ?> →</a>
        </section>
    </div>

    <!-- ===== Demandes en cours ===== -->
    <?php if (!empty($enCours)): ?>
        <section class="acc-section reveal">
            <h2 class="acc-section__titre">Demandes en cours</h2>
            <div class="acc-encours">
                <?php foreach (array_slice($enCours, 0, 3) as $d): ?>
                    <a href="detail-demande.php?id=<?= (int) $d['id'] ?>" class="acc-demande">
                        <div>
                            <strong><?= h($d['categorie_nom']) ?></strong>
                            <span><?= h($d['numero_dossier']) ?> · <?= date('d/m/Y', strtotime($d['date_creation'])) ?></span>
                        </div>
                        <span class="badge badge--<?= h($d['statut']) ?>"><?= h($libelleStatut($d['statut'])) ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- ===== Actions rapides ===== -->
    <section class="acc-section reveal">
        <h2 class="acc-section__titre">Accès rapide</h2>
        <div class="acc-actions">
            <a href="nouvelle-demande.php" class="acc-action"><?= icone('plus', 20) ?> Nouvelle demande</a>
            <a href="mes-demandes.php" class="acc-action"><?= icone('clipboard', 20) ?> Mes demandes</a>
            <a href="abonnement.php" class="acc-action"><span aria-hidden="true">⭐</span> Mon abonnement</a>
            <a href="pass.php" class="acc-action"><?= icone('ticket', 20) ?> Pass Intervention</a>
        </div>
    </section>

    <!-- ===== Dernières demandes ===== -->
    <div class="table-carte acc-tableau reveal">
        <div class="acc-table-entete">
            <div>
                <strong>Mes dernières demandes</strong>
                <span class="acc-table-sous">Vos 5 demandes les plus récentes</span>
            </div>
            <a href="mes-demandes.php" class="acc-table-voir">Voir tout <?= icone('arrow', 14) ?></a>
        </div>

        <table class="acc-table">
            <thead>
                <tr><th>Dossier</th><th>Catégorie</th><th>Statut</th><th>Date</th><th aria-hidden="true"></th></tr>
            </thead>
            <tbody>
            <?php if (empty($mesDemandes)): ?>
                <tr class="acc-table__vide"><td colspan="5">
                    <span class="acc-table__vide-ico"><?= icone('clipboard', 28) ?></span>
                    <span>Aucune demande pour le moment.</span>
                    <a href="nouvelle-demande.php">Créer votre première demande</a>
                </td></tr>
            <?php endif; ?>
            <?php foreach ($recentes as $r => $d): $lien = 'detail-demande.php?id=' . (int) $d['id']; ?>
                <tr class="acc-ligne" style="--r:<?= (int) $r ?>" onclick="window.location='<?= $lien ?>'">
                    <td data-label="Dossier"><a href="<?= $lien ?>" class="acc-ligne__dossier" onclick="event.stopPropagation()"><?= h($d['numero_dossier']) ?></a></td>
                    <td data-label="Catégorie">
                        <span class="acc-cat"><span class="acc-cat__ico"><?= iconePole($d['categorie_nom'], 18) ?></span><?= h($d['categorie_nom']) ?></span>
                    </td>
                    <td data-label="Statut"><span class="badge badge--<?= h($d['statut']) ?>"><?= h($libelleStatut($d['statut'])) ?></span></td>
                    <td data-label="Date" class="acc-ligne__date"><?= date('d/m/Y', strtotime($d['date_creation'])) ?></td>
                    <td class="acc-ligne__fleche" aria-hidden="true"><?= icone('arrow', 16) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</main>

<script>
(function () {
    var reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var els = document.querySelectorAll('.reveal');
    if (reduit || !('IntersectionObserver' in window)) {
        els.forEach(function (e) { e.classList.add('reveal--visible'); });
    } else {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) { en.target.classList.add('reveal--visible'); io.unobserve(en.target); }
            });
        }, { threshold: 0.1 });
        els.forEach(function (e) { io.observe(e); });
    }
    if (!reduit) {
        document.querySelectorAll('[data-compte]').forEach(function (el) {
            var cible = parseInt(el.dataset.compte, 10) || 0, debut = null;
            if (cible < 2) return;
            el.textContent = '0';
            function pas(t) {
                if (!debut) debut = t;
                var p = Math.min((t - debut) / 800, 1);
                el.textContent = Math.round(cible * (1 - Math.pow(1 - p, 3)));
                if (p < 1) requestAnimationFrame(pas);
            }
            requestAnimationFrame(pas);
        });
    }
})();
</script>
</body>
</html>