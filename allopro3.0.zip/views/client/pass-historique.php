<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../includes/icones.php';
require_once __DIR__ . '/../../models/Abonnement.php';

// Échappement HTML sûr (accepte null)
if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$abonnementModel = new Abonnement();
$clientId = (int) $_SESSION['user_id'];

// Moyens de paiement acceptés (clé envoyée par le formulaire => libellé affiché)
$methodesPaiement = ['wave' => 'Wave', 'orange_money' => 'Orange Money'];

$tousPassTypes = $abonnementModel->getPassTypes();
$erreur = null;

// ---------- Achat d'un Pass ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pass_type_id'])) {
    $passTypeId = (int) $_POST['pass_type_id'];
    $methode = $_POST['methode'] ?? '';

    // Le Pass doit exister ET être actif (on ne fait pas confiance au formulaire)
    $type = null;
    foreach ($tousPassTypes as $pt) {
        if ((int) $pt['id'] === $passTypeId && $pt['statut'] === 'actif') { $type = $pt; break; }
    }

    if (!$type) {
        $erreur = "Ce Pass n'est plus disponible.";
    } elseif (!isset($methodesPaiement[$methode])) {
        $erreur = "Choisissez un moyen de paiement.";
    } else {
        $reference = $abonnementModel->creerAchatPass($clientId, $passTypeId);
        $page = $methode === 'wave' ? 'simulation-wave.php' : 'simulation-orange.php';
        header("Location: /allopro/public/{$page}?reference=" . urlencode($reference) . "&montant=" . urlencode($type['prix']) . "&type=pass");
        exit;
    }
}

$mesPass = $abonnementModel->getHistoriquePassClient($clientId);
$libellesStatutsPass = ['en_attente' => 'En attente', 'disponible' => 'Disponible', 'utilise' => 'Utilisé', 'expire' => 'Expiré'];
$typesActifs = array_values(array_filter($tousPassTypes, fn($t) => $t['statut'] === 'actif'));
$nbTypes = count($typesActifs);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pass Intervention — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/pass-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/pass-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/pass-animations.css">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
    <script>document.documentElement.classList.add('js');</script>
</head>
<body class="page-pass">
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client pass-page">

    <a href="pass.php" class="pass-retour">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>
        Retour aux Pass
    </a>
    
    <!-- ===== En-tête ===== -->
    <header class="pass-hero">
        <span class="pass-tag">Sans engagement</span>
        <h1 class="pass-hero__titre">Le Pass Intervention</h1>
        <p class="pass-hero__texte">Payez une intervention à l'unité, à l'avance et au meilleur prix. Idéal si vous n'avez pas d'abonnement.</p>
        <ul class="pass-garanties">
            <li><span class="pass-check"><?= icone('check', 12) ?></span> Sans engagement</li>
            <li><span class="pass-check"><?= icone('check', 12) ?></span> Activé dès le paiement</li>
            <li><span class="pass-check"><?= icone('check', 12) ?></span> Wave et Orange Money</li>
        </ul>
    </header>

    <?php if (isset($_GET['succes'])): ?>
        <div class="pass-alerte pass-alerte--succes" role="status"><?= icone('check', 18) ?> Pass activé — il sera utilisé automatiquement lors de votre prochaine intervention.</div>
    <?php endif; ?>

    <?php if ($erreur): ?>
        <div class="pass-alerte pass-alerte--erreur" role="alert"><?= h($erreur) ?></div>
    <?php endif; ?>

    <!-- ===== Pass déjà possédés ===== -->
    <?php if (!empty($mesPass)): ?>
        <?php
        // Compteurs par statut (puces de filtre)
        $comptesStatut = [];
        foreach ($mesPass as $p) { $s = $p['statut'] ?? ''; $comptesStatut[$s] = ($comptesStatut[$s] ?? 0) + 1; }
        $ordreStatuts = ['disponible', 'en_attente', 'utilise', 'expire'];

        // Séparation : « utilisés » d'un côté, tout le reste (disponibles, en attente, expirés) = « non utilisés »
        $parGroupe = ['non_utilises' => [], 'utilises' => []];
        foreach ($mesPass as $p) {
            $parGroupe[($p['statut'] ?? '') === 'utilise' ? 'utilises' : 'non_utilises'][] = $p;
        }
        $definitionGroupes = [
            'non_utilises' => ['titre' => 'Pass non utilisés', 'sous' => 'Disponibles, en attente de paiement ou expirés', 'vide' => "Vous n'avez aucun Pass non utilisé."],
            'utilises'     => ['titre' => 'Pass utilisés',     'sous' => 'Déjà appliqués à une intervention',               'vide' => "Aucun Pass n'a encore été utilisé."],
        ];
        ?>
        <section class="pass-section" aria-labelledby="titre-mes-pass">
            <div class="pass-section__entete">
                <h2 class="pass-section__titre" id="titre-mes-pass">L’historique de mes Pass</h2>
                <span class="pass-compteur" data-compte="<?= count($mesPass) ?>"><?= count($mesPass) ?></span>
            </div>

            <!-- Barre d'outils -->
            <div class="pass-outils reveal">
                <div class="pass-recherche">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                    <label for="pass-recherche" class="pass-sr-only">Rechercher dans mes Pass</label>
                    <input type="search" id="pass-recherche" placeholder="Rechercher un Pass, un dossier, une date…" autocomplete="off">
                </div>

                <label for="pass-tri" class="pass-sr-only">Trier les Pass</label>
                <select id="pass-tri" class="pass-tri">
                    <option value="recent">Plus récents d'abord</option>
                    <option value="ancien">Plus anciens d'abord</option>
                </select>
            </div>

            <div class="pass-filtres reveal" id="pass-filtres" role="group" aria-label="Filtrer par statut">
                <button type="button" class="pass-filtre pass-filtre--actif" data-statut="" aria-pressed="true">Tous <span><?= count($mesPass) ?></span></button>
                <?php foreach ($ordreStatuts as $cle): if (empty($comptesStatut[$cle])) continue; ?>
                    <button type="button" class="pass-filtre" data-statut="<?= h($cle) ?>" aria-pressed="false"><?= h($libellesStatutsPass[$cle] ?? $cle) ?> <span><?= (int) $comptesStatut[$cle] ?></span></button>
                <?php endforeach; ?>
            </div>

            <p class="pass-resultats" id="pass-resultats" aria-live="polite"></p>

            <!-- Deux groupes : non utilisés, puis utilisés -->
            <?php foreach ($definitionGroupes as $cleGroupe => $def): $pass = $parGroupe[$cleGroupe]; ?>
                <section class="pass-groupe pass-groupe--<?= h(str_replace('_', '-', $cleGroupe)) ?> reveal" data-groupe="<?= h($cleGroupe) ?>" data-total="<?= count($pass) ?>" aria-labelledby="titre-groupe-<?= h($cleGroupe) ?>">
                    <div class="pass-groupe__entete">
                        <h3 class="pass-groupe__titre" id="titre-groupe-<?= h($cleGroupe) ?>"><?= h($def['titre']) ?> <span class="pass-groupe__nb"><?= count($pass) ?></span></h3>
                        <p class="pass-groupe__sous"><?= h($def['sous']) ?></p>
                    </div>

                    <?php if (empty($pass)): ?>
                        <p class="pass-groupe__vide"><?= h($def['vide']) ?></p>
                    <?php else: ?>
                        <div class="pass-possedes">
                            <?php foreach ($pass as $i => $p):
                                $libelleStatut = $libellesStatutsPass[$p['statut']] ?? 'Statut en cours';
                                $dateAchat = !empty($p['date_achat']) ? date('d/m/Y', strtotime($p['date_achat'])) : '';
                                $recherche = trim(($p['nom'] ?? '') . ' ' . ($p['numero_dossier'] ?? '') . ' ' . $dateAchat . ' ' . $libelleStatut);
                            ?>
                                <article class="pass-possede reveal" style="--i:<?= min((int) $i, 8) ?>"
                                         data-statut="<?= h($p['statut'] ?? '') ?>"
                                         data-date="<?= !empty($p['date_achat']) ? (int) strtotime($p['date_achat']) : 0 ?>"
                                         data-recherche="<?= h($recherche) ?>">
                                    <div class="pass-possede__icone" aria-hidden="true"><?= icone('ticket', 24) ?></div>
                                    <div class="pass-possede__infos">
                                        <span class="pass-possede__nom"><?= h($p['nom']) ?></span>
                                        <?php if ($dateAchat !== ''): ?>
                                            <span class="pass-possede__date">Acheté le <?= $dateAchat ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($p['numero_dossier'])): ?>
                                            <span class="pass-possede__date">Dossier <?= h($p['numero_dossier']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <span class="pass-pill <?= $p['statut'] === 'disponible' ? 'pass-pill--ok' : '' ?>"><?= h($libelleStatut) ?></span>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            <?php endforeach; ?>

            <div class="pass-aucun" id="pass-aucun" hidden>
                <p>Aucun Pass ne correspond à votre recherche.</p>
                <button type="button" class="pass-reinit" id="pass-reinit">Réinitialiser les filtres</button>
            </div>
        </section>

        <script>
        (function () {
            const champ = document.getElementById('pass-recherche');
            const tri = document.getElementById('pass-tri');
            const filtres = document.querySelectorAll('#pass-filtres .pass-filtre');
            const groupes = Array.from(document.querySelectorAll('.pass-groupe'));
            const cartes = Array.from(document.querySelectorAll('.pass-possede'));
            const resultats = document.getElementById('pass-resultats');
            const aucun = document.getElementById('pass-aucun');
            let statutActif = '';

            // Recherche sans tenir compte des accents ni des majuscules
            const normaliser = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
            cartes.forEach((c) => { c.dataset.recherche = normaliser(c.dataset.recherche); });

            function appliquer() {
                const termes = normaliser(champ.value).split(/\s+/).filter(Boolean);
                const sens = tri.value === 'ancien' ? 1 : -1;
                const filtreActif = termes.length > 0 || statutActif !== '';
                let visiblesTotal = 0;

                cartes.forEach((c) => {
                    const ok = (statutActif === '' || c.dataset.statut === statutActif)
                        && termes.every((t) => c.dataset.recherche.includes(t));   // tous les mots saisis doivent être présents
                    c.hidden = !ok;
                    if (ok) { visiblesTotal++; c.classList.add('reveal--visible'); }
                    c.style.order = String(sens * Number(c.dataset.date || 0));      // tri par date d'achat, dans chaque groupe
                });

                // Chaque groupe : nombre affiché mis à jour ; masqué s'il n'a plus rien à montrer pendant un filtrage
                groupes.forEach((g) => {
                    const total = Number(g.dataset.total || 0);
                    const visibles = g.querySelectorAll('.pass-possede:not([hidden])').length;
                    g.querySelector('.pass-groupe__nb').textContent = filtreActif && total > 0 ? visibles + ' / ' + total : String(total);
                    g.classList.add('reveal--visible');
                    g.hidden = filtreActif && visibles === 0;
                });

                aucun.hidden = visiblesTotal !== 0;
                resultats.textContent = (filtreActif && visiblesTotal > 0)
                    ? visiblesTotal + ' résultat' + (visiblesTotal > 1 ? 's' : '') + ' sur ' + cartes.length
                    : '';
            }

            champ.addEventListener('input', appliquer);
            tri.addEventListener('change', appliquer);
            filtres.forEach((b) => b.addEventListener('click', () => {
                statutActif = b.dataset.statut;
                filtres.forEach((x) => {
                    const actif = x === b;
                    x.classList.toggle('pass-filtre--actif', actif);
                    x.setAttribute('aria-pressed', actif ? 'true' : 'false');
                });
                appliquer();
            }));
            document.getElementById('pass-reinit').addEventListener('click', () => {
                champ.value = ''; tri.value = 'recent'; statutActif = '';
                filtres.forEach((x, i) => { x.classList.toggle('pass-filtre--actif', i === 0); x.setAttribute('aria-pressed', i === 0 ? 'true' : 'false'); });
                appliquer(); champ.focus();
            });
            champ.addEventListener('keydown', (e) => { if (e.key === 'Escape' && champ.value) { champ.value = ''; appliquer(); } });

            appliquer();
        })();
        </script>
    <?php endif; ?>

    <!-- ===== Comment ça marche ===== -->
    <section class="pass-section" aria-labelledby="titre-etapes">
        <h2 class="pass-section__titre pass-section__titre--centre" id="titre-etapes">Comment ça marche ?</h2>
        <ol class="pass-etapes">
            <li class="pass-etape reveal" style="--i:0">
                <h3 class="pass-etape__titre">Choisissez votre Pass</h3>
                <p class="pass-etape__texte">Sélectionnez la formule qui correspond à votre besoin.</p>
            </li>
            <li class="pass-etape reveal" style="--i:1">
                <h3 class="pass-etape__titre">Payez en quelques secondes</h3>
                <p class="pass-etape__texte">Réglez avec Wave ou Orange Money. Le Pass est activé dès la confirmation.</p>
            </li>
            <li class="pass-etape reveal" style="--i:2">
                <h3 class="pass-etape__titre">Utilisez-le automatiquement</h3>
                <p class="pass-etape__texte">À la fin de votre intervention, votre Pass est appliqué : plus rien à payer.</p>
            </li>
        </ol>
    </section>

    <!-- ===== FAQ ===== -->
    <section class="pass-section" aria-labelledby="titre-faq">
        <h2 class="pass-section__titre pass-section__titre--centre" id="titre-faq">Questions fréquentes</h2>
        <div class="pass-faq reveal">
            <details>
                <summary>Qu'est-ce qu'un Pass Intervention ?</summary>
                <p>C'est une intervention achetée à l'avance. Vous ne vous engagez à rien : vous payez uniquement le Pass que vous choisissez.</p>
            </details>
            <details>
                <summary>Quand mon Pass est-il utilisé ?</summary>
                <p>À la fin d'une intervention, si vous avez un Pass disponible, il est appliqué automatiquement : vous n'avez plus rien à payer. Si vous en avez plusieurs, le plus ancien est utilisé en premier.</p>
            </details>
            <details>
                <summary>Quand mon Pass est-il actif ?</summary>
                <p>Dès que votre paiement est confirmé. Il apparaît alors dans « Vos Pass disponibles » en haut de cette page.</p>
            </details>
            <details>
                <summary>Quels moyens de paiement sont acceptés ?</summary>
                <p>Vous pouvez régler votre Pass avec Wave ou Orange Money.</p>
            </details>
        </div>
    </section>
</main>

<script>
(function () {
    var reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Apparition au défilement
    var els = document.querySelectorAll('.reveal');
    if (reduit || !('IntersectionObserver' in window)) {
        els.forEach(function (e) { e.classList.add('reveal--visible'); });
    } else {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) { en.target.classList.add('reveal--visible'); io.unobserve(en.target); }
            });
        }, { threshold: 0.12 });
        els.forEach(function (e) { io.observe(e); });
    }

    // Compteur animé (nombre de Pass disponibles)
    if (!reduit) {
        document.querySelectorAll('[data-compte]').forEach(function (el) {
            var cible = parseInt(el.dataset.compte, 10) || 0, debut = null;
            if (cible < 2) return;
            el.textContent = '0';
            function pas(t) {
                if (!debut) debut = t;
                var p = Math.min((t - debut) / 800, 1);
                el.textContent = Math.round(cible * (1 - Math.pow(1 - p, 3)));
                if (p < 1) requestAnimationFrame(pas);
            }
            requestAnimationFrame(pas);
        });
    }

    // Évite le double achat : le bouton se bloque après le premier clic
    document.querySelectorAll('.pass-form').forEach(function (form) {
        var bouton = form.querySelector('button[type="submit"]');
        var texteInitial = bouton.textContent;
        form.addEventListener('submit', function () {
            bouton.disabled = true;
            bouton.classList.add('est-envoi');
            bouton.textContent = 'Redirection vers le paiement…';
        });
        // Retour arrière du navigateur : on remet le bouton en état
        window.addEventListener('pageshow', function (e) {
            if (e.persisted) { bouton.disabled = false; bouton.classList.remove('est-envoi'); bouton.textContent = texteInitial; }
        });
    });
})();
</script>
</body>
</html>