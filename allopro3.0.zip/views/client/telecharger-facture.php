<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Facture.php';

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    http_response_code(404);
    exit('Facture introuvable.');
}

try {
    $facture = (new Facture())->getFichierPourClient((int) $id, (int) $_SESSION['user_id']);
} catch (Throwable $e) {
    error_log('Telechargement de facture impossible : ' . $e->getMessage());
    http_response_code(500);
    exit('Le fichier de cette facture est indisponible.');
}

if (!$facture) {
    http_response_code(404);
    exit('Facture introuvable.');
}

header('Content-Type: application/pdf');
header('Content-Length: ' . (string) filesize($facture['chemin_absolu']));
header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $facture['numero']) . '.pdf"');
header('X-Content-Type-Options: nosniff');
readfile($facture['chemin_absolu']);
exit;
