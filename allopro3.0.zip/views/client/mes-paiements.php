<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Paiement.php';

if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$transactions = (new Paiement())->getHistoriqueClient((int) $_SESSION['user_id']);
$libellesTypes = ['intervention' => 'Intervention', 'abonnement' => 'Abonnement', 'pass' => 'Pass'];
$libellesStatuts = [
    'valide' => 'Confirmé',
    'actif' => 'Actif',
    'disponible' => 'Disponible',
    'utilise' => 'Utilisé',
    'en_attente' => 'En attente',
    'echoue' => 'Échoué',
    'expire' => 'Expiré',
    'resilie' => 'Résilié',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes paiements — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/portail-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/portail-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>
<main class="page-client portail-client">
    <header class="portail-entete">
        <div>
            <p class="portail-sur-titre">PAIEMENTS & AVANTAGES</p>
            <h1>Mes paiements</h1>
            <p>Historique de vos paiements d’intervention, abonnements et Pass.</p>
        </div>
        <a class="portail-action portail-action--secondaire" href="mes-factures.php">Mes factures</a>
    </header>

    <?php if ($transactions): ?>
        <section class="portail-transactions" aria-label="Historique des paiements">
            <?php foreach ($transactions as $transaction): ?>
                <?php
                $statut = $transaction['statut'] ?? '';
                $type = $transaction['type'] ?? '';
                ?>
                <article class="portail-transaction">
                    <div class="portail-transaction__principal">
                        <strong><?= h($libellesTypes[$type] ?? 'Opération') ?></strong>
                        <span><?= h($transaction['reference_transaction'] ?: 'Référence non disponible') ?></span>
                    </div>
                    <div class="portail-transaction__detail">
                        <span><?= date('d/m/Y', strtotime($transaction['date_operation'])) ?></span>
                        <span><?= h($libellesStatuts[$statut] ?? 'Statut en cours') ?></span>
                    </div>
                    <strong class="portail-montant"><?= number_format((float) $transaction['montant'], 0, ',', ' ') ?> F&nbsp;CFA</strong>
                    <?php if (!empty($transaction['numero_dossier'])): ?>
                        <a href="detail-demande.php?id=<?= (int) $transaction['demande_id'] ?>">Dossier <?= h($transaction['numero_dossier']) ?></a>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </section>
    <?php else: ?>
        <section class="portail-vide">
            <h2>Aucun paiement enregistré</h2>
            <p>Vos opérations apparaîtront ici après un achat de Pass, un abonnement ou le règlement d’une intervention.</p>
        </section>
    <?php endif; ?>
</main>
</body>
</html>
