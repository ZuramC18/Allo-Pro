<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/EntrepriseB2B.php';

$userId = (int) $_SESSION['user_id'];
$entrepriseModele = new EntrepriseB2B();
$csrfKey = 'csrf_invitations_entreprise';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $invitationId = filter_var($_POST['invitation_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $reponse = is_string($_POST['reponse'] ?? null) ? $_POST['reponse'] : '';

    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $_SESSION['flash_invitations_entreprise'] = ['type' => 'error', 'message' => 'La page a expiré. Rechargez-la puis réessayez.'];
    } elseif ($invitationId === false || !in_array($reponse, ['acceptee', 'refusee'], true)) {
        $_SESSION['flash_invitations_entreprise'] = ['type' => 'error', 'message' => 'La réponse à cette invitation est invalide.'];
    } else {
        try {
            $entrepriseId = $entrepriseModele->repondreInvitationMembre((int) $invitationId, $userId, $reponse);
            if ($reponse === 'acceptee') {
                header('Location: ../entreprise/accueil.php?entreprise_id=' . $entrepriseId);
                exit;
            }
            $_SESSION['flash_invitations_entreprise'] = ['type' => 'success', 'message' => 'Vous avez refusé cette invitation.'];
        } catch (PDOException $exception) {
            error_log('Réponse à une invitation entreprise par client ' . $userId . ' : ' . $exception->getMessage());
            $_SESSION['flash_invitations_entreprise'] = ['type' => 'error', 'message' => 'Votre réponse n’a pas pu être enregistrée. Réessayez.'];
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $_SESSION['flash_invitations_entreprise'] = ['type' => 'error', 'message' => $exception->getMessage()];
        }
    }

    $idUrl = filter_var($_POST['invitation_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    header('Location: invitations-entreprise.php' . ($idUrl !== false ? '?id=' . (int) $idUrl : ''));
    exit;
}

$flash = $_SESSION['flash_invitations_entreprise'] ?? null;
unset($_SESSION['flash_invitations_entreprise']);
$invitations = $entrepriseModele->getInvitationsEnAttenteUtilisateur($userId);
$invitationSelectionnee = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invitations entreprise — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
    <link rel="stylesheet" href="../../public/css/notifications-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/notifications-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>
<main class="page-client">
    <section class="notifications-page" aria-labelledby="invitations-titre">
        <div class="notifications-page__entete">
            <div>
                <p class="notifications-page__surtitre">Votre espace professionnel</p>
                <h1 id="invitations-titre">Invitations d’entreprise</h1>
                <p>Acceptez une invitation pour rejoindre l’espace d’une entreprise sur ALLÔ PRO.</p>
            </div>
            <a href="notifications.php" class="notifications-page__retour">Mes notifications</a>
        </div>

        <?php if (is_array($flash)): ?>
            <div class="b2b-alert<?= ($flash['type'] ?? '') === 'success' ? ' b2b-alert--success' : '' ?>" role="<?= ($flash['type'] ?? '') === 'error' ? 'alert' : 'status' ?>"><?= $e($flash['message'] ?? '') ?></div>
        <?php endif; ?>

        <?php if (!$invitations): ?>
            <div class="notifications-page__vide">
                <h2>Vous n’avez aucune invitation en attente</h2>
                <p>Les invitations d’entreprise reçues apparaîtront ici.</p>
            </div>
        <?php else: ?>
            <div class="notifications-page__liste">
                <?php foreach ($invitations as $invitation):
                    $nomAuteur = trim((string) ($invitation['auteur_prenom'] ?? '') . ' ' . (string) ($invitation['auteur_nom'] ?? ''));
                    $dateInvitation = strtotime((string) $invitation['date_creation']);
                    $estCible = $invitationSelectionnee !== false && (int) $invitationSelectionnee === (int) $invitation['id'];
                ?>
                    <article class="notifications-page__item<?= $estCible ? ' notifications-page__item--non-lue' : '' ?>">
                        <span class="notifications-page__icone" aria-hidden="true">
                            <svg viewBox="0 0 24 24"><path d="M3 7.5 12 13l9-5.5M4.5 5h15A1.5 1.5 0 0 1 21 6.5v11a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5v-11A1.5 1.5 0 0 1 4.5 5Z"/></svg>
                        </span>
                        <span class="notifications-page__texte">
                            <strong><?= $e($invitation['entreprise_nom']) ?></strong>
                            <span><?= $nomAuteur !== '' ? 'Invitation envoyée par ' . $e($nomAuteur) : 'Vous avez reçu une invitation à rejoindre cette entreprise.' ?><?php if (!empty($invitation['auteur_email'])): ?> (<?= $e($invitation['auteur_email']) ?>)<?php endif; ?></span>
                            <?php if ($dateInvitation !== false): ?><time datetime="<?= $e(date(DATE_ATOM, $dateInvitation)) ?>">Reçue le <?= $e(date('d/m/Y à H:i', $dateInvitation)) ?></time><?php endif; ?>
                            <span class="b2b-invitation-actions">
                                <form method="post">
                                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                                    <input type="hidden" name="invitation_id" value="<?= (int) $invitation['id'] ?>">
                                    <button class="b2b-button" type="submit" name="reponse" value="acceptee">Accepter et rejoindre</button>
                                </form>
                                <form method="post">
                                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                                    <input type="hidden" name="invitation_id" value="<?= (int) $invitation['id'] ?>">
                                    <button class="b2b-button b2b-button--secondary" type="submit" name="reponse" value="refusee">Refuser</button>
                                </form>
                            </span>
                        </span>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
