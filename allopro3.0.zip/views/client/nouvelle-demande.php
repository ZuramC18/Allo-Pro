<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/Adresse.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../models/Categorie.php';
require_once __DIR__ . '/../../models/Abonnement.php';
require_once __DIR__ . '/../../models/AttributionDemandes.php';
require_once __DIR__ . '/../../models/Parametre.php';

if (!function_exists('h')) {
    function h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
}

require_once __DIR__ . '/../../includes/icones.php';

$categorieModel  = new Categorie();
$abonnementModel = new Abonnement();
$parametres = new Parametre();
$heureDebutCreneau = max(0, min(23, (int) $parametres->get('heure_debut_indisponibilites', '8')));
$heureFinCreneau = max($heureDebutCreneau + 1, min(24, (int) $parametres->get('heure_fin_indisponibilites', '20')));
$dateMinimumCreneau = date('Y-m-d');

$db = (new Database())->getConnection();
$categoriesPrincipales = $db->query("SELECT * FROM categories WHERE parent_id IS NULL AND statut = 'active' ORDER BY nom")->fetchAll();
$categoriesParPole = [];
$categorieVersPole = [];
foreach ($categoriesPrincipales as $pole) {
    $stmtCategories = $db->prepare(
        "SELECT id, nom FROM categories WHERE parent_id = :parent_id AND statut = 'active' ORDER BY nom"
    );
    $stmtCategories->execute([':parent_id' => $pole['id']]);
    $sousCategories = $stmtCategories->fetchAll(PDO::FETCH_ASSOC);
    if (!$sousCategories) {
        $sousCategories = [['id' => $pole['id'], 'nom' => $pole['nom']]];
    }
    $categoriesParPole[(int) $pole['id']] = $sousCategories;
    foreach ($sousCategories as $sousCategorie) {
        $categorieVersPole[(int) $sousCategorie['id']] = (int) $pole['id'];
    }
}

$mesAdresses = (new Adresse())->getByUser($_SESSION['user_id']);

$abonnementActif = $abonnementModel->getActifParClient($_SESSION['user_id']);
$categoriesEligiblesAbo = $abonnementActif ? $abonnementModel->getCategoriesEligibles($abonnementActif['formule_id']) : [];
$passDisponibles = $abonnementModel->getPassDisponiblesClient($_SESSION['user_id']);

// Pour chaque pôle, détermine si l'abonnement le couvre et quels Pass s'y appliquent
$eligibilitePoles = [];
foreach ($categoriesPrincipales as $pole) { $eligibilitePoles[$pole['id']] = ['abonnement' => false, 'pass' => []]; }

if ($abonnementActif && $abonnementActif['credits_restants'] > 0) {
    if (empty($categoriesEligiblesAbo)) {
        foreach ($eligibilitePoles as &$e) { $e['abonnement'] = true; }
        unset($e);
    } else {
        foreach ($categoriesEligiblesAbo as $ce) {
            $poleId = $ce['parent_id'] ?: $ce['id'];
            if (isset($eligibilitePoles[$poleId])) { $eligibilitePoles[$poleId]['abonnement'] = true; }
        }
    }
}
foreach ($passDisponibles as $p) {
    if ($p['categorie_id'] === null) {
        foreach ($eligibilitePoles as &$e) { $e['pass'][] = $p; }
        unset($e);
    } else {
        $sousCat = $categorieModel->getById($p['categorie_id']);
        $poleId = $sousCat['parent_id'] ?? null;
        if ($poleId && isset($eligibilitePoles[$poleId])) { $eligibilitePoles[$poleId]['pass'][] = $p; }
    }
}

$erreur = '';
// Mode de paiement renvoyé par le formulaire (vide au premier affichage)
$modePost = in_array($_POST['mode_paiement'] ?? '', ['normal', 'abonnement', 'pass'], true) ? $_POST['mode_paiement'] : '';
$old = ['categorie_id' => '', 'pole_id' => '', 'description' => '', 'urgence' => 'normale', 'adresse_id' => '', 'date_creneau' => '', 'heure_creneau' => ''];
if ($mesAdresses) {
    $old['adresse_id'] = (string) $mesAdresses[0]['id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['categorie_id'] = is_string($_POST['categorie_id'] ?? null) ? $_POST['categorie_id'] : '';
    $old['pole_id'] = isset($categorieVersPole[(int) $old['categorie_id']])
        ? (string) $categorieVersPole[(int) $old['categorie_id']]
        : '';
    $old['description']  = is_string($_POST['description'] ?? null) ? trim($_POST['description']) : '';
    $old['urgence']      = ($_POST['urgence'] ?? '') === 'urgente' ? 'urgente' : 'normale';
    $old['adresse_id']   = (string) ($_POST['adresse_id'] ?? '');
    $old['date_creneau'] = is_string($_POST['date_creneau'] ?? null) ? $_POST['date_creneau'] : '';
    $old['heure_creneau'] = is_string($_POST['heure_creneau'] ?? null) ? $_POST['heure_creneau'] : '';

    $categorieId = (int) $old['categorie_id'];
    $adresseId   = (int) $old['adresse_id'];
    $heureCreneau = filter_var($old['heure_creneau'], FILTER_VALIDATE_INT);
    $dateCreneauValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $old['date_creneau']);
    $description = $old['description'];
    $urgence     = $old['urgence'];

    // On ne fait pas confiance au formulaire : le service doit appartenir à un pôle actif.
    $poleId = $categorieVersPole[$categorieId] ?? null;
    $categorieValide = $poleId !== null && isset($eligibilitePoles[$poleId]);
    $adresseValide   = in_array($adresseId, array_map('intval', array_column($mesAdresses, 'id')), true);

    if (!$categorieValide) {
        $erreur = "Merci de choisir une catégorie.";
    } elseif ($description === '') {
        $erreur = "Merci de décrire votre problème.";
    } elseif (mb_strlen($description) > 1000) {
        $erreur = "La description est trop longue (1000 caractères maximum).";
    } elseif (!$adresseValide) {
        $erreur = "Merci de choisir ou d'ajouter une adresse.";
    } elseif (($old['date_creneau'] === '') !== ($old['heure_creneau'] === '')) {
        $erreur = "Pour choisir un créneau, renseignez à la fois la date et l’heure.";
    } elseif ($old['date_creneau'] !== '' && (!$dateCreneauValidee || $dateCreneauValidee->format('Y-m-d') !== $old['date_creneau'] || $old['date_creneau'] < $dateMinimumCreneau)) {
        $erreur = "Merci de choisir une date d’intervention valide.";
    } elseif ($old['heure_creneau'] !== '' && ($heureCreneau === false || $heureCreneau < $heureDebutCreneau || $heureCreneau >= $heureFinCreneau)) {
        $erreur = "Merci de choisir un créneau horaire valide.";
    } elseif ($old['date_creneau'] === $dateMinimumCreneau && $heureCreneau !== false && $heureCreneau < (int) date('G')) {
        $erreur = "Le créneau sélectionné est déjà passé.";
    } else {
        $photoPath = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            if ($_FILES['photo']['error'] !== UPLOAD_ERR_OK || $_FILES['photo']['size'] > 5 * 1024 * 1024) {
                $erreur = "La photo n'a pas pu être envoyée (5 Mo maximum).";
            } elseif (!in_array($extension, ['jpg', 'jpeg', 'png'], true) || @getimagesize($_FILES['photo']['tmp_name']) === false) {
                $erreur = "Format de photo non autorisé (jpg, jpeg, png uniquement).";
            } else {
                $nomFichier = uniqid('demande_') . '.' . $extension;
                $dossierDestination = __DIR__ . '/../../public/uploads/';
                if (!is_dir($dossierDestination)) mkdir($dossierDestination, 0755, true);
                move_uploaded_file($_FILES['photo']['tmp_name'], $dossierDestination . $nomFichier);
                $photoPath = 'uploads/' . $nomFichier;
            }
        }

        // Mode de paiement : vérifié côté serveur (crédits, catégorie couverte, Pass appartenant au client)
        $modePaiement = $_POST['mode_paiement'] ?? 'normal';
        $abonnementIdUtilise = null;
        $passAchatIdUtilise = null;
        if (!$erreur) {
            if ($modePaiement === 'abonnement') {
                if ($abonnementActif && $eligibilitePoles[$poleId]['abonnement']) {
                    $abonnementIdUtilise = $abonnementActif['id'];
                } else {
                    $erreur = "Votre abonnement ne couvre pas cette catégorie ou n'a plus de crédit.";
                }
            } elseif ($modePaiement === 'pass') {
                $passChoisi = (int) ($_POST['pass_achat_id'] ?? 0);
                $idsPassOk = array_map(fn($p) => (int) $p['id'], $eligibilitePoles[$poleId]['pass']);
                if ($passChoisi && in_array($passChoisi, $idsPassOk, true)) {
                    $passAchatIdUtilise = $passChoisi;
                } else {
                    $erreur = "Ce Pass n'est pas utilisable pour cette catégorie.";
                }
            } else {
                $modePaiement = 'normal';
            }
        }

        if (!$erreur) {
            $numero = (new Demande())->create(
                $_SESSION['user_id'],
                $adresseId,
                $categorieId,
                $description,
                $urgence,
                $photoPath,
                $modePaiement,
                $abonnementIdUtilise,
                $passAchatIdUtilise,
                $old['date_creneau'] !== '' ? $old['date_creneau'] : null,
                $old['heure_creneau'] !== '' ? $heureCreneau : null
            );
            try {
                $resultatAttribution = (new AttributionDemandes())->traiterFile($numero);
                if ($resultatAttribution['active']) {
                    $dossierAttribue = in_array(
                        $numero,
                        array_column($resultatAttribution['attribuees'], 'numero_dossier'),
                        true
                    ) || (new Demande())->getStatutByNumeroDossier($numero) !== 'nouvelle';
                    $_SESSION['flash_attribution_demandes'] = $dossierAttribue
                        ? 'Un partenaire et un technicien ont été automatiquement affectés à votre demande.'
                        : ($old['date_creneau'] === ''
                            ? 'Votre demande est enregistrée. L’affectation automatique nécessite une date et un créneau souhaités ; notre équipe vous recontactera pour confirmer le rendez-vous.'
                            : 'Aucun technicien ne répond aux critères dans les 30 prochains jours. Votre demande reste en attente de traitement manuel.');
                }
            } catch (Throwable $exception) {
                error_log('Affectation automatique du dossier ' . $numero . ' : ' . $exception->getMessage());
                $_SESSION['flash_attribution_demandes'] = 'Votre demande est enregistrée, mais l’affectation automatique est indisponible. Notre équipe la traitera manuellement.';
            }
            (new User())->reouvrirConversation($_SESSION['user_id']);
            $_SESSION['brouillon_efface'] = true; // la prochaine visite de cette page repart d'un formulaire vide
            header("Location: confirmation.php?numero=" . urlencode($numero));
            exit;
        }
    }
}

$effacerBrouillon = !empty($_SESSION['brouillon_efface']);
unset($_SESSION['brouillon_efface']);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nouvelle demande — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/navbar-client.css?v=<?= filemtime(__DIR__ . '/../../public/css/navbar-client.css') ?>">
    <link rel="stylesheet" href="../../public/css/adresses.css?v=<?= filemtime(__DIR__ . '/../../public/css/adresses.css') ?>">
    <link rel="stylesheet" href="../../public/css/nouvelle-demande.css?v=<?= filemtime(__DIR__ . '/../../public/css/nouvelle-demande.css') ?>">
    <link rel="stylesheet" href="../../public/css/nouvelle-demande-extra.css?v=<?= filemtime(__DIR__ . '/../../public/css/nouvelle-demande-extra.css') ?>">
    <link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../../public/css/theme.css') ?>">
    <script>document.documentElement.classList.add('js');</script>
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar-client.php'; ?>

<main class="page-client contenu page-nouvelle-demande">
    <div class="page-entete reveal">
        <span class="dem-intro__eyebrow"><?= icone('star', 15) ?> SERVICE ALLÔ PRO</span>
        <h1 class="page-entete__titre">De quoi avez-vous besoin&nbsp;?</h1>
        <p class="page-entete__sous-titre">Choisissez le service, décrivez votre besoin et nous organiserons la suite avec vous.</p>
    </div>

    <?php if ($erreur): ?>
        <div class="erreur dem-erreur" role="alert"><?= icone('alert', 18) ?> <span><?= h($erreur) ?></span></div>
    <?php endif; ?>

    <div class="dem-brouillon" id="dem-brouillon" style="display:none;" role="status">
        <span>Votre demande en cours de saisie a été restaurée.</span>
        <button type="button" id="dem-brouillon-effacer">Recommencer à zéro</button>
    </div>

    <div class="dem-progression" aria-live="polite">
        <div class="dem-progression__meta"><strong>Votre demande</strong><span class="dem-progression__texte" id="prog-texte">0 / 4 étapes complétées</span></div>
        <div class="dem-progression__barre"><div class="dem-progression__rempli" id="prog-rempli"></div></div>
    </div>

    <form method="POST" enctype="multipart/form-data" class="demande-form" id="form-demande">

        <div class="demande-section reveal">
            <div class="demande-section__entete"><span class="demande-section__numero">01</span><div><div class="demande-section__titre">Choisissez un domaine</div><p>Commencez par le type de service dont vous avez besoin.</p></div></div>
            <div class="categorie-grille categorie-grille--poles">
                <?php foreach ($categoriesPrincipales as $cat): ?>
                    <label class="categorie-carte categorie-carte--pole">
                        <input type="radio" name="categorie_pole" value="<?= (int) $cat['id'] ?>" <?= (string) $cat['id'] === $old['pole_id'] ? 'checked' : '' ?>>
                        <span class="categorie-carte__icone"><?= iconePole($cat['nom'], 32) ?></span>
                        <span class="categorie-carte__nom"><?= h($cat['nom']) ?></span>
                        <span class="categorie-carte__compte"><?= count($categoriesParPole[(int) $cat['id']]) ?> services</span>
                    </label>
                <?php endforeach; ?>
            </div>
            <div class="dem-sous-categories" id="dem-sous-categories" <?= $old['pole_id'] === '' ? 'hidden' : '' ?>>
                <div class="dem-sous-categories__entete"><strong>Quel service précisément&nbsp;?</strong><span>Sélectionnez le plus proche de votre besoin.</span></div>
                <?php foreach ($categoriesParPole as $poleId => $sousCategories): ?>
                    <div class="dem-sous-categories__groupe" data-pole="<?= (int) $poleId ?>" <?= (string) $poleId === $old['pole_id'] ? '' : 'hidden' ?>>
                        <?php foreach ($sousCategories as $sousCategorie): ?>
                            <label class="dem-sous-categorie">
                                <input type="radio" name="categorie_id" value="<?= (int) $sousCategorie['id'] ?>" <?= (string) $sousCategorie['id'] === $old['categorie_id'] ? 'checked' : '' ?>>
                                <span><?= h($sousCategorie['nom']) ?></span>
                                <span class="dem-sous-categorie__check" aria-hidden="true"><?= icone('check', 15) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="demande-section reveal">
            <div class="demande-section__entete"><span class="demande-section__numero">02</span><div><div class="demande-section__titre">Décrivez votre besoin</div><p>Quelques détails nous aideront à mieux préparer l’intervention.</p></div></div>
            <div class="champ-icone champ-icone--textarea">
                <span class="champ-icone__pictogramme"><?= icone('pencil', 18) ?></span>
                <textarea name="description" id="description" rows="4" maxlength="1000" placeholder="Ex : Fuite d'eau sous l'évier de la cuisine depuis ce matin..." required><?= h($old['description']) ?></textarea>
            </div>
            <div class="dem-compteur"><span id="compteur-car"><?= mb_strlen($old['description']) ?></span> / 1000 caractères</div>
        </div>

        <div class="demande-section reveal">
            <div class="demande-section__entete"><span class="demande-section__numero">03</span><div><div class="demande-section__titre">Niveau d’urgence</div><p>Indiquez le degré de priorité.</p></div></div>
            <div class="urgence-toggle">
                <label class="urgence-option urgence-option--normale">
                    <input type="radio" name="urgence" value="normale" <?= $old['urgence'] === 'normale' ? 'checked' : '' ?>>
                    <span class="urgence-option__icone"><?= icone('clock', 18) ?></span><span class="urgence-option__texte"><strong>Normale</strong><small>Peut être planifiée</small></span>
                </label>
                <label class="urgence-option urgence-option--urgente">
                    <input type="radio" name="urgence" value="urgente" <?= $old['urgence'] === 'urgente' ? 'checked' : '' ?>>
                    <span class="urgence-option__icone"><?= icone('bolt', 18) ?></span><span class="urgence-option__texte"><strong>Urgente</strong><small>À traiter rapidement</small></span>
                </label>
            </div>
        </div>

        <div class="demande-section reveal">
            <div class="demande-section__entete"><span class="demande-section__numero">04</span><div><div class="demande-section__titre">Lieu d’intervention</div><p>Où devons-nous intervenir&nbsp;?</p></div></div>
            <?php if (empty($mesAdresses)): ?>
                <div class="bandeau-avertissement">
                    Vous n'avez encore aucune adresse enregistrée. <a href="ajouter-adresse.php">Ajoutez-en une</a> pour continuer.
                </div>
            <?php else: ?>
                <div class="adresse-select-liste">
                    <?php foreach ($mesAdresses as $adr): ?>
                        <label class="adresse-select-carte">
                            <input type="radio" name="adresse_id" value="<?= (int) $adr['id'] ?>" <?= (string) $adr['id'] === $old['adresse_id'] ? 'checked' : '' ?> required>
                            <span class="adresse-select-carte__pin"><?= icone('pin', 20) ?></span>
                            <span>
                                <span class="adresse-select-carte__libelle"><?= h($adr['libelle']) ?></span>
                                <span class="adresse-select-carte__detail"><?= h($adr['quartier']) ?>, <?= h($adr['ville']) ?></span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <a href="ajouter-adresse.php" class="lien-ajouter-adresse"><?= icone('plus', 14) ?> Ajouter une nouvelle adresse</a>
            <?php endif; ?>
        </div>

        <div class="demande-section reveal">
            <div class="demande-section__entete"><span class="demande-section__numero">05</span><div><div class="demande-section__titre">Quand intervenir&nbsp;? <span class="demande-section__optionnel">Facultatif</span></div><p>Votre préférence sera confirmée par l’équipe.</p></div></div>
            <p class="demande-creneau__aide">Vous pouvez indiquer votre préférence ; l’équipe vous confirmera le rendez-vous.</p>
            <div class="demande-creneau">
                <label>
                    <span>Date souhaitée</span>
                    <input type="date" name="date_creneau" id="date-creneau" min="<?= h($dateMinimumCreneau) ?>" value="<?= h($old['date_creneau']) ?>">
                </label>
                <label>
                    <span>Créneau horaire</span>
                    <select name="heure_creneau" id="heure-creneau">
                        <option value="">Aucune préférence</option>
                        <?php for ($heure = $heureDebutCreneau; $heure < $heureFinCreneau; $heure++): ?>
                            <option value="<?= $heure ?>" data-heure="<?= $heure ?>" <?= $old['heure_creneau'] === (string) $heure ? 'selected' : '' ?>>
                                <?= sprintf('%02d:00 – %02d:00', $heure, $heure + 1) ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </label>
            </div>
        </div>

        <div class="demande-section reveal">
            <div class="demande-section__entete"><span class="demande-section__numero">06</span><div><div class="demande-section__titre">Ajouter une photo <span class="demande-section__optionnel">Facultatif</span></div><p>Une image peut aider à comprendre la situation.</p></div></div>
            <label class="upload-zone" id="upload-zone">
                <input type="file" name="photo" accept=".jpg,.jpeg,.png" id="input-photo" hidden>
                <div id="upload-placeholder">
                    <div class="upload-zone__icone"><?= icone('camera', 34) ?></div>
                    <div>Cliquez ou glissez une photo ici</div>
                    <div class="upload-zone__format">JPG, JPEG ou PNG · 5 Mo maximum</div>
                </div>
                <img id="apercu-photo" alt="Aperçu de la photo choisie" style="display:none;">
            </label>
            <button type="button" class="dem-retirer-photo" id="retirer-photo" style="display:none;"><?= icone('x', 14) ?> Retirer la photo</button>
        </div>

        <div class="demande-section reveal">
            <div class="demande-section__entete"><span class="demande-section__numero">07</span><div><div class="demande-section__titre">Mode de règlement</div><p>Choisissez une option disponible pour le service sélectionné.</p></div></div>
            <div id="options-paiement" class="pay-liste">
                <label class="pay-option">
                    <input type="radio" name="mode_paiement" value="normal" <?= ($modePost === '' || $modePost === 'normal') ? 'checked' : '' ?>>
                    <span class="pay-option__ico"><?= icone('wallet', 22) ?></span>
                    <span class="pay-option__txt"><strong>Payer après l'intervention</strong><small>Wave ou Orange Money</small></span>
                </label>
                <label class="pay-option" id="option-abonnement">
                    <input type="radio" name="mode_paiement" value="abonnement" <?= $modePost === 'abonnement' ? 'checked' : '' ?>>
                    <span class="pay-option__ico"><?= icone('star', 22) ?></span>
                    <span class="pay-option__txt"><strong>Utiliser mon abonnement</strong><small>Choisissez d'abord une catégorie</small></span>
                </label>
                <div id="option-pass">
                    <label class="pay-option">
                        <input type="radio" name="mode_paiement" value="pass" <?= $modePost === 'pass' ? 'checked' : '' ?>>
                        <span class="pay-option__ico"><?= icone('ticket', 22) ?></span>
                        <span class="pay-option__txt"><strong>Utiliser un Pass déjà acheté</strong><small id="pass-info">Choisissez d'abord une catégorie</small></span>
                    </label>
                    <select name="pass_achat_id" id="select-pass" class="pay-select" style="display:none;"></select>
                </div>
            </div>
            <a href="pass.php" class="pay-lien">Pas de Pass ni d'abonnement adapté ? En acheter un →</a>
        </div>

        <div class="dem-envoi">
            <p><?= icone('inbox', 17) ?> Votre demande sera transmise à notre équipe pour organiser l’intervention.</p>
            <button type="submit" class="bouton-principal-large" id="btn-envoyer" <?= empty($mesAdresses) ? 'disabled' : '' ?>>Envoyer ma demande <?= icone('arrow', 18) ?></button>
        </div>
    </form>
</main>

<script>
(function () {
    var reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };

    // Masquer les heures déjà passées lorsque le client choisit aujourd’hui.
    var dateCreneau = document.getElementById('date-creneau');
    var heureCreneau = document.getElementById('heure-creneau');
    function actualiserCreneaux() {
        var aujourdHui = new Date();
        var dateLocale = [
            aujourdHui.getFullYear(),
            String(aujourdHui.getMonth() + 1).padStart(2, '0'),
            String(aujourdHui.getDate()).padStart(2, '0')
        ].join('-');
        var heureActuelle = aujourdHui.getHours();
        Array.prototype.forEach.call(heureCreneau.options, function (option) {
            if (!option.hasAttribute('data-heure')) return;
            option.disabled = dateCreneau.value === dateLocale && Number(option.dataset.heure) < heureActuelle;
        });
        if (heureCreneau.selectedOptions.length && heureCreneau.selectedOptions[0].disabled) {
            heureCreneau.value = '';
        }
        dateCreneau.required = heureCreneau.value !== '';
        heureCreneau.required = dateCreneau.value !== '';
    }
    dateCreneau.addEventListener('change', actualiserCreneaux);
    heureCreneau.addEventListener('change', actualiserCreneaux);
    actualiserCreneaux();

    // ----- Apparition au défilement -----
    var els = document.querySelectorAll('.reveal');
    if (reduit || !('IntersectionObserver' in window)) {
        els.forEach(function (e) { e.classList.add('reveal--visible'); });
    } else {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('reveal--visible'); io.unobserve(en.target); } });
        }, { threshold: 0.1 });
        els.forEach(function (e) { io.observe(e); });
    }

    // ----- Photo : aperçu, glisser-déposer, retrait -----
    var inputPhoto = document.getElementById('input-photo');
    var apercu = document.getElementById('apercu-photo');
    var placeholder = document.getElementById('upload-placeholder');
    var zone = document.getElementById('upload-zone');
    var btnRetirer = document.getElementById('retirer-photo');

    function afficherPhoto() {
        var f = inputPhoto.files[0];
        if (!f) return;
        var lecteur = new FileReader();
        lecteur.onload = function (e) {
            apercu.src = e.target.result; apercu.style.display = 'block';
            placeholder.style.display = 'none'; btnRetirer.style.display = 'inline-flex';
        };
        lecteur.readAsDataURL(f);
    }
    inputPhoto.addEventListener('change', afficherPhoto);
    btnRetirer.addEventListener('click', function () {
        inputPhoto.value = ''; apercu.style.display = 'none'; apercu.removeAttribute('src');
        placeholder.style.display = ''; btnRetirer.style.display = 'none';
    });
    ['dragenter', 'dragover'].forEach(function (ev) { zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.add('upload-zone--survol'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { zone.addEventListener(ev, function () { zone.classList.remove('upload-zone--survol'); }); });
    zone.addEventListener('drop', function (e) {
        e.preventDefault();
        if (e.dataTransfer.files.length) { inputPhoto.files = e.dataTransfer.files; afficherPhoto(); }
    });

    // ----- Compteur de caractères + progression -----
    var desc = document.getElementById('description');
    var compteur = document.getElementById('compteur-car');
    var rempli = document.getElementById('prog-rempli');
    var texte = document.getElementById('prog-texte');
    var categoriesVersPole = <?= json_encode($categorieVersPole, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    var conteneurSousCategories = document.getElementById('dem-sous-categories');

    function afficherSousCategories(poleId, reinitialiser) {
        conteneurSousCategories.hidden = !poleId;
        conteneurSousCategories.querySelectorAll('.dem-sous-categories__groupe').forEach(function (groupe) {
            var actif = groupe.dataset.pole === String(poleId);
            groupe.hidden = !actif;
            var choix = groupe.querySelectorAll('input[name="categorie_id"]');
            choix.forEach(function (radio, index) {
                radio.disabled = !actif;
                radio.required = actif && index === 0;
                if (reinitialiser && !actif) radio.checked = false;
            });
        });
    }
    document.querySelectorAll('input[name="categorie_pole"]').forEach(function (radio) {
        radio.required = true;
        radio.addEventListener('change', function () {
            afficherSousCategories(radio.value, true);
            actualiserOptionsPaiement();
            progression();
        });
    });
    var poleInitial = valeurCochee('categorie_pole');
    afficherSousCategories(poleInitial, false);

    function progression() {
        compteur.textContent = desc.value.length;
        var n = 0;
        if (document.querySelector('input[name="categorie_id"]:checked')) n++;
        if (desc.value.trim() !== '') n++;
        if (document.querySelector('input[name="adresse_id"]:checked')) n++;
        if (document.querySelector('input[name="urgence"]:checked')) n++;
        rempli.style.width = (n / 4 * 100) + '%';
        texte.textContent = n === 4 ? 'Tout est prêt, vous pouvez envoyer la demande' : n + ' / 4 étapes complétées';
    }
    document.getElementById('form-demande').addEventListener('input', progression);
    document.getElementById('form-demande').addEventListener('change', progression);

    // ----- Options de paiement selon la catégorie -----
    var ELIGIBILITE_POLES = <?= json_encode($eligibilitePoles, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

    // Tant que le client n'a pas choisi lui-même un mode, l'abonnement est sélectionné s'il couvre la catégorie
    var choixManuel = <?= $modePost !== '' ? 'true' : 'false' ?>;

    var ABO = <?= json_encode(['actif' => (bool) $abonnementActif, 'credits' => (int) ($abonnementActif['credits_restants'] ?? 0)]) ?>;
    var NB_PASS = <?= (int) count($passDisponibles) ?>;

    // Une option indisponible reste visible, grisée, avec la raison
    function reglerOption(label, dispo, info) {
        label.querySelector('input[name="mode_paiement"]').disabled = !dispo;
        label.classList.toggle('pay-option--off', !dispo);
        label.querySelector('small').textContent = info;
    }

    function actualiserOptionsPaiement() {
        var cat = document.querySelector('input[name="categorie_id"]:checked');
        var labelAbo = document.getElementById('option-abonnement');
        var labelPass = document.querySelector('#option-pass .pay-option');
        var selectPass = document.getElementById('select-pass');
        var radioAbo = labelAbo.querySelector('input');
        var radioPass = labelPass.querySelector('input');
        var radioNormal = document.querySelector('input[name="mode_paiement"][value="normal"]');
        var poleId = cat && categoriesVersPole[cat.value];
        var el = (poleId && ELIGIBILITE_POLES[poleId]) || { abonnement: false, pass: [] };

        // Abonnement
        var infoAbo;
        if (!cat) infoAbo = "Choisissez d'abord une catégorie";
        else if (!ABO.actif) infoAbo = "Vous n'avez pas d'abonnement actif";
        else if (ABO.credits <= 0) infoAbo = "Plus de crédit disponible";
        else if (!el.abonnement) infoAbo = "Cette catégorie n'est pas couverte par votre abonnement";
        else infoAbo = ABO.credits + ' crédit(s) restant(s) · choisi par défaut';
        reglerOption(labelAbo, el.abonnement, infoAbo);
        if (!el.abonnement && radioAbo.checked) radioNormal.checked = true;
        if (el.abonnement && !choixManuel) radioAbo.checked = true;

        // Pass
        var infoPass;
        if (!cat) infoPass = "Choisissez d'abord une catégorie";
        else if (NB_PASS === 0) infoPass = "Vous n'avez aucun Pass disponible";
        else if (el.pass.length === 0) infoPass = "Aucun Pass valable pour cette catégorie";
        else infoPass = el.pass.length + ' Pass utilisable' + (el.pass.length > 1 ? 's' : '') + ' pour cette intervention';
        reglerOption(labelPass, el.pass.length > 0, infoPass);
        if (el.pass.length > 0) {
            selectPass.innerHTML = el.pass.map(function (p) {
                var d = p.date_achat ? ' (achat du ' + new Date(p.date_achat).toLocaleDateString('fr-FR') + ')' : '';
                return '<option value="' + esc(p.id) + '">' + esc(p.nom) + d + '</option>';
            }).join('');
        } else if (radioPass.checked) {
            radioNormal.checked = true;
        }
        selectPass.style.display = (radioPass.checked && el.pass.length > 0) ? 'block' : 'none';
    }
    document.querySelectorAll('input[name="categorie_id"]').forEach(function (r) { r.addEventListener('change', actualiserOptionsPaiement); });
    document.querySelectorAll('input[name="mode_paiement"]').forEach(function (r) {
        r.addEventListener('change', function () {
            choixManuel = true;
            document.getElementById('select-pass').style.display = document.querySelector('input[name="mode_paiement"][value="pass"]').checked ? 'block' : 'none';
        });
    });

    // ----- Anti double envoi -----
    document.getElementById('form-demande').addEventListener('submit', function () {
        var b = document.getElementById('btn-envoyer');
        setTimeout(function () { b.disabled = true; b.textContent = 'Envoi en cours…'; }, 0);
    });
    window.addEventListener('pageshow', function (e) {
        if (e.persisted) { var b = document.getElementById('btn-envoyer'); b.disabled = false; b.innerHTML = 'Envoyer ma demande <?= addslashes(icone('arrow', 18)) ?>'; }
    });

    // ----- Sauvegarde automatique du brouillon (survit à un rechargement ou une fermeture) -----
    var CLE = 'allopro_brouillon_demande_<?= (int) $_SESSION['user_id'] ?>';
    var EST_POST = <?= $_SERVER['REQUEST_METHOD'] === 'POST' ? 'true' : 'false' ?>;   // le serveur a déjà renvoyé les valeurs saisies
    var EFFACER = <?= $effacerBrouillon ? 'true' : 'false' ?>;                       // la demande vient d'être envoyée
    var form = document.getElementById('form-demande');

    function valeurCochee(nom) {
        var c = document.querySelector('input[name="' + nom + '"]:checked');
        return c ? c.value : '';
    }
    function cocher(nom, valeur) {
        if (!valeur) return;
        var r = document.querySelector('input[name="' + nom + '"][value="' + String(valeur).replace(/"/g, '') + '"]');
        if (r && !r.disabled) r.checked = true;
    }
    function viderBrouillon() { try { localStorage.removeItem(CLE); } catch (e) {} }
    function sauverBrouillon() {
        try {
            var b = {
                t: Date.now(),
                categorie: valeurCochee('categorie_id'),
                description: desc.value,
                urgence: valeurCochee('urgence'),
                adresse: valeurCochee('adresse_id'),
                mode: choixManuel ? valeurCochee('mode_paiement') : '',
                pass: document.getElementById('select-pass').value
            };
            if (!b.categorie && !b.adresse && b.description.trim() === '') { viderBrouillon(); return; }
            localStorage.setItem(CLE, JSON.stringify(b));
        } catch (e) { /* stockage indisponible : on ignore */ }
    }
    function lireBrouillon() {
        try {
            var b = JSON.parse(localStorage.getItem(CLE) || 'null');
            if (b && Date.now() - b.t < 24 * 3600 * 1000) return b;   // valable 24 h
            viderBrouillon();
        } catch (e) {}
        return null;
    }

    if (EFFACER) viderBrouillon();
    var brouillon = (!EST_POST && !EFFACER) ? lireBrouillon() : null;

    if (brouillon) {
        var poleBrouillon = categoriesVersPole[brouillon.categorie]
            || (ELIGIBILITE_POLES[brouillon.categorie] ? brouillon.categorie : '');
        cocher('categorie_pole', poleBrouillon);
        afficherSousCategories(poleBrouillon, false);
        if (categoriesVersPole[brouillon.categorie]) cocher('categorie_id', brouillon.categorie);
        cocher('urgence', brouillon.urgence);
        cocher('adresse_id', brouillon.adresse);
        if (brouillon.description) desc.value = brouillon.description;
        if (brouillon.mode) { cocher('mode_paiement', brouillon.mode); choixManuel = true; }
        document.getElementById('dem-brouillon').style.display = 'flex';
    }

    actualiserOptionsPaiement();

    if (brouillon && brouillon.pass) {
        var sp = document.getElementById('select-pass');
        if (sp.querySelector('option[value="' + String(brouillon.pass).replace(/"/g, '') + '"]')) sp.value = brouillon.pass;
    }
    progression();

    form.addEventListener('input', sauverBrouillon);
    form.addEventListener('change', sauverBrouillon);
    document.getElementById('dem-brouillon-effacer').addEventListener('click', function () {
        viderBrouillon();
        form.reset();
        window.location.reload();
    });
})();
</script>
</body>
</html>