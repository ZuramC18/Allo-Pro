<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['admin']);
$traitementAdminDemande = true;
require __DIR__ . '/../conseiller/traiter-demande.php';
