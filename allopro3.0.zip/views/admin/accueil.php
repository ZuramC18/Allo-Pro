<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('tableau_bord');
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/TicketSav.php';
require_once __DIR__ . '/../../models/AdminPilotage.php';

$demandeModel = new Demande();
$userModel = new User();
$partenaireModel = new Partenaire();
$paiementModel = new Paiement();
$ticketModel = new TicketSav();
$pilotageModel = new AdminPilotage();

$demandesAujourdhui = $demandeModel->compterAujourdhui();
$enCours = $demandeModel->compterEnCours();
$termineesAujourdhui = $demandeModel->compterTermineesAujourdhui();
$savOuverts = $ticketModel->compterOuverts();
$nouveauxClients = $userModel->compterNouveauxAujourdhui();
$partenairesActifs = $partenaireModel->compterActifs();
$caJour = $paiementModel->sommeAujourdhui();
$statutsDemandes = $demandeModel->compterParStatutGlobal();
$statutsPaiements = $paiementModel->sommeParStatut();
$caMois = $paiementModel->sommeMoisEnCours();
$totauxGlobaux = $pilotageModel->getTotauxGlobaux();

$demandesRecentes = $demandeModel->getRecentes(6);
$libellesStatuts = ['nouvelle' => ['Nouvelle', 'violet'], 'attribuee' => ['Attribuée', 'amber'], 'en_cours' => ['En cours', 'amber'], 'terminee' => ['Terminée', 'vert'], 'annulee' => ['Annulée', 'gris']];
$resumeStatuts = [
    'nouvelle' => ['Nouvelles', 'violet'],
    'attribuee' => ['Attribuées', 'amber'],
    'en_cours' => ['En cours', 'amber'],
    'terminee' => ['Terminées', 'vert'],
    'annulee' => ['Annulées', 'gris'],
];
$totalDemandes = (int) $statutsDemandes['toutes'];
$urlDemandes = peut('demandes') ? 'liste-demandes.php' : 'interventions.php';
$joursFrancais = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
$moisFrancais = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
$maintenant = new DateTimeImmutable('now');
$dateFrancaise = $joursFrancais[(int) $maintenant->format('w')] . ' ' . $maintenant->format('j') . ' ' . $moisFrancais[(int) $maintenant->format('n')] . ' ' . $maintenant->format('Y');
$indicateursGlobaux = [];
if (peut('clients')) {
    $indicateursGlobaux[] = ['Clients', $totauxGlobaux['clients_total'], 'clients.php', 'violet'];
}
if (peut('demandes') || peut('interventions')) {
    $indicateursGlobaux[] = ['Demandes totales', $totauxGlobaux['demandes_total'], $urlDemandes, 'violet'];
}
if (peut('interventions')) {
    $indicateursGlobaux[] = ['Interventions actives', $totauxGlobaux['interventions_actives'] . ' / ' . $totauxGlobaux['interventions_total'], 'interventions.php', 'amber'];
}
if (peut('partenaires')) {
    $indicateursGlobaux[] = ['Partenaires', $totauxGlobaux['partenaires_actifs'] . ' actifs / ' . $totauxGlobaux['partenaires_total'], 'partenaires.php', 'vert'];
}
if (peut('techniciens')) {
    $indicateursGlobaux[] = ['Techniciens', $totauxGlobaux['techniciens_actifs'] . ' actifs / ' . $totauxGlobaux['techniciens_total'], 'techniciens.php', 'vert'];
}
if (peut('devis_entreprises')) {
    $indicateursGlobaux[] = ['Demandes entreprises', $totauxGlobaux['demandes_b2b'], 'contrats-entreprises.php', 'amber'];
    $indicateursGlobaux[] = ['Entreprises B2B', $totauxGlobaux['entreprises_actives'] . ' actives / ' . $totauxGlobaux['entreprises_total'], 'contrats-entreprises.php', 'violet'];
    $indicateursGlobaux[] = ['Contrats B2B actifs', $totauxGlobaux['contrats_actifs'] . ' / ' . $totauxGlobaux['contrats_total'], 'contrats-entreprises.php', 'amber'];
}
if (peut('paiements')) {
    $indicateursGlobaux[] = ['CA encaissé global', number_format($totauxGlobaux['chiffre_affaires_total'], 0, ',', ' ') . ' F', 'paiements.php', 'vert', 'dont ' . number_format($totauxGlobaux['paiements_b2b_total'], 0, ',', ' ') . ' F en B2B'];
    $indicateursGlobaux[] = ['CA encaissé ce mois', number_format($totauxGlobaux['chiffre_affaires_mois'], 0, ',', ' ') . ' F', 'paiements.php', 'vert', 'B2B inclus'];
}
if (peut('sav')) {
    $indicateursGlobaux[] = ['Tickets SAV ouverts', $totauxGlobaux['sav_ouverts'], 'sav.php', 'rouge'];
}
if (peut('remboursements_sav')) {
    $indicateursGlobaux[] = ['Remboursements à traiter', $totauxGlobaux['remboursements_en_attente'], 'remboursements-sav.php?statut=en_attente', 'amber', number_format($totauxGlobaux['montant_remboursements_en_attente'], 0, ',', ' ') . ' F'];
}
if (peut('demandes')) {
    $indicateursGlobaux[] = ['Créneaux à vérifier', $totauxGlobaux['creneaux_a_traiter'], 'ajustements-creneaux.php', 'rouge'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tableau de bord — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Tableau de bord</div>
                <div class="admin-entete__sous-titre"><?= htmlspecialchars($dateFrancaise, ENT_QUOTES, 'UTF-8') ?></div>
            </div>
            <div class="admin-badge-role">
                <div class="admin-badge-role__avatar"><?= htmlspecialchars(strtoupper(mb_substr($_SESSION['nom'] ?? 'A', 0, 1))) ?></div>
                <?= htmlspecialchars($_SESSION['nom'] ?? 'Admin') ?>
            </div>
        </div>

        <?php if ($indicateursGlobaux): ?>
        <section class="admin-panneau admin-pilotage" aria-labelledby="admin-pilotage-titre">
            <div class="admin-panneau__titre">
                <span id="admin-pilotage-titre">Pilotage global du site</span>
                <span class="admin-pilotage__periode">Données cumulées · CA encaissé</span>
            </div>
            <div class="admin-pilotage__grille">
                <?php foreach ($indicateursGlobaux as $indicateur): ?>
                <a class="admin-pilotage__indicateur admin-pilotage__indicateur--<?= htmlspecialchars($indicateur[3], ENT_QUOTES, 'UTF-8') ?>" href="<?= htmlspecialchars($indicateur[2], ENT_QUOTES, 'UTF-8') ?>">
                    <span><?= htmlspecialchars($indicateur[0], ENT_QUOTES, 'UTF-8') ?></span>
                    <strong><?= htmlspecialchars((string) $indicateur[1], ENT_QUOTES, 'UTF-8') ?></strong>
                    <?php if (isset($indicateur[4])): ?><small><?= htmlspecialchars($indicateur[4], ENT_QUOTES, 'UTF-8') ?></small><?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <div class="admin-kpi-grille">
            <?php if (peut('interventions') || peut('demandes')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13.5V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5.5"/><path d="m16 10-4 4-4-4"/><path d="M12 14V3"/></svg></div><div class="admin-kpi-carte__label">Demandes aujourd'hui</div><div class="admin-kpi-carte__valeur"><?= $demandesAujourdhui ?></div></div>
            <?php endif; ?>
            <?php if (peut('interventions')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div><div class="admin-kpi-carte__label">Interventions en cours</div><div class="admin-kpi-carte__valeur"><?= $enCours ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/><circle cx="12" cy="12" r="9"/></svg></div><div class="admin-kpi-carte__label">Terminées aujourd'hui</div><div class="admin-kpi-carte__valeur"><?= $termineesAujourdhui ?></div></div>
            <?php endif; ?>
            <?php if (peut('sav')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--rouge"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 13v-2a8 8 0 0 1 16 0v2"/><path d="M4 13H3a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h3v-6H4Zm16 0h1a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-3v-6h2Z"/><path d="M16 19a4 4 0 0 1-4 2h-1"/></svg></div><div class="admin-kpi-carte__label">Tickets SAV ouverts</div><div class="admin-kpi-carte__valeur"><?= $savOuverts ?></div></div>
            <?php endif; ?>
        </div>

        <div class="admin-kpi-grille">
            <?php if (peut('clients')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M3 21v-2a6 6 0 0 1 12 0v2"/><path d="M19 8v6m-3-3h6"/></svg></div><div class="admin-kpi-carte__label">Nouveaux clients</div><div class="admin-kpi-carte__valeur"><?= $nouveauxClients ?></div></div>
            <?php endif; ?>
            <?php if (peut('partenaires')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/><path d="M19 21V11l-6-4"/><path d="M8 9v.01M8 12v.01M8 15v.01M8 18v.01M16 14v.01M16 17v.01"/></svg></div><div class="admin-kpi-carte__label">Partenaires actifs</div><div class="admin-kpi-carte__valeur"><?= $partenairesActifs ?></div></div>
            <?php endif; ?>
            <?php if (peut('paiements')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg></div><div class="admin-kpi-carte__label">CA du jour</div><div class="admin-kpi-carte__valeur"><?= number_format($caJour, 0, ',', ' ') ?> F</div></div>
            <?php endif; ?>
            <?php if (peut('interventions')): ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m7 14 4-4 4 4 6-7"/></svg></div><div class="admin-kpi-carte__label">Total demandes</div><div class="admin-kpi-carte__valeur"><?= $totalDemandes ?></div></div>
            <?php endif; ?>
        </div>

        <?php if (peut('demandes') || peut('interventions') || peut('paiements')): ?>
        <div class="admin-dashboard-details">
            <?php if (peut('demandes') || peut('interventions')): ?>
            <section class="admin-panneau admin-dashboard-details__panel" aria-labelledby="admin-resume-demandes">
                <div class="admin-panneau__titre">
                    <span id="admin-resume-demandes">Vue d'ensemble des demandes</span>
                    <a href="<?= htmlspecialchars($urlDemandes, ENT_QUOTES, 'UTF-8') ?>" class="admin-lien-voir-tout">Consulter →</a>
                </div>
                <div class="admin-dashboard-details__total">
                    <strong><?= number_format($totalDemandes, 0, ',', ' ') ?></strong>
                    <span>dossiers au total</span>
                </div>
                <div class="admin-dashboard-statuts">
                    <?php foreach ($resumeStatuts as $cle => [$libelle, $couleur]):
                        $nombre = (int) ($statutsDemandes[$cle] ?? 0);
                        $pourcentage = $totalDemandes > 0 ? (int) round($nombre / $totalDemandes * 100) : 0;
                    ?>
                    <a class="admin-dashboard-statut" href="<?= htmlspecialchars($urlDemandes, ENT_QUOTES, 'UTF-8') ?>?statut=<?= urlencode($cle) ?>">
                        <span class="admin-dashboard-statut__entete">
                            <span class="admin-dashboard-statut__nom"><i class="admin-dashboard-statut__point admin-dashboard-statut__point--<?= htmlspecialchars($couleur, ENT_QUOTES, 'UTF-8') ?>"></i><?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?></span>
                            <strong><?= number_format($nombre, 0, ',', ' ') ?></strong>
                        </span>
                        <span class="admin-dashboard-statut__barre" aria-hidden="true"><span class="admin-dashboard-statut__progression admin-dashboard-statut__progression--<?= htmlspecialchars($couleur, ENT_QUOTES, 'UTF-8') ?>" style="width: <?= $pourcentage ?>%"></span></span>
                        <span class="admin-dashboard-statut__pourcentage"><?= $pourcentage ?> % du portefeuille</span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <?php if (peut('paiements')): ?>
            <section class="admin-panneau admin-dashboard-details__panel admin-dashboard-finances" aria-labelledby="admin-resume-paiements">
                <div class="admin-panneau__titre">
                    <span id="admin-resume-paiements">Suivi des paiements</span>
                    <a href="paiements.php" class="admin-lien-voir-tout">Voir les paiements →</a>
                </div>
                <div class="admin-dashboard-finances__principal">
                    <span>Chiffre d'affaires encaissé ce mois</span>
                    <strong><?= number_format((float) $caMois, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></strong>
                </div>
                <div class="admin-dashboard-finances__indicateurs">
                    <div class="admin-dashboard-finances__indicateur admin-dashboard-finances__indicateur--vert">
                        <span class="admin-dashboard-finances__marque" aria-hidden="true"></span>
                        <span>Validés</span>
                        <strong><?= number_format((int) ($statutsPaiements['valide']['nb'] ?? 0), 0, ',', ' ') ?></strong>
                        <small><?= number_format((float) ($statutsPaiements['valide']['total'] ?? 0), 0, ',', ' ') ?> F</small>
                    </div>
                    <div class="admin-dashboard-finances__indicateur admin-dashboard-finances__indicateur--amber">
                        <span class="admin-dashboard-finances__marque" aria-hidden="true"></span>
                        <span>En attente</span>
                        <strong><?= number_format((int) ($statutsPaiements['en_attente']['nb'] ?? 0), 0, ',', ' ') ?></strong>
                        <small><?= number_format((float) ($statutsPaiements['en_attente']['total'] ?? 0), 0, ',', ' ') ?> F</small>
                    </div>
                    <div class="admin-dashboard-finances__indicateur admin-dashboard-finances__indicateur--rouge">
                        <span class="admin-dashboard-finances__marque" aria-hidden="true"></span>
                        <span>Échoués</span>
                        <strong><?= number_format((int) ($statutsPaiements['echoue']['nb'] ?? 0), 0, ',', ' ') ?></strong>
                        <small><?= number_format((float) ($statutsPaiements['echoue']['total'] ?? 0), 0, ',', ' ') ?> F</small>
                    </div>
                </div>
            </section>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if (peut('interventions')): ?>
        <div class="admin-panneau">
            <div class="admin-panneau__titre">
                <span>Demandes récentes</span>
                <a href="interventions.php" class="admin-lien-voir-tout">Voir tout →</a>
            </div>
            <div class="admin-table-wrapper" role="region" aria-label="Demandes récentes" tabindex="0">
                <table class="admin-table">
                    <tr><th>Dossier</th><th>Client</th><th>Catégorie</th><th>Statut</th><th>Date</th></tr>
                    <?php foreach ($demandesRecentes as $d): $s = $libellesStatuts[$d['statut']] ?? ['—', 'gris']; ?>
                    <tr class="admin-dashboard-demande" tabindex="0" role="link" aria-label="Ouvrir le dossier <?= htmlspecialchars($d['numero_dossier'], ENT_QUOTES, 'UTF-8') ?>" data-href="traiter-demande.php?id=<?= (int) $d['id'] ?>">
                        <td><strong><?= htmlspecialchars($d['numero_dossier']) ?></strong><?php if (!empty($d['est_demande_entreprise'])): ?><span class="badge-demande-entreprise" title="<?= htmlspecialchars($d['entreprise_b2b_nom'] ?? '', ENT_QUOTES, 'UTF-8') ?>">Demande venant d’une entreprise</span><?php endif; ?></td>
                        <td><?= htmlspecialchars($d['client_nom']) ?></td>
                        <td><?= htmlspecialchars($d['categorie_nom']) ?></td>
                        <td><span class="admin-badge admin-badge--<?= $s[1] ?>"><?= $s[0] ?></span></td>
                        <td><?= date('d/m H:i', strtotime($d['date_creation'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>
<script>
document.querySelectorAll('.admin-dashboard-demande').forEach(ligne => {
    const ouvrir = () => { window.location.href = ligne.dataset.href; };
    ligne.addEventListener('click', ouvrir);
    ligne.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            ouvrir();
        }
    });
});
</script>
</body>
</html>