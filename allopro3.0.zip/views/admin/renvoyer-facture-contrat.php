<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
$roleContrats = $_SESSION['role'] ?? '';
$estFinanceContrats = $roleContrats === 'finance';
verifierAcces($estFinanceContrats ? 'devis_entreprises' : 'parametres');
require_once __DIR__ . '/../../models/FactureContratB2B.php';

$csrfKey = 'csrf_contrats_entreprises_admin';
$csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
$paiementId = filter_var($_POST['paiement_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$contratId = filter_var($_POST['contrat_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SESSION[$csrfKey])
    || !hash_equals($_SESSION[$csrfKey], $csrf) || $paiementId === false || $contratId === false) {
    http_response_code(403);
    exit('La demande de renvoi est invalide ou le formulaire a expiré.');
}

try {
    $facture = (new FactureContratB2B())->emettrePourPaiement((int) $paiementId, true);
    $statut = $facture['email_statut'] === 'envoye' ? 'envoyee' : 'echec';
} catch (Throwable $exception) {
    error_log('Renvoi facture règlement contrat B2B #' . (int) $paiementId . ' : ' . $exception->getMessage());
    $statut = 'echec';
}

journaliser(
    $estFinanceContrats ? 'finance.facture_contrat_b2b_renvoyee' : 'admin.facture_contrat_b2b_renvoyee',
    'paiement_contrat_b2b',
    (int) $paiementId,
    null,
    'Contrat #' . (int) $contratId . ' · ' . $statut
);
header('Location: detail-contrat-entreprise.php?id=' . (int) $contratId . '&facture=' . $statut);
exit;
