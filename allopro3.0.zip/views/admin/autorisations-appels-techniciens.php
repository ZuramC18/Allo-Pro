<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['admin']);
verifierAcces('messagerie');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Accès aux appels clients — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/autorisations-appels-techniciens.css?v=<?= filemtime(__DIR__ . '/../../public/css/autorisations-appels-techniciens.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <?php include __DIR__ . '/../../includes/autorisation-appel-technicien-page.php'; ?>
</div>
</body>
</html>
