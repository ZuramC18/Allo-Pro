<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAdminConnecte();

$echapper = static fn($valeur): string => htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
$afficher = static fn($valeur): string => ($valeur === false || $valeur === null || $valeur === '') ? '—' : (string) $valeur;
$formaterOctets = static function ($octets): string {
    if (!is_numeric($octets) || $octets < 0) {
        return '—';
    }
    $unites = ['o', 'Ko', 'Mo', 'Go', 'To'];
    $taille = (float) $octets;
    $indice = 0;
    while ($taille >= 1024 && $indice < count($unites) - 1) {
        $taille /= 1024;
        $indice++;
    }
    return number_format($taille, $indice === 0 ? 0 : 2, ',', ' ') . ' ' . $unites[$indice];
};

$racineServeur = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: __DIR__;
$espaceLibre = disk_free_space($racineServeur);
$espaceTotal = disk_total_space($racineServeur);
$extensions = get_loaded_extensions();
sort($extensions, SORT_NATURAL | SORT_FLAG_CASE);
$driversPdo = PDO::getAvailableDrivers();
sort($driversPdo, SORT_NATURAL | SORT_FLAG_CASE);
$chargeSysteme = function_exists('sys_getloadavg') ? sys_getloadavg() : false;
$serveurHttps = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
    || (($_SERVER['SERVER_PORT'] ?? '') === '443');
$informationsServeur = [
    'Nom d’hôte' => $afficher(gethostname()),
    'Système d’exploitation' => PHP_OS_FAMILY . ' (' . PHP_OS . ')',
    'Architecture' => php_uname('m'),
    'Adresse du serveur' => $afficher($_SERVER['SERVER_ADDR'] ?? null),
    'Logiciel serveur' => $afficher($_SERVER['SERVER_SOFTWARE'] ?? null),
    'Protocole HTTP' => $afficher($_SERVER['SERVER_PROTOCOL'] ?? null),
    'Port HTTP' => $afficher($_SERVER['SERVER_PORT'] ?? null),
    'Connexion HTTPS' => $serveurHttps ? 'Activée' : 'Désactivée',
];
$informationsPhp = [
    'Version PHP' => PHP_VERSION,
    'Interface (SAPI)' => PHP_SAPI,
    'Taille des entiers' => PHP_INT_SIZE * 8 . ' bits',
    'Fuseau horaire' => date_default_timezone_get(),
    'Limite mémoire' => ini_get('memory_limit'),
    'Temps maximal d’exécution' => ini_get('max_execution_time') . ' s',
    'Taille maximale d’envoi' => ini_get('upload_max_filesize'),
    'Taille maximale des requêtes' => ini_get('post_max_size'),
    'Nombre maximal de variables' => ini_get('max_input_vars'),
    'Extensions PDO disponibles' => $driversPdo ? implode(', ', $driversPdo) : 'Aucun pilote',
];
$derniereActualisation = new DateTimeImmutable('now');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Informations serveur — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/admin-serveur.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin-serveur.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu admin-serveur">
        <header class="admin-serveur__entete">
            <div>
                <p class="admin-serveur__surtitre">ESPACE ADMINISTRATION</p>
                <h1>Informations serveur</h1>
                <p>État et configuration technique de l’environnement qui exécute ALLÔ PRO.</p>
            </div>
            <a class="admin-serveur__actualiser" href="serveur.php">Actualiser</a>
        </header>

        <div class="admin-serveur__actualise" role="status">
            Données relevées le <?= $echapper($derniereActualisation->format('d/m/Y à H:i:s')) ?>
        </div>

        <section class="admin-serveur__grille" aria-label="Informations techniques">
            <article class="admin-serveur__panneau">
                <h2>Serveur</h2>
                <dl>
                    <?php foreach ($informationsServeur as $libelle => $valeur): ?>
                    <div><dt><?= $echapper($libelle) ?></dt><dd><?= $echapper($valeur) ?></dd></div>
                    <?php endforeach; ?>
                </dl>
            </article>

            <article class="admin-serveur__panneau">
                <h2>Environnement PHP</h2>
                <dl>
                    <?php foreach ($informationsPhp as $libelle => $valeur): ?>
                    <div><dt><?= $echapper($libelle) ?></dt><dd><?= $echapper($afficher($valeur)) ?></dd></div>
                    <?php endforeach; ?>
                </dl>
            </article>

            <article class="admin-serveur__panneau">
                <h2>Espace disque</h2>
                <dl>
                    <div><dt>Volume utilisé par le site</dt><dd><?= $echapper($racineServeur) ?></dd></div>
                    <div><dt>Espace libre</dt><dd><?= $echapper($formaterOctets($espaceLibre)) ?></dd></div>
                    <div><dt>Capacité totale</dt><dd><?= $echapper($formaterOctets($espaceTotal)) ?></dd></div>
                    <?php if (is_numeric($espaceLibre) && is_numeric($espaceTotal) && $espaceTotal > 0): ?>
                    <div><dt>Espace utilisé</dt><dd><?= $echapper(number_format(100 - ($espaceLibre / $espaceTotal * 100), 1, ',', ' ')) ?> %</dd></div>
                    <?php endif; ?>
                </dl>
            </article>

            <article class="admin-serveur__panneau">
                <h2>Charge système</h2>
                <?php if (is_array($chargeSysteme)): ?>
                    <dl>
                        <?php foreach (['1 minute', '5 minutes', '15 minutes'] as $index => $periode): ?>
                        <div><dt>Moyenne sur <?= $echapper($periode) ?></dt><dd><?= $echapper(number_format((float) ($chargeSysteme[$index] ?? 0), 2, ',', ' ')) ?></dd></div>
                        <?php endforeach; ?>
                    </dl>
                <?php else: ?>
                    <p class="admin-serveur__indisponible">Cette information n’est pas disponible sur cet environnement.</p>
                <?php endif; ?>
            </article>

            <article class="admin-serveur__panneau admin-serveur__panneau--extensions">
                <h2>Extensions PHP chargées <span><?= count($extensions) ?></span></h2>
                <?php if ($extensions): ?>
                <ul class="admin-serveur__extensions">
                    <?php foreach ($extensions as $extension): ?>
                    <li><?= $echapper($extension) ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php else: ?>
                <p class="admin-serveur__indisponible">Aucune extension détectée.</p>
                <?php endif; ?>
            </article>
        </section>
    </main>
</div>
</body>
</html>
