<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAdminConnecte();
require_once __DIR__ . '/../../models/MessageContact.php';

if (empty($_SESSION['csrf_messages_contact'])) {
    $_SESSION['csrf_messages_contact'] = bin2hex(random_bytes(32));
}

$messageModel = new MessageContact();
$erreur = '';
$messageSucces = $_SESSION['flash_messages_contact'] ?? '';
unset($_SESSION['flash_messages_contact']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    $idSoumis = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

    if (!hash_equals($_SESSION['csrf_messages_contact'], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($action !== 'ouvrir' || !$idSoumis || $idSoumis < 1) {
        $erreur = 'L’action demandée est invalide.';
    } else {
        $messageExiste = $messageModel->getParId((int) $idSoumis);
        if (!$messageExiste) {
            http_response_code(404);
            $erreur = 'Ce message n’existe pas.';
        } else {
            $messageModel->marquerLu((int) $idSoumis);
            header('Location: messages-contact.php?id=' . (int) $idSoumis);
            exit;
        }
    }
}

$idMessage = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$messageDetail = null;
if ($idMessage !== false && $idMessage !== null && $idMessage > 0) {
    $messageDetail = $messageModel->getParId((int) $idMessage);
    if (!$messageDetail) {
        http_response_code(404);
        $erreur = 'Ce message n’existe pas ou a été supprimé.';
    }
}
$messages = $messageModel->getRecents();
$nombreNouveaux = $messageModel->compterNouveaux();
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messages de contact — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/messages-contact-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/messages-contact-admin.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu messages-contact">
        <header class="admin-entete">
            <div>
                <h1 class="admin-entete__titre">Messages de contact</h1>
                <p class="admin-entete__sous-titre">
                    <?= number_format($nombreNouveaux, 0, ',', ' ') ?> nouveau<?= $nombreNouveaux === 1 ? '' : 'x' ?> ·
                    <?= number_format(count($messages), 0, ',', ' ') ?> message<?= count($messages) === 1 ? '' : 's' ?> affiché<?= count($messages) === 1 ? '' : 's' ?>
                </p>
            </div>
        </header>

        <?php if ($messageSucces !== ''): ?>
            <div class="messages-contact__alerte messages-contact__alerte--ok" role="status"><?= $e($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur !== ''): ?>
            <div class="messages-contact__alerte messages-contact__alerte--erreur" role="alert"><?= $e($erreur) ?></div>
        <?php endif; ?>

        <?php if ($messageDetail): ?>
            <article class="admin-panneau messages-contact__detail">
                <a class="messages-contact__retour" href="messages-contact.php">← Retour à la liste</a>
                <div class="messages-contact__detail-entete">
                    <div>
                        <span class="messages-contact__raison"><?= $e($messageDetail['raison']) ?></span>
                        <h2><?= $e($messageDetail['sujet']) ?></h2>
                    </div>
                    <span class="messages-contact__statut messages-contact__statut--<?= $messageDetail['statut'] === 'nouveau' ? 'nouveau' : 'lu' ?>"><?= $messageDetail['statut'] === 'nouveau' ? 'Nouveau' : 'Lu' ?></span>
                </div>
                <dl class="messages-contact__coordonnees">
                    <div><dt>De</dt><dd><?= $e($messageDetail['nom']) ?></dd></div>
                    <div><dt>Email</dt><dd><a href="mailto:<?= $e($messageDetail['email']) ?>"><?= $e($messageDetail['email']) ?></a></dd></div>
                    <?php if (!empty($messageDetail['telephone'])): ?>
                        <div><dt>Téléphone</dt><dd><a href="tel:<?= $e($messageDetail['telephone']) ?>"><?= $e($messageDetail['telephone']) ?></a></dd></div>
                    <?php endif; ?>
                    <div><dt>Reçu le</dt><dd><?= $e(date('d/m/Y à H:i', strtotime($messageDetail['date_creation']))) ?></dd></div>
                </dl>
                <div class="messages-contact__corps"><?= nl2br($e($messageDetail['message']), false) ?></div>
            </article>
        <?php else: ?>
            <section class="admin-panneau messages-contact__liste" aria-label="Liste des messages reçus">
                <?php if (!$messages): ?>
                    <div class="messages-contact__vide">
                        <h2>Aucun message reçu</h2>
                        <p>Les formulaires envoyés depuis la page de contact apparaîtront ici.</p>
                    </div>
                <?php else: ?>
                    <div class="messages-contact__table-scroll">
                        <table class="admin-table">
                            <thead>
                            <tr><th>État</th><th>Expéditeur</th><th>Raison / sujet</th><th>Reçu le</th><th></th></tr>
                            </thead>
                            <tbody>
                            <?php foreach ($messages as $message): ?>
                                <tr class="<?= $message['statut'] === 'nouveau' ? 'messages-contact__ligne--nouveau' : '' ?>">
                                    <td><span class="messages-contact__statut <?= $message['statut'] === 'nouveau' ? 'messages-contact__statut--nouveau' : 'messages-contact__statut--lu' ?>"><?= $message['statut'] === 'nouveau' ? 'Nouveau' : 'Lu' ?></span></td>
                                    <td><strong><?= $e($message['nom']) ?></strong><small><?= $e($message['email']) ?></small></td>
                                    <td><strong><?= $e($message['raison']) ?></strong><small><?= $e($message['sujet']) ?></small></td>
                                    <td><?= $e(date('d/m/Y H:i', strtotime($message['date_creation']))) ?></td>
                                    <td>
                                        <form method="post">
                                            <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_messages_contact']) ?>">
                                            <input type="hidden" name="action" value="ouvrir">
                                            <input type="hidden" name="id" value="<?= (int) $message['id'] ?>">
                                            <button class="messages-contact__ouvrir" type="submit">Lire le message</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
