<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('partenaires');
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: partenaires.php"); exit; }

$partenaireModel = new Partenaire();
$partenaire = $partenaireModel->getById($id);
if (!$partenaire) { die("Partenaire introuvable."); }
$photoProfil = AvatarProfil::estValide($partenaire['photo_profil'] ?? null, 'partenaires')
    ? (string) $partenaire['photo_profil']
    : null;
$avatarInitiales = !empty($partenaire['avatar_initiales']);
$initialesPartenaire = AvatarProfil::initiales((string) $partenaire['nom_entreprise']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['changer_statut'])) {
        $partenaireModel->changerStatutActivation($id, $_POST['changer_statut']);
        journaliser('partenaire.statut_modifie', 'compte', $id, $partenaire['matricule'], $partenaire['nom_entreprise'] . ' → ' . $_POST['changer_statut']);
    } elseif (isset($_POST['changer_niveau'])) {
        $partenaireModel->changerNiveauManuel($id, $_POST['changer_niveau']);
        journaliser('partenaire.niveau_modifie', 'compte', $id, $partenaire['matricule'], $partenaire['niveau'] . ' → ' . $_POST['changer_niveau']);
    }
    header("Location: partenaire-detail.php?id=" . $id);
    exit;
}

$techniciens = (new Technicien())->getByPartenaire($id);
$missions = $partenaireModel->getMissionsRecentes($id);

$labelsNiveaux = ['partenaire' => 'Partenaire', 'certifie' => 'Certifié', 'premium' => 'Premium', 'excellence' => 'Excellence'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($partenaire['nom_entreprise']) ?> — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .fiche-client { display: grid; grid-template-columns: minmax(0, 320px) minmax(0, 1fr); gap: 20px; min-width: 0; }
        .fiche-client > * { min-width: 0; }
        .fiche-profil__avatar { width: 70px; height: 70px; overflow: hidden; border-radius: 16px; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-family:'Space Grotesk',sans-serif; font-weight: 800; font-size: 21px; margin: 0 auto 14px; }
        .fiche-profil__avatar img { width: 100%; height: 100%; object-fit: cover; }
        .fiche-profil__avatar svg { width: 34px; height: 34px; fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.6; }
        .fiche-profil__nom { font-family:'Space Grotesk',sans-serif; font-weight: 700; font-size: 16px; text-align:center; }
        .fiche-profil__ligne { display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-top: 1px solid #F1F0F6; font-size: 13.5px; }
        .fiche-profil__ligne span:first-child { color: var(--admin-texte-discret); }
        .select-inline { width: 100%; padding: 9px 10px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-family:'Inter',sans-serif; font-size: 13px; margin-top: 4px; }
        .missions-table { min-width: 0; }
        .missions-table__lien { color: var(--admin-violet); font-weight: 650; text-decoration: none; }
        .missions-table__lien:hover { text-decoration: underline; }
        .missions-table__lien:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: 3px; border-radius: 3px; }
        @media (max-width: 700px) {
            .fiche-client { grid-template-columns: minmax(0, 1fr); gap: 0; }
            .fiche-client > div { min-width: 0; }
            .fiche-client .admin-panneau { min-width: 0; padding: 16px 14px; }
            .fiche-profil__ligne { gap: 12px; align-items: flex-start; }
            .fiche-profil__ligne span:last-child { min-width: 0; overflow-wrap: anywhere; text-align: right; }
            .fiche-techniciens__ligne { align-items: flex-start !important; flex-direction: column; gap: 7px; }
            .fiche-techniciens__ligne > span:last-child { display: flex; flex-wrap: wrap; gap: 5px; }
            .missions-table.admin-table { display: block; width: 100%; min-width: 0; }
            .missions-table thead { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }
            .missions-table tbody { display: grid; gap: 10px; }
            .missions-table tbody tr.missions-table__ligne { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); padding: 8px 10px; border: 1px solid var(--admin-bordure); border-radius: 10px; background: var(--admin-carte, #fff); }
            .missions-table tbody tr.missions-table__ligne td { min-width: 0; padding: 9px 5px; border: 0; font-size: 12px; overflow-wrap: anywhere; }
            .missions-table__ligne td:first-child,
            .missions-table__ligne td:last-child { grid-column: 1 / -1; }
            .missions-table__ligne td:first-child { border-bottom: 1px solid var(--admin-bordure); }
            .missions-table__ligne td[data-label]::before { display: block; margin-bottom: 4px; color: var(--admin-texte-discret); font-size: 10px; font-weight: 500; content: attr(data-label); }
            .missions-table__ligne td:last-child { border-top: 1px solid var(--admin-bordure); }
            .missions-table__lien--action { display: flex; align-items: center; justify-content: space-between; min-height: 40px; padding: 0 10px; border-radius: 7px; background: rgba(108, 92, 231, .09); }
            .missions-table__vide { display: block; padding: 20px 12px !important; text-align: center; }
            :root[data-theme="dark"] .missions-table tbody tr.missions-table__ligne { background: var(--admin-carte, #1d202b); }
        }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="partenaires.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour aux partenaires</a>
                <div class="admin-entete__titre" style="margin-top:6px;"><?= htmlspecialchars($partenaire['nom_entreprise']) ?></div>
            </div>
        </div>

        <div class="fiche-client">
            <div>
                <div class="admin-panneau" style="text-align:center;">
                    <div class="fiche-profil__avatar" aria-hidden="true">
                        <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                            <img src="../../public/<?= htmlspecialchars($photoProfil, ENT_QUOTES, 'UTF-8') ?>" alt="">
                        <?php elseif ($avatarInitiales): ?>
                            <?= htmlspecialchars($initialesPartenaire, ENT_QUOTES, 'UTF-8') ?>
                        <?php else: ?>
                            <svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V5h14v16M9 8h2m2 0h2M9 12h2m2 0h2M10 21v-5h4v5M3 5h18l-2-3H5L3 5Z"/></svg>
                        <?php endif; ?>
                    </div>
                    <div class="fiche-profil__nom"><?= htmlspecialchars($partenaire['nom_entreprise']) ?></div>
                    <span class="admin-badge admin-badge--<?= $partenaire['statut'] === 'actif' ? 'vert' : 'rouge' ?>" style="margin-top:8px; display:inline-block;">
                        <?= $partenaire['statut'] === 'actif' ? 'Actif' : 'Inactif' ?>
                    </span>

                    <div class="fiche-profil__ligne"><span>Téléphone</span><span><?= htmlspecialchars($partenaire['telephone'] ?: '—') ?></span></div>
                    <div class="fiche-profil__ligne"><span>Email</span><span><?= htmlspecialchars($partenaire['email']) ?></span></div>
                    <div class="fiche-profil__ligne"><span>Zones</span><span><?= htmlspecialchars($partenaire['zones_intervention'] ?: '—') ?></span></div>
                    <div class="fiche-profil__ligne"><span>Score</span><span><?= $partenaire['score'] > 0 ? number_format($partenaire['score'], 1) . '/5' : '—' ?></span></div>
                    <div class="fiche-profil__ligne"><span>Inscrit le</span><span><?= date('d/m/Y', strtotime($partenaire['date_creation'])) ?></span></div>

                    <form method="POST" style="margin-top:16px; text-align:left;">
                        <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret);">Niveau (ajustement manuel)</label>
                        <select name="changer_niveau" class="select-inline" onchange="this.form.submit()">
                            <?php foreach ($labelsNiveaux as $val => $label): ?>
                                <option value="<?= $val ?>" <?= $partenaire['niveau'] === $val ? 'selected' : '' ?>><?= $label ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>

                    <form method="POST" style="margin-top:12px;">
                        <input type="hidden" name="changer_statut" value="<?= $partenaire['statut'] === 'actif' ? 'inactif' : 'actif' ?>">
                        <button type="submit" style="width:100%; text-align:center; background:<?= $partenaire['statut'] === 'actif' ? '#FDECEC' : '#E6F7ED' ?>; color:<?= $partenaire['statut'] === 'actif' ? 'var(--admin-rouge)' : 'var(--admin-vert)' ?>; border:none; border-radius:6px; padding:9px; cursor:pointer; font-weight:600; font-size:13px;">
                            <?= $partenaire['statut'] === 'actif' ? 'Désactiver le partenaire' : 'Réactiver le partenaire' ?>
                        </button>
                    </form>
                </div>

                <div class="admin-panneau">
                    <div class="admin-panneau__titre">Techniciens (<?= count($techniciens) ?>)</div>
                    <?php if (empty($techniciens)): ?>
                        <p style="font-size:13px; color:var(--admin-texte-discret);">Aucun technicien.</p>
                    <?php endif; ?>
                    <?php foreach ($techniciens as $t): ?>
                        <div class="fiche-techniciens__ligne" style="display:flex; justify-content:space-between; padding:9px 0; border-bottom:1px solid #F1F0F6; font-size:13.5px;">
                            <span><?= htmlspecialchars($t['nom']) ?></span>
                            <span>
                                <span class="admin-badge admin-badge--<?= $t['statut'] === 'actif' ? 'vert' : 'gris' ?>"><?= htmlspecialchars($t['competences'] ?? 'Compétences non renseignées') ?></span>
                                <?php if ($t['statut'] === 'corbeille'): ?><span class="admin-badge admin-badge--gris">Corbeille</span><?php endif; ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Missions récentes</div>
                <table class="admin-table missions-table">
                    <thead><tr><th scope="col">Dossier</th><th scope="col">Catégorie</th><th scope="col">Technicien</th><th scope="col">Statut</th><th scope="col" aria-label="Action"></th></tr></thead>
                    <tbody>
                    <?php if (empty($missions)): ?>
                        <tr><td colspan="5" class="missions-table__vide" style="text-align:center; color:var(--admin-texte-discret); padding:20px;">Aucune mission.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($missions as $m): ?>
                    <tr class="missions-table__ligne">
                        <td><strong><a class="missions-table__lien" href="traiter-demande.php?id=<?= (int) $m['demande_id'] ?>"><?= htmlspecialchars($m['numero_dossier']) ?></a></strong></td>
                        <td data-label="Catégorie"><?= htmlspecialchars($m['categorie_nom']) ?></td>
                        <td data-label="Technicien"><?= htmlspecialchars($m['technicien_nom'] ?? '—') ?></td>
                        <td data-label="Statut"><span class="admin-badge admin-badge--<?= $m['statut'] === 'terminee' ? 'vert' : 'amber' ?>"><?= htmlspecialchars($m['statut']) ?></span></td>
                        <td><a class="missions-table__lien missions-table__lien--action" href="traiter-demande.php?id=<?= (int) $m['demande_id'] ?>">Ouvrir le dossier <span aria-hidden="true">→</span></a></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>