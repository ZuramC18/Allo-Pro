<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('paiements');
require_once __DIR__ . '/../../models/Paiement.php';

$paiementModel = new Paiement();
$statutsAutorises = ['valide', 'en_attente', 'echoue'];
$methodesAutorisees = ['wave', 'orange_money', 'especes'];
$statutFiltre = $_GET['statut'] ?? '';
$methodeFiltre = $_GET['methode'] ?? '';
$recherche = $_GET['recherche'] ?? '';

if (!is_string($statutFiltre) || !in_array($statutFiltre, $statutsAutorises, true)) $statutFiltre = '';
if (!is_string($methodeFiltre) || !in_array($methodeFiltre, $methodesAutorisees, true)) $methodeFiltre = '';
if (!is_string($recherche)) $recherche = '';
$recherche = mb_substr(trim($recherche), 0, 100);

$parPage = 25;
$totalPaiements = $paiementModel->compterAvecFiltres($statutFiltre ?: null, $methodeFiltre ?: null, $recherche ?: null);
$nombrePages = max(1, (int) ceil($totalPaiements / $parPage));
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = max(1, min($nombrePages, $page ?: 1));
$decalage = ($page - 1) * $parPage;
$paiements = $paiementModel->getHistoriqueAvecFiltres(
    $statutFiltre ?: null,
    $methodeFiltre ?: null,
    $parPage,
    $decalage,
    $recherche ?: null
);
$filtres = array_filter([
    'statut' => $statutFiltre,
    'methode' => $methodeFiltre,
    'recherche' => $recherche,
], static fn($valeur) => $valeur !== '');
$urlPage = static function (int $numero) use ($filtres): string {
    return '?' . http_build_query($filtres + ['page' => $numero]);
};
$premierResultat = $totalPaiements > 0 ? $decalage + 1 : 0;
$dernierResultat = min($decalage + $parPage, $totalPaiements);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Historique des paiements — ALLÔ PRO <?= ($_SESSION['role'] ?? '') === 'finance' ? 'Finance' : 'Admin' ?></title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/paiements-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/paiements-admin.css') ?>">
</head>
<body class="page-admin-paiements page-admin-historique-paiements">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <main class="admin-contenu">
        <a href="paiements.php" class="paiements-retour">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>
            Retour à Paiements &amp; Finance
        </a>

        <div class="admin-entete">
            <div>
                <h1 class="admin-entete__titre">Historique des paiements</h1>
                <p class="admin-entete__sous-titre"><?= number_format($totalPaiements, 0, ',', ' ') ?> transaction<?= $totalPaiements === 1 ? '' : 's' ?><?= $statutFiltre || $methodeFiltre ? ' pour les filtres sélectionnés' : ' au total' ?></p>
            </div>
        </div>

        <form method="GET" class="paiements-filtres">
            <label class="paiements-filtres__recherche">
                <span>Rechercher une transaction</span>
                <span class="paiements-recherche__champ">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
                    <input type="search" name="recherche" value="<?= htmlspecialchars($recherche, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" placeholder="Référence, dossier ou client">
                </span>
            </label>
            <label class="paiements-filtres__champ">
                <span>Filtrer par statut</span>
                <select name="statut" onchange="this.form.submit()">
                    <option value="">Tous les statuts</option>
                    <option value="valide" <?= $statutFiltre === 'valide' ? 'selected' : '' ?>>Validé</option>
                    <option value="en_attente" <?= $statutFiltre === 'en_attente' ? 'selected' : '' ?>>En attente</option>
                    <option value="echoue" <?= $statutFiltre === 'echoue' ? 'selected' : '' ?>>Échoué</option>
                </select>
            </label>
            <label class="paiements-filtres__champ">
                <span>Filtrer par méthode</span>
                <select name="methode" onchange="this.form.submit()">
                    <option value="">Toutes méthodes</option>
                    <option value="wave" <?= $methodeFiltre === 'wave' ? 'selected' : '' ?>>Wave</option>
                    <option value="orange_money" <?= $methodeFiltre === 'orange_money' ? 'selected' : '' ?>>Orange Money</option>
                    <option value="especes" <?= $methodeFiltre === 'especes' ? 'selected' : '' ?>>Espèces</option>
                </select>
            </label>
            <button type="submit" class="paiements-filtres__submit">Rechercher</button>
            <?php if ($statutFiltre || $methodeFiltre || $recherche): ?><a href="historique-paiements.php" class="paiements-filtres__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <section class="admin-panneau paiements-tableau paiements-historique-tableau" aria-labelledby="historique-paiements-titre">
            <div class="admin-panneau__titre paiements-tableau__titre">
                <span id="historique-paiements-titre">Toutes les transactions</span>
                <span class="paiements-tableau__compte"><?= number_format($premierResultat, 0, ',', ' ') ?>–<?= number_format($dernierResultat, 0, ',', ' ') ?> sur <?= number_format($totalPaiements, 0, ',', ' ') ?></span>
            </div>
            <div class="paiements-tableau__defilement" role="region" aria-label="Historique complet des paiements, défilement horizontal possible" tabindex="0">
                <table class="admin-table paiements-table">
                    <thead><tr><th>Référence</th><th>Dossier</th><th>Client</th><th>Méthode</th><th>Montant</th><th>Statut</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php if (empty($paiements)): ?>
                        <tr><td colspan="7" class="paiements-table__vide">Aucun paiement ne correspond à ces filtres.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($paiements as $p): ?>
                        <tr>
                            <td class="paiements-table__reference"><?= htmlspecialchars($p['reference_transaction'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><strong><?= htmlspecialchars($p['numero_dossier'], ENT_QUOTES, 'UTF-8') ?></strong></td>
                            <td><?= htmlspecialchars($p['client_nom'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($p['methode'] === 'especes' ? 'Espèces' : ucfirst(str_replace('_', ' ', $p['methode'])), ENT_QUOTES, 'UTF-8') ?></td>
                            <td class="paiements-table__montant"><?= number_format((float) $p['montant'], 0, ',', ' ') ?> F</td>
                            <td><span class="admin-badge admin-badge--<?= $p['statut'] === 'valide' ? 'vert' : ($p['statut'] === 'en_attente' ? 'amber' : 'rouge') ?>"><?= htmlspecialchars(['valide' => 'Validé', 'en_attente' => 'En attente', 'echoue' => 'Échoué'][$p['statut']] ?? $p['statut'], ENT_QUOTES, 'UTF-8') ?></span></td>
                            <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($p['date_paiement'])), ENT_QUOTES, 'UTF-8') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($nombrePages > 1): ?>
            <nav class="paiements-pagination" aria-label="Pagination de l'historique des paiements">
                <span>Page <?= $page ?> sur <?= $nombrePages ?></span>
                <div>
                    <?php if ($page > 1): ?><a href="<?= htmlspecialchars($urlPage($page - 1), ENT_QUOTES, 'UTF-8') ?>">← Précédent</a><?php endif; ?>
                    <?php if ($page < $nombrePages): ?><a href="<?= htmlspecialchars($urlPage($page + 1), ENT_QUOTES, 'UTF-8') ?>">Suivant →</a><?php endif; ?>
                </div>
            </nav>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
