<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['admin']);
verifierAcces('interventions');
require_once __DIR__ . '/../../models/Intervention.php';

$interventionModel = new Intervention();
$csrfKey = 'csrf_file_refus_interventions_admin';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

$erreur = '';
$messageSucces = is_string($_SESSION['flash_file_refus_interventions_admin'] ?? null)
    ? $_SESSION['flash_file_refus_interventions_admin']
    : '';
unset($_SESSION['flash_file_refus_interventions_admin']);

$fileAttente = $interventionModel->getFileAttenteCoordinateur();
$elementsParFile = [];
foreach ($fileAttente as $element) {
    $elementsParFile[(int) $element['file_id']] = $element;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $fileId = filter_var($_POST['file_id'] ?? null, FILTER_VALIDATE_INT);
    $technicienId = filter_var($_POST['technicien_id'] ?? null, FILTER_VALIDATE_INT);
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (!$fileId || !$technicienId) {
        $erreur = 'Choisissez un technicien valide pour réattribuer cette intervention.';
    } else {
        try {
            if ($interventionModel->reattribuerDepuisFile($fileId, $technicienId, (int) $_SESSION['user_id'])) {
                $elementReattribue = $elementsParFile[$fileId] ?? [];
                journaliser(
                    'mission.reattribuee_admin',
                    'intervention',
                    isset($elementReattribue['intervention_id']) ? (int) $elementReattribue['intervention_id'] : null,
                    $elementReattribue['numero_dossier'] ?? null,
                    'Intervention réattribuée à un technicien par un administrateur.'
                );
                $_SESSION['flash_file_refus_interventions_admin'] = 'L’intervention a été réattribuée. Le nouveau technicien doit confirmer sa prise en charge.';
                header('Location: refus-interventions.php');
                exit;
            }
            $erreur = 'La file a changé ou le technicien choisi n’est plus disponible. Actualisez la page.';
        } catch (Throwable $exception) {
            error_log('Réattribution admin depuis la file de refus ' . $fileId . ' : ' . $exception->getMessage());
            $erreur = 'Une erreur est survenue pendant la réattribution. Réessayez.';
        }
    }
}
$candidatsParFile = [];
foreach ($fileAttente as $element) {
    $candidatsParFile[(int) $element['file_id']] = $interventionModel->getTechniciensCompatiblesDemande(
        (int) $element['demande_id']
    );
}
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Refus d’interventions — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/refus-interventions-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/refus-interventions-admin.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu">
        <section class="refus-admin">
            <header class="refus-admin__entete">
                <div>
                    <span class="refus-admin__surtitre">Interventions / suivi</span>
                    <h1>Refus d’interventions</h1>
                    <p>Examinez les missions refusées et choisissez un technicien actif ayant une compétence compatible pour les réattribuer.</p>
                </div>
                <div class="refus-admin__liens-entete">
                    <a class="refus-admin__retour" href="historique-refus.php">Historique de refus</a>
                    <a class="refus-admin__retour" href="interventions.php">Voir les interventions</a>
                </div>
            </header>

            <?php if ($messageSucces !== ''): ?><div class="refus-admin__message" role="status"><?= $echapper($messageSucces) ?></div><?php endif; ?>
            <?php if ($erreur !== ''): ?><div class="refus-admin__message refus-admin__message--erreur" role="alert"><?= $echapper($erreur) ?></div><?php endif; ?>

            <div class="refus-admin__resume">
                <strong><?= count($fileAttente) ?></strong>
                <span>mission<?= count($fileAttente) === 1 ? '' : 's' ?> en attente de réaffectation</span>
            </div>

            <?php if (!$fileAttente): ?>
                <div class="refus-admin__vide">
                    <strong>Aucun refus à traiter</strong>
                    <span>Aucune intervention refusée n’attend actuellement de réaffectation.</span>
                </div>
            <?php else: ?>
                <?php foreach ($fileAttente as $element): ?>
                    <?php $candidats = $candidatsParFile[(int) $element['file_id']] ?? []; ?>
                    <article class="refus-admin__carte">
                        <div class="refus-admin__dossier">
                            <div class="refus-admin__dossier-entete">
                                <div>
                                    <span class="refus-admin__numero"><?= $echapper($element['numero_dossier']) ?></span>
                                    <span class="refus-admin__categorie"><?= $echapper($element['categorie_nom']) ?></span>
                                </div>
                                <?php if ($element['urgence'] === 'urgente'): ?><span class="refus-admin__urgence">Urgente</span><?php endif; ?>
                            </div>
                            <?php if (!empty($element['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($element['entreprise_b2b_nom']) ? ' · ' . $echapper($element['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                            <p class="refus-admin__meta"><strong><?= $echapper($element['client_nom']) ?></strong> · <?= $echapper($element['quartier']) ?>, <?= $echapper($element['ville']) ?></p>
                            <p class="refus-admin__description"><?= $echapper($element['description']) ?></p>
                            <p class="refus-admin__meta">
                                Refusée par <strong><?= $echapper($element['technicien_refus_nom']) ?></strong>
                                <?php if (!empty($element['partenaire_refus_nom'])): ?> · <?= $echapper($element['partenaire_refus_nom']) ?><?php endif; ?>
                                · <?= $echapper(date('d/m/Y à H:i', strtotime($element['date_creation']))) ?>
                            </p>
                            <?php if (!empty($element['motif'])): ?><blockquote class="refus-admin__motif"><?= $echapper($element['motif']) ?></blockquote><?php endif; ?>
                        </div>
                        <div class="refus-admin__action">
                            <?php if ($candidats): ?>
                                <form method="POST" onsubmit="return confirm('Réattribuer cette intervention au technicien sélectionné ?');">
                                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfKey]) ?>">
                                    <input type="hidden" name="file_id" value="<?= (int) $element['file_id'] ?>">
                                    <label for="technicien-<?= (int) $element['file_id'] ?>">Nouveau technicien</label>
                                    <select id="technicien-<?= (int) $element['file_id'] ?>" name="technicien_id" required>
                                        <option value="">Choisir un technicien compatible</option>
                                        <?php foreach ($candidats as $candidat): ?>
                                            <option value="<?= (int) $candidat['id'] ?>"><?= $echapper($candidat['nom']) ?> · <?= $echapper($candidat['competences'] ?? 'Compétences non renseignées') ?> · <?= $echapper($candidat['nom_entreprise']) ?> (<?= $echapper($candidat['zones_intervention'] ?? 'Zones non renseignées') ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p>La mission sera renvoyée au technicien sélectionné pour confirmation.</p>
                                    <button type="submit">Réattribuer la mission</button>
                                </form>
                            <?php else: ?>
                                <div class="refus-admin__indisponible">
                                    <strong>Aucun technicien compatible</strong>
                                    <span>Aucun technicien actif ayant une compétence compatible n’est disponible. Cette mission reste dans la file.</span>
                                    <a href="techniciens.php">Vérifier les techniciens actifs et leurs compétences</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
