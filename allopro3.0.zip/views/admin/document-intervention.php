<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAdminConnecte();
require_once __DIR__ . '/../../models/Intervention.php';

$demandeId = filter_input(INPUT_GET, 'demande_id', FILTER_VALIDATE_INT);
$documentId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$demandeId || !$documentId || $demandeId < 1 || $documentId < 1) {
    http_response_code(404);
    exit('Document introuvable.');
}

$interventionModel = new Intervention();
$intervention = $interventionModel->getByDemandeId($demandeId);
if (!$intervention || empty($intervention['technicien_id'])) {
    http_response_code(404);
    exit('Document introuvable.');
}

$document = false;
foreach ($interventionModel->getDocumentsTechnicien(
    (int) $intervention['technicien_id'],
    (int) $intervention['id']
) as $documentMission) {
    if ((int) $documentMission['id'] === $documentId) {
        $document = $documentMission;
        break;
    }
}

$typesAutorises = [
    'application/pdf' => 'pdf',
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/webp' => 'webp',
];
$cheminRelatif = is_array($document) ? (string) $document['chemin'] : '';
if (!$document
    || !isset($typesAutorises[$document['mime_type']])
    || preg_match('#^intervention-documents/[a-f0-9]{32}\.(?:pdf|jpg|png|webp)$#', $cheminRelatif) !== 1
    || pathinfo($cheminRelatif, PATHINFO_EXTENSION) !== $typesAutorises[$document['mime_type']]) {
    http_response_code(404);
    exit('Document introuvable.');
}

$dossierDocuments = realpath(__DIR__ . '/../../storage/intervention-documents');
$cheminFichier = realpath(__DIR__ . '/../../storage/' . $cheminRelatif);
if ($dossierDocuments === false || $cheminFichier === false
    || !str_starts_with($cheminFichier, $dossierDocuments . DIRECTORY_SEPARATOR)
    || !is_file($cheminFichier)) {
    error_log('Document de mission introuvable pour le document ' . $documentId . '.');
    http_response_code(404);
    exit('Document introuvable.');
}

$nomFichier = str_replace(["\r", "\n", '"'], '', (string) $document['nom_original']);
header('Content-Type: ' . $document['mime_type']);
header('Content-Length: ' . (string) filesize($cheminFichier));
header('Content-Disposition: attachment; filename="document"; filename*=UTF-8\'\'' . rawurlencode($nomFichier));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($cheminFichier);
exit;
