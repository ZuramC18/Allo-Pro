<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/Reversement.php';

$statutFiltre = $_GET['statut'] ?? '';
$reversements = (new Reversement())->getAll($statutFiltre ?: null);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reversements — ALLÔ PRO <?= ($_SESSION['role'] ?? '') === 'finance' ? 'Finance' : 'Admin' ?></title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/reversements-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/reversements-admin.css') ?>">
</head>
<body class="page-admin-reversements">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <main class="admin-contenu">
        <div class="admin-entete reversements-entete">
            <div>
                <h1 class="admin-entete__titre"><?= ($_SESSION['role'] ?? '') === 'finance' && isset($financeTitrePage) ? htmlspecialchars($financeTitrePage, ENT_QUOTES, 'UTF-8') : 'Reversements partenaires' ?></h1>
                <p class="admin-entete__sous-titre">Historique des montants dus et payés</p>
            </div>
            <a href="paiements.php" class="reversements-entete__lien">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7h10v10"/><path d="M7 17 17 7"/><path d="M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z"/></svg>
                Voir les montants encore dus
            </a>
        </div>

        <nav class="filtres-tabs reversements-filtres" aria-label="Filtrer les reversements">
            <a href="?" class="filtre-tab <?= !$statutFiltre ? 'filtre-tab--actif' : '' ?>">Tous</a>
            <a href="?statut=en_attente" class="filtre-tab <?= $statutFiltre === 'en_attente' ? 'filtre-tab--actif' : '' ?>">En attente</a>
            <a href="?statut=paye" class="filtre-tab <?= $statutFiltre === 'paye' ? 'filtre-tab--actif' : '' ?>">Payés</a>
        </nav>

        <section class="admin-panneau reversements-panneau" aria-label="Liste des reversements">
            <div class="reversements-panneau__entete">
                <h2>Historique des versements</h2>
                <span><?= number_format(count($reversements), 0, ',', ' ') ?> reversement<?= count($reversements) === 1 ? '' : 's' ?></span>
            </div>
            <div class="reversements-table-scroll">
            <table class="admin-table reversements-table">
                <thead>
                    <tr><th>Partenaire</th><th>Période</th><th>Montant</th><th>Statut</th><th aria-label="Détail"></th></tr>
                </thead>
                <tbody>
                <?php if (empty($reversements)): ?>
                    <tr class="reversements-vide"><td colspan="5">Aucun reversement créé pour l'instant.</td></tr>
                <?php endif; ?>
                <?php foreach ($reversements as $r): ?>
                <tr>
                    <td data-label="Partenaire"><strong><?= htmlspecialchars($r['nom_entreprise']) ?></strong></td>
                    <td data-label="Période"><?= date('d/m/Y', strtotime($r['periode_debut'])) ?> → <?= date('d/m/Y', strtotime($r['periode_fin'])) ?></td>
                    <td data-label="Montant" class="reversements-table__montant"><?= number_format($r['montant_du'], 0, ',', ' ') ?> F</td>
                    <td data-label="Statut"><span class="admin-badge admin-badge--<?= $r['statut'] === 'paye' ? 'vert' : 'amber' ?>"><?= $r['statut'] === 'paye' ? 'Payé' : 'En attente' ?></span></td>
                    <td class="reversements-table__action"><a href="reversement-detail.php?id=<?= (int) $r['id'] ?>">Voir le détail <span aria-hidden="true">→</span></a></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </section>
    </main>
</div>
</body>
</html>