<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('techniciens');
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Categorie.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$technicienModel = new Technicien();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['technicien_id'], $_POST['nouveau_statut'])) {
    if (in_array($_POST['nouveau_statut'], ['actif', 'inactif'], true)) {
        $technicienModel->changerStatut((int) $_POST['technicien_id'], $_POST['nouveau_statut']);
        $t = $technicienModel->getById((int) $_POST['technicien_id']);
        journaliser('technicien.statut_modifie', 'compte', (int) $_POST['technicien_id'], $t['matricule'] ?? null, ($t['nom'] ?? '') . ' → ' . $_POST['nouveau_statut']);
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

$recherche = trim($_GET['q'] ?? '');
$partenaireFiltre = $_GET['partenaire'] ?? '';
$competenceFiltre = $_GET['competence'] ?? '';
$statutFiltre = $_GET['statut'] ?? '';

$techniciens = $technicienModel->getAllAvecStats(
    $recherche ?: null,
    $partenaireFiltre ?: null,
    $competenceFiltre ?: null,
    $statutFiltre ?: null
);
$global = $technicienModel->compterGlobal();
$partenaires = (new Partenaire())->getAllAvecStats();
$competences = (new Categorie())->getSousCategories();

$filtresActifs = $recherche || $partenaireFiltre || $competenceFiltre || $statutFiltre;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Techniciens — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .select-filtre { padding: 10px 14px; border: 1px solid var(--admin-bordure); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 14px; color: var(--admin-texte); background: var(--admin-carte, white); }
        .admin-recherche { flex-wrap: wrap; }
        .techniciens-panneau { overflow: hidden; }
        .techniciens-table { min-width: 0; }
        .techniciens-table tbody tr.techniciens-table__ligne { cursor: pointer; }
        .techniciens-table tbody tr.techniciens-table__ligne:hover td { background: rgba(108, 92, 231, .045); }
        .techniciens-table tbody tr.techniciens-table__ligne:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: -2px; }
        .tech-cellule { display: flex; align-items: center; gap: 10px; }
        .tech-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; }
        .tech-avatar img { width: 100%; height: 100%; border-radius: inherit; object-fit: cover; }
        .tech-avatar svg { width: 19px; height: 19px; fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.6; }
        .technicien-lien-detail { color: inherit; text-decoration: none; }
        .technicien-lien-detail:hover { color: var(--admin-violet); text-decoration: underline; }
        .technicien-lien-detail:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: 3px; border-radius: 3px; }
        .technicien-lien-partenaire { color: var(--admin-violet); text-decoration: none; font-weight: 600; }
        .technicien-lien-partenaire:hover { text-decoration: underline; }
        .technicien-lien-partenaire:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: 3px; border-radius: 3px; }
        .tech-inactif { opacity: 0.55; }
        .bouton-statut { border: none; background: none; cursor: pointer; font-size: 12.5px; font-weight: 600; padding: 4px 0; }
        .bouton-statut--desactiver { color: var(--admin-rouge); }
        .bouton-statut--activer { color: var(--admin-vert); }
        .techniciens-table__identite > span { color: var(--admin-texte-discret); font-size: 12px; }
        .techniciens-table__missions-actives { display: block; color: var(--admin-amber); font-size: 11px; font-weight: 600; }
        .techniciens-table__empty td { padding: 30px; color: var(--admin-texte-discret); text-align: center; }
        @media (max-width: 600px) {
            .admin-contenu > .admin-kpi-grille { grid-template-columns: repeat(3, minmax(0, 1fr)) !important; gap: 8px; margin-bottom: 16px; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte { min-width: 0; min-height: 82px; padding: 11px 9px; border-radius: 11px; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte__icone { display: none; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte__label { max-width: none; min-height: 25px; margin-bottom: 5px; font-size: 10px; line-height: 1.25; overflow-wrap: anywhere; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte__valeur { font-size: 23px; line-height: 1; }
            .techniciens-recherche { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
            .techniciens-recherche input { min-width: 0; width: 100%; max-width: none; grid-column: 1 / -1; }
            .techniciens-recherche .select-filtre { width: 100%; min-width: 0; max-width: 100%; min-height: 42px; padding: 9px 8px; font-size: 11px; }
            .techniciens-recherche button { min-height: 42px; grid-column: 1 / -1; }
            .techniciens-recherche .admin-recherche__reset { grid-column: 1 / -1; justify-content: flex-end; padding: 0 8px; }
            .techniciens-panneau { padding: 10px; overflow: visible; }
            .admin-table.techniciens-table { display: block; width: 100%; min-width: 0; }
            .techniciens-table thead { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }
            .techniciens-table tbody { display: grid; gap: 10px; }
            .techniciens-table tbody tr.techniciens-table__ligne { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); padding: 10px; border: 1px solid var(--admin-bordure); border-radius: 12px; background: var(--admin-carte, #fff); }
            .techniciens-table tbody tr.techniciens-table__ligne:hover { border-color: var(--admin-violet); }
            .techniciens-table tbody tr.techniciens-table__ligne td { min-width: 0; padding: 8px 5px; border: 0; font-size: 12px; overflow-wrap: anywhere; }
            .techniciens-table .techniciens-table__identity,
            .techniciens-table .techniciens-table__action { grid-column: 1 / -1; }
            .techniciens-table .techniciens-table__identity { padding: 2px 5px 10px; }
            .techniciens-table__identity .tech-cellule { align-items: center; }
            .techniciens-table__identity .tech-avatar { width: 40px; height: 40px; font-size: 14px; }
            .techniciens-table__identite { min-width: 0; }
            .techniciens-table__identite > strong { font-size: 13px; }
            .techniciens-table tbody tr.techniciens-table__ligne td[data-label] { border-top: 1px solid var(--admin-bordure); font-weight: 650; }
            .techniciens-table tbody tr.techniciens-table__ligne td[data-label]::before { display: block; margin-bottom: 4px; color: var(--admin-texte-discret); font-size: 10px; font-weight: 500; content: attr(data-label); }
            .techniciens-table__action { padding-top: 10px !important; border-top: 1px solid var(--admin-bordure) !important; }
            .techniciens-table__action > div { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 8px; }
            .techniciens-table__action form { margin: 0; }
            .techniciens-table__action .bouton-statut { min-height: 38px; padding: 8px 10px; border: 1px solid currentColor; border-radius: 8px; background: transparent; }
            .techniciens-table__empty td { display: block; padding: 22px 12px; }
            .techniciens-table tbody tr.techniciens-table__empty { display: block; }
            :root[data-theme="dark"] .techniciens-table tbody tr.techniciens-table__ligne { background: var(--admin-carte, #1d202b); }
            :root[data-theme="dark"] .techniciens-table tbody tr.techniciens-table__ligne:hover td { background: rgba(255, 255, 255, .04); }
        }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Techniciens</div>
                <div class="admin-entete__sous-titre"><?= count($techniciens) ?> technicien<?= count($techniciens) > 1 ? 's' : '' ?> <?= $filtresActifs ? 'trouvé(s)' : 'au total' ?></div>
            </div>
        </div>

        <div class="admin-kpi-grille techniciens-kpis" style="grid-template-columns: repeat(3, minmax(0, 1fr));">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 6 8 12l4 4 6-6M8 12l-3-3 3-3 3 3M12 16l3 3 3-3-3-3"/><path d="m3 21 3-1 10-10-2-2L4 18l-1 3Z"/></svg></div><div class="admin-kpi-carte__label">Techniciens</div><div class="admin-kpi-carte__valeur"><?= (int) $global['total'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg></div><div class="admin-kpi-carte__label">Actifs</div><div class="admin-kpi-carte__valeur"><?= (int) $global['actifs'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div><div class="admin-kpi-carte__label">En mission</div><div class="admin-kpi-carte__valeur"><?= (int) $global['en_mission'] ?></div></div>
        </div>

        <form method="GET" class="admin-recherche techniciens-recherche">
            <input type="search" name="q" aria-label="Rechercher un technicien" placeholder="Nom, email ou téléphone..." value="<?= htmlspecialchars($recherche) ?>">

            <select name="partenaire" class="select-filtre" aria-label="Filtrer par partenaire" onchange="this.form.submit()">
                <option value="">Tous les partenaires</option>
                <?php foreach ($partenaires as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= $partenaireFiltre == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['nom_entreprise']) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="competence" class="select-filtre" aria-label="Filtrer par compétence" onchange="this.form.submit()">
                <option value="">Toutes les compétences</option>
                <?php foreach ($competences as $competence): ?>
                    <option value="<?= $competence['id'] ?>" <?= $competenceFiltre == $competence['id'] ? 'selected' : '' ?>><?= htmlspecialchars($competence['parent_nom'] . ' — ' . $competence['nom']) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="statut" class="select-filtre" aria-label="Filtrer par statut" onchange="this.form.submit()">
                <option value="">Tous les statuts</option>
                <option value="actif" <?= $statutFiltre === 'actif' ? 'selected' : '' ?>>Actifs</option>
                <option value="inactif" <?= $statutFiltre === 'inactif' ? 'selected' : '' ?>>Inactifs</option>
                <option value="corbeille" <?= $statutFiltre === 'corbeille' ? 'selected' : '' ?>>En corbeille</option>
            </select>

            <button type="submit">Rechercher</button>
            <?php if ($filtresActifs): ?><a href="techniciens.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau techniciens-panneau">
            <table class="admin-table techniciens-table">
                <thead><tr><th scope="col">Technicien</th><th scope="col">Partenaire</th><th scope="col">Compétences</th><th scope="col">Missions</th><th scope="col">Note client</th><th scope="col">Refus</th><th scope="col">Statut</th><th scope="col">Actions</th></tr></thead>
                <tbody>
                <?php if (empty($techniciens)): ?>
                    <tr class="techniciens-table__empty"><td colspan="8">Aucun technicien trouvé.</td></tr>
                <?php endif; ?>
                <?php foreach ($techniciens as $t): $actif = $t['statut'] === 'actif'; ?>
                <tr class="techniciens-table__ligne <?= $actif ? '' : 'tech-inactif' ?>" tabindex="0" aria-label="Ouvrir la fiche de <?= htmlspecialchars($t['nom'], ENT_QUOTES, 'UTF-8') ?>" data-href="technicien-detail.php?id=<?= (int) $t['id'] ?>">
                    <td class="techniciens-table__identity">
                        <div class="tech-cellule">
                            <?php
                            $photoTechnicien = (string) ($t['photo_profil'] ?? '');
                            $photoTechnicienValide = preg_match('#^uploads/techniciens/[a-f0-9]{32}\.(?:jpg|png|webp)$#', $photoTechnicien) === 1;
                            $initialesTechnicien = AvatarProfil::initiales((string) $t['nom']);
                            ?>
                            <div class="tech-avatar" aria-hidden="true">
                                <?php if ($photoTechnicienValide && empty($t['avatar_initiales'])): ?>
                                    <img src="../../public/<?= htmlspecialchars($photoTechnicien, ENT_QUOTES, 'UTF-8') ?>" alt="">
                                <?php elseif (!empty($t['avatar_initiales'])): ?>
                                    <?= htmlspecialchars($initialesTechnicien, ENT_QUOTES, 'UTF-8') ?>
                                <?php else: ?>
                                    <svg viewBox="0 0 24 24"><path d="M6 10V8a6 6 0 0 1 12 0v2"/><path d="M4 10h16v2H4z"/><path d="M8 12v2a4 4 0 0 0 8 0v-2"/><path d="M4 21c.5-3.4 3-5 8-5s7.5 1.6 8 5"/></svg>
                                <?php endif; ?>
                            </div>
                            <div class="techniciens-table__identite">
                                <strong><a class="technicien-lien-detail" href="technicien-detail.php?id=<?= (int) $t['id'] ?>"><?= htmlspecialchars($t['nom']) ?></a></strong>
                                <span><?= htmlspecialchars($t['telephone'] ?: $t['email']) ?></span>
                            </div>
                        </div>
                    </td>
                    <td data-label="Partenaire"><a class="technicien-lien-partenaire" href="partenaire-detail.php?id=<?= (int) $t['partenaire_id'] ?>"><?= htmlspecialchars($t['nom_entreprise']) ?></a></td>
                    <td data-label="Compétences"><?= $t['competences'] ? htmlspecialchars($t['competences']) : '<span style="color:var(--admin-texte-discret);">Non renseignées</span>' ?></td>
                    <td data-label="Missions">
                        <?= (int) $t['nb_missions'] ?>
                        <?php if ($t['nb_actives'] > 0): ?><span class="techniciens-table__missions-actives"><?= (int) $t['nb_actives'] ?> en cours</span><?php endif; ?>
                    </td>
                    <td data-label="Note client"><?= $t['note_moyenne'] !== null ? number_format($t['note_moyenne'], 1) . '/5' : '—' ?></td>
                    <td data-label="Refus"><?= (int) $t['nb_refus'] ?></td>
                    <td data-label="Statut"><span class="admin-badge admin-badge--<?= $actif ? 'vert' : 'gris' ?>"><?= $t['statut'] === 'corbeille' ? 'Corbeille' : ($actif ? 'Actif' : 'Inactif') ?></span></td>
                    <td class="techniciens-table__action">
                        <div>
                        <a class="technicien-lien-detail" href="technicien-detail.php?id=<?= (int) $t['id'] ?>">Voir la fiche →</a>
                        <?php
                        $messageConfirm = $actif
                            ? ($t['nb_actives'] > 0
                                ? "Ce technicien a {$t['nb_actives']} mission(s) en cours. Le désactiver l'empêchera de se connecter et de les terminer. Continuer ?"
                                : "Désactiver ce technicien ? Il ne pourra plus se connecter.")
                            : "Réactiver ce technicien ?";
                        ?>
                        <form method="POST" onsubmit="return confirm(<?= htmlspecialchars(json_encode($messageConfirm), ENT_QUOTES) ?>);">
                            <input type="hidden" name="technicien_id" value="<?= $t['id'] ?>">
                            <input type="hidden" name="nouveau_statut" value="<?= $actif ? 'inactif' : 'actif' ?>">
                            <button type="submit" class="bouton-statut <?= $actif ? 'bouton-statut--desactiver' : 'bouton-statut--activer' ?>">
                                <?= $actif ? 'Désactiver' : 'Réactiver' ?>
                            </button>
                        </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    document.querySelectorAll('.techniciens-table__ligne[data-href]').forEach((ligne) => {
        ligne.addEventListener('click', (evenement) => {
            if (evenement.target.closest('a, button, form, input, select, textarea, [contenteditable="true"]')) return;
            window.location.href = ligne.dataset.href;
        });
        ligne.addEventListener('keydown', (evenement) => {
            if (evenement.target !== ligne || (evenement.key !== 'Enter' && evenement.key !== ' ')) return;
            evenement.preventDefault();
            window.location.href = ligne.dataset.href;
        });
    });
</script>
</body>
</html>