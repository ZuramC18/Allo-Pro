<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
$roleContrats = $_SESSION['role'] ?? '';
$estFinanceContrats = $roleContrats === 'finance';
verifierAcces($estFinanceContrats ? 'devis_entreprises' : 'parametres');
require_once __DIR__ . '/../../models/EntrepriseB2B.php';

$modeleEntreprise = new EntrepriseB2B();
$entreprises = $modeleEntreprise->getEntreprisesPourContratAdmin();
$contrats = $modeleEntreprise->getContratsPourAdmin();
$peutLierDemandeContrat = $roleContrats === 'admin';
$demandesSansContrat = $peutLierDemandeContrat ? $modeleEntreprise->getDemandesB2BSansContrat() : [];
$erreur = '';
$csrfKey = 'csrf_contrats_entreprises_admin';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } else {
        $contratId = filter_var($_POST['contrat_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $entrepriseId = filter_var($_POST['entreprise_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        try {
            if ($action === 'creer' && $entrepriseId !== false) {
                $nouveauContratId = $modeleEntreprise->creerContratAdmin(
                    (int) $entrepriseId,
                    (int) $_SESSION['user_id'],
                    $_POST
                );
                journaliser($estFinanceContrats ? 'finance.contrat_entreprise_cree' : 'admin.contrat_entreprise_cree', 'contrat_b2b', $nouveauContratId, null, 'Entreprise #' . (int) $entrepriseId);
                header('Location: contrats-entreprises.php?cree=1');
                exit;
            }
            if ($action === 'resilier' && $contratId !== false) {
                if (!$modeleEntreprise->resilierContratAdmin((int) $contratId, (int) $_SESSION['user_id'])) {
                    throw new RuntimeException('Ce contrat est déjà résilié ou introuvable.');
                }
                journaliser($estFinanceContrats ? 'finance.contrat_entreprise_resilie' : 'admin.contrat_entreprise_resilie', 'contrat_b2b', (int) $contratId);
                header('Location: contrats-entreprises.php?resilie=1');
                exit;
            }
            if ($action === 'paiement' && $contratId !== false) {
                $paiementId = $modeleEntreprise->enregistrerPaiementContratAdmin(
                    (int) $contratId,
                    (int) $_SESSION['user_id'],
                    $_POST
                );
                journaliser($estFinanceContrats ? 'finance.paiement_contrat_b2b_enregistre' : 'admin.paiement_contrat_b2b_enregistre', 'paiement_contrat_b2b', $paiementId, null, 'Contrat #' . (int) $contratId);
                $factureStatut = 'echec';
                try {
                    require_once __DIR__ . '/../../models/FactureContratB2B.php';
                    $facture = (new FactureContratB2B())->emettrePourPaiement($paiementId);
                    $factureStatut = $facture['email_statut'] === 'envoye' ? 'envoyee' : 'echec';
                } catch (Throwable $exception) {
                    error_log('Facture du paiement contrat B2B #' . $paiementId . ' : ' . $exception->getMessage());
                }
                header('Location: detail-contrat-entreprise.php?id=' . (int) $contratId . '&paiement=1&facture=' . $factureStatut);
                exit;
            }
            if ($action === 'lier-demande' && $contratId !== false && $peutLierDemandeContrat) {
                $demandeId = filter_var($_POST['demande_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if ($demandeId === false) {
                    throw new InvalidArgumentException('La demande sélectionnée est invalide.');
                }
                $modeleEntreprise->lierDemandeAuContratAdmin(
                    (int) $demandeId,
                    (int) $contratId,
                    (int) $_SESSION['user_id']
                );
                journaliser('admin.demande_entreprise_contrat_associe', 'demande', (int) $demandeId, null, 'Contrat #' . (int) $contratId);
                header('Location: contrats-entreprises.php?demande_liee=1');
                exit;
            }
            throw new InvalidArgumentException('Action de contrat invalide ou non autorisée.');
        } catch (PDOException $exception) {
            error_log('Gestion contrats entreprise par admin ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
            $erreur = 'Le contrat n’a pas pu être enregistré. Réessayez.';
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        }
    }
    $contrats = $modeleEntreprise->getContratsPourAdmin();
    $demandesSansContrat = $peutLierDemandeContrat ? $modeleEntreprise->getDemandesB2BSansContrat() : [];
}
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$aujourdhuiContrats = date('Y-m-d');
$cleEtatContrat = static function (array $contrat) use ($aujourdhuiContrats): string {
    if ($contrat['statut'] !== 'actif') return 'resilie';
    if ($contrat['date_debut'] > $aujourdhuiContrats) return 'a-venir';
    if ($contrat['date_fin'] < $aujourdhuiContrats) return 'expire';
    return 'actif';
};
$etatContrat = static function (array $contrat) use ($cleEtatContrat): string {
    return [
        'actif' => 'Actif',
        'a-venir' => 'À venir',
        'expire' => 'Expiré',
        'resilie' => 'Résilié',
    ][$cleEtatContrat($contrat)];
};
$contratsActifsParEntreprise = [];
$statistiquesContrats = [
    'total' => count($contrats),
    'actif' => 0,
    'a-venir' => 0,
    'expire' => 0,
    'resilie' => 0,
    'solde' => 0.0,
];
foreach ($contrats as $contrat) {
    $cleEtat = $cleEtatContrat($contrat);
    $statistiquesContrats[$cleEtat]++;
    $statistiquesContrats['solde'] += max(0, (float) $contrat['solde']);

    if ($contrat['statut'] === 'actif' && $contrat['date_debut'] <= $aujourdhuiContrats
        && $contrat['date_fin'] >= $aujourdhuiContrats) {
        $contratsActifsParEntreprise[(int) $contrat['entreprise_b2b_id']][] = $contrat;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contrats entreprises — ALLÔ PRO <?= $estFinanceContrats ? 'Finance' : 'Admin' ?></title>
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
</head>
<body><div class="admin-app"><?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?><main class="admin-contenu b2b-main b2b-contracts-page">
    <header class="b2b-header b2b-contracts-hero"><div><span class="b2b-eyebrow">PILOTAGE ENTREPRISES</span><h1>Contrats entreprises</h1><p><?= $estFinanceContrats ? 'Créez les contrats, suivez les crédits et enregistrez les règlements des entreprises.' : 'Gérez les périodes, crédits d’intervention et niveaux de service du parcours B2B.' ?></p></div></header>
    <?php if (($_GET['cree'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">Le contrat est enregistré et visible dans l’espace entreprise. Les demandes sont possibles pendant sa période de validité.</div><?php endif; ?>
    <?php if (($_GET['resilie'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">Le contrat a été résilié.</div><?php endif; ?>
    <?php if (($_GET['paiement'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">Le règlement du contrat a été enregistré.</div><?php endif; ?>
    <?php if (($_GET['demande_liee'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">La demande est rattachée au contrat et son crédit est réservé.</div><?php endif; ?>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>

    <section class="b2b-contracts-stats" aria-label="Indicateurs des contrats">
        <article class="b2b-contracts-stat"><span>Contrats au total</span><strong><?= $statistiquesContrats['total'] ?></strong><small>Enregistrés dans le portefeuille</small></article>
        <article class="b2b-contracts-stat b2b-contracts-stat--active"><span>Actifs aujourd’hui</span><strong><?= $statistiquesContrats['actif'] ?></strong><small>Dans leur période de validité</small></article>
        <article class="b2b-contracts-stat b2b-contracts-stat--upcoming"><span>À venir</span><strong><?= $statistiquesContrats['a-venir'] ?></strong><small>Début de contrat ultérieur</small></article>
        <article class="b2b-contracts-stat b2b-contracts-stat--balance"><span>Solde à recouvrer</span><strong><?= number_format($statistiquesContrats['solde'], 0, ',', ' ') ?><small>FCFA</small></strong><small>Reste dû sur les contrats</small></article>
    </section>

    <section class="b2b-panel b2b-contract-create-panel">
        <div class="b2b-panel__heading b2b-contract-create-heading">
            <div>
                <span class="b2b-eyebrow">NOUVEL ACCORD</span>
                <h2>Créer un contrat B2B</h2>
                <p>Définissez les crédits, la période et les niveaux de service de votre prochain partenariat.</p>
            </div>
            <aside class="b2b-contract-create-heading__aside" aria-hidden="true">
                <span class="b2b-contract-create-heading__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3.75h7l4 4v12.5H7z"/><path d="M14 3.75v4h4M10 12h5M10 15.5h5"/></svg></span>
                <span><strong>Contrat entreprise</strong><small>Crédits · période · SLA</small></span>
            </aside>
        </div>
        <?php if (!$entreprises): ?><div class="b2b-empty">Aucune entreprise active à contractualiser.</div>
        <?php else: ?><form method="post" class="b2b-form b2b-contract-form">
            <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
            <input type="hidden" name="action" value="creer">
            <section class="b2b-contract-form__section" aria-labelledby="contrat-section-entreprise">
                <header class="b2b-contract-form__section-heading">
                    <span>01</span>
                    <div><h3 id="contrat-section-entreprise">Entreprise et période</h3><p>Choisissez le partenaire et définissez la durée de validité.</p></div>
                </header>
                <div class="b2b-contract-company">
                    <div class="b2b-contract-company__search">
                        <label class="b2b-search-label" for="contrat-entreprise-search">Rechercher une entreprise
                            <input id="contrat-entreprise-search" type="search" autocomplete="off" placeholder="Saisir le nom de l’entreprise…" aria-controls="contrat-entreprise-select">
                        </label>
                        <p id="contrat-entreprise-search-status" class="b2b-contract-company__status" aria-live="polite"><?= count($entreprises) ?> entreprise<?= count($entreprises) === 1 ? '' : 's' ?> disponible<?= count($entreprises) === 1 ? '' : 's' ?>.</p>
                    </div>
                    <label for="contrat-entreprise-select">Entreprise à contractualiser
                        <select id="contrat-entreprise-select" name="entreprise_id" required>
                            <option value="">Choisir une entreprise</option>
                            <?php foreach ($entreprises as $entreprise): ?><option value="<?= (int) $entreprise['id'] ?>"><?= $e($entreprise['nom']) ?></option><?php endforeach; ?>
                        </select>
                    </label>
                </div>
                <div class="b2b-contract-form__row">
                    <label>Début du contrat<input type="date" name="date_debut" value="<?= date('Y-m-d') ?>" required></label>
                    <label>Fin du contrat<input type="date" name="date_fin" required></label>
                </div>
            </section>
            <section class="b2b-contract-form__section" aria-labelledby="contrat-section-credits">
                <header class="b2b-contract-form__section-heading">
                    <span>02</span>
                    <div><h3 id="contrat-section-credits">Crédits et budget</h3><p>Précisez le volume d’interventions prévu et le montant convenu.</p></div>
                </header>
                <div class="b2b-contract-form__row">
                    <label>Nombre de crédits<input type="number" name="volume_credits" min="1" max="1000000" step="1" placeholder="Ex. 20" required></label>
                    <label>Montant contractuel (FCFA)<input type="number" name="montant_total" min="0" max="9999999999.99" step="0.01" value="0" required></label>
                </div>
            </section>
            <section class="b2b-contract-form__section" aria-labelledby="contrat-section-sla">
                <header class="b2b-contract-form__section-heading">
                    <span>03</span>
                    <div><h3 id="contrat-section-sla">Délais de prise en charge</h3><p>Fixez les engagements de service pour chaque niveau d’urgence.</p></div>
                </header>
                <div class="b2b-contract-form__row">
                    <label>SLA urgent (heures)<input type="number" name="sla_urgent_heures" min="1" max="8760" value="2" required></label>
                    <label>SLA normal (heures)<input type="number" name="sla_normal_heures" min="1" max="8760" value="24" required></label>
                </div>
            </section>
            <section class="b2b-contract-form__section b2b-contract-form__section--conditions" aria-labelledby="contrat-section-conditions">
                <header class="b2b-contract-form__section-heading">
                    <span>04</span>
                    <div><h3 id="contrat-section-conditions">Conditions particulières</h3><p>Ajoutez le périmètre, les modalités de règlement ou les exclusions.</p></div>
                </header>
                <label class="b2b-contract-form__conditions-label" for="contrat-conditions">Conditions du contrat
                    <textarea id="contrat-conditions" name="conditions" maxlength="10000" rows="4" placeholder="Saisissez les conditions convenues avec l’entreprise…"></textarea>
                </label>
            </section>
            <footer class="b2b-contract-form__footer">
                <p class="b2b-contract-form__note">Les interventions B2B restent distinctes de la facturation client : aucun paiement individuel n’est demandé lors de leur clôture.</p>
                <button class="b2b-button" type="submit"><span>Créer le contrat</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
            </footer>
        </form><?php endif; ?>
    </section>

    <section class="b2b-panel">
        <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">PORTFOLIO</span><h2>Contrats enregistrés</h2></div><span class="b2b-count" id="contrats-enregistres-count"><?= count($contrats) ?> contrat<?= count($contrats) === 1 ? '' : 's' ?></span></div>
        <?php if (!$contrats): ?><div class="b2b-empty">Aucun contrat entreprise n’a encore été créé.</div>
        <?php else: ?>
        <label class="b2b-search-label b2b-contracts-search" for="contrats-enregistres-search">Rechercher dans les contrats enregistrés
            <input id="contrats-enregistres-search" type="search" autocomplete="off" placeholder="Nom de l’entreprise ou numéro du contrat…" aria-controls="contrats-enregistres-table">
        </label>
        <p id="contrats-enregistres-search-status" class="b2b-contract-company__status" aria-live="polite"><?= count($contrats) ?> contrat<?= count($contrats) === 1 ? '' : 's' ?> affiché<?= count($contrats) === 1 ? '' : 's' ?>.</p>
        <div class="b2b-contracts-filters" role="group" aria-label="Filtrer les contrats par état">
            <button type="button" class="is-active" data-etat-filter="tous" aria-pressed="true">Tous <span><?= $statistiquesContrats['total'] ?></span></button>
            <button type="button" data-etat-filter="actif" aria-pressed="false">Actifs <span><?= $statistiquesContrats['actif'] ?></span></button>
            <button type="button" data-etat-filter="a-venir" aria-pressed="false">À venir <span><?= $statistiquesContrats['a-venir'] ?></span></button>
            <button type="button" data-etat-filter="expire" aria-pressed="false">Expirés <span><?= $statistiquesContrats['expire'] ?></span></button>
            <button type="button" data-etat-filter="resilie" aria-pressed="false">Résiliés <span><?= $statistiquesContrats['resilie'] ?></span></button>
        </div>
        <div class="b2b-table-wrap"><table class="b2b-list b2b-contracts-table"><thead><tr><th>Entreprise / contrat</th><th>Période</th><th>Crédits utilisés</th><th>Disponible</th><th>Montant</th><th>SLA urgent / normal</th><th>État</th><th>Action</th></tr></thead><tbody id="contrats-enregistres-table">
            <?php foreach ($contrats as $contrat): $etat = $etatContrat($contrat); $cleEtat = $cleEtatContrat($contrat); ?>
                <tr data-entreprise="<?= $e($contrat['entreprise_nom']) ?>" data-contrat-id="contrat #<?= (int) $contrat['id'] ?>" data-etat="<?= $e($cleEtat) ?>">
                    <td><?= $e($contrat['entreprise_nom']) ?><small class="b2b-table-subline"><a class="b2b-row-link__primary" href="detail-contrat-entreprise.php?id=<?= (int) $contrat['id'] ?>">Contrat #<?= (int) $contrat['id'] ?> · Voir le détail</a></small></td>
                    <td><?= $e(date('d/m/Y', strtotime($contrat['date_debut']))) ?> — <?= $e(date('d/m/Y', strtotime($contrat['date_fin']))) ?></td>
                    <td><?= (int) $contrat['credits_utilises'] ?> consommé<?= (int) $contrat['credits_utilises'] === 1 ? '' : 's' ?> · <?= (int) $contrat['credits_reserves'] ?> réservé<?= (int) $contrat['credits_reserves'] === 1 ? '' : 's' ?> / <?= (int) $contrat['volume_credits'] ?></td>
                    <td><?= (int) $contrat['credits_disponibles'] ?></td>
                    <td><?= number_format((float) $contrat['montant_total'], 0, ',', ' ') ?> FCFA<small class="b2b-table-subline">Réglé <?= number_format((float) $contrat['montant_regle'], 0, ',', ' ') ?> · Solde <?= number_format((float) $contrat['solde'], 0, ',', ' ') ?></small></td>
                    <td><?= (int) ceil((int) $contrat['sla_urgent_minutes'] / 60) ?> h / <?= (int) ceil((int) $contrat['sla_normal_minutes'] / 60) ?> h</td>
                    <td><span class="b2b-contract-state b2b-contract-state--<?= $e($cleEtat) ?>"><?= $e($etat) ?></span></td>
                    <td><div class="b2b-contract-admin-actions">
                        <?php if ($contrat['statut'] === 'actif' && (float) $contrat['solde'] > 0): ?>
                            <details class="b2b-contract-payment"><summary>Enregistrer un règlement</summary><form method="post" class="b2b-form">
                                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="paiement"><input type="hidden" name="contrat_id" value="<?= (int) $contrat['id'] ?>">
                                <label>Montant reçu<input type="number" name="montant" min="0.01" max="<?= $e(number_format((float) $contrat['solde'], 2, '.', '')) ?>" step="0.01" required></label>
                                <label>Moyen<select name="methode" required><option value="wave">Wave</option><option value="orange_money">Orange Money</option><option value="virement">Virement</option><option value="cheque">Chèque</option><option value="especes">Espèces</option><option value="autre">Autre</option></select></label>
                                <label>Référence (facultative)<input name="reference_transaction" maxlength="100"></label>
                                <button class="b2b-button" type="submit">Enregistrer le paiement</button>
                            </form></details>
                        <?php endif; ?>
                        <?php if ($contrat['statut'] === 'actif' && (int) $contrat['credits_reserves'] === 0): ?>
                            <form method="post"><input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="resilier"><input type="hidden" name="contrat_id" value="<?= (int) $contrat['id'] ?>"><button class="b2b-button b2b-button--secondary" type="submit">Résilier</button></form>
                        <?php elseif ($contrat['statut'] === 'actif'): ?>Missions réservées<?php endif; ?>
                    </div></td>
                </tr>
            <?php endforeach; ?>
        </tbody></table></div><p id="contrats-enregistres-no-results" class="b2b-contracts-no-results" hidden>Aucun contrat ne correspond à cette recherche et à ce filtre.</p><?php endif; ?>
    </section>

    <?php if ($peutLierDemandeContrat): ?>
    <section class="b2b-panel">
        <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">TRANSITION DES DOSSIERS EXISTANTS</span><h2>Demandes entreprise sans contrat</h2><p>Rattachez les demandes ouvertes créées avant l’activation du parcours contractuel.</p></div></div>
        <?php if (!$demandesSansContrat): ?><div class="b2b-empty">Aucune demande entreprise ouverte n’attend un contrat.</div>
        <?php else: ?><div class="b2b-table-wrap"><table class="b2b-list"><thead><tr><th>Dossier</th><th>Entreprise / site</th><th>Créée le</th><th>Contrat actif</th></tr></thead><tbody>
            <?php foreach ($demandesSansContrat as $demande): $contratsDisponibles = $contratsActifsParEntreprise[(int) $demande['entreprise_b2b_id']] ?? []; ?>
                <tr><td><?= $e($demande['numero_dossier']) ?><span class="badge-demande-entreprise">Demande venant d’une entreprise</span><small class="b2b-table-subline"><?= $e(ucfirst(str_replace('_', ' ', $demande['statut']))) ?></small></td><td><?= $e($demande['entreprise_nom']) ?><small class="b2b-table-subline"><?= $e($demande['site_nom']) ?></small></td><td><?= $e(date('d/m/Y', strtotime($demande['date_creation']))) ?></td><td>
                    <?php if ($contratsDisponibles): ?><form method="post" class="b2b-contract-link-form"><input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="lier-demande"><input type="hidden" name="demande_id" value="<?= (int) $demande['id'] ?>"><select name="contrat_id" required><option value="">Choisir le contrat</option><?php foreach ($contratsDisponibles as $contrat): ?><option value="<?= (int) $contrat['id'] ?>">#<?= (int) $contrat['id'] ?> · <?= (int) $contrat['credits_disponibles'] ?> crédit(s) dispo.</option><?php endforeach; ?></select><button class="b2b-button" type="submit">Rattacher</button></form>
                    <?php else: ?>Créez d’abord un contrat actif<?php endif; ?>
                </td></tr>
            <?php endforeach; ?>
        </tbody></table></div><?php endif; ?>
    </section>
    <?php endif; ?>
</main></div>
<script>
(() => {
    const normaliser = (valeur) => valeur.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('fr');

    const rechercheEntreprise = document.getElementById('contrat-entreprise-search');
    const selectEntreprise = document.getElementById('contrat-entreprise-select');
    const statutEntreprise = document.getElementById('contrat-entreprise-search-status');
    if (rechercheEntreprise instanceof HTMLInputElement
        && selectEntreprise instanceof HTMLSelectElement
        && statutEntreprise instanceof HTMLElement) {
        const optionDefaut = selectEntreprise.options[0].cloneNode(true);
        const entreprises = Array.from(selectEntreprise.options).slice(1).map((option) => option.cloneNode(true));
        const afficherEntreprises = () => {
            const recherche = normaliser(rechercheEntreprise.value.trim());
            const resultats = entreprises.filter((option) => normaliser(option.textContent || '').includes(recherche));
            const options = document.createDocumentFragment();
            options.appendChild(optionDefaut.cloneNode(true));
            resultats.forEach((option) => options.appendChild(option.cloneNode(true)));
            selectEntreprise.replaceChildren(options);
            statutEntreprise.textContent = resultats.length
                ? `${resultats.length} entreprise${resultats.length === 1 ? '' : 's'} correspond${resultats.length === 1 ? '' : 'ent'} à la recherche.`
                : 'Aucune entreprise ne correspond à cette recherche.';
        };

        rechercheEntreprise.addEventListener('input', afficherEntreprises);
        selectEntreprise.addEventListener('change', () => {
            const entreprise = selectEntreprise.options[selectEntreprise.selectedIndex];
            if (selectEntreprise.value) {
                statutEntreprise.textContent = `${entreprise.textContent} sélectionnée pour le nouveau contrat.`;
            }
        });
    }

    const rechercheContrats = document.getElementById('contrats-enregistres-search');
    const tableContrats = document.getElementById('contrats-enregistres-table');
    const statutContrats = document.getElementById('contrats-enregistres-search-status');
    const compteurContrats = document.getElementById('contrats-enregistres-count');
    const messageVideContrats = document.getElementById('contrats-enregistres-no-results');
    const filtresContrats = Array.from(document.querySelectorAll('[data-etat-filter]'));
    if (rechercheContrats instanceof HTMLInputElement
        && tableContrats instanceof HTMLTableSectionElement
        && statutContrats instanceof HTMLElement
        && compteurContrats instanceof HTMLElement
        && messageVideContrats instanceof HTMLElement) {
        const lignesContrats = Array.from(tableContrats.rows);
        let etatFiltre = 'tous';
        const filtrerContrats = () => {
            const recherche = normaliser(rechercheContrats.value.trim());
            let nombreVisible = 0;
            lignesContrats.forEach((ligne) => {
                const texte = normaliser(`${ligne.dataset.entreprise || ''} ${ligne.dataset.contratId || ''}`);
                const correspondRecherche = texte.includes(recherche);
                const correspondEtat = etatFiltre === 'tous' || ligne.dataset.etat === etatFiltre;
                ligne.hidden = !correspondRecherche || !correspondEtat;
                if (!ligne.hidden) {
                    nombreVisible += 1;
                }
            });
            const suffixe = nombreVisible === 1 ? '' : 's';
            compteurContrats.textContent = `${nombreVisible} contrat${suffixe}`;
            statutContrats.textContent = nombreVisible
                ? `${nombreVisible} contrat${suffixe} affiché${suffixe} sur ${lignesContrats.length}.`
                : 'Aucun contrat ne correspond à cette recherche et à ce filtre.';
            messageVideContrats.hidden = nombreVisible > 0;
        };
        rechercheContrats.addEventListener('input', filtrerContrats);
        filtresContrats.forEach((filtre) => {
            filtre.addEventListener('click', () => {
                etatFiltre = filtre.dataset.etatFilter || 'tous';
                filtresContrats.forEach((bouton) => {
                    const actif = bouton === filtre;
                    bouton.classList.toggle('is-active', actif);
                    bouton.setAttribute('aria-pressed', actif ? 'true' : 'false');
                });
                filtrerContrats();
            });
        });
    }
})();
</script>
</body></html>
