<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('parametres');
require_once __DIR__ . '/../../models/Parametre.php';
require_once __DIR__ . '/../../models/Facture.php';
require_once __DIR__ . '/../../models/ConfigurationEmail.php';
require_once __DIR__ . '/../../models/AttributionDemandes.php';
require_once __DIR__ . '/../../models/ConfigurationAttributionDemandes.php';

$parametreModel = new Parametre();
$factureModel = new Facture();
$configurationEmailModel = new ConfigurationEmail();
$configurationAttributionModel = new ConfigurationAttributionDemandes();
$configurationAttribution = $configurationAttributionModel->getAll();
if (empty($_SESSION['csrf_parametres'])) {
    $_SESSION['csrf_parametres'] = bin2hex(random_bytes(32));
}

$erreur = '';
$messageSucces = $_SESSION['flash_parametres'] ?? '';
unset($_SESSION['flash_parametres']);
$valeurs = $parametreModel->getAll();
$valeurs['sla_demande_urgente_heures'] = (string) $parametreModel->getSlaDemandeUrgenteHeures();
$valeurs['sla_demande_normale_heures'] = (string) $parametreModel->getSlaDemandeNormaleHeures();
$vendeur = $factureModel->getParametresVendeur();
$configurationEmailGoogle = $configurationEmailModel->getStatutGoogle();
$groupesConfigurationAlgorithme = [
    [
        'titre' => 'Charge maximale',
        'description' => 'Refuser un technicien qui a atteint le plafond d’interventions actives.',
        'cle_active' => 'limite_charge_active',
        'libelle_active' => 'Appliquer le plafond',
        'champs' => [['charge_maximale', 'Interventions actives maximum', 1, 100, 'missions']],
    ],
    [
        'titre' => 'Score de couverture géographique',
        'description' => 'La zone reste obligatoire. Ce réglage change uniquement la priorité entre techniciens couvrant la demande.',
        'cle_active' => 'score_zone_active',
        'libelle_active' => 'Ajouter le score de zone',
        'champs' => [
            ['score_zone_quartier', 'Quartier exact', 0, 1000, 'points'],
            ['score_zone_elargie', 'Zone élargie', 0, 1000, 'points'],
            ['score_zone_ville', 'Ville', 0, 1000, 'points'],
        ],
    ],
    [
        'titre' => 'Score de compétence',
        'description' => 'Une compétence compatible reste obligatoire ; le score distingue la compétence exacte du pôle compatible.',
        'cle_active' => 'score_competence_active',
        'libelle_active' => 'Ajouter le score de compétence',
        'champs' => [
            ['score_competence_exacte', 'Compétence exacte', 0, 1000, 'points'],
            ['score_competence_compatible', 'Pôle compatible', 0, 1000, 'points'],
        ],
    ],
    [
        'titre' => 'Réputation du partenaire',
        'description' => 'Points ajoutés par étoile de réputation (note maximale : 5/5).',
        'cle_active' => 'score_reputation_active',
        'libelle_active' => 'Ajouter la réputation au score',
        'champs' => [['score_reputation_par_point', 'Points par étoile', 0, 100, 'points']],
    ],
    [
        'titre' => 'Niveau du partenaire',
        'description' => 'Bonus associés au niveau du partenaire.',
        'cle_active' => 'score_niveau_active',
        'libelle_active' => 'Ajouter le niveau au score',
        'champs' => [
            ['score_niveau_certifie', 'Certifié', 0, 100, 'points'],
            ['score_niveau_premium', 'Premium', 0, 100, 'points'],
            ['score_niveau_excellence', 'Excellence', 0, 100, 'points'],
        ],
    ],
    [
        'titre' => 'Pénalité de charge',
        'description' => 'Réduire le score des techniciens qui ont déjà des interventions actives.',
        'cle_active' => 'score_charge_active',
        'libelle_active' => 'Pénaliser la charge existante',
        'champs' => [['penalite_charge', 'Retrait par intervention active', 0, 100, 'points']],
    ],
    [
        'titre' => 'Horizon des créneaux',
        'description' => 'Limiter la recherche des créneaux libres. Si la limite est désactivée, la recherche est étendue à 365 jours.',
        'cle_active' => 'horizon_creneaux_active',
        'libelle_active' => 'Appliquer la limite de recherche',
        'champs' => [['horizon_creneaux_jours', 'Jours à rechercher', 1, 365, 'jours']],
    ],
];
$prioritesConfigurationAlgorithme = [
    ['priorite_urgence_active', 'Prioriser les demandes urgentes', 'Les urgences passent avant les demandes normales.'],
    ['priorite_abonnement_active', 'Prioriser les abonnements', 'Les demandes avec abonnement passent avant les autres.'],
    ['priorite_anciennete_active', 'Prioriser les demandes anciennes', 'Si désactivé, les demandes les plus récentes passent d’abord.'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string) ($_POST['csrf'] ?? '');
    if (!hash_equals($_SESSION['csrf_parametres'], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (($_POST['action'] ?? '') === 'configuration_algorithme') {
        $validationConfiguration = $configurationAttributionModel->validerSoumission($_POST);
        $configurationAttribution = $validationConfiguration['configuration'];
        if (!$validationConfiguration['valide']) {
            $erreur = $validationConfiguration['erreur'];
        } else {
            try {
                $configurationAttributionModel->enregistrer($configurationAttribution);
                journaliser(
                    'parametre.algorithme_attribution_modifie',
                    'parametre',
                    null,
                    'algorithme_attribution',
                    'Configuration de l’algorithme d’attribution mise à jour'
                );
                $_SESSION['flash_parametres'] = 'La configuration de l’algorithme a été enregistrée.';
                if ($parametreModel->attributionAutomatiqueDemandesActive()) {
                    try {
                        $resultatAffectation = (new AttributionDemandes())->traiterFile();
                        $nombreAttribuees = count($resultatAffectation['attribuees']);
                        if ($nombreAttribuees > 0) {
                            $_SESSION['flash_parametres'] .= sprintf(
                                ' %d demande%s attribuée%s avec les nouveaux réglages.',
                                $nombreAttribuees,
                                $nombreAttribuees > 1 ? 's' : '',
                                $nombreAttribuees > 1 ? 's' : ''
                            );
                        }
                        if ($resultatAffectation['en_attente'] > 0) {
                            $_SESSION['flash_parametres'] .= sprintf(
                                ' %d demande%s admissible%s reste%s sans technicien ou créneau disponible.',
                                $resultatAffectation['en_attente'],
                                $resultatAffectation['en_attente'] > 1 ? 's' : '',
                                $resultatAffectation['en_attente'] > 1 ? 's' : '',
                                $resultatAffectation['en_attente'] > 1 ? 'nt' : ''
                            );
                        }
                    } catch (Throwable $exception) {
                        error_log('Relance de la file après configuration de l’algorithme : ' . $exception->getMessage());
                        $_SESSION['flash_parametres'] .= ' La file n’a pas pu être relancée ; les demandes non attribuées restent disponibles pour le traitement manuel.';
                    }
                }
                header('Location: parametres.php');
                exit;
            } catch (Throwable $exception) {
                error_log('Enregistrement de la configuration de l’algorithme par admin ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
                $erreur = 'La configuration de l’algorithme n’a pas pu être enregistrée. Vérifiez que la migration est appliquée puis réessayez.';
            }
        }
    } elseif (($_POST['action'] ?? '') === 'sla_demandes') {
        $slaUrgentBrut = is_string($_POST['sla_demande_urgente_heures'] ?? null)
            ? trim($_POST['sla_demande_urgente_heures'])
            : '';
        $slaNormalBrut = is_string($_POST['sla_demande_normale_heures'] ?? null)
            ? trim($_POST['sla_demande_normale_heures'])
            : '';
        $slaUrgent = filter_var($slaUrgentBrut, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 720]]);
        $slaNormal = filter_var($slaNormalBrut, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 720]]);
        $valeurs['sla_demande_urgente_heures'] = $slaUrgentBrut;
        $valeurs['sla_demande_normale_heures'] = $slaNormalBrut;

        if ($slaUrgent === false || $slaNormal === false) {
            $erreur = 'Les SLA doivent être des nombres entiers compris entre 1 et 720 heures.';
        } else {
            $anciens = $parametreModel->getAll();
            $nouveaux = [
                'sla_demande_urgente_heures' => (string) $slaUrgent,
                'sla_demande_normale_heures' => (string) $slaNormal,
            ];
            try {
                if ($parametreModel->setMultiple($nouveaux)) {
                    foreach ($nouveaux as $cle => $valeur) {
                        if ((int) ($anciens[$cle] ?? 0) !== (int) $valeur) {
                            journaliser(
                                'parametre.sla_modifie',
                                'parametre',
                                null,
                                $cle,
                                (string) ($anciens[$cle] ?? '') . ' h → ' . $valeur . ' h'
                            );
                        }
                    }
                    $_SESSION['flash_parametres'] = 'Les délais SLA des demandes ont été enregistrés.';
                    header('Location: parametres.php');
                    exit;
                }
                $erreur = 'Les délais SLA n’ont pas pu être enregistrés. Vérifiez les valeurs saisies.';
            } catch (PDOException $exception) {
                error_log('Enregistrement des SLA par admin ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
                $erreur = 'Les délais SLA n’ont pas pu être enregistrés. Réessayez.';
            }
        }
    } elseif (($_POST['action'] ?? '') === 'coordonnees_facturation') {
        $vendeurSoumis = [];
        foreach (['vendeur_nom', 'vendeur_identifiant', 'vendeur_adresse', 'vendeur_telephone', 'vendeur_email'] as $cle) {
            $valeur = $_POST[$cle] ?? '';
            $vendeurSoumis[$cle] = is_string($valeur) ? trim($valeur) : '';
        }
        try {
            $factureModel->enregistrerParametresVendeur($vendeurSoumis, (int) $_SESSION['user_id']);
            journaliser('parametre.coordonnees_facturation_modifiees', 'parametre', null, 'coordonnees_facturation', 'Coordonnées vendeur mises à jour');
            $_SESSION['flash_parametres'] = 'Les coordonnées de facturation du vendeur ont été enregistrées.';
            header('Location: parametres.php');
            exit;
        } catch (InvalidArgumentException $exception) {
            $vendeur = array_merge($vendeur, $vendeurSoumis);
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Enregistrement des coordonnées de facturation par admin ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
            $vendeur = array_merge($vendeur, $vendeurSoumis);
            $erreur = 'Les coordonnées de facturation n’ont pas pu être enregistrées. Réessayez.';
        }
    } elseif (($_POST['action'] ?? '') === 'configuration_email_google') {
        $emailGoogle = is_string($_POST['compte_google'] ?? null) ? trim($_POST['compte_google']) : '';
        $motDePasseApplication = is_string($_POST['mot_de_passe_application_google'] ?? null)
            ? $_POST['mot_de_passe_application_google']
            : '';
        try {
            $configurationEmailModel->enregistrerGoogle($emailGoogle, $motDePasseApplication, (int) $_SESSION['user_id']);
            journaliser('parametre.email_google_modifie', 'parametre', null, 'email_google', 'Configuration du compte Gmail mise à jour');
            $_SESSION['flash_parametres'] = 'Les identifiants Gmail de messagerie ont été enregistrés de manière chiffrée.';
            header('Location: parametres.php');
            exit;
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $configurationEmailGoogle['compte_google'] = $emailGoogle;
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Configuration Gmail modifiée par admin ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
            $configurationEmailGoogle['compte_google'] = $emailGoogle;
            $erreur = 'Les identifiants Gmail n’ont pas pu être enregistrés. Vérifiez la migration et réessayez.';
        }
    } else {
        $tauxBrut = trim((string) ($_POST['taux_commission'] ?? ''));
        $taux = filter_var($tauxBrut, FILTER_VALIDATE_FLOAT);
        $limiteBrute = trim((string) ($_POST['limite_clients_par_conseiller'] ?? ''));
        $limite = filter_var($limiteBrute, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 10000]]);
        $anciens = $valeurs;
        $heureDebutBrute = trim((string) ($_POST['heure_debut_indisponibilites'] ?? ''));
        $heureFinBrute = trim((string) ($_POST['heure_fin_indisponibilites'] ?? ''));
        $valeurs['heure_debut_indisponibilites'] = $heureDebutBrute;
        $valeurs['heure_fin_indisponibilites'] = $heureFinBrute;

        if ($taux === false || $taux < 0 || $taux > 100 || abs($taux * 2 - round($taux * 2)) > 0.00001) {
            $erreur = 'La commission doit être comprise entre 0 et 100 %, par pas de 0,5 %.';
        } elseif ($limite === false) {
            $erreur = 'Le plafond doit être un nombre entier compris entre 0 et 10 000.';
        } else {
            $heureDebut = filter_var($heureDebutBrute, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 23]]);
            $heureFin = filter_var($heureFinBrute, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 24]]);

            if ($heureDebut === false || $heureFin === false || $heureDebut >= $heureFin) {
                $erreur = 'Les heures du calendrier doivent former une plage valide, de 0 h à 24 h.';
            } else {
                $nouveaux = [
                    'taux_commission' => number_format((float) $taux, 1, '.', ''),
                    'attribution_automatique' => isset($_POST['attribution_automatique']) ? '1' : '0',
                    'attribution_automatique_demandes' => isset($_POST['attribution_automatique_demandes']) ? '1' : '0',
                    'limite_clients_par_conseiller' => (string) $limite,
                    'heure_debut_indisponibilites' => (string) $heureDebut,
                    'heure_fin_indisponibilites' => (string) $heureFin,
                ];

                if ($parametreModel->setMultiple($nouveaux)) {
                    if ((float) $anciens['taux_commission'] !== (float) $nouveaux['taux_commission']) {
                        journaliser('parametre.commission_modifiee', 'parametre', null, 'taux_commission', $anciens['taux_commission'] . ' % → ' . $nouveaux['taux_commission'] . ' %');
                    }
                    if ($anciens['attribution_automatique'] !== $nouveaux['attribution_automatique']) {
                        journaliser('parametre.attribution_modifiee', 'parametre', null, 'attribution_automatique', $nouveaux['attribution_automatique'] === '1' ? 'Activée' : 'Désactivée');
                    }
                    if ($anciens['attribution_automatique_demandes'] !== $nouveaux['attribution_automatique_demandes']) {
                        journaliser('parametre.attribution_demandes_modifiee', 'parametre', null, 'attribution_automatique_demandes', $nouveaux['attribution_automatique_demandes'] === '1' ? 'Activée' : 'Désactivée');
                    }
                    if ((int) $anciens['limite_clients_par_conseiller'] !== (int) $nouveaux['limite_clients_par_conseiller']) {
                        journaliser('parametre.limite_attribution_modifiee', 'parametre', null, 'limite_clients_par_conseiller', $anciens['limite_clients_par_conseiller'] . ' → ' . $nouveaux['limite_clients_par_conseiller']);
                    }
                    if ($anciens['heure_debut_indisponibilites'] !== $nouveaux['heure_debut_indisponibilites']
                        || $anciens['heure_fin_indisponibilites'] !== $nouveaux['heure_fin_indisponibilites']) {
                        journaliser(
                            'parametre.plage_indisponibilites_modifiee',
                            'parametre',
                            null,
                            'plage_indisponibilites',
                            $anciens['heure_debut_indisponibilites'] . ' h–' . $anciens['heure_fin_indisponibilites']
                                . ' h → ' . $nouveaux['heure_debut_indisponibilites'] . ' h–'
                                . $nouveaux['heure_fin_indisponibilites'] . ' h'
                        );
                    }
                    $_SESSION['flash_parametres'] = 'Les paramètres ont été enregistrés.';
                    if ($nouveaux['attribution_automatique_demandes'] === '1') {
                        try {
                            $resultatAffectation = (new AttributionDemandes())->traiterFile();
                            $nombreAttribuees = count($resultatAffectation['attribuees']);
                            $nombreDemandesAdmissibles = $nombreAttribuees + $resultatAffectation['en_attente'];
                            if ($nombreAttribuees > 0) {
                                $_SESSION['flash_parametres'] .= sprintf(
                                    ' %d demande%s en attente attribuée%s automatiquement.',
                                    $nombreAttribuees,
                                    $nombreAttribuees > 1 ? 's' : '',
                                    $nombreAttribuees > 1 ? 's' : ''
                                );
                            } elseif ($nombreDemandesAdmissibles === 0) {
                                $_SESSION['flash_parametres'] .= ' Aucune demande admissible déjà en attente n’a été trouvée.';
                            }
                            if ($resultatAffectation['en_attente'] > 0) {
                                $_SESSION['flash_parametres'] .= sprintf(
                                    ' %d demande%s admissible%s reste%s sans technicien ou créneau disponible et doi%s être traitée%s manuellement.',
                                    $resultatAffectation['en_attente'],
                                    $resultatAffectation['en_attente'] > 1 ? 's' : '',
                                    $resultatAffectation['en_attente'] > 1 ? 's' : '',
                                    $resultatAffectation['en_attente'] > 1 ? 'nt' : '',
                                    $resultatAffectation['en_attente'] > 1 ? 'vent' : 't',
                                    $resultatAffectation['en_attente'] > 1 ? 's' : ''
                                );
                            }
                        } catch (Throwable $exception) {
                            error_log('Traitement de la file automatique depuis les paramètres : ' . $exception->getMessage());
                            $_SESSION['flash_parametres'] .= ' La file n’a pas pu être traitée ; les demandes non attribuées restent disponibles pour le traitement manuel.';
                        }
                    }
                    header('Location: parametres.php');
                    exit;
                }

                $erreur = 'Les paramètres n’ont pas pu être enregistrés.';
            }
        }

        $valeurs['taux_commission'] = $tauxBrut;
        $valeurs['attribution_automatique'] = isset($_POST['attribution_automatique']) ? '1' : '0';
        $valeurs['attribution_automatique_demandes'] = isset($_POST['attribution_automatique_demandes']) ? '1' : '0';
        $valeurs['limite_clients_par_conseiller'] = $limiteBrute;
    }
}

$echapper = static fn($valeur) => htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paramètres — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/parametres-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/parametres-admin.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <main class="admin-contenu parametres-page">
        <header class="admin-entete">
            <div>
                <div class="admin-entete__titre">Paramètres de la plateforme</div>
                <p class="admin-entete__sous-titre">Réglez les commissions, les délais de traitement et les options opérationnelles de la plateforme.</p>
            </div>
        </header>

        <?php if ($messageSucces): ?>
            <div class="parametres-message parametres-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur): ?>
            <div class="parametres-message parametres-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <form method="POST" class="parametres-form">
            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">

            <section class="admin-panneau parametres-section" aria-labelledby="parametres-finance-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">01</div>
                    <div><h2 id="parametres-finance-titre">Finance</h2><p>Commissions appliquées aux reversements à venir.</p></div>
                </header>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="taux-commission">Commission ALLÔ PRO</label>
                        <p>Pourcentage retenu avant le reversement au partenaire. Les reversements déjà créés ne sont pas recalculés.</p>
                    </div>
                    <div class="parametres-taux">
                        <input id="taux-commission" type="number" name="taux_commission" value="<?= $echapper($valeurs['taux_commission']) ?>" min="0" max="100" step="0.5" inputmode="decimal" required>
                        <span>%</span>
                    </div>
                </div>
            </section>

            <section class="admin-panneau parametres-section" aria-labelledby="parametres-conversations-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">02</div>
                    <div><h2 id="parametres-conversations-titre">Attribution automatique</h2><p>Réglez séparément l’affectation des conversations et des demandes de service.</p></div>
                </header>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="attribution-automatique">Attribution automatique</label>
                        <p>Au premier message du client, l’affecter au conseiller en ligne le moins chargé. Sans conseiller disponible, la conversation reste dans la file. Si l’attribution est désactivée, l’équipe la traite manuellement.</p>
                    </div>
                    <label class="parametres-switch" for="attribution-automatique">
                        <input id="attribution-automatique" type="checkbox" name="attribution_automatique" value="1" role="switch" <?= $valeurs['attribution_automatique'] === '1' ? 'checked' : '' ?>>
                        <span class="parametres-switch__piste" aria-hidden="true"></span>
                        <span class="parametres-switch__etat"><?= $valeurs['attribution_automatique'] === '1' ? 'Activée' : 'Désactivée' ?></span>
                    </label>
                </div>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="attribution-automatique-demandes">Affectation automatique des demandes</label>
                        <p>À l’activation, traite aussi les demandes admissibles déjà en attente. L’algorithme prend les demandes avec date et créneau souhaités, par urgence, puis abonnement et ancienneté. Les techniciens sont filtrés par compétence, zone et charge. Le système réserve le premier créneau libre à partir de l’heure demandée, dans les horaires autorisés et les 30 prochains jours. Si le créneau change, une alerte est créée pour le coordinateur. Sans candidat éligible, la demande reste à traiter manuellement.</p>
                    </div>
                    <label class="parametres-switch" for="attribution-automatique-demandes">
                        <input id="attribution-automatique-demandes" type="checkbox" name="attribution_automatique_demandes" value="1" role="switch" <?= $valeurs['attribution_automatique_demandes'] === '1' ? 'checked' : '' ?>>
                        <span class="parametres-switch__piste" aria-hidden="true"></span>
                        <span class="parametres-switch__etat"><?= $valeurs['attribution_automatique_demandes'] === '1' ? 'Activée' : 'Désactivée' ?></span>
                    </label>
                </div>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="limite-clients">Plafond de clients par conseiller</label>
                        <p>Limite les nouvelles attributions de conversations. Les clients déjà attribués restent en place. Saisissez 0 pour ne pas fixer de plafond.</p>
                    </div>
                    <div class="parametres-limite">
                        <input id="limite-clients" type="number" name="limite_clients_par_conseiller" value="<?= $echapper($valeurs['limite_clients_par_conseiller']) ?>" min="0" max="10000" step="1" inputmode="numeric" required>
                        <span>clients</span>
                    </div>
                </div>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label>Plage horaire du calendrier technicien</label>
                        <p>Définit les heures visibles dans le calendrier d’indisponibilité. Chaque créneau bloque une heure entière.</p>
                    </div>
                    <div class="parametres-plage-horaire">
                        <label for="heure-debut-indisponibilites">De
                            <input id="heure-debut-indisponibilites" type="number" name="heure_debut_indisponibilites" value="<?= $echapper($valeurs['heure_debut_indisponibilites']) ?>" min="0" max="23" step="1" required>
                            <span>h</span>
                        </label>
                        <label for="heure-fin-indisponibilites">à
                            <input id="heure-fin-indisponibilites" type="number" name="heure_fin_indisponibilites" value="<?= $echapper($valeurs['heure_fin_indisponibilites']) ?>" min="1" max="24" step="1" required>
                            <span>h</span>
                        </label>
                    </div>
                </div>
            </section>

            <div class="parametres-actions">
                <p>Les changements s’appliquent aux prochaines opérations.</p>
                <button type="submit" class="parametres-enregistrer">Enregistrer les paramètres</button>
            </div>
        </form>

        <form method="POST" class="parametres-form" id="configuration-algorithme-form">
            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
            <input type="hidden" name="action" value="configuration_algorithme">
            <section class="admin-panneau parametres-section" aria-labelledby="parametres-algorithme-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">03</div>
                    <div>
                        <h2 id="parametres-algorithme-titre">Personnalisation de l’algorithme</h2>
                        <p>Réglez les critères de classement, les priorités et la capacité de charge.</p>
                    </div>
                </header>
                <p class="parametres-algorithme__note">
                    La compétence du technicien et la couverture de la zone restent des conditions obligatoires.
                    Les cases « score » activent ou désactivent uniquement leur effet sur le classement.
                </p>
                <div class="parametres-algorithme__grille">
                    <?php foreach ($groupesConfigurationAlgorithme as $index => $groupe):
                        $cleActive = $groupe['cle_active'];
                        $idActive = 'algorithme-' . str_replace('_', '-', $cleActive);
                    ?>
                        <article class="parametres-algorithme__groupe">
                            <header>
                                <div>
                                    <h3><?= $echapper($groupe['titre']) ?></h3>
                                    <p><?= $echapper($groupe['description']) ?></p>
                                </div>
                                <label class="parametres-switch" for="<?= $echapper($idActive) ?>">
                                    <input id="<?= $echapper($idActive) ?>" type="checkbox" name="<?= $echapper($cleActive) ?>" value="1" role="switch" data-algorithme-switch <?= $configurationAttribution[$cleActive] === '1' ? 'checked' : '' ?>>
                                    <span class="parametres-switch__piste" aria-hidden="true"></span>
                                    <span class="parametres-switch__etat"><?= $configurationAttribution[$cleActive] === '1' ? 'Activé' : 'Désactivé' ?></span>
                                </label>
                            </header>
                            <div class="parametres-algorithme__champs">
                                <?php foreach ($groupe['champs'] as [$cle, $libelle, $minimum, $maximum, $unite]):
                                    $id = 'algorithme-' . str_replace('_', '-', $cle);
                                ?>
                                    <label for="<?= $echapper($id) ?>">
                                        <span><?= $echapper($libelle) ?></span>
                                        <span class="parametres-algorithme__valeur">
                                            <input id="<?= $echapper($id) ?>" type="number" name="<?= $echapper($cle) ?>" value="<?= $echapper($configurationAttribution[$cle]) ?>" min="<?= (int) $minimum ?>" max="<?= (int) $maximum ?>" step="1" required>
                                            <span><?= $echapper($unite) ?></span>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                    <article class="parametres-algorithme__groupe parametres-algorithme__groupe--priorites">
                        <header>
                            <div>
                                <h3>Ordre de traitement</h3>
                                <p>Activez ou désactivez les priorités appliquées à la file des demandes.</p>
                            </div>
                        </header>
                        <div class="parametres-algorithme__priorites">
                            <?php foreach ($prioritesConfigurationAlgorithme as [$cle, $libelle, $description]):
                                $id = 'algorithme-' . str_replace('_', '-', $cle);
                            ?>
                                <div class="parametres-algorithme__priorite">
                                    <div><label for="<?= $echapper($id) ?>"><?= $echapper($libelle) ?></label><p><?= $echapper($description) ?></p></div>
                                    <label class="parametres-switch" for="<?= $echapper($id) ?>">
                                        <input id="<?= $echapper($id) ?>" type="checkbox" name="<?= $echapper($cle) ?>" value="1" role="switch" data-algorithme-switch <?= $configurationAttribution[$cle] === '1' ? 'checked' : '' ?>>
                                        <span class="parametres-switch__piste" aria-hidden="true"></span>
                                        <span class="parametres-switch__etat"><?= $configurationAttribution[$cle] === '1' ? 'Activé' : 'Désactivé' ?></span>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </article>
                </div>
                <div class="parametres-actions">
                    <p>Les réglages sont utilisés au prochain traitement de la file.</p>
                    <button type="submit" class="parametres-enregistrer">Enregistrer et traiter la file</button>
                </div>
            </section>
        </form>

        <form method="POST" class="parametres-form">
            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
            <input type="hidden" name="action" value="sla_demandes">
            <section class="admin-panneau parametres-section" aria-labelledby="parametres-sla-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">04</div>
                    <div><h2 id="parametres-sla-titre">Délais SLA des demandes</h2><p>Définissez le délai cible d’affectation à un technicien, à compter de la transmission au coordinateur. Les compteurs et alertes en cours s’alignent sur ces seuils.</p></div>
                </header>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="sla-demande-urgente">Demande urgente</label>
                        <p>Délai maximal d’affectation pour les dossiers urgents.</p>
                    </div>
                    <div class="parametres-limite">
                        <input id="sla-demande-urgente" type="number" name="sla_demande_urgente_heures" value="<?= $echapper($valeurs['sla_demande_urgente_heures']) ?>" min="1" max="720" step="1" inputmode="numeric" required>
                        <span>heures</span>
                    </div>
                </div>
                <div class="parametres-option">
                    <div class="parametres-option__texte">
                        <label for="sla-demande-normale">Demande normale</label>
                        <p>Délai maximal d’affectation pour les dossiers non urgents.</p>
                    </div>
                    <div class="parametres-limite">
                        <input id="sla-demande-normale" type="number" name="sla_demande_normale_heures" value="<?= $echapper($valeurs['sla_demande_normale_heures']) ?>" min="1" max="720" step="1" inputmode="numeric" required>
                        <span>heures</span>
                    </div>
                </div>
                <div class="parametres-actions">
                    <p>Valeur autorisée : 1 à 720 heures.</p>
                    <button type="submit" class="parametres-enregistrer">Enregistrer les SLA</button>
                </div>
            </section>
        </form>

        <form method="POST" class="parametres-form">
            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
            <input type="hidden" name="action" value="coordonnees_facturation">
            <section class="admin-panneau parametres-section" aria-labelledby="parametres-facturation-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">05</div>
                    <div><h2 id="parametres-facturation-titre">Identité et coordonnées de facturation</h2><p>Ces informations figureront sur les prochaines factures PDF. Les factures déjà émises restent inchangées.</p></div>
                </header>
                <div class="parametres-facturation-champs">
                    <div>
                        <label for="vendeur-nom">Nom légal du vendeur <span aria-hidden="true">*</span></label>
                        <input id="vendeur-nom" name="vendeur_nom" type="text" value="<?= $echapper($vendeur['vendeur_nom'] ?? '') ?>" maxlength="150" autocomplete="organization" required>
                    </div>
                    <div>
                        <label for="vendeur-identifiant">Identifiant légal / NINEA</label>
                        <input id="vendeur-identifiant" name="vendeur_identifiant" type="text" value="<?= $echapper($vendeur['vendeur_identifiant'] ?? '') ?>" maxlength="100" autocomplete="off">
                    </div>
                    <div class="parametres-facturation-champs__large">
                        <label for="vendeur-adresse">Adresse professionnelle</label>
                        <input id="vendeur-adresse" name="vendeur_adresse" type="text" value="<?= $echapper($vendeur['vendeur_adresse'] ?? '') ?>" maxlength="255" autocomplete="street-address">
                    </div>
                    <div>
                        <label for="vendeur-telephone">Téléphone professionnel</label>
                        <input id="vendeur-telephone" name="vendeur_telephone" type="tel" value="<?= $echapper($vendeur['vendeur_telephone'] ?? '') ?>" maxlength="30" autocomplete="tel">
                    </div>
                    <div>
                        <label for="vendeur-email">E-mail professionnel</label>
                        <input id="vendeur-email" name="vendeur_email" type="email" value="<?= $echapper($vendeur['vendeur_email'] ?? '') ?>" maxlength="150" autocomplete="email">
                    </div>
                </div>
            </section>
            <div class="parametres-actions">
                <p>Utilisées sur les nouvelles factures uniquement.</p>
                <button type="submit" class="parametres-enregistrer">Enregistrer les coordonnées</button>
            </div>
        </form>

        <form method="POST" class="parametres-form">
            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_parametres']) ?>">
            <input type="hidden" name="action" value="configuration_email_google">
            <section class="admin-panneau parametres-section" aria-labelledby="parametres-email-google-titre">
                <header class="parametres-section__entete">
                    <div class="parametres-section__numero">06</div>
                    <div><h2 id="parametres-email-google-titre">Messagerie Google</h2><p>Configurez le compte Gmail utilisé pour les e-mails ALLÔ PRO, y compris l’envoi des factures.</p></div>
                </header>
                <div class="parametres-facturation-champs">
                    <div>
                        <label for="compte-google">Adresse Gmail</label>
                        <input id="compte-google" name="compte_google" type="email" value="<?= $echapper($configurationEmailGoogle['compte_google']) ?>" maxlength="254" autocomplete="username" placeholder="exemple@gmail.com" required>
                    </div>
                    <div>
                        <label for="mot-de-passe-application-google">Mot de passe d’application Google</label>
                        <input id="mot-de-passe-application-google" name="mot_de_passe_application_google" type="password" maxlength="19" autocomplete="new-password" placeholder="<?= $configurationEmailGoogle['configure'] ? 'Laisser vide pour conserver l’actuel' : '16 caractères fournis par Google' ?>" <?= $configurationEmailGoogle['configure'] ? '' : 'required' ?>>
                    </div>
                    <div class="parametres-facturation-champs__large">
                        <p class="parametres-option__texte">
                            <?php if ($configurationEmailGoogle['configure']): ?>
                                Compte enregistré : <strong><?= $echapper($configurationEmailGoogle['compte_google']) ?></strong>. Le mot de passe n’est jamais affiché ; laissez le champ vide pour le conserver.
                            <?php else: ?>
                                Aucun compte Gmail enregistré. La clé de chiffrement sera créée automatiquement lors du premier enregistrement.
                            <?php endif; ?>
                            Utilisez un mot de passe d’application Google, jamais le mot de passe de connexion au compte.
                        </p>
                    </div>
                </div>
            </section>
            <div class="parametres-actions">
                <p>L’adresse et le mot de passe d’application sont chiffrés ; la clé est conservée dans le stockage privé du serveur. En cas de plusieurs serveurs, partagez ce fichier de clé entre eux.</p>
                <button type="submit" class="parametres-enregistrer">Enregistrer le compte Gmail</button>
            </div>
        </form>

    </main>
</div>
<script>
document.getElementById('attribution-automatique').addEventListener('change', function () {
    document.querySelector('.parametres-switch__etat').textContent = this.checked ? 'Activée' : 'Désactivée';
});
document.querySelectorAll('[data-algorithme-switch]').forEach(function (toggle) {
    toggle.addEventListener('change', function () {
        var etat = this.parentElement.querySelector('.parametres-switch__etat');
        if (etat) etat.textContent = this.checked ? 'Activé' : 'Désactivé';
    });
});
</script>
</body>
</html>