<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('abonnements');
require_once __DIR__ . '/../../models/Abonnement.php';

$abonnementModel = new Abonnement();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['creer_pass'])) {
        $abonnementModel->creerPassType(trim($_POST['nom_pass']), $_POST['prix_pass'], $_POST['categorie_pass'] ?: null);
    } elseif (isset($_POST['toggle_pass_id'])) {
        $stmt = $abonnementModel->getPassTypes();
        foreach ($stmt as $pt) {
            if ($pt['id'] == $_POST['toggle_pass_id']) {
                $abonnementModel->changerStatutPassType($_POST['toggle_pass_id'], $pt['statut'] === 'actif' ? 'inactif' : 'actif');
                break;
            }
        }
    }
    header("Location: abonnements.php");
    exit;
}

$formules = $abonnementModel->getFormules();
$abonnementsActifs = $abonnementModel->getAbonnementsActifs();
$repartition = $abonnementModel->compterActifsParFormule();
$passTypes = $abonnementModel->getPassTypes();
$statsPass = $abonnementModel->compterPassVendus();
require_once __DIR__ . '/../../models/Categorie.php';
$categories = (new Categorie())->getSousCategories();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Abonnements & Pass — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .formule-carte { background: var(--admin-carte, white); border: 1px solid var(--admin-bordure); border-radius: 12px; padding: 18px; position: relative; }
        .formule-carte--inactive { opacity: 0.5; }
        .formule-carte__nom { font-family:'Space Grotesk',sans-serif; font-weight: 700; font-size: 15px; margin-bottom: 6px; }
        .formule-carte__prix { font-family:'Space Grotesk',sans-serif; font-weight: 800; font-size: 22px; color: var(--admin-violet); margin-bottom: 4px; }
        .formule-carte__credits { font-size: 12.5px; color: var(--admin-texte-discret); margin-bottom: 10px; }
        .formule-carte__nb-actifs { position:absolute; top:16px; right:16px; font-size:11px; background:var(--admin-fond-accent, #EFEBFD); color:var(--admin-violet); padding:2px 9px; border-radius:20px; font-weight:700; }
        .formules-grille { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 24px; }
        .formule-carte__cats { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 12px; }
        .formule-carte__cat-tag { font-size: 10.5px; background: var(--admin-fond-app); padding: 2px 8px; border-radius: 10px; color: var(--admin-texte-discret); }
        .formule-carte__lien { display: block; text-align: center; padding: 8px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-size: 12.5px; font-weight: 600; color: var(--admin-violet); text-decoration: none; margin-top: 8px; }
        .bouton-ajouter-formule { display: block; border: 2px dashed var(--admin-bordure); border-radius: 12px; text-align: center; padding: 30px 18px; text-decoration: none; color: var(--admin-texte-discret); font-weight: 600; font-size: 13.5px; }
        .bouton-ajouter-formule:hover { border-color: var(--admin-violet); color: var(--admin-violet); }
        .abonnements-layout { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:20px; align-items:start; }
        .abonnements-layout > .admin-panneau { min-width:0; }
        .pass-type-ligne { display:flex; justify-content:space-between; align-items:center; gap:12px; padding:10px 0; border-bottom:1px solid var(--admin-bordure); font-size:13.5px; }
        .pass-type-ligne__nom { min-width:0; overflow-wrap:anywhere; }
        .pass-type-ligne__meta { display:flex; align-items:center; justify-content:flex-end; flex-wrap:wrap; gap:10px; flex:0 0 auto; }
        .pass-type-ligne__form { margin:0; }
        .pass-type-ligne__modifier { display:grid; place-items:center; width:36px; height:36px; border:1px solid var(--admin-bordure); border-radius:8px; background:transparent; color:var(--admin-violet); cursor:pointer; }
        .pass-type-ligne__modifier svg { width:17px; height:17px; }
        .abonnements-table { min-width:0; }
        @media (max-width: 1100px) {
            .formules-grille { grid-template-columns:repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 900px) {
            .abonnements-layout { grid-template-columns:minmax(0, 1fr); gap:14px; }
        }
        @media (max-width: 600px) {
            .admin-kpi-grille { grid-template-columns:repeat(2, minmax(0, 1fr)); gap:8px; }
            .admin-kpi-carte { min-width:0; min-height:82px; padding:11px; }
            .admin-kpi-carte__icone { top:10px; right:10px; width:29px; height:29px; }
            .admin-kpi-carte__icone svg { width:16px; height:16px; }
            .admin-kpi-carte__label { max-width:calc(100% - 28px); font-size:10px; line-height:1.3; }
            .admin-kpi-carte__valeur { max-width:100%; font-size:20px; overflow-wrap:anywhere; }
            .formules-grille { grid-template-columns:minmax(0, 1fr); gap:10px; margin-bottom:18px; }
            .formule-carte { min-width:0; padding:16px; }
            .formule-carte__nb-actifs { top:12px; right:12px; max-width:calc(100% - 24px); }
            .formule-carte__nom { padding-right:72px; overflow-wrap:anywhere; }
            .formule-carte__prix { font-size:21px; }
            .formule-carte__credits { overflow-wrap:anywhere; line-height:1.5; }
            .formule-carte__cat-tag { overflow-wrap:anywhere; }
            .formule-carte__lien { min-height:42px; display:grid; place-items:center; }
            .bouton-ajouter-formule { padding:18px 14px; }
            .abonnements-layout > .admin-panneau { padding:16px; }
            .pass-type-ligne { align-items:flex-start; flex-direction:column; gap:8px; padding:12px 0; }
            .pass-type-ligne__meta { width:100%; justify-content:flex-start; gap:8px; }
            .pass-type-ligne__modifier { margin-left:auto; }
            .abonnements-table-wrap { overflow:visible; }
            .admin-table.abonnements-table, .abonnements-table tbody { display:block; width:100%; }
            .abonnements-table thead { position:absolute; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden; clip:rect(0,0,0,0); white-space:nowrap; border:0; }
            .abonnements-table tbody { display:grid; gap:10px; }
            .abonnements-table tbody tr { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); overflow:hidden; border:1px solid var(--admin-bordure); border-radius:10px; background:var(--admin-carte, #fff); }
            .abonnements-table tbody td { min-width:0; padding:10px; border:0; border-bottom:1px solid var(--admin-bordure); font-size:12px; overflow-wrap:anywhere; }
            .abonnements-table tbody td::before { display:block; margin-bottom:4px; color:var(--admin-texte-discret); font-size:10px; font-weight:600; content:attr(data-label); }
            .abonnements-table tbody tr > td:last-child { border-bottom:0; }
            .abonnements-table tbody tr.abonnements-table__vide { display:block; }
            .abonnements-table tbody tr.abonnements-table__vide td { display:block; }
            .abonnements-table tbody tr.abonnements-table__vide td::before { content:none; }
            .page-abonnements .admin-entete__titre { font-size:20px; }
        }
        @media (max-width: 380px) {
            .admin-contenu { padding-right:12px; padding-left:12px; }
            .admin-kpi-grille { gap:7px; }
            .admin-kpi-carte__label { max-width:none; padding-right:24px; }
            .abonnements-table tbody tr { grid-template-columns:minmax(0, 1fr); }
        }
        :root[data-theme="dark"] .abonnements-table tbody tr { background:var(--admin-carte, #1d202b); }
    </style>
</head>
<body class="page-abonnements">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Abonnements & Pass</div>
                <div class="admin-entete__sous-titre">Modèle plafonné — aucun abonnement illimité</div>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></div><div class="admin-kpi-carte__label">Abonnements actifs</div><div class="admin-kpi-carte__valeur" id="kpi-abonnements"><?= count($abonnementsActifs) ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4 13 21l-10-10V3h8l9.6 10.4Z"/><circle cx="7.5" cy="7.5" r="1"/></svg></div><div class="admin-kpi-carte__label">Pass vendus</div><div class="admin-kpi-carte__valeur" id="kpi-pass"><?= $statsPass['total'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M16 8.5c-.8-.8-1.8-1.2-3.2-1.2-1.6 0-2.8.8-2.8 2s1.1 1.8 3 2.2 3 1 3 2.3-1.2 2.2-3 2.2c-1.4 0-2.7-.5-3.6-1.5M12 5.5v13"/></svg></div><div class="admin-kpi-carte__label">Revenus Pass</div><div class="admin-kpi-carte__valeur" id="kpi-revenus"><?= number_format($statsPass['montant'], 0, ',', ' ') ?> F</div></div>
        </div>

        <div class="admin-panneau__titre" style="margin-bottom:14px;">Formules d'abonnement</div>
        <div class="formules-grille">
            <?php foreach ($formules as $f):
                $nbActifs = 0;
                foreach ($repartition as $r) { if ($r['nom'] === $f['nom']) $nbActifs = $r['total']; }
                $catsEligibles = $abonnementModel->getCategoriesEligibles($f['id']);
            ?>
            <div class="formule-carte <?= $f['statut'] === 'inactive' ? 'formule-carte--inactive' : '' ?>">
                <span class="formule-carte__nb-actifs"><?= $nbActifs ?> actif(s)</span>
                <div class="formule-carte__nom"><?= htmlspecialchars($f['nom']) ?></div>
                <div class="formule-carte__prix"><?= number_format($f['prix'], 0, ',', ' ') ?> F<span style="font-size:12px; color:var(--admin-texte-discret); font-weight:400;">/mois</span></div>
                <div class="formule-carte__credits"><?= $f['nombre_credits'] ?> crédit(s) — <?= htmlspecialchars($f['description']) ?></div>

                <div class="formule-carte__cats">
                    <?php if (empty($catsEligibles)): ?>
                        <span class="formule-carte__cat-tag">Toutes catégories</span>
                    <?php else: ?>
                        <?php foreach ($catsEligibles as $c): ?>
                            <span class="formule-carte__cat-tag"><?= htmlspecialchars($c['nom']) ?></span>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <a href="formule-detail.php?id=<?= $f['id'] ?>" class="formule-carte__lien">Modifier la formule</a>
            </div>
            <?php endforeach; ?>

            <a href="formule-detail.php" class="bouton-ajouter-formule">+ Créer une nouvelle formule</a>
        </div>

        <div class="abonnements-layout">
            <div class="admin-panneau">
                <div class="admin-panneau__titre">Types de Pass Intervention</div>
                <?php foreach ($passTypes as $pt): ?>
                    <div class="pass-type-ligne">
                        <span class="pass-type-ligne__nom"><?= htmlspecialchars($pt['nom']) ?> <span style="color:var(--admin-texte-discret); font-size:12px;">(<?= htmlspecialchars($pt['categorie_nom'] ?? 'Toutes catégories') ?>)</span></span>
                        <span class="pass-type-ligne__meta">
                            <strong><?= number_format($pt['prix'], 0, ',', ' ') ?> F</strong>
                            <span class="admin-badge admin-badge--<?= $pt['statut'] === 'actif' ? 'vert' : 'gris' ?>"><?= $pt['statut'] ?></span>
                            <form method="POST" class="pass-type-ligne__form"><input type="hidden" name="toggle_pass_id" value="<?= $pt['id'] ?>"><button type="submit" class="pass-type-ligne__modifier" aria-label="Modifier le statut de <?= htmlspecialchars($pt['nom'], ENT_QUOTES, 'UTF-8') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg></button></form>
                        </span>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($passTypes)): ?><p style="font-size:13px; color:var(--admin-texte-discret);">Aucun Pass créé.</p><?php endif; ?>

                <form method="POST" style="margin-top:16px; padding-top:16px; border-top:1px solid var(--admin-bordure);">
                    <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret); display:block; margin-bottom:4px;">Nom du Pass</label>
                    <input type="text" name="nom_pass" placeholder="ex : Pass Intervention Habitat" required style="width:100%; padding:9px 12px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:10px;">
                    <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret); display:block; margin-bottom:4px;">Catégorie liée (optionnel)</label>
                    <select name="categorie_pass" style="width:100%; padding:9px 12px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:10px;">
                        <option value="">Toutes catégories</option>
                        <?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['parent_nom'] . ' — ' . $c['nom']) ?></option><?php endforeach; ?>
                    </select>
                    <label style="font-size:12px; font-weight:600; color:var(--admin-texte-discret); display:block; margin-bottom:4px;">Prix (FCFA)</label>
                    <input type="number" name="prix_pass" step="500" required style="width:100%; padding:9px 12px; border:1px solid var(--admin-bordure); border-radius:6px; margin-bottom:12px;">
                    <button type="submit" name="creer_pass" value="1" style="width:100%; padding:10px; background:var(--admin-violet); color:white; border:none; border-radius:6px; font-weight:700; cursor:pointer;">Créer le Pass</button>
                </form>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Abonnements actifs</div>
                <div class="abonnements-table-wrap">
                <table class="admin-table abonnements-table">
                    <thead><tr><th scope="col">Client</th><th scope="col">Formule</th><th scope="col">Crédits restants</th><th scope="col">Expire le</th></tr></thead>
                    <tbody>
                    <?php if (empty($abonnementsActifs)): ?>
                        <tr class="abonnements-table__vide"><td colspan="4" style="text-align:center; color:var(--admin-texte-discret); padding:20px;">Aucun abonnement actif.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($abonnementsActifs as $a): ?>
                    <tr>
                        <td data-label="Client"><?= htmlspecialchars($a['client_nom']) ?></td>
                        <td data-label="Formule"><?= htmlspecialchars($a['formule_nom']) ?></td>
                        <td data-label="Crédits restants"><span class="admin-badge admin-badge--<?= $a['credits_restants'] > 0 ? 'vert' : 'rouge' ?>"><?= $a['credits_restants'] ?>/<?= $a['nombre_credits'] ?></span></td>
                        <td data-label="Expire le"><?= date('d/m/Y', strtotime($a['date_fin'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
(function() {
    const elAbonnements = document.getElementById('kpi-abonnements');
    const elPass = document.getElementById('kpi-pass');
    const elRevenus = document.getElementById('kpi-revenus');

    function formaterFCFA(n) {
        return Math.round(n).toLocaleString('fr-FR').replace(/\u202f|\u00a0/g, ' ') + ' F';
    }

    function mettreAJour(element, nouvelleValeur) {
        if (element.textContent.trim() === String(nouvelleValeur)) return;
        element.textContent = nouvelleValeur;
        element.classList.remove('kpi-flash');
        void element.offsetWidth; // relance l'animation même si elle vient de jouer
        element.classList.add('kpi-flash');
    }

    async function actualiser() {
        if (document.hidden) return; // inutile d'interroger le serveur si l'onglet n'est pas visible
        try {
            const res = await fetch('/allopro/public/api-stats-abonnements.php');
            if (!res.ok) return;
            const data = await res.json();
            mettreAJour(elAbonnements, data.abonnements_actifs);
            mettreAJour(elPass, data.pass_vendus);
            mettreAJour(elRevenus, formaterFCFA(data.revenus_pass));
        } catch (e) { /* silencieux : on retente au prochain cycle */ }
    }

    setInterval(actualiser, 5000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) actualiser(); });
})();
</script>
</body>
</html>