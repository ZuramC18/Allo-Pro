<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('interventions');
$rolePageCreneaux = 'admin';
require __DIR__ . '/../commun/ajustements-creneaux.php';
