<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
$roleContrats = $_SESSION['role'] ?? '';
$estFinanceContrats = $roleContrats === 'finance';
verifierAcces($estFinanceContrats ? 'devis_entreprises' : 'parametres');
require_once __DIR__ . '/../../models/FactureContratB2B.php';

$paiementId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($paiementId === false) {
    http_response_code(404);
    exit('Facture introuvable.');
}
$facture = (new FactureContratB2B())->getFichierPourPaiement((int) $paiementId, (int) $_SESSION['user_id']);
if (!$facture) {
    http_response_code(404);
    exit('Le PDF de cette facture est indisponible.');
}
$taille = filesize($facture['chemin_absolu']);
if ($taille === false) {
    http_response_code(404);
    exit('Le PDF de cette facture est indisponible.');
}

header('Content-Type: application/pdf');
header('Content-Length: ' . (string) $taille);
header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $facture['numero']) . '.pdf"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($facture['chemin_absolu']);
exit;
