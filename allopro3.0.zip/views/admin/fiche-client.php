<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['admin']);
verifierAcces('clients');
require __DIR__ . '/../../includes/fiche-client-equipe.php';
