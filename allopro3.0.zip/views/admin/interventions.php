<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('interventions');
require_once __DIR__ . '/../../models/Demande.php';

$demandeModel = new Demande();
$recherche = trim($_GET['q'] ?? '');
$statutFiltre = $_GET['statut'] ?? '';
$urgenceFiltre = $_GET['urgence'] ?? '';

$demandes = $demandeModel->getAllAvecFiltres($recherche ?: null, $statutFiltre ?: null, $urgenceFiltre ?: null);
$compteurs = $demandeModel->compterParStatutGlobal();

$labelsStatuts = ['nouvelle' => ['Nouvelle', 'violet'], 'attribuee' => ['Attribuée', 'amber'], 'en_cours' => ['En cours', 'amber'], 'terminee' => ['Terminée', 'vert'], 'annulee' => ['Annulée', 'gris']];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Interventions — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <style>
        .interventions-table-wrapper { max-width: 100%; overflow-x: auto; overscroll-behavior-x: contain; }
        .interventions-table-wrapper .admin-table { min-width: 960px; }
        .interventions-table-wrapper:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: 2px; }
        .interventions-table-wrapper tbody tr[data-href] { cursor: pointer; }
        .admin-app .interventions-table-wrapper .admin-table tbody tr[data-href]:hover { background-color: color-mix(in srgb, var(--admin-violet) 6%, var(--admin-carte)); }
        .interventions-table-wrapper tbody tr[data-href]:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: -2px; }
        .interventions-icone { display: block; width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
        @media (max-width: 600px) {
            .admin-interventions { overflow-x: hidden; }
            .admin-interventions .admin-recherche {
                flex-wrap: wrap;
                gap: 8px;
                margin-bottom: 16px;
            }
            .admin-interventions .admin-recherche input {
                flex: 1 1 100%;
                width: 100%;
                max-width: none;
                min-width: 0;
            }
            .admin-interventions .admin-recherche select {
                flex: 1 1 calc(50% - 4px);
                min-width: 0;
                padding: 10px 8px !important;
                font-size: 12px !important;
            }
            .admin-interventions .admin-recherche button {
                flex: 1 1 auto;
                padding: 10px 14px;
            }
            .admin-interventions .admin-recherche__reset { padding: 8px 0; }
            .admin-interventions .admin-kpi-grille { margin-bottom: 18px; }
            .admin-interventions .admin-panneau { min-width: 0; padding: 14px; }
            .interventions-table-wrapper .admin-table { min-width: 960px; }
            .interventions-table-wrapper .admin-table th,
            .interventions-table-wrapper .admin-table td { padding: 10px; font-size: 12px; }
        }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu admin-interventions">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Interventions</div>
                <div class="admin-entete__sous-titre">Vue d'ensemble de tous les dossiers</div>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg class="interventions-icone" viewBox="0 0 24 24"><path d="M8 4h8l3 3v13H5V4h3Z"/><path d="M8 4v5h8V4M8 13h8M8 17h5"/></svg></div><div class="admin-kpi-carte__label">Total</div><div class="admin-kpi-carte__valeur"><?= $compteurs['toutes'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg class="interventions-icone" viewBox="0 0 24 24"><path d="M12 3v18M3 12h18"/></svg></div><div class="admin-kpi-carte__label">Nouvelles</div><div class="admin-kpi-carte__valeur"><?= $compteurs['nouvelle'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg class="interventions-icone" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div><div class="admin-kpi-carte__label">En cours</div><div class="admin-kpi-carte__valeur"><?= $compteurs['attribuee'] + $compteurs['en_cours'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg class="interventions-icone" viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg></div><div class="admin-kpi-carte__label">Terminées</div><div class="admin-kpi-carte__valeur"><?= $compteurs['terminee'] ?></div></div>
        </div>

        <form method="GET" class="admin-recherche">
            <input type="text" name="q" placeholder="Numéro de dossier ou nom du client..." value="<?= htmlspecialchars($recherche) ?>">
            <select name="statut" onchange="this.form.submit()" style="padding:10px 14px; border:1px solid var(--admin-bordure); border-radius:8px; font-size:14px;">
                <option value="">Tous les statuts</option>
                <?php foreach ($labelsStatuts as $val => $l): ?>
                    <option value="<?= $val ?>" <?= $statutFiltre === $val ? 'selected' : '' ?>><?= $l[0] ?></option>
                <?php endforeach; ?>
            </select>
            <select name="urgence" onchange="this.form.submit()" style="padding:10px 14px; border:1px solid var(--admin-bordure); border-radius:8px; font-size:14px;">
                <option value="">Urgence : toutes</option>
                <option value="urgente" <?= $urgenceFiltre === 'urgente' ? 'selected' : '' ?>>Urgente</option>
                <option value="normale" <?= $urgenceFiltre === 'normale' ? 'selected' : '' ?>>Normale</option>
            </select>
            <button type="submit">Filtrer</button>
            <?php if ($recherche || $statutFiltre || $urgenceFiltre): ?><a href="interventions.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau">
            <div class="interventions-table-wrapper" role="region" aria-label="Liste des interventions" tabindex="0">
                <table class="admin-table">
                    <thead>
                        <tr><th>Dossier</th><th>Client</th><th>Catégorie</th><th>Partenaire</th><th>Technicien</th><th>Urgence</th><th>Statut</th><th>Date</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($demandes)): ?>
                            <tr><td colspan="8" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun résultat.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($demandes as $d): $s = $labelsStatuts[$d['statut']] ?? ['—','gris']; ?>
                        <tr tabindex="0"
                            aria-label="Ouvrir le dossier <?= htmlspecialchars($d['numero_dossier'], ENT_QUOTES, 'UTF-8') ?> de <?= htmlspecialchars($d['client_nom'], ENT_QUOTES, 'UTF-8') ?>"
                            data-href="traiter-demande.php?id=<?= (int) $d['id'] ?>">
                            <td><strong><?= htmlspecialchars($d['numero_dossier']) ?></strong><?php if (!empty($d['est_demande_entreprise'])): ?><span class="badge-demande-entreprise" title="<?= htmlspecialchars($d['entreprise_b2b_nom'] ?? '', ENT_QUOTES, 'UTF-8') ?>">Demande venant d’une entreprise</span><?php endif; ?></td>
                            <td><?= htmlspecialchars($d['client_nom']) ?></td>
                            <td><?= htmlspecialchars($d['categorie_nom']) ?></td>
                            <td><?= htmlspecialchars($d['nom_entreprise'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($d['technicien_nom'] ?? '—') ?></td>
                            <td><span class="admin-badge admin-badge--<?= $d['urgence'] === 'urgente' ? 'rouge' : 'gris' ?>"><?= htmlspecialchars($d['urgence']) ?></span></td>
                            <td><span class="admin-badge admin-badge--<?= $s[1] ?>"><?= $s[0] ?></span></td>
                            <td><?= date('d/m/Y', strtotime($d['date_creation'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelectorAll('.interventions-table-wrapper tbody tr[data-href]').forEach(function (ligne) {
    ligne.addEventListener('click', function () {
        window.location.href = ligne.dataset.href;
    });
    ligne.addEventListener('keydown', function (event) {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault();
        window.location.href = ligne.dataset.href;
    });
});
</script>
</body>
</html>