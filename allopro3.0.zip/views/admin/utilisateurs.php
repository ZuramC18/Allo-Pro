<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('equipe');
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$userModel = new User();
$moiId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $flash = null;

    if ($action === 'creer') {
        $nom = trim($_POST['nom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $motDePasse = $_POST['mot_de_passe'] ?? '';
        $role = $_POST['role'] ?? '';

        if ($nom === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $flash = ['erreur', "Nom et email valides obligatoires."];
        } elseif (!in_array($role, ROLES_INTERNES, true)) {
            $flash = ['erreur', "Rôle invalide."];
        } elseif (strlen($motDePasse) < 8) {
            $flash = ['erreur', "Le mot de passe doit contenir au moins 8 caractères."];
        } elseif ($userModel->findByEmail($email)) {
            $flash = ['erreur', "Cet email est déjà utilisé."];
        } else {
            $nouvelId = $userModel->create($prenom, $nom, $email, $motDePasse, $telephone, $role);
            $nouveau = $userModel->getById($nouvelId);
            journaliser('compte.cree', 'compte', $nouvelId, $nouveau['matricule'], $nom . ' — ' . LIBELLES_ROLES[$role]);
        }
    } else {
        $cibleId = (int) ($_POST['membre_id'] ?? 0);
        $cible = $userModel->getById($cibleId);

        if (!$cible || !in_array($cible['role'], ROLES_INTERNES, true)) {
            $flash = ['erreur', "Membre introuvable."];
        } elseif ($cibleId === $moiId) {
            $flash = ['erreur', "Vous ne pouvez pas modifier votre propre compte depuis cette page."];
        } elseif ($action === 'changer_role' && in_array($_POST['role'] ?? '', ROLES_INTERNES, true)) {
            $userModel->changerRoleMembre($cibleId, $_POST['role']);
            journaliser('compte.role_modifie', 'compte', $cibleId, $cible['matricule'], $cible['nom'] . ' : ' . LIBELLES_ROLES[$cible['role']] . ' → ' . LIBELLES_ROLES[$_POST['role']]);
            $flash = ['succes', "{$cible['nom']} est maintenant : " . LIBELLES_ROLES[$_POST['role']] . "."];
        } elseif ($action === 'changer_statut' && in_array($_POST['statut'] ?? '', ['actif', 'suspendu'], true)) {
            $userModel->changerStatutMembre($cibleId, $_POST['statut']);
            journaliser($_POST['statut'] === 'suspendu' ? 'compte.suspendu' : 'compte.reactive', 'compte', $cibleId, $cible['matricule'], $cible['nom']);
            $flash = ['succes', $_POST['statut'] === 'suspendu' ? "{$cible['nom']} a été suspendu(e)." : "{$cible['nom']} a été réactivé(e)."];
        } elseif ($action === 'reset_mdp') {
            $temporaire = bin2hex(random_bytes(5));
            journaliser('compte.mdp_reinitialise', 'compte', $cibleId, $cible['matricule'], $cible['nom']);
            $userModel->reinitialiserMotDePasse($cibleId, $temporaire);
            $flash = ['mdp', $cible['nom'], $temporaire];
        }
    }

    $_SESSION['flash_equipe'] = $flash;
    header("Location: utilisateurs.php");
    exit;
}

$flash = $_SESSION['flash_equipe'] ?? null;
unset($_SESSION['flash_equipe']);

$recherche = trim($_GET['q'] ?? '');
$roleFiltre = in_array($_GET['role'] ?? '', ROLES_INTERNES, true) ? $_GET['role'] : '';
$membres = $userModel->getEquipe($recherche ?: null, $roleFiltre ?: null);
$stats = $userModel->compterEquipe();
$filtresActifs = $recherche || $roleFiltre;
$couleursRoles = ['admin' => 'violet', 'coordinateur' => 'amber', 'qualite' => 'rouge', 'finance' => 'vert', 'conseiller' => 'gris'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Équipe ALLÔ PRO — Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .select-filtre { padding: 10px 14px; border: 1px solid var(--admin-bordure); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 14px; background: white; }
        .membre-cellule { display: flex; align-items: center; gap: 10px; }
        .membre-avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--admin-violet); color: white; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; flex-shrink: 0; overflow: hidden; }
        .membre-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .membre-avatar svg { width: 19px; height: 19px; fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.7; }
        .membre-avatar--autre { background: #1D5670; }
        .membre-suspendu { opacity: 0.55; }
        .select-role { padding: 5px 8px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-size: 12.5px; font-family: 'Inter', sans-serif; background: white; }
        .lien-action { border: none; background: none; cursor: pointer; font-size: 12.5px; font-weight: 600; padding: 3px 0; font-family: 'Inter', sans-serif; }
        .lien-action--rouge { color: var(--admin-rouge); }
        .lien-action--vert { color: var(--admin-vert); }
        .lien-action--violet { color: var(--admin-violet); }
        .actions-cellule { display: flex; flex-direction: column; align-items: flex-start; gap: 2px; }
        .flash { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; }
        .flash--succes { background: #E6F7ED; color: var(--admin-vert); }
        .flash--erreur { background: #FDECEC; color: var(--admin-rouge); }
        .flash--mdp { background: #FEF3E2; color: #92400E; border: 1px solid #F5D9A8; }
        .flash__mdp-code { display: inline-block; margin: 6px 0; padding: 6px 12px; background: white; border-radius: 6px; font-family: monospace; font-size: 16px; font-weight: 700; letter-spacing: 0.05em; color: var(--admin-texte); user-select: all; }
        .champ-equipe { margin-bottom: 12px; }
        .champ-equipe label { display: block; font-size: 12px; font-weight: 600; color: var(--admin-texte-discret); margin-bottom: 4px; }
        .champ-equipe input, .champ-equipe select { width: 100%; padding: 9px 12px; border: 1px solid var(--admin-bordure); border-radius: 6px; font-family: 'Inter', sans-serif; font-size: 13.5px; }
        .legende-roles { font-size: 12px; color: var(--admin-texte-discret); line-height: 1.6; margin-bottom: 14px; }
        .equipe-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; align-items: start; }
        .equipe-table { min-width: 0; }
        .equipe-table td { vertical-align: middle; }
        @media (max-width: 1100px) {
            .equipe-layout { grid-template-columns: minmax(0, 1fr); }
        }
        @media (max-width: 700px) {
            .equipe-layout { gap: 14px; }
            .equipe-layout > div, .equipe-layout .admin-panneau { min-width: 0; }
            .equipe-table-wrap { overflow: visible; }
            .admin-panneau.equipe-table-wrap { padding: 0; border: 0; background: transparent; box-shadow: none; }
            .admin-table.equipe-table, .equipe-table tbody { display: block; width: 100%; }
            .equipe-table thead { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }
            .equipe-table tbody { display: grid; gap: 10px; }
            .equipe-table tbody tr { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); overflow: hidden; border: 1px solid var(--admin-bordure); border-radius: 12px; background: var(--admin-carte, #fff); }
            .equipe-table tbody tr > td { min-width: 0; padding: 10px; border: 0; border-bottom: 1px solid var(--admin-bordure); font-size: 12px; overflow-wrap: anywhere; }
            .equipe-table tbody tr > td:first-child { grid-column: 1 / -1; padding: 12px; }
            .equipe-table tbody tr > td:not(:first-child)::before { display: block; margin-bottom: 5px; color: var(--admin-texte-discret); font-size: 10px; font-weight: 600; content: attr(data-label); }
            .equipe-table tbody tr > td:last-child { grid-column: 1 / -1; border-bottom: 0; }
            .equipe-table tbody tr.equipe-table__vide { display: block; }
            .membre-cellule { align-items: flex-start; gap: 10px; }
            .membre-cellule > div:last-child { min-width: 0; overflow-wrap: anywhere; }
            .membre-avatar { width: 40px; height: 40px; flex: 0 0 40px; }
            .select-role { max-width: 100%; min-height: 38px; }
            .actions-cellule { flex-direction: row; flex-wrap: wrap; gap: 8px 16px; }
            .actions-cellule form { min-height: 38px; display: flex; align-items: center; }
            .lien-action { min-height: 38px; padding: 7px 0; text-align: left; }
            .equipe-recherche { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 8px; }
            .equipe-recherche input { grid-column: 1 / -1; width: 100%; max-width: none; min-width: 0; }
            .equipe-recherche select { min-width: 0; max-width: 100%; min-height: 42px; padding: 8px; font-size: 12px; }
            .equipe-recherche button { min-height: 42px; padding: 8px 12px; }
            .equipe-recherche .admin-recherche__reset { grid-column: 1 / -1; justify-content: flex-end; min-height: 32px; }
            .admin-entete__titre { font-size: 20px; }
            .admin-kpi-grille { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
            .admin-kpi-carte { min-width: 0; min-height: 78px; padding: 11px; }
            .admin-kpi-carte__label { font-size: 11px; }
        }
        @media (max-width: 380px) {
            .admin-contenu { padding-right: 12px; padding-left: 12px; }
            .equipe-table tbody tr { grid-template-columns: minmax(0, 1fr); }
            .equipe-table tbody tr > td:first-child, .equipe-table tbody tr > td:last-child { grid-column: 1; }
            .equipe-table tbody tr > td:nth-last-child(2) { border-bottom: 1px solid var(--admin-bordure); }
            .equipe-recherche { grid-template-columns: minmax(0, 1fr); }
            .equipe-recherche input, .equipe-recherche select, .equipe-recherche button { grid-column: 1; width: 100%; }
        }
        :root[data-theme="dark"] .equipe-table tbody tr { background: var(--admin-carte, #1d202b); }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Équipe ALLÔ PRO</div>
                <div class="admin-entete__sous-titre">Comptes internes ayant accès au back-office</div>
            </div>
            <a href="roles.php" style="font-size:13px; color:var(--admin-violet); font-weight:600; text-decoration:none;">Configurer les permissions →</a>
        </div>

        <?php if ($flash): ?>
            <?php if ($flash[0] === 'mdp'): ?>
                <div class="flash flash--mdp">
                    Mot de passe temporaire de <strong><?= htmlspecialchars($flash[1]) ?></strong> :<br>
                    <span class="flash__mdp-code"><?= htmlspecialchars($flash[2]) ?></span><br>
                    Il n'est affiché qu'une seule fois. Transmettez-le par un canal sûr.
                </div>
            <?php else: ?>
                <div class="flash flash--<?= $flash[0] ?>"><?= htmlspecialchars($flash[1]) ?></div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></div><div class="admin-kpi-carte__label">Membres</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['total'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 2 11 12"/><path d="M21 2 14.5 22l-4-9.5L1 8.5 21 2Z"/></svg></div><div class="admin-kpi-carte__label">Administrateurs</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['admins'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 13v-2a9 9 0 0 1 18 0v2"/><path d="M5 13H3v4a2 2 0 0 0 2 2h2v-6H5Zm14 0h2v4a2 2 0 0 1-2 2h-2v-6h2Z"/><path d="M17 19a5 5 0 0 1-5 3"/></svg></div><div class="admin-kpi-carte__label">Autres rôles</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['autres'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--rouge"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9 9v6m6-6v6"/></svg></div><div class="admin-kpi-carte__label">Suspendus</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['suspendus'] ?></div></div>
        </div>

        <div class="equipe-layout">
            <div>
                <form method="GET" class="admin-recherche equipe-recherche" style="flex-wrap:wrap;">
                    <input type="text" name="q" placeholder="Nom, email ou téléphone..." value="<?= htmlspecialchars($recherche) ?>">
                    <select name="role" class="select-filtre" onchange="this.form.submit()">
                        <option value="">Tous les rôles</option>
                        <?php foreach (ROLES_INTERNES as $r): ?>
                            <option value="<?= $r ?>" <?= $roleFiltre === $r ? 'selected' : '' ?>><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Rechercher</button>
                    <?php if ($filtresActifs): ?><a href="utilisateurs.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
                </form>

                <div class="admin-panneau equipe-table-wrap">
                    <table class="admin-table equipe-table">
                        <thead><tr><th scope="col">Membre</th><th scope="col">Rôle</th><th scope="col">Activité</th><th scope="col">Statut</th><th scope="col">Actions</th></tr></thead>
                        <tbody>
                        <?php if (empty($membres)): ?>
                            <tr class="equipe-table__vide"><td colspan="5" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun membre trouvé.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($membres as $m):
                            $estMoi = (int) $m['id'] === $moiId;
                            $suspendu = $m['statut'] === 'suspendu';
                            $photoMembre = AvatarProfil::estValide($m['photo_profil'] ?? null, 'equipe')
                                ? (string) $m['photo_profil']
                                : null;
                            $initialesMembre = AvatarProfil::initiales(trim((string) ($m['prenom'] ?? '') . ' ' . (string) ($m['nom'] ?? '')));
                        ?>
                        <tr class="<?= $suspendu ? 'membre-suspendu' : '' ?>">
                            <td data-label="Membre">
                                <div class="membre-cellule">
                                    <div class="membre-avatar <?= $m['role'] !== 'admin' ? 'membre-avatar--autre' : '' ?>">
                                        <?php if (empty($m['avatar_initiales']) && $photoMembre !== null): ?>
                                            <img src="../../public/<?= htmlspecialchars($photoMembre, ENT_QUOTES, 'UTF-8') ?>" alt="">
                                        <?php elseif (!empty($m['avatar_initiales'])): ?>
                                            <?= htmlspecialchars($initialesMembre, ENT_QUOTES, 'UTF-8') ?>
                                        <?php else: ?>
                                            <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <strong><?= htmlspecialchars($m['nom'] ?? '') ?></strong> <strong><?= htmlspecialchars($m['prenom'] ?? '') ?></strong>
                                        <?php if ($estMoi): ?><span class="admin-badge admin-badge--violet" style="margin-left:4px;">Vous</span><?php endif; ?><br>
                                        <span style="color:var(--admin-texte-discret); font-size:12px;"><span class="matricule-badge"><?= htmlspecialchars($m['matricule'] ?? '—') ?></span> · <?= htmlspecialchars($m['email']) ?></span>
                                    </div>
                                </div>
                            </td>
                            <td data-label="Rôle">
                                <?php if ($estMoi): ?>
                                    <span class="admin-badge admin-badge--<?= $couleursRoles[$m['role']] ?? 'gris' ?>"><?= htmlspecialchars(LIBELLES_ROLES[$m['role']] ?? $m['role']) ?></span>
                                <?php else: ?>
                                    <form method="POST" onsubmit="return confirm(<?= htmlspecialchars(json_encode('Changer le rôle de ' . $m['nom'] . ' ?'), ENT_QUOTES) ?>);">
                                        <input type="hidden" name="action" value="changer_role">
                                        <input type="hidden" name="membre_id" value="<?= $m['id'] ?>">
                                        <select name="role" class="select-role" onchange="this.form.requestSubmit()">
                                            <?php foreach (ROLES_INTERNES as $r): ?>
                                                <option value="<?= $r ?>" <?= $m['role'] === $r ? 'selected' : '' ?>><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </form>
                                <?php endif; ?>
                            </td>
                            <td data-label="Activité" style="font-size:12.5px; color:var(--admin-texte-discret);">
                                <?= (int) $m['nb_messages'] ?> message(s)<br><?= (int) $m['nb_notes'] ?> note(s) interne(s)
                            </td>
                            <td data-label="Statut"><span class="admin-badge admin-badge--<?= $suspendu ? 'rouge' : 'vert' ?>"><?= $suspendu ? 'Suspendu' : 'Actif' ?></span></td>
                            <td data-label="Actions">
                                <?php if ($estMoi): ?>
                                    <span style="font-size:12px; color:var(--admin-texte-discret);">—</span>
                                <?php else: ?>
                                    <div class="actions-cellule">
                                        <form method="POST" onsubmit="return confirm(<?= htmlspecialchars(json_encode($suspendu ? "Réactiver ce compte ?" : "Suspendre ce compte ? La personne ne pourra plus se connecter."), ENT_QUOTES) ?>);">
                                            <input type="hidden" name="action" value="changer_statut">
                                            <input type="hidden" name="membre_id" value="<?= $m['id'] ?>">
                                            <input type="hidden" name="statut" value="<?= $suspendu ? 'actif' : 'suspendu' ?>">
                                            <button type="submit" class="lien-action <?= $suspendu ? 'lien-action--vert' : 'lien-action--rouge' ?>"><?= $suspendu ? 'Réactiver' : 'Suspendre' ?></button>
                                        </form>
                                        <form method="POST" onsubmit="return confirm('Générer un nouveau mot de passe temporaire ? L\'ancien ne fonctionnera plus.');">
                                            <input type="hidden" name="action" value="reset_mdp">
                                            <input type="hidden" name="membre_id" value="<?= $m['id'] ?>">
                                            <button type="submit" class="lien-action lien-action--violet">Réinitialiser le mot de passe</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="admin-panneau">
                <div class="admin-panneau__titre">Ajouter un membre</div>
                <p class="legende-roles">
                    <?php foreach (ROLES_INTERNES as $r): ?>
                        <strong><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></strong> : <?= htmlspecialchars(DESCRIPTIONS_ROLES[$r]) ?><br>
                    <?php endforeach; ?>
                </p>
                <form method="POST">
                    <input type="hidden" name="action" value="creer">
                    <div class="champ-equipe"><label>Nom</label><input type="text" name="nom" required></div>
                    <div class="champ-equipe"><label>Prénom</label><input type="text" name="prenom" required></div>
                    <div class="champ-equipe"><label>Email</label><input type="email" name="email" required></div>
                    <div class="champ-equipe"><label>Téléphone</label><input type="tel" name="telephone"></div>
                    <div class="champ-equipe">
                        <label>Rôle</label>
                        <select name="role" required>
                            <?php foreach (ROLES_INTERNES as $r): ?>
                                <option value="<?= $r ?>"><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="champ-equipe"><label>Mot de passe initial (8 caractères min.)</label><input type="password" name="mot_de_passe" minlength="8" required></div>
                    <button type="submit" style="width:100%; padding:11px; background:var(--admin-violet); color:white; border:none; border-radius:8px; font-weight:700; cursor:pointer; margin-top:4px;">Créer le compte</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>