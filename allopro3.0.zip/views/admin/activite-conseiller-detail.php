<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('audit');
require_once __DIR__ . '/../../models/ActiviteConseiller.php';

$userId = filter_var($_GET['user_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$membre = $userId === false ? null : (new ActiviteConseiller())->getMembreEquipe((int) $userId);
if (!$membre) {
    http_response_code(404);
    exit('Membre introuvable.');
}
$date = $_GET['date'] ?? date('Y-m-d');
$dateVerifiee = is_string($date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)
    ? DateTimeImmutable::createFromFormat('!Y-m-d', $date)
    : false;
if (!$dateVerifiee || $dateVerifiee->format('Y-m-d') !== $date) {
    $date = date('Y-m-d');
    $dateVerifiee = new DateTimeImmutable($date);
}
$activiteModel = new ActiviteConseiller();
$debutSemaine = $dateVerifiee->modify('-' . ((int) $dateVerifiee->format('N') - 1) . ' days');
$finSemaine = $debutSemaine->modify('+6 days');
$presenceParJour = $activiteModel->getPresenceParJour(
    (int) $membre['id'],
    $debutSemaine->format('Y-m-d'),
    $finSemaine->format('Y-m-d')
);
$aujourdHui = new DateTimeImmutable('today');
if (
    $aujourdHui >= $debutSemaine
    && $aujourdHui <= $finSemaine
    && in_array($membre['presence_status'], ['online', 'pause'], true)
    && $membre['presence_last_seen']
) {
    $dernierSignal = new DateTimeImmutable($membre['presence_last_seen']);
    $debutPresence = $dernierSignal;
    $debutJour = $aujourdHui;
    if ($debutPresence < $debutJour) {
        $debutPresence = $debutJour;
    }
    $finPresence = new DateTimeImmutable();
    $finMaximale = $dernierSignal->modify('+90 seconds');
    $finJour = $debutJour->modify('+1 day');
    if ($finPresence > $finMaximale) {
        $finPresence = $finMaximale;
    }
    if ($finPresence > $finJour) {
        $finPresence = $finJour;
    }
    if ($finPresence > $debutPresence) {
        $presenceParJour[$aujourdHui->format('Y-m-d')] ??= ['en_ligne' => 0, 'en_pause' => 0];
        $cleDuree = $membre['presence_status'] === 'online' ? 'en_ligne' : 'en_pause';
        $presenceParJour[$aujourdHui->format('Y-m-d')][$cleDuree] += $finPresence->getTimestamp() - $debutPresence->getTimestamp();
    }
}
$libellesPresence = [
    'online' => 'En ligne',
    'pause' => 'En pause',
    'offline' => 'Hors ligne',
    'suspendu' => 'Compte suspendu',
];
$e = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$formaterDuree = static function (int $secondes): string {
    $minutes = intdiv($secondes, 60);
    $reste = $secondes % 60;
    return intdiv($minutes, 60) . ' h ' . str_pad((string) ($minutes % 60), 2, '0', STR_PAD_LEFT) . ' min'
        . ($reste > 0 ? ' ' . $reste . ' s' : '');
};
$jours = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
$mois = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
$joursSemaine = [];
$totalEnLigne = 0;
$totalEnPause = 0;
for ($jour = $debutSemaine; $jour <= $finSemaine; $jour = $jour->modify('+1 day')) {
    $cleJour = $jour->format('Y-m-d');
    $temps = $presenceParJour[$cleJour] ?? ['en_ligne' => 0, 'en_pause' => 0];
    $joursSemaine[] = [
        'date' => $cleJour,
        'libelle' => ucfirst($jours[(int) $jour->format('N') - 1]),
        'date_courte' => $jour->format('d/m'),
        'en_ligne' => $temps['en_ligne'],
        'en_pause' => $temps['en_pause'],
        'total' => $temps['en_ligne'] + $temps['en_pause'],
    ];
    $totalEnLigne += $temps['en_ligne'];
    $totalEnPause += $temps['en_pause'];
}
$totalPresence = $totalEnLigne + $totalEnPause;
$numeroJourDebut = $debutSemaine->format('j') === '1' ? '1er' : $debutSemaine->format('j');
$numeroJourFin = $finSemaine->format('j') === '1' ? '1er' : $finSemaine->format('j');
$jourDebutLisible = $numeroJourDebut . ' ' . $mois[(int) $debutSemaine->format('n')];
$jourFinLisible = $numeroJourFin . ' ' . $mois[(int) $finSemaine->format('n')] . ' ' . $finSemaine->format('Y');
$periodeLisible = (int) $debutSemaine->format('n') === (int) $finSemaine->format('n')
    ? $numeroJourDebut . ' au ' . $jourFinLisible
    : $jourDebutLisible . ' au ' . $jourFinLisible;
$jourLePlusActif = max(array_column($joursSemaine, 'total'));
$statutActuel = $membre['presence_status'];
$urlDate = fn(DateTimeImmutable $jour): string => '?user_id=' . (int) $membre['id'] . '&date=' . $jour->format('Y-m-d');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Calendrier de présence — <?= $e($membre['nom']) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/presence-detail.css?v=<?= filemtime(__DIR__ . '/../../public/css/presence-detail.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu">
        <a class="presence-detail__retour" href="activite-conseillers.php?date=<?= $e($date) ?>"><span aria-hidden="true">←</span> Équipe · Présence</a>
        <header class="presence-detail__entete">
            <div class="presence-detail__avatar" aria-hidden="true"><?= $e(mb_strtoupper(mb_substr($membre['nom'], 0, 1, 'UTF-8'), 'UTF-8')) ?></div>
            <div>
                <div class="presence-detail__surtitre"><?= $e(LIBELLES_ROLES[$membre['role']] ?? $membre['role']) ?> <span aria-hidden="true">·</span> <?= $e($membre['matricule']) ?></div>
                <h1 class="presence-detail__titre"><?= $e($membre['nom']) ?></h1>
            </div>
            <span class="presence-detail__statut presence-detail__statut--<?= $e($statutActuel) ?>"><i aria-hidden="true"></i><?= $e($libellesPresence[$statutActuel] ?? $statutActuel) ?></span>
        </header>

        <section class="presence-detail__jour" aria-label="Sélection de la semaine">
            <div class="presence-detail__jour-titre">
                <span class="presence-detail__jour-label">Activité de la semaine</span>
                <h2>Du <?= $e($periodeLisible) ?></h2>
            </div>
            <nav class="presence-detail__navigation" aria-label="Naviguer entre les semaines">
                <a href="<?= $e($urlDate($dateVerifiee->modify('-7 days'))) ?>" aria-label="Semaine précédente"><span aria-hidden="true">←</span><span class="presence-detail__navigation-texte">Semaine précédente</span></a>
                <form method="get">
                    <input type="hidden" name="user_id" value="<?= (int) $membre['id'] ?>">
                    <label class="presence-detail__date-label" for="presence-date">Choisir une date</label>
                    <input id="presence-date" type="date" name="date" value="<?= $e($date) ?>">
                    <button class="admin-btn admin-btn--primaire" type="submit">Afficher</button>
                </form>
                <a href="<?= $e($urlDate($dateVerifiee->modify('+7 days'))) ?>"><span class="presence-detail__navigation-texte">Semaine suivante</span><span aria-hidden="true">→</span></a>
            </nav>
        </section>

        <section class="presence-detail__resume" aria-label="Résumé de la semaine">
            <article class="presence-detail__stat presence-detail__stat--online">
                <span class="presence-detail__stat-label"><i aria-hidden="true"></i>Temps en ligne</span>
                <strong><?= $e($formaterDuree($totalEnLigne)) ?></strong>
                <span class="presence-detail__stat-note">cumulé sur la semaine</span>
            </article>
            <article class="presence-detail__stat presence-detail__stat--pause">
                <span class="presence-detail__stat-label"><i aria-hidden="true"></i>Temps en pause</span>
                <strong><?= $e($formaterDuree($totalEnPause)) ?></strong>
                <span class="presence-detail__stat-note">cumulé sur la semaine</span>
            </article>
            <article class="presence-detail__stat presence-detail__stat--total">
                <span class="presence-detail__stat-label"><i aria-hidden="true"></i>Présence enregistrée</span>
                <strong><?= $e($formaterDuree($totalPresence)) ?></strong>
                <span class="presence-detail__stat-note">ligne + pauses de la semaine</span>
            </article>
        </section>

        <section class="presence-detail__panneau" aria-labelledby="presence-detail-semaine">
            <div class="presence-detail__section-entete">
                <div>
                    <span class="presence-detail__sur-titre">Vue d’ensemble</span>
                    <h2 id="presence-detail-semaine">Présence par jour</h2>
                </div>
                <div class="presence-detail__legende" aria-label="Légende">
                    <span><i class="presence-detail__couleur presence-detail__couleur--online" aria-hidden="true"></i>En ligne</span>
                    <span><i class="presence-detail__couleur presence-detail__couleur--pause" aria-hidden="true"></i>En pause</span>
                </div>
            </div>
            <?php if ($totalPresence === 0): ?>
                <p class="presence-detail__vide">Aucune présence enregistrée sur cette semaine.</p>
            <?php endif; ?>
            <div class="presence-detail__jours">
                <?php foreach ($joursSemaine as $jourSemaine):
                    $largeurJour = $jourLePlusActif > 0 ? ($jourSemaine['total'] / $jourLePlusActif) * 100 : 0;
                    $partEnLigne = $jourSemaine['total'] > 0 ? ($jourSemaine['en_ligne'] / $jourSemaine['total']) * 100 : 0;
                    $partEnPause = $jourSemaine['total'] > 0 ? ($jourSemaine['en_pause'] / $jourSemaine['total']) * 100 : 0;
                    ?>
                    <article class="presence-detail__jour-ligne" aria-label="<?= $e($jourSemaine['libelle'] . ' ' . $jourSemaine['date_courte']) ?> : <?= $e($formaterDuree($jourSemaine['en_ligne'])) ?> en ligne, <?= $e($formaterDuree($jourSemaine['en_pause'])) ?> en pause">
                        <div class="presence-detail__jour-identite">
                            <strong><?= $e($jourSemaine['libelle']) ?></strong>
                            <span><?= $e($jourSemaine['date_courte']) ?></span>
                        </div>
                        <div class="presence-detail__jour-resultat">
                            <div class="presence-detail__jour-durees">
                                <strong><?= $e($formaterDuree($jourSemaine['total'])) ?></strong>
                                <span><i class="presence-detail__couleur presence-detail__couleur--online" aria-hidden="true"></i><?= $e($formaterDuree($jourSemaine['en_ligne'])) ?></span>
                                <span><i class="presence-detail__couleur presence-detail__couleur--pause" aria-hidden="true"></i><?= $e($formaterDuree($jourSemaine['en_pause'])) ?></span>
                            </div>
                            <div class="presence-detail__barre" aria-hidden="true">
                                <span class="presence-detail__barre-active" style="width: <?= number_format($largeurJour, 2, '.', '') ?>%">
                                    <i class="presence-detail__barre-ligne" style="width: <?= number_format($partEnLigne, 2, '.', '') ?>%"></i>
                                    <i class="presence-detail__barre-pause" style="width: <?= number_format($partEnPause, 2, '.', '') ?>%"></i>
                                </span>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <p class="presence-detail__note">Les barres comparent chaque journée à la journée la plus active de la semaine. Les durées sont estimées à partir des signaux de présence (environ une minute) ; les périodes antérieures à l’installation du suivi ne sont pas disponibles.</p>
        </section>
    </main>
</div>
</body>
</html>
