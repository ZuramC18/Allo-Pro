<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/Parametre.php';
require_once __DIR__ . '/../../models/Reversement.php';

$parametreModel = new Parametre();
$reversementModel = new Reversement();
$peutModifierTaux = peut('parametres');
$erreur = '';

if (empty($_SESSION['csrf_partage_benefices'])) {
    $_SESSION['csrf_partage_benefices'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_partage_benefices'], (string) ($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        $erreur = 'La session a expiré. Rechargez la page puis réessayez.';
    } elseif (!$peutModifierTaux) {
        http_response_code(403);
        $erreur = 'Seul un administrateur peut modifier les taux de partage.';
    } else {
        $tauxPassBrut = str_replace(',', '.', trim((string) ($_POST['taux_commission_pass'] ?? '')));
        $tauxAbonnementBrut = str_replace(',', '.', trim((string) ($_POST['taux_commission_abonnement'] ?? '')));
        $tauxPass = filter_var($tauxPassBrut, FILTER_VALIDATE_FLOAT);
        $tauxAbonnement = filter_var($tauxAbonnementBrut, FILTER_VALIDATE_FLOAT);
        $tauxValide = static function ($taux): bool {
            return $taux !== false && $taux >= 0 && $taux <= 100
                && abs($taux * 2 - round($taux * 2)) < 0.00001;
        };

        if (!$tauxValide($tauxPass) || !$tauxValide($tauxAbonnement)) {
            $erreur = 'Chaque commission doit être comprise entre 0 et 100 %, par pas de 0,5 %.';
        } else {
            $anciensPass = $parametreModel->getTauxCommissionPass();
            $ancienAbonnement = $parametreModel->getTauxCommissionAbonnement();
            $nouveaux = [
                'taux_commission_pass' => number_format((float) $tauxPass, 1, '.', ''),
                'taux_commission_abonnement' => number_format((float) $tauxAbonnement, 1, '.', ''),
            ];

            if ($parametreModel->setMultiple($nouveaux)) {
                if ($anciensPass !== (float) $nouveaux['taux_commission_pass']) {
                    journaliser('parametre.commission_pass_modifiee', 'parametre', null, 'taux_commission_pass', $anciensPass . ' % → ' . $nouveaux['taux_commission_pass'] . ' %');
                }
                if ($ancienAbonnement !== (float) $nouveaux['taux_commission_abonnement']) {
                    journaliser('parametre.commission_abonnement_modifiee', 'parametre', null, 'taux_commission_abonnement', $ancienAbonnement . ' % → ' . $nouveaux['taux_commission_abonnement'] . ' %');
                }
                $_SESSION['flash_partage_benefices'] = 'Les taux de partage ont été enregistrés.';
                header('Location: partage-benefices.php');
                exit;
            }

            $erreur = 'Les taux de partage n’ont pas pu être enregistrés.';
        }
    }
}

$messageSucces = $_SESSION['flash_partage_benefices'] ?? '';
unset($_SESSION['flash_partage_benefices']);
$tauxPass = $parametreModel->getTauxCommissionPass();
$tauxAbonnement = $parametreModel->getTauxCommissionAbonnement();
$reversementsDus = $reversementModel->getReversementsDus();
$totalBrut = array_sum(array_column($reversementsDus, 'montant_brut'));
$totalPartenaires = array_sum(array_column($reversementsDus, 'montant_du'));
$totalAlloPro = $totalBrut - $totalPartenaires;
$nombreInterventions = array_sum(array_column($reversementsDus, 'nb_missions'));
$echapper = static fn($valeur) => htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= ($_SESSION['role'] ?? '') === 'finance' && isset($financeTitrePage) ? htmlspecialchars($financeTitrePage, ENT_QUOTES, 'UTF-8') : 'Partage des bénéfices' ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/partage-benefices.css?v=<?= filemtime(__DIR__ . '/../../public/css/partage-benefices.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <main class="admin-contenu partage-page">
        <header class="admin-entete partage-entete">
            <div>
                <div class="admin-entete__titre"><?= ($_SESSION['role'] ?? '') === 'finance' && isset($financeTitrePage) ? htmlspecialchars($financeTitrePage, ENT_QUOTES, 'UTF-8') : 'Partage des bénéfices' ?></div>
                <p class="admin-entete__sous-titre">Répartition transparente des revenus Pass et abonnements par partenaire.</p>
            </div>
            <a class="partage-lien-retour" href="reversements.php">Historique des reversements <span aria-hidden="true">→</span></a>
        </header>

        <?php if ($messageSucces): ?>
            <div class="partage-alerte partage-alerte--succes" role="status"><?= $echapper($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur): ?>
            <div class="partage-alerte partage-alerte--erreur" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <section class="partage-kpis" aria-label="Résumé des reversements à préparer">
            <article class="partage-kpi">
                <span class="partage-kpi__icone partage-kpi__icone--violet" aria-hidden="true">◈</span>
                <div><span class="partage-kpi__label">Interventions à répartir</span><strong><?= number_format($nombreInterventions, 0, ',', ' ') ?></strong></div>
            </article>
            <article class="partage-kpi">
                <span class="partage-kpi__icone partage-kpi__icone--bleu" aria-hidden="true">↗</span>
                <div><span class="partage-kpi__label">Revenus attribués</span><strong><?= number_format($totalBrut, 0, ',', ' ') ?> F</strong></div>
            </article>
            <article class="partage-kpi">
                <span class="partage-kpi__icone partage-kpi__icone--vert" aria-hidden="true">⌂</span>
                <div><span class="partage-kpi__label">À reverser aux partenaires</span><strong><?= number_format($totalPartenaires, 0, ',', ' ') ?> F</strong></div>
            </article>
            <article class="partage-kpi">
                <span class="partage-kpi__icone partage-kpi__icone--ambre" aria-hidden="true">%</span>
                <div><span class="partage-kpi__label">Commissions ALLÔ PRO</span><strong><?= number_format($totalAlloPro, 0, ',', ' ') ?> F</strong></div>
            </article>
        </section>

        <section class="partage-explication admin-panneau" aria-labelledby="partage-regle-titre">
            <div class="partage-explication__icone" aria-hidden="true">i</div>
            <div>
                <h2 id="partage-regle-titre">Une part calculée sur chaque intervention terminée</h2>
                <p>Le partenaire qui réalise la prestation reçoit le reversement, que l’intervention soit faite par lui-même ou par l’un de ses techniciens. La redistribution aux techniciens est gérée par le partenaire.</p>
                <ul>
                    <li><strong>Pass :</strong> le prix d’achat du pass est attribué à son intervention terminée.</li>
                    <li><strong>Abonnement :</strong> le prix payé est réparti à parts égales entre les crédits inclus; un crédit est attribué au partenaire de chaque intervention terminée.</li>
                    <li><strong>Commission :</strong> le taux propre au produit est retenu par ALLÔ PRO; le solde est versé au partenaire.</li>
                </ul>
                <p class="partage-explication__note">Les montants d’achat et les crédits sont figés au moment de la souscription. Un produit non encore utilisé ne génère pas de reversement partenaire.</p>
            </div>
        </section>

        <?php if ($peutModifierTaux): ?>
            <section class="admin-panneau partage-taux" aria-labelledby="partage-taux-titre">
                <div class="partage-section-entete">
                    <div>
                        <h2 id="partage-taux-titre">Taux de commission ALLÔ PRO</h2>
                        <p>Les nouveaux taux s’appliquent aux prochains reversements, sans recalculer ceux déjà créés.</p>
                    </div>
                    <span class="partage-admin-tag">Réglage administrateur</span>
                </div>
                <form method="POST" class="partage-taux__form">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf_partage_benefices']) ?>">
                    <label class="partage-taux__champ" for="taux-pass">
                        <span>Commission sur les Pass</span>
                        <span class="partage-taux__saisie"><input id="taux-pass" type="number" name="taux_commission_pass" min="0" max="100" step="0.5" value="<?= $echapper(number_format($tauxPass, 1, '.', '')) ?>" required><span>%</span></span>
                    </label>
                    <label class="partage-taux__champ" for="taux-abonnement">
                        <span>Commission sur les abonnements</span>
                        <span class="partage-taux__saisie"><input id="taux-abonnement" type="number" name="taux_commission_abonnement" min="0" max="100" step="0.5" value="<?= $echapper(number_format($tauxAbonnement, 1, '.', '')) ?>" required><span>%</span></span>
                    </label>
                    <button class="partage-bouton" type="submit">Enregistrer les taux</button>
                </form>
            </section>
        <?php else: ?>
            <section class="partage-taux partage-taux--lecture admin-panneau" aria-labelledby="partage-taux-titre">
                <div class="partage-section-entete">
                    <div><h2 id="partage-taux-titre">Taux actuellement appliqués</h2><p>Seul un administrateur peut modifier ces paramètres.</p></div>
                </div>
                <div class="partage-taux__lecture">
                    <span>Pass <strong><?= number_format($tauxPass, 1, ',', ' ') ?> %</strong></span>
                    <span>Abonnements <strong><?= number_format($tauxAbonnement, 1, ',', ' ') ?> %</strong></span>
                </div>
            </section>
        <?php endif; ?>

        <section class="admin-panneau partage-tableau" aria-labelledby="partage-partenaires-titre">
            <div class="partage-section-entete">
                <div>
                    <h2 id="partage-partenaires-titre">Reversements prêts à préparer</h2>
                    <p>Seules les interventions terminées et non encore reversées sont comptabilisées.</p>
                </div>
                <a class="partage-lien-secondaire" href="paiements.php">Voir les paiements</a>
            </div>
            <div class="partage-tableau__scroll">
                <table class="admin-table">
                    <thead>
                        <tr><th>Partenaire</th><th>Interventions</th><th>Base répartie</th><th>Commission ALLÔ PRO</th><th>Montant à reverser</th><th></th></tr>
                    </thead>
                    <tbody>
                    <?php if (!$reversementsDus): ?>
                        <tr><td colspan="6" class="partage-tableau__vide">Aucun partage à préparer pour le moment. Les interventions terminées apparaîtront ici.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($reversementsDus as $reversement): ?>
                        <tr>
                            <td><strong><?= $echapper($reversement['nom_entreprise']) ?></strong></td>
                            <td><?= number_format((int) $reversement['nb_missions'], 0, ',', ' ') ?></td>
                            <td><?= number_format((float) $reversement['montant_brut'], 0, ',', ' ') ?> F</td>
                            <td class="partage-tableau__commission"><?= number_format((float) $reversement['montant_brut'] - (float) $reversement['montant_du'], 0, ',', ' ') ?> F</td>
                            <td class="partage-tableau__montant"><?= number_format((float) $reversement['montant_du'], 0, ',', ' ') ?> F</td>
                            <td><a class="partage-bouton-partenaire" href="creer-reversement.php?partenaire_id=<?= (int) $reversement['id'] ?>">Détail et reversement <span aria-hidden="true">→</span></a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
</body>
</html>
