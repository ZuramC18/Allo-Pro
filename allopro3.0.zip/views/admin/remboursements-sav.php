<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('remboursements_sav');
require_once __DIR__ . '/../../models/TicketSav.php';

$ticketModel = new TicketSav();
$erreur = '';
$csrfKey = 'csrf_remboursements_sav';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}
$statutsAutorises = ['en_attente', 'autorise', 'refuse'];
$statutFiltre = is_string($_GET['statut'] ?? null) && in_array($_GET['statut'], $statutsAutorises, true)
    ? $_GET['statut']
    : '';
$recherche = is_string($_GET['recherche'] ?? null)
    ? trim(mb_substr($_GET['recherche'], 0, 100))
    : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $id = filter_var($_POST['remboursement_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $decision = is_string($_POST['decision'] ?? null) ? $_POST['decision'] : '';
    $commentaire = is_string($_POST['commentaire'] ?? null) ? $_POST['commentaire'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'La session a expiré. Rechargez la page puis réessayez.';
    } elseif ($id === false) {
        $erreur = 'La demande de remboursement sélectionnée est invalide.';
    } else {
        try {
            if (!$ticketModel->deciderRemboursement((int) $id, (int) $_SESSION['user_id'], $decision, $commentaire)) {
                throw new RuntimeException('Cette demande a déjà été traitée ou est introuvable.');
            }
            journaliser('finance.remboursement_sav_' . $decision, 'remboursement_sav', (int) $id, null, $commentaire);
            $retour = array_filter([
                'statut' => $statutFiltre,
                'recherche' => $recherche,
                'decision' => $decision,
            ], static fn($valeur) => $valeur !== '');
            header('Location: remboursements-sav.php?' . http_build_query($retour));
            exit;
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Décision remboursement SAV #' . (int) $id . ' : ' . $exception->getMessage());
            $erreur = 'La décision n’a pas pu être enregistrée. Réessayez.';
        }
    }
}

$parPage = 25;
$totalDemandes = $ticketModel->compterRemboursementsFinance($statutFiltre ?: null, $recherche ?: null);
$nombrePages = max(1, (int) ceil($totalDemandes / $parPage));
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = max(1, min($nombrePages, $page ?: 1));
$decalage = ($page - 1) * $parPage;
$demandes = $ticketModel->getRemboursementsFinance(
    $statutFiltre ?: null,
    $recherche ?: null,
    $parPage,
    $decalage
);
$statistiques = $ticketModel->getStatistiquesRemboursementsFinance();
$filtres = array_filter([
    'statut' => $statutFiltre,
    'recherche' => $recherche,
], static fn($valeur) => $valeur !== '');
$urlPage = static fn(int $numero): string => '?' . http_build_query($filtres + ['page' => $numero]);
$premierResultat = $totalDemandes > 0 ? $decalage + 1 : 0;
$dernierResultat = min($decalage + $parPage, $totalDemandes);
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$libellesStatuts = [
    'en_attente' => ['En attente', 'amber'],
    'autorise' => ['Autorisé', 'vert'],
    'refuse' => ['Refusé', 'rouge'],
];
$roleFinance = ($_SESSION['role'] ?? '') === 'finance';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Remboursements SAV — ALLÔ PRO <?= $roleFinance ? 'Finance' : 'Admin' ?></title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/finance-remboursements.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-remboursements.css') ?>">
</head>
<body class="page-admin-sav page-finance-remboursements">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu finance-remboursements">
        <header class="remboursements-hero">
            <div>
                <span class="remboursements-hero__eyebrow">Décision financière · SAV</span>
                <h1><?= $roleFinance ? 'Remboursements' : 'Autorisations de remboursement SAV' ?></h1>
                <p>Examinez les demandes transmises par Qualité et consignez votre décision.</p>
            </div>
            <aside class="remboursements-hero__notice">
                <span aria-hidden="true">i</span>
                <p>Une autorisation Finance n’exécute pas le remboursement. Elle valide uniquement la demande.</p>
            </aside>
        </header>

        <?php if ($erreur !== ''): ?>
            <div class="remboursements-alerte remboursements-alerte--erreur" role="alert"><?= $e($erreur) ?></div>
        <?php endif; ?>
        <?php if (in_array($_GET['decision'] ?? '', ['autorise', 'refuse'], true)): ?>
            <div class="remboursements-alerte remboursements-alerte--succes" role="status">
                Décision enregistrée : demande <?= $e($_GET['decision'] === 'autorise' ? 'autorisée' : 'refusée') ?>.
            </div>
        <?php endif; ?>

        <section class="remboursements-kpis" aria-label="Résumé des remboursements">
            <a class="remboursement-kpi remboursement-kpi--attente" href="remboursements-sav.php?statut=en_attente">
                <span class="remboursement-kpi__label">En attente de décision</span>
                <strong><?= number_format($statistiques['en_attente']['nombre'], 0, ',', ' ') ?></strong>
                <span class="remboursement-kpi__note"><?= number_format($statistiques['en_attente']['montant'], 0, ',', ' ') ?> F&nbsp;CFA proposés</span>
            </a>
            <a class="remboursement-kpi remboursement-kpi--autorise" href="remboursements-sav.php?statut=autorise">
                <span class="remboursement-kpi__label">Autorisés</span>
                <strong><?= number_format($statistiques['autorise']['nombre'], 0, ',', ' ') ?></strong>
                <span class="remboursement-kpi__note"><?= number_format($statistiques['autorise']['montant'], 0, ',', ' ') ?> F&nbsp;CFA autorisés</span>
            </a>
            <a class="remboursement-kpi remboursement-kpi--refuse" href="remboursements-sav.php?statut=refuse">
                <span class="remboursement-kpi__label">Refusés</span>
                <strong><?= number_format($statistiques['refuse']['nombre'], 0, ',', ' ') ?></strong>
                <span class="remboursement-kpi__note"><?= number_format($statistiques['refuse']['montant'], 0, ',', ' ') ?> F&nbsp;CFA concernés</span>
            </a>
            <a class="remboursement-kpi remboursement-kpi--total" href="remboursements-sav.php">
                <span class="remboursement-kpi__label">Demandes enregistrées</span>
                <strong><?= number_format(array_sum(array_column($statistiques, 'nombre')), 0, ',', ' ') ?></strong>
                <span class="remboursement-kpi__note">Toutes les décisions</span>
            </a>
        </section>

        <section class="remboursements-panel" aria-label="Demandes de remboursement SAV">
            <header class="remboursements-panel__entete">
                <div>
                    <h2><?= $statutFiltre === 'en_attente' ? 'Demandes à traiter' : 'Suivi des demandes' ?></h2>
                    <p><?= number_format($totalDemandes, 0, ',', ' ') ?> résultat<?= $totalDemandes === 1 ? '' : 's' ?><?= $filtres ? ' pour les critères sélectionnés' : '' ?></p>
                </div>
                <span class="remboursements-panel__pagination"><?= number_format($premierResultat, 0, ',', ' ') ?>–<?= number_format($dernierResultat, 0, ',', ' ') ?> / <?= number_format($totalDemandes, 0, ',', ' ') ?></span>
            </header>

            <form class="remboursements-filtres" method="get" role="search">
                <label class="remboursements-filtres__recherche">
                    <span>Rechercher une demande</span>
                    <input type="search" name="recherche" value="<?= $e($recherche) ?>" maxlength="100" placeholder="Dossier, client, demandeur ou motif">
                </label>
                <label>
                    <span>Statut</span>
                    <select name="statut">
                        <option value="">Toutes les demandes</option>
                        <?php foreach ($libellesStatuts as $valeur => [$libelle]): ?>
                            <option value="<?= $e($valeur) ?>" <?= $statutFiltre === $valeur ? 'selected' : '' ?>><?= $e($libelle) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="submit">Filtrer</button>
                <?php if ($filtres): ?><a href="remboursements-sav.php" class="remboursements-filtres__reset">Effacer</a><?php endif; ?>
            </form>

            <?php if (!$demandes): ?>
                <div class="remboursements-vide">
                    <span aria-hidden="true">✓</span>
                    <strong><?= $statutFiltre === 'en_attente' ? 'Aucune demande en attente' : ($filtres ? 'Aucune demande correspondante' : 'Aucune demande de remboursement') ?></strong>
                    <p><?= $statutFiltre === 'en_attente' ? 'Toutes les demandes transmises par Qualité ont été examinées.' : 'Les demandes soumises par Qualité apparaîtront ici.' ?></p>
                    <?php if ($filtres): ?><a href="remboursements-sav.php">Afficher toutes les demandes</a><?php endif; ?>
                </div>
            <?php else: ?>
                <div class="remboursements-liste">
                    <?php foreach ($demandes as $demande):
                        $statut = $libellesStatuts[$demande['statut']] ?? [$demande['statut'], 'gris'];
                        $demandeEnAttente = $demande['statut'] === 'en_attente';
                    ?>
                        <article class="remboursement-carte <?= $demandeEnAttente ? 'remboursement-carte--attente' : '' ?>">
                            <div class="remboursement-carte__entete">
                                <div>
                                    <span class="remboursement-carte__dossier">Dossier <?= $e($demande['numero_dossier']) ?></span>
                                    <h3><?= $e($demande['client_nom']) ?></h3>
                                </div>
                                <span class="admin-badge admin-badge--<?= $e($statut[1]) ?>"><?= $e($statut[0]) ?></span>
                            </div>
                            <div class="remboursement-carte__infos">
                                <div><span>Montant demandé</span><strong><?= number_format((float) $demande['montant_demande'], 0, ',', ' ') ?> F&nbsp;CFA</strong></div>
                                <div><span>Soumis par</span><strong><?= $e($demande['demandeur_nom']) ?></strong><small><?= $e(date('d/m/Y à H:i', strtotime($demande['date_demande']))) ?></small></div>
                                <?php if (!$demandeEnAttente): ?>
                                    <div><span>Décision</span><strong><?= $e($demande['decideur_nom'] ?: 'Utilisateur supprimé') ?></strong><small><?= $demande['date_decision'] ? $e(date('d/m/Y à H:i', strtotime($demande['date_decision']))) : 'Date indisponible' ?></small></div>
                                <?php endif; ?>
                            </div>
                            <details class="remboursement-carte__details">
                                <summary>Motif et dossier SAV</summary>
                                <div class="remboursement-carte__motifs">
                                    <p><strong>Motif de la demande</strong><?= nl2br($e($demande['motif'])) ?></p>
                                    <p><strong>Ticket SAV</strong><?= nl2br($e($demande['motif_sav'])) ?></p>
                                    <?php if (!$demandeEnAttente && trim((string) $demande['commentaire_decision']) !== ''): ?>
                                        <p><strong>Note de décision</strong><?= nl2br($e($demande['commentaire_decision'])) ?></p>
                                    <?php endif; ?>
                                </div>
                            </details>
                            <?php if ($demandeEnAttente): ?>
                                <form method="post" class="remboursement-decision">
                                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                                    <input type="hidden" name="remboursement_id" value="<?= (int) $demande['id'] ?>">
                                    <input type="hidden" name="statut" value="<?= $e($statutFiltre) ?>">
                                    <input type="hidden" name="recherche" value="<?= $e($recherche) ?>">
                                    <label for="commentaire-<?= (int) $demande['id'] ?>">Note de décision <span>(facultative)</span></label>
                                    <textarea id="commentaire-<?= (int) $demande['id'] ?>" name="commentaire" rows="2" maxlength="3000" placeholder="Ajoutez le contexte utile à la traçabilité de la décision…"></textarea>
                                    <div>
                                        <button class="remboursement-decision__autoriser" name="decision" value="autorise" type="submit">Autoriser la demande</button>
                                        <button class="remboursement-decision__refuser" name="decision" value="refuse" type="submit">Refuser</button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($nombrePages > 1): ?>
                <nav class="remboursements-pagination" aria-label="Pagination des demandes">
                    <span>Page <?= $page ?> sur <?= $nombrePages ?></span>
                    <div>
                        <?php if ($page > 1): ?><a href="<?= $e($urlPage($page - 1)) ?>">← Précédente</a><?php endif; ?>
                        <?php if ($page < $nombrePages): ?><a href="<?= $e($urlPage($page + 1)) ?>">Suivante →</a><?php endif; ?>
                    </div>
                </nav>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
