<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('audit');
require_once __DIR__ . '/../../models/ActiviteConseiller.php';

$date = $_GET['date'] ?? date('Y-m-d');
$dateVerifiee = is_string($date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)
    ? DateTimeImmutable::createFromFormat('!Y-m-d', $date)
    : false;
if (!$dateVerifiee || $dateVerifiee->format('Y-m-d') !== $date) {
    $date = date('Y-m-d');
}
$recherche = is_string($_GET['q'] ?? null) ? trim(mb_substr($_GET['q'], 0, 100)) : '';
$activiteModel = new ActiviteConseiller();
$membres = $activiteModel->getMembresEquipe($recherche);
$durees = $activiteModel->getDureesPresence($date, $date);
$libellesPresence = [
    'online' => 'En ligne',
    'pause' => 'En pause',
    'offline' => 'Hors ligne',
    'suspendu' => 'Compte suspendu',
];
$formaterDuree = static function (int $secondes): string {
    $minutes = intdiv($secondes, 60);
    return intdiv($minutes, 60) . ' h ' . str_pad((string) ($minutes % 60), 2, '0', STR_PAD_LEFT) . ' min';
};
$e = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$totalEnLigne = 0;
$totalEnPause = 0;
$nombreEnLigne = 0;
foreach ($membres as &$membre) {
    $id = (int) $membre['id'];
    $temps = $durees[$id] ?? ['en_ligne' => 0, 'en_pause' => 0];
    if ($date === date('Y-m-d') && in_array($membre['presence_status'], ['online', 'pause'], true) && $membre['presence_last_seen']) {
        $debutActuel = new DateTimeImmutable($membre['presence_last_seen']);
        $finActuelle = new DateTimeImmutable();
        $finMaximale = $debutActuel->modify('+90 seconds');
        if ($finActuelle > $finMaximale) {
            $finActuelle = $finMaximale;
        }
        if ($finActuelle > $debutActuel) {
            $cleDuree = $membre['presence_status'] === 'online' ? 'en_ligne' : 'en_pause';
            $temps[$cleDuree] += $finActuelle->getTimestamp() - $debutActuel->getTimestamp();
        }
    }
    $membre['temps_presence'] = $temps;
    $totalEnLigne += $temps['en_ligne'];
    $totalEnPause += $temps['en_pause'];
    if ($membre['presence_status'] === 'online') {
        $nombreEnLigne++;
    }
}
unset($membre);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Présence de l’équipe — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
    <style>
        .activite-equipe__intro { color: var(--admin-texte-discret); margin: -8px 0 20px; }
        .activite-equipe__stats { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; margin-bottom: 18px; }
        .activite-equipe__stat { padding: 16px; border: 1px solid var(--admin-bordure); border-radius: 10px; background: var(--admin-carte); }
        .activite-equipe__stat strong { display: block; font-size: 24px; color: var(--admin-texte); }
        .activite-equipe__stat span { color: var(--admin-texte-discret); font-size: 12px; }
        .activite-equipe__filtres { display: flex; flex-wrap: wrap; align-items: end; gap: 10px; margin-bottom: 18px; }
        .activite-equipe__filtres label { display: grid; gap: 5px; color: var(--admin-texte-discret); font-size: 12px; }
        .activite-equipe__filtres input { min-width: 180px; padding: 9px 11px; border: 1px solid var(--admin-bordure); border-radius: 8px; color: var(--admin-texte); background: var(--admin-carte); font: inherit; }
        .activite-equipe__filtres button { border: 0; border-radius: 8px; padding: 10px 17px; color: #fff; background: #15596b; font: inherit; font-weight: 700; cursor: pointer; }
        .activite-equipe__table-wrap { overflow-x: auto; }
        .activite-equipe__table { width: 100%; border-collapse: collapse; color: var(--admin-texte); }
        .activite-equipe__table th, .activite-equipe__table td { padding: 13px 14px; border-bottom: 1px solid var(--admin-bordure); text-align: left; }
        .activite-equipe__table th { color: var(--admin-texte-discret); font-size: 12px; font-weight: 700; }
        .activite-equipe__table td { font-size: 14px; }
        .activite-equipe__table tbody tr[data-href] { cursor: pointer; }
        .activite-equipe__table tbody tr:hover { background: rgba(21, 89, 107, .06); }
        .activite-equipe__identite { color: var(--admin-texte); font-weight: 700; text-decoration: none; }
        .activite-equipe__identite:hover { color: #15596b; text-decoration: underline; }
        .activite-equipe__identite:focus-visible { outline: 2px solid #15596b; outline-offset: 3px; }
        .activite-equipe__role, .activite-equipe__matricule { display: block; margin-top: 3px; color: var(--admin-texte-discret); font-size: 12px; font-weight: 400; }
        .activite-equipe__presence { display: inline-flex; align-items: center; gap: 7px; white-space: nowrap; font-size: 12px; font-weight: 700; }
        .activite-equipe__point { width: 9px; height: 9px; border-radius: 50%; background: #85949b; }
        .activite-equipe__presence--online .activite-equipe__point { background: #16834a; }
        .activite-equipe__presence--pause .activite-equipe__point { background: #d39120; }
        .activite-equipe__presence--suspendu .activite-equipe__point { background: #c83f3f; }
        .activite-equipe__note { margin: 0 0 15px; padding: 11px 13px; border-radius: 8px; background: rgba(21, 89, 107, .08); color: var(--admin-texte); font-size: 13px; }
        @media (max-width: 650px) {
            .activite-equipe__stats { grid-template-columns: 1fr; }
            .activite-equipe__table th, .activite-equipe__table td { padding: 10px 8px; }
        }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu">
        <header class="admin-entete">
            <div>
                <div class="admin-entete__surtitre">Gestion de l’équipe</div>
                <h1 class="admin-entete__titre">Présence de l’équipe</h1>
            </div>
        </header>
        <p class="activite-equipe__intro">Consultez les statuts et le temps connecté des conseillers, coordinateurs et membres de la finance.</p>

        <form method="get" class="activite-equipe__filtres">
            <label>Rechercher un membre<input type="search" name="q" maxlength="100" value="<?= $e($recherche) ?>" placeholder="Nom ou matricule"></label>
            <label>Journée observée<input type="date" name="date" value="<?= $e($date) ?>"></label>
            <button type="submit">Rechercher</button>
        </form>

        <section class="activite-equipe__stats" aria-label="Résumé de la journée">
            <article class="activite-equipe__stat"><strong><?= $nombreEnLigne ?></strong><span>Membres en ligne actuellement</span></article>
            <article class="activite-equipe__stat"><strong><?= $e($formaterDuree($totalEnLigne)) ?></strong><span>Temps cumulé en ligne le <?= $e(date('d/m/Y', strtotime($date))) ?></span></article>
            <article class="activite-equipe__stat"><strong><?= $e($formaterDuree($totalEnPause)) ?></strong><span>Temps cumulé en pause le <?= $e(date('d/m/Y', strtotime($date))) ?></span></article>
        </section>

        <section class="admin-panneau" aria-labelledby="presence-equipe-titre">
            <div class="admin-panneau__titre" id="presence-equipe-titre">Conseillers, coordination et finance</div>
            <p class="activite-equipe__note">Cliquez sur une ligne pour consulter le récapitulatif hebdomadaire. Les durées sont estimées à partir des signaux de présence et sont suivies depuis l’installation de cette fonctionnalité.</p>
            <div class="activite-equipe__table-wrap">
                <table class="activite-equipe__table">
                    <thead>
                        <tr><th>Membre</th><th>Statut actuel</th><th>En ligne</th><th>En pause</th><th>Dernière activité</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($membres as $membre): ?>
                        <?php
                        $idMembre = (int) $membre['id'];
                        $statutPresence = (string) $membre['presence_status'];
                        $hrefDetail = 'activite-conseiller-detail.php?user_id=' . $idMembre . '&date=' . rawurlencode($date);
                        ?>
                        <tr data-href="<?= $e($hrefDetail) ?>">
                            <td>
                                <a class="activite-equipe__identite" href="<?= $e($hrefDetail) ?>"><?= $e($membre['nom']) ?></a>
                                <span class="activite-equipe__matricule"><?= $e($membre['matricule']) ?></span>
                                <span class="activite-equipe__role"><?= $e(LIBELLES_ROLES[$membre['role']] ?? $membre['role']) ?></span>
                            </td>
                            <td><span class="activite-equipe__presence activite-equipe__presence--<?= $e($statutPresence) ?>"><span class="activite-equipe__point" aria-hidden="true"></span><?= $e($libellesPresence[$statutPresence] ?? $statutPresence) ?></span></td>
                            <td><?= $e($formaterDuree($membre['temps_presence']['en_ligne'])) ?></td>
                            <td><?= $e($formaterDuree($membre['temps_presence']['en_pause'])) ?></td>
                            <td><?php if ($membre['presence_last_seen']): ?><?= $e(date('d/m/Y H:i', strtotime($membre['presence_last_seen']))) ?><?php else: ?>—<?php endif; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$membres): ?><tr><td colspan="5">Aucun membre ne correspond à cette recherche.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
<script>
    document.querySelectorAll('.activite-equipe__table tbody tr[data-href]').forEach((ligne) => {
        ligne.addEventListener('click', (event) => {
            if (event.target.closest('a, button, input, select, textarea, label')) return;
            window.location.href = ligne.dataset.href;
        });
    });
</script>
</body>
</html>
