<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: sav.php"); exit; }

$ticketModel = new TicketSav();
$ticket = $ticketModel->getById($id);
if (!$ticket) { die("Ticket introuvable."); }
$origineLibelles = [
    'client' => 'Client',
    'conseiller' => 'Conseiller',
    'coordinateur' => 'Coordinateur',
    'entreprise' => 'Entreprise',
    'historique' => 'Ancien ticket · origine inconnue',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticketModel->mettreAJour($id, $_POST['statut'], trim($_POST['commentaire_conseiller']));
    journaliser('sav.mis_a_jour', 'ticket_sav', $id, $ticket['numero_dossier'], $ticket['statut'] . ' → ' . $_POST['statut']);
    header("Location: sav.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ticket SAV — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/sav-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/sav-admin.css') ?>">
</head>
<body class="page-admin-sav page-admin-sav-detail">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <main class="admin-contenu">
        <div class="admin-entete sav-detail-entete">
            <div>
                <a href="sav.php" class="sav-detail-retour">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>
                    Retour au SAV
                </a>
                <h1 class="admin-entete__titre">Ticket — <?= htmlspecialchars($ticket['numero_dossier']) ?></h1>
                <?php if (!empty($ticket['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($ticket['entreprise_b2b_nom']) ? ' · ' . htmlspecialchars($ticket['entreprise_b2b_nom'], ENT_QUOTES, 'UTF-8') : '' ?></span><?php endif; ?>
            </div>
            <a href="../conseiller/traiter-demande.php?id=<?= (int) $ticket['demande_id'] ?>" class="sav-detail-dossier">
                Voir le dossier complet
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7M7 7h10v10"/></svg>
            </a>
        </div>

        <div class="sav-detail-grille">
            <section class="admin-panneau sav-detail-panneau" aria-labelledby="sav-detail-infos">
                <header class="sav-detail-panneau__entete">
                    <span class="sav-detail-panneau__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/></svg></span>
                    <h2 id="sav-detail-infos">Détails du ticket</h2>
                </header>
                <dl class="sav-detail-infos">
                    <div class="sav-detail-info">
                        <dt>Client</dt>
                        <dd><?= htmlspecialchars($ticket['client_nom']) ?></dd>
                    </div>
                    <div class="sav-detail-info">
                        <dt>Ticket soumis par</dt>
                        <dd><?= htmlspecialchars($origineLibelles[$ticket['origine'] ?? 'historique'], ENT_QUOTES, 'UTF-8') ?></dd>
                    </div>
                    <div class="sav-detail-info">
                        <dt>Téléphone</dt>
                        <dd><a href="tel:<?= htmlspecialchars(preg_replace('/[^0-9+]/', '', (string) $ticket['client_telephone'])) ?>"><?= htmlspecialchars($ticket['client_telephone']) ?></a></dd>
                    </div>
                    <div class="sav-detail-info sav-detail-info--large">
                        <dt>Problème initial</dt>
                        <dd><?= nl2br(htmlspecialchars($ticket['description'])) ?></dd>
                    </div>
                    <div class="sav-detail-info">
                        <dt>Note laissée</dt>
                        <dd>
                            <?php $note = max(0, min(5, (int) $ticket['note'])); ?>
                            <?php if ($note > 0): ?>
                                <span class="sav-note" role="img" aria-label="<?= $note ?> sur 5"><?php for ($i = 0; $i < $note; $i++): ?><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2 2.9 6 6.6 1-4.8 4.7 1.1 6.6-5.8-3.1-5.8 3.1 1.1-6.6L2.5 9l6.6-1L12 2Z"/></svg><?php endfor; ?></span>
                                <span class="sav-detail-note-valeur"><?= $note ?>/5</span>
                            <?php else: ?>Non notée<?php endif; ?>
                        </dd>
                    </div>
                    <div class="sav-detail-info sav-detail-info--large">
                        <dt>Commentaire client</dt>
                        <dd><?= nl2br(htmlspecialchars($ticket['commentaire'] ?: 'Aucun commentaire laissé.')) ?></dd>
                    </div>
                </dl>
            </section>

            <section class="admin-panneau sav-detail-panneau sav-detail-traitement" aria-labelledby="sav-detail-traitement">
                <header class="sav-detail-panneau__entete">
                    <span class="sav-detail-panneau__icone sav-detail-panneau__icone--traitement" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 5 6v5c0 4.6 2.9 8.2 7 10 4.1-1.8 7-5.4 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/></svg></span>
                    <div><h2 id="sav-detail-traitement">Traitement</h2><p>Mettre à jour le suivi de ce ticket</p></div>
                </header>
                <form method="POST" class="sav-detail-form">
                    <label for="sav-statut">Statut</label>
                    <select name="statut" id="sav-statut">
                        <option value="ouvert" <?= $ticket['statut'] === 'ouvert' ? 'selected' : '' ?>>Ouvert</option>
                        <option value="en_cours" <?= $ticket['statut'] === 'en_cours' ? 'selected' : '' ?>>En cours</option>
                        <option value="resolu" <?= $ticket['statut'] === 'resolu' ? 'selected' : '' ?>>Résolu</option>
                    </select>

                    <label for="sav-commentaire-interne">Notes internes</label>
                    <textarea name="commentaire_conseiller" id="sav-commentaire-interne" rows="6" placeholder="Ajoutez vos notes de suivi pour l’équipe…"><?= htmlspecialchars($ticket['commentaire_conseiller'] ?? '') ?></textarea>

                    <button type="submit" class="sav-detail-enregistrer">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h12l3 3v13H4V4h1Z"/><path d="M8 4v6h8V4M8 20v-7h8v7"/></svg>
                        Enregistrer les modifications
                    </button>
                </form>
            </section>
        </div>
    </main>
</div>
</body>
</html>