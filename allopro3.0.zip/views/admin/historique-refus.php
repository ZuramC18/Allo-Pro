<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['admin']);
verifierAcces('interventions');
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../includes/icones.php';

$interventionModel = new Intervention();
$recherche = $_GET['recherche'] ?? '';
if (!is_string($recherche)) {
    $recherche = '';
}
$recherche = mb_substr(trim($recherche), 0, 100);

$statutFiltre = $_GET['statut'] ?? '';
if (!is_string($statutFiltre) || !in_array($statutFiltre, ['en_attente', 'traitee'], true)) {
    $statutFiltre = '';
}
$rechercheFiltre = $recherche !== '' ? $recherche : null;
$compteursStatut = $interventionModel->compterHistoriqueRefusParStatut($rechercheFiltre);
$totalTousRefus = $interventionModel->compterHistoriqueRefus($rechercheFiltre);
$parPage = 25;
$totalRefus = $interventionModel->compterHistoriqueRefus($rechercheFiltre, $statutFiltre ?: null);
$nombrePages = max(1, (int) ceil($totalRefus / $parPage));
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
$page = max(1, min($nombrePages, $page ?: 1));
$decalage = ($page - 1) * $parPage;
$historique = $interventionModel->getHistoriqueRefus(
    $rechercheFiltre,
    $parPage,
    $decalage,
    $statutFiltre ?: null
);
$premierResultat = $totalRefus > 0 ? $decalage + 1 : 0;
$dernierResultat = min($decalage + $parPage, $totalRefus);
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$urlHistorique = static function (array $parametres = []) use ($recherche, $statutFiltre): string {
    $parametres = array_merge(
        ['recherche' => $recherche, 'statut' => $statutFiltre],
        $parametres
    );
    $query = http_build_query(array_filter(
        $parametres,
        static fn($valeur, $cle): bool => $valeur !== '' && $valeur !== null
            && !($cle === 'page' && (int) $valeur === 1),
        ARRAY_FILTER_USE_BOTH
    ));
    return $query !== '' ? '?' . $query : 'historique-refus.php';
};
$urlPage = static function (int $numero) use ($urlHistorique): string {
    return $urlHistorique(['page' => $numero]);
};
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Historique de refus — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/refus-interventions-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/refus-interventions-admin.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu">
        <section class="refus-admin refus-admin--historique">
            <header class="refus-admin__entete">
                <div>
                    <span class="refus-admin__surtitre">Interventions / suivi</span>
                    <h1>Historique de refus</h1>
                    <p>Suivez les refus d’intervention, leur motif et l’issue de chaque réaffectation.</p>
                </div>
                <a class="refus-admin__retour" href="refus-interventions.php">Refus à réaffecter</a>
            </header>

            <section class="refus-admin__indicateurs" aria-label="Résumé de l’historique">
                <article class="refus-admin__indicateur">
                    <span class="refus-admin__indicateur-icone" aria-hidden="true"><?= icone('file-text', 19) ?></span>
                    <span class="refus-admin__indicateur-label">Refus enregistrés</span>
                    <strong><?= number_format($totalTousRefus, 0, ',', ' ') ?></strong>
                    <span class="refus-admin__indicateur-note"><?= $recherche !== '' ? 'correspondent à la recherche' : 'toutes périodes' ?></span>
                </article>
                <article class="refus-admin__indicateur refus-admin__indicateur--attente">
                    <span class="refus-admin__indicateur-icone" aria-hidden="true"><?= icone('clock', 19) ?></span>
                    <span class="refus-admin__indicateur-label">En attente</span>
                    <strong><?= number_format($compteursStatut['en_attente'], 0, ',', ' ') ?></strong>
                    <span class="refus-admin__indicateur-note">à réaffecter</span>
                </article>
                <article class="refus-admin__indicateur refus-admin__indicateur--traitee">
                    <span class="refus-admin__indicateur-icone" aria-hidden="true"><?= icone('check', 19) ?></span>
                    <span class="refus-admin__indicateur-label">Traités</span>
                    <strong><?= number_format($compteursStatut['traitee'], 0, ',', ' ') ?></strong>
                    <span class="refus-admin__indicateur-note">réaffectation effectuée</span>
                </article>
            </section>

            <form method="GET" class="refus-admin__recherche">
                <label for="recherche-refus">Rechercher dans l’historique</label>
                <div>
                    <input
                        id="recherche-refus"
                        type="search"
                        name="recherche"
                        value="<?= $echapper($recherche) ?>"
                        maxlength="100"
                        placeholder="Dossier, client, technicien, partenaire, lieu ou motif"
                    >
                    <?php if ($statutFiltre !== ''): ?><input type="hidden" name="statut" value="<?= $echapper($statutFiltre) ?>"><?php endif; ?>
                    <button type="submit">Rechercher</button>
                    <?php if ($recherche !== ''): ?><a href="<?= $echapper($urlHistorique(['recherche' => ''])) ?>">Effacer</a><?php endif; ?>
                </div>
            </form>

            <section class="admin-panneau refus-admin__tableau" aria-labelledby="historique-refus-titre">
                <div class="admin-panneau__titre refus-admin__tableau-entete">
                    <div>
                        <span id="historique-refus-titre">Journal des refus</span>
                        <span class="refus-admin__tableau-description">Les refus sont classés du plus récent au plus ancien.</span>
                    </div>
                    <span><?= number_format($premierResultat, 0, ',', ' ') ?>–<?= number_format($dernierResultat, 0, ',', ' ') ?> sur <?= number_format($totalRefus, 0, ',', ' ') ?></span>
                </div>
                <nav class="refus-admin__filtres" aria-label="Filtrer par état">
                    <a href="<?= $echapper($urlHistorique(['statut' => '', 'page' => 1])) ?>" <?= $statutFiltre === '' ? 'aria-current="page"' : '' ?>>
                        Tous <span><?= number_format($totalTousRefus, 0, ',', ' ') ?></span>
                    </a>
                    <a href="<?= $echapper($urlHistorique(['statut' => 'en_attente', 'page' => 1])) ?>" <?= $statutFiltre === 'en_attente' ? 'aria-current="page"' : '' ?>>
                        En attente <span><?= number_format($compteursStatut['en_attente'], 0, ',', ' ') ?></span>
                    </a>
                    <a href="<?= $echapper($urlHistorique(['statut' => 'traitee', 'page' => 1])) ?>" <?= $statutFiltre === 'traitee' ? 'aria-current="page"' : '' ?>>
                        Traités <span><?= number_format($compteursStatut['traitee'], 0, ',', ' ') ?></span>
                    </a>
                </nav>
                <div class="admin-table-wrapper" role="region" aria-label="Historique de refus, défilement horizontal possible" tabindex="0">
                    <table class="admin-table refus-admin__table">
                        <thead>
                        <tr>
                            <th>Date du refus</th>
                            <th>Dossier</th>
                            <th>Client / lieu</th>
                            <th>Priorité</th>
                            <th>Technicien ayant refusé</th>
                            <th>Motif</th>
                            <th>État</th>
                            <th>Réaffectation</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (!$historique): ?>
                            <tr><td colspan="8" class="refus-admin__table-vide">
                                <strong><?= $totalTousRefus === 0
                                    ? ($recherche !== '' ? 'Aucun résultat pour cette recherche' : 'Aucun refus enregistré')
                                    : 'Aucun résultat pour ces filtres' ?></strong>
                                <span><?= $recherche !== '' ? 'Modifiez votre recherche ou effacez-la pour afficher davantage de résultats.' : 'Essayez un autre état ou consultez tous les refus.' ?></span>
                            </td></tr>
                        <?php endif; ?>
                        <?php foreach ($historique as $element): ?>
                            <tr>
                                <td>
                                    <strong><?= $echapper(date('d/m/Y', strtotime($element['date_creation']))) ?></strong>
                                    <span class="refus-admin__cellule-secondaire"><?= $echapper(date('H:i', strtotime($element['date_creation']))) ?></span>
                                </td>
                                <td>
                                    <a class="refus-admin__lien-dossier" href="traiter-demande.php?id=<?= (int) $element['intervention_id'] ?>"><?= $echapper($element['numero_dossier']) ?></a>
                                    <span class="refus-admin__cellule-secondaire"><?= $echapper($element['categorie_nom']) ?></span>
                                </td>
                                <td>
                                    <strong><?= $echapper($element['client_nom']) ?></strong>
                                    <span class="refus-admin__cellule-secondaire"><?= $echapper($element['quartier']) ?>, <?= $echapper($element['ville']) ?></span>
                                    <?php if (!empty($element['est_demande_entreprise'])): ?>
                                        <span class="refus-admin__cellule-secondaire"><?= $echapper($element['site_b2b_nom'] ?: 'Site entreprise') ?><?= !empty($element['entreprise_b2b_nom']) ? ' · ' . $echapper($element['entreprise_b2b_nom']) : '' ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="refus-admin__urgence <?= $element['urgence'] === 'urgente' ? '' : 'refus-admin__urgence--normale' ?>">
                                        <?= $element['urgence'] === 'urgente' ? 'Urgente' : 'Normale' ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?= $echapper($element['technicien_refus_nom']) ?></strong>
                                    <?php if (!empty($element['partenaire_refus_nom'])): ?><span class="refus-admin__cellule-secondaire"><?= $echapper($element['partenaire_refus_nom']) ?></span><?php endif; ?>
                                </td>
                                <td class="refus-admin__motif-cellule"><?= $element['motif'] !== null && $element['motif'] !== '' ? $echapper($element['motif']) : 'Non précisé' ?></td>
                                <td>
                                    <span class="refus-admin__statut <?= $element['statut_file'] === 'traitee' ? 'refus-admin__statut--traitee' : '' ?>">
                                        <?= $element['statut_file'] === 'traitee' ? 'Traité' : 'En attente' ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($element['statut_file'] === 'traitee'): ?>
                                        <strong><?= $echapper($element['technicien_actuel_nom'] ?: 'Technicien non renseigné') ?></strong>
                                        <?php if (!empty($element['acteur_traitement_nom'])): ?><span class="refus-admin__cellule-secondaire">Par <?= $echapper($element['acteur_traitement_nom']) ?></span><?php endif; ?>
                                        <?php if (!empty($element['date_traitement'])): ?><span class="refus-admin__cellule-secondaire"><?= $echapper(date('d/m/Y H:i', strtotime($element['date_traitement']))) ?></span><?php endif; ?>
                                    <?php else: ?>
                                        <span class="refus-admin__cellule-secondaire">À réaffecter</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($nombrePages > 1): ?>
                    <nav class="refus-admin__pagination" aria-label="Pagination de l’historique de refus">
                        <span>Page <?= $page ?> sur <?= $nombrePages ?></span>
                        <div>
                            <?php if ($page > 1): ?><a href="<?= $echapper($urlPage($page - 1)) ?>">← Précédent</a><?php endif; ?>
                            <?php if ($page < $nombrePages): ?><a href="<?= $echapper($urlPage($page + 1)) ?>">Suivant →</a><?php endif; ?>
                        </div>
                    </nav>
                <?php endif; ?>
            </section>
        </section>
    </main>
</div>
</body>
</html>
