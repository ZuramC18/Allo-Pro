<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('techniciens');
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: techniciens.php');
    exit;
}

$technicienModel = new Technicien();
$technicien = $technicienModel->getDetailsAdminById($id);
if (!$technicien) {
    http_response_code(404);
    die('Technicien introuvable.');
}

$missions = $technicienModel->getMissionsRecentesParTechnicien(
    (int) $technicien['id'],
    (int) $technicien['partenaire_id']
);
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$cheminPhoto = (string) ($technicien['photo_profil'] ?? '');
$photoValide = preg_match('#^uploads/techniciens/[a-f0-9]{32}\.(?:jpg|png|webp)$#', $cheminPhoto) === 1;
$afficherPhoto = $photoValide && empty($technicien['avatar_initiales']);
$initiales = AvatarProfil::initiales((string) $technicien['nom']);
$libellesStatuts = [
    'acceptee' => ['Acceptée', 'amber'],
    'en_attente' => ['À confirmer', 'violet'],
    'en_route' => ['En route', 'amber'],
    'arrive' => ['Arrivé', 'amber'],
    'diagnostic' => ['Diagnostic', 'amber'],
    'en_cours' => ['En cours', 'amber'],
    'terminee' => ['Terminée', 'vert'],
    'annulee' => ['Annulée', 'gris'],
    'refusee' => ['Refusée', 'rouge'],
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $echapper($technicien['nom']) ?> — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .technicien-detail { display: grid; grid-template-columns: minmax(0, 320px) minmax(0, 1fr); gap: 20px; min-width: 0; }
        .technicien-detail > * { min-width: 0; }
        .technicien-detail__avatar { display: grid; width: 76px; height: 76px; margin: 0 auto 14px; place-items: center; overflow: hidden; border-radius: 50%; color: #fff; background: var(--admin-violet); font-size: 24px; font-weight: 750; }
        .technicien-detail__avatar img { width: 100%; height: 100%; object-fit: cover; }
        .technicien-detail__avatar svg { width: 34px; height: 34px; fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.7; }
        .technicien-detail__identite { text-align: center; }
        .technicien-detail__nom { overflow-wrap: anywhere; font-family: 'Space Grotesk', sans-serif; font-size: 17px; font-weight: 700; }
        .technicien-detail__matricule { display: block; margin-top: 5px; color: var(--admin-texte-discret); font-size: 12px; }
        .technicien-detail__ligne { display: flex; justify-content: space-between; gap: 12px; padding: 11px 0; border-top: 1px solid var(--admin-bordure); font-size: 13px; text-align: left; }
        .technicien-detail__ligne > span:first-child { flex: 0 0 auto; color: var(--admin-texte-discret); }
        .technicien-detail__ligne > span:last-child { min-width: 0; overflow-wrap: anywhere; text-align: right; }
        .technicien-detail__ligne a { color: var(--admin-violet); text-decoration: none; overflow-wrap: anywhere; }
        .technicien-detail__ligne a:hover { text-decoration: underline; }
        .technicien-detail__partenaire { color: var(--admin-violet); font-weight: 650; text-decoration: none; }
        .technicien-detail__partenaire:hover { text-decoration: underline; }
        .technicien-detail__missions { min-width: 0; }
        .technicien-detail__mission-lien { color: var(--admin-violet); font-weight: 650; text-decoration: none; }
        .technicien-detail__mission-lien:hover { text-decoration: underline; }
        .technicien-detail__mission-lien:focus-visible,
        .technicien-detail__partenaire:focus-visible,
        .technicien-detail__ligne a:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: 3px; border-radius: 3px; }
        .technicien-detail__mission-note { display: block; margin-top: 4px; color: var(--admin-texte-discret); font-size: 11px; }
        @media (max-width: 700px) {
            .technicien-detail { grid-template-columns: minmax(0, 1fr); gap: 0; }
            .technicien-detail > div { min-width: 0; }
            .technicien-detail .admin-panneau { min-width: 0; padding: 16px 14px; }
            .admin-contenu > .admin-kpi-grille { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; margin-bottom: 16px; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte { min-width: 0; min-height: 82px; padding: 11px 9px; border-radius: 11px; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte__icone { display: none; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte__label { margin-bottom: 6px; font-size: 10px; line-height: 1.25; overflow-wrap: anywhere; }
            .admin-contenu > .admin-kpi-grille .admin-kpi-carte__valeur { font-size: 23px; line-height: 1; }
            .technicien-detail__identite { display: grid; grid-template-columns: 58px minmax(0, 1fr); column-gap: 12px; align-items: center; margin-bottom: 14px; text-align: left; }
            .technicien-detail__avatar { grid-row: span 3; width: 58px; height: 58px; margin: 0; font-size: 19px; }
            .technicien-detail__avatar svg { width: 27px; height: 27px; }
            .technicien-detail__nom { align-self: end; font-size: 16px; }
            .technicien-detail__matricule { margin-top: 2px; font-size: 11px; }
            .technicien-detail__identite .admin-badge { justify-self: start; margin: 5px 0 0 !important; }
            .technicien-detail__missions.admin-table { display: block; width: 100%; min-width: 0; }
            .technicien-detail__missions thead { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }
            .technicien-detail__missions tbody { display: grid; gap: 10px; }
            .technicien-detail__missions tbody tr.technicien-detail__mission { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); padding: 8px 10px; border: 1px solid var(--admin-bordure); border-radius: 10px; background: var(--admin-carte, #fff); }
            .technicien-detail__missions tbody tr.technicien-detail__mission td { min-width: 0; padding: 9px 5px; border: 0; font-size: 12px; overflow-wrap: anywhere; }
            .technicien-detail__mission td:first-child,
            .technicien-detail__mission td:last-child { grid-column: 1 / -1; }
            .technicien-detail__mission td:first-child { border-bottom: 1px solid var(--admin-bordure); }
            .technicien-detail__mission td[data-label]::before { display: block; margin-bottom: 4px; color: var(--admin-texte-discret); font-size: 10px; font-weight: 500; content: attr(data-label); }
            .technicien-detail__mission td:last-child { border-top: 1px solid var(--admin-bordure); }
            .technicien-detail__mission-lien--action { display: flex; align-items: center; justify-content: space-between; min-height: 40px; padding: 0 10px; border-radius: 7px; background: rgba(108, 92, 231, .09); }
            .technicien-detail__vide { display: block; padding: 20px 12px !important; text-align: center; }
            :root[data-theme="dark"] .technicien-detail__missions tbody tr.technicien-detail__mission { background: var(--admin-carte, #1d202b); }
        }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <a href="techniciens.php" style="font-size:13px; color:var(--admin-texte-discret); text-decoration:none;">← Retour aux techniciens</a>
                <div class="admin-entete__titre" style="margin-top:6px;"><?= $echapper($technicien['nom']) ?></div>
            </div>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet">
                <div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19V5m0 14h16M8 15l3-4 3 2 5-7"/></svg></div>
                <div class="admin-kpi-carte__label">Missions au total</div>
                <div class="admin-kpi-carte__valeur"><?= (int) $technicien['nb_missions'] ?></div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--vert">
                <div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m5 12 4 4L19 6"/></svg></div>
                <div class="admin-kpi-carte__label">Terminées</div>
                <div class="admin-kpi-carte__valeur"><?= (int) $technicien['nb_terminees'] ?></div>
            </div>
            <div class="admin-kpi-carte admin-kpi-carte--amber">
                <div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div>
                <div class="admin-kpi-carte__label">En cours</div>
                <div class="admin-kpi-carte__valeur"><?= (int) $technicien['nb_en_cours'] ?></div>
            </div>
        </div>

        <div class="technicien-detail">
            <div>
                <section class="admin-panneau" style="text-align:center;" aria-label="Profil du technicien">
                    <div class="technicien-detail__identite">
                        <div class="technicien-detail__avatar" aria-hidden="true">
                            <?php if ($afficherPhoto): ?>
                                <img src="../../public/<?= $echapper($cheminPhoto) ?>" alt="">
                            <?php elseif (!empty($technicien['avatar_initiales'])): ?>
                                <?= $echapper($initiales) ?>
                            <?php else: ?>
                                <svg viewBox="0 0 24 24"><path d="M6 10V8a6 6 0 0 1 12 0v2"/><path d="M4 10h16v2H4z"/><path d="M8 12v2a4 4 0 0 0 8 0v-2"/><path d="M4 21c.5-3.4 3-5 8-5s7.5 1.6 8 5"/></svg>
                            <?php endif; ?>
                        </div>
                        <div class="technicien-detail__nom"><?= $echapper($technicien['nom']) ?></div>
                        <span class="technicien-detail__matricule"><?= $echapper($technicien['matricule'] ?: 'Matricule non attribué') ?></span>
                        <span class="admin-badge admin-badge--<?= $technicien['statut'] === 'actif' ? 'vert' : 'gris' ?>">
                            <?= $technicien['statut'] === 'corbeille' ? 'Corbeille' : ($technicien['statut'] === 'actif' ? 'Actif' : 'Inactif') ?>
                        </span>
                    </div>

                    <div class="technicien-detail__ligne"><span>Téléphone</span><span><?= $technicien['telephone'] ? '<a href="tel:' . $echapper($technicien['telephone']) . '">' . $echapper($technicien['telephone']) . '</a>' : '—' ?></span></div>
                    <div class="technicien-detail__ligne"><span>E-mail</span><span><a href="mailto:<?= $echapper($technicien['email']) ?>"><?= $echapper($technicien['email']) ?></a></span></div>
                    <div class="technicien-detail__ligne"><span>Partenaire</span><span><a class="technicien-detail__partenaire" href="partenaire-detail.php?id=<?= (int) $technicien['partenaire_id'] ?>"><?= $echapper($technicien['nom_entreprise']) ?></a></span></div>
                    <div class="technicien-detail__ligne"><span>Compétences</span><span><?= $echapper($technicien['competences'] ?: 'Non renseignées') ?></span></div>
                    <div class="technicien-detail__ligne"><span>Note moyenne</span><span><?= $technicien['note_moyenne'] !== null ? number_format((float) $technicien['note_moyenne'], 1) . '/5 (' . (int) $technicien['nb_avis'] . ' avis clients)' : 'Aucun avis client' ?></span></div>
                    <div class="technicien-detail__ligne"><span>Refus (hors note client)</span><span><?= (int) $technicien['nb_refus'] ?></span></div>
                </section>
            </div>

            <section class="admin-panneau" aria-labelledby="technicien-missions-titre">
                <div class="admin-panneau__titre" id="technicien-missions-titre">Missions récentes</div>
                <table class="admin-table technicien-detail__missions">
                    <thead><tr><th scope="col">Dossier</th><th scope="col">Catégorie</th><th scope="col">Dates</th><th scope="col">Note</th><th scope="col">Statut</th><th scope="col" aria-label="Action"></th></tr></thead>
                    <tbody>
                    <?php if (empty($missions)): ?>
                        <tr><td colspan="6" class="technicien-detail__vide" style="text-align:center; color:var(--admin-texte-discret); padding:20px;">Aucune mission enregistrée.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($missions as $mission):
                        $statutMission = $libellesStatuts[$mission['statut']]
                            ?? [ucfirst(str_replace('_', ' ', (string) $mission['statut'])), 'gris'];
                    ?>
                        <tr class="technicien-detail__mission">
                            <td><strong><a class="technicien-detail__mission-lien" href="traiter-demande.php?id=<?= (int) $mission['demande_id'] ?>"><?= $echapper($mission['numero_dossier']) ?></a></strong><?php if (!empty($mission['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($mission['entreprise_b2b_nom']) ? ' · ' . $echapper($mission['entreprise_b2b_nom']) : '' ?></span><?php endif; ?></td>
                            <td data-label="Catégorie"><?= $echapper($mission['categorie_nom']) ?></td>
                            <td data-label="Dates">
                                <?= !empty($mission['date_debut']) ? $echapper(date('d/m/Y', strtotime($mission['date_debut']))) : '—' ?>
                                <?php if (!empty($mission['date_fin'])): ?><span class="technicien-detail__mission-note">Fin : <?= $echapper(date('d/m/Y', strtotime($mission['date_fin']))) ?></span><?php endif; ?>
                            </td>
                            <td data-label="Note"><?= $mission['note'] !== null ? $echapper(number_format((float) $mission['note'], 1) . '/5') : '—' ?></td>
                            <td data-label="Statut"><span class="admin-badge admin-badge--<?= $statutMission[1] ?>"><?= $echapper($statutMission[0]) ?></span></td>
                            <td><a class="technicien-detail__mission-lien technicien-detail__mission-lien--action" href="traiter-demande.php?id=<?= (int) $mission['demande_id'] ?>">Ouvrir le dossier <span aria-hidden="true">→</span></a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </section>
        </div>
    </div>
</div>
</body>
</html>
