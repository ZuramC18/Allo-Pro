<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('audit');
require_once __DIR__ . '/../../models/Audit.php';
require_once __DIR__ . '/../../includes/audit-affichage.php';

$auditModel = new Audit();

// ===== Filtres =====
$periodes = ['jour' => "Aujourd'hui", '7j' => '7 jours', '30j' => '30 jours', 'tout' => 'Tout'];
$periode = $_GET['periode'] ?? '7j';
if (!isset($periodes[$periode])) $periode = '7j';
$debut = ['jour' => date('Y-m-d'), '7j' => date('Y-m-d', strtotime('-6 days')), '30j' => date('Y-m-d', strtotime('-29 days')), 'tout' => ''][$periode];

$matricule = trim($_GET['matricule'] ?? '');
if (!preg_match('/^([A-Z]{2}-\d{5}|SYSTEME)$/', $matricule)) $matricule = '';

$filtres = [
    'debut' => $debut,
    'acteur_type' => trim($_GET['acteur_type'] ?? ''),
    'matricule' => $matricule,
    'categorie' => trim($_GET['categorie'] ?? ''),
    'q' => trim($_GET['q'] ?? ''),
    'pays' => trim($_GET['pays'] ?? ''),
];

// ===== Export CSV (respecte les filtres ; l'export lui-même est journalisé) =====
if (isset($_GET['export'])) {
    $lignes = $auditModel->rechercher($filtres, 5000, 0);
    journaliser('audit.exporte', 'audit', null, null, count($lignes) . ' ligne(s) exportée(s)');

    // Neutralise les cellules qu'Excel interpréterait comme une formule (ex. un nom de compte commençant par "=")
    $sur = fn($v) => (is_string($v) && preg_match('/^[=+\-@\t\r]/', $v)) ? "'" . $v : $v;

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="audit-allopro-' . date('Ymd-His') . '.csv"');
    $sortie = fopen('php://output', 'w');
    fwrite($sortie, "\xEF\xBB\xBF");
    fputcsv($sortie, ['Date', 'Matricule', 'Nom', 'Type', 'Action', 'Entité', 'Cible', 'Détail', 'IP', 'Pays'], ';');
    foreach ($lignes as $l) {
        fputcsv($sortie, array_map($sur, [$l['date_creation'], $l['acteur_matricule'], $l['acteur_nom'], $l['acteur_type'], $l['action'], $l['entite'], $l['cible'], $l['detail'], $l['ip'], $l['pays']]), ';');
    }
    fclose($sortie);
    exit;
}

// ===== Données =====
$parPage = 50;
$total = $auditModel->compter($filtres);
$nbPages = max(1, (int) ceil($total / $parPage));
$page = min(max(1, (int) ($_GET['page'] ?? 1)), $nbPages);
$evenements = $auditModel->rechercher($filtres, $parPage, ($page - 1) * $parPage);
$stats = $auditModel->stats();
$categories = $auditModel->categories();
$typesActeurs = $auditModel->typesActeurs();

$libellesTypes = LIBELLES_ROLES + ['partenaire' => 'Partenaire', 'technicien' => 'Technicien', 'systeme' => 'Système', 'inconnu' => 'Non identifié'];

function urlAudit(array $modif = []) {
    $p = array_filter(array_merge($_GET, $modif), fn($v) => $v !== '' && $v !== null);
    return '?' . http_build_query($p);
}

$nomFiltre = '';
if ($matricule && !empty($evenements)) {
    foreach ($evenements as $e) { if ($e['acteur_matricule'] === $matricule) { $nomFiltre = $e['acteur_nom']; break; } }
}
$filtresActifs = $filtres['acteur_type'] || $matricule || $filtres['categorie'] || $filtres['q'];
$parametresRetour = $_GET;
unset($parametresRetour['export']);
$retourAudit = http_build_query($parametresRetour);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Journal d'audit — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .page-audit { --audit-surface: #FFFFFF; --audit-accent-fond: #EFEBFD; --audit-accent-texte: var(--admin-violet); --audit-echec-fond: #FEF6F6; }
        .audit-filtres { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 18px; }
        .audit-filtres input, .audit-filtres select { padding: 10px 14px; border: 1px solid var(--admin-bordure); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 13.5px; background: var(--audit-surface); }
        .audit-filtres button { padding: 10px 20px; background: var(--admin-violet); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; }
        .matricule-badge { display: inline-block; font-family: monospace; font-size: 12px; font-weight: 700; background: var(--audit-accent-fond); color: var(--audit-accent-texte); padding: 2px 8px; border-radius: 6px; text-decoration: none; }
        .matricule-badge:hover { background: var(--admin-violet); color: white; }
        .audit-detail { font-size: 12.5px; color: var(--admin-texte-discret); max-width: 340px; line-height: 1.5; }
        .audit-cible { font-size: 13px; }
        .audit-cible a { color: var(--admin-texte); text-decoration: none; border-bottom: 1px dotted var(--admin-texte-discret); }
        .ligne-echec td { background: var(--audit-echec-fond); }
        .bandeau-filtre { background: var(--audit-accent-fond); color: var(--audit-accent-texte); padding: 11px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 13.5px; display: flex; justify-content: space-between; align-items: center; }
        .bandeau-filtre a { color: var(--audit-accent-texte); font-weight: 700; text-decoration: none; }
        .pagination-audit { display: flex; justify-content: space-between; align-items: center; margin-top: 16px; font-size: 13px; color: var(--admin-texte-discret); }
        .pagination-audit a { padding: 7px 14px; border: 1px solid var(--admin-bordure); border-radius: 6px; text-decoration: none; color: var(--admin-texte); background: var(--audit-surface); font-weight: 600; }
        .btn-export { padding: 9px 18px; border: 1px solid var(--admin-bordure); background: var(--audit-surface); border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--admin-texte); text-decoration: none; }
        .btn-export { display: inline-flex; align-items: center; justify-content: center; gap: 8px; }
        .btn-export svg { width: 16px; height: 16px; flex: 0 0 16px; }
        .audit-table-wrap { min-width: 0; }
        .audit-table { min-width: 0; }
        .audit-table tbody tr.audit-table__ligne { cursor: pointer; }
        .audit-table tbody tr.audit-table__ligne:hover td { background: rgba(108, 92, 231, .045); }
        .audit-table tbody tr.audit-table__ligne:focus-visible { outline: 2px solid var(--admin-violet); outline-offset: -2px; }
        .audit-date { white-space: nowrap; font-size: 12.5px; }
        .audit-acteur { min-width: 145px; }
        .audit-ip { font-size: 12px; color: var(--admin-texte-discret); white-space: nowrap; }
        @media (max-width: 900px) {
            .audit-entete { align-items: flex-start; }
            .audit-filtres { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .audit-filtres input, .audit-filtres select { width: 100% !important; min-width: 0; }
            .audit-filtres input[name="q"] { grid-column: 1 / -1; }
        }
        @media (max-width: 900px) {
            .audit-entete { flex-direction: column; }
            .btn-export { min-height: 42px; padding: 8px 12px; }
            .admin-kpi-grille { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
            .admin-kpi-carte { min-width: 0; min-height: 82px; padding: 11px; }
            .admin-kpi-carte__icone { top: 10px; right: 10px; width: 29px; height: 29px; }
            .admin-kpi-carte__icone svg { width: 16px; height: 16px; }
            .admin-kpi-carte__label { max-width: calc(100% - 28px); font-size: 10px; line-height: 1.3; }
            .admin-kpi-carte__valeur { max-width: 100%; font-size: 20px; overflow-wrap: anywhere; }
            .filtres-tabs { flex-wrap: nowrap; max-width: 100%; padding: 2px 1px 8px; overflow-x: auto; overscroll-behavior-inline: contain; -webkit-overflow-scrolling: touch; }
            .filtres-tabs .filtre-tab { flex: 0 0 auto; min-height: 38px; display: inline-flex; align-items: center; }
            .audit-filtres { grid-template-columns: minmax(0, 1fr); gap: 8px; }
            .audit-filtres input[name="q"] { grid-column: auto; }
            .audit-filtres input, .audit-filtres select { min-height: 42px; font-size: 16px; }
            .audit-filtres button { min-height: 42px; }
            .audit-filtres .admin-recherche__reset { min-height: 36px; justify-content: flex-end; }
            .bandeau-filtre { align-items: flex-start; flex-direction: column; gap: 8px; padding: 12px; font-size: 12px; overflow-wrap: anywhere; }
            .admin-panneau.audit-table-wrap { padding: 0; border: 0; background: transparent; box-shadow: none; }
            .admin-table.audit-table, .audit-table tbody { display: block; width: 100%; }
            .audit-table thead { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0,0,0,0); white-space: nowrap; border: 0; }
            .audit-table tbody { display: grid; gap: 10px; }
            .audit-table tbody tr { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); overflow: hidden; border: 1px solid var(--admin-bordure); border-radius: 11px; background: var(--audit-surface); }
            .audit-table tbody td { min-width: 0; padding: 10px; border: 0; border-bottom: 1px solid var(--admin-bordure); font-size: 12px; overflow-wrap: anywhere; }
            .audit-table tbody td::before { display: block; margin-bottom: 4px; color: var(--admin-texte-discret); font-size: 10px; font-weight: 600; content: attr(data-label); }
            .audit-table .audit-date { white-space: normal !important; }
            .audit-table .audit-acteur, .audit-table .audit-cible, .audit-table .audit-detail { grid-column: 1 / -1; }
            .audit-table .audit-acteur strong { overflow-wrap: anywhere; }
            .audit-table .audit-detail { max-width: none; line-height: 1.5; }
            .audit-table .audit-ip { white-space: normal !important; }
            .audit-table .ligne-echec td { background: transparent; }
            .audit-table .ligne-echec { background: var(--audit-echec-fond); }
            .audit-table tbody tr.audit-table__ligne:hover { border-color: var(--admin-violet); }
            .audit-table tbody tr.audit-table__vide { display: block; }
            .audit-table tbody tr.audit-table__vide td { display: block; }
            .audit-table tbody tr.audit-table__vide td::before { content: none; }
            .pagination-audit { align-items: stretch; flex-direction: column; gap: 10px; }
            .pagination-audit > span:last-child { justify-content: space-between; }
            .pagination-audit a { min-height: 40px; display: inline-flex; align-items: center; justify-content: center; }
        }
        @media (max-width: 380px) {
            .admin-contenu { padding-right: 12px; padding-left: 12px; }
            .audit-table tbody tr { grid-template-columns: minmax(0, 1fr); }
            .audit-table .audit-acteur, .audit-table .audit-cible, .audit-table .audit-detail { grid-column: 1; }
        }
        :root[data-theme="dark"] .audit-table tbody tr { background: var(--audit-surface); }
        :root[data-theme="dark"] .audit-table tbody tr.audit-table__ligne:hover td { background: rgba(255, 255, 255, .04); }
    </style>
</head>
<body class="page-audit">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Journal d'audit</div>
                <div class="admin-entete__sous-titre">Qui a fait quoi, quand, et depuis où — journal en lecture seule</div>
            </div>
            <a href="<?= htmlspecialchars(urlAudit(['export' => 1, 'page' => null])) ?>" class="btn-export"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/></svg>Exporter en CSV</a>
        </div>

        <div class="admin-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 2v4m8-4v4M3 10h18"/><rect x="3" y="4" width="18" height="18" rx="2"/><path d="m9 16 2 2 4-4"/></svg></div><div class="admin-kpi-carte__label">Actions aujourd'hui</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['aujourdhui'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 2.64-6.36L3 8"/><path d="M3 3v5h5m4-1v5l3 2"/></svg></div><div class="admin-kpi-carte__label">Actions sur 7 jours</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['sept_jours'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--<?= $stats['echecs_24h'] > 5 ? 'rouge' : 'vert' ?>"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/><path d="m10 15 4 4m0-4-4 4"/></svg></div><div class="admin-kpi-carte__label">Connexions échouées (24 h)</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['echecs_24h'] ?></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="4"/><path d="M3 21v-2a6 6 0 0 1 12 0v2m2-13a4 4 0 0 1 0 8m1 2a5 5 0 0 1 3 4v1"/></svg></div><div class="admin-kpi-carte__label">Acteurs distincts (7 j)</div><div class="admin-kpi-carte__valeur"><?= (int) $stats['acteurs_7j'] ?></div></div>
        </div>

        <div class="filtres-tabs" style="margin-bottom:16px;">
            <?php foreach ($periodes as $cle => $libelle): ?>
                <a href="<?= htmlspecialchars(urlAudit(['periode' => $cle, 'page' => null])) ?>" class="filtre-tab <?= $periode === $cle ? 'filtre-tab--actif' : '' ?>"><?= $libelle ?></a>
            <?php endforeach; ?>
        </div>

        <form method="GET" class="audit-filtres">
            <input type="hidden" name="periode" value="<?= htmlspecialchars($periode) ?>">
            <input type="text" name="matricule" placeholder="Matricule (ex : EQ-00003)" value="<?= htmlspecialchars($matricule) ?>" style="width:190px;">
            <select name="acteur_type" onchange="this.form.submit()">
                <option value="">Tous les types d'acteurs</option>
                <?php foreach ($typesActeurs as $t): ?>
                    <option value="<?= htmlspecialchars($t) ?>" <?= $filtres['acteur_type'] === $t ? 'selected' : '' ?>><?= htmlspecialchars($libellesTypes[$t] ?? $t) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="categorie" onchange="this.form.submit()">
                <option value="">Toutes les actions</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>" <?= $filtres['categorie'] === $c ? 'selected' : '' ?>><?= htmlspecialchars(ucfirst($c)) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="pays" onchange="this.form.submit()">
                <option value="">Tous les pays</option>
                <?php foreach ($auditModel->paysDistincts() as $p): ?>
                    <option value="<?= htmlspecialchars($p) ?>" <?= ($filtres['pays'] ?? '') === $p ? 'selected' : '' ?>><?= htmlspecialchars($p) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="q" placeholder="Rechercher (cible, détail, nom)..." value="<?= htmlspecialchars($filtres['q']) ?>" style="flex:1; min-width:200px;">
            <button type="submit">Filtrer</button>
            <?php if ($filtresActifs): ?><a href="?periode=<?= htmlspecialchars($periode) ?>" class="admin-recherche__reset" style="align-self:center;">Réinitialiser</a><?php endif; ?>
        </form>

        <?php if ($matricule): ?>
            <div class="bandeau-filtre">
                <span>Actions de <strong><?= htmlspecialchars($nomFiltre ?: $matricule) ?></strong> · <span class="matricule-badge"><?= htmlspecialchars($matricule) ?></span></span>
                <a href="<?= htmlspecialchars(urlAudit(['matricule' => null, 'page' => null])) ?>">Voir tout le monde ×</a>
            </div>
        <?php endif; ?>

        <div class="admin-panneau audit-table-wrap">
            <table class="admin-table audit-table">
                <thead><tr><th scope="col">Date</th><th scope="col">Acteur</th><th scope="col">Action</th><th scope="col">Cible</th><th scope="col">Détail</th><th scope="col">IP</th></tr></thead>
                <tbody>
                <?php if (empty($evenements)): ?>
                    <tr class="audit-table__vide"><td colspan="6" style="text-align:center; color:var(--admin-texte-discret); padding:30px;">Aucun événement sur cette période.</td></tr>
                <?php endif; ?>
                <?php foreach ($evenements as $e): ?>
                <tr class="<?= $e['action'] === 'connexion.echec' ? 'ligne-echec' : '' ?> audit-table__ligne" tabindex="0" aria-label="Consulter le détail de <?= htmlspecialchars(libelleActionAudit($e['action']), ENT_QUOTES, 'UTF-8') ?>, le <?= htmlspecialchars(date('d/m/Y à H:i:s', strtotime($e['date_creation'])), ENT_QUOTES, 'UTF-8') ?>" data-href="audit-detail.php?id=<?= (int) $e['id'] ?>&amp;retour=<?= rawurlencode($retourAudit) ?>">
                    <td class="audit-date" data-label="Date"><?= date('d/m/Y', strtotime($e['date_creation'])) ?><br><span style="color:var(--admin-texte-discret);"><?= date('H:i:s', strtotime($e['date_creation'])) ?></span></td>
                    <td class="audit-acteur" data-label="Acteur">
                        <?php if ($e['acteur_matricule']): ?>
                            <strong><?= htmlspecialchars($e['acteur_nom'] ?? '—') ?></strong><br>
                            <a href="<?= htmlspecialchars(urlAudit(['matricule' => $e['acteur_matricule'], 'page' => null])) ?>" class="matricule-badge" title="Voir toutes ses actions"><?= htmlspecialchars($e['acteur_matricule']) ?></a>
                            <span style="font-size:11.5px; color:var(--admin-texte-discret);"><?= htmlspecialchars($libellesTypes[$e['acteur_type']] ?? $e['acteur_type']) ?></span>
                        <?php else: ?>
                            <span style="color:var(--admin-texte-discret);"><?= htmlspecialchars($libellesTypes[$e['acteur_type']] ?? $e['acteur_type']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="audit-action" data-label="Action"><span class="admin-badge admin-badge--<?= couleurActionAudit($e['action']) ?>"><?= htmlspecialchars(libelleActionAudit($e['action'])) ?></span></td>
                    <td class="audit-cible" data-label="Cible">
                        <?php if ($e['cible']): ?><a href="<?= htmlspecialchars(urlAudit(['q' => $e['cible'], 'page' => null])) ?>"><?= htmlspecialchars($e['cible']) ?></a><?php else: ?>—<?php endif; ?>
                    </td>
                    <td class="audit-detail" data-label="Détail"><?= $e['detail'] ? nl2br(htmlspecialchars($e['detail'])) : '—' ?></td>
                    <td class="audit-ip" data-label="IP">
                        <?= htmlspecialchars($e['ip'] ?? '—') ?>
                        <?php if ($e['pays']): ?><br><span style="font-weight:600; color:var(--admin-texte);"><?= htmlspecialchars($e['pays']) ?></span><?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div class="pagination-audit">
                <span><?= number_format($total, 0, ',', ' ') ?> événement<?= $total > 1 ? 's' : '' ?> · page <?= $page ?> / <?= $nbPages ?></span>
                <span style="display:flex; gap:8px;">
                    <?php if ($page > 1): ?><a href="<?= htmlspecialchars(urlAudit(['page' => $page - 1])) ?>">← Précédent</a><?php endif; ?>
                    <?php if ($page < $nbPages): ?><a href="<?= htmlspecialchars(urlAudit(['page' => $page + 1])) ?>">Suivant →</a><?php endif; ?>
                </span>
            </div>
        </div>
    </div>
</div>
<script>
    document.querySelectorAll('.audit-table__ligne[data-href]').forEach((ligne) => {
        ligne.addEventListener('click', (evenement) => {
            if (evenement.target.closest('a, button, form, input, select, textarea, [contenteditable="true"]')) return;
            window.location.href = ligne.dataset.href;
        });
        ligne.addEventListener('keydown', (evenement) => {
            if (evenement.target !== ligne || (evenement.key !== 'Enter' && evenement.key !== ' ')) return;
            evenement.preventDefault();
            window.location.href = ligne.dataset.href;
        });
    });
</script>
</body>
</html>