<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('audit');
require_once __DIR__ . '/../../models/Audit.php';
require_once __DIR__ . '/../../includes/audit-affichage.php';

$auditModel = new Audit();
$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$evenement = $id ? $auditModel->getById($id) : false;
if (!$evenement) {
    http_response_code(404);
}

$parametresRetourBruts = [];
parse_str((string) ($_GET['retour'] ?? ''), $parametresRetourBruts);
$parametresRetour = [];
foreach (['periode', 'page', 'matricule', 'acteur_type', 'categorie', 'q', 'pays'] as $cle) {
    if (isset($parametresRetourBruts[$cle]) && is_scalar($parametresRetourBruts[$cle])) {
        $parametresRetour[$cle] = (string) $parametresRetourBruts[$cle];
    }
}
$urlRetour = 'audit.php' . ($parametresRetour ? '?' . http_build_query($parametresRetour) : '');
$dateCreation = $evenement ? strtotime($evenement['date_creation']) : false;
$matriculeValide = $evenement && preg_match('/^([A-Z]{2}-\d{5}|SYSTEME)$/', (string) $evenement['acteur_matricule']);
$urlActeur = $matriculeValide ? 'audit.php?' . http_build_query(['matricule' => $evenement['acteur_matricule']]) : null;
$urlCible = $evenement && $evenement['cible'] !== null && $evenement['cible'] !== ''
    ? 'audit.php?' . http_build_query(['q' => $evenement['cible']])
    : null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $evenement ? 'Événement #' . (int) $evenement['id'] : 'Événement introuvable' ?> — Journal d'audit</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .page-audit-detail { --audit-surface: #fff; --audit-accent-fond: #EFEBFD; --audit-accent-texte: var(--admin-violet); }
        .audit-detail-actions { display:flex; flex-wrap:wrap; gap:10px; }
        .audit-detail-lien { display:inline-flex; align-items:center; justify-content:center; gap:8px; min-height:40px; padding:8px 14px; border:1px solid var(--admin-bordure); border-radius:8px; color:var(--admin-texte); background:var(--audit-surface); font-size:13px; font-weight:600; text-decoration:none; }
        .audit-detail-lien--retour { color:var(--admin-violet); }
        .audit-detail-lien svg { width:16px; height:16px; flex:0 0 16px; }
        .audit-detail-carte { max-width:900px; }
        .audit-detail-entete { display:flex; align-items:flex-start; justify-content:space-between; gap:16px; padding-bottom:18px; border-bottom:1px solid var(--admin-bordure); }
        .audit-detail-titre { margin-bottom:8px; font-family:'Space Grotesk',sans-serif; font-size:21px; font-weight:800; overflow-wrap:anywhere; }
        .audit-detail-reference { color:var(--admin-texte-discret); font-family:monospace; font-size:12px; }
        .audit-detail-grille { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:0 20px; }
        .audit-detail-champ { min-width:0; padding:16px 0; border-bottom:1px solid var(--admin-bordure); }
        .audit-detail-champ--large { grid-column:1/-1; }
        .audit-detail-libelle { margin-bottom:6px; color:var(--admin-texte-discret); font-size:11px; font-weight:700; letter-spacing:.04em; text-transform:uppercase; }
        .audit-detail-valeur { min-width:0; color:var(--admin-texte); font-size:14px; line-height:1.55; overflow-wrap:anywhere; }
        .audit-detail-valeur a { color:var(--admin-violet); text-decoration:none; border-bottom:1px dotted currentColor; }
        .audit-detail-acteur { display:flex; flex-wrap:wrap; align-items:center; gap:8px; }
        .audit-detail-texte { padding:12px; border-radius:9px; background:var(--admin-fond-app); white-space:pre-wrap; overflow-wrap:anywhere; }
        .audit-detail-vide { max-width:680px; }
        @media (max-width:600px) {
            .audit-detail-actions { width:100%; }
            .audit-detail-lien { min-height:42px; }
            .audit-detail-actions .audit-detail-lien { flex:1 1 auto; }
            .audit-detail-carte { padding:16px; }
            .audit-detail-entete { flex-direction:column; gap:12px; padding-bottom:14px; }
            .audit-detail-titre { font-size:19px; }
            .audit-detail-grille { grid-template-columns:minmax(0,1fr); }
            .audit-detail-champ--large { grid-column:auto; }
            .audit-detail-champ { padding:13px 0; }
            .audit-detail-valeur { font-size:13px; }
        }
        :root[data-theme="dark"] .audit-detail-texte { background:#191c25; }
    </style>
</head>
<body class="page-audit-detail">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Détail du journal d'audit</div>
                <div class="admin-entete__sous-titre">Consultation en lecture seule d'un événement enregistré</div>
            </div>
            <div class="audit-detail-actions">
                <a class="audit-detail-lien audit-detail-lien--retour" href="<?= htmlspecialchars($urlRetour, ENT_QUOTES, 'UTF-8') ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/><path d="M9 12h12"/></svg>
                    Retour au journal
                </a>
            </div>
        </div>

        <?php if (!$evenement): ?>
            <div class="admin-panneau audit-detail-vide">
                <div class="admin-panneau__titre">Événement introuvable</div>
                <p style="color:var(--admin-texte-discret);font-size:13px;line-height:1.6;">Cet événement n'existe pas ou n'est plus disponible dans le journal d'audit.</p>
            </div>
        <?php else: ?>
            <div class="admin-panneau audit-detail-carte">
                <div class="audit-detail-entete">
                    <div>
                        <div class="audit-detail-titre"><?= htmlspecialchars(libelleActionAudit($evenement['action'])) ?></div>
                        <div class="audit-detail-reference">Événement #<?= (int) $evenement['id'] ?> · <?= $dateCreation ? date('d/m/Y à H:i:s', $dateCreation) : htmlspecialchars($evenement['date_creation']) ?></div>
                    </div>
                    <span class="admin-badge admin-badge--<?= couleurActionAudit($evenement['action']) ?>"><?= htmlspecialchars($evenement['action']) ?></span>
                </div>

                <div class="audit-detail-grille">
                    <div class="audit-detail-champ">
                        <div class="audit-detail-libelle">Acteur</div>
                        <div class="audit-detail-valeur audit-detail-acteur">
                            <strong><?= htmlspecialchars($evenement['acteur_nom'] ?: '—') ?></strong>
                            <span><?= htmlspecialchars(libelleActeurAudit((string) $evenement['acteur_type'])) ?></span>
                            <?php if ($evenement['acteur_matricule']): ?>
                                <?php if ($urlActeur): ?>
                                    <a class="matricule-badge" href="<?= htmlspecialchars($urlActeur, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($evenement['acteur_matricule']) ?></a>
                                <?php else: ?>
                                    <span class="matricule-badge"><?= htmlspecialchars($evenement['acteur_matricule']) ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="audit-detail-champ">
                        <div class="audit-detail-libelle">Date et heure</div>
                        <div class="audit-detail-valeur"><?= $dateCreation ? date('d/m/Y à H:i:s', $dateCreation) : htmlspecialchars($evenement['date_creation']) ?></div>
                    </div>
                    <div class="audit-detail-champ">
                        <div class="audit-detail-libelle">Entité concernée</div>
                        <div class="audit-detail-valeur">
                            <?= htmlspecialchars($evenement['entite'] ?: '—') ?>
                            <?php if ($evenement['entite_id'] !== null): ?> · #<?= (int) $evenement['entite_id'] ?><?php endif; ?>
                        </div>
                    </div>
                    <div class="audit-detail-champ">
                        <div class="audit-detail-libelle">Cible</div>
                        <div class="audit-detail-valeur">
                            <?php if ($evenement['cible']): ?>
                                <?php if ($urlCible): ?><a href="<?= htmlspecialchars($urlCible, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($evenement['cible']) ?></a><?php else: ?><?= htmlspecialchars($evenement['cible']) ?><?php endif; ?>
                            <?php else: ?>—<?php endif; ?>
                        </div>
                    </div>
                    <div class="audit-detail-champ audit-detail-champ--large">
                        <div class="audit-detail-libelle">Détail de l'action</div>
                        <div class="audit-detail-valeur audit-detail-texte"><?= $evenement['detail'] !== null && $evenement['detail'] !== '' ? htmlspecialchars($evenement['detail']) : 'Aucun détail complémentaire.' ?></div>
                    </div>
                    <div class="audit-detail-champ">
                        <div class="audit-detail-libelle">Adresse IP</div>
                        <div class="audit-detail-valeur"><?= htmlspecialchars($evenement['ip'] ?: '—') ?></div>
                    </div>
                    <div class="audit-detail-champ">
                        <div class="audit-detail-libelle">Pays</div>
                        <div class="audit-detail-valeur"><?= htmlspecialchars($evenement['pays'] ?: '—') ?></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
