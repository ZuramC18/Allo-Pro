<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('devis_entreprises');
require_once __DIR__ . '/../../models/EntrepriseB2B.php';

$modeleEntreprise = new EntrepriseB2B();
$role = $_SESSION['role'];
$peutQualifier = in_array($role, ['qualite', 'admin'], true);
$peutEmettre = in_array($role, ['finance', 'admin'], true);
$erreur = '';
$csrfKey = 'csrf_devis_entreprise_admin';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $devisId = filter_var($_POST['devis_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($devisId === false) {
        $erreur = 'Le devis sélectionné est invalide.';
    } else {
        try {
            if ($action === 'qualifier' && $peutQualifier) {
                $decision = is_string($_POST['decision'] ?? null) ? $_POST['decision'] : '';
                $commentaire = is_string($_POST['commentaire_qualite'] ?? null) ? $_POST['commentaire_qualite'] : '';
                if (!$modeleEntreprise->traiterQualificationDevis((int) $devisId, (int) $_SESSION['user_id'], $decision, $commentaire)) {
                    throw new RuntimeException('Cette demande a déjà été prise en charge ou est introuvable.');
                }
                journaliser('devis_entreprise.qualite_' . $decision, 'devis_b2b', (int) $devisId, null, $commentaire);
                header('Location: devis-entreprises.php?qualifie=1');
                exit;
            }
            if ($action === 'emettre' && $peutEmettre) {
                $montantBrut = is_string($_POST['montant'] ?? null) ? str_replace(',', '.', trim($_POST['montant'])) : '';
                $montant = filter_var($montantBrut, FILTER_VALIDATE_FLOAT);
                $details = is_string($_POST['details'] ?? null) ? $_POST['details'] : '';
                $validite = is_string($_POST['date_validite'] ?? null) && trim($_POST['date_validite']) !== ''
                    ? trim($_POST['date_validite'])
                    : null;
                if ($montant === false) {
                    throw new InvalidArgumentException('Le montant du devis est invalide.');
                }
                if (!$modeleEntreprise->emettreDevis((int) $devisId, (int) $_SESSION['user_id'], (float) $montant, $details, $validite)) {
                    throw new RuntimeException('Ce devis n’a pas encore été validé par le responsable Qualité / SAV, ou est déjà traité.');
                }
                journaliser('devis_entreprise.finance_emis', 'devis_b2b', (int) $devisId, null, number_format((float) $montant, 2, '.', '') . ' FCFA');
                header('Location: devis-entreprises.php?emis=1');
                exit;
            }
            throw new RuntimeException('Vous ne disposez pas des droits nécessaires pour cette action.');
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Traitement devis entreprise #' . (int) $devisId . ' par utilisateur ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
            $erreur = 'Le devis n’a pas pu être enregistré. Réessayez.';
        }
    }
}
$devisQualite = $peutQualifier ? $modeleEntreprise->getDevisB2BPourQualite() : [];
$devisFinance = $peutEmettre ? $modeleEntreprise->getDevisB2BPourEmission() : [];
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$titreDevis = 'Devis entreprises';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $e($titreDevis) ?> — ALLÔ PRO <?= $e(ucfirst($role)) ?></title>
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css">
    <link rel="stylesheet" href="../../public/css/finance-devis-entreprises.css?v=<?= filemtime(__DIR__ . '/../../public/css/finance-devis-entreprises.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu b2b-main b2b-devis-page">
    <header class="b2b-devis-hero">
        <div>
            <span class="b2b-devis-hero__eyebrow">Parcours entreprises</span>
            <h1>Devis entreprises</h1>
            <p><?= $role === 'qualite' ? 'Vérifiez la faisabilité technique avant le chiffrage par Finance.' : ($role === 'finance' ? 'Chiffrez et transmettez les offres validées par Qualité / SAV.' : 'Suivez la qualification technique et le chiffrage des demandes entreprise.') ?></p>
        </div>
    </header>
    <?php if (($_GET['emis'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">Le devis a été envoyé à l’espace entreprise.</div><?php endif; ?>
    <?php if (($_GET['qualifie'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">La qualification technique a été enregistrée.</div><?php endif; ?>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
    <section class="b2b-devis-stats" aria-label="Demandes de devis en attente">
        <?php if ($peutQualifier): ?>
        <article class="b2b-devis-stat b2b-devis-stat--qualite">
            <span>À qualifier</span><strong><?= number_format(count($devisQualite), 0, ',', ' ') ?></strong>
            <p>Demandes à vérifier techniquement</p>
        </article>
        <?php endif; ?>
        <?php if ($peutEmettre): ?>
        <article class="b2b-devis-stat b2b-devis-stat--finance">
            <span>À chiffrer</span><strong><?= number_format(count($devisFinance), 0, ',', ' ') ?></strong>
            <p>Demandes validées par Qualité</p>
        </article>
        <?php endif; ?>
    </section>
    <?php if ($peutQualifier): ?>
        <section class="b2b-devis-section" aria-labelledby="devis-qualite-title">
            <header class="b2b-devis-section__header">
                <div><span class="b2b-devis-section__eyebrow">Étape 1 · Qualité / SAV</span><h2 id="devis-qualite-title">Qualification technique</h2><p>Vérifiez le périmètre puis validez le dossier ou demandez des précisions.</p></div>
                <span class="b2b-devis-section__count"><?= number_format(count($devisQualite), 0, ',', ' ') ?> à traiter</span>
            </header>
            <?php if (!$devisQualite): ?>
                <div class="b2b-devis-empty"><strong>Tout est à jour</strong><p>Aucune demande de devis n’attend de qualification technique.</p></div>
            <?php else: foreach ($devisQualite as $ligne): ?>
                <article class="b2b-devis-card">
                    <header class="b2b-devis-card__header">
                        <div><span class="b2b-devis-card__reference"><?= $e($ligne['numero']) ?></span><h3><?= $e($ligne['entreprise_nom']) ?></h3></div>
                        <span class="b2b-status b2b-status--en_attente"><?= $ligne['qualite_statut'] === 'a_preciser' ? 'Précisions reçues' : 'À qualifier' ?></span>
                    </header>
                    <div class="b2b-devis-card__meta">
                        <span>Soumis le <strong><?= $e(date('d/m/Y à H:i', strtotime($ligne['date_creation']))) ?></strong></span>
                        <?php if (!empty($ligne['numero_dossier'])): ?><span>Dossier <strong><?= $e($ligne['numero_dossier']) ?></strong></span><?php endif; ?>
                    </div>
                    <p class="b2b-devis-card__description"><?= nl2br($e($ligne['description'])) ?></p>
                    <?php if (!empty($ligne['numero_dossier'])): ?>
                        <a class="b2b-devis-card__dossier" href="<?= $role === 'qualite' ? 'detail-dossier.php' : '../qualite/detail-dossier.php' ?>?devis_id=<?= (int) $ligne['id'] ?>">Consulter le dossier <span aria-hidden="true">→</span></a>
                    <?php endif; ?>
                    <?php if ($ligne['qualite_commentaire']): ?><div class="b2b-devis-card__previous"><strong>Précision déjà demandée</strong><p><?= nl2br($e($ligne['qualite_commentaire'])) ?></p></div><?php endif; ?>
                    <form method="post" class="b2b-form b2b-devis-form">
                        <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                        <input type="hidden" name="devis_id" value="<?= (int) $ligne['id'] ?>">
                        <input type="hidden" name="action" value="qualifier">
                        <label>Note technique ou précisions attendues<textarea name="commentaire_qualite" maxlength="3000" required placeholder="Précisez la faisabilité, les éléments à vérifier ou les informations manquantes."></textarea></label>
                        <div class="b2b-devis-form__actions">
                            <button class="b2b-button" name="decision" value="valide" type="submit">Valider pour chiffrage</button>
                            <button class="b2b-button b2b-button--secondary" name="decision" value="a_preciser" type="submit">Demander des précisions</button>
                        </div>
                    </form>
                </article>
            <?php endforeach; endif; ?>
        </section>
    <?php endif; ?>
    <?php if ($peutEmettre): ?>
        <section class="b2b-devis-section" aria-labelledby="devis-finance-title">
            <header class="b2b-devis-section__header">
                <div><span class="b2b-devis-section__eyebrow">Étape 2 · Finance</span><h2 id="devis-finance-title">Chiffrage et émission</h2><p>Définissez le montant, les conditions et la durée de validité de chaque offre.</p></div>
                <span class="b2b-devis-section__count"><?= number_format(count($devisFinance), 0, ',', ' ') ?> à chiffrer</span>
            </header>
            <?php if (!$devisFinance): ?>
                <div class="b2b-devis-empty"><strong>Aucun devis à chiffrer</strong><p>Les demandes validées par Qualité apparaîtront ici.</p></div>
            <?php else: foreach ($devisFinance as $ligne): ?>
                <article class="b2b-devis-card b2b-devis-card--finance">
                    <header class="b2b-devis-card__header">
                        <div><span class="b2b-devis-card__reference"><?= $e($ligne['numero']) ?></span><h3><?= $e($ligne['entreprise_nom']) ?></h3></div>
                        <span class="b2b-status b2b-status--emis">Validé techniquement</span>
                    </header>
                    <div class="b2b-devis-card__meta">
                        <span>Soumis le <strong><?= $e(date('d/m/Y à H:i', strtotime($ligne['date_creation']))) ?></strong></span>
                        <?php if (!empty($ligne['qualite_le'])): ?><span>Validé le <strong><?= $e(date('d/m/Y à H:i', strtotime($ligne['qualite_le']))) ?></strong></span><?php endif; ?>
                        <?php if (!empty($ligne['numero_dossier'])): ?><span>Dossier <strong><?= $e($ligne['numero_dossier']) ?></strong></span><?php endif; ?>
                    </div>
                    <p class="b2b-devis-card__description"><?= nl2br($e($ligne['description'])) ?></p>
                    <?php if (!empty($ligne['numero_dossier'])): ?>
                        <a class="b2b-devis-card__dossier" href="../qualite/detail-dossier.php?devis_id=<?= (int) $ligne['id'] ?>">Consulter le dossier <span aria-hidden="true">→</span></a>
                    <?php endif; ?>
                    <div class="b2b-devis-card__validation"><strong>Note de validation technique</strong><p><?= nl2br($e($ligne['qualite_commentaire'])) ?></p></div>
                    <form method="post" class="b2b-form b2b-devis-form b2b-devis-form--finance">
                        <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                        <input type="hidden" name="devis_id" value="<?= (int) $ligne['id'] ?>">
                        <input type="hidden" name="action" value="emettre">
                        <label>Montant du devis (FCFA)<input type="number" name="montant" min="1" max="9999999999" step="0.01" inputmode="decimal" required placeholder="Ex. : 125000"></label>
                        <label>Valide jusqu’au <span class="b2b-devis-form__optional">Facultatif</span><input type="date" name="date_validite" min="<?= date('Y-m-d') ?>"></label>
                        <label class="b2b-devis-form__details">Conditions et détails financiers<textarea name="details" maxlength="3000" required placeholder="Détaillez les prestations, les conditions de règlement et les éventuelles exclusions."></textarea></label>
                        <div class="b2b-devis-form__actions"><button class="b2b-button" type="submit">Émettre le devis à l’entreprise</button></div>
                    </form>
                </article>
            <?php endforeach; endif; ?>
        </section>
    <?php endif; ?>
    </main>
</div>
</body>
</html>
