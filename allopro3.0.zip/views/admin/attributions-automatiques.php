<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['admin']);
verifierAcces('interventions');
require_once __DIR__ . '/../../models/AttributionDemandes.php';

$attributions = (new AttributionDemandes())->getAttributionsAutomatiques();
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$lienMissions = 'interventions.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Attributions automatiques — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/attributions-automatiques.css?v=<?= filemtime(__DIR__ . '/../../public/css/attributions-automatiques.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu">
        <?php include __DIR__ . '/../../includes/attributions-automatiques-contenu.php'; ?>
    </main>
</div>
</body>
</html>
