<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAdminConnecte();
verifierAcces('parametres');
require_once __DIR__ . '/../../includes/event-themes-manager.php';

if (empty($_SESSION['csrf_themes_evenementiels'])) {
    $_SESSION['csrf_themes_evenementiels'] = bin2hex(random_bytes(32));
}

$erreur = '';
$messageSucces = $_SESSION['flash_themes_evenementiels'] ?? '';
unset($_SESSION['flash_themes_evenementiels']);
$erreurChargement = null;
$configuration = chargerConfigurationThemesEvenementiels($erreurChargement);
$erreur = $erreurChargement ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_themes_evenementiels'], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } else {
        $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
        try {
            if ($action === 'global') {
                $configuration['enabled'] = ($_POST['enabled'] ?? '') === '1';
            } elseif ($action === 'confirm_dates') {
                $slug = is_string($_POST['slug'] ?? null) ? $_POST['slug'] : '';
                $found = false;
                $anneeConfirmation = (int) (new DateTimeImmutable('now', new DateTimeZone('Africa/Dakar')))->format('Y');
                foreach ($configuration['themes'] as &$theme) {
                    if ($theme['slug'] !== $slug || empty($theme['annual_date_confirmation'])) {
                        continue;
                    }
                    $theme['dates_confirmed_year'] = $anneeConfirmation;
                    $theme['dates_confirmed_start'] = $theme['start'];
                    $theme['dates_confirmed_end'] = $theme['end'];
                    $found = true;
                    break;
                }
                unset($theme);
                if (!$found) {
                    throw new InvalidArgumentException('Cet événement à date mobile n’existe plus. Rechargez la page.');
                }
            } elseif ($action === 'hide_dates_reminder') {
                $anneeMasquage = (int) (new DateTimeImmutable('now', new DateTimeZone('Africa/Dakar')))->format('Y');
                $nombreDatesMobiles = 0;
                foreach ($configuration['themes'] as $theme) {
                    if (empty($theme['annual_date_confirmation'])) {
                        continue;
                    }
                    $nombreDatesMobiles++;
                    if (
                        ($theme['dates_confirmed_year'] ?? null) !== $anneeMasquage
                        || ($theme['dates_confirmed_start'] ?? null) !== $theme['start']
                        || ($theme['dates_confirmed_end'] ?? null) !== $theme['end']
                    ) {
                        throw new InvalidArgumentException('Confirmez d’abord les dates de chaque événement avant de masquer le rappel.');
                    }
                }
                if ($nombreDatesMobiles === 0) {
                    throw new InvalidArgumentException('Aucun événement à date mobile n’est à confirmer.');
                }
                $configuration['dates_confirmation_dismissed_year'] = $anneeMasquage;
                $configuration['dates_confirmation_dismissed_signature'] = signatureDatesConfirmationAnnuelle($configuration['themes'], $anneeMasquage);
            } elseif ($action === 'add') {
                $configuration['themes'][] = [
                    'name' => trim(is_string($_POST['name'] ?? null) ? $_POST['name'] : ''),
                    'slug' => trim(is_string($_POST['slug'] ?? null) ? $_POST['slug'] : ''),
                    'start' => trim(is_string($_POST['start'] ?? null) ? $_POST['start'] : ''),
                    'end' => trim(is_string($_POST['end'] ?? null) ? $_POST['end'] : ''),
                    'priority' => filter_var($_POST['priority'] ?? null, FILTER_VALIDATE_INT),
                    'enabled' => ($_POST['enabled'] ?? '') === '1',
                    'animations' => ($_POST['animations'] ?? '') === '1',
                    'greeting_enabled' => ($_POST['greeting_enabled'] ?? '') === '1',
                    'greeting_message' => trim(is_string($_POST['greeting_message'] ?? null) ? $_POST['greeting_message'] : ''),
                ];
            } elseif ($action === 'update') {
                $slug = is_string($_POST['slug'] ?? null) ? $_POST['slug'] : '';
                $found = false;
                foreach ($configuration['themes'] as &$theme) {
                    if ($theme['slug'] !== $slug) {
                        continue;
                    }
                    $theme['name'] = trim(is_string($_POST['name'] ?? null) ? $_POST['name'] : '');
                    $theme['start'] = trim(is_string($_POST['start'] ?? null) ? $_POST['start'] : '');
                    $theme['end'] = trim(is_string($_POST['end'] ?? null) ? $_POST['end'] : '');
                    $theme['greeting_message'] = trim(is_string($_POST['greeting_message'] ?? null) ? $_POST['greeting_message'] : '');
                    $theme['greeting_enabled'] = ($_POST['greeting_enabled'] ?? '') === '1';
                    $theme['priority'] = filter_var($_POST['priority'] ?? null, FILTER_VALIDATE_INT);
                    $theme['enabled'] = ($_POST['enabled'] ?? '') === '1';
                    $theme['animations'] = ($_POST['animations'] ?? '') === '1';
                    $found = true;
                    break;
                }
                unset($theme);
                if (!$found) {
                    throw new InvalidArgumentException('Ce thème n’existe plus. Rechargez la page.');
                }
            } elseif ($action === 'delete') {
                $slug = is_string($_POST['slug'] ?? null) ? $_POST['slug'] : '';
                $themes = array_values(array_filter(
                    $configuration['themes'],
                    static fn(array $theme): bool => $theme['slug'] !== $slug
                ));
                if (count($themes) === count($configuration['themes'])) {
                    throw new InvalidArgumentException('Ce thème n’existe plus. Rechargez la page.');
                }
                $configuration['themes'] = $themes;
            } else {
                throw new InvalidArgumentException('Action non reconnue.');
            }

            enregistrerConfigurationThemesEvenementiels($configuration);
            journaliser(
                'parametre.themes_evenementiels_modifie',
                'parametre',
                null,
                $action,
                'Configuration des thèmes événementiels mise à jour'
            );
            $_SESSION['flash_themes_evenementiels'] = 'La configuration des thèmes événementiels a été enregistrée.';
            if ($action === 'confirm_dates') {
                $_SESSION['flash_themes_evenementiels'] = 'Les dates de cet événement ont été confirmées pour ' . $anneeConfirmation . '.';
            } elseif ($action === 'hide_dates_reminder') {
                $_SESSION['flash_themes_evenementiels'] = 'Le rappel est masqué jusqu’à l’année prochaine. Il réapparaîtra si une date est modifiée.';
            }
            header('Location: themes-evenementiels.php');
            exit;
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (JsonException $exception) {
            error_log('Encodage de la configuration des thèmes : ' . $exception->getMessage());
            $erreur = 'La configuration n’a pas pu être enregistrée. Consultez les journaux du serveur.';
        }
    }
}

$dateMaintenant = new DateTimeImmutable('now', new DateTimeZone('Africa/Dakar'));
$dateTheme = $dateMaintenant->format('m-d');
$anneeTheme = (int) $dateMaintenant->format('Y');
$themesDatesMobiles = [];
$nombreDatesAConfirmer = 0;
$nombreDatesMobiles = 0;
$dateConfirmation = static function (array $theme) use ($anneeTheme): bool {
    return ($theme['dates_confirmed_year'] ?? null) === $anneeTheme
        && ($theme['dates_confirmed_start'] ?? null) === $theme['start']
        && ($theme['dates_confirmed_end'] ?? null) === $theme['end'];
};
foreach ($configuration['themes'] as $theme) {
    if (empty($theme['annual_date_confirmation'])) {
        continue;
    }
    $nombreDatesMobiles++;
    $confirme = $dateConfirmation($theme);
    if (!$confirme) {
        $nombreDatesAConfirmer++;
    }
    $themesDatesMobiles[] = ['theme' => $theme, 'confirme' => $confirme];
}
$rappelDatesMasque = $nombreDatesMobiles > 0
    && $nombreDatesAConfirmer === 0
    && ($configuration['dates_confirmation_dismissed_year'] ?? null) === $anneeTheme
    && ($configuration['dates_confirmation_dismissed_signature'] ?? null) === signatureDatesConfirmationAnnuelle($configuration['themes'], $anneeTheme);
$themeActif = null;
if ($configuration['enabled']) {
    foreach ($configuration['themes'] as $theme) {
        $dansPeriode = $theme['start'] <= $theme['end']
            ? $dateTheme >= $theme['start'] && $dateTheme <= $theme['end']
            : $dateTheme >= $theme['start'] || $dateTheme <= $theme['end'];
        $cssDisponible = is_file(__DIR__ . '/../../public/css/event-themes/' . $theme['slug'] . '.css');
        if ($theme['enabled'] && $dansPeriode && $cssDisponible
            && ($themeActif === null || $theme['priority'] > $themeActif['priority'])) {
            $themeActif = $theme;
        }
    }
}

$e = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thèmes événementiels — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/admin-themes-evenementiels.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin-themes-evenementiels.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu themes-evenementiels">
        <header class="admin-entete">
            <div>
                <div class="admin-entete__titre">Thèmes événementiels</div>
                <div class="admin-entete__sous-titre">Planifiez les habillages saisonniers du site public et de l’espace client.</div>
            </div>
        </header>

        <?php if ($messageSucces !== ''): ?>
            <div class="themes-evenementiels__message themes-evenementiels__message--succes" role="status"><?= $e($messageSucces) ?></div>
        <?php endif; ?>
        <?php if ($erreur !== ''): ?>
            <div class="themes-evenementiels__message themes-evenementiels__message--erreur" role="alert"><?= $e($erreur) ?></div>
        <?php endif; ?>

        <?php if ($nombreDatesMobiles > 0 && !$rappelDatesMasque): ?>
        <section class="themes-evenementiels__rappel <?= $nombreDatesAConfirmer > 0 ? 'themes-evenementiels__rappel--a-confirmer' : 'themes-evenementiels__rappel--confirme' ?>" aria-labelledby="themes-rappel-titre">
            <div class="themes-evenementiels__rappel-entete">
                <div>
                    <h2 id="themes-rappel-titre">Rappel annuel : confirmer les dates qui changent</h2>
                    <p>
                        Vérifiez les dates officielles de chaque événement lunaire pour <?= $anneeTheme ?>.
                        Chaque événement doit être confirmé séparément. Toute modification des dates réactive automatiquement son rappel.
                    </p>
                </div>
                <div class="themes-evenementiels__rappel-resume">
                    <strong><?= $nombreDatesAConfirmer > 0
                        ? $nombreDatesAConfirmer . ' événement' . ($nombreDatesAConfirmer > 1 ? 's' : '') . ' à confirmer'
                        : 'Dates confirmées pour ' . $anneeTheme ?></strong>
                    <?php if ($nombreDatesAConfirmer === 0): ?>
                        <form method="post">
                            <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_themes_evenementiels']) ?>">
                            <input type="hidden" name="action" value="hide_dates_reminder">
                            <button class="themes-evenementiels__bouton themes-evenementiels__bouton--secondaire" type="submit">Masquer le rappel jusqu’à l’an prochain</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <div class="themes-evenementiels__rappel-liste">
                <?php foreach ($themesDatesMobiles as $rappel):
                    $themeRappel = $rappel['theme'];
                ?>
                <div class="themes-evenementiels__rappel-ligne">
                    <div>
                        <strong><?= $e($themeRappel['name']) ?></strong>
                        <span>Dates configurées : <?= $e($themeRappel['start']) ?> au <?= $e($themeRappel['end']) ?></span>
                    </div>
                    <?php if ($rappel['confirme']): ?>
                        <span class="themes-evenementiels__rappel-etat themes-evenementiels__rappel-etat--confirme">Confirmées pour <?= $anneeTheme ?></span>
                    <?php else: ?>
                        <form method="post">
                            <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_themes_evenementiels']) ?>">
                            <input type="hidden" name="action" value="confirm_dates">
                            <input type="hidden" name="slug" value="<?= $e($themeRappel['slug']) ?>">
                            <button class="themes-evenementiels__bouton" type="submit">
                                Confirmer les dates pour <?= $anneeTheme ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <section class="themes-evenementiels__statut admin-panneau" aria-labelledby="themes-statut-titre">
            <div>
                <h2 id="themes-statut-titre">Diffusion automatique</h2>
                <p><?= $themeActif
                    ? 'Thème diffusé actuellement : ' . $themeActif['name'] . '.'
                    : 'Aucun thème événementiel n’est diffusé actuellement.' ?></p>
                <small>La période suit l’heure de Dakar. Les dates de début et de fin sont incluses.</small>
            </div>
            <form method="post">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_themes_evenementiels']) ?>">
                <input type="hidden" name="action" value="global">
                <input type="hidden" name="enabled" value="<?= $configuration['enabled'] ? '0' : '1' ?>">
                <button class="themes-evenementiels__bouton <?= $configuration['enabled'] ? 'themes-evenementiels__bouton--secondaire' : '' ?>" type="submit">
                    <?= $configuration['enabled'] ? 'Désactiver tous les thèmes' : 'Activer la diffusion' ?>
                </button>
            </form>
        </section>

        <section aria-labelledby="themes-liste-titre">
            <div class="themes-evenementiels__section-entete">
                <div>
                    <h2 id="themes-liste-titre">Thèmes configurés</h2>
                    <p>Les thèmes actifs sont départagés par priorité si leurs dates se chevauchent. Ajustez chaque année les dates lunaires (Ramadan, Korité, Tabaski, Magal et Tamkharit) selon les annonces officielles.</p>
                </div>
            </div>

            <?php if (!$configuration['themes']): ?>
                <div class="admin-panneau themes-evenementiels__vide">Aucun thème n’est configuré. Ajoutez-en un ci-dessous.</div>
            <?php endif; ?>

            <div class="themes-evenementiels__liste">
                <?php foreach ($configuration['themes'] as $theme):
                    $cssPath = __DIR__ . '/../../public/css/event-themes/' . $theme['slug'] . '.css';
                    $cssDisponible = is_file($cssPath);
                    $dansPeriode = $theme['start'] <= $theme['end']
                        ? $dateTheme >= $theme['start'] && $dateTheme <= $theme['end']
                        : $dateTheme >= $theme['start'] || $dateTheme <= $theme['end'];
                ?>
                <article class="admin-panneau themes-evenementiels__carte">
                    <div class="themes-evenementiels__carte-entete">
                        <div>
                            <h3><?= $e($theme['name']) ?></h3>
                            <code><?= $e($theme['slug']) ?></code>
                        </div>
                        <span class="themes-evenementiels__badge <?= $cssDisponible ? 'themes-evenementiels__badge--ok' : 'themes-evenementiels__badge--manquant' ?>">
                            <?= $cssDisponible ? 'CSS disponible' : 'CSS à créer' ?>
                        </span>
                    </div>
                    <form method="post" class="themes-evenementiels__formulaire">
                        <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_themes_evenementiels']) ?>">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="slug" value="<?= $e($theme['slug']) ?>">
                        <label>
                            Nom affiché
                            <input name="name" type="text" maxlength="60" required value="<?= $e($theme['name']) ?>">
                        </label>
                        <label>
                            Début (MM-JJ)
                            <input name="start" type="text" inputmode="numeric" pattern="(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])" required value="<?= $e($theme['start']) ?>">
                        </label>
                        <label>
                            Fin (MM-JJ)
                            <input name="end" type="text" inputmode="numeric" pattern="(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])" required value="<?= $e($theme['end']) ?>">
                        </label>
                        <label class="themes-evenementiels__message-souhait">
                            Message de souhait affiché sur l’accueil
                            <textarea name="greeting_message" maxlength="300" rows="3" placeholder="Laissez vide pour ne pas afficher de message."><?= $e($theme['greeting_message'] ?? '') ?></textarea>
                        </label>
                        <label class="themes-evenementiels__activation themes-evenementiels__message-souhait-toggle">
                            <input name="greeting_enabled" type="checkbox" value="1" <?= !empty($theme['greeting_enabled']) ? 'checked' : '' ?>>
                            <span>Afficher le message et son illustration sur l’accueil</span>
                        </label>
                        <label>
                            Priorité
                            <input name="priority" type="number" min="-1000" max="1000" required value="<?= (int) $theme['priority'] ?>">
                        </label>
                        <label class="themes-evenementiels__activation">
                            <input name="enabled" type="checkbox" value="1" <?= $theme['enabled'] ? 'checked' : '' ?>>
                            <span>Thème activé</span>
                        </label>
                        <label class="themes-evenementiels__activation">
                            <input name="animations" type="checkbox" value="1" <?= !empty($theme['animations']) ? 'checked' : '' ?>>
                            <span>Animations activées</span>
                        </label>
                        <div class="themes-evenementiels__actions">
                            <button class="themes-evenementiels__bouton" type="submit">Enregistrer</button>
                            <span class="themes-evenementiels__etat">
                                <?= !$theme['enabled'] ? 'Désactivé' : ($dansPeriode ? 'Dans la période' : 'Hors période') ?>
                            </span>
                        </div>
                    </form>
                    <form method="post" class="themes-evenementiels__suppression" onsubmit="return confirm('Supprimer définitivement ce thème ?');">
                        <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_themes_evenementiels']) ?>">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="slug" value="<?= $e($theme['slug']) ?>">
                        <button type="submit">Supprimer ce thème</button>
                    </form>
                </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="admin-panneau themes-evenementiels__ajout" aria-labelledby="themes-ajout-titre">
            <h2 id="themes-ajout-titre">Ajouter un thème</h2>
            <p>La feuille CSS correspondante devra être créée dans <code>public/css/event-themes/&lt;identifiant&gt;.css</code>.</p>
            <form method="post" class="themes-evenementiels__formulaire themes-evenementiels__formulaire--ajout">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_themes_evenementiels']) ?>">
                <input type="hidden" name="action" value="add">
                <label>
                    Nom affiché
                    <input name="name" type="text" maxlength="60" required placeholder="Ex. Nouvel an">
                </label>
                <label>
                    Identifiant CSS
                    <input name="slug" type="text" pattern="[a-z0-9]+(-[a-z0-9]+)*" maxlength="40" required placeholder="Ex. nouvel-an">
                </label>
                <label>
                    Début (MM-JJ)
                    <input name="start" type="text" inputmode="numeric" pattern="(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])" required placeholder="12-28">
                </label>
                <label>
                    Fin (MM-JJ)
                    <input name="end" type="text" inputmode="numeric" pattern="(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])" required placeholder="01-03">
                </label>
                <label>
                    Priorité
                    <input name="priority" type="number" min="-1000" max="1000" required value="10">
                </label>
                <label class="themes-evenementiels__message-souhait">
                    Message de souhait
                    <textarea name="greeting_message" maxlength="300" rows="3" placeholder="Message facultatif à afficher sur l’accueil."></textarea>
                </label>
                <label class="themes-evenementiels__activation themes-evenementiels__message-souhait-toggle">
                    <input name="greeting_enabled" type="checkbox" value="1" checked>
                    <span>Afficher le message et son illustration sur l’accueil</span>
                </label>
                <label class="themes-evenementiels__activation">
                    <input name="enabled" type="checkbox" value="1" checked>
                    <span>Activer à la création</span>
                </label>
                <label class="themes-evenementiels__activation">
                    <input name="animations" type="checkbox" value="1" checked>
                    <span>Activer les animations</span>
                </label>
                <button class="themes-evenementiels__bouton" type="submit">Ajouter le thème</button>
            </form>
        </section>
    </main>
</div>
</body>
</html>
