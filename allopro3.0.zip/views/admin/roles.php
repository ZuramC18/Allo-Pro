<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAdminConnecte();
require_once __DIR__ . '/../../models/RolePermission.php';

$model = new RolePermission();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $avant = $model->getMatrice();
    $model->enregistrer($_POST['perm'] ?? []);
    $apres = $model->getMatrice();

    $changements = [];
    foreach (ROLES_INTERNES as $r) {
        if ($r === 'admin') continue;
        foreach (array_keys(MODULES) as $mod) {
            $a = isset($avant[$r][$mod]);
            $b = isset($apres[$r][$mod]);
            if ($a !== $b) $changements[] = ($b ? '+ ' : '− ') . LIBELLES_ROLES[$r] . ' : ' . MODULES[$mod];
        }
    }
    if ($changements) journaliser('permissions.modifiees', 'roles', null, null, implode("\n", $changements));

    $_SESSION['flash_roles'] = "Permissions enregistrées.";
    header("Location: roles.php");
    exit;
}

$flash = $_SESSION['flash_roles'] ?? null;
unset($_SESSION['flash_roles']);

$matrice = $model->getMatrice();
$membres = $model->compterMembresParRole();
$rolesEditables = array_values(array_diff(ROLES_INTERNES, ['admin']));
$pagesModules = [
    'tableau_bord' => 'Accueil admin',
    'statistiques' => 'Statistiques',
    'demandes' => 'Demandes, attribution et traitement',
    'messagerie' => 'Messagerie client',
    'messagerie_interne' => 'Messagerie interne',
    'coordination' => 'Suivi des conversations',
    'interventions' => 'Liste des interventions',
    'sav' => 'Liste, détail et traitement SAV',
    'devis_entreprises' => 'Qualification technique et émission des devis entreprise',
    'remboursements_sav' => 'Autorisation des demandes de remboursement SAV',
    'paiements' => 'Paiements',
    'reversements' => 'Livre des comptes, partage des bénéfices, reversements et détails',
    'clients' => 'Liste des clients et fiches client',
    'partenaires' => 'Liste des partenaires et fiches partenaire',
    'techniciens' => 'Gestion des techniciens',
    'categories' => 'Catégories et tarifs',
    'abonnements' => 'Abonnements, Pass et détails des formules',
];
$libellesModulesAdmin = [
    'equipe' => 'Équipe ALLÔ PRO',
    'parametres' => 'Paramètres de la plateforme',
    'roles' => 'Rôles & permissions',
    'audit' => 'Journal d’audit',
    'quartiers' => 'Villes & quartiers',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Rôles & permissions — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .roles-table th, .roles-table td { text-align: center; }
        .roles-table th:first-child, .roles-table td:first-child { text-align: left; }
        .roles-module { display: block; }
        .roles-pages { display: block; margin-top: 3px; color: var(--admin-texte-discret); font-size: 11px; font-weight: 400; line-height: 1.45; }
        .roles-section td { padding-top: 13px; padding-bottom: 8px; color: var(--admin-violet); background: #F7F6FB; font-size: 11px; font-weight: 800; letter-spacing: .07em; text-align: left !important; text-transform: uppercase; }
        .roles-verrouille { color: var(--admin-texte-discret); }
        .roles-verrouille input { cursor: not-allowed !important; }
        .roles-intro { margin-bottom: 15px; color: var(--admin-texte-discret); font-size: 13px; line-height: 1.6; }
        .roles-legende { display: flex; flex-wrap: wrap; gap: 9px 18px; margin-top: 14px; color: var(--admin-texte-discret); font-size: 12px; }
        .roles-legende span { display: inline-flex; align-items: center; gap: 7px; }
        .roles-legende input { width: 15px; height: 15px; accent-color: var(--admin-violet); }
        .roles-table input[type=checkbox] { width: 18px; height: 18px; accent-color: var(--admin-violet); cursor: pointer; }
        .roles-table input[disabled] { cursor: not-allowed; opacity: 0.5; }
        .roles-sous { display: block; font-weight: 400; text-transform: none; letter-spacing: 0; font-size: 11px; color: var(--admin-texte-discret); margin-top: 2px; }
        .flash-ok { background: #E6F7ED; color: var(--admin-vert); padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; }
        .note-roles { font-size: 13px; color: var(--admin-texte-discret); line-height: 1.6; }
        .roles-enregistrer { margin-top: 20px; min-height: 46px; padding: 12px 28px; border: 0; border-radius: 8px; color: #fff; background: var(--admin-violet); font: inherit; font-weight: 700; cursor: pointer; }
        .roles-enregistrer:hover { filter: brightness(1.08); }
        .roles-enregistrer:focus-visible, .roles-table input:focus-visible { outline: 3px solid var(--admin-violet-clair); outline-offset: 3px; }
        .roles-table-wrap { width: 100%; }
        @media (max-width: 700px) {
            .roles-entete { display: none; }
            .roles-table-wrap { overflow: visible; }
            .roles-table, .roles-table tbody { display: block; width: 100%; }
            .roles-table tbody { display: grid; gap: 10px; }
            .roles-table tr:not(.roles-entete) {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                overflow: hidden;
                border: 1px solid var(--admin-bordure);
                border-radius: 12px;
                background: #fff;
            }
            .roles-table td { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-width: 0; padding: 9px 12px; border-bottom: 1px solid #F1F0F6; text-align: right; }
            .roles-table td:first-child { grid-column: 1 / -1; justify-content: flex-start; padding: 12px; background: #F7F6FB; text-align: left; }
            .roles-table td:first-child strong { overflow-wrap: anywhere; }
            .roles-table td:not(:first-child)::before { content: attr(data-role-label); overflow-wrap: anywhere; color: var(--admin-texte-discret); font-size: 11px; font-weight: 600; text-align: left; }
            .roles-table tr:not(.roles-entete) td:nth-last-child(-n + 2) { border-bottom: 0; }
            .roles-table input[type=checkbox] { flex: 0 0 20px; width: 20px; height: 20px; }
            .roles-enregistrer { width: 100%; }
            .admin-panneau { padding: 16px; }
            .admin-entete__titre { font-size: 20px; }
            .note-roles { font-size: 12.5px; }
        }
        @media (max-width: 380px) {
            .roles-table tr:not(.roles-entete) { grid-template-columns: minmax(0, 1fr); }
            .roles-table td:first-child { grid-column: 1; }
            .roles-table tr:not(.roles-entete) td:nth-last-child(2) { border-bottom: 1px solid #F1F0F6; }
        }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Rôles & permissions</div>
                <div class="admin-entete__sous-titre">Choisissez les modules accessibles à chaque rôle interne</div>
            </div>
        </div>

        <?php if ($flash): ?><div class="flash-ok"><?= htmlspecialchars($flash) ?></div><?php endif; ?>

        <div class="admin-panneau">
            <form method="POST">
                <p class="roles-intro">Chaque autorisation ouvre le module et les pages détaillées associées. Les accès internes de gestion de l’équipe et de sécurité restent exclusivement administrateur.</p>
                <div class="roles-table-wrap">
                    <table class="admin-table roles-table">
                        <caption class="sr-only">Permissions par module et par rôle interne</caption>
                        <tbody>
                        <tr class="roles-entete">
                            <th scope="col">Module</th>
                            <?php foreach ($rolesEditables as $r): ?>
                                <th scope="col"><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?><span class="roles-sous"><?= (int) ($membres[$r] ?? 0) ?> membre(s)</span></th>
                            <?php endforeach; ?>
                            <th scope="col">Administrateur<span class="roles-sous"><?= (int) ($membres['admin'] ?? 0) ?> membre(s)</span></th>
                        </tr>
                        <?php foreach (MODULES as $cle => $libelle): ?>
                        <tr>
                            <td>
                                <strong class="roles-module"><?= htmlspecialchars($libelle) ?></strong>
                                <span class="roles-pages"><?= htmlspecialchars($pagesModules[$cle] ?? '') ?></span>
                            </td>
                            <?php foreach ($rolesEditables as $r): ?>
                                <td data-role-label="<?= htmlspecialchars(LIBELLES_ROLES[$r]) ?>"><input type="checkbox" name="perm[<?= $r ?>][]" value="<?= $cle ?>" aria-label="<?= htmlspecialchars($libelle . ' — ' . LIBELLES_ROLES[$r]) ?>" <?= isset($matrice[$r][$cle]) ? 'checked' : '' ?>></td>
                            <?php endforeach; ?>
                            <td data-role-label="Administrateur"><input type="checkbox" checked disabled aria-label="<?= htmlspecialchars($libelle . ' — administrateur, toujours autorisé') ?>"></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr class="roles-section">
                            <td colspan="<?= count($rolesEditables) + 2 ?>">Pages réservées à l’administrateur</td>
                        </tr>
                        <?php foreach (MODULES_ADMIN_SEULEMENT as $moduleAdmin): ?>
                            <?php $libelleAdmin = $libellesModulesAdmin[$moduleAdmin] ?? $moduleAdmin; ?>
                            <tr>
                                <td>
                                    <strong class="roles-module"><?= htmlspecialchars($libelleAdmin) ?></strong>
                                    <span class="roles-pages">Accès non délégable</span>
                                </td>
                                <?php foreach ($rolesEditables as $r): ?>
                                    <td class="roles-verrouille" data-role-label="<?= htmlspecialchars(LIBELLES_ROLES[$r]) ?>">
                                        <input type="checkbox" disabled aria-label="<?= htmlspecialchars($libelleAdmin . ' — réservé à l’administrateur') ?>">
                                    </td>
                                <?php endforeach; ?>
                                <td data-role-label="Administrateur">
                                    <input type="checkbox" checked disabled aria-label="<?= htmlspecialchars($libelleAdmin . ' — administrateur, toujours autorisé') ?>">
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="roles-legende" aria-label="Légende des permissions">
                    <span><input type="checkbox" checked disabled aria-hidden="true"> Accessible au rôle</span>
                    <span><input type="checkbox" disabled aria-hidden="true"> Non autorisé ou accès réservé</span>
                </div>
                <button type="submit" class="roles-enregistrer">Enregistrer les permissions</button>
            </form>
        </div>

        <div class="admin-panneau">
            <div class="admin-panneau__titre">À savoir</div>
            <p class="note-roles">
                <?php foreach ($rolesEditables as $r): ?>
                    <strong><?= htmlspecialchars(LIBELLES_ROLES[$r]) ?></strong> : <?= htmlspecialchars(DESCRIPTIONS_ROLES[$r]) ?><br>
                <?php endforeach; ?>
                <br>
                <strong>Profil conseiller</strong> est accessible à chaque conseiller connecté : modifier son profil ou son mot de passe ne dépend pas des permissions de modules.<br>
                <strong>Équipe ALLÔ PRO, Paramètres, Rôles & permissions et Journal d’audit</strong> sont visibles dans la matrice, mais restent réservés à l’administrateur et ne peuvent pas être délégués.<br>
                <strong>Client, Partenaire et Technicien</strong> disposent chacun de leur propre espace de connexion et ne sont pas concernés par cette matrice.<br>
                Les changements s'appliquent dès le prochain chargement de page des membres concernés.
            </p>
        </div>
    </div>
</div>
</body>
</html>