<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAdminConnecte();

$rechercheOutils = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Outils — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/admin-outils.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin-outils.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu admin-outils">
        <?php
        $outilsParCategorie = [];
        foreach ($liensCatalogueOutils as $outil) {
            $categorie = match ($outil['categorie']) {
                "Vue d'ensemble", 'Vue d’ensemble' => "Vue d'ensemble",
                'Gestion' => 'Gestion',
                'Configuration' => 'Configuration',
                default => 'Opérations',
            };
            $outil['categorieAffichee'] = $categorie;
            $outilsParCategorie[$categorie][] = $outil;
        }
        ?>
        <header class="admin-outils__entete">
            <div>
                <p class="admin-outils__surtitre">ESPACE ADMINISTRATION</p>
                <h1>Outils</h1>
                <p>Retrouvez rapidement les outils de gestion et de suivi disponibles pour votre compte.</p>
            </div>
            <span class="admin-outils__compteur"><?= count($liensCatalogueOutils) ?> outils disponibles</span>
        </header>

        <div class="admin-outils__recherche">
            <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m16 16 4 4"></path></svg>
            <input id="recherche-catalogue-outils" type="search" value="<?= htmlspecialchars($rechercheOutils, ENT_QUOTES, 'UTF-8') ?>" placeholder="Rechercher par nom ou catégorie..." autocomplete="off" aria-label="Rechercher un outil">
            <button class="admin-outils__effacer" id="effacer-recherche-outils" type="button" aria-label="Effacer la recherche" hidden>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m18 6-12 12M6 6l12 12"></path></svg>
            </button>
            <kbd>Ctrl K</kbd>
        </div>
        <p class="admin-outils__resultat" id="nombre-resultats-outils" aria-live="polite"></p>

        <?php if ($liensCatalogueOutils): ?>
        <details class="admin-outils__reglages" id="reglages-outils">
            <summary>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z"></path><path d="m19.4 15 .1.1a1.8 1.8 0 1 1-2.5 2.5l-.1-.1a1.8 1.8 0 0 0-3 .9v.2a1.8 1.8 0 1 1-3.6 0v-.2a1.8 1.8 0 0 0-3-.9l-.1.1a1.8 1.8 0 1 1-2.5-2.5l.1-.1a1.8 1.8 0 0 0-.9-3h-.2a1.8 1.8 0 1 1 0-3.6h.2a1.8 1.8 0 0 0 .9-3l-.1-.1a1.8 1.8 0 1 1 2.5-2.5l.1.1a1.8 1.8 0 0 0 3-.9v-.2a1.8 1.8 0 1 1 3.6 0v.2a1.8 1.8 0 0 0 3 .9l.1-.1a1.8 1.8 0 1 1 2.5 2.5l-.1.1a1.8 1.8 0 0 0 .9 3h.2a1.8 1.8 0 1 1 0 3.6h-.2a1.8 1.8 0 0 0-.9 3Z"></path></svg>
                Préférences de recherche
                <span>Personnaliser l’ouverture des outils</span>
            </summary>
            <div class="admin-outils__reglages-contenu">
                <label class="admin-outils__option">
                    <input id="outils-nouvel-onglet" type="checkbox">
                    <span><strong>Ouvrir les outils dans un nouvel onglet</strong><small>Votre préférence s’applique aux raccourcis et aux résultats de recherche.</small></span>
                </label>
                <label class="admin-outils__option">
                    <input id="outils-afficher-populaires" type="checkbox" checked>
                    <span><strong>Afficher les outils les plus utilisés</strong><small>Les outils fréquents apparaissent avant le catalogue complet.</small></span>
                </label>
                <button class="admin-outils__reinitialiser" id="outils-reinitialiser" type="button">Réinitialiser l’historique d’utilisation</button>
                <span class="admin-outils__reglages-message" id="outils-reglages-message" role="status" aria-live="polite"></span>
            </div>
        </details>

        <section class="admin-outils__populaires" id="outils-populaires-section" aria-labelledby="outils-populaires-titre">
            <header class="admin-outils__section-entete">
                <div>
                    <h2 id="outils-populaires-titre">Les plus utilisés</h2>
                    <p>Vos raccourcis fréquents, accessibles en un clic.</p>
                </div>
                <span id="outils-populaires-info"></span>
            </header>
            <div class="admin-outils__grille admin-outils__grille--populaires" id="outils-populaires"></div>
        </section>

        <section class="admin-outils__catalogue" aria-labelledby="outils-catalogue-titre">
            <header class="admin-outils__section-entete">
                <div>
                    <h2 id="outils-catalogue-titre">Tous les outils</h2>
                    <p>Parcourez l’ensemble des modules disponibles dans votre espace.</p>
                </div>
            </header>
        <div id="catalogue-outils" aria-live="polite">
            <?php $indexCategorie = 0; foreach ($outilsParCategorie as $categorieOutils => $outilsCategorie):
                $idCategorie = 'outils-categorie-' . $indexCategorie++;
            ?>
            <section class="admin-outils__groupe" aria-labelledby="<?= $idCategorie ?>">
                <h3 class="admin-outils__groupe-titre" id="<?= $idCategorie ?>"><?= htmlspecialchars($categorieOutils, ENT_QUOTES, 'UTF-8') ?></h3>
                <div class="admin-outils__grille">
                <?php foreach ($outilsCategorie as $outil): ?>
                <a class="admin-outils__carte" href="<?= htmlspecialchars($outil['href'], ENT_QUOTES, 'UTF-8') ?>" data-outil-href="<?= htmlspecialchars($outil['href'], ENT_QUOTES, 'UTF-8') ?>" data-outil-titre="<?= htmlspecialchars($outil['titre'], ENT_QUOTES, 'UTF-8') ?>" data-outil-recherche="<?= htmlspecialchars(mb_strtolower($outil['titre'] . ' ' . $outil['categorie'], 'UTF-8'), ENT_QUOTES, 'UTF-8') ?>">
                    <span class="admin-outils__icone" aria-hidden="true"><?= $outil['icone'] ?></span>
                    <span class="admin-outils__texte">
                        <span class="admin-outils__categorie"><?= htmlspecialchars($outil['categorieAffichee'], ENT_QUOTES, 'UTF-8') ?></span>
                        <span class="admin-outils__titre"><?= htmlspecialchars($outil['titre'], ENT_QUOTES, 'UTF-8') ?></span>
                    </span>
                    <svg class="admin-outils__fleche" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"></path></svg>
                </a>
                <?php endforeach; ?>
                </div>
            </section>
            <?php endforeach; ?>
        </div>
        <p class="admin-outils__vide" id="catalogue-outils-vide" hidden>Aucun outil ne correspond à cette recherche.</p>
        </section>
        <?php else: ?>
        <p class="admin-outils__vide">Aucun outil n’est disponible pour votre compte.</p>
        <?php endif; ?>
    </main>
</div>
<script>
(function () {
    var champ = document.getElementById('recherche-catalogue-outils');
    var effacer = document.getElementById('effacer-recherche-outils');
    var grille = document.getElementById('catalogue-outils');
    var vide = document.getElementById('catalogue-outils-vide');
    var compteur = document.getElementById('nombre-resultats-outils');
    var sectionCatalogue = document.querySelector('.admin-outils__catalogue');
    var sectionPopulaires = document.getElementById('outils-populaires-section');
    var populaires = document.getElementById('outils-populaires');
    var populairesInfo = document.getElementById('outils-populaires-info');
    var nouvelOnglet = document.getElementById('outils-nouvel-onglet');
    var afficherPopulaires = document.getElementById('outils-afficher-populaires');
    var reinitialiser = document.getElementById('outils-reinitialiser');
    var messageReglages = document.getElementById('outils-reglages-message');
    if (!champ || !grille || !vide || !effacer || !compteur || !sectionCatalogue || !sectionPopulaires || !populaires) return;

    var cartes = Array.from(grille.querySelectorAll('[data-outil-recherche]'));
    var cleOnglet = 'allopro_admin_outils_nouvel_onglet';
    var clePopulaires = 'allopro_admin_outils_populaires';
    var cleUsage = 'allopro_admin_outils_utilisation';
    var ordreInitial = ['Tableau de bord', 'Demandes', 'Clients', 'Interventions', 'Paiements', 'Messagerie'];

    function lirePreference(cle, valeurDefaut) {
        try {
            var valeur = localStorage.getItem(cle);
            return valeur === null ? valeurDefaut : valeur === '1';
        } catch (erreur) {
            return valeurDefaut;
        }
    }

    function enregistrerPreference(cle, valeur) {
        try {
            localStorage.setItem(cle, valeur ? '1' : '0');
        } catch (erreur) {
            if (messageReglages) messageReglages.textContent = 'La préférence ne peut pas être enregistrée dans ce navigateur.';
        }
    }

    function lireUtilisation() {
        try {
            var donnees = JSON.parse(localStorage.getItem(cleUsage) || '{}');
            return donnees && typeof donnees === 'object' && !Array.isArray(donnees) ? donnees : {};
        } catch (erreur) {
            return {};
        }
    }

    function cleOutil(lien) {
        return new URL(lien.href, window.location.href).pathname;
    }

    function definirNouvelOnglet(actif) {
        document.querySelectorAll('.admin-sidebar details a.admin-sidebar__lien, .admin-sidebar__recherche-resultats a:not(.admin-sidebar__recherche-tout), .admin-outils__carte')
            .forEach(function (lien) {
                if (actif) {
                    lien.target = '_blank';
                    lien.rel = 'noopener noreferrer';
                } else {
                    lien.removeAttribute('target');
                    lien.removeAttribute('rel');
                }
            });
    }

    function afficherOutilsPopulaires() {
        populaires.replaceChildren();
        var utilisation = lireUtilisation();
        var ordre = new Map(ordreInitial.map(function (titre, index) { return [titre, index]; }));
        var tries = cartes.slice().sort(function (a, b) {
            var frequences = (Number(utilisation[cleOutil(b)]) || 0) - (Number(utilisation[cleOutil(a)]) || 0);
            if (frequences !== 0) return frequences;
            var ordreA = ordre.has(a.dataset.outilTitre) ? ordre.get(a.dataset.outilTitre) : 100;
            var ordreB = ordre.has(b.dataset.outilTitre) ? ordre.get(b.dataset.outilTitre) : 100;
            return ordreA - ordreB;
        });
        var selection = tries.slice(0, 6);
        selection.forEach(function (carte, index) {
            var copie = carte.cloneNode(true);
            copie.removeAttribute('hidden');
            copie.dataset.outilPopulaire = 'true';
            var utilisationOutil = Number(utilisation[cleOutil(carte)]) || 0;
            if (utilisationOutil > 0) {
                copie.dataset.outilRecherche = carte.dataset.outilRecherche;
                copie.title = utilisationOutil + (utilisationOutil === 1 ? ' utilisation' : ' utilisations');
            } else if (index === 0 && Object.keys(utilisation).length === 0) {
                copie.title = 'Outil recommandé';
            }
            populaires.appendChild(copie);
        });
        if (populairesInfo) {
            var aHistorique = Object.keys(utilisation).length > 0;
            populairesInfo.textContent = aHistorique ? 'Classés selon votre utilisation' : 'Sélection de départ';
        }
        definirNouvelOnglet(lirePreference(cleOnglet, false));
    }

    function filtrer() {
        var terme = champ.value.trim().toLocaleLowerCase('fr');
        var visibles = 0;
        cartes.forEach(function (carte) {
            var correspond = carte.dataset.outilRecherche.includes(terme);
            carte.hidden = !correspond;
            if (correspond) visibles++;
        });
        grille.querySelectorAll('.admin-outils__groupe').forEach(function (groupe) {
            groupe.hidden = !groupe.querySelector('[data-outil-recherche]:not([hidden])');
        });
        effacer.hidden = terme === '';
        compteur.textContent = visibles + (visibles === 1 ? ' outil trouvé' : ' outils trouvés');
        vide.hidden = visibles > 0;
        sectionPopulaires.hidden = terme !== '' || !lirePreference(clePopulaires, true);
        sectionCatalogue.hidden = false;
    }

    champ.addEventListener('input', filtrer);
    effacer.addEventListener('click', function () {
        champ.value = '';
        filtrer();
        champ.focus();
    });
    champ.addEventListener('keydown', function (evenement) {
        if (evenement.key === 'Escape') {
            champ.value = '';
            filtrer();
        }
    });
    document.addEventListener('keydown', function (evenement) {
        if ((evenement.ctrlKey || evenement.metaKey) && evenement.key.toLowerCase() === 'k') {
            evenement.preventDefault();
            champ.focus();
        }
    });

    if (nouvelOnglet) {
        nouvelOnglet.checked = lirePreference(cleOnglet, false);
        nouvelOnglet.addEventListener('change', function () {
            enregistrerPreference(cleOnglet, nouvelOnglet.checked);
            definirNouvelOnglet(nouvelOnglet.checked);
        });
    }
    if (afficherPopulaires) {
        afficherPopulaires.checked = lirePreference(clePopulaires, true);
        afficherPopulaires.addEventListener('change', function () {
            enregistrerPreference(clePopulaires, afficherPopulaires.checked);
            filtrer();
        });
    }
    if (reinitialiser && messageReglages) {
        reinitialiser.addEventListener('click', function () {
            try {
                localStorage.removeItem(cleUsage);
                messageReglages.textContent = 'Historique réinitialisé.';
                afficherOutilsPopulaires();
            } catch (erreur) {
                messageReglages.textContent = 'Impossible de réinitialiser l’historique dans ce navigateur.';
            }
        });
    }
    document.addEventListener('click', function (evenement) {
        var cible = evenement.target instanceof Element ? evenement.target : evenement.target.parentElement;
        var lien = cible && cible.closest('.admin-outils__carte');
        if (!lien) return;
        try {
            var utilisation = lireUtilisation();
            var cle = cleOutil(lien);
            utilisation[cle] = (Number(utilisation[cle]) || 0) + 1;
            localStorage.setItem(cleUsage, JSON.stringify(utilisation));
        } catch (erreur) {
            return;
        }
    });

    afficherOutilsPopulaires();
    definirNouvelOnglet(lirePreference(cleOnglet, false));
    filtrer();
})();
</script>
</body>
</html>
