<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('reversements');
require_once __DIR__ . '/../../models/LivreComptes.php';

$livre = new LivreComptes();
$aujourdhui = date('Y-m-d');
$premierJourMois = date('Y-m-01');
$normaliserDate = static function ($valeur, string $defaut): string {
    if (!is_string($valeur) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $valeur)) {
        return $defaut;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $valeur);
    return $date && $date->format('Y-m-d') === $valeur ? $valeur : $defaut;
};
$debut = $normaliserDate($_GET['debut'] ?? $premierJourMois, $premierJourMois);
$fin = $normaliserDate($_GET['fin'] ?? $aujourdhui, $aujourdhui);
$erreur = '';
if ($debut > $fin) {
    $erreur = 'La date de début doit précéder la date de fin.';
    $debut = $premierJourMois;
    $fin = $aujourdhui;
}

$categoriesDisponibles = [
    'toutes' => 'Toutes les opérations',
    'paiement' => 'Paiements de services',
    'pass' => 'Pass',
    'abonnement' => 'Abonnements',
    'reversement' => 'Reversements partenaires',
    'revenus' => 'Revenus encaissés',
];
$categorie = is_string($_GET['categorie'] ?? null) ? $_GET['categorie'] : 'toutes';
if (!isset($categoriesDisponibles[$categorie])) {
    $categorie = 'toutes';
}

$soldeAvant = $livre->getTotauxAvant($debut);
$ecritures = $livre->getEcritures($debut, $fin);
$encaissementsParMethode = $livre->getEncaissementsParMethode($debut, $fin);
$ecrituresAffichees = [];
$creditsPeriode = 0.0;
$debitsPeriode = 0.0;
$soldeCourant = $soldeAvant['credits'] - $soldeAvant['debits'];
foreach ($ecritures as $ecriture) {
    $ecriture['montant_credit'] = (float) $ecriture['montant_credit'];
    $ecriture['montant_debit'] = (float) $ecriture['montant_debit'];
    $soldeCourant += $ecriture['montant_credit'] - $ecriture['montant_debit'];
    $ecriture['solde'] = $soldeCourant;
    $creditsPeriode += $ecriture['montant_credit'];
    $debitsPeriode += $ecriture['montant_debit'];
    if (
        $categorie === 'toutes'
        || $ecriture['categorie'] === $categorie
        || ($categorie === 'revenus' && in_array($ecriture['categorie'], ['paiement', 'pass', 'abonnement'], true))
    ) {
        $ecrituresAffichees[] = $ecriture;
    }
}
$synthesePartenaires = $livre->getSynthesePartenaires();
$echapper = static fn($valeur) => htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
$formatMontant = static fn($valeur) => number_format((float) $valeur, 0, ',', ' ') . ' F';
$libellesCategories = [
    'paiement' => 'Paiement',
    'pass' => 'Pass',
    'abonnement' => 'Abonnement',
    'reversement' => 'Reversement',
];
$titrePage = ($_SESSION['role'] ?? '') === 'finance' && isset($financeTitrePage)
    ? $financeTitrePage
    : 'Livre des comptes';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $echapper($titrePage) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/livre-comptes.css?v=<?= filemtime(__DIR__ . '/../../public/css/livre-comptes.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <main class="admin-contenu livre-comptes">
        <header class="admin-entete livre-entete">
            <div>
                <div class="admin-entete__titre"><?= $echapper($titrePage) ?></div>
                <p class="admin-entete__sous-titre">Journal chronologique des encaissements et des reversements réellement payés.</p>
            </div>
            <a href="partage-benefices.php" class="livre-entete__lien">Gérer les parts partenaires <span aria-hidden="true">→</span></a>
        </header>

        <?php if ($erreur): ?>
            <div class="livre-alerte" role="alert"><?= $echapper($erreur) ?></div>
        <?php endif; ?>

        <form method="GET" class="livre-filtres" aria-label="Filtrer le journal comptable">
            <label>
                <span>Du</span>
                <input type="date" name="debut" value="<?= $echapper($debut) ?>" required>
            </label>
            <label>
                <span>Au</span>
                <input type="date" name="fin" value="<?= $echapper($fin) ?>" required>
            </label>
            <label class="livre-filtres__categorie">
                <span>Type d’opération</span>
                <select name="categorie">
                    <?php foreach ($categoriesDisponibles as $cle => $libelle): ?>
                        <option value="<?= $echapper($cle) ?>" <?= $categorie === $cle ? 'selected' : '' ?>><?= $echapper($libelle) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button type="submit">Afficher le journal</button>
        </form>

        <section class="livre-kpis" aria-label="Résumé financier de la période">
            <article class="livre-kpi">
                <span class="livre-kpi__icone livre-kpi__icone--bleu" aria-hidden="true">↓</span>
                <div><span class="livre-kpi__label">Encaissements sur la période</span><strong><?= $formatMontant($creditsPeriode) ?></strong></div>
            </article>
            <article class="livre-kpi">
                <span class="livre-kpi__icone livre-kpi__icone--rouge" aria-hidden="true">↑</span>
                <div><span class="livre-kpi__label">Reversements payés sur la période</span><strong><?= $formatMontant($debitsPeriode) ?></strong></div>
            </article>
            <article class="livre-kpi">
                <span class="livre-kpi__icone livre-kpi__icone--violet" aria-hidden="true">=</span>
                <div><span class="livre-kpi__label">Solde cumulé au <?= date('d/m/Y', strtotime($fin)) ?></span><strong><?= $formatMontant($soldeCourant) ?></strong></div>
            </article>
            <article class="livre-kpi">
                <span class="livre-kpi__icone livre-kpi__icone--ambre" aria-hidden="true">◷</span>
                <div><span class="livre-kpi__label">À reverser aux partenaires</span><strong><?= $formatMontant($synthesePartenaires['a_reverser']) ?></strong></div>
            </article>
        </section>

        <section class="livre-modes-paiement" aria-labelledby="livre-modes-paiement-titre">
            <header class="livre-modes-paiement__entete">
                <div>
                    <h2 id="livre-modes-paiement-titre">Montants reçus par mode de paiement</h2>
                    <p>Paiements de services validés du <?= date('d/m/Y', strtotime($debut)) ?> au <?= date('d/m/Y', strtotime($fin)) ?></p>
                </div>
                <span class="livre-modes-paiement__periode">Période sélectionnée</span>
            </header>
            <?php if ($encaissementsParMethode): ?>
                <div class="livre-modes-paiement__grille">
                    <?php foreach ($encaissementsParMethode as $encaissement):
                        $methode = (string) $encaissement['methode'];
                        $libellesMethodes = ['wave' => 'Wave', 'orange_money' => 'Orange Money', 'especes' => 'Espèces'];
                        $libelleMethode = $libellesMethodes[$methode] ?? ucfirst(str_replace('_', ' ', $methode));
                        $classeMethode = in_array($methode, ['wave', 'orange_money', 'especes'], true) ? $methode : 'autre';
                    ?>
                    <article class="livre-mode-carte">
                        <span class="livre-mode-carte__icone livre-mode-carte__icone--<?= $echapper($classeMethode) ?>" aria-hidden="true">
                            <?php if ($methode === 'wave' || $methode === 'orange_money'): ?>
                                <img src="../../public/images/paiements/<?= $methode === 'wave' ? 'wave-logo.png' : 'orange-money-logo.svg' ?>" alt="">
                            <?php else: ?>
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/></svg>
                            <?php endif; ?>
                        </span>
                        <div class="livre-mode-carte__contenu">
                            <span class="livre-mode-carte__libelle"><?= $echapper($libelleMethode) ?></span>
                            <strong><?= $formatMontant($encaissement['montant']) ?></strong>
                            <span class="livre-mode-carte__nombre"><?= number_format((int) $encaissement['nombre'], 0, ',', ' ') ?> paiement<?= (int) $encaissement['nombre'] === 1 ? '' : 's' ?></span>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="livre-modes-paiement__vide">Aucun paiement de service validé sur cette période.</p>
            <?php endif; ?>
            <p class="livre-modes-paiement__note">Les achats de Pass et d’abonnements sont comptabilisés dans les encaissements globaux, mais ne sont pas répartis ici car leur mode de paiement n’est pas enregistré dans le journal comptable.</p>
        </section>

        <section class="livre-resume">
            <div><span>Solde d’ouverture au <?= date('d/m/Y', strtotime($debut)) ?></span><strong><?= $formatMontant($soldeAvant['credits'] - $soldeAvant['debits']) ?></strong></div>
            <div><span>Commissions ALLÔ PRO calculées</span><strong><?= $formatMontant($synthesePartenaires['commissions_calculees']) ?></strong></div>
            <p>Le solde suit les encaissements validés (paiements, Pass et abonnements) moins les reversements marqués comme payés. Les commissions sont informatives et ne sont pas ajoutées une seconde fois au solde. Les parts dues aux partenaires sont suivies séparément.</p>
        </section>

        <section class="admin-panneau livre-journal" aria-labelledby="livre-journal-titre">
            <header class="livre-journal__entete">
                <div>
                    <h2 id="livre-journal-titre">Journal des opérations</h2>
                    <p><?= count($ecrituresAffichees) ?> opération<?= count($ecrituresAffichees) === 1 ? '' : 's' ?> affichée<?= count($ecrituresAffichees) === 1 ? '' : 's' ?> · du <?= date('d/m/Y', strtotime($debut)) ?> au <?= date('d/m/Y', strtotime($fin)) ?> · le filtre de type ne modifie pas le solde courant</p>
                </div>
                <a href="livre-comptes.php" class="livre-journal__reset">Réinitialiser</a>
            </header>
            <div class="livre-journal__scroll">
                <table class="admin-table">
                    <thead>
                        <tr><th>Date</th><th>Opération</th><th>Tiers</th><th>Référence</th><th>Débit</th><th>Crédit</th><th>Solde après opération</th></tr>
                    </thead>
                    <tbody>
                    <?php if (!$ecrituresAffichees): ?>
                        <tr><td colspan="7" class="livre-journal__vide">Aucune opération validée sur cette période.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($ecrituresAffichees as $ecriture): ?>
                        <tr>
                            <td class="livre-date"><?= date('d/m/Y H:i', strtotime($ecriture['date_operation'])) ?></td>
                            <td><span class="livre-type livre-type--<?= $echapper($ecriture['categorie']) ?>"><?= $echapper($libellesCategories[$ecriture['categorie']] ?? $ecriture['categorie']) ?></span><strong class="livre-libelle"><?= $echapper($ecriture['libelle']) ?></strong></td>
                            <td><?= $echapper($ecriture['tiers'] ?: '—') ?></td>
                            <td class="livre-reference"><?= $echapper($ecriture['reference'] ?: '—') ?></td>
                            <td class="livre-debit"><?= $ecriture['montant_debit'] > 0 ? $formatMontant($ecriture['montant_debit']) : '—' ?></td>
                            <td class="livre-credit"><?= $ecriture['montant_credit'] > 0 ? $formatMontant($ecriture['montant_credit']) : '—' ?></td>
                            <td class="livre-solde"><?= $formatMontant($ecriture['solde']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <?php if ($ecrituresAffichees): ?>
                    <tfoot>
                        <tr><th colspan="4">Totaux de la période · toutes opérations</th><th><?= $formatMontant($debitsPeriode) ?></th><th><?= $formatMontant($creditsPeriode) ?></th><th><?= $formatMontant($soldeCourant) ?></th></tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </section>
    </main>
</div>
</body>
</html>
