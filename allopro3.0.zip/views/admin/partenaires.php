<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('partenaires');
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$partenaireModel = new Partenaire();
$recherche = trim($_GET['q'] ?? '');
$niveauFiltre = $_GET['niveau'] ?? '';
$partenaires = $partenaireModel->getAllAvecStats($recherche ?: null, $niveauFiltre ?: null);

$labelsNiveaux = ['partenaire' => ['Partenaire', 'gris'], 'certifie' => ['Certifié', 'violet'], 'premium' => ['Premium', 'amber'], 'excellence' => ['Excellence', 'vert']];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Partenaires — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/partenaires-admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Partenaires</div>
                <div class="admin-entete__sous-titre"><?= count($partenaires) ?> partenaire<?= count($partenaires) > 1 ? 's' : '' ?></div>
            </div>
        </div>

        <form method="GET" class="admin-recherche partenaires-recherche">
            <input type="search" name="q" aria-label="Rechercher un partenaire" placeholder="Entreprise ou email..." value="<?= htmlspecialchars($recherche) ?>">
            <select name="niveau" aria-label="Filtrer par niveau">
                <option value="">Tous les niveaux</option>
                <?php foreach ($labelsNiveaux as $val => $l): ?>
                    <option value="<?= $val ?>" <?= $niveauFiltre === $val ? 'selected' : '' ?>><?= $l[0] ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Rechercher</button>
            <?php if ($recherche || $niveauFiltre): ?><a href="partenaires.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau partenaires-panneau">
            <table class="admin-table partenaires-table">
                <thead>
                    <tr><th scope="col">Entreprise</th><th scope="col">Zone</th><th scope="col">Techniciens</th><th scope="col">Missions</th><th scope="col">Score</th><th scope="col">Niveau</th><th scope="col">Statut</th><th scope="col" aria-label="Action"></th></tr>
                </thead>
                <tbody>
                <?php if (empty($partenaires)): ?>
                    <tr class="partenaires-table__vide"><td colspan="8">Aucun partenaire trouvé.</td></tr>
                <?php endif; ?>
                <?php foreach ($partenaires as $p):
                    $niv = $labelsNiveaux[$p['niveau']] ?? ['—','gris'];
                    $photoProfil = AvatarProfil::estValide($p['photo_profil'] ?? null, 'partenaires')
                        ? (string) $p['photo_profil']
                        : null;
                    $avatarInitiales = !empty($p['avatar_initiales']);
                    $initialesPartenaire = AvatarProfil::initiales((string) $p['nom_entreprise']);
                ?>
                <tr class="partenaires-table__ligne" tabindex="0" aria-label="Ouvrir la fiche de <?= htmlspecialchars($p['nom_entreprise'], ENT_QUOTES, 'UTF-8') ?>" data-href="partenaire-detail.php?id=<?= (int) $p['id'] ?>">
                    <td class="partenaires-table__entreprise">
                        <div class="partenaires-table__identite">
                            <div class="partenaires-table__avatar" aria-hidden="true">
                                <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                                    <img src="../../public/<?= htmlspecialchars($photoProfil, ENT_QUOTES, 'UTF-8') ?>" alt="">
                                <?php elseif ($avatarInitiales): ?>
                                    <?= htmlspecialchars($initialesPartenaire, ENT_QUOTES, 'UTF-8') ?>
                                <?php else: ?>
                                    <svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V5h14v16M9 8h2m2 0h2M9 12h2m2 0h2M10 21v-5h4v5M3 5h18l-2-3H5L3 5Z"/></svg>
                                <?php endif; ?>
                            </div>
                            <div class="partenaires-table__identite-texte">
                                <strong><?= htmlspecialchars($p['nom_entreprise']) ?></strong>
                                <span><?= htmlspecialchars($p['email']) ?></span>
                            </div>
                        </div>
                    </td>
                    <td data-label="Zones"><?= htmlspecialchars($p['zones_intervention'] ?: '—') ?></td>
                    <td data-label="Techniciens"><?= (int) $p['nb_techniciens'] ?></td>
                    <td data-label="Missions">
                        <?= (int) $p['nb_missions'] ?>
                        <?php if ((int) $p['nb_missions_actives'] > 0): ?>
                            <span class="partenaires-table__actives">(<?= (int) $p['nb_missions_actives'] ?> en cours)</span>
                        <?php endif; ?>
                    </td>
                    <td data-label="Score"><?= $p['score'] > 0 ? number_format((float) $p['score'], 1) . '/5' : '—' ?></td>
                    <td data-label="Niveau"><span class="admin-badge admin-badge--<?= $niv[1] ?>"><?= htmlspecialchars($niv[0]) ?></span></td>
                    <td data-label="Statut"><span class="admin-badge admin-badge--<?= $p['statut'] === 'actif' ? 'vert' : 'rouge' ?>"><?= $p['statut'] === 'actif' ? 'Actif' : 'Inactif' ?></span></td>
                    <td class="partenaires-table__action"><a href="partenaire-detail.php?id=<?= (int) $p['id'] ?>">Voir la fiche <span aria-hidden="true">→</span></a></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    document.querySelectorAll('.partenaires-table__ligne[data-href]').forEach((ligne) => {
        ligne.addEventListener('click', (evenement) => {
            if (evenement.target.closest('a, button, form, input, select, textarea, [contenteditable="true"]')) return;
            window.location.href = ligne.dataset.href;
        });
        ligne.addEventListener('keydown', (evenement) => {
            if (evenement.target !== ligne || (evenement.key !== 'Enter' && evenement.key !== ' ')) return;
            evenement.preventDefault();
            window.location.href = ligne.dataset.href;
        });
    });
</script>
</body>
</html>