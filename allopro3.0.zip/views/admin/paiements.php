<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('paiements');
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/Partenaire.php';

$paiementModel = new Paiement();
$statutFiltre = $_GET['statut'] ?? '';
$methodeFiltre = $_GET['methode'] ?? '';
$recherche = $_GET['recherche'] ?? '';

if (!is_string($statutFiltre)) $statutFiltre = '';
if (!is_string($methodeFiltre)) $methodeFiltre = '';
if (!is_string($recherche)) $recherche = '';
$recherche = mb_substr(trim($recherche), 0, 100);

$paiements = $paiementModel->getAllAvecFiltres($statutFiltre ?: null, $methodeFiltre ?: null, $recherche ?: null);
$sommes = $paiementModel->sommeParStatut();
$sommeMois = $paiementModel->sommeMoisEnCours();
$parMethode = $paiementModel->sommeParMethode();
$reversementsDus = (new Partenaire())->getReversementsDus();
$lienFiltresHistorique = http_build_query(array_filter([
    'statut' => $statutFiltre,
    'methode' => $methodeFiltre,
    'recherche' => $recherche,
], static fn($valeur) => $valeur !== ''));
$lienHistorique = 'historique-paiements.php' . ($lienFiltresHistorique !== '' ? '?' . $lienFiltresHistorique : '');
$historiqueScrollable = count($paiements) >= 10;
$titrePaiements = ($_SESSION['role'] ?? '') === 'finance' && $statutFiltre === 'echoue'
    ? 'Paiements échoués'
    : (($_SESSION['role'] ?? '') === 'finance' ? 'Paiements clients' : 'Paiements & Finance');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Paiements — ALLÔ PRO <?= ($_SESSION['role'] ?? '') === 'finance' ? 'Finance' : 'Admin' ?></title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/paiements-admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/paiements-admin.css') ?>">
</head>
<body class="page-admin-paiements">
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre"><?= htmlspecialchars($titrePaiements, ENT_QUOTES, 'UTF-8') ?></div>
                <div class="admin-entete__sous-titre">Suivez les encaissements et les reversements partenaires</div>
            </div>
            <a href="partage-benefices.php" class="paiements-lien-partage">Gérer Pass &amp; abonnements <span aria-hidden="true">→</span></a>
        </div>

        <div class="admin-kpi-grille paiements-kpi-grille">
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7h18v13H3z"/><path d="M3 7l2-3h14l2 3M7 13h4"/></svg></div><div class="admin-kpi-carte__label">Chiffre d’affaires du mois</div><div class="admin-kpi-carte__valeur"><?= number_format($sommeMois, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></div><div class="paiements-kpi-note">Encaissements validés ce mois</div></div>
            <div class="admin-kpi-carte admin-kpi-carte--vert"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/></svg></div><div class="admin-kpi-carte__label">Paiements validés · <?= (int) $sommes['valide']['nb'] ?></div><div class="admin-kpi-carte__valeur"><?= number_format($sommes['valide']['total'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--amber"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div><div class="admin-kpi-carte__label">En attente · <?= (int) $sommes['en_attente']['nb'] ?></div><div class="admin-kpi-carte__valeur"><?= number_format($sommes['en_attente']['total'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></div></div>
            <div class="admin-kpi-carte admin-kpi-carte--rouge"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m9 9 6 6m0-6-6 6"/></svg></div><div class="admin-kpi-carte__label">Échoués · <?= (int) $sommes['echoue']['nb'] ?></div><div class="admin-kpi-carte__valeur"><?= number_format($sommes['echoue']['total'], 0, ',', ' ') ?> <small>F&nbsp;CFA</small></div></div>
            <?php require_once __DIR__ . '/../../models/Reversement.php'; $margeMois = (new Reversement())->margeMoisEnCours(); ?>
            <div class="admin-kpi-carte admin-kpi-carte--violet"><div class="admin-kpi-carte__icone" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V5m0 14h16"/><path d="m7 14 4-4 3 3 5-7"/></svg></div><div class="admin-kpi-carte__label">Marge du mois</div><div class="admin-kpi-carte__valeur"><?= number_format($margeMois, 0, ',', ' ') ?> <small>F&nbsp;CFA</small></div><div class="paiements-kpi-note">Après reversements enregistrés</div></div>
        </div>

        <div class="paiements-grille">
            <section class="paiements-transactions" aria-labelledby="paiements-titre-transactions">
                <form method="GET" class="paiements-filtres">
                    <label class="paiements-filtres__recherche">
                        <span>Rechercher</span>
                        <span class="paiements-recherche__champ">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
                            <input type="search" name="recherche" value="<?= htmlspecialchars($recherche, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" placeholder="Référence, dossier ou client">
                        </span>
                    </label>
                    <label class="paiements-filtres__champ">
                        <span>Filtrer par statut</span>
                        <select name="statut" onchange="this.form.submit()">
                        <option value="">Tous les statuts</option>
                        <option value="valide" <?= $statutFiltre === 'valide' ? 'selected' : '' ?>>Validé</option>
                        <option value="en_attente" <?= $statutFiltre === 'en_attente' ? 'selected' : '' ?>>En attente</option>
                        <option value="echoue" <?= $statutFiltre === 'echoue' ? 'selected' : '' ?>>Échoué</option>
                        </select>
                    </label>
                    <label class="paiements-filtres__champ">
                        <span>Filtrer par méthode</span>
                        <select name="methode" onchange="this.form.submit()">
                        <option value="">Toutes méthodes</option>
                        <option value="wave" <?= $methodeFiltre === 'wave' ? 'selected' : '' ?>>Wave</option>
                        <option value="orange_money" <?= $methodeFiltre === 'orange_money' ? 'selected' : '' ?>>Orange Money</option>
                        <option value="especes" <?= $methodeFiltre === 'especes' ? 'selected' : '' ?>>Espèces</option>
                        </select>
                    </label>
                    <button type="submit" class="paiements-filtres__submit">Rechercher</button>
                    <?php if ($statutFiltre || $methodeFiltre || $recherche): ?><a href="paiements.php" class="paiements-filtres__reset">Réinitialiser</a><?php endif; ?>
                </form>

                <div class="admin-panneau paiements-tableau">
                    <div class="admin-panneau__titre paiements-tableau__titre">
                        <span id="paiements-titre-transactions">Historique des transactions</span>
                        <div class="paiements-tableau__actions">
                            <span class="paiements-tableau__compte"><?= count($paiements) ?> transaction<?= count($paiements) === 1 ? '' : 's' ?> récente<?= count($paiements) === 1 ? '' : 's' ?></span>
                            <a class="paiements-historique-lien" href="<?= htmlspecialchars($lienHistorique, ENT_QUOTES, 'UTF-8') ?>">Voir tout l’historique <span aria-hidden="true">→</span></a>
                        </div>
                    </div>
                    <div class="paiements-tableau__defilement<?= $historiqueScrollable ? ' paiements-tableau__defilement--vertical' : '' ?>" role="region" aria-label="Historique récent des transactions, défilement possible" tabindex="0">
                    <table class="admin-table paiements-table">
                        <thead><tr><th>Référence</th><th>Dossier</th><th>Client</th><th>Méthode</th><th>Montant</th><th>Statut</th><th>Date</th></tr></thead>
                        <tbody>
                        <?php if (empty($paiements)): ?>
                            <tr><td colspan="7" class="paiements-table__vide">Aucun paiement ne correspond à ces filtres.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($paiements as $p): ?>
                        <tr>
                            <td class="paiements-table__reference"><?= htmlspecialchars($p['reference_transaction']) ?></td>
                            <td><strong><?= htmlspecialchars($p['numero_dossier']) ?></strong></td>
                            <td><?= htmlspecialchars($p['client_nom']) ?></td>
                            <td><?= htmlspecialchars($p['methode'] === 'especes' ? 'Espèces' : ucfirst(str_replace('_', ' ', $p['methode']))) ?></td>
                            <td class="paiements-table__montant"><?= number_format($p['montant'], 0, ',', ' ') ?> F</td>
                            <td><span class="admin-badge admin-badge--<?= $p['statut'] === 'valide' ? 'vert' : ($p['statut'] === 'en_attente' ? 'amber' : 'rouge') ?>"><?= htmlspecialchars(['valide' => 'Validé', 'en_attente' => 'En attente', 'echoue' => 'Échoué'][$p['statut']] ?? $p['statut']) ?></span></td>
                            <td><?= date('d/m/Y H:i', strtotime($p['date_paiement'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </section>

            <aside class="paiements-side">
                <section class="admin-panneau paiements-resume">
                    <div class="admin-panneau__titre">Répartition encaissée par méthode</div>
                    <?php foreach ($parMethode as $m): ?>
                        <div class="paiements-resume__ligne">
                            <span><?= htmlspecialchars($m['methode'] === 'especes' ? 'Espèces' : ucfirst(str_replace('_', ' ', $m['methode']))) ?></span>
                            <strong><?= number_format($m['total'], 0, ',', ' ') ?> F</strong>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($parMethode)): ?><p class="paiements-texte-vide">Aucun encaissement validé pour le moment.</p><?php endif; ?>
                </section>

                <section class="admin-panneau paiements-resume">
                    <div class="admin-panneau__titre">Reversements à effectuer</div>
                    <?php if (empty($reversementsDus)): ?>
                        <p class="paiements-texte-vide">Aucun reversement dû actuellement.</p>
                    <?php endif; ?>
                    <?php foreach ($reversementsDus as $r): ?>
                        <div class="paiements-reversement">
                            <span class="paiements-reversement__partenaire"><?= htmlspecialchars($r['nom_entreprise']) ?><small><?= (int) $r['nb_missions'] ?> mission<?= (int) $r['nb_missions'] === 1 ? '' : 's' ?></small></span>
                            <a href="creer-reversement.php?partenaire_id=<?= (int) $r['id'] ?>" class="paiements-reversement__action"><strong><?= number_format($r['montant_du'], 0, ',', ' ') ?> F</strong><span aria-hidden="true">→</span><span class="sr-only">Créer un reversement pour <?= htmlspecialchars($r['nom_entreprise'], ENT_QUOTES, 'UTF-8') ?></span></a>
                        </div>
                    <?php endforeach; ?>
                </section>
            </aside>
        </div>
    </div>
</div>
</body>
</html>