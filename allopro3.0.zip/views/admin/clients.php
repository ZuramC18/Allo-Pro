<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAcces('clients');
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$userModel = new User();
$recherche = trim($_GET['q'] ?? '');
$clients = $userModel->getAllClients($recherche ?: null);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clients — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/clients-admin.css">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>

    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Clients</div>
                <div class="admin-entete__sous-titre"><?= count($clients) ?> client<?= count($clients) > 1 ? 's' : '' ?> <?= $recherche ? 'trouvé(s)' : 'au total' ?></div>
            </div>
        </div>

        <form method="GET" class="admin-recherche clients-recherche">
            <input type="search" name="q" aria-label="Rechercher un client" placeholder="Nom, email ou téléphone..." value="<?= htmlspecialchars($recherche) ?>">
            <button type="submit">Rechercher</button>
            <?php if ($recherche): ?><a href="clients.php" class="admin-recherche__reset">Réinitialiser</a><?php endif; ?>
        </form>

        <div class="admin-panneau clients-panneau">
            <table class="admin-table clients-table">
                <thead>
                    <tr>
                        <th scope="col">Client</th><th scope="col">Contact</th><th scope="col">Dossiers</th><th scope="col">En cours</th><th scope="col">Inscrit le</th><th scope="col">Statut</th><th scope="col"><span class="visually-hidden">Action</span></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($clients)): ?>
                    <tr class="clients-table__empty"><td colspan="7">Aucun client trouvé.</td></tr>
                <?php endif; ?>
                <?php foreach ($clients as $c): ?>
                <tr class="clients-table__row" tabindex="0" aria-label="Ouvrir la fiche de <?= htmlspecialchars(trim($c['prenom'] . ' ' . $c['nom']), ENT_QUOTES, 'UTF-8') ?>" data-href="client-detail.php?id=<?= (int) $c['id'] ?>">
                    <td class="clients-table__identity">
                        <div class="clients-table__person">
                            <div class="clients-table__avatar">
                                <?php
                                $photoProfil = AvatarProfil::estValide($c['photo_profil'] ?? null, 'clients')
                                    ? (string) $c['photo_profil']
                                    : null;
                                $avatarInitiales = !empty($c['avatar_initiales']);
                                $initialesClient = AvatarProfil::initiales(trim((string) ($c['prenom'] ?? '') . ' ' . (string) ($c['nom'] ?? '')));
                                ?>
                                <?php if (!$avatarInitiales && $photoProfil !== null): ?>
                                    <img src="../../public/<?= htmlspecialchars($photoProfil, ENT_QUOTES, 'UTF-8') ?>" alt="">
                                <?php elseif ($avatarInitiales): ?>
                                    <?= htmlspecialchars($initialesClient, ENT_QUOTES, 'UTF-8') ?>
                                <?php else: ?>
                                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                                <?php endif; ?>
                            </div>
                            <span><strong><?= htmlspecialchars($c['nom']) ?></strong> <strong><?= htmlspecialchars($c['prenom']) ?></strong></span>
                        </div>
                    </td>
                    <td class="clients-table__contact">
                        <span><?= htmlspecialchars($c['telephone'] ?: '—') ?></span>
                        <span><?= htmlspecialchars($c['email']) ?></span>
                    </td>
                    <td class="clients-table__metric" data-label="Dossiers"><?= (int) $c['nb_demandes'] ?></td>
                    <td class="clients-table__metric" data-label="En cours"><?= $c['nb_actives'] > 0 ? "<span class='admin-badge admin-badge--amber'>" . (int) $c['nb_actives'] . "</span>" : '—' ?></td>
                    <td class="clients-table__metric" data-label="Inscrit le"><?= date('d/m/Y', strtotime($c['date_creation'])) ?></td>
                    <td class="clients-table__status" data-label="Statut"><span class="admin-badge admin-badge--<?= $c['statut'] === 'actif' ? 'vert' : 'rouge' ?>"><?= $c['statut'] === 'actif' ? 'Actif' : 'Suspendu' ?></span></td>
                    <td class="clients-table__action"><a href="client-detail.php?id=<?= (int) $c['id'] ?>">Voir le dossier <span aria-hidden="true">→</span></a></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    document.querySelectorAll('.clients-table__row[data-href]').forEach((ligne) => {
        ligne.addEventListener('click', (evenement) => {
            if (evenement.target.closest('a, button, form, input, select, textarea, [contenteditable="true"]')) return;
            window.location.href = ligne.dataset.href;
        });
        ligne.addEventListener('keydown', (evenement) => {
            if (evenement.target !== ligne || (evenement.key !== 'Enter' && evenement.key !== ' ')) return;
            evenement.preventDefault();
            window.location.href = ligne.dataset.href;
        });
    });
</script>
</body>
</html>