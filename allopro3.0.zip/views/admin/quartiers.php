<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
verifierAdminConnecte();
require_once __DIR__ . '/../../models/Zone.php';

$zoneModel = new Zone();
$villes = $zoneModel->getVillesActives();
$erreur = '';
$villeFiltre = filter_var($_GET['ville_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$villeFiltre = $villeFiltre === false ? null : (int) $villeFiltre;
$recherche = trim(is_string($_GET['q'] ?? null) ? $_GET['q'] : '');
$statutFiltre = is_string($_GET['statut'] ?? null) && in_array($_GET['statut'], ['active', 'inactive'], true)
    ? $_GET['statut']
    : 'tous';
$tri = is_string($_GET['tri'] ?? null) && in_array($_GET['tri'], ['ville_asc', 'quartier_asc', 'quartier_desc'], true)
    ? $_GET['tri']
    : 'ville_asc';

if (empty($_SESSION['csrf_quartiers'])) {
    $_SESSION['csrf_quartiers'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_quartiers'], $csrf)) {
        http_response_code(403);
        $erreur = 'Le formulaire a expiré. Rechargez la page et réessayez.';
    } elseif (($_POST['action'] ?? '') === 'ajouter') {
        $villeId = filter_var($_POST['ville_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $nom = trim(is_string($_POST['nom'] ?? null) ? $_POST['nom'] : '');
        if ($villeId === false || $nom === '' || mb_strlen($nom) > 100) {
            $erreur = 'Choisissez une ville et saisissez un nom de 100 caractères maximum.';
        } else {
            try {
                if (!$zoneModel->ajouterQuartier((int) $villeId, $nom)) {
                    $erreur = 'Cette ville est indisponible ou le quartier n’a pas pu être ajouté.';
                } else {
                    journaliser('zone.quartier_ajoute', 'zone', null, $nom, 'Ville ID ' . (int) $villeId);
                    $_SESSION['flash_quartiers'] = 'Le quartier a été ajouté.';
                    header('Location: quartiers.php?' . http_build_query(['ville_id' => (int) $villeId, 'tri' => $tri]));
                    exit;
                }
            } catch (PDOException $exception) {
                if ((string) $exception->getCode() === '23000') {
                    $erreur = 'Un quartier portant ce nom existe déjà dans cette ville.';
                } else {
                    error_log('Ajout de quartier : ' . $exception->getMessage());
                    $erreur = 'Le quartier n’a pas pu être ajouté. Réessayez.';
                }
            }
        }
    } elseif (($_POST['action'] ?? '') === 'changer_statut') {
        $id = filter_var($_POST['zone_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $statut = ($_POST['statut'] ?? '') === 'inactive' ? 'inactive' : 'active';
        if ($id === false || !$zoneModel->changerStatut((int) $id, $statut)) {
            $erreur = 'Le statut du quartier n’a pas pu être modifié.';
        } else {
            journaliser('zone.quartier_statut_modifie', 'zone', (int) $id, null, $statut);
            $_SESSION['flash_quartiers'] = $statut === 'active' ? 'Le quartier est maintenant actif.' : 'Le quartier a été désactivé.';
            $retourVille = filter_var($_POST['retour_ville_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            $retourVille = $retourVille === false ? null : (int) $retourVille;
            $retourRecherche = trim(is_string($_POST['retour_q'] ?? null) ? $_POST['retour_q'] : '');
            $retourStatut = is_string($_POST['retour_statut'] ?? null) && in_array($_POST['retour_statut'], ['active', 'inactive'], true)
                ? $_POST['retour_statut']
                : 'tous';
            $retourTri = is_string($_POST['retour_tri'] ?? null) && in_array($_POST['retour_tri'], ['ville_asc', 'quartier_asc', 'quartier_desc'], true)
                ? $_POST['retour_tri']
                : 'ville_asc';
            $filtresRetour = array_filter([
                'ville_id' => $retourVille,
                'q' => $retourRecherche,
                'statut' => $retourStatut === 'tous' ? null : $retourStatut,
                'tri' => $retourTri === 'ville_asc' ? null : $retourTri,
            ], static fn($valeur): bool => $valeur !== null && $valeur !== '');
            header('Location: quartiers.php' . ($filtresRetour ? '?' . http_build_query($filtresRetour) : ''));
            exit;
        }
    } else {
        $erreur = 'Action non reconnue.';
    }
}

$villesActivesIds = array_map('intval', array_column($villes, 'id'));
$villeAjoutId = $villeFiltre !== null && in_array($villeFiltre, $villesActivesIds, true)
    ? $villeFiltre
    : ($villesActivesIds[0] ?? null);
$quartiers = $zoneModel->rechercherQuartiers($villeFiltre, $recherche, $statutFiltre, $tri);
$flash = $_SESSION['flash_quartiers'] ?? '';
unset($_SESSION['flash_quartiers']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Villes & quartiers — ALLÔ PRO Admin</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <style>
        .quartiers-intro { margin: 4px 0 20px; color: var(--admin-texte-discret); font-size: 13px; line-height: 1.55; }
        .quartiers-grille { display: grid; grid-template-columns: minmax(260px, .75fr) minmax(0, 1.5fr); gap: 18px; align-items: start; }
        .quartiers-grille > * { min-width: 0; }
        .quartiers-formulaire { display: grid; gap: 13px; }
        .quartiers-champ { display: grid; gap: 6px; }
        .quartiers-champ label { color: var(--admin-texte-discret); font-size: 12px; font-weight: 650; }
        .quartiers-champ input, .quartiers-champ select, .quartiers-recherche input, .quartiers-recherche select { width: 100%; min-height: 42px; padding: 9px 11px; border: 1px solid var(--admin-bordure); border-radius: 8px; background: var(--admin-carte, #fff); color: var(--admin-texte); font: inherit; font-size: 13px; }
        .quartiers-champ input:focus, .quartiers-champ select:focus, .quartiers-recherche input:focus, .quartiers-recherche select:focus { outline: 3px solid var(--admin-violet-clair); outline-offset: 1px; }
        .quartiers-bouton { min-height: 42px; padding: 9px 14px; border: 0; border-radius: 8px; background: var(--admin-violet); color: #fff; font: inherit; font-size: 13px; font-weight: 700; cursor: pointer; }
        .quartiers-bouton:hover { filter: brightness(1.08); }
        .quartiers-barre { display: flex; align-items: end; gap: 10px; margin-bottom: 14px; }
        .quartiers-barre .quartiers-recherche { flex: 1 1 150px; }
        .quartiers-barre .quartiers-bouton { flex: 0 0 auto; }
        .quartiers-recherche { display: grid; flex: 1; gap: 6px; }
        .quartiers-recherche label { color: var(--admin-texte-discret); font-size: 12px; font-weight: 650; }
        .quartiers-table-wrap { width: 100%; overflow-x: auto; }
        .quartiers-table { width: 100%; border-collapse: collapse; }
        .quartiers-table th, .quartiers-table td { padding: 11px 12px; border-bottom: 1px solid var(--admin-bordure); text-align: left; vertical-align: middle; }
        .quartiers-table th { color: var(--admin-texte-discret); font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .quartiers-table td { font-size: 13px; }
        .quartiers-table tr:last-child td { border-bottom: 0; }
        .quartiers-nom { min-width: 0; overflow-wrap: anywhere; font-weight: 650; }
        .quartiers-meta { display: block; margin-top: 3px; color: var(--admin-texte-discret); font-size: 11px; }
        .quartiers-action { min-height: 34px; padding: 5px 9px; border: 1px solid var(--admin-bordure); border-radius: 7px; background: transparent; color: var(--admin-violet); font: inherit; font-size: 12px; font-weight: 650; cursor: pointer; }
        .quartiers-vide { padding: 24px 12px; color: var(--admin-texte-discret); font-size: 13px; text-align: center; }
        .quartiers-alerte { margin-bottom: 14px; padding: 11px 14px; border-radius: 8px; font-size: 13px; line-height: 1.5; }
        .quartiers-alerte--ok { background: #E6F7ED; color: var(--admin-vert); }
        .quartiers-alerte--erreur { background: #FDECEC; color: #B91C1C; }
        @media (max-width: 850px) { .quartiers-grille { grid-template-columns: minmax(0, 1fr); } }
        @media (max-width: 600px) {
            .quartiers-barre { align-items: stretch; flex-direction: column; }
            .quartiers-table thead { display: none; }
            .quartiers-table, .quartiers-table tbody, .quartiers-table tr, .quartiers-table td { display: block; width: 100%; }
            .quartiers-table tbody { display: grid; gap: 9px; }
            .quartiers-table tr { padding: 10px 12px; border: 1px solid var(--admin-bordure); border-radius: 10px; background: var(--admin-carte, #fff); }
            .quartiers-table td { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 6px 0; border: 0; }
            .quartiers-table td::before { content: attr(data-label); flex: 0 0 76px; color: var(--admin-texte-discret); font-size: 11px; font-weight: 600; }
            .quartiers-table .quartiers-nom { text-align: right; }
            .quartiers-vide { border: 1px dashed var(--admin-bordure); border-radius: 10px; }
        }
        :root[data-theme="dark"] .quartiers-alerte--ok { background: var(--vert-fond); }
        :root[data-theme="dark"] .quartiers-alerte--erreur { background: var(--rouge-fond); color: #F5B5B5; }
    </style>
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <div class="admin-contenu">
        <div class="admin-entete">
            <div>
                <div class="admin-entete__titre">Villes & quartiers</div>
                <div class="admin-entete__sous-titre">Complétez les lieux proposés aux clients lors de l’ajout d’une adresse</div>
            </div>
        </div>

        <p class="quartiers-intro">Les lieux sont rattachés à une ville ou région active. Les quartiers désactivés restent dans les adresses déjà enregistrées, mais ne peuvent plus être choisis pour une nouvelle adresse.</p>

        <?php if ($flash !== ''): ?><div class="quartiers-alerte quartiers-alerte--ok" role="status"><?= htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
        <?php if ($erreur !== ''): ?><div class="quartiers-alerte quartiers-alerte--erreur" role="alert"><?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

        <div class="quartiers-grille">
            <section class="admin-panneau" aria-labelledby="quartier-ajouter-titre">
                <div class="admin-panneau__titre" id="quartier-ajouter-titre">Ajouter un quartier</div>
                <form method="POST" class="quartiers-formulaire">
                    <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_quartiers'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="action" value="ajouter">
                    <div class="quartiers-champ">
                        <label for="ville_id">Ville ou région</label>
                        <select id="ville_id" name="ville_id" required>
                            <option value="">Choisir une ville ou région</option>
                            <?php foreach ($villes as $ville): ?>
                                <option value="<?= (int) $ville['id'] ?>" <?= $villeAjoutId === (int) $ville['id'] ? 'selected' : '' ?>><?= htmlspecialchars($ville['nom'], ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="quartiers-champ">
                        <label for="nom">Nom du quartier</label>
                        <input id="nom" name="nom" type="text" maxlength="100" autocomplete="off" placeholder="Ex. Médina" required>
                    </div>
                    <button class="quartiers-bouton" type="submit">Ajouter le quartier</button>
                </form>
            </section>

            <section class="admin-panneau" aria-labelledby="quartiers-liste-titre">
                <div class="admin-panneau__titre" id="quartiers-liste-titre">Quartiers enregistrés <span class="admin-badge admin-badge--gris"><?= count($quartiers) ?></span></div>
                <form method="GET" class="quartiers-barre">
                    <div class="quartiers-recherche">
                        <label for="filtre-ville">Ville ou région</label>
                        <select id="filtre-ville" name="ville_id">
                            <option value="">Toutes</option>
                            <?php foreach ($villes as $ville): ?>
                                <option value="<?= (int) $ville['id'] ?>" <?= $villeFiltre === (int) $ville['id'] ? 'selected' : '' ?>><?= htmlspecialchars($ville['nom'], ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="quartiers-recherche">
                        <label for="recherche">Rechercher</label>
                        <input id="recherche" name="q" type="search" value="<?= htmlspecialchars($recherche, ENT_QUOTES, 'UTF-8') ?>" placeholder="Nom du quartier">
                    </div>
                    <div class="quartiers-recherche">
                        <label for="filtre-statut">Statut</label>
                        <select id="filtre-statut" name="statut">
                            <option value="tous" <?= $statutFiltre === 'tous' ? 'selected' : '' ?>>Tous</option>
                            <option value="active" <?= $statutFiltre === 'active' ? 'selected' : '' ?>>Actifs</option>
                            <option value="inactive" <?= $statutFiltre === 'inactive' ? 'selected' : '' ?>>Inactifs</option>
                        </select>
                    </div>
                    <div class="quartiers-recherche">
                        <label for="tri">Trier par</label>
                        <select id="tri" name="tri">
                            <option value="ville_asc" <?= $tri === 'ville_asc' ? 'selected' : '' ?>>Ville, puis quartier</option>
                            <option value="quartier_asc" <?= $tri === 'quartier_asc' ? 'selected' : '' ?>>Quartier A à Z</option>
                            <option value="quartier_desc" <?= $tri === 'quartier_desc' ? 'selected' : '' ?>>Quartier Z à A</option>
                        </select>
                    </div>
                    <button class="quartiers-bouton" type="submit">Filtrer</button>
                </form>

                <?php if (!$quartiers): ?>
                    <p class="quartiers-vide">Aucun quartier ne correspond à ces filtres.</p>
                <?php else: ?>
                    <div class="quartiers-table-wrap">
                        <table class="quartiers-table">
                            <thead><tr><th scope="col">Quartier</th><th scope="col">Ville ou région</th><th scope="col">Statut</th><th scope="col">Action</th></tr></thead>
                            <tbody>
                            <?php foreach ($quartiers as $quartier): ?>
                                <tr>
                                    <td class="quartiers-nom" data-label="Quartier">
                                        <?= htmlspecialchars($quartier['nom'], ENT_QUOTES, 'UTF-8') ?>
                                        <?php if ($quartier['osm_id']): ?><span class="quartiers-meta">OpenStreetMap #<?= (int) $quartier['osm_id'] ?></span><?php endif; ?>
                                    </td>
                                    <td data-label="Ville ou région"><?= htmlspecialchars($quartier['ville_nom'], ENT_QUOTES, 'UTF-8') ?></td>
                                    <td data-label="Statut"><span class="admin-badge admin-badge--<?= $quartier['statut'] === 'active' ? 'vert' : 'rouge' ?>"><?= $quartier['statut'] === 'active' ? 'Actif' : 'Inactif' ?></span></td>
                                    <td data-label="Action">
                                        <form method="POST">
                                            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_quartiers'], ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="action" value="changer_statut">
                                            <input type="hidden" name="zone_id" value="<?= (int) $quartier['id'] ?>">
                                            <input type="hidden" name="statut" value="<?= $quartier['statut'] === 'active' ? 'inactive' : 'active' ?>">
                                            <input type="hidden" name="retour_ville_id" value="<?= $villeFiltre ?? '' ?>">
                                            <input type="hidden" name="retour_q" value="<?= htmlspecialchars($recherche, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="retour_statut" value="<?= htmlspecialchars($statutFiltre, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="retour_tri" value="<?= htmlspecialchars($tri, ENT_QUOTES, 'UTF-8') ?>">
                                            <button class="quartiers-action" type="submit"><?= $quartier['statut'] === 'active' ? 'Désactiver' : 'Activer' ?></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </div>
</div>
</body>
</html>
