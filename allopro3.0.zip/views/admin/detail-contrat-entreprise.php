<?php
require_once __DIR__ . '/../../includes/auth-admin.php';
$roleContrats = $_SESSION['role'] ?? '';
$estFinanceContrats = $roleContrats === 'finance';
verifierAcces($estFinanceContrats ? 'devis_entreprises' : 'parametres');
require_once __DIR__ . '/../../models/EntrepriseB2B.php';

$contratId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$contrat = $contratId === false
    ? null
    : (new EntrepriseB2B())->getContratDetailAdmin((int) $contratId, (int) $_SESSION['user_id']);
if (!$contrat) {
    http_response_code(404);
    exit('Ce contrat entreprise est introuvable.');
}

$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$etatContrat = $contrat['statut'] !== 'actif'
    ? 'Résilié'
    : ($contrat['date_debut'] > date('Y-m-d')
        ? 'À venir'
        : ($contrat['date_fin'] < date('Y-m-d') ? 'Expiré' : 'Actif'));
$statutsDemande = [
    'nouvelle' => 'Nouvelle',
    'attribuee' => 'Attribuée',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$statutsIntervention = [
    'en_attente' => 'En attente du technicien',
    'acceptee' => 'Acceptée',
    'refusee' => 'Refusée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé sur site',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$methodesPaiement = [
    'wave' => 'Wave',
    'orange_money' => 'Orange Money',
    'virement' => 'Virement',
    'cheque' => 'Chèque',
    'especes' => 'Espèces',
    'autre' => 'Autre',
];
$creditsMobilises = (int) $contrat['credits_utilises'] + (int) $contrat['credits_reserves'];
$progressionCredits = min(100, (int) round($creditsMobilises / max(1, (int) $contrat['volume_credits']) * 100));
$montantContrat = (float) $contrat['montant_total'];
$progressionPaiement = $montantContrat > 0
    ? min(100, (int) round((float) $contrat['montant_regle'] / $montantContrat * 100))
    : 0;
$urlContrats = 'contrats-entreprises.php';
$csrfKey = 'csrf_contrats_entreprises_admin';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contrat #<?= (int) $contrat['id'] ?> — ALLÔ PRO <?= $estFinanceContrats ? 'Finance' : 'Admin' ?></title>
    <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
</head>
<body>
<div class="admin-app">
    <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <main class="admin-contenu b2b-main">
        <a class="b2b-detail-back" href="<?= $e($urlContrats) ?>"><span aria-hidden="true">←</span> Tous les contrats</a>
        <header class="b2b-detail-hero">
            <div>
                <span class="b2b-eyebrow">CONTRAT ENTREPRISE</span>
                <h1>Contrat #<?= (int) $contrat['id'] ?></h1>
                <p><?= $e($contrat['entreprise_nom']) ?> · Du <?= $e(date('d/m/Y', strtotime($contrat['date_debut']))) ?> au <?= $e(date('d/m/Y', strtotime($contrat['date_fin']))) ?></p>
            </div>
            <span class="b2b-status b2b-status--<?= $e($contrat['statut']) ?>"><?= $e($etatContrat) ?></span>
        </header>
        <?php if (($_GET['paiement'] ?? '') === '1' && ($_GET['facture'] ?? '') === 'envoyee'): ?>
            <div class="b2b-alert b2b-alert--success" role="status">Le règlement est enregistré. La facture PDF a été envoyée à l’adresse e-mail de l’entreprise.</div>
        <?php elseif (($_GET['paiement'] ?? '') === '1' && ($_GET['facture'] ?? '') === 'echec'): ?>
            <div class="b2b-alert b2b-alert--warning" role="status">Le règlement est enregistré, mais l’envoi de la facture a échoué. Consultez son état ci-dessous pour corriger l’adresse ou réessayer.</div>
        <?php elseif (($_GET['facture'] ?? '') === 'envoyee'): ?>
            <div class="b2b-alert b2b-alert--success" role="status">La facture PDF a été envoyée à l’entreprise.</div>
        <?php elseif (($_GET['facture'] ?? '') === 'echec'): ?>
            <div class="b2b-alert b2b-alert--warning" role="status">Le renvoi de la facture a échoué. Consultez le motif affiché dans l’historique.</div>
        <?php endif; ?>

        <section class="b2b-stats" aria-label="Résumé du contrat">
            <div class="b2b-stat"><span>Crédits disponibles</span><strong><?= (int) $contrat['credits_disponibles'] ?></strong></div>
            <div class="b2b-stat"><span>Crédits réservés</span><strong><?= (int) $contrat['credits_reserves'] ?></strong></div>
            <div class="b2b-stat"><span>Crédits consommés</span><strong><?= (int) $contrat['credits_utilises'] ?></strong></div>
            <div class="b2b-stat"><span>Volume contractuel</span><strong><?= (int) $contrat['volume_credits'] ?></strong></div>
        </section>

        <section class="b2b-panel b2b-contract-overview" aria-label="Avancement du contrat">
            <div class="b2b-contract-progress">
                <div class="b2b-contract-progress__heading">
                    <div><span class="b2b-eyebrow">UTILISATION DU VOLUME</span><strong><?= $creditsMobilises ?> crédit<?= $creditsMobilises === 1 ? '' : 's' ?> mobilisé<?= $creditsMobilises === 1 ? '' : 's' ?> sur <?= (int) $contrat['volume_credits'] ?></strong></div>
                    <span><?= $progressionCredits ?> %</span>
                </div>
                <div class="b2b-contract-progress__track" role="progressbar" aria-label="Crédits utilisés ou réservés" aria-valuemin="0" aria-valuemax="<?= (int) $contrat['volume_credits'] ?>" aria-valuenow="<?= $creditsMobilises ?>">
                    <span style="width: <?= $progressionCredits ?>%"></span>
                </div>
                <small><?= (int) $contrat['credits_utilises'] ?> consommé<?= (int) $contrat['credits_utilises'] === 1 ? '' : 's' ?> · <?= (int) $contrat['credits_reserves'] ?> réservé<?= (int) $contrat['credits_reserves'] === 1 ? '' : 's' ?> · <?= (int) $contrat['credits_disponibles'] ?> disponible<?= (int) $contrat['credits_disponibles'] === 1 ? '' : 's' ?></small>
            </div>
            <div class="b2b-contract-progress">
                <div class="b2b-contract-progress__heading">
                    <div><span class="b2b-eyebrow">RÈGLEMENT</span><strong><?= number_format((float) $contrat['montant_regle'], 2, ',', ' ') ?> FCFA réglés sur <?= number_format($montantContrat, 2, ',', ' ') ?> FCFA</strong></div>
                    <span><?= $progressionPaiement ?> %</span>
                </div>
                <div class="b2b-contract-progress__track b2b-contract-progress__track--payment" role="progressbar" aria-label="Montant du contrat réglé" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= $progressionPaiement ?>">
                    <span style="width: <?= $progressionPaiement ?>%"></span>
                </div>
                <small><?= number_format((float) $contrat['solde'], 2, ',', ' ') ?> FCFA de solde restant</small>
            </div>
        </section>

        <div class="b2b-detail-layout">
            <div class="b2b-detail-main">
                <section class="b2b-panel">
                    <div class="b2b-panel__heading">
                        <div><span class="b2b-eyebrow">PÉRIMÈTRE ET SUIVI</span><h2>Demandes rattachées</h2></div>
                        <span class="b2b-count"><?= count($contrat['demandes']) ?> demande<?= count($contrat['demandes']) === 1 ? '' : 's' ?></span>
                    </div>
                    <?php if (!$contrat['demandes']): ?>
                        <div class="b2b-empty">Aucune demande n’est rattachée à ce contrat.</div>
                    <?php else: ?>
                        <div class="b2b-table-wrap">
                            <table class="b2b-list">
                                <thead><tr><th>Dossier</th><th>Site</th><th>Service</th><th>Statut</th><th>Crédit</th><th>Créée le</th></tr></thead>
                                <tbody>
                                <?php foreach ($contrat['demandes'] as $demande):
                                    $statut = $demande['intervention_statut'] ?: $demande['statut'];
                                    $libelleStatut = $statutsIntervention[$statut] ?? $statutsDemande[$statut] ?? ucfirst(str_replace('_', ' ', $statut));
                                ?>
                                    <tr>
                                        <td><?= $e($demande['numero_dossier']) ?><span class="badge-demande-entreprise">Demande venant d’une entreprise</span></td>
                                        <td><?= $e($demande['site_nom']) ?></td>
                                        <td><?= $e($demande['categorie_nom']) ?></td>
                                        <td><?= $e($libelleStatut) ?></td>
                                        <td><?php if ($demande['date_consommation']): ?><?= (int) $demande['credits_consommes'] ?> consommé(s)<?php elseif (!in_array($demande['statut'], ['terminee', 'annulee'], true)): ?>1 réservé<?php else: ?>Non consommé<?php endif; ?></td>
                                        <td><?= $e(date('d/m/Y H:i', strtotime($demande['date_creation']))) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </section>

                <section class="b2b-panel">
                    <div class="b2b-panel__heading">
                        <div><span class="b2b-eyebrow">HISTORIQUE FINANCIER</span><h2>Règlements du contrat</h2></div>
                        <span class="b2b-count"><?= count($contrat['paiements']) ?> règlement<?= count($contrat['paiements']) === 1 ? '' : 's' ?></span>
                    </div>
                    <?php if (!$contrat['paiements']): ?>
                        <div class="b2b-empty">Aucun règlement n’a encore été enregistré.</div>
                    <?php else: ?>
                        <div class="b2b-table-wrap">
                            <table class="b2b-list">
                                <thead><tr><th>Date</th><th>Montant</th><th>Moyen</th><th>Référence</th><th>Enregistré par</th><th>Facture / e-mail</th></tr></thead>
                                <tbody>
                                <?php foreach ($contrat['paiements'] as $paiement): ?>
                                    <tr>
                                        <td><?= $e(date('d/m/Y à H:i', strtotime($paiement['date_paiement']))) ?></td>
                                        <td><?= number_format((float) $paiement['montant'], 2, ',', ' ') ?> FCFA</td>
                                        <td><?= $e($methodesPaiement[$paiement['methode']] ?? ucfirst($paiement['methode'])) ?></td>
                                        <td><?= $e($paiement['reference_transaction'] ?: '—') ?></td>
                                        <td><strong><?= $e($paiement['enregistre_par_nom']) ?></strong><small class="b2b-contract-matricule"><?= $e($paiement['enregistre_par_matricule'] ?: 'Matricule non renseigné') ?></small></td>
                                        <td>
                                            <?php if ($paiement['facture_numero']): ?>
                                                <strong><?= $e($paiement['facture_numero']) ?></strong>
                                                <small class="b2b-contract-matricule"><?= $paiement['facture_email_statut'] === 'envoye' ? 'E-mail envoyé' : ($paiement['facture_email_statut'] === 'echec' ? 'Échec e-mail' : 'En attente') ?></small>
                                                <?php if ($paiement['facture_destinataire']): ?><small><?= $e($paiement['facture_destinataire']) ?></small><?php endif; ?>
                                                <?php if ($paiement['facture_email_erreur']): ?><small class="b2b-invoice-error"><?= $e($paiement['facture_email_erreur']) ?></small><?php endif; ?>
                                                <div class="b2b-invoice-actions">
                                                    <?php if ($paiement['facture_pdf_disponible']): ?><a href="telecharger-facture-contrat.php?id=<?= (int) $paiement['id'] ?>">Télécharger PDF</a><?php endif; ?>
                                                    <?php if ($paiement['facture_email_statut'] !== 'envoye'): ?>
                                                        <form method="post" action="renvoyer-facture-contrat.php">
                                                            <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                                                            <input type="hidden" name="paiement_id" value="<?= (int) $paiement['id'] ?>">
                                                            <input type="hidden" name="contrat_id" value="<?= (int) $contrat['id'] ?>">
                                                            <button type="submit">Renvoyer</button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <span>Facture indisponible</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </section>
            </div>

            <aside class="b2b-detail-aside">
                <section class="b2b-panel">
                    <span class="b2b-eyebrow">CONDITIONS COMMERCIALES</span>
                    <h2>Montant et règlement</h2>
                    <p class="b2b-quote-amount"><?= number_format($montantContrat, 2, ',', ' ') ?> FCFA</p>
                    <dl class="b2b-detail-list b2b-detail-list--single">
                        <div><dt>Réglé</dt><dd><?= number_format((float) $contrat['montant_regle'], 2, ',', ' ') ?> FCFA</dd></div>
                        <div><dt>Solde</dt><dd><?= number_format((float) $contrat['solde'], 2, ',', ' ') ?> FCFA</dd></div>
                        <div><dt>SLA urgent</dt><dd><?= (int) ceil((int) $contrat['sla_urgent_minutes'] / 60) ?> h</dd></div>
                        <div><dt>SLA normal</dt><dd><?= (int) ceil((int) $contrat['sla_normal_minutes'] / 60) ?> h</dd></div>
                        <div><dt>Interlocuteur</dt><dd><?= $e($contrat['interlocuteur_nom'] ?: 'Non renseigné') ?></dd></div>
                        <div><dt>Téléphone</dt><dd><?= $e($contrat['interlocuteur_telephone'] ?: 'Non renseigné') ?></dd></div>
                        <div><dt>E-mail</dt><dd><?= $e($contrat['interlocuteur_email'] ?: 'Non renseigné') ?></dd></div>
                        <div class="b2b-contract-creator"><dt>Créé par</dt><dd><strong><?= $e($contrat['createur_nom'] ?: 'Compte indisponible') ?></strong><small class="b2b-contract-matricule"><?= $e($contrat['createur_matricule'] ?: 'Matricule non renseigné') ?></small></dd></div>
                    </dl>
                </section>

                <section class="b2b-panel">
                    <span class="b2b-eyebrow">CONDITIONS PARTICULIÈRES</span>
                    <h2>Notes du contrat</h2>
                    <?php if (trim((string) $contrat['conditions']) === ''): ?>
                        <p>Aucune condition particulière n’a été renseignée.</p>
                    <?php else: ?>
                        <div class="b2b-quote-description"><?= nl2br($e($contrat['conditions'])) ?></div>
                    <?php endif; ?>
                </section>
                <a class="b2b-button b2b-button--secondary b2b-detail-back-button" href="<?= $e($urlContrats) ?>">Retour aux contrats</a>
            </aside>
        </div>
    </main>
</div>
</body>
</html>
