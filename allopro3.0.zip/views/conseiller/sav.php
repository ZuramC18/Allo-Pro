<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

if (!function_exists('h')) {
    function h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
}

$libellesStatut = ['ouvert' => 'Ouvert', 'en_cours' => 'En cours', 'resolu' => 'Résolu'];
$ticketModel = new TicketSav();
$erreurCreation = '';
if (empty($_SESSION['csrf_creation_ticket_sav'])) {
    $_SESSION['csrf_creation_ticket_sav'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['creer_ticket_sav'])) {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $demandeId = filter_var($_POST['demande_id'] ?? null, FILTER_VALIDATE_INT);
    $motif = is_string($_POST['motif'] ?? null) ? trim($_POST['motif']) : '';

    if (!hash_equals($_SESSION['csrf_creation_ticket_sav'], $csrf)) {
        http_response_code(403);
        $erreurCreation = 'Votre session a expiré. Rechargez la page puis réessayez.';
    } elseif (!$demandeId || $motif === '' || mb_strlen($motif) > 100) {
        $erreurCreation = 'Choisissez un dossier terminé et indiquez un motif de 100 caractères maximum.';
    } else {
        try {
            if ($ticketModel->creerPourConseiller((int) $demandeId, $motif, (int) $_SESSION['user_id'])) {
                journaliser('sav.cree_par_conseiller', 'demande', (int) $demandeId, (string) $demandeId, $motif);
                $_SESSION['csrf_creation_ticket_sav'] = bin2hex(random_bytes(32));
                header('Location: sav.php?ticket=cree');
                exit;
            }
            $erreurCreation = 'Ce dossier n’est plus éligible ou possède déjà un ticket SAV.';
        } catch (Throwable $exception) {
            error_log('Création ticket SAV conseiller pour la demande ' . (int) $demandeId . ' : ' . $exception->getMessage());
            $erreurCreation = 'Une erreur est survenue lors de la création du ticket SAV.';
        }
    }
}

// Le filtre doit être un statut connu, sinon on affiche tout
$statutFiltre = $_GET['statut'] ?? null;
if (!is_string($statutFiltre) || !isset($libellesStatut[$statutFiltre])) { $statutFiltre = null; }

// Une seule requête : on compte et on filtre en PHP
$tous = $ticketModel->getAll(null);
$demandesEligibles = $ticketModel->getDemandesEligibleConseiller();

$compteurs = array_fill_keys(array_keys($libellesStatut), 0);
$sommeNotes = 0;
$nbNotes = 0;
foreach ($tous as $t) {
    if (isset($compteurs[$t['statut']])) { $compteurs[$t['statut']]++; }
    if ((int) $t['note'] > 0) { $sommeNotes += (int) $t['note']; $nbNotes++; }
}
$noteMoyenne = $nbNotes ? round($sommeNotes / $nbNotes, 1) : null;

$tickets = $statutFiltre
    ? array_values(array_filter($tous, fn($t) => $t['statut'] === $statutFiltre))
    : $tous;

// 5 étoiles en SVG : pleines jusqu'à la note, vides ensuite
function etoiles(int $note): string {
    $note = max(0, min(5, $note));
    $chemin = '<path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/>';
    $html = '<span class="etoiles" role="img" aria-label="Note : ' . $note . ' sur 5">';
    for ($i = 1; $i <= 5; $i++) {
        $html .= '<svg class="etoile ' . ($i <= $note ? 'etoile--pleine' : 'etoile--vide') . '" width="16" height="16" viewBox="0 0 24 24" stroke-linejoin="round" aria-hidden="true">' . $chemin . '</svg>';
    }
    return $html . '</span>';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SAV — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/liste-demandes.css?v=<?= filemtime(__DIR__ . '/../../public/css/liste-demandes.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-conseiller-sav">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>

    <div class="contenu">
        <div class="contenu__entete">
            <div>
                <div class="contenu__titre">Tickets SAV</div>
                <p class="liste-soustitre"><?= count($tous) ?> ticket<?= count($tous) > 1 ? 's' : '' ?> au total</p>
            </div>
        </div>

        <?php if (($_GET['ticket'] ?? '') === 'cree'): ?>
            <div class="alerte alerte--succes" role="status">Le ticket SAV a été créé et ajouté à la liste.</div>
        <?php endif; ?>
        <?php if ($erreurCreation !== ''): ?>
            <div class="alerte alerte--erreur" role="alert"><?= h($erreurCreation) ?></div>
        <?php endif; ?>

        <section class="sav-creation" aria-labelledby="titre-creer-ticket">
            <div class="sav-creation__entete">
                <span class="sav-creation__icone" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8v4l2.5 2.5"/><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6 4 4m14.4 1.6L20 4"/></svg>
                </span>
                <div>
                    <h2 id="titre-creer-ticket">Créer un ticket SAV</h2>
                    <p>Ouvrez un suivi pour un problème signalé après une intervention terminée.</p>
                </div>
            </div>
            <?php if ($demandesEligibles): ?>
                <form method="post" class="formulaire-ticket-sav">
                    <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf_creation_ticket_sav']) ?>">
                    <input id="demande-sav-id" type="hidden" name="demande_id">
                    <datalist id="demandes-sav">
                        <?php foreach ($demandesEligibles as $demande): ?>
                            <option value="<?= h((!empty($demande['est_demande_entreprise']) ? 'Demande venant d’une entreprise · ' : '') . $demande['numero_dossier'] . ' · ' . $demande['client_nom'] . ' · ' . $demande['categorie_nom']) ?>"
                                    data-id="<?= (int) $demande['id'] ?>"></option>
                        <?php endforeach; ?>
                    </datalist>
                    <div class="sav-champ">
                        <label for="demande-sav">Dossier concerné</label>
                        <div class="sav-champ__controle sav-champ__controle--recherche">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m16 16 4 4"/></svg>
                            <input id="demande-sav" type="search" list="demandes-sav" autocomplete="off" required
                                   placeholder="Dossier, client ou catégorie">
                        </div>
                        <small class="sav-recherche-aide">Saisissez un numéro, un nom de client ou une catégorie, puis choisissez une suggestion.</small>
                    </div>
                    <div class="sav-champ">
                        <label for="motif-sav">Motif</label>
                        <input id="motif-sav" name="motif" type="text" maxlength="100" required
                               value="<?= h($_POST['motif'] ?? '') ?>" placeholder="Ex. : problème après intervention">
                    </div>
                    <button type="submit" name="creer_ticket_sav" value="1">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14m-7-7h14"/></svg>
                        Créer le ticket
                    </button>
                </form>
            <?php else: ?>
                <p class="texte-doux" style="margin:0;">Aucun dossier terminé sans ticket SAV n’est disponible pour le moment.</p>
            <?php endif; ?>
        </section>

        <!-- Cartes de synthèse -->
        <div class="synthese">
            <a href="?statut=ouvert" class="synthese__carte synthese__carte--ouvert">
                <span class="synthese__nombre"><?= $compteurs['ouvert'] ?></span>
                <span class="synthese__label">À traiter</span>
            </a>
            <a href="?statut=en_cours" class="synthese__carte synthese__carte--en-cours">
                <span class="synthese__nombre"><?= $compteurs['en_cours'] ?></span>
                <span class="synthese__label">En cours</span>
            </a>
            <a href="?statut=resolu" class="synthese__carte synthese__carte--terminee">
                <span class="synthese__nombre"><?= $compteurs['resolu'] ?></span>
                <span class="synthese__label">Résolus</span>
            </a>
            <div class="synthese__carte synthese__carte--note">
                <span class="synthese__nombre">
                    <?= $noteMoyenne !== null ? number_format($noteMoyenne, 1, ',', '') : '—' ?><small>/5</small>
                </span>
                <span class="synthese__label">Note moyenne<?= $nbNotes ? ' (' . $nbNotes . ' avis)' : '' ?></span>
            </div>
        </div>

        <!-- Filtres + recherche -->
        <div class="barre-outils">
            <div class="filtres">
                <a href="?" class="filtre <?= !$statutFiltre ? 'filtre--actif' : '' ?>">Tous <span class="filtre__nb"><?= count($tous) ?></span></a>
                <?php foreach ($libellesStatut as $cle => $label): ?>
                    <a href="?statut=<?= h($cle) ?>" class="filtre <?= $statutFiltre === $cle ? 'filtre--actif' : '' ?>">
                        <?= h($label) ?>s <span class="filtre__nb"><?= $compteurs[$cle] ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <div class="recherche">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="search" id="recherche" placeholder="Dossier, client, commentaire…" aria-label="Rechercher dans les tickets">
            </div>
        </div>

        <!-- Tableau -->
        <div class="table-carte">
            <div class="table-defilement">
                <table class="table-demandes">
                    <thead>
                        <tr><th>Dossier</th><th>Client</th><th>Note</th><th>Commentaire</th><th>Statut</th></tr>
                    </thead>
                    <tbody id="corps-tableau">
                        <?php foreach ($tickets as $t): ?>
                        <tr class="<?= $t['statut'] === 'ouvert' ? 'ligne--urgente' : '' ?>"
                            data-recherche="<?= h(mb_strtolower($t['numero_dossier'] . ' ' . $t['client_nom'] . ' ' . $t['client_telephone'] . ' ' . ($t['commentaire'] ?? ''))) ?>">
                            <td class="cellule-dossier" data-label="Dossier"><?= h($t['numero_dossier']) ?><?php if (!empty($t['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($t['entreprise_b2b_nom']) ? ' · ' . h($t['entreprise_b2b_nom']) : '' ?></span><?php endif; ?></td>
                            <td class="cellule-client" data-label="Client">
                                <strong><?= h($t['client_nom']) ?></strong>
                                <small><?= h($t['client_telephone']) ?></small>
                            </td>
                            <td data-label="Note"><?= etoiles((int) $t['note']) ?></td>
                            <td class="cellule-commentaire" data-label="Commentaire">
                                <?php if (!empty($t['commentaire'])): ?>
                                    <span class="commentaire" title="<?= h($t['commentaire']) ?>"><?= h($t['commentaire']) ?></span>
                                <?php else: ?>
                                    <span class="texte-vide">Aucun commentaire</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="Statut"><span class="pastille pastille--<?= h($t['statut']) ?>"><?= h($libellesStatut[$t['statut']] ?? ucfirst(str_replace('_', ' ', $t['statut']))) ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="liste-vide" id="liste-vide" <?= empty($tickets) ? '' : 'hidden' ?>>
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
                <p>Aucun ticket SAV à afficher.</p>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    var champ = document.getElementById('recherche');
    var rechercheDemande = document.getElementById('demande-sav');
    var demandeId = document.getElementById('demande-sav-id');
    var listeDemandes = document.getElementById('demandes-sav');
    var formulaireCreation = document.querySelector('.formulaire-ticket-sav');
    var lignes = document.querySelectorAll('#corps-tableau tr');
    var vide = document.getElementById('liste-vide');
    var totalInitial = lignes.length;

    function synchroniserDemande() {
        var valeur = rechercheDemande.value.trim();
        var option = Array.prototype.find.call(listeDemandes.options, function (candidate) {
            return candidate.value === valeur;
        });
        demandeId.value = option ? option.dataset.id : '';
        rechercheDemande.setCustomValidity(valeur !== '' && !option ? 'Choisissez un dossier dans les suggestions.' : '');
    }

    rechercheDemande.addEventListener('input', synchroniserDemande);
    formulaireCreation.addEventListener('submit', function (event) {
        synchroniserDemande();
        if (!demandeId.value) {
            event.preventDefault();
            rechercheDemande.reportValidity();
        }
    });

    // Recherche instantanée
    champ.addEventListener('input', function () {
        var q = champ.value.trim().toLowerCase();
        var visibles = 0;
        lignes.forEach(function (tr) {
            var ok = q === '' || tr.getAttribute('data-recherche').indexOf(q) !== -1;
            tr.hidden = !ok;
            if (ok) visibles++;
        });
        vide.hidden = !(totalInitial === 0 || visibles === 0);
    });

})();
</script>
</body>
</html>