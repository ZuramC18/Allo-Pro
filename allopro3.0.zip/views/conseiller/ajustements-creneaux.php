<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['conseiller', 'admin']);
verifierAcces('demandes');
$rolePageCreneaux = 'conseiller';
require __DIR__ . '/../commun/ajustements-creneaux.php';
