<?php
require_once __DIR__ . '/../../includes/auth.php';
$consultationDossierInterne = !empty($consultationDossierInterne);
$traitementAdminDemande = !empty($traitementAdminDemande)
    && ($_SESSION['role'] ?? null) === 'admin';
if (!$consultationDossierInterne) {
    verifierAcces('demandes');
}
require_once __DIR__ . '/../../models/Demande.php';
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../models/Paiement.php';
require_once __DIR__ . '/../../models/Partenaire.php';
require_once __DIR__ . '/../../models/Technicien.php';
require_once __DIR__ . '/../../models/ClotureIntervention.php';
require_once __DIR__ . '/../../models/AttributionDemandeCoordinateur.php';
require_once __DIR__ . '/../../models/NoteDemande.php';
require_once __DIR__ . '/../../models/Parametre.php';
require_once __DIR__ . '/../../models/Abonnement.php';

// Échappement HTML sûr (accepte null, évite les "deprecated" de PHP 8.1+)
if (!function_exists('h')) {
    function h($valeur): string {
        return htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$estCoordinateur = !empty($traitementCoordinateur) || $consultationDossierInterne || $traitementAdminDemande;
$parametresCreneaux = new Parametre();
$heureDebutCreneau = max(0, min(23, (int) $parametresCreneaux->get('heure_debut_indisponibilites', '8')));
$heureFinCreneau = max($heureDebutCreneau + 1, min(24, (int) $parametresCreneaux->get('heure_fin_indisponibilites', '20')));
$dateMinCreneau = (new DateTimeImmutable('today'))->format('Y-m-d');
$dateMaxCreneau = (new DateTimeImmutable('today'))->modify('+30 days')->format('Y-m-d');
$dateDefautCreneau = (int) date('G') >= $heureFinCreneau
    ? (new DateTimeImmutable('tomorrow'))->format('Y-m-d')
    : $dateMinCreneau;
$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id) {
    header('Location: ' . ($consultationDossierInterne ? 'devis-entreprises.php' : ($traitementAdminDemande ? 'liste-demandes.php' : ($estCoordinateur ? '../coordinateur/demandes.php' : 'liste-demandes.php'))));
    exit;
}

$demandeModel = new Demande();
$demande = $demandeModel->getById($id);
if (!$demande) { http_response_code(404); die("Demande introuvable."); }
$abonnementClientActif = (new Abonnement())->getActifParClient((int) $demande['client_id']);
$niveauxPartenaire = [
    'partenaire' => 'Partenaire',
    'certifie' => 'Certifié',
    'premium' => 'Premium',
    'excellence' => 'Excellence',
];
$datePrefereeCreneau = is_string($demande['date_creneau_souhaite'] ?? null)
    ? $demande['date_creneau_souhaite']
    : '';
$heurePrefereeCreneau = ($demande['heure_creneau_souhaitee'] ?? null) !== null
    ? (int) $demande['heure_creneau_souhaitee']
    : null;
$datePrefereeValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $datePrefereeCreneau);
if (!$datePrefereeValidee || $datePrefereeValidee->format('Y-m-d') !== $datePrefereeCreneau
    || $datePrefereeCreneau < $dateMinCreneau || $datePrefereeCreneau > $dateMaxCreneau
    || ($datePrefereeCreneau === $dateMinCreneau && $heurePrefereeCreneau !== null
        && $heurePrefereeCreneau < (int) date('G'))) {
    $datePrefereeCreneau = $dateDefautCreneau;
}

$attributionCoordinateurModel = new AttributionDemandeCoordinateur();
$attributionCoordinateur = $attributionCoordinateurModel->getByDemande($id);
$noteDemandeModel = new NoteDemande();
$notesDemande = $noteDemandeModel->getByDemande($id);

$partenaireModel = new Partenaire();
$partenairesActifs = [];

$interventionModel = new Intervention();
$intervention = $interventionModel->getByDemandeId($id);
$suiviTechnicienAdmin = null;
$erreurSuiviTechnicienAdmin = null;
if ($traitementAdminDemande && $intervention && !empty($intervention['technicien_id'])) {
    try {
        $suiviTechnicienAdmin = [
            'checklist' => [],
            'documents' => $interventionModel->getDocumentsTechnicien(
                (int) $intervention['technicien_id'],
                (int) $intervention['id']
            ),
        ];
        if (!in_array($intervention['statut'], ['en_attente', 'refusee', 'annulee'], true)) {
            $interventionModel->initialiserChecklist((int) $intervention['id']);
            $suiviTechnicienAdmin['checklist'] = $interventionModel->getChecklist(
                (int) $intervention['id'],
                (int) $intervention['technicien_id']
            );
        }
    } catch (Throwable $exception) {
        error_log('Impossible de charger le suivi technicien du dossier ' . (int) $id . ' : ' . $exception->getMessage());
        $erreurSuiviTechnicienAdmin = 'Le suivi technicien est momentanément indisponible.';
    }
}
$fileAttenteFallback = $intervention && $intervention['statut'] === 'refusee'
    ? $interventionModel->getFileAttentePourIntervention((int) $intervention['id'])
    : false;
$techniciensFallback = $fileAttenteFallback
    ? $interventionModel->getTechniciensCompatiblesDemande((int) $id)
    : [];
$coordinateurPeutAgir = !$consultationDossierInterne && (!$estCoordinateur
    || ($_SESSION['role'] ?? null) === 'admin'
    || ($attributionCoordinateur
        && (($attributionCoordinateur['coordinateur_id'] === null
                && $attributionCoordinateur['statut'] === 'en_attente')
            || (int) $attributionCoordinateur['coordinateur_id'] === (int) $_SESSION['user_id'])));
$peutModifierCreneau = $estCoordinateur && $coordinateurPeutAgir && $intervention
    && in_array($intervention['statut'], ['en_attente', 'acceptee'], true);
$techniciensReaffectation = $estCoordinateur && $coordinateurPeutAgir && $intervention
    && $intervention['statut'] === 'en_attente'
    ? array_values(array_filter(
        $interventionModel->getTechniciensCompatiblesDemande((int) $id),
        static fn(array $technicien): bool => (int) $technicien['id'] !== (int) $intervention['technicien_id']
    ))
    : [];
$dateCreneauMission = (string) ($intervention['date_creneau_planifie'] ?? '');
$dateCreneauMissionValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $dateCreneauMission);
if (!$dateCreneauMissionValidee || $dateCreneauMissionValidee->format('Y-m-d') !== $dateCreneauMission
    || $dateCreneauMission < $dateMinCreneau || $dateCreneauMission > $dateMaxCreneau) {
    $dateCreneauMission = $datePrefereeCreneau;
}
$dateCreneauReaffectation = $dateCreneauMission;
$heureCreneauReaffectation = ($intervention['heure_creneau_planifie'] ?? null) !== null
    ? (int) $intervention['heure_creneau_planifie']
    : null;
$techniciensCompatibles = $estCoordinateur && $demande['statut'] === 'nouvelle'
    && ($traitementAdminDemande
        || ($attributionCoordinateur && $attributionCoordinateur['statut'] === 'en_attente'))
    ? $interventionModel->getTechniciensCompatiblesDemande($id)
    : [];
if ($techniciensCompatibles) {
    $partenaireIdsCompatibles = array_unique(array_map(
        static fn($technicien) => (int) $technicien['partenaire_id'],
        $techniciensCompatibles
    ));
    $quartiersCompatiblesParPartenaire = [];
    foreach ($techniciensCompatibles as $technicienCompatible) {
        $quartiersCompatiblesParPartenaire[(int) $technicienCompatible['partenaire_id']] =
            (string) ($technicienCompatible['zones_intervention'] ?? '');
    }
    $partenairesActifs = array_values(array_filter(
        $partenaireModel->getAllActifs(),
        static fn($partenaire) => in_array((int) $partenaire['id'], $partenaireIdsCompatibles, true)
    ));
    foreach ($partenairesActifs as &$partenaireActif) {
        $partenaireActif['quartier_compatible'] =
            $quartiersCompatiblesParPartenaire[(int) $partenaireActif['id']] ?? '';
    }
    unset($partenaireActif);
}

$paiementModel = new Paiement();
$paiement = $paiementModel->getByDemandeId($id);
$profilsTechniciensCompatibles = [];
foreach ($techniciensCompatibles as $technicienCompatible) {
    $profilsTechniciensCompatibles[(string) $technicienCompatible['id']] = [
        'competences' => (string) ($technicienCompatible['competences_affichage'] ?? ''),
        'note' => $technicienCompatible['note_moyenne'] !== null
            ? round((float) $technicienCompatible['note_moyenne'], 1)
            : null,
        'avis' => (int) ($technicienCompatible['nombre_avis'] ?? 0),
    ];
}
$profilsPartenairesCompatibles = [];
foreach ($partenairesActifs as $partenaireActif) {
    $niveauPartenaire = (string) ($partenaireActif['niveau'] ?? 'partenaire');
    $profilsPartenairesCompatibles[(string) $partenaireActif['id']] = [
        'nom' => (string) $partenaireActif['nom_entreprise'],
        'niveau' => $niveauxPartenaire[$niveauPartenaire] ?? $niveauxPartenaire['partenaire'],
        'niveau_cle' => isset($niveauxPartenaire[$niveauPartenaire]) ? $niveauPartenaire : 'partenaire',
        'quartier' => (string) ($partenaireActif['quartier_compatible'] ?? ''),
    ];
}
$notesTechnicienMission = $intervention && !empty($intervention['technicien_id'])
    ? (new Technicien())->getNotesActivite((int) $intervention['technicien_id'])
    : false;

$statutsMission = ['en_route', 'arrive', 'diagnostic', 'en_cours'];
$statutsModifiables = ['attribuee', 'en_cours'];
$erreur = null;
$csrfKey = $estCoordinateur ? 'csrf_traiter_demande_coordinateur' : 'csrf_transmettre_demande_coordinateur';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}
$flashKey = $estCoordinateur ? 'flash_traiter_demande_coordinateur' : 'flash_transmettre_demande_coordinateur';
$messageSucces = is_string($_SESSION[$flashKey] ?? null) ? $_SESSION[$flashKey] : '';
unset($_SESSION[$flashKey]);
$noteSaisie = is_string($_POST['note_dossier'] ?? null) ? $_POST['note_dossier'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($consultationDossierInterne || ($estCoordinateur && !$coordinateurPeutAgir))) {
    http_response_code(403);
    $erreur = $consultationDossierInterne
        ? 'Cette fiche est accessible en consultation uniquement.'
        : 'Vous pouvez consulter ce dossier et son avancement, mais seul le coordinateur qui le prend en charge peut effectuer des actions.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['modifier_creneau_planifie'])) {
        $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
        $dateCreneau = is_string($_POST['date_creneau_planifie'] ?? null)
            ? $_POST['date_creneau_planifie']
            : '';
        $heureCreneau = is_string($_POST['heure_creneau_planifie'] ?? null)
            ? filter_var($_POST['heure_creneau_planifie'], FILTER_VALIDATE_INT)
            : false;
        $dateValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $dateCreneau);
        if (!$estCoordinateur) {
            http_response_code(403);
            $erreur = 'Seul un coordinateur peut modifier le créneau planifié.';
        } elseif (!hash_equals($_SESSION[$csrfKey], $csrf)) {
            http_response_code(403);
            $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
        } elseif (!$intervention || !in_array($intervention['statut'], ['en_attente', 'acceptee'], true)) {
            $erreur = 'Le créneau ne peut plus être modifié : le technicien a commencé sa route ou la mission a avancé.';
        } elseif ($heureCreneau === false || !$dateValidee || $dateValidee->format('Y-m-d') !== $dateCreneau
            || $dateCreneau < $dateMinCreneau || $dateCreneau > $dateMaxCreneau) {
            $erreur = 'Choisissez une date et un créneau valides dans les 30 prochains jours.';
        } else {
            try {
                if ($interventionModel->modifierCreneauPlanifie(
                    (int) $intervention['id'],
                    (int) $id,
                    $dateCreneau,
                    (int) $heureCreneau,
                    $heureDebutCreneau,
                    $heureFinCreneau
                )) {
                    journaliser(
                        'mission.creneau_modifie_coordinateur',
                        'demande',
                        $id,
                        $demande['numero_dossier'],
                        sprintf('Nouveau créneau planifié : %s à %02d:00', $dateCreneau, (int) $heureCreneau)
                    );
                    $_SESSION[$flashKey] = 'Le créneau de la mission a été mis à jour.';
                    header('Location: traiter-demande.php?id=' . $id);
                    exit;
                }
                $erreur = 'Le créneau est devenu indisponible ou la mission a commencé. Actualisez la page puis réessayez.';
            } catch (Throwable $exception) {
                error_log('Modification créneau intervention ' . (int) $intervention['id'] . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de la modification du créneau.';
            }
        }

    } elseif (isset($_POST['reattribuer_mission'])) {
        $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
        $technicienReaffectationId = filter_var($_POST['technicien_reaffectation_id'] ?? null, FILTER_VALIDATE_INT);
        $dateReaffectation = is_string($_POST['date_creneau_reaffectation'] ?? null)
            ? $_POST['date_creneau_reaffectation']
            : '';
        $heureReaffectation = is_string($_POST['heure_creneau_reaffectation'] ?? null)
            ? filter_var($_POST['heure_creneau_reaffectation'], FILTER_VALIDATE_INT)
            : false;
        $dateReaffectationValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $dateReaffectation);

        if (!$estCoordinateur) {
            http_response_code(403);
            $erreur = 'Seul un coordinateur peut réaffecter une mission.';
        } elseif (!hash_equals($_SESSION[$csrfKey], $csrf)) {
            http_response_code(403);
            $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
        } elseif (!$intervention || $intervention['statut'] !== 'en_attente') {
            $erreur = 'La mission ne peut plus être réaffectée : le technicien l’a acceptée ou elle a avancé.';
        } elseif (!$technicienReaffectationId || !in_array(
            (int) $technicienReaffectationId,
            array_map('intval', array_column($techniciensReaffectation, 'id')),
            true
        )) {
            $erreur = 'Choisissez un autre technicien compatible, actif et disponible.';
        } elseif ($heureReaffectation === false || !$dateReaffectationValidee
            || $dateReaffectationValidee->format('Y-m-d') !== $dateReaffectation
            || $dateReaffectation < $dateMinCreneau || $dateReaffectation > $dateMaxCreneau) {
            $erreur = 'Choisissez une date et un créneau disponibles dans les 30 prochains jours.';
        } else {
            try {
                if ($interventionModel->reattribuerMissionEnAttente(
                    (int) $intervention['id'],
                    (int) $id,
                    (int) $technicienReaffectationId,
                    (int) $_SESSION['user_id'],
                    ($_SESSION['role'] ?? null) === 'admin',
                    $dateReaffectation,
                    (int) $heureReaffectation,
                    $heureDebutCreneau,
                    $heureFinCreneau
                )) {
                    journaliser(
                        'mission.reattribuee_coordinateur',
                        'intervention',
                        (int) $intervention['id'],
                        $demande['numero_dossier'],
                        'Réaffectée avant acceptation du technicien.'
                    );
                    $_SESSION[$flashKey] = 'La mission a été réaffectée. Le nouveau technicien doit confirmer sa prise en charge.';
                    header('Location: traiter-demande.php?id=' . $id);
                    exit;
                }
                $erreur = 'La mission, le créneau ou la disponibilité du technicien a changé. Actualisez la page puis réessayez.';
            } catch (Throwable $exception) {
                error_log('Réaffectation avant acceptation intervention ' . (int) $intervention['id'] . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de la réaffectation de la mission.';
            }
        }

    } elseif (isset($_POST['declencher_fallback'])) {
        $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
        $technicienFallbackId = filter_var($_POST['technicien_fallback_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$estCoordinateur) {
            http_response_code(403);
            $erreur = 'Seul un coordinateur peut déclencher le fallback d’une mission.';
        } elseif (!hash_equals($_SESSION[$csrfKey], $csrf)) {
            http_response_code(403);
            $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
        } elseif (!$intervention || $intervention['statut'] !== 'refusee' || !$fileAttenteFallback) {
            $erreur = 'Cette mission n’est plus en attente de réattribution.';
        } elseif (!$technicienFallbackId) {
            $erreur = 'Choisissez un technicien compatible pour déclencher le fallback.';
        } else {
            try {
                if ($interventionModel->reattribuerDepuisFile(
                    (int) $fileAttenteFallback['file_id'],
                    (int) $technicienFallbackId,
                    (int) $_SESSION['user_id']
                )) {
                    journaliser(
                        'mission.fallback_declenche_coordinateur',
                        'intervention',
                        (int) $intervention['id'],
                        $demande['numero_dossier'],
                        'Réattribuée à un technicien compatible depuis la fiche du dossier.'
                    );
                    $_SESSION[$flashKey] = 'Le fallback a été déclenché. Le nouveau technicien doit confirmer la mission.';
                    header('Location: traiter-demande.php?id=' . $id);
                    exit;
                }
                $erreur = 'La mission ou la disponibilité du technicien a changé. Actualisez la page puis réessayez.';
            } catch (Throwable $exception) {
                error_log('Fallback intervention ' . (int) $intervention['id'] . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors du déclenchement du fallback.';
            }
        }

    } elseif (isset($_POST['ajouter_note'])) {
        $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
        $note = is_string($_POST['note_dossier'] ?? null) ? trim($_POST['note_dossier']) : '';
        if ($estCoordinateur && !$traitementAdminDemande) {
            http_response_code(403);
            $erreur = 'Cette action est réservée aux conseillers.';
        } elseif (!hash_equals($_SESSION[$csrfKey], $csrf)) {
            http_response_code(403);
            $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
        } elseif ($note === '') {
            $erreur = 'Saisissez une note avant de l’ajouter au dossier.';
        } elseif (mb_strlen($note) > 3000) {
            $erreur = 'La note ne peut pas dépasser 3 000 caractères.';
        } else {
            try {
                $noteDemandeModel->ajouter($id, (int) $_SESSION['user_id'], $note);
                journaliser('demande.note_ajoutee', 'demande', $id, $demande['numero_dossier']);
                $_SESSION[$flashKey] = 'La note a été ajoutée au dossier.';
                header('Location: traiter-demande.php?id=' . $id);
                exit;
            } catch (PDOException $exception) {
                error_log('Ajout note demande ' . $id . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de l’ajout de la note.';
            }
        }

    // ---------- Transmission conseiller -> file commune des coordinateurs ----------
    } elseif (isset($_POST['transmettre_coordinateurs'])) {
        $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
        $commentaire = is_string($_POST['commentaire_interne'] ?? null) ? trim($_POST['commentaire_interne']) : '';
        if ($estCoordinateur) {
            http_response_code(403);
            $erreur = 'Cette action est réservée aux conseillers.';
        } elseif (!hash_equals($_SESSION[$csrfKey], $csrf)) {
            http_response_code(403);
            $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
        } elseif ($demande['statut'] !== 'nouvelle') {
            $erreur = 'Seules les nouvelles demandes peuvent être transmises aux coordinateurs.';
        } elseif ($commentaire === '') {
            $erreur = 'Ajoutez un commentaire interne avant de transmettre le dossier.';
        } elseif (mb_strlen($commentaire) > 3000) {
            $erreur = 'Le commentaire interne ne peut pas dépasser 3 000 caractères.';
        } else {
            try {
                if ($attributionCoordinateurModel->transmettre($id, (int) $_SESSION['user_id'], $commentaire)) {
                    journaliser('demande.transmise_coordinateurs', 'demande', $id, $demande['numero_dossier'], $commentaire);
                    $_SESSION[$flashKey] = 'Le dossier a été transmis à la file commune des coordinateurs.';
                    header('Location: traiter-demande.php?id=' . $id);
                    exit;
                }
                $erreur = 'Le dossier a déjà été transmis ou n’est plus une nouvelle demande.';
            } catch (PDOException $exception) {
                error_log('Transmission demande ' . $id . ' aux coordinateurs : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de la transmission du dossier.';
            }
        }

    // ---------- Attribution de mission, réservée au coordinateur ----------
    } elseif (isset($_POST['technicien_id'])) {
        $partenaireId = (int) ($_POST['partenaire_id'] ?? 0);
        $technicienId = (int) $_POST['technicien_id'];
        $dateCreneau = is_string($_POST['date_creneau_planifie'] ?? null)
            ? $_POST['date_creneau_planifie']
            : '';
        $heureCreneauBrute = is_string($_POST['heure_creneau_planifie'] ?? null)
            ? filter_var($_POST['heure_creneau_planifie'], FILTER_VALIDATE_INT)
            : false;
        $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
        $p = $estCoordinateur ? $partenaireModel->getById($partenaireId) : null;
        $t = $estCoordinateur ? (new Technicien())->getById($technicienId) : null;
        $technicienCompatible = false;
        foreach ($techniciensCompatibles as $candidat) {
            if ((int) $candidat['id'] === $technicienId && (int) $candidat['partenaire_id'] === $partenaireId) {
                $technicienCompatible = true;
                break;
            }
        }

        if (!$estCoordinateur) {
            http_response_code(403);
            $erreur = 'Seul un coordinateur peut attribuer une mission.';
        } elseif (!hash_equals($_SESSION[$csrfKey], $csrf)) {
            http_response_code(403);
            $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
        } elseif (!$traitementAdminDemande
            && (!$attributionCoordinateur || $attributionCoordinateur['statut'] !== 'en_attente')) {
            $erreur = 'Ce dossier n’est plus en attente dans la file des coordinateurs.';
        } elseif ($demande['statut'] !== 'nouvelle') {
            $erreur = "Cette demande a déjà été attribuée.";
        } elseif ($heureCreneauBrute === false || $dateCreneau === ''
            || !DateTimeImmutable::createFromFormat('!Y-m-d', $dateCreneau)
            || $dateCreneau < $dateMinCreneau || $dateCreneau > $dateMaxCreneau) {
            $erreur = 'Choisissez une date et un créneau disponibles dans les 30 prochains jours.';
        } elseif (!$p || !$t || $p['statut'] !== 'actif' || $t['statut'] !== 'actif'
            || (int) $t['partenaire_id'] !== $partenaireId || !$technicienCompatible) {
            $erreur = "Partenaire ou technicien incompatible avec la demande.";
        } else {
            try {
                $coordinateurAffectationId = $attributionCoordinateur
                    && $attributionCoordinateur['statut'] === 'en_attente'
                    ? (int) $_SESSION['user_id']
                    : null;
                if (!$interventionModel->creerAvecPartenaire(
                    $id,
                    $partenaireId,
                    $technicienId,
                    $coordinateurAffectationId,
                    $dateCreneau,
                    $heureCreneauBrute,
                    $heureDebutCreneau,
                    $heureFinCreneau
                )) {
                    $erreur = 'Le créneau choisi ou le dossier vient de changer. Actualisez les disponibilités puis réessayez.';
                } else {
                    journaliser('demande.attribuee', 'demande', $id, $demande['numero_dossier'],
                        'Partenaire ' . $p['matricule'] . ' (' . $p['nom_entreprise'] . ') · Technicien ' . $t['matricule'] . ' (' . $t['nom'] . ')');
                    header('Location: ' . ($traitementAdminDemande ? 'liste-demandes.php' : '../coordinateur/demandes.php'));
                    exit;
                }
            } catch (Throwable $exception) {
                error_log('Attribution manuelle demande ' . $id . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de l’attribution de la mission.';
            }
        }

    // ---------- 2. Mise à jour du statut de la mission ----------
    } elseif (isset($_POST['nouveau_statut'])) {
        $nouveauStatut = $_POST['nouveau_statut'];

        if (!in_array($demande['statut'], $statutsModifiables, true) || !$intervention
            || !in_array($intervention['statut'], ['acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours'], true)) {
            $erreur = "Le statut de cette mission ne peut plus être modifié.";
        } elseif (!in_array($nouveauStatut, $statutsMission, true)) {
            $erreur = "Statut invalide.";
        } elseif (!$interventionModel->mettreAJourStatut($id, $nouveauStatut)) {
            $erreur = "Le statut de cette mission vient de changer. Rechargez la page.";
        } else {
            $demandeModel->mettreAJourStatut($id, 'en_cours');
            journaliser('mission.statut_modifie', 'demande', $id, $demande['numero_dossier'], '→ ' . $nouveauStatut);
            header("Location: traiter-demande.php?id=" . $id);
            exit;
        }

    // ---------- 3. Clôture ----------
    } elseif (isset($_POST['rapport'])) {
        $rapport = is_string($_POST['rapport'] ?? null) ? trim($_POST['rapport']) : '';
        $encaisseEspeces = ($_POST['encaisse_especes'] ?? '') === '1';

        if (!in_array($demande['statut'], $statutsModifiables, true)) {
            $erreur = "Cette intervention ne peut pas être clôturée (déjà terminée ou non attribuée).";
        } else {
            $resultatCloture = (new ClotureIntervention())->cloturer(
                $id,
                $rapport,
                $_POST['montant'] ?? '',
                $encaisseEspeces
            );
            if (!$resultatCloture['ok']) {
                $erreur = $resultatCloture['erreur'];
            } else {
                $couverture = $resultatCloture['couverture'];
                $montant = $resultatCloture['montant'];
                journaliser('mission.cloturee', 'demande', $id, $demande['numero_dossier'],
                    $couverture
                        ? 'Couvert par ' . $couverture['type']
                        : ($encaisseEspeces
                            ? 'Paiement reçu en espèces : ' . number_format($montant, 0, ',', ' ') . ' F'
                            : 'Montant : ' . number_format($montant, 0, ',', ' ') . ' F'));
                require_once __DIR__ . '/../../models/Notification.php';
                $notificationModel = new Notification();
                $lienDetail = !empty($demande['contrat_b2b_id'])
                    ? "/allopro/views/entreprise/detail-demande.php?entreprise_id=" . (int) $demande['entreprise_b2b_id'] . "&id=" . $id
                    : "/allopro/views/client/detail-demande.php?id=" . $id;

                if (($couverture['type'] ?? null) === 'contrat_b2b') {
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Elle est couverte par le contrat de votre entreprise — un crédit a été consommé.", $lienDetail);
                } elseif (($couverture['type'] ?? null) === 'abonnement') {
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Elle est couverte par votre abonnement — aucun paiement requis.", $lienDetail);
                } elseif (($couverture['type'] ?? null) === 'pass') {
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Elle est couverte par votre Pass — aucun paiement requis.", $lienDetail);
                } elseif ($encaisseEspeces) {
                    $montantFormate = number_format($montant, 0, ',', ' ');
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Paiement reçu en espèces : {$montantFormate} FCFA.", $lienDetail);
                } else {
                    $montantFormate = number_format($montant, 0, ',', ' ');
                    $notificationModel->create($demande['client_id'], "Votre intervention {$demande['numero_dossier']} est terminée. Montant à payer : {$montantFormate} FCFA.", "/allopro/views/client/payer.php?id=" . $id);
                }

                header("Location: traiter-demande.php?id=" . $id);
                exit;
            }
        }
    }
}
?>
<?php
$libellesStatut = ['nouvelle' => 'Nouvelle', 'attribuee' => 'Attribuée', 'en_cours' => 'En cours', 'terminee' => 'Terminée'];
$formaterDateEtape = static function ($date): ?string {
    if (!is_string($date) || $date === '') {
        return null;
    }
    $horodatage = strtotime($date);
    return $horodatage === false ? null : date('d/m/Y · H:i', $horodatage);
};
$etapes = [
    ['nom' => 'Demande reçue', 'date' => $formaterDateEtape($demande['date_creation'] ?? null)],
    [
        'nom' => $attributionCoordinateur ? 'Transmise au coordinateur' : 'Prise en charge',
        'date' => $formaterDateEtape($attributionCoordinateur['date_attribution'] ?? null),
    ],
    ['nom' => 'Mission attribuée', 'date' => $formaterDateEtape($intervention['date_debut'] ?? null)],
    ['nom' => 'Réponse du technicien', 'date' => null],
    ['nom' => 'Mission acceptée', 'date' => null],
    ['nom' => 'En route', 'date' => null],
    ['nom' => 'Arrivé sur place', 'date' => null],
    ['nom' => 'Diagnostic', 'date' => null],
    ['nom' => 'Intervention en cours', 'date' => null],
    ['nom' => 'Terminée', 'date' => $formaterDateEtape($intervention['date_fin'] ?? null)],
];
$statutIntervention = $intervention['statut'] ?? null;
if ($statutIntervention === 'refusee') {
    $etapes[3]['nom'] = 'Réaffectation';
    $etapes[3]['date'] = $formaterDateEtape($intervention['date_decision_technicien'] ?? null);
} elseif (!empty($intervention['date_decision_technicien'])) {
    $etapes[4]['date'] = $formaterDateEtape($intervention['date_decision_technicien']);
}
$indexEtapeCourante = 0;
$messageAvancement = 'La demande est reçue et attend son transfert à un coordinateur.';
$avancementAnnule = $demande['statut'] === 'annulee' || $statutIntervention === 'annulee';

if ($avancementAnnule) {
    $etapes = [
        ['nom' => 'Demande reçue', 'date' => $formaterDateEtape($demande['date_creation'] ?? null)],
        ['nom' => 'Dossier annulé', 'date' => null],
    ];
    $indexEtapeCourante = 1;
    $messageAvancement = 'Ce dossier a été annulé ; aucune autre étape ne sera réalisée.';
} elseif ($demande['statut'] === 'terminee' || $statutIntervention === 'terminee') {
    $indexEtapeCourante = 9;
    $messageAvancement = 'L’intervention est terminée.';
} elseif ($intervention) {
    $indexParStatutIntervention = [
        'en_attente' => 3,
        'refusee' => 3,
        'acceptee' => 4,
        'en_route' => 5,
        'arrive' => 6,
        'diagnostic' => 7,
        'en_cours' => 8,
    ];
    $indexEtapeCourante = $indexParStatutIntervention[$statutIntervention] ?? 2;
    $messageAvancement = match ($statutIntervention) {
        'en_attente' => 'La mission est proposée au technicien et attend sa réponse.',
        'refusee' => 'Le technicien a refusé la mission ; une réaffectation est en attente du coordinateur.'
            . (!empty($fileAttenteFallback['motif']) ? ' Motif : ' . $fileAttenteFallback['motif'] : ''),
        'acceptee' => 'Le technicien a accepté la mission ; son départ vers le client est attendu.',
        'en_route' => 'Le technicien est en route vers le client.',
        'arrive' => 'Le technicien est arrivé sur place.',
        'diagnostic' => 'Le technicien réalise le diagnostic.',
        'en_cours' => 'L’intervention est en cours.',
        default => 'La mission est attribuée.',
    };
} elseif ($attributionCoordinateur) {
    $indexEtapeCourante = $attributionCoordinateur['statut'] === 'traitee' ? 2 : 1;
    if ($attributionCoordinateur['statut'] === 'traitee') {
        $etapes[2]['date'] = $formaterDateEtape($attributionCoordinateur['date_traitement'] ?? null);
    }
    $messageAvancement = $attributionCoordinateur['statut'] === 'traitee'
        ? 'Le coordinateur a pris en charge le dossier ; l’attribution de la mission est en cours.'
        : 'Le dossier a été transmis et attend la prise en charge d’un coordinateur.';
} elseif ($demande['statut'] === 'attribuee' || $demande['statut'] === 'en_cours') {
    $indexEtapeCourante = 2;
    $messageAvancement = 'La mission est attribuée.';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dossier <?= h($demande['numero_dossier']) ?> — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/traiter-demande.css?v=<?= filemtime(__DIR__ . '/../../public/css/traiter-demande.css') ?>">
    <?php if ($consultationDossierInterne): ?>
        <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <?php endif; ?>
    <?php if ($estCoordinateur): ?>
        <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
        <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php endif; ?>
    <?php if ($traitementAdminDemande): ?>
        <link rel="stylesheet" href="../../public/css/admin.css?v=<?= filemtime(__DIR__ . '/../../public/css/admin.css') ?>">
    <?php endif; ?>
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-traiter-demande <?= $traitementAdminDemande ? 'page-traiter-demande--admin' : ($estCoordinateur ? 'page-traiter-demande--coordinateur' : 'page-traiter-demande--conseiller') ?>">
<?php if ($consultationDossierInterne || $traitementAdminDemande): ?>
<div class="admin-app">
    <?php if ($consultationDossierInterne && ($_SESSION['role'] ?? '') === 'qualite'): ?>
        <?php include __DIR__ . '/../../includes/sidebar-qualite.php'; ?>
    <?php else: ?>
        <?php include __DIR__ . '/../../includes/sidebar-admin.php'; ?>
    <?php endif; ?>
    <main class="admin-contenu"><div class="contenu">
<?php else: ?>
<div class="app <?= $estCoordinateur ? 'coord-shell' : '' ?>">
    <?php if ($estCoordinateur): ?>
        <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <?php else: ?>
        <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>
    <?php endif; ?>

    <div class="contenu">
<?php endif; ?>

        <a href="<?= $consultationDossierInterne ? ($urlRetourConsultation ?? 'devis-entreprises.php') : ($traitementAdminDemande ? 'liste-demandes.php' : ($estCoordinateur ? '../coordinateur/demandes.php' : 'liste-demandes.php')) ?>" class="lien-retour">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>
            <?= $consultationDossierInterne ? ($libelleRetourConsultation ?? 'Retour aux devis') : 'Retour aux demandes' ?>
        </a>

        <div class="dossier-entete">
            <div>
                <span class="dossier-entete__sur-titre"><?= $consultationDossierInterne ? 'Consultation du dossier' : 'Traitement de la demande' ?></span>
                <h1 class="dossier-entete__titre">Dossier <?= h($demande['numero_dossier']) ?></h1>
                <p class="dossier-entete__date">
                    <span><?= h($demande['categorie_nom']) ?></span>
                    <?php if (!empty($demande['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($demande['entreprise_b2b_nom']) ? ' · ' . h($demande['entreprise_b2b_nom']) : '' ?><?= !empty($demande['contrat_b2b_id']) ? ' · Contrat #' . (int) $demande['contrat_b2b_id'] : '' ?></span><?php endif; ?>
                    <span aria-hidden="true">·</span>
                    <span>Créé le <?= date('d/m/Y à H:i', strtotime($demande['date_creation'] ?? 'now')) ?></span>
                </p>
            </div>
            <div class="dossier-entete__badges">
                <span class="pastille pastille--<?= h($demande['urgence']) ?>"><?= h(ucfirst($demande['urgence'])) ?></span>
                <span class="pastille pastille--<?= h($demande['statut']) ?>"><?= h($libellesStatut[$demande['statut']] ?? $demande['statut']) ?></span>
            </div>
        </div>

        <section class="dossier-avancement" aria-labelledby="titre-avancement">
            <h2 class="dossier-avancement__titre" id="titre-avancement">Avancement du dossier</h2>
            <p class="dossier-avancement__message" role="status"><?= h($messageAvancement) ?></p>
            <p class="dossier-avancement__note">Les dates apparaissent pour les étapes dont l’horodatage est enregistré.</p>
            <ol class="frise" aria-label="Étapes d’avancement du dossier">
                <?php foreach ($etapes as $i => $etape):
                    $terminee = ($demande['statut'] === 'terminee' || $statutIntervention === 'terminee');
                    $etat = $i < $indexEtapeCourante || ($terminee && $i === $indexEtapeCourante)
                        ? 'fait'
                        : ($i === $indexEtapeCourante ? 'courant' : 'attente');
                    ?>
                        <li class="frise__etape frise__etape--<?= $etat ?>"
                            <?= $etat === 'courant' ? 'aria-current="step"' : '' ?>>
                            <span class="frise__rond">
                                <?php if ($etat === 'fait'): ?>
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
                                <?php else: ?><?= $i + 1 ?><?php endif; ?>
                            </span>
                            <span class="frise__nom"><?= h($etape['nom']) ?></span>
                            <?php if ($etape['date'] !== null): ?>
                                <span class="frise__date"><?= h($etape['date']) ?></span>
                            <?php endif; ?>
                        </li>
                <?php endforeach; ?>
            </ol>
        </section>

        <div class="dossier-grille">

            <!-- ===== Colonne gauche : informations ===== -->
            <section class="carte">
                <h2 class="carte__titre">Informations du dossier</h2>

                <div class="dossier__ligne dossier__ligne--client">
                    <span>Client</span>
                    <span class="dossier-client">
                        <strong><?= h($demande['client_nom']) ?></strong>
                        <?php if ($traitementAdminDemande && $abonnementClientActif): ?>
                            <span class="dossier-client__premium" title="<?= h($abonnementClientActif['formule_nom'] ?? 'Abonnement actif') ?>">
                                <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m10 1.8 2.5 5.1 5.6.8-4 3.9.9 5.6-5-2.7-5 2.7.9-5.6-4-3.9 5.6-.8z"/></svg>
                                Premium
                            </span>
                        <?php endif; ?>
                        <span class="dossier-client__contact">
                            <?php if (!$estCoordinateur || $coordinateurPeutAgir): ?>
                                <a class="dossier__telephone" href="tel:<?= h($demande['client_telephone']) ?>"><?= h($demande['client_telephone']) ?></a>
                            <?php else: ?>
                                <?= h($demande['client_telephone']) ?>
                            <?php endif; ?>
                            <?php if ($traitementAdminDemande && $abonnementClientActif): ?>
                                <small><?= h($abonnementClientActif['formule_nom'] ?? 'Abonnement actif') ?><?= isset($abonnementClientActif['credits_restants']) ? ' · ' . (int) $abonnementClientActif['credits_restants'] . ' crédit(s)' : '' ?></small>
                            <?php endif; ?>
                        </span>
                    </span>
                </div>
                <?php if (!empty($demande['est_demande_entreprise'])): ?>
                    <div class="dossier__ligne">
                        <span>Demandé par</span>
                        <span><?= h(trim((string) ($demande['demandeur_nom'] ?? '')) ?: $demande['client_nom']) ?></span>
                    </div>
                <?php endif; ?>
                <div class="dossier__ligne"><span>Catégorie</span><span><?= h($demande['categorie_nom']) ?></span></div>
                <div class="dossier__ligne dossier__ligne--adresse"><span>Adresse</span><span><?= h($demande['quartier'] . ', ' . $demande['ville']) ?><?php if (!empty($demande['adresse_details'])): ?><br><small class="texte-doux"><?= h($demande['adresse_details']) ?></small><?php endif; ?></span></div>
                <?php if (!empty($demande['date_creneau_souhaite']) && $demande['heure_creneau_souhaitee'] !== null): ?>
                    <div class="dossier__ligne dossier__ligne--creneau"><span>Créneau souhaité</span><span><?= h(date('d/m/Y', strtotime($demande['date_creneau_souhaite']))) ?> · <?= sprintf('%02d:00–%02d:00', (int) $demande['heure_creneau_souhaitee'], (int) $demande['heure_creneau_souhaitee'] + 1) ?><br><small class="texte-doux">À confirmer avec le client</small></span></div>
                <?php endif; ?>
                <div class="dossier__ligne dossier__ligne--description"><span>Description</span><span><?= nl2br(h($demande['description'])) ?></span></div>
                <?php if ($attributionCoordinateur): ?>
                    <div class="dossier__ligne dossier__ligne--description">
                        <span>Commentaire interne · <?= h($attributionCoordinateur['conseiller_nom']) ?></span>
                        <span><?= nl2br(h($attributionCoordinateur['commentaire_interne'])) ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($paiement): ?>
                    <div class="dossier__ligne dossier__ligne--paiement">
                        <span>Paiement</span>
                        <span>
                            <span class="pastille pastille--<?= h($paiement['statut']) ?>"><?= h(ucfirst(str_replace('_', ' ', (string) $paiement['statut']))) ?></span>
                            <strong class="montant"><?= number_format((float) $paiement['montant'], 0, ',', ' ') ?> FCFA</strong>
                            <small class="texte-doux">(<?= h($paiement['methode'] === 'especes' ? 'Espèces' : str_replace('_', ' ', (string) $paiement['methode'])) ?>)</small>
                        </span>
                    </div>
                <?php elseif ($demande['statut'] === 'terminee'): ?>
                    <div class="dossier__ligne"><span>Paiement</span><span class="texte-doux">En attente de paiement par le client</span></div>
                <?php endif; ?>

                <?php if (!empty($demande['photo_path'])): ?>
                    <div class="dossier__photo-bloc">
                        <div class="dossier__photo-label">Photo jointe</div>
                        <a href="/allopro/public/<?= h($demande['photo_path']) ?>" target="_blank" rel="noopener">
                            <img src="/allopro/public/<?= h($demande['photo_path']) ?>" class="dossier__photo" alt="Photo jointe à la demande">
                        </a>
                    </div>
                <?php endif; ?>

                <?php if (!$estCoordinateur || $traitementAdminDemande): ?>
                    <div class="dossier__ligne">
                        <a href="messagerie.php?client_id=<?= (int) $demande['client_id'] ?>" class="bouton-message--ligne">
                            <svg class="icone-msg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>
                                <circle class="icone-msg__point" cx="8.5"  cy="12" r="1" fill="currentColor" stroke="none"/>
                                <circle class="icone-msg__point" cx="12"   cy="12" r="1" fill="currentColor" stroke="none"/>
                                <circle class="icone-msg__point" cx="15.5" cy="12" r="1" fill="currentColor" stroke="none"/>
                            </svg>
                            Écrire au client
                        </a>
                    </div>
                <?php endif; ?>
            </section>

            <!-- ===== Colonne droite : actions ===== -->
            <div class="colonne-actions">

                <?php if ($messageSucces !== ''): ?>
                    <div class="alerte alerte--succes" role="status"><?= h($messageSucces) ?></div>
                <?php endif; ?>
                <?php if ($erreur): ?>
                    <div class="alerte alerte--erreur" role="alert"><?= h($erreur) ?></div>
                <?php endif; ?>
                <?php if ($estCoordinateur && !$coordinateurPeutAgir): ?>
                    <section class="carte" role="status">
                        <h2 class="carte__titre">Consultation uniquement</h2>
                        <p class="texte-doux" style="margin:0;">
                            <?php if ($consultationDossierInterne): ?>
                                <?= h($messageConsultationDossier ?? 'Cette fiche est liée à un devis entreprise. Consultez les informations et l’avancement du dossier ; son traitement reste dans les espaces dédiés.') ?>
                            <?php elseif ($attributionCoordinateur && !empty($attributionCoordinateur['coordinateur_nom'])): ?>
                                Ce dossier est pris en charge par <?= h($attributionCoordinateur['coordinateur_nom']) ?>. Vous pouvez consulter ses informations et son avancement, mais seul le coordinateur responsable peut effectuer des actions.
                            <?php else: ?>
                                Ce dossier n’est pas affecté à votre file de traitement. Vous pouvez consulter ses informations et son avancement, mais pas effectuer d’actions.
                            <?php endif; ?>
                        </p>
                    </section>
                <?php endif; ?>

                <?php if ($traitementAdminDemande): ?>
                    <section class="carte suivi-technicien" aria-labelledby="titre-suivi-technicien">
                        <h2 class="carte__titre" id="titre-suivi-technicien">Suivi technicien</h2>
                        <?php if ($erreurSuiviTechnicienAdmin !== null): ?>
                            <p class="texte-doux" role="alert"><?= h($erreurSuiviTechnicienAdmin) ?></p>
                        <?php elseif (!$intervention || empty($intervention['technicien_id'])): ?>
                            <p class="texte-doux suivi-technicien__vide">Le suivi sera disponible dès qu’un technicien sera affecté à la mission.</p>
                        <?php else: ?>
                            <p class="suivi-technicien__mission">
                                <span>Technicien</span>
                                <strong><?= h($intervention['technicien_nom_reel'] ?? $intervention['technicien_nom'] ?? 'Technicien affecté') ?></strong>
                            </p>

                            <?php if ($suiviTechnicienAdmin['checklist']): ?>
                                <?php
                                $nombreChecklistTerminee = count(array_filter(
                                    $suiviTechnicienAdmin['checklist'],
                                    static fn(array $element): bool => (bool) $element['terminee']
                                ));
                                $nombreChecklistTotal = count($suiviTechnicienAdmin['checklist']);
                                ?>
                                <div class="suivi-technicien__section">
                                    <div class="suivi-technicien__section-entete">
                                        <h3>Checklist d’intervention</h3>
                                        <span><?= $nombreChecklistTerminee ?>/<?= $nombreChecklistTotal ?> terminée(s)</span>
                                    </div>
                                    <progress value="<?= $nombreChecklistTerminee ?>" max="<?= $nombreChecklistTotal ?>" aria-label="Progression de la checklist"></progress>
                                    <ul class="suivi-technicien__checklist">
                                        <?php foreach ($suiviTechnicienAdmin['checklist'] as $elementChecklist): ?>
                                            <li class="<?= !empty($elementChecklist['terminee']) ? 'is-terminee' : '' ?>">
                                                <span aria-hidden="true"><?= !empty($elementChecklist['terminee']) ? '✓' : '○' ?></span>
                                                <?= h($elementChecklist['libelle']) ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php elseif (in_array($intervention['statut'], ['en_attente', 'refusee', 'annulee'], true)): ?>
                                <p class="texte-doux suivi-technicien__vide">La checklist sera initialisée lorsque le technicien commencera la mission.</p>
                            <?php endif; ?>

                            <?php if (!empty($intervention['photo_avant']) || !empty($intervention['photo_apres'])): ?>
                                <div class="suivi-technicien__section">
                                    <h3>Photos de l’intervention</h3>
                                    <div class="suivi-technicien__photos">
                                        <?php foreach (['photo_avant' => 'Avant intervention', 'photo_apres' => 'Après intervention'] as $clePhoto => $libellePhoto): ?>
                                            <?php if (!empty($intervention[$clePhoto])): ?>
                                                <a href="/allopro/public/<?= h($intervention[$clePhoto]) ?>" target="_blank" rel="noopener">
                                                    <img src="/allopro/public/<?= h($intervention[$clePhoto]) ?>" alt="<?= h($libellePhoto) ?>" loading="lazy">
                                                    <span><?= h($libellePhoto) ?></span>
                                                </a>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="suivi-technicien__section">
                                <div class="suivi-technicien__section-entete">
                                    <h3>Documents de mission</h3>
                                    <span><?= count($suiviTechnicienAdmin['documents']) ?></span>
                                </div>
                                <?php if ($suiviTechnicienAdmin['documents']): ?>
                                    <ul class="suivi-technicien__documents">
                                        <?php foreach ($suiviTechnicienAdmin['documents'] as $documentMission): ?>
                                            <li>
                                                <a href="/allopro/views/admin/document-intervention.php?demande_id=<?= (int) $id ?>&amp;id=<?= (int) $documentMission['id'] ?>" target="_blank" rel="noopener">
                                                    <span><?= h($documentMission['nom_original']) ?></span>
                                                    <small><?= h(date('d/m/Y à H:i', strtotime($documentMission['date_creation']))) ?></small>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="texte-doux suivi-technicien__vide">Aucun document transmis pour cette mission.</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>

                <section class="carte notes-dossier" aria-labelledby="titre-notes-dossier">
                    <h2 class="carte__titre" id="titre-notes-dossier">Notes internes</h2>
                    <p class="texte-doux notes-dossier__intro"><?= ($consultationDossierInterne || $traitementAdminDemande) ? 'Notes internes accessibles aux équipes internes autorisées.' : 'Ces notes sont visibles par les conseillers et les coordinateurs.' ?></p>
                    <?php if ($notesDemande): ?>
                        <ol class="notes-dossier__liste">
                            <?php foreach ($notesDemande as $noteDossier): ?>
                                <li class="notes-dossier__item">
                                    <div class="notes-dossier__meta">
                                        <strong><?= h($noteDossier['auteur_nom']) ?></strong>
                                        <time datetime="<?= h(date(DATE_ATOM, strtotime($noteDossier['date_creation']))) ?>">
                                            <?= h(date('d/m/Y à H:i', strtotime($noteDossier['date_creation']))) ?>
                                        </time>
                                    </div>
                                    <p><?= nl2br(h($noteDossier['note'])) ?></p>
                                </li>
                            <?php endforeach; ?>
                        </ol>
                    <?php else: ?>
                        <p class="texte-doux notes-dossier__vide">Aucune note ajoutée à ce dossier.</p>
                    <?php endif; ?>

                    <?php if (!$estCoordinateur || $traitementAdminDemande): ?>
                        <form method="POST" class="notes-dossier__form">
                            <input type="hidden" name="csrf" value="<?= h($_SESSION[$csrfKey]) ?>">
                            <label class="champ-label" for="note-dossier">Ajouter une note</label>
                            <textarea class="champ" id="note-dossier" name="note_dossier" rows="3" maxlength="3000" required placeholder="Ajoutez une information utile au suivi du dossier…"><?= h($noteSaisie) ?></textarea>
                            <button type="submit" name="ajouter_note" value="1" class="btn btn--principal btn--plein">Ajouter la note</button>
                        </form>
                    <?php endif; ?>
                </section>

                <?php if ($demande['statut'] === 'nouvelle' && $estCoordinateur && $coordinateurPeutAgir
                    && ($traitementAdminDemande
                        || ($attributionCoordinateur && $attributionCoordinateur['statut'] === 'en_attente'))): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Attribuer une mission</h2>
                        <?php if (!$techniciensCompatibles): ?>
                            <p class="texte-doux" style="margin:0;">Aucun technicien actif ne possède actuellement les compétences requises pour cette demande.</p>
                        <?php else: ?>
                        <form method="POST" id="form-attribution">
                            <input type="hidden" name="csrf" value="<?= h($_SESSION[$csrfKey]) ?>">
                            <label class="champ-label" for="select-partenaire">Partenaire</label>
                            <select name="partenaire_id" id="select-partenaire" class="champ" required>
                                <option value="">-- Choisir --</option>
                                <?php foreach ($partenairesActifs as $p): ?>
                                    <option value="<?= (int) $p['id'] ?>"><?= h($p['nom_entreprise']) ?> · <?= h($niveauxPartenaire[$p['niveau']] ?? 'Partenaire') ?><?= !empty($p['quartier_compatible']) ? ' · ' . h($p['quartier_compatible']) : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="attribution-apercu attribution-apercu--partenaire" id="apercu-partenaire" hidden aria-live="polite">
                                <span class="attribution-apercu__icone" aria-hidden="true">
                                    <svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 9h.01M15 9h.01M9 13h.01M15 13h.01M10 21v-4h4v4"/></svg>
                                </span>
                                <span class="attribution-apercu__contenu">
                                    <strong class="attribution-apercu__nom"></strong>
                                    <span class="attribution-apercu__meta">
                                        <span class="attribution-apercu__niveau"></span>
                                        <span class="attribution-apercu__quartier"></span>
                                    </span>
                                </span>
                            </div>

                            <label class="champ-label" for="select-technicien">Technicien</label>
                            <select name="technicien_id" id="select-technicien" class="champ" required disabled aria-describedby="aide-technicien">
                                <option value="">-- Choisir d'abord un partenaire --</option>
                            </select>
                            <p class="champ-aide" id="aide-technicien" role="status" aria-live="polite">La liste des techniciens s’affichera après le choix du partenaire.</p>
                            <div class="attribution-apercu attribution-apercu--technicien" id="apercu-technicien" hidden aria-live="polite">
                                <span class="attribution-apercu__icone" aria-hidden="true">
                                    <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
                                </span>
                                <span class="attribution-apercu__contenu">
                                    <strong class="attribution-apercu__nom"></strong>
                                    <span class="attribution-apercu__competences"></span>
                                    <span class="attribution-apercu__note"></span>
                                </span>
                            </div>

                            <label class="champ-label" for="select-date-creneau">Date de l’intervention</label>
                            <input type="date" name="date_creneau_planifie" id="select-date-creneau" class="champ"
                                   min="<?= h($dateMinCreneau) ?>" max="<?= h($dateMaxCreneau) ?>"
                                   value="<?= h($datePrefereeCreneau) ?>" required disabled>
                            <label class="champ-label" for="select-heure-creneau">Créneau horaire disponible</label>
                            <select name="heure_creneau_planifie" id="select-heure-creneau" class="champ" required disabled aria-describedby="aide-creneau">
                                <option value="">Choisissez d’abord un technicien et une date</option>
                            </select>
                            <p class="champ-aide" id="aide-creneau" role="status" aria-live="polite">Les créneaux indisponibles et déjà réservés ne seront pas proposés.</p>

                            <button type="submit" class="btn btn--principal btn--plein">Attribuer la mission</button>
                        </form>
                        <?php endif; ?>
                    </section>

                <?php elseif ($demande['statut'] === 'nouvelle' && !$estCoordinateur && !$attributionCoordinateur): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Transmettre aux coordinateurs</h2>
                        <p class="texte-doux">Ajoutez une note interne pour expliquer le besoin ou signaler un point à vérifier. Elle sera visible uniquement par l’équipe.</p>
                        <form method="POST">
                            <input type="hidden" name="csrf" value="<?= h($_SESSION[$csrfKey]) ?>">
                            <label class="champ-label" for="commentaire-interne">Commentaire interne</label>
                            <textarea class="champ" id="commentaire-interne" name="commentaire_interne" rows="4" maxlength="3000" required placeholder="Contexte, vérifications réalisées, consigne au coordinateur…"></textarea>
                            <button type="submit" name="transmettre_coordinateurs" value="1" class="btn btn--principal btn--plein">Envoyer aux coordinateurs</button>
                        </form>
                    </section>

                <?php elseif ($demande['statut'] === 'nouvelle' && !$estCoordinateur && $attributionCoordinateur): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Dossier transmis aux coordinateurs</h2>
                        <p class="texte-doux" style="margin:0;">Le dossier attend son traitement dans la file commune des coordinateurs.</p>
                    </section>

                <?php elseif ($demande['statut'] === 'nouvelle' && $estCoordinateur && $coordinateurPeutAgir): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Dossier déjà traité</h2>
                        <p class="texte-doux" style="margin:0;">Cette demande n’est plus disponible dans la file des coordinateurs.</p>
                    </section>

                <?php elseif (in_array($demande['statut'], $statutsModifiables, true) && $intervention): ?>
                    <section class="carte">
                        <h2 class="carte__titre"><?= $intervention['statut'] === 'en_attente' ? 'Mission proposée au technicien' : 'Mission en cours' ?></h2>
                        <div class="dossier__ligne"><span>Partenaire</span><span><strong><?= h($intervention['nom_entreprise']) ?></strong><span class="niveau-partenaire niveau-partenaire--<?= h($intervention['partenaire_niveau'] ?? 'partenaire') ?>"><?= h($niveauxPartenaire[$intervention['partenaire_niveau'] ?? ''] ?? 'Partenaire') ?></span></span></div>
                        <div class="dossier__ligne"><span>Quartier</span><span><?= h($intervention['quartier_partenaire'] ?: 'Non renseigné pour ce quartier') ?></span></div>
                        <div class="dossier__ligne"><span>Technicien</span><span><strong><?= h($intervention['technicien_nom_reel']) ?></strong><?php if (!empty($intervention['technicien_competences_affichage'])): ?><small class="technicien-competences" title="<?= h($intervention['technicien_competences']) ?>"><?= h($intervention['technicien_competences_affichage']) ?></small><?php endif; ?><?php if ($notesTechnicienMission && $notesTechnicienMission['note_clients'] !== null): ?><small class="technicien-note"><span aria-hidden="true">★</span> <?= h(number_format((float) $notesTechnicienMission['note_clients'], 1, ',', ' ')) ?>/5 · <?= (int) $notesTechnicienMission['nb_avis_clients'] ?> avis</small><?php else: ?><small class="technicien-note technicien-note--vide">Pas encore noté par les clients</small><?php endif; ?></span></div>
                        <div class="dossier__ligne"><span>Statut mission</span><span><?= h($libellesMission[$intervention['statut']] ?? str_replace('_', ' ', (string) $intervention['statut'])) ?></span></div>
                        <?php if (!empty($intervention['date_creneau_planifie']) && $intervention['heure_creneau_planifie'] !== null): ?>
                            <div class="dossier__ligne"><span>Créneau planifié</span><span><?= h(date('d/m/Y', strtotime($intervention['date_creneau_planifie']))) ?> · <?= sprintf('%02d:00–%02d:00', (int) $intervention['heure_creneau_planifie'], ((int) $intervention['heure_creneau_planifie'] + 1) % 24) ?></span></div>
                        <?php endif; ?>
                    </section>

                    <?php if ($estCoordinateur && $coordinateurPeutAgir && $intervention['statut'] === 'en_attente'): ?>
                        <section class="carte">
                            <h2 class="carte__titre">Réaffecter la mission</h2>
                            <?php if (!$techniciensReaffectation): ?>
                                <p class="texte-doux" style="margin:0;">Aucun autre technicien actif avec les compétences requises n’est disponible pour cette mission.</p>
                            <?php else: ?>
                                <p class="texte-doux" style="margin:0 0 14px;">Le technicien n’a pas encore accepté. Vous pouvez corriger l’affectation avant sa réponse.</p>
                                <form method="POST" id="form-reattribuer-mission" onsubmit="return confirm('Réaffecter cette mission au technicien choisi ?');">
                                    <input type="hidden" name="csrf" value="<?= h($_SESSION[$csrfKey]) ?>">
                                    <label class="champ-label" for="technicien-reaffectation">Nouveau technicien</label>
                                    <select name="technicien_reaffectation_id" id="technicien-reaffectation" class="champ" required>
                                        <option value="">Choisir un technicien</option>
                                        <?php foreach ($techniciensReaffectation as $candidat): ?>
                                            <option value="<?= (int) $candidat['id'] ?>" title="<?= h($candidat['competences'] ?? '') ?>"><?= h($candidat['nom']) ?> · <?= h($candidat['competences_affichage'] ?? $candidat['competences'] ?? 'Compétences non renseignées') ?> · <?= h($candidat['nom_entreprise']) ?> (<?= h($candidat['zones_intervention'] ?? 'Zones non renseignées') ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                    <label class="champ-label" for="date-reaffectation">Date du créneau</label>
                                    <input type="date" name="date_creneau_reaffectation" id="date-reaffectation" class="champ"
                                           min="<?= h($dateMinCreneau) ?>" max="<?= h($dateMaxCreneau) ?>"
                                           value="<?= h($dateCreneauReaffectation) ?>" required>
                                    <label class="champ-label" for="heure-reaffectation">Créneau disponible</label>
                                    <select name="heure_creneau_reaffectation" id="heure-reaffectation" class="champ" required disabled>
                                        <option value="">Choisissez un technicien et une date</option>
                                    </select>
                                    <p class="champ-aide" id="aide-reaffectation" role="status" aria-live="polite">Les créneaux sont vérifiés selon les disponibilités du nouveau technicien.</p>
                                    <button type="submit" name="reattribuer_mission" value="1" class="btn btn--principal btn--plein">Réaffecter la mission</button>
                                </form>
                            <?php endif; ?>
                        </section>
                    <?php endif; ?>

                    <?php if ($peutModifierCreneau): ?>
                        <section class="carte">
                            <h2 class="carte__titre">Modifier le créneau</h2>
                            <p class="texte-doux" style="margin:0 0 14px;">Possible tant que le technicien n’est pas en route. Les créneaux indisponibles ou déjà réservés ne seront pas proposés.</p>
                            <form method="POST" id="form-modifier-creneau">
                                <input type="hidden" name="csrf" value="<?= h($_SESSION[$csrfKey]) ?>">
                                <label class="champ-label" for="modifier-date-creneau">Nouvelle date</label>
                                <input type="date" name="date_creneau_planifie" id="modifier-date-creneau" class="champ"
                                       min="<?= h($dateMinCreneau) ?>" max="<?= h($dateMaxCreneau) ?>"
                                       value="<?= h($dateCreneauMission) ?>" required>
                                <label class="champ-label" for="modifier-heure-creneau">Créneau disponible</label>
                                <select name="heure_creneau_planifie" id="modifier-heure-creneau" class="champ" required disabled aria-describedby="aide-modifier-creneau">
                                    <option value="">Chargement des disponibilités…</option>
                                </select>
                                <p class="champ-aide" id="aide-modifier-creneau" role="status" aria-live="polite">Chargement des créneaux du technicien…</p>
                                <button type="submit" name="modifier_creneau_planifie" value="1" class="btn btn--principal btn--plein">Enregistrer le nouveau créneau</button>
                            </form>
                        </section>
                    <?php endif; ?>

                    <?php if ($intervention['statut'] === 'en_attente'): ?>
                        <section class="carte">
                            <h2 class="carte__titre">Réponse du technicien en attente</h2>
                            <p class="texte-doux" style="margin:0;">Le technicien doit accepter ou refuser cette proposition avant le démarrage de l’intervention.</p>
                        </section>
                    <?php elseif ($intervention['statut'] === 'refusee'): ?>
                        <section class="carte">
                            <?php if (!$estCoordinateur): ?>
                                <h2 class="carte__titre">Refus transmis au coordinateur</h2>
                                <p class="texte-doux" style="margin:0;">Cette demande attend sa réattribution dans la file du coordinateur.</p>
                            <?php else: ?>
                                <h2 class="carte__titre">Fallback de la mission</h2>
                                <?php if (!$coordinateurPeutAgir): ?>
                                    <p class="texte-doux" style="margin:0;">Cette mission attend sa réattribution. Seul le coordinateur responsable peut déclencher le fallback.</p>
                                <?php elseif (!$fileAttenteFallback): ?>
                                    <p class="texte-doux" style="margin:0;">Aucune demande de réattribution active n’est associée à ce refus.</p>
                                <?php elseif (!$techniciensFallback): ?>
                                    <p class="texte-doux" style="margin:0;">Aucun technicien actif ayant une compétence compatible n’est disponible. La mission reste dans la file de refus.</p>
                                <?php else: ?>
                                    <p class="texte-doux" style="margin:0 0 14px;">Le technicien a refusé la mission. Choisissez un autre technicien compatible pour la lui proposer à nouveau.</p>
                                    <?php if (!empty($fileAttenteFallback['motif'])): ?>
                                        <p class="texte-doux"><strong>Motif du refus :</strong> <?= h($fileAttenteFallback['motif']) ?></p>
                                    <?php endif; ?>
                                    <form method="POST" onsubmit="return confirm('Déclencher le fallback et proposer cette mission au technicien choisi ?');">
                                        <input type="hidden" name="csrf" value="<?= h($_SESSION[$csrfKey]) ?>">
                                        <label class="champ-label" for="technicien-fallback">Technicien de remplacement</label>
                                        <select name="technicien_fallback_id" id="technicien-fallback" class="champ" required>
                                            <option value="">Choisir un technicien</option>
                                            <?php foreach ($techniciensFallback as $candidat): ?>
                                                <option value="<?= (int) $candidat['id'] ?>" title="<?= h($candidat['competences_pertinentes'] ?? '') ?>"><?= h($candidat['nom']) ?> · <?= h($candidat['competences_affichage'] ?? 'Compétences non renseignées') ?> · <?= $candidat['note_moyenne'] !== null ? h(number_format((float) $candidat['note_moyenne'], 1, ',', ' ') . '/5') : 'Pas encore noté' ?> (<?= (int) ($candidat['nombre_avis'] ?? 0) ?> avis) · <?= h($candidat['nom_entreprise']) ?> — <?= h($niveauxPartenaire[$candidat['partenaire_niveau'] ?? ''] ?? 'Partenaire') ?> · <?= h($candidat['zones_intervention'] ?: 'Quartier non renseigné') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button type="submit" name="declencher_fallback" value="1" class="btn btn--principal btn--plein">Déclencher le fallback</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </section>
                    <?php elseif ($coordinateurPeutAgir || !$estCoordinateur): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Mettre à jour le statut</h2>
                        <form method="POST">
                            <label class="champ-label" for="nouveau_statut">Nouvelle étape</label>
                            <select name="nouveau_statut" id="nouveau_statut" class="champ">
                                <?php foreach ($libellesMission as $cle => $label): ?>
                                    <option value="<?= h($cle) ?>" <?= ($intervention['statut'] ?? '') === $cle ? 'selected' : '' ?>><?= h($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn btn--secondaire btn--plein">Mettre à jour</button>
                        </form>
                    </section>

                    <section class="carte">
                        <h2 class="carte__titre">Clôturer l'intervention</h2>
                        <div class="alerte alerte--succes">
                            <?php if (!empty($demande['contrat_b2b_id'])): ?>
                                Cette intervention entreprise est couverte par le contrat B2B #<?= (int) $demande['contrat_b2b_id'] ?>. Un crédit sera consommé à la clôture, sans paiement individuel.
                            <?php else: ?>
                            La couverture sera vérifiée à la clôture. Le montant est requis uniquement si aucun abonnement ou Pass valide ne couvre cette demande.
                            <?php endif; ?>
                        </div>
                        <form method="POST">
                            <label class="champ-label" for="rapport">Rapport d'intervention</label>
                            <textarea name="rapport" id="rapport" class="champ" rows="4" placeholder="Diagnostic, travail réalisé, pièces utilisées..." required></textarea>

                            <?php if (empty($demande['contrat_b2b_id'])): ?>
                                <label class="champ-label" for="montant">Montant facturé (FCFA, si non couvert)</label>
                                <input type="number" name="montant" id="montant" class="champ" placeholder="Ex : 15000" step="1" min="1">
                            <?php endif; ?>

                            <?php if ($demande['mode_paiement'] === 'normal' && empty($demande['contrat_b2b_id'])): ?>
                                <label class="cloture-encaissement">
                                    <input type="checkbox" name="encaisse_especes" value="1">
                                    <span>
                                        <strong>Paiement reçu en espèces</strong>
                                        <small>Cochez uniquement si le client a remis ce montant. Cette confirmation remplace l’application automatique d’un Pass ou abonnement.</small>
                                    </span>
                                </label>
                            <?php endif; ?>

                            <button type="submit" class="btn btn--principal btn--plein">Clôturer l'intervention</button>
                        </form>
                    </section>
                    <?php endif; ?>

                <?php elseif ($demande['statut'] === 'terminee' && $intervention): ?>
                    <section class="carte">
                        <h2 class="carte__titre">Intervention terminée</h2>
                        <?php if (!empty($intervention['date_fin'])): ?>
                            <p class="texte-doux" style="margin:0 0 12px;">Le <?= date('d/m/Y à H:i', strtotime($intervention['date_fin'])) ?></p>
                        <?php endif; ?>
                        <div class="rapport"><?= nl2br(h($intervention['rapport'])) ?></div>
                    </section>

                <?php elseif (!$estCoordinateur || $coordinateurPeutAgir): ?>
                    <section class="carte">
                        <p class="texte-doux" style="margin:0;">Aucune action disponible pour une demande au statut « <?= h($libellesStatut[$demande['statut']] ?? $demande['statut']) ?> ».</p>
                    </section>
                <?php endif; ?>

            </div>
        </div>
        <?php if ($consultationDossierInterne || $traitementAdminDemande): ?>
    </div></main>
</div>
        <?php else: ?>
    </div>
</div>
        <?php endif; ?>

<script>
// Empêche le double envoi des formulaires (double clic)
document.querySelectorAll('form[method="POST"]').forEach(form => {
    form.addEventListener('submit', () => {
        const bouton = form.querySelector('button[type="submit"]');
        if (bouton) setTimeout(() => { bouton.disabled = true; }, 0);
    });
});

// Chargement des techniciens selon le partenaire choisi
const selectPartenaire = document.getElementById('select-partenaire');
if (selectPartenaire) {
    const selectTech = document.getElementById('select-technicien');
    const aideTech = document.getElementById('aide-technicien');
    const apercuPartenaire = document.getElementById('apercu-partenaire');
    const apercuTechnicien = document.getElementById('apercu-technicien');
    const selectDate = document.getElementById('select-date-creneau');
    const selectHeure = document.getElementById('select-heure-creneau');
    const aideCreneau = document.getElementById('aide-creneau');
    const idsCompatibles = <?= json_encode(array_map('intval', array_column($techniciensCompatibles, 'id')), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>.map(String);
    const profilsTechniciens = <?= json_encode($profilsTechniciensCompatibles, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const profilsPartenaires = <?= json_encode($profilsPartenairesCompatibles, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const demandeIdCreneau = <?= (int) $id ?>;
    const dateSouhaiteeClient = <?= json_encode($demande['date_creneau_souhaite'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const heureSouhaiteeClient = <?= $heurePrefereeCreneau === null ? 'null' : (int) $heurePrefereeCreneau ?>;
    let chargementEnCours = 0;
    let chargementCreneauEnCours = 0;

    function afficherApercuPartenaire() {
        const partenaire = profilsPartenaires[selectPartenaire.value];
        if (!apercuPartenaire || !partenaire) {
            if (apercuPartenaire) apercuPartenaire.hidden = true;
            return;
        }
        apercuPartenaire.hidden = false;
        apercuPartenaire.querySelector('.attribution-apercu__nom').textContent = partenaire.nom;
        const niveau = apercuPartenaire.querySelector('.attribution-apercu__niveau');
        niveau.textContent = partenaire.niveau;
        niveau.className = `attribution-apercu__niveau niveau-partenaire--${partenaire.niveau_cle}`;
        const quartier = apercuPartenaire.querySelector('.attribution-apercu__quartier');
        quartier.textContent = partenaire.quartier || 'Quartier non renseigné';
    }

    function afficherApercuTechnicien() {
        const option = selectTech.options[selectTech.selectedIndex];
        const profil = profilsTechniciens[selectTech.value];
        if (!apercuTechnicien || !selectTech.value || !profil) {
            if (apercuTechnicien) apercuTechnicien.hidden = true;
            return;
        }
        apercuTechnicien.hidden = false;
        apercuTechnicien.querySelector('.attribution-apercu__nom').textContent = option.textContent.split(' — ')[0];
        apercuTechnicien.querySelector('.attribution-apercu__competences').textContent =
            profil.competences || 'Compétences compatibles';
        apercuTechnicien.querySelector('.attribution-apercu__note').textContent = profil.note === null
            ? 'Pas encore noté par les clients'
            : `★ ${Number(profil.note).toLocaleString('fr-FR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}/5 · ${profil.avis} avis`;
    }

    function remplir(message, techniciens) {
        selectTech.innerHTML = '';
        selectTech.add(new Option(message, ''));
        // new Option() traite le nom comme du texte : aucun risque d'injection HTML
        (techniciens || []).forEach(t => {
            const profil = profilsTechniciens[String(t.id)] || {};
            const competencesAffichees = profil.competences || '';
            const note = profil.note === null || profil.note === undefined
                ? 'Pas encore noté'
                : `★ ${Number(profil.note).toLocaleString('fr-FR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}/5`;
            const libelle = `${t.nom} — ${competencesAffichees || 'Compétences compatibles'} · ${note}`;
            const option = new Option(libelle, t.id);
            if (t.competences) option.title = t.competences;
            selectTech.add(option);
        });
        if (apercuTechnicien) apercuTechnicien.hidden = true;
        selectTech.disabled = !techniciens || techniciens.length === 0;
        if (techniciens && techniciens.length > 0) {
            aideTech.textContent = `${techniciens.length} technicien${techniciens.length > 1 ? 's' : ''} disponible${techniciens.length > 1 ? 's' : ''}. Les compétences sont indiquées à côté du nom.`;
        }
        selectDate.disabled = !techniciens || techniciens.length === 0;
        if (!selectDate.disabled) chargerCreneaux();
        else {
            selectHeure.innerHTML = '';
            selectHeure.add(new Option('Choisissez d’abord un technicien et une date', ''));
            selectHeure.disabled = true;
        }
    }

    async function chargerCreneaux() {
        const requete = ++chargementCreneauEnCours;
        const technicienId = selectTech.value;
        const date = selectDate.value;
        selectHeure.innerHTML = '';
        selectHeure.add(new Option('Chargement des disponibilités…', ''));
        selectHeure.disabled = true;

        if (!technicienId || !date) {
            selectHeure.innerHTML = '';
            selectHeure.add(new Option('Choisissez d’abord un technicien et une date', ''));
            aideCreneau.textContent = 'Les créneaux indisponibles et déjà réservés ne seront pas proposés.';
            return;
        }

        aideCreneau.textContent = 'Vérification des disponibilités du technicien…';
        try {
            const url = new URL('../../public/api-creneaux-technicien.php', window.location.href);
            url.searchParams.set('demande_id', String(demandeIdCreneau));
            url.searchParams.set('technicien_id', technicienId);
            url.searchParams.set('date', date);
            const reponse = await fetch(url, { cache: 'no-store', credentials: 'same-origin' });
            const resultat = await reponse.json();
            if (!reponse.ok) throw new Error(resultat.error || `HTTP ${reponse.status}`);
            if (requete !== chargementCreneauEnCours) return;

            selectHeure.innerHTML = '';
            selectHeure.add(new Option(resultat.slots.length ? '-- Choisir un créneau --' : 'Aucun créneau disponible', ''));
            (resultat.slots || []).forEach(creneau => {
                selectHeure.add(new Option(creneau.label, String(creneau.value)));
            });
            selectHeure.disabled = !resultat.slots || resultat.slots.length === 0;
            if (date === dateSouhaiteeClient && heureSouhaiteeClient !== null) {
                const optionPreferee = Array.from(selectHeure.options).find(option => option.value === String(heureSouhaiteeClient));
                if (optionPreferee) selectHeure.value = optionPreferee.value;
            }
            aideCreneau.textContent = resultat.slots.length
                ? `${resultat.slots.length} créneau${resultat.slots.length > 1 ? 'x' : ''} disponible${resultat.slots.length > 1 ? 's' : ''} pour ce technicien. Le souhait du client est présélectionné s’il est encore libre.`
                : 'Aucun créneau n’est disponible à cette date. Essayez une autre date.';
        } catch (erreur) {
            if (requete !== chargementCreneauEnCours) return;
            console.error('Impossible de charger les disponibilités du technicien.', erreur);
            selectHeure.innerHTML = '';
            selectHeure.add(new Option('Disponibilités indisponibles', ''));
            aideCreneau.textContent = erreur.message || 'Le chargement a échoué. Réessayez.';
        }
    }

    selectTech.addEventListener('change', () => {
        afficherApercuTechnicien();
        chargerCreneaux();
    });
    selectDate.addEventListener('change', chargerCreneaux);

    selectPartenaire.addEventListener('change', afficherApercuPartenaire);
    selectPartenaire.addEventListener('change', async function () {
        const requete = ++chargementEnCours;
        if (!this.value) {
            remplir("-- Choisir d'abord un partenaire --", null);
            aideTech.textContent = 'La liste des techniciens s’affichera après le choix du partenaire.';
            return;
        }

        selectTech.disabled = true;
        aideTech.textContent = 'Chargement des techniciens…';
        remplir('Chargement…', null);
        try {
            const url = new URL('../../public/api-techniciens.php', window.location.href);
            url.searchParams.set('partenaire_id', this.value);
            const res = await fetch(url);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const techniciensApi = await res.json();
            if (requete !== chargementEnCours) return;
            const techniciens = Array.isArray(techniciensApi)
                ? techniciensApi.filter(t => idsCompatibles.includes(String(t.id)))
                : [];
            if (!Array.isArray(techniciens) || techniciens.length === 0) {
                remplir('Aucun technicien actif', null);
                aideTech.textContent = 'Aucun technicien actif compatible n’est associé à ce partenaire.';
            } else {
                remplir('-- Choisir --', techniciens);
            }
        } catch (e) {
            if (requete !== chargementEnCours) return;
            console.error('Impossible de charger les techniciens du partenaire.', e);
            remplir('Erreur de chargement, réessayez', null);
            aideTech.textContent = 'Le chargement a échoué. Choisissez à nouveau le partenaire pour réessayer.';
        }
    });
}

const formModifierCreneau = document.getElementById('form-modifier-creneau');
if (formModifierCreneau) {
    const selectDateMission = document.getElementById('modifier-date-creneau');
    const selectHeureMission = document.getElementById('modifier-heure-creneau');
    const aideMission = document.getElementById('aide-modifier-creneau');
    const demandeMissionId = <?= (int) $id ?>;
    const interventionMissionId = <?= (int) ($intervention['id'] ?? 0) ?>;
    const technicienMissionId = <?= (int) ($intervention['technicien_id'] ?? 0) ?>;
    const heureMissionActuelle = <?= $intervention && $intervention['heure_creneau_planifie'] !== null
        ? (int) $intervention['heure_creneau_planifie']
        : 'null' ?>;
    let requeteDisponibilites = 0;

    async function chargerDisponibilitesMission() {
        const requete = ++requeteDisponibilites;
        const date = selectDateMission.value;
        selectHeureMission.disabled = true;
        selectHeureMission.innerHTML = '';
        selectHeureMission.add(new Option('Chargement des disponibilités…', ''));
        aideMission.textContent = 'Vérification des créneaux du technicien…';
        try {
            const url = new URL('../../public/api-creneaux-technicien.php', window.location.href);
            url.searchParams.set('demande_id', String(demandeMissionId));
            url.searchParams.set('intervention_id', String(interventionMissionId));
            url.searchParams.set('technicien_id', String(technicienMissionId));
            url.searchParams.set('date', date);
            const reponse = await fetch(url, { cache: 'no-store', credentials: 'same-origin' });
            const resultat = await reponse.json();
            if (!reponse.ok) throw new Error(resultat.error || `HTTP ${reponse.status}`);
            if (requete !== requeteDisponibilites) return;

            const creneaux = Array.isArray(resultat.slots) ? resultat.slots : [];
            selectHeureMission.innerHTML = '';
            selectHeureMission.add(new Option(
                creneaux.length ? '-- Choisir un créneau --' : 'Aucun créneau disponible',
                ''
            ));
            creneaux.forEach(creneau => selectHeureMission.add(new Option(creneau.label, String(creneau.value))));
            selectHeureMission.disabled = creneaux.length === 0;
            if (date === <?= json_encode((string) ($intervention['date_creneau_planifie'] ?? ''), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>
                && heureMissionActuelle !== null
                && Array.from(selectHeureMission.options).some(option => option.value === String(heureMissionActuelle))) {
                selectHeureMission.value = String(heureMissionActuelle);
            }
            aideMission.textContent = creneaux.length
                ? `${creneaux.length} créneau${creneaux.length > 1 ? 'x' : ''} disponible${creneaux.length > 1 ? 's' : ''}.`
                : 'Aucun créneau disponible à cette date. Essayez une autre date.';
        } catch (erreur) {
            if (requete !== requeteDisponibilites) return;
            console.error('Impossible de charger les disponibilités pour modifier le créneau.', erreur);
            selectHeureMission.innerHTML = '';
            selectHeureMission.add(new Option('Disponibilités indisponibles', ''));
            aideMission.textContent = erreur.message || 'Le chargement des disponibilités a échoué.';
        }
    }

    selectDateMission.addEventListener('change', chargerDisponibilitesMission);
    chargerDisponibilitesMission();
}

const formReattribuerMission = document.getElementById('form-reattribuer-mission');
if (formReattribuerMission) {
    const selectTechnicien = document.getElementById('technicien-reaffectation');
    const selectDate = document.getElementById('date-reaffectation');
    const selectHeure = document.getElementById('heure-reaffectation');
    const aide = document.getElementById('aide-reaffectation');
    const demandeIdReaffectation = <?= (int) $id ?>;
    const interventionIdReaffectation = <?= (int) ($intervention['id'] ?? 0) ?>;
    const heureActuelleReaffectation = <?= $heureCreneauReaffectation === null
        ? 'null'
        : $heureCreneauReaffectation ?>;
    let requeteReaffectation = 0;

    async function chargerCreneauxReaffectation() {
        const requete = ++requeteReaffectation;
        const technicienId = selectTechnicien.value;
        const date = selectDate.value;
        selectHeure.disabled = true;
        selectHeure.innerHTML = '';
        selectHeure.add(new Option('Chargement des disponibilités…', ''));
        if (!technicienId || !date) {
            selectHeure.innerHTML = '';
            selectHeure.add(new Option('Choisissez un technicien et une date', ''));
            aide.textContent = 'Les créneaux sont vérifiés selon les disponibilités du nouveau technicien.';
            return;
        }

        aide.textContent = 'Vérification des créneaux du nouveau technicien…';
        try {
            const url = new URL('../../public/api-creneaux-technicien.php', window.location.href);
            url.searchParams.set('demande_id', String(demandeIdReaffectation));
            url.searchParams.set('intervention_id', String(interventionIdReaffectation));
            url.searchParams.set('reaffectation', '1');
            url.searchParams.set('technicien_id', technicienId);
            url.searchParams.set('date', date);
            const reponse = await fetch(url, { cache: 'no-store', credentials: 'same-origin' });
            const resultat = await reponse.json();
            if (!reponse.ok) throw new Error(resultat.error || `HTTP ${reponse.status}`);
            if (requete !== requeteReaffectation) return;

            const creneaux = Array.isArray(resultat.slots) ? resultat.slots : [];
            selectHeure.innerHTML = '';
            selectHeure.add(new Option(
                creneaux.length ? '-- Choisir un créneau --' : 'Aucun créneau disponible',
                ''
            ));
            creneaux.forEach(creneau => selectHeure.add(new Option(creneau.label, String(creneau.value))));
            selectHeure.disabled = creneaux.length === 0;
            if (heureActuelleReaffectation !== null
                && creneaux.some(creneau => String(creneau.value) === String(heureActuelleReaffectation))) {
                selectHeure.value = String(heureActuelleReaffectation);
            }
            aide.textContent = creneaux.length
                ? `${creneaux.length} créneau${creneaux.length > 1 ? 'x' : ''} disponible${creneaux.length > 1 ? 's' : ''} pour ce technicien.`
                : 'Aucun créneau disponible à cette date. Essayez une autre date.';
        } catch (erreur) {
            if (requete !== requeteReaffectation) return;
            console.error('Impossible de charger les disponibilités pour réaffecter la mission.', erreur);
            selectHeure.innerHTML = '';
            selectHeure.add(new Option('Disponibilités indisponibles', ''));
            aide.textContent = erreur.message || 'Le chargement des disponibilités a échoué.';
        }
    }

    selectTechnicien.addEventListener('change', chargerCreneauxReaffectation);
    selectDate.addEventListener('change', chargerCreneauxReaffectation);
    chargerCreneauxReaffectation();
}
</script>
</body>
</html>