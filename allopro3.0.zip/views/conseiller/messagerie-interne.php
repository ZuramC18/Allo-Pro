<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['conseiller']);
verifierAcces('messagerie_interne');
require_once __DIR__ . '/../../includes/icones.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messagerie interne — ALLÔ PRO Conseiller</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
    <link rel="stylesheet" href="../../public/css/messagerie-interne.css?v=<?= filemtime(__DIR__ . '/../../public/css/messagerie-interne.css') ?>">
    <link rel="stylesheet" href="../../public/css/conseiller-messagerie-interne.css?v=<?= filemtime(__DIR__ . '/../../public/css/conseiller-messagerie-interne.css') ?>">
</head>
<body class="page-conseiller-messagerie-interne">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>
    <main class="contenu contenu--messagerie-interne">
        <?php include __DIR__ . '/../../includes/messagerie-interne-corps.php'; ?>
    </main>
</div>
<script src="../../public/js/messagerie-interne.js?v=<?= filemtime(__DIR__ . '/../../public/js/messagerie-interne.js') ?>"></script>
</body>
</html>
