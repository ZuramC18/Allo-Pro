<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('demandes');
require_once __DIR__ . '/../../models/Demande.php';

if (!function_exists('h')) {
    function h($v): string { return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES, 'UTF-8'); }
}

$libellesStatut = [
    'nouvelle'  => 'À transmettre',
    'transmise_coordinateur' => 'Transmise au coordinateur',
    'attribuee' => 'Attribuée',
    'en_cours'  => 'En cours',
    'terminee'  => 'Terminée',
];

// Par défaut, afficher les demandes qui restent à attribuer. Toutes les demandes restent accessibles via le filtre dédié.
$statutFiltre = $_GET['statut'] ?? 'nouvelle';
$filtreToutes = $statutFiltre === 'toutes';
if (!is_string($statutFiltre) || (!$filtreToutes && !isset($libellesStatut[$statutFiltre]))) {
    $statutFiltre = 'nouvelle';
    $filtreToutes = false;
}

// Une seule requête : on compte et on filtre en PHP
$toutes = (new Demande())->getAll(null, true);

$compteurs = array_fill_keys(array_keys($libellesStatut), 0);
$nbUrgentesOuvertes = 0;
foreach ($toutes as &$d) {
    $d['statut_affiche'] = $d['statut'] === 'nouvelle'
        && ($d['attribution_coordinateur_statut'] ?? null) === 'en_attente'
        ? 'transmise_coordinateur'
        : $d['statut'];
    if (isset($compteurs[$d['statut_affiche']])) { $compteurs[$d['statut_affiche']]++; }
    if ($d['urgence'] === 'urgente' && $d['statut'] !== 'terminee') { $nbUrgentesOuvertes++; }
}
unset($d);

$demandes = $filtreToutes
    ? $toutes
    : array_values(array_filter($toutes, fn($d) => $d['statut_affiche'] === $statutFiltre));

function libelleStatut(string $s, array $libelles): string {
    return $libelles[$s] ?? ucfirst(str_replace('_', ' ', $s));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Demandes — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css?v=<?= filemtime(__DIR__ . '/../../public/css/dashboard.css') ?>">
    <link rel="stylesheet" href="../../public/css/liste-demandes.css?v=<?= filemtime(__DIR__ . '/../../public/css/liste-demandes.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-liste-demandes">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-conseiller.php'; ?>

    <div class="contenu">
        <div class="contenu__entete">
            <div>
                <h1 class="contenu__titre">Demandes d'intervention</h1>
                <p class="liste-soustitre"><?= count($toutes) ?> demande<?= count($toutes) > 1 ? 's' : '' ?> au total</p>
            </div>
        </div>

        <!-- Cartes de synthèse -->
        <div class="synthese">
            <a href="?statut=nouvelle" class="synthese__carte synthese__carte--nouvelle">
                <span class="synthese__nombre"><?= $compteurs['nouvelle'] ?></span>
                <span class="synthese__label">À transmettre</span>
            </a>
            <a href="?statut=en_cours" class="synthese__carte synthese__carte--en-cours">
                <span class="synthese__nombre"><?= $compteurs['attribuee'] + $compteurs['en_cours'] ?></span>
                <span class="synthese__label">En traitement</span>
            </a>
            <div class="synthese__carte synthese__carte--urgente">
                <span class="synthese__nombre"><?= $nbUrgentesOuvertes ?></span>
                <span class="synthese__label">Urgentes ouvertes</span>
            </div>
            <a href="?statut=terminee" class="synthese__carte synthese__carte--terminee">
                <span class="synthese__nombre"><?= $compteurs['terminee'] ?></span>
                <span class="synthese__label">Terminées</span>
            </a>
        </div>

        <!-- Filtres + recherche -->
        <div class="barre-outils">
            <div class="filtres">
                <a href="?statut=toutes" class="filtre <?= $filtreToutes ? 'filtre--actif' : '' ?>" <?= $filtreToutes ? 'aria-current="page"' : '' ?>>Toutes <span class="filtre__nb"><?= count($toutes) ?></span></a>
                <?php foreach ($libellesStatut as $cle => $label): ?>
                    <a href="?statut=<?= h($cle) ?>" class="filtre <?= $statutFiltre === $cle ? 'filtre--actif' : '' ?>" <?= $statutFiltre === $cle ? 'aria-current="page"' : '' ?>>
                        <?= h(['nouvelle' => 'À transmettre', 'transmise_coordinateur' => 'Transmises au coordinateur', 'attribuee' => 'Attribuées', 'en_cours' => 'En cours', 'terminee' => 'Terminées'][$cle]) ?> <span class="filtre__nb"><?= $compteurs[$cle] ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <div class="recherche">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="search" id="recherche" placeholder="Dossier, client, quartier…" aria-label="Rechercher dans la liste" aria-controls="corps-tableau">
            </div>
        </div>

        <!-- Tableau -->
        <div class="table-carte">
            <div class="liste-resultats" id="liste-resultats" role="status" aria-live="polite">
                <?= count($demandes) ?> demande<?= count($demandes) > 1 ? 's' : '' ?> affichée<?= count($demandes) > 1 ? 's' : '' ?>
            </div>
            <div class="table-defilement">
                <table class="table-demandes">
                    <thead>
                        <tr>
                            <th>Dossier</th><th>Client</th><th>Catégorie</th><th>Quartier</th>
                            <th>Urgence</th><th>Statut</th><th>Date</th><th></th>
                        </tr>
                    </thead>
                    <tbody id="corps-tableau">
                        <?php foreach ($demandes as $d): ?>
                        <tr class="<?= $d['urgence'] === 'urgente' ? 'ligne--urgente' : '' ?>"
                            tabindex="0"
                            aria-label="Ouvrir le dossier <?= h($d['numero_dossier']) ?> de <?= h($d['client_nom']) ?>"
                            data-href="traiter-demande.php?id=<?= (int) $d['id'] ?>"
                            data-recherche="<?= h(mb_strtolower($d['numero_dossier'] . ' ' . $d['client_nom'] . ' ' . $d['categorie_nom'] . ' ' . $d['quartier'] . ' ' . ($d['entreprise_b2b_nom'] ?? '') . (!empty($d['est_demande_entreprise']) ? ' demande venant d’une entreprise' : ''))) ?>">
                            <td class="cellule-dossier" data-label="Dossier"><?= h($d['numero_dossier']) ?><?php if (!empty($d['est_demande_entreprise'])): ?><span class="badge-demande-entreprise" title="<?= h($d['entreprise_b2b_nom'] ?? '') ?>">Demande venant d’une entreprise</span><?php endif; ?></td>
                            <td data-label="Client"><?= h($d['client_nom']) ?></td>
                            <td data-label="Catégorie"><?= h($d['categorie_nom']) ?></td>
                            <td data-label="Quartier"><?= h($d['quartier']) ?></td>
                            <td data-label="Urgence"><span class="pastille pastille--<?= h($d['urgence']) ?>"><?= h(ucfirst($d['urgence'])) ?></span></td>
                            <td data-label="Statut"><span class="pastille pastille--<?= h($d['statut_affiche']) ?>"><?= h(libelleStatut($d['statut_affiche'], $libellesStatut)) ?></span></td>
                            <td class="cellule-date" data-label="Date">
                                <?= date('d/m/Y', strtotime($d['date_creation'])) ?>
                                <small><?= date('H:i', strtotime($d['date_creation'])) ?></small>
                            </td>
                            <td class="cellule-action" data-label="Action">
                                <a href="traiter-demande.php?id=<?= (int) $d['id'] ?>" class="bouton-traiter">
                                    Traiter
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="liste-vide" id="liste-vide" <?= empty($demandes) ? '' : 'hidden' ?>>
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>
                <p>Aucune demande à afficher.</p>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    var champ = document.getElementById('recherche');
    var lignes = document.querySelectorAll('#corps-tableau tr');
    var vide = document.getElementById('liste-vide');
    var resultats = document.getElementById('liste-resultats');
    var messageVide = vide.querySelector('p');
    var totalInitial = lignes.length;

    // Recherche instantanée
    champ.addEventListener('input', function () {
        var q = champ.value.trim().toLowerCase();
        var visibles = 0;
        lignes.forEach(function (tr) {
            var ok = q === '' || tr.getAttribute('data-recherche').indexOf(q) !== -1;
            tr.hidden = !ok;
            if (ok) visibles++;
        });
        vide.hidden = visibles !== 0;
        resultats.textContent = visibles + ' demande' + (visibles > 1 ? 's' : '') + ' affichée' + (visibles > 1 ? 's' : '');
        messageVide.textContent = totalInitial === 0
            ? 'Aucune demande à afficher.'
            : 'Aucune demande ne correspond à votre recherche.';
    });

    // Ligne entière cliquable (sauf si on clique déjà sur le lien)
    lignes.forEach(function (tr) {
        tr.addEventListener('click', function (e) {
            if (e.target.closest('a')) return;
            window.location.href = tr.getAttribute('data-href');
        });
        tr.addEventListener('keydown', function (e) {
            if (e.target !== tr || (e.key !== 'Enter' && e.key !== ' ')) return;
            e.preventDefault();
            window.location.href = tr.getAttribute('data-href');
        });
    });
})();
</script>
</body>
</html>