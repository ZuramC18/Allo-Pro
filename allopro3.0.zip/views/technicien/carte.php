<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();
require_once __DIR__ . '/../../models/Intervention.php';

$missionId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if ($missionId === false || $missionId === null || $missionId < 1) {
    header('Location: missions.php');
    exit;
}

$technicienId = (int) $_SESSION['technicien_id'];
$mission = (new Intervention())->getByIdEtTechnicien($missionId, $technicienId);
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$missionTerminee = $mission && $mission['statut'] === 'terminee';

if (!$mission) {
    http_response_code(404);
}

$coordonneesValides = $mission
    && is_numeric($mission['adresse_latitude'] ?? null)
    && is_numeric($mission['adresse_longitude'] ?? null)
    && (float) $mission['adresse_latitude'] >= -90
    && (float) $mission['adresse_latitude'] <= 90
    && (float) $mission['adresse_longitude'] >= -180
    && (float) $mission['adresse_longitude'] <= 180;
$adresseRecherche = $mission && !$missionTerminee
    ? implode(', ', array_filter([
        trim((string) ($mission['adresse_google'] ?? '')),
        trim((string) ($mission['quartier'] ?? '')),
        trim((string) ($mission['ville'] ?? '')),
    ], static fn(string $partie): bool => $partie !== ''))
    : '';
$destination = $missionTerminee
    ? ''
    : ($coordonneesValides
    ? (string) $mission['adresse_latitude'] . ',' . (string) $mission['adresse_longitude']
    : $adresseRecherche);
$carteUrl = 'https://maps.google.com/maps?' . http_build_query([
    'q' => $destination,
    'z' => '16',
    'output' => 'embed',
]);
$itineraireUrl = 'https://www.google.com/maps/dir/?' . http_build_query([
    'api' => '1',
    'destination' => $destination,
    'travelmode' => 'driving',
]);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $mission ? 'Itinéraire vers ' . $echapper($mission['numero_dossier']) : 'Mission introuvable' ?> — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/technicien-carte.css?v=<?= filemtime(__DIR__ . '/../../public/css/technicien-carte.css') ?>">
</head>
<body class="page-technicien-carte">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>

    <main class="contenu technicien-carte-page">
        <a class="carte-retour" href="mission.php?id=<?= (int) $missionId ?>"><?= icone('arrow', 16) ?> Retour à la mission</a>

        <?php if (!$mission): ?>
            <section class="carte-introuvable">
                <span><?= icone('alert', 26) ?></span>
                <h1>Mission introuvable</h1>
                <p>Cette intervention n’existe pas ou ne vous est pas attribuée.</p>
                <a href="missions.php">Revenir à mes missions</a>
            </section>
        <?php else: ?>
            <header class="carte-entete">
                <div>
                    <span class="carte-entete__surtitre">Itinéraire d’intervention</span>
                    <h1><?= $echapper($mission['numero_dossier']) ?></h1>
                    <p><?= $echapper($mission['categorie_nom']) ?></p>
                    <?php if (!empty($mission['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($mission['entreprise_b2b_nom']) ? ' · ' . $echapper($mission['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                    <p><?= $echapper($mission['quartier']) ?>, <?= $echapper($mission['ville']) ?></p>
                </div>
                <?php if ($destination !== ''): ?>
                    <a class="carte-google" href="<?= $echapper($itineraireUrl) ?>" target="_blank" rel="noopener noreferrer">
                        <?= icone('pin', 17) ?> Ouvrir l’itinéraire dans Google Maps
                    </a>
                <?php endif; ?>
            </header>

            <section class="carte-panneau" aria-labelledby="carte-titre">
                <div class="carte-panneau__infos">
                    <span class="carte-panneau__icone"><?= icone('pin', 20) ?></span>
                    <div>
                        <h2 id="carte-titre">Adresse du client</h2>
                        <?php if (!$missionTerminee && !empty($mission['adresse_google'])): ?><p><?= $echapper($mission['adresse_google']) ?></p><?php endif; ?>
                        <?php if (!empty($mission['adresse_details'])): ?><p><?= nl2br($echapper($mission['adresse_details'])) ?></p><?php endif; ?>
                        <strong><?= $echapper($mission['quartier']) ?>, <?= $echapper($mission['ville']) ?></strong>
                    </div>
                </div>
                <?php if ($missionTerminee): ?>
                    <div class="carte-indisponible" role="status">
                        <span><?= icone('shield', 20) ?></span>
                        <p>L’adresse précise et l’itinéraire ne sont plus accessibles après la clôture de l’intervention.</p>
                    </div>
                <?php elseif ($destination !== ''): ?>
                    <div class="carte-integree">
                        <iframe
                            src="<?= $echapper($carteUrl) ?>"
                            title="Carte de l’adresse client pour la mission <?= $echapper($mission['numero_dossier']) ?>"
                            loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"
                            allowfullscreen>
                        </iframe>
                    </div>
                    <p class="carte-note">Pour le guidage GPS et les conditions de circulation, ouvrez l’itinéraire dans Google Maps.</p>
                <?php else: ?>
                    <div class="carte-indisponible" role="status">
                        <span><?= icone('alert', 20) ?></span>
                        <p>L’adresse du client n’est pas suffisamment renseignée pour afficher la carte.</p>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
