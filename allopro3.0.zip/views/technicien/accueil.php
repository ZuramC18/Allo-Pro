<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../models/Tache.php';
require_once __DIR__ . '/../../models/Technicien.php';

$technicienId = (int) $_SESSION['technicien_id'];
$nomTechnicien = (string) ($_SESSION['technicien_nom'] ?? 'technicien');
$interventionModel = new Intervention();
$mesMissions = $interventionModel->getByTechnicien($technicienId);
$rappels = (new Tache())->getRappels($technicienId);
$notesTechnicien = (new Technicien())->getNotesActivite($technicienId);

$missionsActives = array_values(array_filter(
    $mesMissions,
    static fn(array $mission): bool => !in_array($mission['statut'], ['terminee', 'annulee', 'refusee'], true)
));
$missionsTerminees = count(array_filter(
    $mesMissions,
    static fn(array $mission): bool => $mission['statut'] === 'terminee'
));
$missionsUrgentes = count(array_filter(
    $missionsActives,
    static fn(array $mission): bool => $mission['urgence'] === 'urgente'
));
$missionsAConsulter = array_slice($missionsActives, 0, 4);
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$statutsMissions = [
    'en_attente' => 'À confirmer',
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Accueil — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/technicien-accueil.css?v=<?= filemtime(__DIR__ . '/../../public/css/technicien-accueil.css') ?>">
</head>
<body class="page-technicien-accueil">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>

    <main class="contenu technicien-accueil">
        <section class="technicien-bienvenue" aria-labelledby="technicien-bienvenue-titre">
            <div class="technicien-bienvenue__contenu">
                <span class="technicien-bienvenue__surtitre">Votre espace professionnel</span>
                <h1 id="technicien-bienvenue-titre">Bonjour, <?= $echapper($nomTechnicien) ?></h1>
                <p>Suivez vos interventions, vos priorités et vos rappels depuis un seul endroit.</p>
                <a class="technicien-bienvenue__action" href="missions.php">Consulter mes missions <?= icone('arrow', 17) ?></a>
            </div>
            <div class="technicien-bienvenue__illustration" aria-hidden="true">
                <span><?= icone('wrench', 42) ?></span>
                <i></i><i></i>
            </div>
        </section>

        <section class="technicien-synthese" aria-label="Résumé de votre activité">
            <a class="technicien-synthese__carte technicien-synthese__carte--actives" href="missions.php?statut=actives">
                <span class="technicien-synthese__icone"><?= icone('bolt', 20) ?></span>
                <span class="technicien-synthese__valeur"><?= count($missionsActives) ?></span>
                <span class="technicien-synthese__libelle">Missions à suivre</span>
                <span class="technicien-synthese__detail">à suivre</span>
            </a>
            <a class="technicien-synthese__carte technicien-synthese__carte--urgentes" href="missions.php?urgence=urgente">
                <span class="technicien-synthese__icone"><?= icone('alert', 20) ?></span>
                <span class="technicien-synthese__valeur"><?= $missionsUrgentes ?></span>
                <span class="technicien-synthese__libelle">Priorités urgentes</span>
                <span class="technicien-synthese__detail">parmi vos missions actives</span>
            </a>
            <a class="technicien-synthese__carte technicien-synthese__carte--terminees" href="missions.php?statut=terminee">
                <span class="technicien-synthese__icone"><?= icone('check', 20) ?></span>
                <span class="technicien-synthese__valeur"><?= $missionsTerminees ?></span>
                <span class="technicien-synthese__libelle">Missions terminées</span>
                <span class="technicien-synthese__detail">historique réalisé</span>
            </a>
            <a class="technicien-synthese__carte technicien-synthese__carte--rappels" href="taches.php">
                <span class="technicien-synthese__icone"><?= icone('clipboard', 20) ?></span>
                <span class="technicien-synthese__valeur"><?= count($rappels) ?></span>
                <span class="technicien-synthese__libelle">Rappels de tâches</span>
                <span class="technicien-synthese__detail"><?= count($rappels) > 0 ? 'à consulter' : 'aucun rappel en attente' ?></span>
            </a>
        </section>

        <?php if ($notesTechnicien): ?>
            <section class="technicien-notes" aria-label="Vos notes">
                <article class="technicien-note technicien-note--client">
                    <span class="technicien-note__icone"><?= icone('star', 20) ?></span>
                    <div class="technicien-note__contenu">
                        <span class="technicien-note__libelle">Note des clients</span>
                        <strong><?= $notesTechnicien['note_clients'] !== null ? number_format((float) $notesTechnicien['note_clients'], 1, ',', ' ') . '<small>/5</small>' : '—' ?></strong>
                        <span class="technicien-note__detail">
                            <?= (int) $notesTechnicien['nb_avis_clients'] ?> avis client<?= (int) $notesTechnicien['nb_avis_clients'] === 1 ? '' : 's' ?>
                        </span>
                    </div>
                </article>
                <article class="technicien-note technicien-note--allopro">
                    <span class="technicien-note__icone"><?= icone('shield', 20) ?></span>
                    <div class="technicien-note__contenu">
                        <span class="technicien-note__libelle">Note ALLÔ PRO</span>
                        <strong><?= $notesTechnicien['note_allopro'] !== null ? number_format((float) $notesTechnicien['note_allopro'], 1, ',', ' ') . '<small>/5</small>' : '—' ?></strong>
                        <span class="technicien-note__detail">
                            <?= (int) $notesTechnicien['nb_missions_acceptees'] ?> acceptée<?= (int) $notesTechnicien['nb_missions_acceptees'] === 1 ? '' : 's' ?> ·
                            <?= (int) $notesTechnicien['nb_missions_refusees'] ?> refusée<?= (int) $notesTechnicien['nb_missions_refusees'] === 1 ? '' : 's' ?>
                        </span>
                        <span class="technicien-note__explication">Basée sur la part des propositions acceptées.</span>
                    </div>
                </article>
            </section>
        <?php endif; ?>

        <div class="technicien-accueil__grille">
            <section class="technicien-carte technicien-rappels" aria-labelledby="technicien-rappels-titre">
                <header class="technicien-carte__entete">
                    <div>
                        <span class="technicien-carte__surtitre">À ne pas oublier</span>
                        <h2 id="technicien-rappels-titre">Mes rappels</h2>
                    </div>
                    <a href="taches.php" aria-label="Voir toutes mes tâches"><?= icone('arrow', 17) ?></a>
                </header>
                <?php if ($rappels): ?>
                    <ul class="technicien-rappels__liste">
                        <?php foreach (array_slice($rappels, 0, 4) as $rappel): ?>
                            <?php
                            $echeanceRappel = new DateTimeImmutable($rappel['date_echeance']);
                            $enRetard = $echeanceRappel < new DateTimeImmutable();
                            ?>
                            <li>
                                <span class="technicien-rappels__icone <?= $enRetard ? 'technicien-rappels__icone--retard' : '' ?>">
                                    <?= icone($enRetard ? 'alert' : 'clock', 16) ?>
                                </span>
                                <span class="technicien-rappels__texte">
                                    <strong><?= $echapper($rappel['titre']) ?></strong>
                                    <small><?= $echapper($enRetard ? 'En retard' : 'Aujourd’hui') ?> · <?= $echapper($echeanceRappel->format('d/m à H:i')) ?></small>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if (count($rappels) > 4): ?>
                        <a class="technicien-rappels__plus" href="taches.php">Voir les <?= count($rappels) - 4 ?> autres rappels</a>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="technicien-vide technicien-vide--compact">
                        <span><?= icone('check', 19) ?></span>
                        <p>Aucun rappel aujourd’hui ou en retard.</p>
                        <a href="taches.php">Ouvrir mes tâches</a>
                    </div>
                <?php endif; ?>
            </section>

            <section class="technicien-carte technicien-missions-recentes" aria-labelledby="technicien-missions-titre">
                <header class="technicien-carte__entete">
                    <div>
                        <span class="technicien-carte__surtitre">Suivi terrain</span>
                        <h2 id="technicien-missions-titre">Missions à suivre</h2>
                    </div>
                    <a href="missions.php">Toutes mes missions <?= icone('arrow', 16) ?></a>
                </header>
                <?php if ($missionsAConsulter): ?>
                    <div class="technicien-missions__liste">
                        <?php foreach ($missionsAConsulter as $mission): ?>
                            <?php $statutMission = (string) $mission['statut']; ?>
                            <a class="technicien-mission" href="mission.php?id=<?= (int) $mission['id'] ?>">
                                <span class="technicien-mission__icone"><?= icone('wrench', 17) ?></span>
                                <span class="technicien-mission__contenu">
                                    <strong><?= $echapper($mission['categorie_nom']) ?></strong>
                                    <small><?= $echapper($mission['numero_dossier']) ?> · <?= $echapper($mission['quartier']) ?></small>
                                    <?php if (!empty($mission['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($mission['entreprise_b2b_nom']) ? ' · ' . $echapper($mission['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                                </span>
                                <span class="technicien-mission__badges">
                                    <?php if ($mission['urgence'] === 'urgente'): ?><span class="technicien-mission__urgence">Urgente</span><?php endif; ?>
                                    <span class="technicien-mission__statut technicien-mission__statut--<?= $echapper($statutMission) ?>"><?= $echapper($statutsMissions[$statutMission] ?? ucfirst(str_replace('_', ' ', $statutMission))) ?></span>
                                </span>
                                <?= icone('arrow', 16) ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="technicien-vide">
                        <span><?= icone('inbox', 24) ?></span>
                        <strong>Vous êtes à jour</strong>
                        <p>Aucune mission active à suivre pour le moment.</p>
                        <a href="missions.php">Consulter l’historique des missions</a>
                    </div>
                <?php endif; ?>
            </section>
        </div>

        <section class="technicien-acces" aria-labelledby="technicien-acces-titre">
            <div class="technicien-acces__entete">
                <div>
                    <span class="technicien-carte__surtitre">Vos outils</span>
                    <h2 id="technicien-acces-titre">Accès rapides</h2>
                </div>
            </div>
            <div class="technicien-acces__liens">
                <a href="missions.php"><?= icone('wrench', 18) ?><span>Mes missions</span><?= icone('arrow', 15) ?></a>
                <a href="taches.php"><?= icone('clipboard', 18) ?><span>Mes tâches</span><?= icone('arrow', 15) ?></a>
                <a href="messagerie.php"><?= icone('messages', 18) ?><span>Messagerie interne</span><?= icone('arrow', 15) ?></a>
                <a href="reglages.php"><?= icone('settings', 18) ?><span>Réglages du compte</span><?= icone('arrow', 15) ?></a>
            </div>
        </section>
    </main>
</div>
</body>
</html>
