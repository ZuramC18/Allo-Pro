<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();
require_once __DIR__ . '/../../models/IndisponibiliteTechnicien.php';
require_once __DIR__ . '/../../models/Parametre.php';

$technicienId = (int) $_SESSION['technicien_id'];
$parametres = new Parametre();
$heureDebut = max(0, min(23, (int) $parametres->get('heure_debut_indisponibilites', '8')));
$heureFin = max($heureDebut + 1, min(24, (int) $parametres->get('heure_fin_indisponibilites', '20')));
$dateDemandee = is_string($_GET['semaine'] ?? null) ? $_GET['semaine'] : '';
$dateSemaine = DateTimeImmutable::createFromFormat('!Y-m-d', $dateDemandee);
if (!$dateSemaine || $dateSemaine->format('Y-m-d') !== $dateDemandee) {
    $dateSemaine = new DateTimeImmutable('today');
}
$debutSemaine = $dateSemaine->modify('monday this week');
$finSemaine = $debutSemaine->modify('+6 days');
$aujourdhui = new DateTimeImmutable('today');
$dateMin = $debutSemaine->format('Y-m-d');
$dateMax = $finSemaine->format('Y-m-d');

$csrfKey = 'csrf_indisponibilites_technicien';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}
$cleFlash = 'flash_indisponibilites_technicien';
$message = is_string($_SESSION[$cleFlash] ?? null) ? $_SESSION[$cleFlash] : '';
unset($_SESSION[$cleFlash]);
$erreur = '';
$modeleIndisponibilites = new IndisponibiliteTechnicien();

$libellesJours = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
$libellesMois = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

$cleAujourdhui = $aujourdhui->format('Y-m-d');
$heureActuelle = (int) date('G');
$estPasse = static fn(string $date, int $heure): bool =>
    $date < $cleAujourdhui || ($date === $cleAujourdhui && $heure < $heureActuelle);
$accord = static fn(int $n, string $singulier, string $pluriel): string => $n . ' ' . ($n > 1 ? $pluriel : $singulier);
$estAjax = strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';

function repondreJson(array $donnees, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : 'creneau';
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $datePostee = is_string($_POST['date'] ?? null) ? $_POST['date'] : '';
    $dateValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $datePostee);
    $codeHttp = 422;
    $creneauxModifies = [];
    $messageSucces = '';

    try {
        if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
            $codeHttp = 403;
            throw new DomainException('La session du formulaire a expiré. Rechargez la page puis réessayez.');
        }
        if (!$dateValidee || $dateValidee->format('Y-m-d') !== $datePostee
            || $datePostee < $dateMin || $datePostee > $dateMax) {
            throw new DomainException('La date sélectionnée ne fait pas partie de cette semaine.');
        }

        if ($action === 'jour') {
            // ---------- Toute une journée ----------
            $indispos = [];
            foreach ($modeleIndisponibilites->getParPeriode($technicienId, $datePostee, $datePostee) as $c) {
                $indispos[(int) $c['heure_debut']] = true;
            }
            $missionsJour = [];
            foreach ($modeleIndisponibilites->getMissionsPlanifieesParPeriode($technicienId, $datePostee, $datePostee) as $m) {
                $missionsJour[(int) $m['heure_creneau_planifie']] = true;
            }

            $modifiables = [];
            $avecMission = 0;
            for ($h = $heureDebut; $h < $heureFin; $h++) {
                if ($estPasse($datePostee, $h)) { continue; }
                if (isset($missionsJour[$h])) { $avecMission++; continue; }
                $modifiables[] = $h;
            }
            if (!$modifiables) {
                throw new DomainException('Aucun créneau de cette journée ne peut être modifié.');
            }

            // Un créneau libre existe : on bloque tout ce qui est libre. Sinon, on libère tout.
            $aBloquer = array_values(array_filter($modifiables, static fn(int $h): bool => !isset($indispos[$h])));
            $bloquer = count($aBloquer) > 0;
            $cibles = $bloquer ? $aBloquer : $modifiables;

            $echecs = 0;
            foreach ($cibles as $h) {
                try {
                    if ($modeleIndisponibilites->definir($technicienId, $datePostee, $h, $bloquer)) {
                        $creneauxModifies[] = ['date' => $datePostee, 'heure' => $h, 'bloque' => $bloquer];
                    } else {
                        $echecs++;
                    }
                } catch (DomainException $e) {
                    $avecMission++;            // créneau devenu réservé entre-temps
                } catch (PDOException $e) {
                    error_log('Journée indisponibilité technicien ' . $technicienId . ' : ' . $e->getMessage());
                    $echecs++;
                }
            }
            if (!$creneauxModifies) {
                throw new DomainException('Aucun créneau n’a pu être modifié.');
            }

            $libelleJour = $libellesJours[(int) $dateValidee->format('w')] . ' ' . $dateValidee->format('j') . ' ' . $libellesMois[(int) $dateValidee->format('n')];
            $n = count($creneauxModifies);
            $messageSucces = 'Journée du ' . $libelleJour . ' : ' . ($bloquer
                ? $accord($n, 'créneau marqué indisponible', 'créneaux marqués indisponibles')
                : $accord($n, 'créneau de nouveau disponible', 'créneaux de nouveau disponibles')) . '.';
            if ($avecMission > 0) {
                $messageSucces .= ' ' . $accord($avecMission, 'créneau avec mission conservé', 'créneaux avec mission conservés') . '.';
            }
            if ($echecs > 0) {
                $messageSucces .= ' ' . $accord($echecs, 'créneau n’a pas pu être modifié', 'créneaux n’ont pas pu être modifiés') . '.';
            }

        } elseif ($action === 'creneau') {
            // ---------- Un seul créneau ----------
            $heureBrute = $_POST['heure'] ?? null;
            $heurePostee = is_string($heureBrute) ? filter_var($heureBrute, FILTER_VALIDATE_INT) : false;
            $indisponibleBrute = is_string($_POST['indisponible'] ?? null) ? $_POST['indisponible'] : '';
            $indisponible = $indisponibleBrute === '1';

            if ($heurePostee === false || $heurePostee < $heureDebut || $heurePostee >= $heureFin) {
                throw new DomainException('Le créneau horaire sélectionné n’est pas valide.');
            }
            if (!in_array($indisponibleBrute, ['0', '1'], true)) {
                throw new DomainException('L’action demandée pour ce créneau n’est pas valide.');
            }
            if ($estPasse($datePostee, $heurePostee)) {
                throw new DomainException('Un créneau passé ne peut pas être modifié.');
            }
            if (!$modeleIndisponibilites->definir($technicienId, $datePostee, $heurePostee, $indisponible)) {
                throw new DomainException('Le créneau n’a pas pu être mis à jour.');
            }
            $creneauxModifies[] = ['date' => $datePostee, 'heure' => $heurePostee, 'bloque' => $indisponible];
            $messageSucces = $indisponible
                ? 'Le créneau a été marqué comme indisponible.'
                : 'Le créneau est de nouveau disponible.';

        } else {
            $codeHttp = 400;
            throw new DomainException('Action inconnue.');
        }

        if ($estAjax) {
            repondreJson(['ok' => true, 'message' => $messageSucces, 'creneaux' => $creneauxModifies]);
        }
        $_SESSION[$cleFlash] = $messageSucces;
        header('Location: indisponibilites.php?semaine=' . rawurlencode($dateMin));
        exit;

    } catch (DomainException $exception) {
        $erreur = $exception->getMessage();
    } catch (PDOException $exception) {
        error_log('Mise à jour indisponibilité technicien ' . $technicienId . ' : ' . $exception->getMessage());
        $erreur = 'Une erreur est survenue lors de l’enregistrement du créneau.';
        $codeHttp = 500;
    }

    if ($estAjax) {
        repondreJson(['ok' => false, 'erreur' => $erreur], $codeHttp);
    }
    if ($codeHttp === 403) { http_response_code(403); }
}

$indisponibilites = [];
foreach ($modeleIndisponibilites->getParPeriode($technicienId, $dateMin, $dateMax) as $creneau) {
    $indisponibilites[$creneau['date_indisponibilite']][(int) $creneau['heure_debut']] = true;
}
$missionsPlanifiees = [];
foreach ($modeleIndisponibilites->getMissionsPlanifieesParPeriode($technicienId, $dateMin, $dateMax) as $missionPlanifiee) {
    $missionsPlanifiees[$missionPlanifiee['date_creneau_planifie']][(int) $missionPlanifiee['heure_creneau_planifie']] = $missionPlanifiee;
}
$jours = [];
$libellesJours = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
$libellesMois = [1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
for ($jour = 0; $jour < 7; $jour++) {
    $date = $debutSemaine->modify('+' . $jour . ' days');
    $cle = $date->format('Y-m-d');

    // Créneaux que le technicien peut encore modifier ce jour-là (ni passés, ni réservés par une mission)
    $nbModifiables = 0;
    $nbBloques = 0;
    for ($h = $heureDebut; $h < $heureFin; $h++) {
        if ($estPasse($cle, $h) || isset($missionsPlanifiees[$cle][$h])) { continue; }
        $nbModifiables++;
        if (isset($indisponibilites[$cle][$h])) { $nbBloques++; }
    }

    $jours[] = [
        'date' => $date,
        'cle' => $cle,
        'libelle' => ucfirst($libellesJours[(int) $date->format('w')]) . ' ' . $date->format('j') . ' ' . $libellesMois[(int) $date->format('n')],
        'modifiables' => $nbModifiables,
        'tout_bloque' => $nbModifiables > 0 && $nbBloques === $nbModifiables,
    ];
}
$semainePrecedente = $debutSemaine->modify('-7 days')->format('Y-m-d');
$semaineSuivante = $debutSemaine->modify('+7 days')->format('Y-m-d');
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$heureFinLibelle = $heureFin === 24 ? '00' : sprintf('%02d', $heureFin);

// Missions non terminées du technicien (alerte en haut de page)
$missionsNonTerminees = [];
try {
    $missionsNonTerminees = $modeleIndisponibilites->getMissionsNonTerminees($technicienId);
} catch (PDOException $exception) {
    error_log('Missions non terminées technicien ' . $technicienId . ' : ' . $exception->getMessage());
}
$nbMissionsNonTerminees = count($missionsNonTerminees);
$libellesStatutMission = [
    'en_attente' => 'À confirmer', 'acceptee' => 'Acceptée', 'attribuee' => 'Attribuée',
    'en_route' => 'En route', 'arrive' => 'Arrivé', 'diagnostic' => 'Diagnostic', 'en_cours' => 'En cours',
];

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mes disponibilités — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/technicien-indisponibilites.css?v=<?= filemtime(__DIR__ . '/../../public/css/technicien-indisponibilites.css') ?>">
</head>
<body class="page-technicien-indisponibilites">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>

    <main class="contenu technicien-indisponibilites">
        <div id="indisponibilites-notifs" class="indisponibilites-notifs" aria-live="polite"></div>
        <header class="indisponibilites-entete">
            <div>
                <span class="indisponibilites-entete__sur-titre">Organisation du travail</span>
                <h1>Mes disponibilités</h1>
                <p>Bloquez les heures où vous ne pouvez pas prendre de mission. Cliquez sur un créneau pour le marquer indisponible ou le libérer.</p>
            </div>
            <nav class="indisponibilites-navigation" aria-label="Navigation du calendrier">
                <a href="indisponibilites.php?semaine=<?= $echapper($semainePrecedente) ?>" aria-label="Semaine précédente"><?= icone('arrow', 17) ?></a>
                <strong><?= $echapper($debutSemaine->format('d/m')) ?> – <?= $echapper($finSemaine->format('d/m/Y')) ?></strong>
                <a href="indisponibilites.php?semaine=<?= $echapper($semaineSuivante) ?>" aria-label="Semaine suivante"><?= icone('arrow', 17) ?></a>
                <?php if ($dateMin !== $aujourdhui->modify('monday this week')->format('Y-m-d')): ?>
                    <a class="indisponibilites-navigation__aujourdhui" href="indisponibilites.php">Cette semaine</a>
                <?php endif; ?>
            </nav>
        </header>

        <?php if ($message !== ''): ?><div class="indisponibilites-message" role="status"><?= $echapper($message) ?></div><?php endif; ?>
        <?php if ($erreur !== ''): ?><div class="indisponibilites-message indisponibilites-message--erreur" role="alert"><?= $echapper($erreur) ?></div><?php endif; ?>
        <?php if ($nbMissionsNonTerminees > 0): ?>
            <?php
            $enRetardTotal = 0;
            foreach ($missionsNonTerminees as $m) {
                if (!empty($m['date_creneau_planifie'])
                    && ($m['date_creneau_planifie'] < $aujourdhui->format('Y-m-d')
                        || ($m['date_creneau_planifie'] === $aujourdhui->format('Y-m-d') && (int) $m['heure_creneau_planifie'] < (int) date('G')))) {
                    $enRetardTotal++;
                }
            }
            ?>
            <section class="indisponibilites-alerte <?= $enRetardTotal > 0 ? 'indisponibilites-alerte--retard' : '' ?>" role="status" aria-label="Missions non terminées">
                <div class="indisponibilites-alerte__icone" aria-hidden="true">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
                </div>
                <div class="indisponibilites-alerte__corps">
                    <strong>
                        Vous avez <?= $nbMissionsNonTerminees ?> mission<?= $nbMissionsNonTerminees > 1 ? 's' : '' ?> non terminée<?= $nbMissionsNonTerminees > 1 ? 's' : '' ?>
                    </strong>
                    <?php if ($enRetardTotal > 0): ?>
                        <span class="indisponibilites-alerte__sous-titre"><?= $enRetardTotal ?> dont le créneau est déjà passé : pensez à les clôturer.</span>
                    <?php endif; ?>

                    <ul class="indisponibilites-alerte__liste">
                        <?php foreach (array_slice($missionsNonTerminees, 0, 3) as $m): ?>
                            <?php
                            $creneau = '';
                            $retard = false;
                            if (!empty($m['date_creneau_planifie'])) {
                                $d = DateTimeImmutable::createFromFormat('!Y-m-d', $m['date_creneau_planifie']);
                                if ($d) {
                                    $creneau = $d->format('d/m') . ' à ' . sprintf('%02d:00', (int) $m['heure_creneau_planifie']);
                                    $retard = $m['date_creneau_planifie'] < $aujourdhui->format('Y-m-d')
                                        || ($m['date_creneau_planifie'] === $aujourdhui->format('Y-m-d') && (int) $m['heure_creneau_planifie'] < (int) date('G'));
                                }
                            }
                            $statutLibelle = $libellesStatutMission[$m['statut_mission'] ?? ''] ?? ($libellesStatutMission[$m['statut_demande']] ?? '');
                            ?>
                            <li>
                                <a href="mission.php?id=<?= (int) $m['intervention_id'] ?>">
                                    <span class="indisponibilites-alerte__dossier"><?= $echapper($m['numero_dossier']) ?></span>
                                    <?php if ($creneau !== ''): ?><span class="indisponibilites-alerte__creneau"><?= $echapper($creneau) ?></span><?php endif; ?>
                                    <?php if ($statutLibelle !== ''): ?><span class="indisponibilites-alerte__statut"><?= $echapper($statutLibelle) ?></span><?php endif; ?>
                                    <?php if ($retard): ?><span class="indisponibilites-alerte__retard">En retard</span><?php endif; ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ($nbMissionsNonTerminees > 3): ?>
                        <span class="indisponibilites-alerte__reste">+ <?= $nbMissionsNonTerminees - 3 ?> autre<?= $nbMissionsNonTerminees - 3 > 1 ? 's' : '' ?></span>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>
        <section class="indisponibilites-legende" aria-label="Légende du calendrier">
            <span><i class="indisponibilites-legende__disponible"></i>Disponible</span>
            <span><i class="indisponibilites-legende__bloque"></i>Indisponible</span>
            <span><i class="indisponibilites-legende__reserve"></i>Mission planifiée</span>
            <small>Horaires définis par Allô Pro : <?= sprintf('%02d:00', $heureDebut) ?> – <?= $heureFinLibelle ?>:00</small>
        </section>

        <div class="indisponibilites-calendrier-defilement" role="region" aria-label="Calendrier hebdomadaire des disponibilités" tabindex="0">
            <table class="indisponibilites-calendrier">
                <thead>
                    <tr>
                        <th scope="col">Heure</th>
                        <?php foreach ($jours as $jour): ?>
                            <?php $estAujourdhui = $jour['cle'] === $aujourdhui->format('Y-m-d'); ?>
                            <th scope="col" data-jour="<?= $echapper($jour['cle']) ?>" class="<?= $estAujourdhui ? 'indisponibilites-calendrier__aujourdhui' : '' ?>">
                                <?php if ($jour['modifiables'] > 0): ?>
                                    <form method="POST" class="indisponibilites-jour-form">
                                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfKey]) ?>">
                                        <input type="hidden" name="date" value="<?= $echapper($jour['cle']) ?>">
                                        <input type="hidden" name="action" value="jour">
                                        <button type="submit" class="indisponibilites-jour" data-tout-bloque="<?= $jour['tout_bloque'] ? '1' : '0' ?>"
                                                aria-label="Bloquer ou libérer toute la journée du <?= $echapper($jour['libelle']) ?>">
                                            <span class="indisponibilites-jour__libelle"><?= $echapper($jour['libelle']) ?></span>
                                            <?php if ($estAujourdhui): ?><small>Aujourd’hui</small><?php endif; ?>
                                            <span class="indisponibilites-jour__action" data-action-libelle><?= $jour['tout_bloque'] ? 'Libérer la journée' : 'Bloquer la journée' ?></span>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <?= $echapper($jour['libelle']) ?>
                                    <?php if ($estAujourdhui): ?><small>Aujourd’hui</small><?php endif; ?>
                                <?php endif; ?>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php for ($heure = $heureDebut; $heure < $heureFin; $heure++): ?>
                        <?php $heureSuivante = $heure === 23 ? '00' : sprintf('%02d', $heure + 1); ?>
                        <tr>
                            <th scope="row"><?= sprintf('%02d:00', $heure) ?><small><?= $heureSuivante ?>:00</small></th>
                            <?php foreach ($jours as $jour): ?>
                                <?php
                                $bloque = isset($indisponibilites[$jour['cle']][$heure]);
                                $missionPlanifiee = $missionsPlanifiees[$jour['cle']][$heure] ?? null;
                                $creneauPasse = $jour['cle'] < $aujourdhui->format('Y-m-d')
                                    || ($jour['cle'] === $aujourdhui->format('Y-m-d') && $heure < (int) date('G'));
                                ?>
                                <<td data-date="<?= $echapper($jour['cle']) ?>" data-heure="<?= $heure ?>"
                                data-libelle="<?= $echapper($jour['libelle']) ?>"
                                data-plage="<?= sprintf('%02d:00', $heure) ?> à <?= $heureSuivante ?>:00">
                                    <?php if ($missionPlanifiee): ?>
                                        <span class="indisponibilites-creneau indisponibilites-creneau--reserve"
                                            aria-label="Mission planifiée <?= $echapper($missionPlanifiee['numero_dossier']) ?> le <?= $echapper($jour['libelle']) ?> de <?= sprintf('%02d:00', $heure) ?> à <?= $heureSuivante ?>:00">
                                            <a href="mission.php?id=<?= (int) $missionPlanifiee['intervention_id'] ?>">
                                                Mission · <?= $echapper($missionPlanifiee['numero_dossier']) ?>
                                            </a>
                                            <?php if (!empty($missionPlanifiee['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($missionPlanifiee['entreprise_b2b_nom']) ? ' · ' . $echapper($missionPlanifiee['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                                        </span>
                                    <?php elseif ($creneauPasse): ?>
                                        <span class="indisponibilites-creneau indisponibilites-creneau--passe" aria-label="Créneau passé"><?= $bloque ? 'Indisponible' : '—' ?></span>
                                    <?php else: ?>
                                        <form method="POST">
                                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfKey]) ?>">
                                            <input type="hidden" name="date" value="<?= $echapper($jour['cle']) ?>">
                                            <input type="hidden" name="heure" value="<?= $heure ?>">
                                            <button class="indisponibilites-creneau <?= $bloque ? 'indisponibilites-creneau--bloque' : 'indisponibilites-creneau--disponible' ?>"
                                                type="submit" name="indisponible" value="<?= $bloque ? '0' : '1' ?>"
                                                aria-label="<?= $bloque ? 'Rendre disponible' : 'Marquer indisponible' ?> le <?= $echapper($jour['libelle']) ?> de <?= sprintf('%02d:00', $heure) ?> à <?= $heureSuivante ?>:00">
                                                <?= $bloque ? 'Indisponible' : 'Disponible' ?>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
        <p class="indisponibilites-note">Les missions planifiées apparaissent comme réservées et ne peuvent pas être bloquées. Les créneaux bloqués restent exclus des propositions d’affectation.</p>
    </main>
</div>

<script>
(function () {
    'use strict';
    var tableau = document.querySelector('.indisponibilites-calendrier');
    var zone = document.getElementById('indisponibilites-notifs');
    if (!tableau || !zone || !window.fetch) return;   // sans JS, les formulaires fonctionnent normalement

    var timerNotif = null;

    function notifier(texte, erreur) {
        // Retire les messages affichés par le serveur au chargement de la page
        document.querySelectorAll('.indisponibilites-message').forEach(function (e) {
            if (!zone.contains(e)) e.remove();
        });
        zone.textContent = '';
        var d = document.createElement('div');
        d.className = 'indisponibilites-message' + (erreur ? ' indisponibilites-message--erreur' : '');
        d.setAttribute('role', erreur ? 'alert' : 'status');
        d.textContent = texte;
        zone.appendChild(d);
        clearTimeout(timerNotif);
        timerNotif = setTimeout(function () { d.remove(); }, erreur ? 7000 : 4000);
    }

    function cellule(date, heure) {
        return tableau.querySelector('td[data-date="' + date + '"][data-heure="' + heure + '"]');
    }

    function majCreneau(date, heure, bloque) {
        var td = cellule(date, heure);
        var b = td && td.querySelector('button.indisponibilites-creneau');
        if (!b) return;
        b.classList.toggle('indisponibilites-creneau--bloque', bloque);
        b.classList.toggle('indisponibilites-creneau--disponible', !bloque);
        b.value = bloque ? '0' : '1';
        b.textContent = bloque ? 'Indisponible' : 'Disponible';
        b.setAttribute('aria-label', (bloque ? 'Rendre disponible' : 'Marquer indisponible') + ' le ' + td.dataset.libelle + ' de ' + td.dataset.plage);
    }

    // Le libellé du jour dépend de l'état réel des créneaux de la colonne
    function majJour(date) {
        var btn = tableau.querySelector('th[data-jour="' + date + '"] .indisponibilites-jour');
        if (!btn) return;
        var boutons = tableau.querySelectorAll('td[data-date="' + date + '"] button.indisponibilites-creneau');
        var tousBloques = boutons.length > 0 && Array.prototype.every.call(boutons, function (b) {
            return b.classList.contains('indisponibilites-creneau--bloque');
        });
        btn.dataset.toutBloque = tousBloques ? '1' : '0';
        btn.querySelector('[data-action-libelle]').textContent = tousBloques ? 'Libérer la journée' : 'Bloquer la journée';
    }

    tableau.addEventListener('submit', async function (e) {
        var form = e.target.closest('form');
        if (!form) return;
        e.preventDefault();

        var bouton = e.submitter || form.querySelector('button[type="submit"]');
        if (!bouton || bouton.disabled) return;

        var donnees = new URLSearchParams(new FormData(form));
        if (bouton.name) donnees.set(bouton.name, bouton.value);

        var avaitLeFocus = document.activeElement === bouton;
        bouton.disabled = true;
        bouton.classList.add('is-attente');

        try {
            var res = await fetch(window.location.href, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: donnees.toString()
            });
            var json = await res.json().catch(function () { return null; });
            if (!json) throw new Error('Réponse invalide');

            if (json.ok) {
                var dates = {};
                (json.creneaux || []).forEach(function (c) {
                    majCreneau(c.date, c.heure, c.bloque);
                    dates[c.date] = true;
                });
                Object.keys(dates).forEach(majJour);
                notifier(json.message || 'Enregistré.', false);
            } else {
                notifier(json.erreur || 'Une erreur est survenue.', true);
            }
        } catch (err) {
            notifier('Connexion impossible, réessayez.', true);
        } finally {
            bouton.disabled = false;
            bouton.classList.remove('is-attente');
            if (avaitLeFocus) bouton.focus();
        }
    });
})();
</script>
</body>
</html>
