<?php
require_once __DIR__ . '/../../includes/auth-technicien.php';
verifierTechnicienConnecte();
require_once __DIR__ . '/../../models/Intervention.php';
require_once __DIR__ . '/../../models/ClotureIntervention.php';

$technicienId = (int) $_SESSION['technicien_id'];
$missionId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if ($missionId === false || $missionId === null || $missionId < 1) {
    header('Location: missions.php');
    exit;
}

$interventionModel = new Intervention();
$mission = $interventionModel->getByIdEtTechnicien($missionId, $technicienId);
if (!$mission) {
    http_response_code(404);
    header('Location: missions.php');
    exit;
} elseif ($mission['statut'] !== 'en_attente') {
    $interventionModel->initialiserChecklist($missionId);
}
$checklist = $mission && $mission['statut'] !== 'en_attente' ? $interventionModel->getChecklist($missionId, $technicienId) : [];
$documents = $mission && $mission['statut'] !== 'en_attente' ? $interventionModel->getDocumentsTechnicien($technicienId, $missionId) : [];

$csrfSession = 'csrf_technicien_mission';
if (empty($_SESSION[$csrfSession])) {
    $_SESSION[$csrfSession] = bin2hex(random_bytes(32));
}
$cleFlashMission = 'flash_technicien_mission_' . $missionId;
$messageSucces = is_string($_SESSION[$cleFlashMission] ?? null) ? $_SESSION[$cleFlashMission] : '';
unset($_SESSION[$cleFlashMission]);
$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mission) {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION[$csrfSession], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } else {
        $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
        $urlMission = 'mission.php?id=' . $missionId;

        if (in_array($action, ['accepter', 'refuser'], true)) {
            $accepter = $action === 'accepter';
            $motif = is_string($_POST['motif'] ?? null) ? trim($_POST['motif']) : '';
            if ($mission['statut'] !== 'en_attente') {
                $erreur = 'Cette proposition a déjà reçu une réponse.';
            } elseif (mb_strlen($motif, 'UTF-8') > 2000) {
                $erreur = 'Le motif de refus ne peut pas dépasser 2 000 caractères.';
            } else {
                try {
                    if ($interventionModel->repondreAProposition(
                        $missionId,
                        $technicienId,
                        $accepter,
                        $motif === '' ? null : $motif
                    )) {
                        journaliser(
                            $accepter ? 'mission.acceptee_technicien' : 'mission.refusee_technicien',
                            'demande',
                            $mission['demande_id'],
                            $mission['numero_dossier'],
                            $accepter ? 'Proposition acceptée par le technicien.' : 'Proposition refusée par le technicien.'
                                . ($motif !== '' ? ' Motif : ' . $motif : '')
                        );
                        if ($accepter) {
                            $_SESSION[$cleFlashMission] = 'La mission a été acceptée.';
                            header('Location: ' . $urlMission);
                        } else {
                            $_SESSION['flash_technicien_missions'] = 'La mission a été refusée et transmise au coordinateur.';
                            header('Location: missions.php');
                        }
                        exit;
                    }
                    $erreur = 'La proposition a déjà été traitée ou n’est plus disponible.';
                } catch (PDOException $exception) {
                    error_log('Décision technicien mission ' . $missionId . ' : ' . $exception->getMessage());
                    $erreur = 'Une erreur est survenue lors de l’enregistrement de votre décision.';
                }
            }
        } elseif ($mission['statut'] === 'en_attente') {
            $erreur = 'Acceptez la proposition avant d’effectuer des actions sur cette intervention.';
        } elseif ($action === 'statut') {
            $nouveauStatut = is_string($_POST['nouveau_statut'] ?? null) ? $_POST['nouveau_statut'] : '';
            $statutsAutorises = ['en_route', 'arrive', 'diagnostic', 'en_cours'];
            if (!in_array($nouveauStatut, $statutsAutorises, true) || $mission['statut'] === 'terminee') {
                $erreur = 'Le statut demandé n’est pas valide pour cette intervention.';
            } else {
                try {
                    if ($interventionModel->mettreAJourStatutParId($missionId, $nouveauStatut)) {
                        journaliser(
                            'mission.statut_modifie',
                            'demande',
                            $mission['demande_id'],
                            $mission['numero_dossier'],
                            '→ ' . $nouveauStatut
                        );
                        $_SESSION[$cleFlashMission] = 'Le statut de l’intervention a été mis à jour.';
                        header('Location: ' . $urlMission);
                        exit;
                    }
                    $erreur = 'Le statut n’a pas pu être mis à jour. Réessayez.';
                } catch (PDOException $exception) {
                    error_log('Mise à jour du statut de mission ' . $missionId . ' : ' . $exception->getMessage());
                    $erreur = 'Une erreur est survenue lors de la mise à jour du statut.';
                }
            }
        } elseif ($action === 'cloturer') {
            require_once __DIR__ . '/../../models/Demande.php';
            $demandeInfo = null;
            $resultatCloture = null;
            try {
                $demandeInfo = (new Demande())->getById($mission['demande_id']);
                if ($demandeInfo) {
                    $rapport = is_string($_POST['rapport'] ?? null) ? $_POST['rapport'] : '';
                    $montant = is_string($_POST['montant'] ?? null) ? $_POST['montant'] : '';
                    $resultatCloture = (new ClotureIntervention())->cloturer(
                        $mission['demande_id'],
                        $rapport,
                        $montant
                    );
                }
            } catch (PDOException $exception) {
                error_log('Clôture de mission ' . $missionId . ' : ' . $exception->getMessage());
                $erreur = 'Une erreur est survenue lors de la clôture de l’intervention.';
            }
            if ($erreur === '' && !$demandeInfo) {
                $erreur = 'Les informations de la demande sont indisponibles. La clôture n’a pas été effectuée.';
            } elseif ($erreur === '' && $resultatCloture && !$resultatCloture['ok']) {
                $erreur = $resultatCloture['erreur'];
            } elseif ($erreur === '' && $resultatCloture && $resultatCloture['ok']) {
                $couverture = $resultatCloture['couverture'];
                $montantFinal = $resultatCloture['montant'];
                journaliser(
                    'mission.cloturee',
                    'demande',
                    $mission['demande_id'],
                    $mission['numero_dossier'],
                    $couverture
                        ? 'Couvert par ' . $couverture['type']
                        : 'Montant : ' . number_format($montantFinal, 0, ',', ' ') . ' F'
                );

                require_once __DIR__ . '/../../models/Notification.php';
                if (($couverture['type'] ?? null) === 'abonnement') {
                    $message = "Votre intervention {$mission['numero_dossier']} est terminée. Elle est couverte par votre abonnement — aucun paiement requis.";
                    $lien = '/allopro/views/client/detail-demande.php?id=' . (int) $mission['demande_id'];
                } elseif (($couverture['type'] ?? null) === 'pass') {
                    $message = "Votre intervention {$mission['numero_dossier']} est terminée. Elle est couverte par votre Pass — aucun paiement requis.";
                    $lien = '/allopro/views/client/detail-demande.php?id=' . (int) $mission['demande_id'];
                } elseif (($couverture['type'] ?? null) === 'contrat_b2b') {
                    $message = "Votre intervention {$mission['numero_dossier']} est terminée. Elle est couverte par le contrat de votre entreprise — un crédit a été consommé.";
                    $lien = '/allopro/views/entreprise/detail-demande.php?entreprise_id=' . (int) $mission['entreprise_b2b_id'] . '&id=' . (int) $mission['demande_id'];
                } else {
                    $montantFormate = number_format($montantFinal, 0, ',', ' ');
                    $message = "Votre intervention {$mission['numero_dossier']} est terminée. Montant à payer : {$montantFormate} FCFA.";
                    $lien = '/allopro/views/client/payer.php?id=' . (int) $mission['demande_id'];
                }
                (new Notification())->create($demandeInfo['client_id'], $message, $lien);

                require_once __DIR__ . '/../../models/User.php';
                $userModel = new User();
                if (!$userModel->aDemandesActives($demandeInfo['client_id'])) {
                    $userModel->fermerConversation($demandeInfo['client_id']);
                }

                $_SESSION[$cleFlashMission] = 'L’intervention a été clôturée avec succès.';
                header('Location: ' . $urlMission);
                exit;
            }
        } elseif ($action === 'photo') {
            $fichier = $_FILES['photo'] ?? null;
            $typePhoto = is_string($_POST['type_photo'] ?? null) ? $_POST['type_photo'] : '';
            if (!in_array($typePhoto, ['avant', 'apres'], true)) {
                $erreur = 'Le type de photo sélectionné est invalide.';
            } elseif (!is_array($fichier) || !isset($fichier['error']) || $fichier['error'] !== UPLOAD_ERR_OK) {
                $codeErreurUpload = is_array($fichier) ? (int) ($fichier['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
                $erreur = match ($codeErreurUpload) {
                    UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'La photo dépasse la taille maximale autorisée.',
                    UPLOAD_ERR_NO_FILE => 'Sélectionnez une photo avant de continuer.',
                    default => 'La photo n’a pas pu être reçue. Réessayez.',
                };
            } elseif ((int) ($fichier['size'] ?? 0) > 8 * 1024 * 1024) {
                $erreur = 'La photo ne doit pas dépasser 8 Mo.';
            } elseif (!is_uploaded_file((string) ($fichier['tmp_name'] ?? ''))) {
                $erreur = 'Le fichier transmis n’est pas un téléversement valide.';
            } else {
                $image = @getimagesize($fichier['tmp_name']);
                $typesImage = [
                    IMAGETYPE_JPEG => ['extension' => 'jpg', 'mime' => 'image/jpeg'],
                    IMAGETYPE_PNG => ['extension' => 'png', 'mime' => 'image/png'],
                ];
                $typeImage = is_array($image) ? ($typesImage[$image[2] ?? 0] ?? null) : null;
                $mimeDetecte = (new finfo(FILEINFO_MIME_TYPE))->file($fichier['tmp_name']);

                if (!$typeImage || $mimeDetecte !== $typeImage['mime']) {
                    $erreur = 'Format de photo invalide. Utilisez une image JPG ou PNG.';
                } elseif ((int) ($image[0] ?? 0) < 1 || (int) ($image[1] ?? 0) < 1
                    || (int) $image[0] * (int) $image[1] > 40000000) {
                    $erreur = 'Les dimensions de cette image ne sont pas prises en charge.';
                } else {
                    $dossierDestination = __DIR__ . '/../../public/uploads/';
                    if (!is_dir($dossierDestination) && !mkdir($dossierDestination, 0755, true) && !is_dir($dossierDestination)) {
                        error_log('Création du dossier des photos d’intervention impossible.');
                        $erreur = 'Le stockage des photos est indisponible pour le moment.';
                    } else {
                        $nomFichier = 'intervention_' . bin2hex(random_bytes(16)) . '.' . $typeImage['extension'];
                        $cheminRelatif = 'uploads/' . $nomFichier;
                        try {
                            if (!move_uploaded_file($fichier['tmp_name'], $dossierDestination . $nomFichier)) {
                                $erreur = 'La photo n’a pas pu être enregistrée. Réessayez.';
                            } elseif (!$interventionModel->ajouterPhoto($missionId, $typePhoto, $cheminRelatif)) {
                                if (is_file($dossierDestination . $nomFichier)) {
                                    unlink($dossierDestination . $nomFichier);
                                }
                                $erreur = 'La photo n’a pas pu être associée à cette intervention.';
                            } else {
                                $_SESSION[$cleFlashMission] = $typePhoto === 'avant'
                                    ? 'La photo avant intervention a été ajoutée.'
                                    : 'La photo après intervention a été ajoutée.';
                                header('Location: ' . $urlMission);
                                exit;
                            }
                        } catch (PDOException $exception) {
                            error_log('Enregistrement photo de mission ' . $missionId . ' : ' . $exception->getMessage());
                            $erreur = 'Une erreur est survenue lors de l’enregistrement de la photo.';
                        }
                    }
                }
            }
        } elseif ($action === 'checklist') {
            $elementId = filter_var($_POST['element_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$elementId || $mission['statut'] === 'terminee') {
                $erreur = 'Cet élément de checklist ne peut pas être modifié.';
            } else {
                try {
                    if ($interventionModel->definirElementChecklist(
                        $elementId,
                        $missionId,
                        $technicienId,
                        isset($_POST['terminee'])
                    )) {
                        $_SESSION[$cleFlashMission] = 'La checklist a été mise à jour.';
                        header('Location: ' . $urlMission . '#mission-checklist');
                        exit;
                    }
                    $erreur = 'La checklist n’a pas pu être mise à jour. Rechargez la page puis réessayez.';
                } catch (PDOException $exception) {
                    error_log('Checklist de mission ' . $missionId . ' : ' . $exception->getMessage());
                    $erreur = 'Une erreur est survenue lors de la mise à jour de la checklist.';
                }
            }
        } elseif ($action === 'document') {
            if ($mission['statut'] === 'terminee') {
                $erreur = 'Les documents ne peuvent plus être ajoutés après la clôture de la mission.';
            } else {
                $fichier = $_FILES['document'] ?? null;
                $codeErreurUpload = is_array($fichier) ? (int) ($fichier['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
                if ($codeErreurUpload !== UPLOAD_ERR_OK) {
                    $erreur = match ($codeErreurUpload) {
                        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Le document dépasse la taille maximale de 10 Mo.',
                        UPLOAD_ERR_NO_FILE => 'Sélectionnez un document avant de continuer.',
                        default => 'Le document n’a pas pu être reçu. Réessayez.',
                    };
                } elseif ((int) ($fichier['size'] ?? 0) > 10 * 1024 * 1024) {
                    $erreur = 'Le document ne doit pas dépasser 10 Mo.';
                } elseif (!is_uploaded_file((string) ($fichier['tmp_name'] ?? ''))) {
                    $erreur = 'Le fichier transmis n’est pas un téléversement valide.';
                } else {
                    $typesAutorises = [
                        'application/pdf' => 'pdf',
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/webp' => 'webp',
                    ];
                    $mimeDetecte = (new finfo(FILEINFO_MIME_TYPE))->file($fichier['tmp_name']);
                    if (!is_string($mimeDetecte) || !isset($typesAutorises[$mimeDetecte])) {
                        $erreur = 'Format non pris en charge. Ajoutez un PDF, une image JPG, PNG ou WebP.';
                    } elseif (str_starts_with($mimeDetecte, 'image/')) {
                        $image = @getimagesize($fichier['tmp_name']);
                        if (!is_array($image) || (int) ($image[0] ?? 0) < 1 || (int) ($image[1] ?? 0) < 1
                            || (int) $image[0] * (int) $image[1] > 40000000) {
                            $erreur = 'Les dimensions de cette image ne sont pas prises en charge.';
                        }
                    }

                    if ($erreur === '') {
                        $dossierStockage = __DIR__ . '/../../storage/intervention-documents/';
                        if (!is_dir($dossierStockage) && !mkdir($dossierStockage, 0755, true) && !is_dir($dossierStockage)) {
                            error_log('Création du dossier des documents d’intervention impossible.');
                            $erreur = 'Le stockage des documents est indisponible pour le moment.';
                        } else {
                            $extension = $typesAutorises[$mimeDetecte];
                            $nomFichier = bin2hex(random_bytes(16)) . '.' . $extension;
                            $cheminDocument = 'intervention-documents/' . $nomFichier;
                            $cheminAbsolu = $dossierStockage . $nomFichier;
                            $nomOriginal = basename(str_replace('\\', '/', (string) ($fichier['name'] ?? 'document')));
                            $nomOriginal = mb_strcut($nomOriginal !== '' ? $nomOriginal : 'document', 0, 255, 'UTF-8');

                            try {
                                if (!move_uploaded_file($fichier['tmp_name'], $cheminAbsolu)) {
                                    $erreur = 'Le document n’a pas pu être enregistré. Réessayez.';
                                } elseif (!$interventionModel->ajouterDocument(
                                    $missionId,
                                    $technicienId,
                                    $nomOriginal,
                                    $cheminDocument,
                                    $mimeDetecte,
                                    (int) $fichier['size']
                                )) {
                                    unlink($cheminAbsolu);
                                    $erreur = 'Le document n’a pas pu être associé à cette intervention.';
                                } else {
                                    $_SESSION[$cleFlashMission] = 'Le document a été ajouté à l’historique de l’intervention.';
                                    header('Location: ' . $urlMission . '#mission-documents');
                                    exit;
                                }
                            } catch (PDOException $exception) {
                                if (is_file($cheminAbsolu)) {
                                    unlink($cheminAbsolu);
                                }
                                error_log('Document de mission ' . $missionId . ' : ' . $exception->getMessage());
                                $erreur = 'Une erreur est survenue lors de l’enregistrement du document.';
                            }
                        }
                    }
                }
            }
        } else {
            $erreur = 'Action inconnue. Rechargez la page puis réessayez.';
        }
    }
}

if (!$mission) {
    http_response_code(404);
}

$couvertureDisponible = null;
if ($mission && empty($mission['contrat_b2b_id'])
    && !in_array($mission['statut'], ['terminee', 'en_attente'], true)) {
    try {
        $couvertureDisponible = (new ClotureIntervention())->getCouvertureDisponible((int) $mission['demande_id']);
    } catch (PDOException $exception) {
        error_log('Vérification de la couverture pour la mission ' . $missionId . ' : ' . $exception->getMessage());
        if ($erreur === '') {
            $erreur = 'La couverture Pass ou abonnement n’a pas pu être vérifiée. Le montant reste affiché par précaution.';
        }
    }
}

$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$statutsMission = [
    'en_attente' => ['libelle' => 'À confirmer', 'etape' => 0],
    'acceptee' => ['libelle' => 'Acceptée', 'etape' => 0],
    'en_route' => ['libelle' => 'En route', 'etape' => 1],
    'arrive' => ['libelle' => 'Arrivé sur place', 'etape' => 2],
    'diagnostic' => ['libelle' => 'Diagnostic', 'etape' => 3],
    'en_cours' => ['libelle' => 'Intervention en cours', 'etape' => 4],
    'terminee' => ['libelle' => 'Terminée', 'etape' => 5],
];
$statutActuel = $statutsMission[$mission['statut']] ?? ['libelle' => ucfirst(str_replace('_', ' ', $mission['statut'])), 'etape' => 0];
$missionTerminee = $mission['statut'] === 'terminee';
$missionEnAttente = $mission['statut'] === 'en_attente';
$checklistTerminee = count(array_filter($checklist, static fn(array $element): bool => (bool) $element['terminee']));
$rapportSaisi = ($_POST['action'] ?? null) === 'cloturer' && is_string($_POST['rapport'] ?? null)
    ? $_POST['rapport']
    : '';
$montantSaisi = ($_POST['action'] ?? null) === 'cloturer' && is_string($_POST['montant'] ?? null)
    ? $_POST['montant']
    : '';
$etapesMission = [
    ['statut' => 'acceptee', 'libelle' => 'Acceptée'],
    ['statut' => 'en_route', 'libelle' => 'En route'],
    ['statut' => 'arrive', 'libelle' => 'Sur place'],
    ['statut' => 'diagnostic', 'libelle' => 'Diagnostic'],
    ['statut' => 'en_cours', 'libelle' => 'Intervention'],
    ['statut' => 'terminee', 'libelle' => 'Terminée'],
];
$csrfAppelWeb = (string) ($_SESSION[$csrfSession] ?? '');
$roleAppelWeb = 'technicien';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $mission ? 'Mission ' . $echapper($mission['numero_dossier']) : 'Mission introuvable' ?> — ALLÔ PRO Technicien</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/technicien-mission.css?v=<?= filemtime(__DIR__ . '/../../public/css/technicien-mission.css') ?>">
    <link rel="stylesheet" href="../../public/css/appels-web.css?v=<?= filemtime(__DIR__ . '/../../public/css/appels-web.css') ?>">
</head>
<body class="page-technicien-mission">
<div class="app">
    <?php include __DIR__ . '/../../includes/sidebar-technicien.php'; ?>

    <main class="contenu technicien-mission-page">
        <a class="mission-retour" href="missions.php"><?= icone('arrow', 16) ?> Retour à mes missions</a>

        <?php if (!$mission): ?>
            <section class="mission-introuvable">
                <span><?= icone('alert', 26) ?></span>
                <h1>Mission introuvable</h1>
                <p>Cette intervention n’existe pas ou ne vous est pas attribuée.</p>
                <a href="missions.php">Revenir à mes missions</a>
            </section>
        <?php else: ?>
            <?php if ($messageSucces !== ''): ?>
                <div class="mission-message mission-message--succes" role="status"><?= $echapper($messageSucces) ?></div>
            <?php endif; ?>
            <?php if ($erreur !== ''): ?>
                <div class="mission-message mission-message--erreur" role="alert"><?= $echapper($erreur) ?></div>
            <?php endif; ?>

            <header class="mission-hero">
                <div class="mission-hero__contenu">
                    <span class="mission-hero__surtitre"><?= $echapper($mission['categorie_nom']) ?> · <?= $mission['urgence'] === 'urgente' ? 'Priorité urgente' : 'Intervention' ?></span>
                    <h1><?= $echapper($mission['numero_dossier']) ?></h1>
                    <?php if (!empty($mission['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($mission['entreprise_b2b_nom']) ? ' · ' . $echapper($mission['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                    <p><?= $echapper($mission['quartier']) ?>, <?= $echapper($mission['ville']) ?></p>
                    <?php if (!empty($mission['est_demande_entreprise'])): ?><p class="mission-hero__surtitre">Site <?= $echapper($mission['site_b2b_nom']) ?><?php if (!empty($mission['contrat_b2b_id'])): ?> · Contrat #<?= (int) $mission['contrat_b2b_id'] ?><?php endif; ?></p><?php endif; ?>
                </div>
                <span class="mission-statut mission-statut--<?= $echapper($mission['statut']) ?>">
                    <i aria-hidden="true"></i><?= $echapper($statutActuel['libelle']) ?>
                </span>
            </header>

            <?php if (!$missionEnAttente): ?>
            <section class="mission-progression" aria-label="Progression de l’intervention">
                <?php foreach ($etapesMission as $index => $etape): ?>
                    <?php
                    $etapeActive = $index < $statutActuel['etape'];
                    $etapeCourante = $index === $statutActuel['etape'];
                    ?>
                    <div class="mission-progression__etape <?= $etapeActive ? 'mission-progression__etape--faite' : '' ?> <?= $etapeCourante ? 'mission-progression__etape--courante' : '' ?>">
                        <span><?= $etapeActive ? icone('check', 13) : (string) ($index + 1) ?></span>
                        <small><?= $echapper($etape['libelle']) ?></small>
                    </div>
                <?php endforeach; ?>
            </section>
            <?php endif; ?>

            <?php include __DIR__ . '/../../includes/rappels-technicien.php'; ?>

            <div class="mission-colonnes">
                <div class="mission-colonne mission-colonne--infos">
                    <section class="mission-carte mission-details" aria-labelledby="mission-details-titre">
                        <header class="mission-carte__entete">
                            <span><?= icone('file-text', 18) ?></span>
                            <div><h2 id="mission-details-titre">Détails de l’intervention</h2><p>Informations utiles pour votre déplacement</p></div>
                        </header>
                        <div class="mission-details__corps">
                            <?php if (empty($mission['est_demande_entreprise']) && !$missionTerminee && !$missionEnAttente): ?>
                                <div class="mission-details__appel">
                                    <button type="button" class="mission-bouton mission-bouton--appel-web"
                                            data-webcall-start
                                            data-client-id="<?= (int) $mission['client_id'] ?>"
                                            data-intervention-id="<?= (int) $missionId ?>"
                                            data-csrf="<?= $echapper($csrfAppelWeb) ?>"
                                            data-nom="le client"
                                            hidden>
                                        <?= icone('phone', 16) ?> Appeler le client par le web
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="mission-info">
                                <span class="mission-info__icone"><?= icone('pin', 17) ?></span>
                                <div><span class="mission-info__label">Adresse</span><strong><?= $echapper($mission['quartier']) ?>, <?= $echapper($mission['ville']) ?></strong>
                                    <?php if (!$missionTerminee && !empty($mission['adresse_google'])): ?><p><?= $echapper($mission['adresse_google']) ?></p><?php endif; ?>
                                    <?php if (!empty($mission['adresse_details'])): ?><p><?= nl2br($echapper($mission['adresse_details'])) ?></p><?php endif; ?>
                                    <?php if (!$missionTerminee && $mission['adresse_latitude'] !== null && $mission['adresse_longitude'] !== null): ?>
                                        <a href="https://www.google.com/maps/dir/?api=1&amp;destination=<?= rawurlencode((string) $mission['adresse_latitude'] . ',' . (string) $mission['adresse_longitude']) ?>&amp;travelmode=driving" target="_blank" rel="noopener noreferrer">Ouvrir l’itinéraire dans Google Maps</a>
                                    <?php endif; ?>
                                    <?php if (!$missionTerminee): ?>
                                        <a class="mission-adresse__carte" href="carte.php?id=<?= $missionId ?>"><?= icone('pin', 15) ?> Afficher dans la carte</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if (!empty($mission['contrat_b2b_id'])): ?>
                                <div class="mission-info">
                                    <span class="mission-info__icone"><?= icone('users', 17) ?></span>
                                    <div>
                                        <span class="mission-info__label">Contact sur le site</span>
                                        <strong><?= $echapper($mission['site_b2b_nom'] ?? 'Site entreprise') ?></strong>
                                        <?php if (!empty($mission['entreprise_b2b_nom'])): ?><p><?= $echapper($mission['entreprise_b2b_nom']) ?></p><?php endif; ?>
                                        <?php if (!empty($mission['site_b2b_details'])): ?><p><?= nl2br($echapper($mission['site_b2b_details'])) ?></p><?php endif; ?>
                                        <?php if (!empty($mission['site_b2b_telephone'])): ?><p><a href="tel:<?= $echapper($mission['site_b2b_telephone']) ?>"><?= $echapper($mission['site_b2b_telephone']) ?></a></p><?php endif; ?>
                                        <?php if (!empty($mission['site_b2b_email'])): ?><p><a href="mailto:<?= $echapper($mission['site_b2b_email']) ?>"><?= $echapper($mission['site_b2b_email']) ?></a></p><?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($mission['date_creneau_planifie']) && $mission['heure_creneau_planifie'] !== null): ?>
                                <div class="mission-info">
                                    <span class="mission-info__icone"><?= icone('clock', 17) ?></span>
                                    <div><span class="mission-info__label">Créneau attribué par le coordinateur</span><strong><?= $echapper(date('d/m/Y', strtotime($mission['date_creneau_planifie']))) ?> · <?= sprintf('%02d:00–%02d:00', (int) $mission['heure_creneau_planifie'], ((int) $mission['heure_creneau_planifie'] + 1) % 24) ?></strong></div>
                                </div>
                                <?php if (!empty($mission['date_creneau_souhaite']) && $mission['heure_creneau_souhaitee'] !== null): ?>
                                    <div class="mission-info">
                                        <span class="mission-info__icone"><?= icone('clock', 17) ?></span>
                                        <div><span class="mission-info__label">Souhait initial du client</span><strong><?= $echapper(date('d/m/Y', strtotime($mission['date_creneau_souhaite']))) ?> · <?= sprintf('%02d:00–%02d:00', (int) $mission['heure_creneau_souhaitee'], ((int) $mission['heure_creneau_souhaitee'] + 1) % 24) ?></strong></div>
                                    </div>
                                <?php endif; ?>
                            <?php elseif (!empty($mission['date_creneau_souhaite']) && $mission['heure_creneau_souhaitee'] !== null): ?>
                                <div class="mission-info">
                                    <span class="mission-info__icone"><?= icone('clock', 17) ?></span>
                                    <div><span class="mission-info__label">Créneau souhaité par le client</span><strong><?= $echapper(date('d/m/Y', strtotime($mission['date_creneau_souhaite']))) ?> · <?= sprintf('%02d:00–%02d:00', (int) $mission['heure_creneau_souhaitee'], ((int) $mission['heure_creneau_souhaitee'] + 1) % 24) ?></strong></div>
                                </div>
                            <?php endif; ?>
                            <div class="mission-info">
                                <span class="mission-info__icone"><?= icone('wrench', 17) ?></span>
                                <div><span class="mission-info__label">Catégorie</span><strong><?= $echapper($mission['categorie_nom']) ?></strong></div>
                            </div>
                            <div class="mission-info">
                                <span class="mission-info__icone mission-info__icone--<?= $mission['urgence'] === 'urgente' ? 'urgent' : 'normal' ?>"><?= icone($mission['urgence'] === 'urgente' ? 'bolt' : 'clock', 17) ?></span>
                                <div><span class="mission-info__label">Niveau de priorité</span><strong><?= $mission['urgence'] === 'urgente' ? 'Urgente' : 'Normale' ?></strong></div>
                            </div>
                            <div class="mission-description">
                                <span class="mission-info__label">Description du client</span>
                                <p><?= nl2br($echapper($mission['description'])) ?></p>
                            </div>
                            <?php if (!empty($mission['photo_path'])): ?>
                                <div class="mission-photo-client">
                                    <span class="mission-info__label">Photo envoyée par le client</span>
                                    <a href="/allopro/public/<?= $echapper($mission['photo_path']) ?>" target="_blank" rel="noopener">
                                        <img src="/allopro/public/<?= $echapper($mission['photo_path']) ?>" alt="Photo fournie par le client pour la mission <?= $echapper($mission['numero_dossier']) ?>" loading="lazy">
                                        <span>Ouvrir la photo <?= icone('arrow', 14) ?></span>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>

                    <?php if (!$missionEnAttente): ?>
                    <section class="mission-carte mission-checklist" id="mission-checklist" aria-labelledby="mission-checklist-titre">
                        <header class="mission-carte__entete">
                            <span><?= icone('check', 18) ?></span>
                            <div>
                                <h2 id="mission-checklist-titre">Checklist de l’intervention</h2>
                                <p><?= $checklistTerminee ?> élément<?= $checklistTerminee > 1 ? 's' : '' ?> sur <?= count($checklist) ?> terminé<?= $checklistTerminee > 1 ? 's' : '' ?></p>
                            </div>
                        </header>
                        <div class="mission-checklist__progression" role="progressbar" aria-label="Progression de la checklist" aria-valuemin="0" aria-valuemax="<?= count($checklist) ?>" aria-valuenow="<?= $checklistTerminee ?>">
                            <span style="width: <?= count($checklist) > 0 ? (int) round($checklistTerminee / count($checklist) * 100) : 0 ?>%"></span>
                        </div>
                        <div class="mission-checklist__liste">
                            <?php foreach ($checklist as $element): ?>
                                <form method="POST" class="mission-checklist__element <?= $element['terminee'] ? 'mission-checklist__element--termine' : '' ?>">
                                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                    <input type="hidden" name="action" value="checklist">
                                    <input type="hidden" name="element_id" value="<?= (int) $element['id'] ?>">
                                    <label>
                                        <input type="checkbox" name="terminee" value="1" <?= $element['terminee'] ? 'checked' : '' ?> <?= $missionTerminee ? 'disabled' : 'onchange="this.form.requestSubmit()"' ?>>
                                        <span><?= $echapper($element['libelle']) ?></span>
                                    </label>
                                    <?php if ($missionTerminee): ?><span class="mission-checklist__etat"><?= $element['terminee'] ? 'Fait' : 'Non coché' ?></span><?php endif; ?>
                                </form>
                            <?php endforeach; ?>
                        </div>
                    </section>

                    <section class="mission-carte mission-photos" aria-labelledby="mission-photos-titre">
                        <header class="mission-carte__entete">
                            <span><?= icone('camera', 18) ?></span>
                            <div><h2 id="mission-photos-titre">Photos de l’intervention</h2><p>Documentez l’état avant et après votre passage</p></div>
                        </header>
                        <div class="mission-photos__grille">
                            <?php foreach (['avant' => ['Avant intervention', $mission['photo_avant']], 'apres' => ['Après intervention', $mission['photo_apres']]] as $typePhoto => [$libellePhoto, $cheminPhoto]): ?>
                                <article class="mission-photo">
                                    <div class="mission-photo__aperçu">
                                        <?php if (!empty($cheminPhoto)): ?>
                                            <a href="/allopro/public/<?= $echapper($cheminPhoto) ?>" target="_blank" rel="noopener">
                                                <img src="/allopro/public/<?= $echapper($cheminPhoto) ?>" alt="<?= $echapper($libellePhoto) ?>" loading="lazy">
                                            </a>
                                        <?php else: ?>
                                            <span><?= icone('camera', 24) ?></span>
                                            <small>Aucune photo ajoutée</small>
                                        <?php endif; ?>
                                    </div>
                                    <h3><?= $echapper($libellePhoto) ?></h3>
                                    <?php if (!$missionTerminee): ?>
                                        <form method="POST" enctype="multipart/form-data" class="mission-photo__formulaire">
                                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                            <input type="hidden" name="action" value="photo">
                                            <input type="hidden" name="type_photo" value="<?= $echapper($typePhoto) ?>">
                                            <label for="photo-<?= $echapper($typePhoto) ?>">Choisir une image JPG ou PNG (8 Mo max)</label>
                                            <input id="photo-<?= $echapper($typePhoto) ?>" type="file" name="photo" accept="image/jpeg,image/png" required>
                                            <button type="submit"><?= icone('plus', 15) ?> <?= $cheminPhoto ? 'Remplacer la photo' : 'Ajouter une photo' ?></button>
                                        </form>
                                    <?php endif; ?>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </section>

                    <section class="mission-carte mission-documents" id="mission-documents" aria-labelledby="mission-documents-titre">
                        <header class="mission-carte__entete">
                            <span><?= icone('file-text', 18) ?></span>
                            <div><h2 id="mission-documents-titre">Documents de l’intervention</h2><p>Conservez devis, factures ou documents utiles avec cette mission</p></div>
                        </header>
                        <?php if (!$missionTerminee): ?>
                            <form method="POST" enctype="multipart/form-data" class="mission-document-formulaire">
                                <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                <input type="hidden" name="action" value="document">
                                <label for="mission-document">Ajouter un document <small>PDF, JPG, PNG ou WebP · 10 Mo maximum</small></label>
                                <div>
                                    <input id="mission-document" type="file" name="document" accept="application/pdf,image/jpeg,image/png,image/webp" required>
                                    <button type="submit"><?= icone('plus', 15) ?> Ajouter</button>
                                </div>
                            </form>
                        <?php endif; ?>
                        <div class="mission-documents__liste">
                            <?php if (!$documents): ?>
                                <p class="mission-documents__vide">Aucun document ajouté pour le moment.</p>
                            <?php else: ?>
                                <?php foreach ($documents as $document): ?>
                                    <a class="mission-document" href="document.php?id=<?= (int) $document['id'] ?>">
                                        <span class="mission-document__icone"><?= icone($document['mime_type'] === 'application/pdf' ? 'file-text' : 'camera', 17) ?></span>
                                        <span class="mission-document__infos">
                                            <strong><?= $echapper($document['nom_original']) ?></strong>
                                            <small><?= number_format((int) $document['taille'] / 1024, 0, ',', ' ') ?> Ko · <?= $echapper(date('d/m/Y à H:i', strtotime($document['date_creation']))) ?></small>
                                        </span>
                                        <span class="mission-document__action"><?= icone('arrow', 15) ?></span>
                                    </a>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </section>
                    <?php endif; ?>
                </div>

                <aside class="mission-colonne mission-colonne--actions">
                    <?php if ($missionEnAttente): ?>
                        <section class="mission-carte mission-decision" aria-labelledby="mission-decision-titre">
                            <header class="mission-carte__entete">
                                <span><?= icone('alert', 18) ?></span>
                                <div><h2 id="mission-decision-titre">Répondre à la proposition</h2><p>Choisissez si vous prenez en charge cette intervention.</p></div>
                            </header>
                            <form method="POST" class="mission-formulaire">
                                <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                <input type="hidden" name="action" value="accepter">
                                <button class="mission-bouton mission-bouton--cloture" type="submit"><?= icone('check', 17) ?> Accepter la mission</button>
                            </form>
                            <form method="POST" class="mission-formulaire">
                                <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                <input type="hidden" name="action" value="refuser">
                                <label for="mission-motif-refus">Motif du refus <small>facultatif</small></label>
                                <textarea id="mission-motif-refus" name="motif" rows="3" maxlength="2000" placeholder="Indiquez au coordinateur pourquoi vous ne pouvez pas prendre cette mission…"></textarea>
                                <button class="mission-bouton mission-bouton--secondaire" type="submit" onclick="return confirm('Refuser cette mission et la transmettre au coordinateur ?');"><?= icone('x', 16) ?> Refuser la mission</button>
                            </form>
                        </section>
                    <?php elseif (!$missionTerminee): ?>
                        <section class="mission-carte mission-statut-form" aria-labelledby="mission-statut-titre">
                            <header class="mission-carte__entete">
                                <span><?= icone('refresh', 18) ?></span>
                                <div><h2 id="mission-statut-titre">Faire avancer la mission</h2><p>Informez le client de votre progression</p></div>
                            </header>
                            <form method="POST" class="mission-formulaire">
                                <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                <input type="hidden" name="action" value="statut">
                                <label for="mission-nouveau-statut">Nouveau statut</label>
                                <select id="mission-nouveau-statut" name="nouveau_statut" required>
                                    <option value="en_route" <?= $mission['statut'] === 'en_route' ? 'selected' : '' ?>>En route</option>
                                    <option value="arrive" <?= $mission['statut'] === 'arrive' ? 'selected' : '' ?>>Arrivé sur place</option>
                                    <option value="diagnostic" <?= $mission['statut'] === 'diagnostic' ? 'selected' : '' ?>>Diagnostic</option>
                                    <option value="en_cours" <?= $mission['statut'] === 'en_cours' ? 'selected' : '' ?>>Intervention en cours</option>
                                </select>
                                <button class="mission-bouton mission-bouton--secondaire" type="submit"><?= icone('check', 16) ?> Mettre à jour le statut</button>
                            </form>
                        </section>

                        <section class="mission-carte mission-cloture" aria-labelledby="mission-cloture-titre">
                            <header class="mission-carte__entete">
                                <span><?= icone('check', 18) ?></span>
                                <div><h2 id="mission-cloture-titre">Clôturer l’intervention</h2><p>Terminez la mission et transmettez votre rapport</p></div>
                            </header>
                            <div class="mission-cloture__contenu">
                                <p class="mission-cloture__note"><?= icone('shield', 15) ?><?php if (!empty($mission['contrat_b2b_id'])): ?> Intervention entreprise couverte par contrat : le rapport clôture la mission et consomme un crédit, sans paiement individuel.<?php elseif ($couvertureDisponible): ?> Cette intervention est couverte par un <?= $couvertureDisponible['type'] === 'abonnement' ? 'abonnement' : 'Pass' ?> compatible. Aucun montant n’est à demander au client ; la couverture sera appliquée à la clôture.<?php else: ?> Aucun Pass ou abonnement compatible n’est actuellement disponible. Saisissez le montant à facturer avant la clôture.<?php endif; ?></p>
                                <form method="POST" class="mission-formulaire mission-formulaire--cloture">
                                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfSession]) ?>">
                                    <input type="hidden" name="action" value="cloturer">
                                    <label for="mission-rapport">Rapport d’intervention <span>*</span></label>
                                    <textarea id="mission-rapport" name="rapport" rows="5" maxlength="10000" placeholder="Décrivez le diagnostic, les travaux réalisés et les pièces utilisées…" required><?= $echapper($rapportSaisi) ?></textarea>
                                    <?php if (empty($mission['contrat_b2b_id']) && !$couvertureDisponible): ?>
                                        <label for="mission-montant">Montant à facturer <small>Si aucune couverture ne s’applique</small></label>
                                        <div class="mission-montant">
                                            <input id="mission-montant" type="number" name="montant" min="1" max="99999999" step="1" value="<?= $echapper($montantSaisi) ?>" placeholder="Ex. 15 000">
                                            <span>FCFA</span>
                                        </div>
                                    <?php endif; ?>
                                    <button class="mission-bouton mission-bouton--cloture" type="submit" onclick="return confirm('Clôturer cette intervention et transmettre le rapport au client ?');"><?= icone('check', 17) ?> Clôturer la mission</button>
                                </form>
                            </div>
                        </section>
                    <?php else: ?>
                        <section class="mission-carte mission-terminee">
                            <span><?= icone('check', 22) ?></span>
                            <h2>Intervention terminée</h2>
                            <p>Le rapport a été transmis. Cette mission est maintenant en lecture seule.</p>
                            <?php if (!empty($mission['rapport'])): ?>
                                <div class="mission-terminee__rapport"><strong>Rapport transmis</strong><p><?= nl2br($echapper($mission['rapport'])) ?></p></div>
                            <?php endif; ?>
                        </section>
                    <?php endif; ?>
                </aside>
            </div>
        <?php endif; ?>
    </main>
</div>
<?php if ($mission && empty($mission['est_demande_entreprise']) && !$missionTerminee && !$missionEnAttente): ?>
    <?php include __DIR__ . '/../../includes/messagerie-appel-interface.php'; ?>
    <script src="../../public/js/autorisation-appel-technicien.js?v=<?= filemtime(__DIR__ . '/../../public/js/autorisation-appel-technicien.js') ?>"></script>
    <script src="../../public/js/appels-web.js?v=<?= filemtime(__DIR__ . '/../../public/js/appels-web.js') ?>"></script>
<?php endif; ?>
</body>
</html>
