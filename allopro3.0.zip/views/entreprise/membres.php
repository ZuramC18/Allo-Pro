<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';
require_once __DIR__ . '/../../includes/icones.php';
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$estAdmin = $entreprise['role_membre'] === 'admin';
$erreur = '';
$succes = '';
$csrfKey = 'csrf_entreprise_membres';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

$actionPost = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $action = $actionPost;
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (!$estAdmin) {
        http_response_code(403);
        $erreur = 'Seul un administrateur peut gérer les accès.';
    } else {
        try {
            if ($action === 'ajouter') {
                $email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new InvalidArgumentException('Saisissez une adresse e-mail valide.');
                }
                $entrepriseModele->envoyerInvitationMembre($entrepriseId, (int) $_SESSION['user_id'], $email);
                $succes = 'Invitation envoyée. La personne aura accès à cet espace après l’avoir acceptée.';
            } elseif ($action === 'annuler_invitation') {
                $invitationId = filter_var($_POST['invitation_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if ($invitationId === false || !$entrepriseModele->annulerInvitationMembre($entrepriseId, (int) $_SESSION['user_id'], (int) $invitationId)) {
                    throw new InvalidArgumentException('Cette invitation ne peut pas être annulée.');
                }
                $succes = 'L’invitation a été annulée.';
            } elseif ($action === 'permissions') {
                $membreId = filter_var($_POST['membre_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                $permissions = $_POST['permissions'] ?? [];
                if ($membreId === false || !is_array($permissions)) {
                    throw new InvalidArgumentException('Les permissions soumises sont invalides.');
                }
                $entrepriseModele->enregistrerPermissionsMembre(
                    $entrepriseId,
                    (int) $_SESSION['user_id'],
                    (int) $membreId,
                    $permissions
                );
                $succes = 'Les permissions du membre ont été mises à jour.';
            } elseif ($action === 'retirer') {
                $membreId = filter_var($_POST['membre_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if ($membreId === false || !$entrepriseModele->retirerMembre($entrepriseId, (int) $_SESSION['user_id'], (int) $membreId)) {
                    throw new InvalidArgumentException('Cet accès ne peut pas être retiré.');
                }
                $succes = 'L’accès du membre a été retiré.';
            }
        } catch (PDOException $exception) {
            error_log('Gestion des membres entreprise ' . $entrepriseId . ' : ' . $exception->getMessage());
            $erreur = 'La modification des accès a échoué. Réessayez.';
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        }
    }
}
$membres = $entrepriseModele->getMembres($entrepriseId);
$invitationsEnAttente = $estAdmin
    ? $entrepriseModele->getInvitationsEnAttenteEntreprise($entrepriseId, (int) $_SESSION['user_id'])
    : [];
$nombreAdmins = count(array_filter($membres, static fn(array $membre): bool => ($membre['role'] ?? '') === 'admin'));
$nombreMembres = count($membres) - $nombreAdmins;
$cataloguePermissions = EntrepriseB2B::getCataloguePermissionsMembre();
$permissionsParMembre = [];
if ($estAdmin) {
    foreach ($membres as $membre) {
        if (($membre['role'] ?? '') === 'membre') {
            $permissionsParMembre[(int) $membre['id']] = $entrepriseModele->getPermissionsMembre(
                $entrepriseId,
                (int) $_SESSION['user_id'],
                (int) $membre['id']
            );
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Utilisateurs autorisés — <?= $e($entreprise['nom']) ?></title><link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>"><script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script></head>
<body><div class="b2b-app"><?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?><main class="b2b-main b2b-members-page">
    <header class="b2b-members-hero">
        <div>
            <span class="b2b-eyebrow">COLLABORATION EN ÉQUIPE</span>
            <h1>Les bonnes personnes,<br>au bon endroit.</h1>
            <p>Gérez les accès à l’espace professionnel de <?= $e($entreprise['nom']) ?>, sans modifier les comptes personnels des membres.</p>
        </div>
        <div class="b2b-members-hero__art" aria-hidden="true">
            <span class="b2b-members-hero__orbit"></span>
            <span class="b2b-members-hero__icon"><?= icone('users', 39) ?></span>
        </div>
    </header>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
    <?php if ($succes !== ''): ?><div class="b2b-alert b2b-alert--success" role="status"><?= $e($succes) ?></div><?php endif; ?>
    <?php if ($estAdmin && ($_GET['membre_parti'] ?? '') === '1'): ?><div class="b2b-alert b2b-alert--success" role="status">Un membre a quitté cette entreprise. Consultez vos notifications pour voir les détails.</div><?php endif; ?>
    <section class="b2b-members-summary" aria-label="Résumé des accès">
        <span class="b2b-members-summary__icon"><?= icone('users', 19) ?></span>
        <span class="b2b-members-summary__total"><strong><?= count($membres) ?></strong><small><?= count($membres) === 1 ? 'personne autorisée' : 'personnes autorisées' ?></small></span>
        <span class="b2b-members-summary__divider" aria-hidden="true"></span>
        <span class="b2b-members-summary__role"><i class="b2b-members-dot b2b-members-dot--admin" aria-hidden="true"></i><?= $nombreAdmins ?> administrateur<?= $nombreAdmins === 1 ? '' : 's' ?></span>
        <span class="b2b-members-summary__role"><i class="b2b-members-dot" aria-hidden="true"></i><?= $nombreMembres ?> membre<?= $nombreMembres === 1 ? '' : 's' ?></span>
    </section>
    <section class="b2b-panel b2b-members-panel">
        <div class="b2b-members-panel__heading">
            <div><span class="b2b-eyebrow">ACCÈS À L’ESPACE</span><h2>Membres autorisés</h2><p>Les personnes qui peuvent consulter et gérer cet espace entreprise.</p></div>
            <?php if (count($membres) > 1): ?><label class="b2b-members-search"><?= icone('search', 17) ?><span class="b2b-visually-hidden">Rechercher un membre</span><input id="recherche-membres-entreprise" type="search" placeholder="Nom ou e-mail…" autocomplete="off"></label><?php endif; ?>
        </div>
        <?php if ($membres): ?><div class="b2b-table-wrap"><table class="b2b-list b2b-members-list"><thead><tr><th>Personne</th><th>Adresse e-mail</th><th>Rôle</th><th>Depuis le</th><?php if ($estAdmin): ?><th>Accès</th><?php endif; ?></tr></thead><tbody>
        <?php foreach ($membres as $membre): ?><tr>
            <?php
            $nomMembre = trim((string) ($membre['prenom'] ?? '') . ' ' . (string) ($membre['nom'] ?? ''));
            $initialesMembre = mb_strtoupper(
                mb_substr((string) ($membre['prenom'] ?? ''), 0, 1)
                . mb_substr((string) ($membre['nom'] ?? ''), 0, 1)
            );
            ?>
            <td data-label="Personne" class="b2b-members-person" data-member-search="<?= $e($nomMembre . ' ' . $membre['email']) ?>">
                <span class="b2b-members-avatar <?= $membre['role'] === 'admin' ? 'b2b-members-avatar--admin' : '' ?>" aria-hidden="true"><?= $e($initialesMembre !== '' ? $initialesMembre : mb_strtoupper(mb_substr((string) $membre['email'], 0, 1))) ?></span>
                <span class="b2b-members-person__name"><strong><?= $e($nomMembre !== '' ? $nomMembre : $membre['email']) ?></strong><small><?= $membre['role'] === 'admin' ? 'Compte administrateur' : 'Accès équipe' ?></small></span>
            </td>
            <td data-label="Adresse e-mail" class="b2b-members-email"><a href="mailto:<?= $e($membre['email']) ?>"><?= $e($membre['email']) ?></a></td>
            <td data-label="Rôle"><span class="b2b-members-role <?= $membre['role'] === 'admin' ? 'b2b-members-role--admin' : '' ?>"><?= icone($membre['role'] === 'admin' ? 'shield' : 'user', 14) ?><?= $membre['role'] === 'admin' ? 'Administrateur' : 'Membre' ?></span></td>
            <td data-label="Depuis le" class="b2b-members-date"><?= icone('calendar', 14) ?><?= $e(date('d/m/Y', strtotime($membre['date_ajout']))) ?></td>
            <?php if ($estAdmin): ?><td data-label="Accès" class="b2b-members-access"><?php if ($membre['role'] === 'membre'): ?><form method="post" data-remove-member-form data-member-name="<?= $e($nomMembre !== '' ? $nomMembre : $membre['email']) ?>"><input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="retirer"><input type="hidden" name="membre_id" value="<?= (int) $membre['id'] ?>"><button class="b2b-button b2b-button--secondary" type="submit" aria-label="Retirer l’accès de <?= $e($nomMembre !== '' ? $nomMembre : $membre['email']) ?>"><?= icone('x', 14) ?> Retirer</button></form><?php else: ?><span class="b2b-members-owner" title="L’administrateur principal ne peut pas être retiré"><?= icone('key', 14) ?> Principal</span><?php endif; ?></td><?php endif; ?>
        </tr><?php endforeach; ?>
    </tbody></table></div><p id="membres-recherche-vide" class="b2b-members-no-results" hidden>Aucun membre ne correspond à votre recherche.</p>
        <?php else: ?><div class="b2b-members-empty"><span class="b2b-members-empty__icon" aria-hidden="true"><?= icone('users', 23) ?></span><strong><?= $invitationsEnAttente ? 'Aucun membre n’a encore accepté son invitation' : 'Aucun membre n’a encore rejoint cet espace' ?></strong><p><?= $invitationsEnAttente ? 'Les invitations envoyées apparaîtront comme membres après leur acceptation.' : 'Invitez un collègue pour lui proposer de rejoindre cet espace entreprise.' ?></p></div><?php endif; ?>
    </section>
    <?php if ($estAdmin): ?>
        <dialog class="b2b-member-remove-dialog" data-remove-member-dialog aria-labelledby="retirer-membre-titre" aria-describedby="retirer-membre-description">
            <div class="b2b-member-remove-dialog__content">
                <span class="b2b-member-remove-dialog__icon" aria-hidden="true"><?= icone('x', 22) ?></span>
                <span class="b2b-eyebrow">CONFIRMATION</span>
                <h2 id="retirer-membre-titre">Retirer ce membre ?</h2>
                <p id="retirer-membre-description">L’accès de <strong data-remove-member-name></strong> à cet espace entreprise sera supprimé.</p>
                <div class="b2b-member-remove-dialog__actions">
                    <button class="b2b-button b2b-button--secondary" type="button" data-cancel-remove-member>Annuler</button>
                    <button class="b2b-button b2b-button--danger" type="button" data-confirm-remove-member>Retirer l’accès</button>
                </div>
            </div>
        </dialog>
    <?php endif; ?>
    <?php if ($estAdmin): ?>
        <?php if ($permissionsParMembre): ?>
            <?php $premierMembrePermissions = (int) array_key_first($permissionsParMembre); ?>
            <section class="b2b-panel b2b-member-permissions" aria-labelledby="permissions-membres-titre">
                <div class="b2b-members-panel__heading">
                    <div><span class="b2b-eyebrow">ACCÈS PERSONNALISÉS</span><h2 id="permissions-membres-titre">Permissions des membres</h2><p>Sélectionnez un membre pour afficher ses rubriques et ajuster ses accès.</p></div>
                </div>
                <div class="b2b-member-permissions__layout">
                    <nav class="b2b-member-permissions__members" aria-label="Choisir un membre">
                        <?php foreach ($membres as $membre):
                            $membreId = (int) $membre['id'];
                            if (($membre['role'] ?? '') !== 'membre') {
                                continue;
                            }
                            $nomMembre = trim((string) ($membre['prenom'] ?? '') . ' ' . (string) ($membre['nom'] ?? ''));
                        ?>
                            <button class="b2b-member-permissions__member<?= $membreId === $premierMembrePermissions ? ' is-active' : '' ?>" type="button" data-permission-member="<?= $membreId ?>" aria-pressed="<?= $membreId === $premierMembrePermissions ? 'true' : 'false' ?>">
                                <span class="b2b-members-avatar" aria-hidden="true"><?= $e(mb_strtoupper(mb_substr($nomMembre !== '' ? $nomMembre : $membre['email'], 0, 1))) ?></span>
                                <span><strong><?= $e($nomMembre !== '' ? $nomMembre : $membre['email']) ?></strong><small><?= $e($membre['email']) ?></small></span>
                            </button>
                        <?php endforeach; ?>
                    </nav>
                    <div class="b2b-member-permissions__list">
                    <?php foreach ($membres as $membre):
                        $membreId = (int) $membre['id'];
                        if (($membre['role'] ?? '') !== 'membre') {
                            continue;
                        }
                        $nomMembre = trim((string) ($membre['prenom'] ?? '') . ' ' . (string) ($membre['nom'] ?? ''));
                    ?>
                        <form method="post" class="b2b-member-permissions__card" data-permission-form="<?= $membreId ?>" data-permission-endpoint="../../public/api-entreprise-permissions.php?entreprise_id=<?= $entrepriseId ?>"<?= $membreId !== $premierMembrePermissions ? ' hidden' : '' ?>>
                            <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                            <input type="hidden" name="action" value="permissions">
                            <input type="hidden" name="membre_id" value="<?= $membreId ?>">
                            <div class="b2b-member-permissions__heading">
                                <div><strong><?= $e($nomMembre !== '' ? $nomMembre : $membre['email']) ?></strong><small><?= $e($membre['email']) ?></small></div>
                                <button class="b2b-button b2b-button--secondary" type="submit">Enregistrer</button>
                            </div>
                            <p class="b2b-member-permissions__status" data-permission-status role="status" aria-live="polite"></p>
                            <div class="b2b-member-permissions__grid">
                                <?php foreach ($cataloguePermissions as $permissionKey => $libellePermission): ?>
                                    <label class="b2b-member-permissions__option">
                                        <input type="checkbox" name="permissions[]" value="<?= $e($permissionKey) ?>" <?= in_array($permissionKey, $permissionsParMembre[$membreId], true) ? 'checked' : '' ?>>
                                        <span><?= $e($libellePermission) ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </form>
                    <?php endforeach; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        <?php if ($invitationsEnAttente): ?>
            <section class="b2b-panel b2b-members-pending" aria-labelledby="invitations-en-attente-titre">
                <div class="b2b-members-panel__heading">
                    <div><span class="b2b-eyebrow">EN ATTENTE DE RÉPONSE</span><h2 id="invitations-en-attente-titre">Invitations envoyées</h2><p>Ces personnes n’ont pas encore accès à l’espace entreprise.</p></div>
                </div>
                <div class="b2b-members-pending__list">
                    <?php foreach ($invitationsEnAttente as $invitation):
                        $nomInvite = trim((string) ($invitation['prenom'] ?? '') . ' ' . (string) ($invitation['nom'] ?? ''));
                        $dateInvitation = strtotime((string) $invitation['date_creation']);
                    ?>
                        <div class="b2b-members-pending__item">
                            <span class="b2b-members-pending__person"><strong><?= $e($nomInvite !== '' ? $nomInvite : $invitation['email']) ?></strong><small><?= $e($invitation['email']) ?><?php if ($dateInvitation !== false): ?> · Envoyée le <?= $e(date('d/m/Y', $dateInvitation)) ?><?php endif; ?></small></span>
                            <form method="post">
                                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                                <input type="hidden" name="action" value="annuler_invitation">
                                <input type="hidden" name="invitation_id" value="<?= (int) $invitation['id'] ?>">
                                <button class="b2b-button b2b-button--secondary" type="submit"><?= icone('x', 14) ?> Annuler</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
        <section class="b2b-members-invite" aria-labelledby="autoriser-membre-titre">
            <div class="b2b-members-invite__intro">
                <span class="b2b-members-invite__icon" aria-hidden="true"><?= icone('user', 20) ?></span>
                <span class="b2b-eyebrow">INVITATION SÉCURISÉE</span>
                <h2 id="autoriser-membre-titre">Inviter un collègue</h2>
                <p>Envoyez une invitation à une personne de confiance. Son accès sera activé uniquement après son acceptation.</p>
                <ul>
                    <li><?= icone('check', 14) ?> Son compte client reste personnel</li>
                    <li><?= icone('check', 14) ?> L’adresse e-mail doit être vérifiée</li>
                    <li><?= icone('check', 14) ?> L’accès peut être retiré à tout moment</li>
                </ul>
            </div>
            <form method="post" class="b2b-form b2b-members-invite__form">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="ajouter">
                <label for="membre-email">Adresse e-mail du compte client</label>
                <div class="b2b-members-invite__input"><?= icone('message', 17) ?><input id="membre-email" type="email" name="email" maxlength="150" placeholder="nom@entreprise.com" autocomplete="email" required></div>
                <small>La personne doit déjà avoir un compte client ALLÔ PRO actif et vérifié.</small>
                <button class="b2b-button" type="submit"><?= icone('plus', 16) ?> Envoyer l’invitation</button>
            </form>
        </section>
    <?php endif; ?>
<script>
const rechercheMembres = document.getElementById('recherche-membres-entreprise');
if (rechercheMembres) {
    const lignesMembres = Array.from(document.querySelectorAll('.b2b-members-list tbody tr'));
    const resultatVide = document.getElementById('membres-recherche-vide');
    const normaliserTexte = (texte) => texte.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('fr').trim();
    rechercheMembres.addEventListener('input', () => {
        const terme = normaliserTexte(rechercheMembres.value);
        let visibles = 0;
        lignesMembres.forEach((ligne) => {
            const correspond = normaliserTexte(ligne.querySelector('[data-member-search]')?.dataset.memberSearch || '').includes(terme);
            ligne.hidden = !correspond;
            if (correspond) visibles += 1;
        });
        resultatVide.hidden = visibles !== 0;
    });
}
</script>
</main></div></body></html>
