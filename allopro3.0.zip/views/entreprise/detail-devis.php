<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';

$devisId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$devis = $devisId === false
    ? null
    : $entrepriseModele->getDevisDetail($entrepriseId, (int) $devisId);
if (!$devis) {
    http_response_code(404);
    exit('Ce devis est introuvable dans votre entreprise.');
}

$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$statuts = [
    'demande' => 'Demande transmise',
    'emis' => 'Devis envoyé',
    'accepte' => 'Accepté',
    'refuse' => 'Refusé',
    'expire' => 'Expiré',
];
$libelleStatut = $statuts[$devis['statut']] ?? ucfirst(str_replace('_', ' ', $devis['statut']));
$devisRepondable = $devis['statut'] === 'emis'
    && (!$devis['date_validite'] || $devis['date_validite'] >= date('Y-m-d'));
$csrfKey = 'csrf_entreprise_gestion';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}
$retourUrl = 'gestion.php?entreprise_id=' . $entrepriseId . '&module=devis';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Devis <?= $e($devis['numero'] ?: ('#' . (int) $devis['id'])) ?> — <?= $e($entreprise['nom']) ?></title>
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
</head>
<body>
<div class="b2b-app">
    <?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?>
    <main class="b2b-main">
        <a class="b2b-detail-back" href="<?= $e($retourUrl) ?>"><span aria-hidden="true">←</span> Tous les devis</a>
        <header class="b2b-detail-hero">
            <div>
                <span class="b2b-eyebrow">PROPOSITION COMMERCIALE</span>
                <h1><?= $e($devis['numero'] ?: ('Devis #' . (int) $devis['id'])) ?></h1>
                <p><?= $devis['date_emission'] ? 'Émis le ' . $e(date('d/m/Y à H:i', strtotime($devis['date_emission']))) : 'Demande créée le ' . $e(date('d/m/Y à H:i', strtotime($devis['date_creation']))) ?></p>
            </div>
            <span class="b2b-status b2b-status--<?= $e($devis['statut']) ?>"><?= $e($libelleStatut) ?></span>
        </header>

        <div class="b2b-detail-layout">
            <div class="b2b-detail-main">
                <section class="b2b-panel">
                    <div class="b2b-panel__heading">
                        <div><span class="b2b-eyebrow">VOTRE BESOIN</span><h2>Description</h2></div>
                    </div>
                    <p class="b2b-quote-description"><?= nl2br($e($devis['description'])) ?></p>
                </section>

                <?php if ($devis['details']): ?>
                    <section class="b2b-panel">
                        <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">PROPOSITION ALLÔ PRO</span><h2>Prestations et conditions</h2></div></div>
                        <div class="b2b-quote-description"><?= nl2br($e($devis['details'])) ?></div>
                    </section>
                <?php endif; ?>

                <?php if ($devis['demande_id']): ?>
                    <section class="b2b-panel">
                        <span class="b2b-eyebrow">DOSSIER ASSOCIÉ</span>
                        <h2><?= $e($devis['numero_dossier'] ?: 'Dossier entreprise') ?></h2>
                        <?php if ($devis['site_nom']): ?><p>Site : <?= $e($devis['site_nom']) ?></p><?php endif; ?>
                        <?php if ($devis['numero_dossier'] && $entrepriseAutorisePermission('demandes')): ?><a class="b2b-button b2b-button--secondary" href="detail-demande.php?entreprise_id=<?= $entrepriseId ?>&amp;id=<?= (int) $devis['demande_id'] ?>">Consulter le dossier</a><?php endif; ?>
                    </section>
                <?php endif; ?>
            </div>

            <aside class="b2b-detail-aside">
                <section class="b2b-panel">
                    <span class="b2b-eyebrow">RÉCAPITULATIF</span>
                    <h2>Montant proposé</h2>
                    <p class="b2b-quote-amount"><?= $devis['montant'] === null ? 'En cours de chiffrage' : number_format((float) $devis['montant'], 0, ',', ' ') . ' FCFA' ?></p>
                    <dl class="b2b-detail-list b2b-detail-list--single">
                        <div><dt>État</dt><dd><?= $e($libelleStatut) ?></dd></div>
                        <div><dt>Demandé le</dt><dd><?= $e(date('d/m/Y à H:i', strtotime($devis['date_creation']))) ?></dd></div>
                        <?php if ($devis['date_validite']): ?><div><dt>Valide jusqu’au</dt><dd><?= $e(date('d/m/Y', strtotime($devis['date_validite']))) ?></dd></div><?php endif; ?>
                        <?php if ($devis['date_reponse']): ?><div><dt>Réponse enregistrée le</dt><dd><?= $e(date('d/m/Y à H:i', strtotime($devis['date_reponse']))) ?></dd></div><?php endif; ?>
                    </dl>
                </section>

                <?php if ($devisRepondable): ?>
                    <section class="b2b-panel">
                        <span class="b2b-eyebrow">VOTRE DÉCISION</span>
                        <h2>Répondre au devis</h2>
                        <p>La réponse sera transmise à ALLÔ PRO. L’activation du contrat B2B sera confirmée séparément.</p>
                        <form method="post" action="<?= $e($retourUrl) ?>" class="b2b-actions">
                            <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                            <input type="hidden" name="action" value="repondre">
                            <input type="hidden" name="devis_id" value="<?= (int) $devis['id'] ?>">
                            <button class="b2b-button" name="reponse" value="accepte" type="submit">Accepter</button>
                            <button class="b2b-button b2b-button--secondary" name="reponse" value="refuse" type="submit">Refuser</button>
                        </form>
                    </section>
                <?php endif; ?>

                <a class="b2b-button b2b-button--secondary b2b-detail-back-button" href="<?= $e($retourUrl) ?>">Retour aux devis</a>
            </aside>
        </div>
    </main>
</div>
<script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script>
</body>
</html>
