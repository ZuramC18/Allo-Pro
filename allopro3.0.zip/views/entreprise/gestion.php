<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';

$modules = [
    'tickets' => ['Tickets et SAV', 'Suivez l’état de vos demandes de service après-vente.'],
    'interventions' => ['Suivi des interventions', 'Consultez les missions, les créneaux et leur progression.'],
    'contrats' => ['Contrats et SLA', 'Consultez vos contrats, crédits et délais de service convenus.'],
    'devis' => ['Devis', 'Demandez un chiffrage et répondez aux devis émis pour votre entreprise.'],
    'factures' => ['Factures', 'Factures des interventions facturées directement, distinctes des règlements de contrat B2B.'],
    'paiements' => ['Paiements', 'Consultez séparément les règlements directs et ceux de vos contrats entreprise.'],
    'rapports' => ['Rapports', 'Indicateurs d’activité calculés sur les dossiers de vos sites.'],
    'historique' => ['Historique des interventions', 'Interventions terminées pour l’ensemble de vos sites.'],
    'documents' => ['Documents', 'Documents produits et ajoutés au suivi de vos interventions.'],
    'parametres' => ['Paramètres du compte', 'Coordonnées de contact et identité de votre entreprise.'],
];
$module = is_string($_GET['module'] ?? null) ? $_GET['module'] : '';
if (!isset($modules[$module])) {
    http_response_code(404);
    exit('Cette rubrique est introuvable.');
}
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$estAdmin = $entreprise['role_membre'] === 'admin';
$libelleEtatContrat = static function (array $contrat): string {
    if ($contrat['statut'] !== 'actif') return 'Résilié';
    if ($contrat['date_debut'] > date('Y-m-d')) return 'À venir';
    if ($contrat['date_fin'] < date('Y-m-d')) return 'Expiré';
    return 'Actif';
};
$erreur = '';
$succes = '';
$iconesModule = [
    'interventions' => 'wrench',
    'historique' => 'refresh',
    'contrats' => 'shield',
    'devis' => 'file-text',
    'factures' => 'receipt',
    'paiements' => 'wallet',
    'rapports' => 'chart',
    'documents' => 'folder',
    'parametres' => 'settings',
];
$csrfKey = 'csrf_entreprise_gestion';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($module === 'tickets') {
        $demandeId = filter_var($_POST['demande_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $motif = is_string($_POST['motif'] ?? null) ? $_POST['motif'] : '';
        if ($demandeId === false) {
            $erreur = 'Choisissez un dossier terminé.';
        } else {
            try {
                $entrepriseModele->creerTicketSav($entrepriseId, (int) $_SESSION['user_id'], (int) $demandeId, $motif);
                $succes = 'Votre ticket SAV a été créé.';
            } catch (InvalidArgumentException | RuntimeException $exception) {
                $erreur = $exception->getMessage();
            } catch (PDOException $exception) {
                error_log('Création ticket SAV entreprise ' . $entrepriseId . ' : ' . $exception->getMessage());
                $erreur = 'Le ticket SAV n’a pas pu être créé. Réessayez.';
            }
        }
    } elseif ($module === 'devis') {
        $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
        try {
            if ($action === 'demander') {
                $demandeId = filter_var($_POST['demande_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                $description = is_string($_POST['description'] ?? null) ? $_POST['description'] : '';
                $entrepriseModele->demanderDevis(
                    $entrepriseId,
                    (int) $_SESSION['user_id'],
                    $demandeId === false ? null : (int) $demandeId,
                    $description
                );
                $succes = 'Votre demande de devis a été transmise à ALLÔ PRO.';
            } elseif ($action === 'repondre') {
                $devisId = filter_var($_POST['devis_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                $reponse = is_string($_POST['reponse'] ?? null) ? $_POST['reponse'] : '';
                if ($devisId === false || !$entrepriseModele->repondreDevis($entrepriseId, (int) $_SESSION['user_id'], (int) $devisId, $reponse)) {
                    throw new InvalidArgumentException('Ce devis n’est plus disponible pour une réponse.');
                }
                $succes = $reponse === 'accepte' ? 'Vous avez accepté le devis.' : 'Vous avez refusé le devis.';
            } else {
                throw new InvalidArgumentException('Action de devis invalide.');
            }
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Gestion devis entreprise ' . $entrepriseId . ' : ' . $exception->getMessage());
            $erreur = 'Le devis n’a pas pu être enregistré. Réessayez.';
        }
    } elseif ($module === 'parametres' && $estAdmin) {
        try {
            if ($entrepriseModele->modifierEntreprise($entrepriseId, (int) $_SESSION['user_id'], $_POST)) {
                $succes = 'Les paramètres du compte ont été enregistrés.';
                $entreprise = $entrepriseModele->getEntreprisePourMembre($entrepriseId, (int) $_SESSION['user_id']);
            } else {
                $erreur = 'Les paramètres n’ont pas été modifiés.';
            }
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Modification paramètres entreprise ' . $entrepriseId . ' : ' . $exception->getMessage());
            $erreur = 'Les paramètres n’ont pas pu être enregistrés. Réessayez.';
        }
    } else {
        http_response_code(403);
        $erreur = 'Cette action n’est pas autorisée.';
    }
}

$lignes = [];
$paiementsContrat = [];
$intervenantsActifs = [];
$eligibleSav = [];
$resume = [];
switch ($module) {
    case 'tickets':
        $lignes = $entrepriseModele->getTicketsSav($entrepriseId);
        $eligibleSav = $entrepriseModele->getDemandesEligiblesSav($entrepriseId);
        break;
    case 'interventions':
    case 'historique':
        $lignes = $entrepriseModele->getInterventions($entrepriseId);
        if ($module === 'interventions') {
            $intervenantsActifs = array_values(array_filter(
                $lignes,
                static fn(array $ligne): bool => !in_array($ligne['statut'], ['terminee', 'annulee', 'refusee'], true)
            ));
            $lignes = $intervenantsActifs;
        } else {
            $lignes = array_values(array_filter($lignes, static fn(array $ligne): bool => $ligne['statut'] === 'terminee'));
        }
        break;
    case 'contrats':
        $lignes = $entrepriseModele->getContrats($entrepriseId);
        break;
    case 'devis':
        $lignes = $entrepriseModele->getDevis($entrepriseId);
        $demandesPourDevis = $entrepriseModele->getDemandes($entrepriseId);
        break;
    case 'factures':
        $lignes = $entrepriseModele->getFactures($entrepriseId);
        break;
    case 'paiements':
        $lignes = $entrepriseModele->getPaiements($entrepriseId);
        $paiementsContrat = $entrepriseModele->getPaiementsContrat($entrepriseId);
        break;
    case 'rapports':
        $resume = $entrepriseModele->getRapport($entrepriseId);
        $lignes = $entrepriseModele->getDemandes($entrepriseId);
        break;
    case 'documents':
        $lignes = $entrepriseModele->getDocuments($entrepriseId);
        break;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= $e($modules[$module][0]) ?> — <?= $e($entreprise['nom']) ?></title><link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>"></head>
<body><div class="b2b-app"><?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?><main class="b2b-main">
    <?php if (!in_array($module, ['tickets', 'devis'], true)): ?>
        <header class="b2b-module-hero">
            <div class="b2b-module-hero__content"><span class="b2b-eyebrow">ESPACE ENTREPRISE · <?= $e(strtoupper($modules[$module][0])) ?></span><h1><?= $e($modules[$module][0]) ?></h1><p><?= $e($modules[$module][1]) ?></p></div>
            <span class="b2b-module-hero__mark" aria-hidden="true"><?= icone($iconesModule[$module] ?? 'building', 42) ?></span>
        </header>
    <?php elseif ($module === 'devis'): ?><header class="b2b-header"><div><h1><?= $e($modules[$module][0]) ?></h1><p><?= $e($modules[$module][1]) ?></p></div></header><?php endif; ?>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
    <?php if ($succes !== ''): ?><div class="b2b-alert b2b-alert--success" role="status"><?= $e($succes) ?></div><?php endif; ?>

    <?php if ($module === 'tickets'): ?>
        <?php
        $ticketsResolus = count(array_filter($lignes, static fn(array $ticket): bool => in_array(strtolower((string) $ticket['statut']), ['resolu', 'resolue', 'termine', 'terminee', 'ferme', 'fermee'], true)));
        $ticketsActifs = count($lignes) - $ticketsResolus;
        $libellesStatutSav = [
            'ouvert' => 'Ouvert',
            'nouveau' => 'Nouveau',
            'en_attente' => 'En attente',
            'en_cours' => 'En cours',
            'resolu' => 'Résolu',
            'resolue' => 'Résolue',
            'termine' => 'Terminé',
            'terminee' => 'Terminée',
            'ferme' => 'Fermé',
            'fermee' => 'Fermée',
        ];
        $statutsTicketsSav = array_unique(array_map(
            static fn(array $ticket): string => strtolower((string) $ticket['statut']),
            $lignes
        ));
        ?>
        <section class="b2b-sav-hero">
            <div class="b2b-sav-hero__content">
                <span class="b2b-eyebrow">ACCOMPAGNEMENT APRÈS INTERVENTION</span>
                <h1>Un suivi, même après la mission.</h1>
                <p>Un problème persiste après une intervention terminée ? Ouvrez un ticket SAV et retrouvez toutes les demandes de suivi au même endroit.</p>
            </div>
            <span class="b2b-sav-hero__mark" aria-hidden="true"><?= icone('headset', 48) ?></span>
        </section>
        <section class="b2b-sav-overview" aria-label="Résumé des tickets SAV">
            <div class="b2b-sav-overview__intro"><span class="b2b-sav-overview__icon" aria-hidden="true"><?= icone('message', 20) ?></span><span><strong><?= count($lignes) ?></strong><small>ticket<?= count($lignes) === 1 ? '' : 's' ?> au total</small></span></div>
            <span class="b2b-sav-overview__divider" aria-hidden="true"></span>
            <div class="b2b-sav-overview__metric"><strong><?= $ticketsActifs ?></strong><span>En suivi</span></div>
            <div class="b2b-sav-overview__metric b2b-sav-overview__metric--resolved"><strong><?= $ticketsResolus ?></strong><span>Résolu<?= $ticketsResolus === 1 ? '' : 's' ?></span></div>
            <div class="b2b-sav-overview__metric"><strong><?= count($eligibleSav) ?></strong><span>Dossier<?= count($eligibleSav) === 1 ? '' : 's' ?> éligible<?= count($eligibleSav) === 1 ? '' : 's' ?></span></div>
        </section>
        <section class="b2b-sav-request" aria-labelledby="ouvrir-ticket-titre">
            <div class="b2b-sav-request__intro">
                <span class="b2b-eyebrow">BESOIN D’UN NOUVEAU SUIVI ?</span>
                <h2 id="ouvrir-ticket-titre">Ouvrir un ticket SAV</h2>
                <p>Choisissez l’intervention terminée concernée et décrivez brièvement le problème constaté.</p>
                <div class="b2b-sav-request__note"><?= icone('info', 15) ?><span>Un ticket peut être ouvert pour une intervention terminée sans ticket SAV existant.</span></div>
            </div>
            <?php if ($eligibleSav): ?>
                <form method="post" class="b2b-form b2b-sav-request__form">
                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                    <label for="sav-demande-id">Intervention concernée
                        <select id="sav-demande-id" name="demande_id" required><option value="">Sélectionner un dossier terminé</option><?php foreach ($eligibleSav as $demande): ?><option value="<?= (int) $demande['id'] ?>"><?= $e($demande['numero_dossier'] . ' — ' . $demande['site_nom']) ?></option><?php endforeach; ?></select>
                    </label>
                    <label for="sav-motif">Motif du SAV
                        <input id="sav-motif" name="motif" maxlength="100" placeholder="Ex. : le problème persiste après l’intervention" required>
                        <span class="b2b-sav-request__hint"><span id="sav-motif-compteur">0</span>/100 caractères</span>
                    </label>
                    <div class="b2b-sav-request__submit"><span>Votre demande sera transmise à notre équipe.</span><button class="b2b-button" type="submit"><?= icone('send', 16) ?> Ouvrir le ticket</button></div>
                </form>
            <?php else: ?>
                <div class="b2b-sav-request__unavailable"><span aria-hidden="true"><?= icone('check', 17) ?></span><div><strong>Aucun dossier éligible pour le moment</strong><p>Le SAV est disponible après la clôture d’une intervention terminée. Les interventions déjà associées à un ticket ne peuvent pas en ouvrir un second.</p><a href="gestion.php?entreprise_id=<?= (int) $entrepriseId ?>&amp;module=interventions">Consulter vos interventions <?= icone('arrow', 14) ?></a></div></div>
            <?php endif; ?>
        </section>
        <section class="b2b-panel b2b-sav-list" aria-labelledby="tickets-existants-titre">
            <div class="b2b-sav-list__heading">
                <div><span class="b2b-eyebrow">HISTORIQUE SAV</span><h2 id="tickets-existants-titre">Vos tickets</h2><p>Suivez les demandes après intervention de tous les sites de l’entreprise.</p></div>
                <?php if ($lignes): ?>
                    <div class="b2b-sav-list__filters">
                        <label class="b2b-demandes-search b2b-sav-search" for="recherche-tickets-sav"><?= icone('search', 16) ?><span class="b2b-visually-hidden">Rechercher un ticket SAV</span><input id="recherche-tickets-sav" type="search" placeholder="Ticket, dossier, site, motif…" autocomplete="off"></label>
                        <label class="b2b-visually-hidden" for="filtre-statut-sav">Filtrer par statut</label>
                        <select id="filtre-statut-sav" class="b2b-demandes-select"><option value="">Tous les statuts</option><?php foreach ($statutsTicketsSav as $statutTicket): ?><option value="<?= $e($statutTicket) ?>"><?= $e($libellesStatutSav[$statutTicket] ?? ucfirst(str_replace('_', ' ', $statutTicket))) ?></option><?php endforeach; ?></select>
                    </div>
                <?php endif; ?>
            </div>
            <?php if (!$lignes): ?>
                <div class="b2b-sav-empty"><span aria-hidden="true"><?= icone('message', 21) ?></span><strong>Aucun ticket SAV pour le moment</strong><p>Lorsqu’un ticket sera ouvert pour une intervention de votre entreprise, son statut et son historique apparaîtront ici.</p></div>
            <?php else: ?>
                <div class="b2b-sav-cards">
                    <?php foreach ($lignes as $ligne):
                        $statutTicket = strtolower((string) $ligne['statut']);
                        $classeStatutTicket = (string) preg_replace('/[^a-z0-9_-]/', '', $statutTicket);
                        $libelleStatutTicket = $libellesStatutSav[$statutTicket] ?? ucfirst(str_replace('_', ' ', $statutTicket));
                        $dateTicket = strtotime((string) $ligne['date_creation']);
                        $dateResolutionTicket = !empty($ligne['date_resolution']) ? strtotime((string) $ligne['date_resolution']) : false;
                        $urlDossierTicket = 'detail-demande.php?entreprise_id=' . (int) $entrepriseId . '&id=' . (int) $ligne['demande_id'];
                    ?>
                        <article class="b2b-sav-card" data-ticket-sav data-ticket-status="<?= $e($statutTicket) ?>">
                            <div class="b2b-sav-card__top">
                                <div><span class="b2b-eyebrow">TICKET SAV</span><strong>#<?= (int) $ligne['id'] ?></strong></div>
                                <span class="b2b-status b2b-status--<?= $e($classeStatutTicket) ?>"><?= $e($libelleStatutTicket) ?></span>
                            </div>
                            <p class="b2b-sav-card__motif"><?= $e($ligne['motif']) ?></p>
                            <div class="b2b-sav-card__dossier"><span><?= icone('folder', 15) ?></span><div><small>Dossier d’intervention</small><strong><?= $e($ligne['numero_dossier']) ?></strong></div><span class="b2b-sav-card__site"><?= icone('pin', 14) ?><?= $e($ligne['site_nom']) ?></span></div>
                            <div class="b2b-sav-card__footer">
                                <span><?= icone('calendar', 14) ?>Ouvert le <?= $dateTicket !== false ? $e(date('d/m/Y', $dateTicket)) : '—' ?><?php if ($dateResolutionTicket !== false): ?><span class="b2b-sav-card__resolution"> · Résolu le <?= $e(date('d/m/Y', $dateResolutionTicket)) ?></span><?php endif; ?></span>
                                <a href="<?= $e($urlDossierTicket) ?>" aria-label="Consulter le dossier <?= $e($ligne['numero_dossier']) ?>">Consulter le dossier <?= icone('arrow', 14) ?></a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <p id="tickets-sav-sans-resultat" class="b2b-sav-no-results" hidden>Aucun ticket ne correspond à votre recherche ou au statut choisi.</p>
            <?php endif; ?>
        </section>
    <?php elseif ($module === 'interventions' || $module === 'historique'): ?>
        <?php
        $interventionsPlanifiees = count(array_filter($lignes, static fn(array $intervention): bool => !empty($intervention['date_creneau_planifie'])));
        $interventionsSansAffectation = count(array_filter($lignes, static fn(array $intervention): bool => empty($intervention['technicien_nom']) && empty($intervention['partenaire_nom'])));
        $libellesStatutIntervention = [
            'en_attente' => 'En attente',
            'attribuee' => 'Attribuée',
            'en_route' => 'En route',
            'arrive' => 'Arrivé sur place',
            'diagnostic' => 'Diagnostic',
            'en_cours' => 'En cours',
            'terminee' => 'Terminée',
            'annulee' => 'Annulée',
            'refusee' => 'Refusée',
        ];
        ?>
        <section class="b2b-operation-overview" aria-label="Résumé des interventions">
            <div class="b2b-operation-overview__intro"><span aria-hidden="true"><?= icone($module === 'historique' ? 'refresh' : 'wrench', 20) ?></span><div><strong><?= count($lignes) ?></strong><small><?= $module === 'historique' ? 'intervention' : 'intervention active' ?><?= count($lignes) === 1 ? '' : 's' ?></small></div></div>
            <span class="b2b-operation-overview__divider" aria-hidden="true"></span>
            <div><strong><?= $interventionsPlanifiees ?></strong><small>Créneau<?= $interventionsPlanifiees === 1 ? '' : 'x' ?> planifié<?= $interventionsPlanifiees === 1 ? '' : 's' ?></small></div>
            <?php if ($module === 'interventions'): ?><div><strong><?= $interventionsSansAffectation ?></strong><small>En attente d’affectation</small></div><?php endif; ?>
        </section>
        <section class="b2b-panel b2b-operations-panel" aria-labelledby="operations-liste-titre">
            <div class="b2b-operations-panel__heading"><div><span class="b2b-eyebrow"><?= $module === 'historique' ? 'MISSIONS CLÔTURÉES' : 'SUIVI EN COURS' ?></span><h2 id="operations-liste-titre"><?= $module === 'historique' ? 'Interventions terminées' : 'Interventions actives' ?></h2><p><?= $module === 'historique' ? 'Retrouvez les missions terminées sur tous les sites de votre entreprise.' : 'Suivez l’affectation, les créneaux et la progression des missions.' ?></p></div></div>
            <?php if (!$lignes): ?>
                <div class="b2b-operations-empty"><span aria-hidden="true"><?= icone($module === 'historique' ? 'refresh' : 'wrench', 22) ?></span><strong><?= $module === 'historique' ? 'Aucune intervention terminée' : 'Aucune intervention active' ?></strong><p><?= $module === 'historique' ? 'Les missions clôturées apparaîtront ici après leur achèvement.' : 'Les nouvelles missions apparaîtront ici dès leur création. Vous pourrez suivre leur affectation et leur créneau.' ?></p><?php if ($module === 'interventions' && $entrepriseAutorisePermission('demandes')): ?><a class="b2b-button" href="nouvelle-demande.php?entreprise_id=<?= (int) $entrepriseId ?>"><?= icone('plus', 15) ?> Nouvelle demande</a><?php endif; ?></div>
            <?php else: ?>
                <label class="b2b-module-search" for="recherche-interventions"><?= icone('search', 16) ?><span class="b2b-visually-hidden">Rechercher une intervention</span><input id="recherche-interventions" type="search" placeholder="Dossier, site, service, intervenant…" autocomplete="off"></label>
                <div class="b2b-operation-cards">
                    <?php foreach ($lignes as $ligne):
                        $statutIntervention = strtolower((string) $ligne['statut']);
                        $classeStatutIntervention = (string) preg_replace('/[^a-z0-9_-]/', '', $statutIntervention);
                        $dateIntervention = strtotime((string) ($ligne['date_debut'] ?: $ligne['date_creation']));
                        $urlIntervention = 'detail-demande.php?entreprise_id=' . (int) $entrepriseId . '&id=' . (int) $ligne['demande_id'];
                    ?>
                        <article class="b2b-operation-card" data-module-operation>
                            <div class="b2b-operation-card__top"><div><span class="b2b-eyebrow">DOSSIER</span><strong><?= $e($ligne['numero_dossier']) ?></strong></div><span class="b2b-status b2b-status--<?= $e($classeStatutIntervention) ?>"><?= $e($libellesStatutIntervention[$statutIntervention] ?? ucfirst(str_replace('_', ' ', $statutIntervention))) ?></span></div>
                            <div class="b2b-operation-card__service"><span aria-hidden="true"><?= icone('wrench', 16) ?></span><div><strong><?= $e($ligne['categorie_nom']) ?></strong><small><?= $e($ligne['site_nom']) ?></small></div></div>
                            <div class="b2b-operation-card__details"><span><small>Intervenant</small><strong><?= $e($ligne['technicien_nom'] ?: ($ligne['partenaire_nom'] ?: 'En attente d’affectation')) ?></strong></span><span><small>Créneau prévu</small><strong><?= $ligne['date_creneau_planifie'] ? $e(date('d/m/Y', strtotime($ligne['date_creneau_planifie'])) . ' · ' . sprintf('%02d:00', (int) $ligne['heure_creneau_planifie'])) : 'À confirmer' ?></strong></span></div>
                            <div class="b2b-operation-card__progress">
                                <?php if (!empty($ligne['date_decision_technicien'])): ?><span><?= icone('check', 13) ?>Technicien confirmé · <?= $e(date('d/m H:i', strtotime($ligne['date_decision_technicien']))) ?></span><?php endif; ?>
                                <?php if (!empty($ligne['date_debut'])): ?><span><?= icone('clock', 13) ?>Intervention démarrée · <?= $e(date('d/m H:i', strtotime($ligne['date_debut']))) ?></span><?php endif; ?>
                                <?php if (!empty($ligne['date_fin'])): ?><span><?= icone('check', 13) ?>Mission terminée · <?= $e(date('d/m H:i', strtotime($ligne['date_fin']))) ?></span><?php endif; ?>
                                <?php if (empty($ligne['date_decision_technicien']) && empty($ligne['date_debut']) && empty($ligne['date_fin'])): ?><span><?= icone('info', 13) ?>Dernière mise à jour · <?= $dateIntervention !== false ? $e(date('d/m/Y', $dateIntervention)) : '—' ?></span><?php endif; ?>
                            </div>
                            <a class="b2b-operation-card__link" href="<?= $e($urlIntervention) ?>">Voir le suivi du dossier <?= icone('arrow', 14) ?></a>
                        </article>
                    <?php endforeach; ?>
                </div>
                <p id="interventions-sans-resultat" class="b2b-module-no-results" hidden>Aucune intervention ne correspond à votre recherche.</p>
            <?php endif; ?>
        </section>
    <?php elseif ($module === 'contrats'): ?>
        <?php
        $contratsActifs = count(array_filter($lignes, static fn(array $contrat): bool => $libelleEtatContrat($contrat) === 'Actif'));
        $creditsDisponiblesTotal = array_sum(array_map(static fn(array $contrat): int => (int) $contrat['credits_disponibles'], $lignes));
        $soldeContrats = array_sum(array_map(static fn(array $contrat): float => (float) $contrat['solde'], $lignes));
        ?>
        <section class="b2b-module-overview" aria-label="Résumé des contrats">
            <div class="b2b-module-overview__intro"><span aria-hidden="true"><?= icone('shield', 20) ?></span><div><strong><?= count($lignes) ?></strong><small>contrat<?= count($lignes) === 1 ? '' : 's' ?></small></div></div>
            <span class="b2b-module-overview__divider" aria-hidden="true"></span>
            <div><strong><?= $contratsActifs ?></strong><small>Actif<?= $contratsActifs === 1 ? '' : 's' ?></small></div>
            <div><strong><?= $creditsDisponiblesTotal ?></strong><small>Crédit<?= $creditsDisponiblesTotal === 1 ? '' : 's' ?> disponible<?= $creditsDisponiblesTotal === 1 ? '' : 's' ?></small></div>
            <div><strong><?= number_format($soldeContrats, 0, ',', ' ') ?> FCFA</strong><small>Solde contractuel</small></div>
        </section>
        <section class="b2b-panel">
            <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">COUVERTURE CONTRACTUELLE</span><h2>Contrats et SLA</h2><p>Les interventions B2B sont prises en charge par vos crédits, sans paiement individuel à la clôture.</p></div></div>
            <?php if (!$lignes): ?><div class="b2b-empty">Aucun contrat n’est associé à cette entreprise. <?php if ($entrepriseAutorisePermission('devis')): ?><a href="gestion.php?entreprise_id=<?= $entrepriseId ?>&amp;module=devis">Demandez un devis pour mettre en place votre couverture B2B.</a><?php else: ?>Demandez à un administrateur d’envoyer une demande de devis.<?php endif; ?></div>
            <?php else: ?><div class="b2b-contract-cards"><?php foreach ($lignes as $ligne): ?>
                <article class="b2b-contract-card">
                    <header><div><span class="b2b-eyebrow">CONTRAT #<?= (int) $ligne['id'] ?></span><h3><?= $e($libelleEtatContrat($ligne)) ?></h3></div><span class="b2b-status b2b-status--<?= $ligne['statut'] === 'actif' ? 'acceptee' : 'annulee' ?>"><?= $e($libelleEtatContrat($ligne)) ?></span></header>
                    <p class="b2b-contract-card__period"><?= $e(date('d/m/Y', strtotime($ligne['date_debut']))) ?> — <?= $e(date('d/m/Y', strtotime($ligne['date_fin']))) ?></p>
                    <?php $creditsUtilisesContrat = (int) $ligne['credits_utilises']; $creditsReservesContrat = (int) $ligne['credits_reserves']; $volumeCreditsContrat = max(0, (int) $ligne['volume_credits']); $progressionCreditsContrat = $volumeCreditsContrat > 0 ? min(100, (int) round(($creditsUtilisesContrat + $creditsReservesContrat) / $volumeCreditsContrat * 100)) : 0; ?>
                    <div class="b2b-credit-meter"><span><strong><?= $creditsUtilisesContrat ?></strong> consommé<?= $creditsUtilisesContrat === 1 ? '' : 's' ?> · <strong><?= $creditsReservesContrat ?></strong> réservé<?= $creditsReservesContrat === 1 ? '' : 's' ?></span><strong><?= (int) $ligne['credits_disponibles'] ?> disponible<?= (int) $ligne['credits_disponibles'] === 1 ? '' : 's' ?> / <?= $volumeCreditsContrat ?></strong></div>
                    <div class="b2b-contract-credits-progress" role="progressbar" aria-label="Utilisation des crédits du contrat #<?= (int) $ligne['id'] ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= $progressionCreditsContrat ?>"><span style="width: <?= $progressionCreditsContrat ?>%"></span></div>
                    <div class="b2b-contract-card__slas"><span>Urgent<strong><?= (int) ceil((int) $ligne['sla_urgent_minutes'] / 60) ?> h</strong></span><span>Normal<strong><?= (int) ceil((int) $ligne['sla_normal_minutes'] / 60) ?> h</strong></span><span>Montant contractuel<strong><?= number_format((float) $ligne['montant_total'], 0, ',', ' ') ?> FCFA</strong></span><span>Réglé<strong><?= number_format((float) $ligne['montant_regle'], 0, ',', ' ') ?> FCFA</strong></span><span>Solde<strong><?= number_format((float) $ligne['solde'], 0, ',', ' ') ?> FCFA</strong></span></div>
                    <?php if ($ligne['conditions']): ?><details class="b2b-contract-conditions"><summary>Conditions du contrat</summary><p><?= nl2br($e($ligne['conditions'])) ?></p></details><?php endif; ?>
                    <?php if ((int) $ligne['credits_disponibles'] === 0 && $libelleEtatContrat($ligne) === 'Actif'): ?><p class="b2b-contract-card__notice">Tous les crédits sont consommés ou réservés. Demandez un renouvellement ou un devis.</p><?php endif; ?>
                </article>
            <?php endforeach; ?></div><?php endif; ?>
        </section>
    <?php elseif ($module === 'devis'): ?>
        <?php
        $exemplesDescriptionDevis = [
            'Ex. : entretien de 5 climatiseurs sur le site de Dakar-Plateau, une fois par trimestre.',
            'Ex. : maintenance préventive de 12 ordinateurs dans nos bureaux de Sacré-Cœur.',
            'Ex. : installation de 8 caméras de surveillance sur notre site de Rufisque.',
            'Ex. : réparation de la plomberie des sanitaires de notre agence des Almadies.',
            'Ex. : contrôle et entretien de 3 groupes électrogènes, avec intervention mensuelle.',
            'Ex. : câblage réseau et installation de prises dans 4 salles de notre siège.',
            'Ex. : nettoyage et entretien de 6 climatiseurs avant la saison chaude.',
        ];
        $exempleDescriptionDevis = $exemplesDescriptionDevis[random_int(0, count($exemplesDescriptionDevis) - 1)];
        $devisARepondre = count(array_filter(
            $lignes,
            static fn(array $ligne): bool => $ligne['statut'] === 'emis'
                && (!$ligne['date_validite'] || $ligne['date_validite'] >= date('Y-m-d'))
        ));
        $devisEnCours = count(array_filter($lignes, static fn(array $ligne): bool => in_array($ligne['statut'], ['demande', 'emis'], true)));
        $devisAcceptes = count(array_filter($lignes, static fn(array $ligne): bool => $ligne['statut'] === 'accepte'));
        $libellesStatutDevis = [
            'demande' => 'En préparation',
            'emis' => 'À votre décision',
            'accepte' => 'Accepté',
            'refuse' => 'Refusé',
            'expire' => 'Expiré',
        ];
        ?>
        <section class="b2b-quotes-overview" aria-label="Résumé des devis">
            <div class="b2b-quotes-overview__intro">
                <span class="b2b-quotes-overview__icon" aria-hidden="true"><?= icone('file-text', 22) ?></span>
                <span><strong><?= count($lignes) ?></strong><small>devis au total</small></span>
            </div>
            <span class="b2b-quotes-overview__divider" aria-hidden="true"></span>
            <div class="b2b-quotes-overview__metric"><strong><?= $devisARepondre ?></strong><span>À votre décision</span></div>
            <div class="b2b-quotes-overview__metric"><strong><?= $devisEnCours ?></strong><span>En cours</span></div>
            <div class="b2b-quotes-overview__metric"><strong><?= $devisAcceptes ?></strong><span>Acceptés</span></div>
        </section>
        <section class="b2b-quotes-request" aria-labelledby="demander-devis-titre">
            <div class="b2b-quotes-request__intro">
                <span class="b2b-eyebrow">UN PROJET À CHIFFRER ?</span>
                <h2 id="demander-devis-titre">Parlons de votre besoin.</h2>
                <p>Décrivez votre projet. L’équipe ALLÔ PRO vous transmettra une proposition directement dans cet espace.</p>
                <div class="b2b-quotes-request__note"><?= icone('check', 15) ?><span>Vous pourrez consulter le montant, les conditions et la validité avant de répondre.</span></div>
            </div>
            <form method="post" class="b2b-form b2b-quotes-request__form">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                <input type="hidden" name="action" value="demander">
                <label for="recherche-dossier-devis">Associer à un dossier existant <span class="b2b-quotes-field-optional">Facultatif</span>
                    <input id="recherche-dossier-devis" type="search" placeholder="Rechercher par référence ou site" autocomplete="off">
                    <select id="devis-demande-id" name="demande_id"><option value="">Aucun dossier associé</option><?php foreach ($demandesPourDevis as $demande): ?><option value="<?= (int) $demande['id'] ?>"><?= $e($demande['numero_dossier'] . ' — ' . $demande['site_nom']) ?></option><?php endforeach; ?></select>
                </label>
                <label for="description-demande-devis">Décrivez votre besoin
                    <textarea id="description-demande-devis" name="description" maxlength="3000" placeholder="<?= $e($exempleDescriptionDevis) ?>" required><?= $e($_POST['description'] ?? '') ?></textarea>
                    <span class="b2b-quotes-field-hint">Précisez les quantités, le site et le résultat souhaité.</span>
                </label>
                <div class="b2b-quotes-request__submit">
                    <span>Votre demande sera transmise à notre équipe.</span>
                    <button class="b2b-button" type="submit"><?= icone('send', 16) ?> Envoyer ma demande</button>
                </div>
            </form>
        </section>
        <section class="b2b-panel b2b-quotes-list" aria-labelledby="devis-transmis-titre">
            <div class="b2b-quotes-list__heading">
                <div><span class="b2b-eyebrow">SUIVI COMMERCIAL</span><h2 id="devis-transmis-titre">Vos devis</h2><p>Retrouvez ici vos demandes de chiffrage et les propositions reçues.</p></div>
                <?php if ($lignes): ?>
                    <div class="b2b-quotes-list__filters">
                        <label class="b2b-search-label b2b-quotes-search" for="recherche-devis-envoye"><span class="b2b-visually-hidden">Rechercher dans les devis</span><input id="recherche-devis-envoye" type="search" placeholder="Référence, dossier, objet…" autocomplete="off"></label>
                        <label class="b2b-visually-hidden" for="filtre-statut-devis">Filtrer par statut</label>
                        <select id="filtre-statut-devis" class="b2b-quotes-status-filter">
                            <option value="">Tous les statuts</option>
                            <option value="demande">En préparation</option>
                            <option value="emis">À votre décision</option>
                            <option value="accepte">Acceptés</option>
                            <option value="refuse">Refusés</option>
                            <option value="expire">Expirés</option>
                        </select>
                    </div>
                <?php endif; ?>
            </div>
            <?php if (!$lignes): ?>
                <div class="b2b-quotes-empty"><span aria-hidden="true"><?= icone('file-text', 22) ?></span><strong>Votre premier devis commence ici</strong><p>Envoyez une demande de chiffrage. Elle et les propositions reçues apparaîtront dans cette liste.</p></div>
            <?php else: ?>
                <div class="b2b-quotes-cards">
                    <?php foreach ($lignes as $ligne):
                        $urlDetailDevis = 'detail-devis.php?entreprise_id=' . $entrepriseId . '&id=' . (int) $ligne['id'];
                        $numeroDevis = $ligne['numero'] ?: ('Devis #' . (int) $ligne['id']);
                        $statutDevis = (string) $ligne['statut'];
                        $dateCreationDevis = strtotime((string) $ligne['date_creation']);
                        $dateValiditeDevis = !empty($ligne['date_validite']) ? strtotime((string) $ligne['date_validite']) : false;
                        $devisRepondable = $statutDevis === 'emis' && (!$ligne['date_validite'] || $ligne['date_validite'] >= date('Y-m-d'));
                    ?>
                        <article class="b2b-quote-card" data-devis-row data-devis-status="<?= $e($statutDevis) ?>">
                            <div class="b2b-quote-card__top">
                                <div><span class="b2b-eyebrow">RÉFÉRENCE</span><a class="b2b-quote-card__number" href="<?= $e($urlDetailDevis) ?>"><?= $e($numeroDevis) ?></a></div>
                                <span class="b2b-status b2b-status--<?= $e($statutDevis) ?>"><?= $e($libellesStatutDevis[$statutDevis] ?? ucfirst(str_replace('_', ' ', $statutDevis))) ?></span>
                            </div>
                            <p class="b2b-quote-card__description"><?= $e($ligne['description']) ?></p>
                            <?php if (!empty($ligne['details'])): ?><p class="b2b-quote-card__details"><?= nl2br($e($ligne['details'])) ?></p><?php endif; ?>
                            <div class="b2b-quote-card__facts">
                                <span><small>Dossier associé</small><strong><?= $e($ligne['numero_dossier'] ?: 'Aucun') ?></strong></span>
                                <span><small>Montant proposé</small><strong><?= $ligne['montant'] === null ? 'En cours de chiffrage' : number_format((float) $ligne['montant'], 0, ',', ' ') . ' FCFA' ?></strong></span>
                                <span><small><?= $ligne['date_validite'] ? 'Valide jusqu’au' : 'Demande envoyée' ?></small><strong><?= $dateValiditeDevis !== false ? $e(date('d/m/Y', $dateValiditeDevis)) : ($dateCreationDevis !== false ? $e(date('d/m/Y', $dateCreationDevis)) : '—') ?></strong></span>
                            </div>
                            <div class="b2b-quote-card__footer">
                                <?php if ($devisRepondable): ?>
                                    <form method="post" class="b2b-quote-card__decision" data-confirm-devis>
                                        <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                                        <input type="hidden" name="action" value="repondre">
                                        <input type="hidden" name="devis_id" value="<?= (int) $ligne['id'] ?>">
                                        <button class="b2b-button" name="reponse" value="accepte" type="submit"><?= icone('check', 14) ?> Accepter</button>
                                        <button class="b2b-button b2b-button--secondary" name="reponse" value="refuse" type="submit">Refuser</button>
                                    </form>
                                <?php else: ?>
                                    <span class="b2b-quote-card__date"><?= $dateCreationDevis !== false ? 'Créé le ' . $e(date('d/m/Y', $dateCreationDevis)) : '' ?></span>
                                <?php endif; ?>
                                <a class="b2b-quote-card__open" href="<?= $e($urlDetailDevis) ?>">Consulter le devis <?= icone('arrow', 14) ?></a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <p id="devis-recherche-vide" class="b2b-quotes-no-results" hidden>Aucun devis ne correspond à votre recherche.</p>
            <?php endif; ?>
        </section>
    <?php elseif ($module === 'factures'): ?>
        <?php $montantFactures = array_sum(array_map(static fn(array $facture): float => (float) $facture['montant'], $lignes)); ?>
        <section class="b2b-module-overview" aria-label="Résumé des factures"><div class="b2b-module-overview__intro"><span aria-hidden="true"><?= icone('receipt', 20) ?></span><div><strong><?= count($lignes) ?></strong><small>facture<?= count($lignes) === 1 ? '' : 's' ?></small></div></div><span class="b2b-module-overview__divider" aria-hidden="true"></span><div><strong><?= number_format($montantFactures, 0, ',', ' ') ?> FCFA</strong><small>Montant cumulé</small></div><div><strong>Interventions</strong><small>Facturation directe</small></div></section>
        <section class="b2b-panel b2b-finance-panel" aria-labelledby="factures-titre">
            <div class="b2b-finance-panel__heading"><div><span class="b2b-eyebrow">DOCUMENTS COMPTABLES</span><h2 id="factures-titre">Factures d’intervention</h2><p>Téléchargez les factures émises pour les interventions de votre entreprise.</p></div><?php if ($lignes): ?><label class="b2b-module-search" for="recherche-factures"><?= icone('search', 16) ?><span class="b2b-visually-hidden">Rechercher une facture</span><input id="recherche-factures" type="search" placeholder="Facture, dossier, site…" autocomplete="off"></label><?php endif; ?></div>
            <?php if (!$lignes): ?><div class="b2b-finance-empty"><span aria-hidden="true"><?= icone('receipt', 21) ?></span><strong>Aucune facture disponible</strong><p>Les factures d’intervention apparaîtront ici après leur émission.</p></div>
            <?php else: ?><div class="b2b-finance-cards">
                <?php foreach ($lignes as $ligne): $dateFacture = strtotime((string) $ligne['date_emission']); ?>
                    <article class="b2b-finance-card" data-module-facture>
                        <div class="b2b-finance-card__top"><span aria-hidden="true"><?= icone('receipt', 18) ?></span><div><small>FACTURE</small><strong><?= $e($ligne['numero']) ?></strong></div><span class="b2b-status b2b-status--acceptee">Émise</span></div>
                        <div class="b2b-finance-card__reference"><span>Dossier <strong><?= $e($ligne['numero_dossier']) ?></strong></span><span><?= $e($ligne['site_nom']) ?></span></div>
                        <div class="b2b-finance-card__amount"><small>Montant facturé</small><strong><?= number_format((float) $ligne['montant'], 0, ',', ' ') ?> <?= $e($ligne['devise']) ?></strong></div>
                        <div class="b2b-finance-card__footer"><span><?= icone('calendar', 14) ?>Émise le <?= $dateFacture !== false ? $e(date('d/m/Y', $dateFacture)) : '—' ?></span><a href="telecharger-facture.php?entreprise_id=<?= (int) $entrepriseId ?>&amp;id=<?= (int) $ligne['id'] ?>"><?= icone('download', 14) ?> Télécharger</a></div>
                    </article>
                <?php endforeach; ?>
            </div><p id="factures-sans-resultat" class="b2b-module-no-results" hidden>Aucune facture ne correspond à votre recherche.</p><?php endif; ?>
        </section>
    <?php elseif ($module === 'paiements'): ?>
        <?php
        $montantPaiementsContrat = array_sum(array_map(static fn(array $paiement): float => (float) $paiement['montant'], $paiementsContrat));
        $montantPaiementsDirects = array_sum(array_map(static fn(array $paiement): float => (float) $paiement['montant'], $lignes));
        ?>
        <section class="b2b-module-overview" aria-label="Résumé des paiements">
            <div class="b2b-module-overview__intro"><span aria-hidden="true"><?= icone('wallet', 20) ?></span><div><strong><?= count($paiementsContrat) + count($lignes) ?></strong><small>règlement<?= count($paiementsContrat) + count($lignes) === 1 ? '' : 's' ?></small></div></div>
            <span class="b2b-module-overview__divider" aria-hidden="true"></span>
            <div><strong><?= number_format($montantPaiementsContrat, 0, ',', ' ') ?> FCFA</strong><small>Contrats B2B</small></div>
            <div><strong><?= number_format($montantPaiementsDirects, 0, ',', ' ') ?> FCFA</strong><small>Interventions directes</small></div>
        </section>
        <section class="b2b-panel b2b-finance-panel" aria-labelledby="paiements-contrat-titre">
            <div class="b2b-finance-panel__heading"><div><span class="b2b-eyebrow">COUVERTURE B2B</span><h2 id="paiements-contrat-titre">Règlements de contrat</h2><p>Paiements liés à vos contrats et à leurs crédits d’intervention.</p></div><span class="b2b-finance-panel__count"><?= count($paiementsContrat) ?> règlement<?= count($paiementsContrat) === 1 ? '' : 's' ?></span></div>
            <?php if (!$paiementsContrat): ?><div class="b2b-finance-empty b2b-finance-empty--compact"><span aria-hidden="true"><?= icone('wallet', 19) ?></span><strong>Aucun règlement de contrat enregistré</strong><p>Les règlements de contrat apparaîtront ici dès leur enregistrement.</p></div>
            <?php else: ?><div class="b2b-payment-list"><?php foreach ($paiementsContrat as $paiement): $datePaiementContrat = strtotime((string) $paiement['date_paiement']); ?>
                <article class="b2b-payment-row"><span class="b2b-payment-row__icon" aria-hidden="true"><?= icone('shield', 17) ?></span><div class="b2b-payment-row__main"><strong>Contrat #<?= (int) $paiement['contrat_id'] ?></strong><small><?= $e(ucfirst(str_replace('_', ' ', $paiement['methode']))) ?> · Réf. <?= $e($paiement['reference_transaction'] ?: '—') ?></small></div><span class="b2b-payment-row__date"><?= $datePaiementContrat !== false ? $e(date('d/m/Y', $datePaiementContrat)) : '—' ?></span><strong class="b2b-payment-row__amount"><?= number_format((float) $paiement['montant'], 0, ',', ' ') ?> FCFA</strong></article>
            <?php endforeach; ?></div><?php endif; ?>
        </section>
        <section class="b2b-panel b2b-finance-panel" aria-labelledby="paiements-directs-titre">
            <div class="b2b-finance-panel__heading"><div><span class="b2b-eyebrow">RÈGLEMENT PAR DOSSIER</span><h2 id="paiements-directs-titre">Paiements directs par intervention</h2><p>Transactions associées aux interventions facturées directement.</p></div><span class="b2b-finance-panel__count"><?= count($lignes) ?> paiement<?= count($lignes) === 1 ? '' : 's' ?></span></div>
            <?php if (!$lignes): ?><div class="b2b-finance-empty b2b-finance-empty--compact"><span aria-hidden="true"><?= icone('card', 19) ?></span><strong>Aucun paiement direct enregistré</strong><p>Aucun paiement individuel n’est associé aux interventions de votre entreprise.</p></div>
            <?php else: ?><div class="b2b-payment-list"><?php foreach ($lignes as $paiement): $datePaiementDirect = strtotime((string) $paiement['date_paiement']); $statutPaiement = strtolower((string) $paiement['statut']); ?>
                <article class="b2b-payment-row"><span class="b2b-payment-row__icon b2b-payment-row__icon--direct" aria-hidden="true"><?= icone('card', 17) ?></span><div class="b2b-payment-row__main"><strong><?= $e($paiement['numero_dossier']) ?> · <?= $e($paiement['site_nom']) ?></strong><small><?= $e(ucfirst(str_replace('_', ' ', $paiement['methode']))) ?> · Réf. <?= $e($paiement['reference_transaction'] ?: '—') ?></small></div><span class="b2b-status b2b-status--<?= $e((string) preg_replace('/[^a-z0-9_-]/', '', $statutPaiement)) ?>"><?= $e(ucfirst(str_replace('_', ' ', $statutPaiement))) ?></span><span class="b2b-payment-row__date"><?= $datePaiementDirect !== false ? $e(date('d/m/Y', $datePaiementDirect)) : '—' ?></span><strong class="b2b-payment-row__amount"><?= number_format((float) $paiement['montant'], 0, ',', ' ') ?> FCFA</strong></article>
            <?php endforeach; ?></div><?php endif; ?>
        </section>
    <?php elseif ($module === 'rapports'): ?>
        <?php $totalDemandesRapport = (int) ($resume['demandes'] ?? 0); $tauxTermineesRapport = $totalDemandesRapport > 0 ? min(100, (int) round((int) ($resume['terminees'] ?? 0) / $totalDemandesRapport * 100)) : 0; ?>
        <section class="b2b-stats b2b-report-stats">
            <article class="b2b-stat b2b-report-stat"><span>Total des demandes</span><strong><?= $totalDemandesRapport ?></strong><small>Tous les sites de l’entreprise</small></article>
            <article class="b2b-stat b2b-report-stat b2b-report-stat--success"><span>Demandes terminées</span><strong><?= (int) ($resume['terminees'] ?? 0) ?></strong><small><?= $tauxTermineesRapport ?> % du total</small></article>
            <article class="b2b-stat b2b-report-stat b2b-report-stat--muted"><span>Demandes annulées</span><strong><?= (int) ($resume['annulees'] ?? 0) ?></strong><small>Suivi de l’activité</small></article>
            <article class="b2b-stat b2b-report-stat b2b-report-stat--orange"><span>Dossiers avec SAV</span><strong><?= (int) ($resume['dossiers_sav'] ?? 0) ?></strong><small>Suivi après intervention</small></article>
        </section>
        <section class="b2b-panel b2b-report-panel">
            <div class="b2b-finance-panel__heading"><div><span class="b2b-eyebrow">ACTIVITÉ OPÉRATIONNELLE</span><h2>Activité par dossier</h2><p>Accédez au détail de chaque demande comptabilisée dans ce rapport.</p></div><?php if ($lignes): ?><label class="b2b-module-search" for="recherche-rapport"><?= icone('search', 16) ?><span class="b2b-visually-hidden">Rechercher un dossier</span><input id="recherche-rapport" type="search" placeholder="Dossier, site, catégorie…" autocomplete="off"></label><?php endif; ?></div>
            <?php if (!$lignes): ?><div class="b2b-finance-empty"><span aria-hidden="true"><?= icone('chart', 21) ?></span><strong>Aucune activité à rapporter</strong><p>Les indicateurs apparaîtront dès que des demandes seront créées pour votre entreprise.</p></div>
            <?php else: ?><div class="b2b-report-list"><?php foreach ($lignes as $ligne): $statutRapport = strtolower((string) $ligne['statut']); $dateRapport = strtotime((string) $ligne['date_creation']); $urlRapport = 'detail-demande.php?entreprise_id=' . (int) $entrepriseId . '&id=' . (int) $ligne['id']; ?>
                <a class="b2b-report-row" data-module-document href="<?= $e($urlRapport) ?>"><span class="b2b-report-row__icon" aria-hidden="true"><?= icone('clipboard', 17) ?></span><span class="b2b-report-row__main"><strong><?= $e($ligne['numero_dossier']) ?></strong><small><?= $e($ligne['site_nom']) ?> · <?= $e($ligne['categorie_nom']) ?></small></span><span class="b2b-report-row__urgency <?= $ligne['urgence'] === 'urgente' ? 'is-urgent' : '' ?>"><?= $ligne['urgence'] === 'urgente' ? 'Urgente' : 'Normale' ?></span><span class="b2b-status b2b-status--<?= $e((string) preg_replace('/[^a-z0-9_-]/', '', $statutRapport)) ?>"><?= $e(ucfirst(str_replace('_', ' ', $statutRapport))) ?></span><span class="b2b-report-row__date"><?= $dateRapport !== false ? $e(date('d/m/Y', $dateRapport)) : '—' ?></span><span class="b2b-report-row__open"><?= icone('arrow', 14) ?></span></a>
            <?php endforeach; ?></div><p id="rapport-sans-resultat" class="b2b-module-no-results" hidden>Aucun dossier ne correspond à votre recherche.</p><?php endif; ?>
        </section>
    <?php elseif ($module === 'documents'): ?>
        <section class="b2b-module-overview" aria-label="Résumé des documents"><div class="b2b-module-overview__intro"><span aria-hidden="true"><?= icone('folder', 20) ?></span><div><strong><?= count($lignes) ?></strong><small>document<?= count($lignes) === 1 ? '' : 's' ?></small></div></div><span class="b2b-module-overview__divider" aria-hidden="true"></span><div><strong>Interventions</strong><small>Pièces jointes disponibles</small></div><div><strong>Accès sécurisé</strong><small>Téléchargement par dossier</small></div></section>
        <section class="b2b-panel b2b-finance-panel" aria-labelledby="documents-titre">
            <div class="b2b-finance-panel__heading"><div><span class="b2b-eyebrow">RESSOURCES DE L’ENTREPRISE</span><h2 id="documents-titre">Documents d’intervention</h2><p>Retrouvez et téléchargez les fichiers ajoutés au suivi des missions.</p></div><?php if ($lignes): ?><label class="b2b-module-search" for="recherche-documents"><?= icone('search', 16) ?><span class="b2b-visually-hidden">Rechercher un document</span><input id="recherche-documents" type="search" placeholder="Nom, dossier, site, type…" autocomplete="off"></label><?php endif; ?></div>
            <?php if (!$lignes): ?><div class="b2b-finance-empty"><span aria-hidden="true"><?= icone('folder', 21) ?></span><strong>Aucun document disponible</strong><p>Les documents ajoutés au suivi de vos interventions seront regroupés ici.</p></div>
            <?php else: ?><div class="b2b-document-cards"><?php foreach ($lignes as $ligne): $dateDocument = strtotime((string) $ligne['date_creation']); $extensionDocument = strtoupper(pathinfo((string) $ligne['nom_original'], PATHINFO_EXTENSION) ?: 'FICHIER'); ?>
                <article class="b2b-document-card" data-module-document><span class="b2b-document-card__icon" aria-hidden="true"><?= icone('file-text', 20) ?></span><div class="b2b-document-card__body"><span class="b2b-eyebrow"><?= $e($extensionDocument) ?> · <?= $e($ligne['mime_type']) ?></span><strong><?= $e($ligne['nom_original']) ?></strong><small><?= $e($ligne['numero_dossier']) ?> · <?= $e($ligne['site_nom']) ?></small></div><span class="b2b-document-card__date"><?= $dateDocument !== false ? $e(date('d/m/Y', $dateDocument)) : '—' ?></span><a href="telecharger-document.php?entreprise_id=<?= (int) $entrepriseId ?>&amp;id=<?= (int) $ligne['id'] ?>" aria-label="Télécharger <?= $e($ligne['nom_original']) ?>"><?= icone('download', 16) ?><span class="b2b-visually-hidden">Télécharger</span></a></article>
            <?php endforeach; ?></div><p id="documents-sans-resultat" class="b2b-module-no-results" hidden>Aucun document ne correspond à votre recherche.</p><?php endif; ?>
        </section>
    <?php elseif ($module === 'parametres'): ?>
        <section class="b2b-settings-layout">
            <aside class="b2b-settings-aside"><span class="b2b-settings-aside__icon" aria-hidden="true"><?= icone('building', 21) ?></span><span class="b2b-eyebrow">VOTRE ORGANISATION</span><h2><?= $e($entreprise['nom']) ?></h2><p>Ces coordonnées permettent à l’équipe ALLÔ PRO de joindre le bon interlocuteur pour le suivi de votre compte et de vos interventions.</p><div class="b2b-settings-aside__role"><span aria-hidden="true"><?= icone($estAdmin ? 'key' : 'shield', 15) ?></span><span><small>Votre rôle</small><strong><?= $estAdmin ? 'Administrateur' : 'Membre autorisé' ?></strong></span></div></aside>
            <section class="b2b-panel b2b-settings-panel" aria-labelledby="coordonnees-entreprise-titre">
                <div class="b2b-finance-panel__heading"><div><span class="b2b-eyebrow">INFORMATIONS DE CONTACT</span><h2 id="coordonnees-entreprise-titre">Coordonnées de l’entreprise</h2><p><?= $estAdmin ? 'Tenez les coordonnées de votre entreprise à jour.' : 'Ces informations sont consultables par les membres. Seul un administrateur peut les modifier.' ?></p></div><?php if ($estAdmin): ?><span class="b2b-settings-editable"><?= icone('pencil', 13) ?> Modifiable</span><?php endif; ?></div>
                <?php if (!$estAdmin): ?><div class="b2b-settings-readonly" role="note"><?= icone('info', 15) ?><span>Lecture seule — contactez un administrateur de votre entreprise pour demander une modification.</span></div><?php endif; ?>
                <form method="post" class="b2b-form b2b-settings-form"><input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                    <label for="param-entreprise-nom">Nom de l’entreprise<input id="param-entreprise-nom" name="nom" value="<?= $e($entreprise['nom']) ?>" maxlength="150" required <?= $estAdmin ? '' : 'readonly' ?>></label>
                    <label for="param-interlocuteur-nom">Nom de l’interlocuteur<input id="param-interlocuteur-nom" name="interlocuteur_nom" value="<?= $e($entreprise['interlocuteur_nom']) ?>" maxlength="100" required <?= $estAdmin ? '' : 'readonly' ?>></label>
                    <label for="param-interlocuteur-telephone">Téléphone de contact<input id="param-interlocuteur-telephone" name="interlocuteur_telephone" type="tel" value="<?= $e($entreprise['interlocuteur_telephone']) ?>" maxlength="20" <?= $estAdmin ? '' : 'readonly' ?>></label>
                    <label for="param-interlocuteur-email">E-mail de contact<input id="param-interlocuteur-email" name="interlocuteur_email" type="email" value="<?= $e($entreprise['interlocuteur_email']) ?>" maxlength="150" required <?= $estAdmin ? '' : 'readonly' ?>></label>
                    <?php if ($estAdmin): ?><div class="b2b-settings-form__footer"><span><?= icone('shield', 14) ?> Seuls les administrateurs peuvent enregistrer les changements.</span><button class="b2b-button" type="submit"><?= icone('check', 15) ?> Enregistrer les paramètres</button></div><?php endif; ?>
                </form>
            </section>
        </section>
    <?php endif; ?>
</main></div><script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script></body></html>
