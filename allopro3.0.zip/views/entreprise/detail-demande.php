<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';

$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$demandeId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$demande = $demandeId === false ? null : $entrepriseModele->getDemandeDetail($entrepriseId, (int) $demandeId);
if (!$demande) {
    http_response_code(404);
    exit('Ce dossier est introuvable dans votre entreprise.');
}
$nomDemandeur = trim((string) ($demande['demandeur_prenom'] ?? '') . ' ' . (string) ($demande['demandeur_nom'] ?? ''));

$documents = $entrepriseModele->getDocumentsDemande($entrepriseId, (int) $demandeId);
$statutsDemande = [
    'nouvelle' => 'Nouvelle demande',
    'attribuee' => 'Technicien attribué',
    'en_cours' => 'Intervention en cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$statutsMission = [
    'en_attente' => 'En attente de réponse du technicien',
    'acceptee' => 'Mission acceptée',
    'refusee' => 'Mission refusée, réaffectation à traiter',
    'en_route' => 'Technicien en route',
    'arrive' => 'Technicien arrivé sur place',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'Intervention en cours',
    'terminee' => 'Intervention terminée',
    'annulee' => 'Mission annulée',
];
$statutActuel = $demande['intervention_statut']
    ? ($statutsMission[$demande['intervention_statut']] ?? ucfirst(str_replace('_', ' ', $demande['intervention_statut'])))
    : ($statutsDemande[$demande['demande_statut']] ?? ucfirst(str_replace('_', ' ', $demande['demande_statut'])));
$annulee = $demande['demande_statut'] === 'annulee'
    || $demande['intervention_statut'] === 'annulee';
$refusee = $demande['intervention_statut'] === 'refusee';

$etapes = [
    ['titre' => 'Demande enregistrée', 'date' => $demande['date_creation'], 'description' => 'Votre dossier a été créé.'],
    ['titre' => 'Transmise à la coordination', 'date' => $demande['date_transmission'], 'description' => 'La demande est prise en charge par l’équipe de coordination.'],
    ['titre' => 'Mission confiée à un technicien', 'date' => $demande['intervention_id'] ? $demande['date_debut'] : null, 'description' => 'Un technicien a été sollicité pour cette intervention.'],
    ['titre' => 'Réponse du technicien', 'date' => $demande['date_decision_technicien'], 'description' => $demande['intervention_statut'] === 'refusee' ? 'Le technicien a décliné la mission.' : 'La mission a été acceptée par le technicien.'],
    ['titre' => 'En route', 'date' => null, 'description' => 'Le technicien se déplace vers le site.'],
    ['titre' => 'Arrivé sur le site', 'date' => null, 'description' => 'Le technicien est arrivé sur le lieu d’intervention.'],
    ['titre' => 'Diagnostic', 'date' => null, 'description' => 'Évaluation de la situation sur place.'],
    ['titre' => 'Intervention en cours', 'date' => null, 'description' => 'Les travaux sont en cours.'],
    ['titre' => 'Intervention terminée', 'date' => $demande['date_fin'], 'description' => 'La mission a été clôturée.'],
];
$indicesEtape = [
    'nouvelle' => $demande['date_transmission'] ? 1 : 0,
    'attribuee' => $demande['intervention_id'] ? 3 : 2,
    'en_cours' => 7,
    'terminee' => 8,
    'en_attente' => $demande['date_transmission'] ? 3 : 1,
    'acceptee' => 4,
    'refusee' => 3,
    'en_route' => 4,
    'arrive' => 5,
    'diagnostic' => 6,
    'en_cours' => 7,
    'terminee' => 8,
];
$etapeActive = $demande['intervention_statut']
    ? ($indicesEtape[$demande['intervention_statut']] ?? 2)
    : ($indicesEtape[$demande['demande_statut']] ?? 0);
$missionTerminee = $demande['demande_statut'] === 'terminee'
    || $demande['intervention_statut'] === 'terminee';
if ($demande['intervention_statut'] === 'acceptee' && $demande['date_decision_technicien']) {
    $etapes[3]['titre'] = 'Mission acceptée';
}
if ($refusee) {
    $etapes[3]['titre'] = 'Mission refusée';
}

$seuilSlaMinutes = $demande['urgence'] === 'urgente'
    ? $demande['sla_urgent_minutes']
    : $demande['sla_normal_minutes'];
$slaDepasse = $demande['date_transmission'] && $seuilSlaMinutes !== null
    && time() - strtotime($demande['date_transmission']) >= (int) $seuilSlaMinutes * 60
    && !$demande['intervention_id'];
$creneau = $demande['date_creneau_planifie'] ?: $demande['date_creneau_souhaite'];
$heureCreneau = $demande['date_creneau_planifie']
    ? $demande['heure_creneau_planifie']
    : $demande['heure_creneau_souhaitee'];
$creneauPlanifie = !empty($demande['date_creneau_planifie']);
$paiementStatuts = [
    'valide' => 'Payé',
    'en_attente' => 'En attente',
    'echoue' => 'Échec de paiement',
];
$retourUrl = 'demandes.php?entreprise_id=' . $entrepriseId;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dossier <?= $e($demande['numero_dossier']) ?> — <?= $e($entreprise['nom']) ?></title>
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
    <script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script>
</head>
<body>
<div class="b2b-app">
    <?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?>
    <main class="b2b-main">
        <a class="b2b-detail-back" href="<?= $e($retourUrl) ?>"><span aria-hidden="true">←</span> Toutes les demandes</a>
        <header class="b2b-detail-hero">
            <div>
                <span class="b2b-eyebrow">SUIVI DE VOTRE DEMANDE</span>
                <h1><?= $e($demande['numero_dossier']) ?></h1>
                <span class="badge-demande-entreprise">Demande venant d’une entreprise · <?= $e($entreprise['nom']) ?></span>
                <p><?= $e($demande['categorie_nom']) ?> <span aria-hidden="true">·</span> Créée le <?= $e(date('d/m/Y à H:i', strtotime($demande['date_creation']))) ?></p>
            </div>
            <span class="b2b-status b2b-status--<?= $e($demande['intervention_statut'] ?: $demande['demande_statut']) ?>"><?= $e($statutActuel) ?></span>
        </header>

        <?php if ($annulee || $refusee): ?>
            <div class="b2b-alert <?= $annulee ? '' : 'b2b-alert--warning' ?>" role="status">
                <?= $annulee ? 'Ce dossier a été annulé.' : 'Le technicien a refusé cette mission. Une réaffectation peut être en cours.' ?>
            </div>
        <?php endif; ?>

        <div class="b2b-detail-layout">
            <div class="b2b-detail-main">
                <section class="b2b-panel b2b-timeline-panel" aria-labelledby="progression-titre">
                    <div class="b2b-panel__heading">
                        <div><span class="b2b-eyebrow">EN TEMPS RÉEL</span><h2 id="progression-titre">État d’avancement</h2><p>Les horaires affichés correspondent aux événements enregistrés.</p></div>
                    </div>
                    <?php if ($annulee): ?>
                        <div class="b2b-cancelled-state"><span aria-hidden="true">!</span><div><strong>Dossier annulé</strong><p>Contactez votre interlocuteur ALLÔ PRO si vous souhaitez organiser une nouvelle intervention.</p></div></div>
                    <?php else: ?>
                        <ol class="b2b-timeline">
                            <?php foreach ($etapes as $index => $etape):
                                $terminee = $index < $etapeActive
                                    || ($index === $etapeActive && ($missionTerminee || ($refusee && $index === 3)));
                                $active = $index === $etapeActive && !$terminee;
                                $ignoree = $refusee && $index > 3;
                                if ($ignoree) continue;
                                $etatEtape = $terminee ? 'done' : ($active ? 'active' : 'upcoming');
                                $afficherEtape = $index === 0
                                    || !empty($etape['date'])
                                    || $index <= $etapeActive
                                    || $active;
                                if (!$afficherEtape) continue;
                            ?>
                                <li class="b2b-timeline__item b2b-timeline__item--<?= $etatEtape ?>">
                                    <span class="b2b-timeline__marker" aria-hidden="true"><?= $terminee ? '✓' : (string) ($index + 1) ?></span>
                                    <div class="b2b-timeline__content">
                                        <div class="b2b-timeline__title"><?= $e($etape['titre']) ?><?php if ($active): ?><span>Étape actuelle</span><?php endif; ?></div>
                                        <p><?= $e($etape['description']) ?></p>
                                        <?php if (!empty($etape['date'])): ?><time datetime="<?= $e(date(DATE_ATOM, strtotime($etape['date']))) ?>"><?= $e(date('d/m/Y à H:i', strtotime($etape['date']))) ?></time><?php elseif ($active): ?><small>En attente de la prochaine mise à jour</small><?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ol>
                    <?php endif; ?>
                </section>

                <section class="b2b-panel" aria-labelledby="demande-detail-titre">
                    <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">INFORMATIONS DU DOSSIER</span><h2 id="demande-detail-titre">Votre demande</h2></div></div>
                    <dl class="b2b-detail-list">
                        <div><dt>Catégorie</dt><dd><?= $e($demande['categorie_nom']) ?></dd></div>
                        <div><dt>Urgence</dt><dd><span class="b2b-urgency b2b-urgency--<?= $e($demande['urgence']) ?>"><?= $demande['urgence'] === 'urgente' ? 'Urgente' : 'Normale' ?></span></dd></div>
                        <div><dt>Demandé par</dt><dd><?= $e($nomDemandeur !== '' ? $nomDemandeur : 'Membre de l’entreprise') ?></dd></div>
                        <div><dt>Site</dt><dd><?= $e($demande['site_nom']) ?><small><?= $e(trim($demande['site_quartier'] . ', ' . $demande['site_ville'], ', ')) ?></small></dd></div>
                        <div><dt>Adresse détaillée</dt><dd><?= $e($demande['site_details'] ?: $demande['adresse_details'] ?: 'Aucun complément renseigné') ?><?php if ($demande['adresse_google']): ?><small><?= $e($demande['adresse_google']) ?></small><?php endif; ?></dd></div>
                        <div class="b2b-detail-list__wide"><dt>Description du besoin</dt><dd><?= nl2br($e($demande['description'])) ?></dd></div>
                        <?php if ($creneau): ?><div><dt><?= $creneauPlanifie ? 'Créneau planifié' : 'Créneau souhaité' ?></dt><dd><?= $e(date('d/m/Y', strtotime($creneau))) ?><?= $heureCreneau !== null ? ' · ' . sprintf('%02d:00–%02d:00', (int) $heureCreneau, ((int) $heureCreneau + 1) % 24) : '' ?><small><?= $creneauPlanifie ? 'Créneau confirmé par l’équipe' : 'Préférence à confirmer' ?></small></dd></div><?php endif; ?>
                    </dl>
                </section>

                <?php if ($demande['intervention_id']): ?>
                    <section class="b2b-panel" aria-labelledby="intervention-titre">
                        <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">ÉQUIPE SUR LE DOSSIER</span><h2 id="intervention-titre">Intervention</h2></div></div>
                        <dl class="b2b-detail-list">
                            <div><dt>Partenaire</dt><dd><?= $e($demande['partenaire_nom'] ?: 'En cours d’attribution') ?></dd></div>
                            <div><dt>Technicien</dt><dd><?= $e($demande['technicien_nom'] ?: 'À confirmer') ?></dd></div>
                            <?php if ($demande['date_debut']): ?><div><dt>Mission confiée le</dt><dd><?= $e(date('d/m/Y à H:i', strtotime($demande['date_debut']))) ?></dd></div><?php endif; ?>
                            <?php if ($demande['date_decision_technicien']): ?><div><dt>Réponse du technicien</dt><dd><?= $e(date('d/m/Y à H:i', strtotime($demande['date_decision_technicien']))) ?></dd></div><?php endif; ?>
                            <?php if ($demande['date_fin']): ?><div><dt>Clôturée le</dt><dd><?= $e(date('d/m/Y à H:i', strtotime($demande['date_fin']))) ?></dd></div><?php endif; ?>
                            <?php if ($demande['rapport']): ?><div class="b2b-detail-list__wide"><dt>Compte rendu</dt><dd><?= nl2br($e($demande['rapport'])) ?></dd></div><?php endif; ?>
                        </dl>
                    </section>
                <?php endif; ?>

                <?php if ($documents && $entrepriseAutorisePermission('documents')): ?>
                    <section class="b2b-panel" aria-labelledby="documents-dossier-titre">
                        <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">FICHIERS ASSOCIÉS</span><h2 id="documents-dossier-titre">Documents</h2></div></div>
                        <ul class="b2b-document-list"><?php foreach ($documents as $document): ?>
                            <li><span><strong><?= $e($document['nom_original']) ?></strong><small><?= $e(date('d/m/Y à H:i', strtotime($document['date_creation']))) ?> · <?= number_format((int) $document['taille'] / 1024, 0, ',', ' ') ?> Ko</small></span><a href="telecharger-document.php?entreprise_id=<?= $entrepriseId ?>&amp;id=<?= (int) $document['id'] ?>">Télécharger</a></li>
                        <?php endforeach; ?></ul>
                    </section>
                <?php endif; ?>
            </div>

            <aside class="b2b-detail-aside">
                <section class="b2b-panel">
                    <span class="b2b-eyebrow">DÉLAI CONTRACTUEL</span>
                    <h2>SLA d’affectation</h2>
                    <?php if ($seuilSlaMinutes === null): ?>
                        <p>Aucun SLA de contrat actif n’est configuré.</p>
                    <?php elseif ($demande['date_transmission']): ?>
                        <?php if ($demande['intervention_id']): ?>
                            <p class="b2b-sla-result b2b-sla-result--done">✓ Mission confiée à l’équipe d’intervention.</p>
                        <?php elseif ($slaDepasse): ?>
                            <p class="b2b-sla-result b2b-sla-result--late">SLA dépassé. Le dossier nécessite un suivi.</p>
                        <?php else: ?>
                            <p class="b2b-sla-result">Dans le délai prévu au contrat.</p>
                        <?php endif; ?>
                        <p><?= (int) ceil((int) $seuilSlaMinutes / 60) ?> h pour une demande <?= $demande['urgence'] === 'urgente' ? 'urgente' : 'normale' ?>.</p>
                        <small>Transmise le <?= $e(date('d/m/Y à H:i', strtotime($demande['date_transmission']))) ?></small>
                    <?php else: ?>
                        <p>Le délai SLA démarre à la transmission à l’équipe de coordination.</p>
                        <small>Pas encore transmise</small>
                    <?php endif; ?>
                </section>

                <section class="b2b-panel">
                    <span class="b2b-eyebrow">PAIEMENT</span><h2>État du paiement</h2>
                    <?php if ($demande['contrat_b2b_id']): ?>
                        <p class="b2b-payment-state">Couvert par le contrat B2B #<?= (int) $demande['contrat_b2b_id'] ?>.</p>
                        <?php if ($demande['contrat_credit_consomme_le']): ?><small>1 crédit consommé à la clôture, le <?= $e(date('d/m/Y', strtotime($demande['contrat_credit_consomme_le']))) ?>.</small><?php else: ?><small>1 crédit réservé ; il sera consommé à la clôture de l’intervention.</small><?php endif; ?>
                    <?php elseif ($demande['site_id']): ?>
                        <p>Demande entreprise antérieure au contrat B2B. Elle doit être rattachée à un contrat avant sa clôture.</p>
                    <?php elseif ($demande['mode_paiement'] !== 'normal'): ?>
                        <p class="b2b-payment-state">Couvert par <?= $demande['mode_paiement'] === 'abonnement' ? 'un abonnement' : 'un Pass' ?>.</p>
                    <?php elseif ($demande['paiement_statut']): ?>
                        <p class="b2b-payment-state"><?= $e($paiementStatuts[$demande['paiement_statut']] ?? 'Statut inconnu') ?></p>
                        <?php if ($demande['paiement_montant'] !== null): ?><p><?= number_format((float) $demande['paiement_montant'], 0, ',', ' ') ?> FCFA</p><?php endif; ?>
                        <?php if ($demande['date_paiement']): ?><small><?= $e(date('d/m/Y à H:i', strtotime($demande['date_paiement']))) ?></small><?php endif; ?>
                    <?php else: ?>
                        <p>Le paiement n’est pas encore enregistré.</p>
                        <?php if ($demande['intervention_montant']): ?><small>Montant prévu : <?= number_format((float) $demande['intervention_montant'], 0, ',', ' ') ?> FCFA</small><?php endif; ?>
                    <?php endif; ?>
                </section>

                <?php if ($demande['ticket_sav_id']): ?>
                    <section class="b2b-panel">
                        <span class="b2b-eyebrow">SERVICE APRÈS-VENTE</span><h2>Ticket SAV #<?= (int) $demande['ticket_sav_id'] ?></h2>
                        <p><?= $e($demande['ticket_sav_motif']) ?></p>
                        <span class="b2b-status b2b-status--<?= $e($demande['ticket_sav_statut']) ?>"><?= $e(ucfirst(str_replace('_', ' ', $demande['ticket_sav_statut']))) ?></span>
                        <small>Ouvert le <?= $e(date('d/m/Y', strtotime($demande['ticket_sav_date']))) ?></small>
                    </section>
                <?php endif; ?>

                <a class="b2b-button b2b-button--secondary b2b-detail-back-button" href="<?= $e($retourUrl) ?>">Retour aux demandes</a>
            </aside>
        </div>
    </main>
</div>
</body>
</html>
