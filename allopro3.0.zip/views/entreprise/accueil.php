<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../../models/EntrepriseB2B.php';
require_once __DIR__ . '/../../includes/icones.php';

$modeleEntreprise = new EntrepriseB2B();
$userId = (int) $_SESSION['user_id'];
$entreprises = $modeleEntreprise->getEntreprisesParMembre($userId);
if (!$entreprises) {
    header('Location: ../client/activer-compte-entreprise.php');
    exit;
}
$erreur = '';
$nomSaisi = '';
$nomExisteErreur = false;
$csrfKey = 'csrf_entreprise_creation';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $nomSaisi = is_string($_POST['nom'] ?? null) ? trim($_POST['nom']) : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } else {
        try {
            $nouvelleEntrepriseId = $modeleEntreprise->creerPourClient($userId, $nomSaisi);
            journaliser('entreprise.compte_cree', 'entreprise_b2b', $nouvelleEntrepriseId, $nomSaisi);
            header('Location: accueil.php?entreprise_id=' . $nouvelleEntrepriseId);
            exit;
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
            $nomExisteErreur = str_contains($erreur, 'porte déjà ce nom');
        } catch (PDOException $exception) {
            error_log('Création espace entreprise par client ' . $userId . ' : ' . $exception->getMessage());
            $erreur = 'La création de l’espace entreprise a échoué. Réessayez.';
        }
    }
}

$entreprise = null;
$entrepriseId = filter_var($_GET['entreprise_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($entrepriseId !== false && $entrepriseId !== null) {
    $entreprise = $modeleEntreprise->getEntreprisePourMembre((int) $entrepriseId, $userId);
    if (!$entreprise) {
        header('Location: accueil.php');
        exit;
    }
    $entrepriseId = (int) $entrepriseId;
}

$permissionsEntreprise = $entreprise
    ? $modeleEntreprise->getPermissionsPourMembre($entrepriseId, $userId, (string) $entreprise['role_membre'])
    : [];
$entrepriseAutorisePermission = static fn(string $permission): bool => in_array($permission, $permissionsEntreprise, true);
if ($entreprise && !$entrepriseAutorisePermission('accueil')) {
    http_response_code(403);
    exit('Vous n’avez pas la permission d’accéder au tableau de bord entreprise.');
}
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$resume = $entreprise ? $modeleEntreprise->getResume($entrepriseId) : [];
$demandes = $entreprise && $entrepriseAutorisePermission('demandes')
    ? array_slice($modeleEntreprise->getDemandes($entrepriseId), 0, 6)
    : [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Espace entreprise — ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
    <script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script>
</head>
<body>
<?php if ($entreprise): ?>
<div class="b2b-app">
    <?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?>
    <main class="b2b-main">
        <header class="b2b-dashboard-hero">
            <div class="b2b-dashboard-hero__content">
                <span class="b2b-eyebrow">ESPACE ENTREPRISE</span>
                <h1>Bonjour, <?= $e($entreprise['nom']) ?></h1>
                <p>Retrouvez en un coup d’œil vos demandes, interventions et services professionnels.</p>
                <?php if ($entrepriseAutorisePermission('demandes')): ?><div class="b2b-dashboard-hero__actions">
                    <a class="b2b-button" href="nouvelle-demande.php?entreprise_id=<?= $entrepriseId ?>"><?= icone('plus', 17) ?> Nouvelle demande</a>
                    <a class="b2b-button b2b-button--hero-secondary" href="demandes.php?entreprise_id=<?= $entrepriseId ?>">Voir mes demandes <?= icone('arrow', 15) ?></a>
                </div><?php endif; ?>
            </div>
            <div class="b2b-dashboard-hero__art" aria-hidden="true">
                <span class="b2b-dashboard-hero__glow"></span>
                <span class="b2b-dashboard-hero__icon"><?= icone('building', 46) ?></span>
                <span class="b2b-dashboard-hero__caption">VOTRE ACTIVITÉ, EN UN SEUL ENDROIT</span>
            </div>
        </header>
        <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
        <?php if (count($entreprises) > 1): ?>
            <section class="b2b-panel b2b-dashboard-companies">
                <h2>Mes espaces entreprise</h2>
                <div class="b2b-actions">
                    <?php foreach ($entreprises as $membreEntreprise): ?>
                        <a class="b2b-button b2b-button--secondary" href="accueil.php?entreprise_id=<?= (int) $membreEntreprise['id'] ?>"><?= $e($membreEntreprise['nom']) ?></a>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
        <?php if ($entrepriseAutorisePermission('demandes') || $entrepriseAutorisePermission('interventions') || $entrepriseAutorisePermission('tickets')): ?>
        <section class="b2b-stats" aria-label="Indicateurs de l’entreprise">
            <?php if ($entrepriseAutorisePermission('demandes')): ?>
            <a class="b2b-stat b2b-stat--dashboard" href="demandes.php?entreprise_id=<?= $entrepriseId ?>">
                <span class="b2b-stat__icon"><?= icone('inbox', 19) ?></span>
                <span class="b2b-stat__label">Demandes totales</span>
                <strong><?= (int) ($resume['demandes'] ?? 0) ?></strong>
                <span class="b2b-stat__hint">Tous vos dossiers</span>
                <span class="b2b-stat__arrow" aria-hidden="true"><?= icone('arrow', 15) ?></span>
            </a>
            <a class="b2b-stat b2b-stat--dashboard" href="demandes.php?entreprise_id=<?= $entrepriseId ?>">
                <span class="b2b-stat__icon b2b-stat__icon--orange"><?= icone('clock', 19) ?></span>
                <span class="b2b-stat__label">Demandes en cours</span>
                <strong><?= (int) ($resume['demandes_en_cours'] ?? 0) ?></strong>
                <span class="b2b-stat__hint">Dossiers à suivre</span>
                <span class="b2b-stat__arrow" aria-hidden="true"><?= icone('arrow', 15) ?></span>
            </a>
            <?php endif; ?>
            <?php if ($entrepriseAutorisePermission('interventions')): ?>
            <a class="b2b-stat b2b-stat--dashboard" href="gestion.php?entreprise_id=<?= $entrepriseId ?>&amp;module=interventions">
                <span class="b2b-stat__icon b2b-stat__icon--blue"><?= icone('wrench', 19) ?></span>
                <span class="b2b-stat__label">Interventions actives</span>
                <strong><?= (int) ($resume['interventions_actives'] ?? 0) ?></strong>
                <span class="b2b-stat__hint">Prises en charge</span>
                <span class="b2b-stat__arrow" aria-hidden="true"><?= icone('arrow', 15) ?></span>
            </a>
            <?php endif; ?>
            <?php if ($entrepriseAutorisePermission('tickets')): ?>
            <a class="b2b-stat b2b-stat--dashboard" href="gestion.php?entreprise_id=<?= $entrepriseId ?>&amp;module=tickets">
                <span class="b2b-stat__icon b2b-stat__icon--violet"><?= icone('ticket', 19) ?></span>
                <span class="b2b-stat__label">Tickets SAV</span>
                <strong><?= (int) ($resume['tickets_sav'] ?? 0) ?></strong>
                <span class="b2b-stat__hint">Suivi après intervention</span>
                <span class="b2b-stat__arrow" aria-hidden="true"><?= icone('arrow', 15) ?></span>
            </a>
            <?php endif; ?>
        </section>
        <?php endif; ?>
        <?php if ($entrepriseAutorisePermission('demandes')): ?>
        <section class="b2b-panel b2b-dashboard-recent">
            <div class="b2b-dashboard-section-head">
                <div>
                    <span class="b2b-eyebrow">VOTRE ACTIVITÉ</span>
                    <h2>Demandes récentes</h2>
                    <p>Accédez rapidement aux derniers dossiers de vos sites.</p>
                </div>
                <a class="b2b-button b2b-button--secondary" href="demandes.php?entreprise_id=<?= $entrepriseId ?>">Tout afficher</a>
            </div>
            <?php if (!$demandes): ?>
                <div class="b2b-dashboard-empty">
                    <span class="b2b-dashboard-empty__icon" aria-hidden="true"><?= icone('inbox', 22) ?></span>
                    <strong>Votre activité démarre ici</strong>
                    <p>Créez une demande pour l’un de vos sites et suivez sa prise en charge depuis cet espace.</p>
                    <a class="b2b-button" href="nouvelle-demande.php?entreprise_id=<?= $entrepriseId ?>"><?= icone('plus', 16) ?> Créer une demande</a>
                </div>
            <?php else: ?>
                <div class="b2b-table-wrap"><table class="b2b-list">
                    <thead><tr><th>Dossier</th><th>Site</th><th>Catégorie</th><th>Statut</th><th>SLA</th><th>Créée le</th></tr></thead>
                    <tbody><?php foreach ($demandes as $demande): ?>
                        <tr>
                            <td><a class="b2b-dashboard-dossier" href="detail-demande.php?entreprise_id=<?= $entrepriseId ?>&amp;id=<?= (int) $demande['id'] ?>"><?= $e($demande['numero_dossier']) ?> <?= icone('arrow', 13) ?></a><span class="b2b-dashboard-site-subline"><?= $demande['urgence'] === 'urgente' ? 'Urgence élevée' : 'Demande entreprise' ?></span></td>
                            <td><?= $e($demande['site_nom']) ?></td>
                            <td><?= $e($demande['categorie_nom']) ?></td>
                            <td><span class="b2b-dashboard-status"><?= $e(ucfirst(str_replace('_', ' ', $demande['intervention_statut'] ?: $demande['statut']))) ?></span></td>
                            <td><?php
                                $seuilSla = $demande['sla_' . ($demande['urgence'] === 'urgente' ? 'urgent' : 'normal') . '_minutes'];
                                if ($demande['statut'] !== 'nouvelle') {
                                    $slaLabel = 'Affectation effectuée';
                                    $slaClasse = 'b2b-dashboard-sla--ok';
                                } elseif ($seuilSla === null) {
                                    $slaLabel = 'Pas de SLA contractuel';
                                    $slaClasse = '';
                                } elseif (empty($demande['date_transmission'])) {
                                    $slaLabel = 'En attente de transmission';
                                    $slaClasse = '';
                                } else {
                                    $slaDepasse = (time() - strtotime($demande['date_transmission'])) >= ((int) $seuilSla * 60);
                                    $slaLabel = $slaDepasse ? 'SLA dépassé' : 'Dans le délai';
                                    $slaClasse = $slaDepasse ? 'b2b-dashboard-sla--alert' : 'b2b-dashboard-sla--ok';
                                }
                            ?><span class="b2b-dashboard-sla <?= $slaClasse ?>"><?= $e($slaLabel) ?></span></td>
                            <td><?= $e(date('d/m/Y H:i', strtotime($demande['date_creation']))) ?></td>
                        </tr>
                    <?php endforeach; ?></tbody>
                </table></div>
            <?php endif; ?>
        </section>
        <?php endif; ?>
        <?php if ($entrepriseAutorisePermission('sites') || $entrepriseAutorisePermission('contrats') || $entreprise['role_membre'] === 'admin'): ?>
        <section class="b2b-dashboard-shortcuts" aria-labelledby="raccourcis-entreprise-titre">
            <div class="b2b-dashboard-section-head">
                <div>
                    <span class="b2b-eyebrow">POUR ALLER PLUS VITE</span>
                    <h2 id="raccourcis-entreprise-titre">Accès rapides</h2>
                    <p>Les outils essentiels pour gérer votre activité.</p>
                </div>
            </div>
            <div class="b2b-dashboard-shortcuts__grid">
                <?php if ($entrepriseAutorisePermission('sites')): ?>
                <a class="b2b-dashboard-shortcut" href="sites.php?entreprise_id=<?= $entrepriseId ?>">
                    <span class="b2b-dashboard-shortcut__icon"><?= icone('pin', 20) ?></span>
                    <span><strong>Gérer mes sites</strong><small>Adresses et informations de vos établissements</small></span>
                    <span class="b2b-dashboard-shortcut__arrow" aria-hidden="true"><?= icone('arrow', 16) ?></span>
                </a>
                <?php endif; ?>
                <?php if ($entrepriseAutorisePermission('contrats')): ?>
                <a class="b2b-dashboard-shortcut" href="gestion.php?entreprise_id=<?= $entrepriseId ?>&amp;module=contrats">
                    <span class="b2b-dashboard-shortcut__icon b2b-dashboard-shortcut__icon--orange"><?= icone('shield', 20) ?></span>
                    <span><strong>Contrats et SLA</strong><small>Consulter vos crédits et délais de prise en charge</small></span>
                    <span class="b2b-dashboard-shortcut__arrow" aria-hidden="true"><?= icone('arrow', 16) ?></span>
                </a>
                <?php endif; ?>
                <?php if ($entreprise['role_membre'] === 'admin'): ?>
                <a class="b2b-dashboard-shortcut" href="membres.php?entreprise_id=<?= $entrepriseId ?>">
                    <span class="b2b-dashboard-shortcut__icon b2b-dashboard-shortcut__icon--violet"><?= icone('users', 20) ?></span>
                    <span><strong>Gérer les accès</strong><small>Choisir qui peut accéder à cet espace entreprise</small></span>
                    <span class="b2b-dashboard-shortcut__arrow" aria-hidden="true"><?= icone('arrow', 16) ?></span>
                </a>
                <?php endif; ?>
            </div>
        </section>
        <?php endif; ?>
    </main>
</div>
<?php else: ?>
<main class="b2b-main">
    <header class="b2b-header b2b-header--welcome">
        <div class="b2b-header__copy"><span class="b2b-eyebrow">VOTRE ACTIVITÉ, MIEUX ORGANISÉE</span><h1>Espace client entreprise</h1><p>Gérez vos sites et vos demandes professionnelles, avec votre compte client ALLÔ PRO habituel.</p></div>
        <a class="b2b-button b2b-button--secondary" href="../client/accueil.php">Retour à mon espace client <span aria-hidden="true">↗</span></a>
    </header>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
    <?php if ($entreprises): ?>
        <section class="b2b-panel">
            <div class="b2b-panel__heading"><div><span class="b2b-eyebrow">ACCÈS RAPIDE</span><h2>Vos espaces entreprise</h2><p>Choisissez l’organisation à gérer.</p></div><span class="b2b-count"><?= count($entreprises) ?> espace<?= count($entreprises) > 1 ? 's' : '' ?></span></div>
            <div class="b2b-company-grid">
                <?php foreach ($entreprises as $membreEntreprise): ?>
                    <a class="b2b-company-card" href="accueil.php?entreprise_id=<?= (int) $membreEntreprise['id'] ?>">
                        <span class="b2b-company-card__icon" aria-hidden="true"><?= $e(mb_strtoupper(mb_substr($membreEntreprise['nom'], 0, 1))) ?></span>
                        <span class="b2b-company-card__details"><strong><?= $e($membreEntreprise['nom']) ?></strong><small><?= $membreEntreprise['role_membre'] === 'admin' ? 'Administrateur' : 'Membre autorisé' ?></small></span>
                        <span class="b2b-company-card__arrow" aria-hidden="true">→</span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
    <section class="b2b-create-layout">
        <div class="b2b-create-aside">
            <span class="b2b-create-aside__icon" aria-hidden="true">✦</span>
            <span class="b2b-eyebrow">VOTRE ESPACE PRO</span>
            <h2>Tout votre suivi professionnel au même endroit.</h2>
            <p>Centralisez les sites, interventions, contrats et documents de votre organisation.</p>
            <ul><li>Vos équipes gardent leur propre compte client</li><li>Vous décidez qui accède à l’espace entreprise</li><li>Les demandes sont suivies par site</li></ul>
        </div>
        <div class="b2b-panel b2b-create-panel">
            <span class="b2b-eyebrow">NOUVELLE ORGANISATION</span>
            <h2>Créer un espace entreprise</h2>
            <p>Votre compte client reste inchangé. Vous en serez l’administrateur et pourrez ajouter des membres ensuite.</p>
            <form method="post" class="b2b-form" id="form-entreprise" data-verification-url="../../public/api-entreprise-nom.php">
                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                <label for="entreprise-nom">Nom légal ou usuel de l’entreprise
                    <input id="entreprise-nom" name="nom" type="text" value="<?= $e($nomSaisi) ?>" minlength="2" maxlength="150" autocomplete="organization" aria-describedby="entreprise-nom-aide entreprise-nom-statut" aria-invalid="<?= $nomExisteErreur ? 'true' : 'false' ?>" required>
                </label>
                <small id="entreprise-nom-aide" class="b2b-field-hint">Le nom doit être unique dans ALLÔ PRO.</small>
                <div id="entreprise-nom-statut" class="b2b-name-status" role="status" aria-live="polite"><?= $nomExisteErreur ? $e($erreur) : '' ?></div>
                <button class="b2b-button b2b-button--create" type="submit" id="entreprise-creer">Créer mon espace entreprise <span aria-hidden="true">→</span></button>
            </form>
            <p class="b2b-privacy-note"><span aria-hidden="true">●</span> Vos informations restent rattachées à votre compte client sécurisé.</p>
        </div>
    </section>
</main>
<?php endif; ?>
</body>
</html>
