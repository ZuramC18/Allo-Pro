<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$demandes = $entrepriseModele->getDemandes($entrepriseId);
$etatSlaDemande = static function (array $demande): array {
    $seuilSla = $demande['sla_' . ($demande['urgence'] === 'urgente' ? 'urgent' : 'normal') . '_minutes'];
    if ($demande['statut'] !== 'nouvelle') {
        return ['label' => 'Affectation effectuée', 'class' => 'neutral'];
    }
    if ($seuilSla === null) {
        return ['label' => 'Pas de SLA contractuel', 'class' => 'neutral'];
    }
    if (empty($demande['date_transmission'])) {
        return ['label' => 'En attente de transmission', 'class' => 'warning'];
    }
    $depasse = (time() - strtotime($demande['date_transmission'])) >= ((int) $seuilSla * 60);
    return ['label' => $depasse ? 'SLA dépassé' : 'Dans le délai', 'class' => $depasse ? 'danger' : 'success'];
};
$statutsConnus = ['nouvelle' => true, 'terminee' => true, 'termine' => true, 'annulee' => true, 'annule' => true, 'refusee' => true, 'refuse' => true];
$demandesEnAttente = 0;
$demandesUrgentes = 0;
$demandesSlaDepasse = 0;
$sitesDemandes = [];
foreach ($demandes as &$demande) {
    $demande['statut_effectif'] = (string) ($demande['intervention_statut'] ?: $demande['statut']);
    $demande['sla_affiche'] = $etatSlaDemande($demande);
    $demande['date_timestamp'] = strtotime((string) $demande['date_creation']);
    $demandesEnAttente += $demande['statut'] === 'nouvelle' ? 1 : 0;
    $demandesUrgentes += $demande['urgence'] === 'urgente' ? 1 : 0;
    $demandesSlaDepasse += $demande['sla_affiche']['class'] === 'danger' ? 1 : 0;
    $sitesDemandes[(string) $demande['site_nom']] = (string) $demande['site_nom'];
    $statutsConnus[strtolower($demande['statut_effectif'])] = true;
}
unset($demande);
$demandesActives = count(array_filter(
    $demandes,
    static fn(array $demande): bool => !in_array(strtolower($demande['statut_effectif']), ['terminee', 'termine', 'annulee', 'annule', 'refusee', 'refuse'], true)
));
natcasesort($sitesDemandes);
$libellesStatutDemande = [
    'nouvelle' => 'Nouvelle',
    'en_attente' => 'En attente',
    'attribuee' => 'Attribuée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'termine' => 'Terminé',
    'annulee' => 'Annulée',
    'annule' => 'Annulé',
    'refusee' => 'Refusée',
    'refuse' => 'Refusé',
    'resolue' => 'Résolue',
];
$libelleStatutDemande = static fn(string $statut): string => $libellesStatutDemande[$statut] ?? ucfirst(str_replace('_', ' ', $statut));
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Demandes et interventions — <?= $e($entreprise['nom']) ?></title><link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>"></head>
<body><div class="b2b-app"><?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?><main class="b2b-main">
    <header class="b2b-demandes-hero">
        <div class="b2b-demandes-hero__content">
            <span class="b2b-eyebrow">CENTRE DE SUIVI</span>
            <h1>Demandes et interventions</h1>
            <p>Un suivi clair des demandes partagées entre les sites et les membres de votre entreprise.</p>
        </div>
        <div class="b2b-demandes-hero__actions">
            <span class="b2b-demandes-hero__note"><?= icone('shield', 15) ?> Votre activité, réunie au même endroit</span>
            <a class="b2b-button" href="nouvelle-demande.php?entreprise_id=<?= $entrepriseId ?>"><?= icone('plus', 16) ?> Nouvelle demande</a>
        </div>
        <span class="b2b-demandes-hero__mark" aria-hidden="true"><?= icone('clipboard', 52) ?></span>
    </header>
    <?php if (($_GET['nouvelle'] ?? '') === '1' && !empty($_SESSION['flash_entreprise'])): ?><div class="b2b-alert b2b-alert--success" role="status"><?= $e($_SESSION['flash_entreprise']) ?></div><?php unset($_SESSION['flash_entreprise']); endif; ?>
    <section class="b2b-demandes-overview" aria-label="Résumé des demandes">
        <div class="b2b-demandes-overview__intro"><span class="b2b-demandes-overview__icon" aria-hidden="true"><?= icone('inbox', 21) ?></span><span><strong><?= count($demandes) ?></strong><small>demande<?= count($demandes) === 1 ? '' : 's' ?> au total</small></span></div>
        <span class="b2b-demandes-overview__divider" aria-hidden="true"></span>
        <div class="b2b-demandes-overview__metric"><strong><?= $demandesActives ?></strong><span>À suivre</span></div>
        <div class="b2b-demandes-overview__metric"><strong><?= $demandesUrgentes ?></strong><span>Urgente<?= $demandesUrgentes === 1 ? '' : 's' ?></span></div>
        <div class="b2b-demandes-overview__metric b2b-demandes-overview__metric--alert"><strong><?= $demandesSlaDepasse ?></strong><span>SLA dépassé</span></div>
    </section>
    <section class="b2b-panel b2b-demandes-panel" aria-labelledby="liste-demandes-titre">
        <div class="b2b-demandes-panel__heading">
            <div><span class="b2b-eyebrow">VUE D’ENSEMBLE</span><h2 id="liste-demandes-titre">Toutes vos demandes</h2><p>Consultez le statut, le site concerné et le délai de traitement.</p></div>
            <?php if ($demandes): ?><div class="b2b-demandes-panel__count"><strong><?= count($demandes) ?></strong> dossier<?= count($demandes) === 1 ? '' : 's' ?></div><?php endif; ?>
        </div>
        <?php if (!$demandes): ?>
            <div class="b2b-demandes-empty"><span class="b2b-demandes-empty__icon" aria-hidden="true"><?= icone('inbox', 21) ?></span><strong>Aucune demande pour le moment</strong><p>Créez votre première demande pour suivre son avancement ici. Les autres membres autorisés de votre entreprise pourront également la consulter.</p><a class="b2b-button" href="nouvelle-demande.php?entreprise_id=<?= $entrepriseId ?>"><?= icone('plus', 16) ?> Créer une demande</a></div>
        <?php else: ?>
            <div class="b2b-demandes-filters">
                <label class="b2b-demandes-search" for="recherche-demandes-entreprise"><?= icone('search', 17) ?><span class="b2b-visually-hidden">Rechercher une demande</span><input id="recherche-demandes-entreprise" type="search" placeholder="Référence, site, catégorie…" autocomplete="off"></label>
                <label class="b2b-visually-hidden" for="filtre-statut-demandes">Filtrer par statut</label>
                <select id="filtre-statut-demandes" class="b2b-demandes-select"><option value="">Tous les statuts</option><?php foreach (array_keys($statutsConnus) as $statut): ?><option value="<?= $e($statut) ?>"><?= $e($libelleStatutDemande($statut)) ?></option><?php endforeach; ?></select>
                <label class="b2b-visually-hidden" for="filtre-site-demandes">Filtrer par site</label>
                <select id="filtre-site-demandes" class="b2b-demandes-select"><option value="">Tous les sites</option><?php foreach ($sitesDemandes as $site): ?><option value="<?= $e($site) ?>"><?= $e($site) ?></option><?php endforeach; ?></select>
                <label class="b2b-visually-hidden" for="filtre-urgence-demandes">Filtrer par urgence</label>
                <select id="filtre-urgence-demandes" class="b2b-demandes-select"><option value="">Toutes les urgences</option><option value="urgente">Urgentes</option><option value="normale">Normales</option></select>
                <label class="b2b-visually-hidden" for="tri-demandes">Trier les demandes</label>
                <select id="tri-demandes" class="b2b-demandes-select b2b-demandes-select--sort"><option value="recent">Plus récentes</option><option value="ancien">Plus anciennes</option><option value="reference">Référence</option></select>
            </div>
            <div class="b2b-demandes-grid" id="liste-demandes">
                <?php foreach ($demandes as $demande):
                    $urlDetail = 'detail-demande.php?entreprise_id=' . $entrepriseId . '&id=' . (int) $demande['id'];
                    $statutDemande = strtolower($demande['statut_effectif']);
                    $classeStatut = (string) preg_replace('/[^a-z0-9_-]/', '', $statutDemande);
                    $dateDemande = $demande['date_timestamp'] !== false ? date('d/m/Y à H:i', $demande['date_timestamp']) : 'Date indisponible';
                ?>
                    <article class="b2b-demande-card" data-demande-row data-demande-status="<?= $e($statutDemande) ?>" data-demande-site="<?= $e($demande['site_nom']) ?>" data-demande-urgency="<?= $e($demande['urgence']) ?>" data-demande-date="<?= (int) $demande['date_timestamp'] ?>" data-demande-reference="<?= $e($demande['numero_dossier']) ?>">
                        <a class="b2b-demande-card__overlay" href="<?= $e($urlDetail) ?>" aria-label="Ouvrir le dossier <?= $e($demande['numero_dossier']) ?>"></a>
                        <div class="b2b-demande-card__top">
                            <div class="b2b-demande-card__reference"><span class="b2b-eyebrow">DOSSIER</span><strong><?= $e($demande['numero_dossier']) ?></strong></div>
                            <span class="b2b-status b2b-status--<?= $e($classeStatut) ?>"><?= $e($libelleStatutDemande($statutDemande)) ?></span>
                        </div>
                        <?php if (!empty($demande['description'])): ?><p class="b2b-demande-card__description"><?= $e($demande['description']) ?></p><?php endif; ?>
                        <div class="b2b-demande-card__site"><?= icone('pin', 15) ?><span><small>Site d’intervention</small><strong><?= $e($demande['site_nom']) ?></strong></span></div>
                        <div class="b2b-demande-card__details">
                            <span><small>Catégorie</small><strong><?= $e($demande['categorie_nom']) ?></strong></span>
                            <span><small>Urgence</small><strong class="<?= $demande['urgence'] === 'urgente' ? 'b2b-demande-card__urgent' : '' ?>"><?= $demande['urgence'] === 'urgente' ? 'Urgente' : 'Normale' ?></strong></span>
                            <span class="b2b-demande-card__sla b2b-demande-card__sla--<?= $e($demande['sla_affiche']['class']) ?>"><small>Délai contractuel</small><strong><?= $e($demande['sla_affiche']['label']) ?></strong></span>
                        </div>
                        <div class="b2b-demande-card__footer"><span><?= icone('calendar', 14) ?><?= $e($dateDemande) ?></span><span class="b2b-row-link__action">Ouvrir le dossier <?= icone('arrow', 14) ?></span></div>
                    </article>
                <?php endforeach; ?>
            </div>
            <p id="demandes-recherche-vide" class="b2b-demandes-no-results" hidden>Aucun dossier ne correspond à ces critères. Modifiez votre recherche ou vos filtres.</p>
        <?php endif; ?>
    </section>
</main></div>
<script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script>
</body></html>
