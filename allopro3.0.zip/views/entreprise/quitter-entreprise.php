<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';

if (($entreprise['role_membre'] ?? '') !== 'membre') {
    http_response_code(403);
    exit('Seuls les membres non administrateurs peuvent quitter cet espace.');
}

$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$erreur = '';
$aQuitte = false;
$csrfKey = 'csrf_quitter_entreprise';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'La page a expiré. Rechargez-la puis réessayez.';
    } elseif (($_POST['confirmation'] ?? '') !== 'quitter') {
        $erreur = 'Confirmez votre départ pour continuer.';
    } else {
        try {
            $entrepriseModele->quitterEntreprise($entrepriseId, (int) $_SESSION['user_id']);
            $aQuitte = true;
        } catch (PDOException $exception) {
            error_log('Départ entreprise ' . $entrepriseId . ' par le membre ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
            $erreur = 'Votre départ n’a pas pu être enregistré. Réessayez.';
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $aQuitte ? 'Accès retiré' : 'Quitter l’entreprise' ?> — <?= $e($entreprise['nom']) ?></title>
    <link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>">
</head>
<body>
<main class="b2b-main b2b-leave-page">
    <section class="b2b-panel b2b-leave-card">
        <?php if ($aQuitte): ?>
            <span class="b2b-eyebrow">ACCÈS MIS À JOUR</span>
            <h1>Vous avez quitté <?= $e($entreprise['nom']) ?>.</h1>
            <p>Votre accès à cet espace entreprise a été retiré. Les administrateurs ont été informés.</p>
            <a class="b2b-button" href="../client/accueil.php">Revenir à mon espace client</a>
        <?php else: ?>
            <span class="b2b-eyebrow">ESPACE ENTREPRISE</span>
            <h1>Quitter <?= $e($entreprise['nom']) ?> ?</h1>
            <p>Vous perdrez l’accès aux sites, demandes et autres informations partagées de cette entreprise. Votre compte client personnel ne sera pas affecté.</p>
            <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
            <div class="b2b-leave-actions">
                <a class="b2b-button b2b-button--secondary" href="accueil.php?entreprise_id=<?= $entrepriseId ?>">Annuler</a>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
                    <input type="hidden" name="confirmation" value="quitter">
                    <button class="b2b-button b2b-button--danger" type="submit">Confirmer mon départ</button>
                </form>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
