<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';
require_once __DIR__ . '/../../includes/icones.php';
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$estAdmin = $entreprise['role_membre'] === 'admin';
$erreur = '';
$succes = '';
$csrfKey = 'csrf_entreprise_sites';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (!$estAdmin) {
        http_response_code(403);
        $erreur = 'Seul un administrateur peut gérer les sites.';
    } else {
        try {
            if ($action === 'creer') {
                $entrepriseModele->creerSite($entrepriseId, (int) $_SESSION['user_id'], $_POST);
                $succes = 'Le site a été ajouté.';
            } elseif ($action === 'modifier') {
                $siteId = filter_var($_POST['site_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if ($siteId === false || !$entrepriseModele->modifierSite($entrepriseId, (int) $_SESSION['user_id'], (int) $siteId, $_POST)) {
                    throw new InvalidArgumentException('Ce site est introuvable ou ne peut pas être modifié.');
                }
                $succes = 'Les informations du site ont été mises à jour.';
            } elseif ($action === 'statut') {
                $siteId = filter_var($_POST['site_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                $statut = is_string($_POST['statut'] ?? null) ? $_POST['statut'] : '';
                if ($siteId === false || !$entrepriseModele->changerStatutSite($entrepriseId, (int) $_SESSION['user_id'], (int) $siteId, $statut)) {
                    throw new InvalidArgumentException('Le statut du site n’a pas pu être modifié.');
                }
                $succes = 'Le statut du site a été modifié.';
            }
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Gestion des sites entreprise ' . $entrepriseId . ' : ' . $exception->getMessage());
            $erreur = 'La modification des sites a échoué. Réessayez.';
        }
    }
}
$sites = $entrepriseModele->getSites($entrepriseId);
$nombreSitesActifs = count(array_filter($sites, static fn(array $site): bool => ($site['statut'] ?? '') === 'actif'));
$nombreSitesInactifs = count($sites) - $nombreSitesActifs;
$villes = $entrepriseModele->getVillesActives();
$zonesParVille = [];
foreach ($villes as $ville) {
    $zonesParVille[(int) $ville['id']] = $entrepriseModele->getZonesActivesParVille((int) $ville['id']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sites — <?= $e($entreprise['nom']) ?></title><link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>"><script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script></head>
<body><div class="b2b-app"><?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?><main class="b2b-main b2b-sites-page">
    <header class="b2b-sites-hero">
        <div class="b2b-sites-hero__content">
            <span class="b2b-eyebrow">VOTRE RÉSEAU D’ÉTABLISSEMENTS</span>
            <h1>Vos sites, au même endroit.</h1>
            <p>Gérez les lieux d’intervention et les contacts de <?= $e($entreprise['nom']) ?>.</p>
            <?php if ($estAdmin && $villes): ?>
                <a class="b2b-button" href="#ajouter-site"><?= icone('plus', 17) ?> Ajouter un site</a>
            <?php endif; ?>
        </div>
        <div class="b2b-sites-hero__mark" aria-hidden="true"><?= icone('building', 43) ?></div>
    </header>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
    <?php if ($succes !== ''): ?><div class="b2b-alert b2b-alert--success" role="status"><?= $e($succes) ?></div><?php endif; ?>
    <section class="b2b-sites-overview" aria-label="Résumé des sites">
        <div class="b2b-sites-overview__intro"><span class="b2b-sites-overview__icon"><?= icone('pin', 19) ?></span><span><strong><?= count($sites) ?></strong><small><?= count($sites) === 1 ? 'site enregistré' : 'sites enregistrés' ?></small></span></div>
        <span class="b2b-sites-overview__divider" aria-hidden="true"></span>
        <span class="b2b-sites-overview__status"><i class="b2b-sites-dot b2b-sites-dot--actif" aria-hidden="true"></i><?= $nombreSitesActifs ?> actif<?= $nombreSitesActifs === 1 ? '' : 's' ?></span>
        <span class="b2b-sites-overview__status"><i class="b2b-sites-dot b2b-sites-dot--inactif" aria-hidden="true"></i><?= $nombreSitesInactifs ?> inactif<?= $nombreSitesInactifs === 1 ? '' : 's' ?></span>
    </section>
    <section class="b2b-sites-section" aria-labelledby="sites-enregistres-titre">
        <div class="b2b-sites-section__head">
            <div><span class="b2b-eyebrow">RÉSEAU</span><h2 id="sites-enregistres-titre">Sites enregistrés</h2><p>Les lieux associés à vos demandes d’intervention.</p></div>
            <?php if (count($sites) > 1): ?>
                <label class="b2b-sites-search"><?= icone('search', 17) ?><span class="b2b-visually-hidden">Rechercher un site</span><input id="recherche-sites-entreprise" type="search" placeholder="Rechercher un site…" autocomplete="off"></label>
            <?php endif; ?>
        </div>
        <?php if (!$sites): ?>
            <div class="b2b-sites-empty">
                <span class="b2b-sites-empty__icon" aria-hidden="true"><?= icone('building', 25) ?></span>
                <strong>Aucun site pour le moment</strong>
                <p>Ajoutez votre premier lieu d’intervention pour pouvoir créer des demandes professionnelles.</p>
                <?php if ($estAdmin && $villes): ?><a class="b2b-button" href="#ajouter-site"><?= icone('plus', 16) ?> Ajouter un site</a><?php endif; ?>
            </div>
        <?php else: ?>
            <div class="b2b-sites-grid" id="liste-sites-entreprise">
                <?php foreach ($sites as $site): ?>
                    <?php
                    $adresseSite = trim((string) ($site['quartier'] ?? '') . ', ' . (string) ($site['ville'] ?? ''), ', ');
                    $estSiteActif = ($site['statut'] ?? '') === 'actif';
                    $texteRecherche = trim(implode(' ', [
                        (string) ($site['nom'] ?? ''),
                        $adresseSite,
                        (string) ($site['details'] ?? ''),
                        (string) ($site['telephone_contact'] ?? ''),
                        (string) ($site['email_contact'] ?? ''),
                    ]));
                    ?>
                    <article class="b2b-site-card" data-site-texte="<?= $e($texteRecherche) ?>">
                        <header class="b2b-site-card__head">
                            <span class="b2b-site-card__icon" aria-hidden="true"><?= icone('building', 21) ?></span>
                            <span class="b2b-site-card__identity"><strong><?= $e($site['nom']) ?></strong><small><?= $e($adresseSite !== '' ? $adresseSite : 'Adresse à compléter') ?></small></span>
                            <span class="b2b-site-status <?= $estSiteActif ? 'b2b-site-status--actif' : 'b2b-site-status--inactif' ?>"><i aria-hidden="true"></i><?= $estSiteActif ? 'Actif' : 'Inactif' ?></span>
                        </header>
                        <div class="b2b-site-card__body">
                            <?php if (!empty($site['details'])): ?>
                                <div class="b2b-site-card__detail"><span><?= icone('pin', 15) ?></span><p><?= nl2br($e($site['details'])) ?></p></div>
                            <?php endif; ?>
                            <?php if (!empty($site['telephone_contact']) || !empty($site['email_contact'])): ?>
                                <div class="b2b-site-card__contact">
                                    <?php if (!empty($site['telephone_contact'])): ?><span><?= icone('phone', 15) ?> <?= $e($site['telephone_contact']) ?></span><?php endif; ?>
                                    <?php if (!empty($site['email_contact'])): ?><span><?= icone('message', 15) ?> <?= $e($site['email_contact']) ?></span><?php endif; ?>
                                </div>
                            <?php else: ?>
                                <p class="b2b-site-card__no-contact">Aucun contact renseigné</p>
                            <?php endif; ?>
                        </div>
                        <?php if ($estAdmin): ?>
                            <footer class="b2b-site-card__footer">
                                <?php if (!empty($site['adresse_id'])): ?>
                                    <details class="b2b-site-edit">
                                        <summary><?= icone('pencil', 15) ?> Modifier le site</summary>
                                        <div class="b2b-site-edit__content">
                                            <form method="post" class="b2b-form">
                                                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="modifier"><input type="hidden" name="site_id" value="<?= (int) $site['id'] ?>">
                                                <label>Nom du site<input name="nom" value="<?= $e($site['nom']) ?>" maxlength="100" required></label>
                                                <label>Ville<select name="ville_id" class="b2b-ville" data-zone-cible="zone-<?= (int) $site['id'] ?>" required><?php foreach ($villes as $ville): ?><option value="<?= (int) $ville['id'] ?>" <?= (int) $ville['id'] === (int) $site['ville_id'] ? 'selected' : '' ?>><?= $e($ville['nom']) ?></option><?php endforeach; ?></select></label>
                                                <label>Quartier / zone<select id="zone-<?= (int) $site['id'] ?>" name="zone_id" class="b2b-zone" data-zone-selection="<?= (int) $site['zone_id'] ?>" required></select></label>
                                                <label>Complément d’adresse<textarea name="details" maxlength="2000"><?= $e($site['details']) ?></textarea></label>
                                                <label>Téléphone du contact<input name="telephone_contact" type="tel" value="<?= $e($site['telephone_contact']) ?>" maxlength="20"></label>
                                                <label>E-mail du contact<input name="email_contact" type="email" value="<?= $e($site['email_contact']) ?>" maxlength="150"></label>
                                                <button class="b2b-button" type="submit"><?= icone('check', 16) ?> Enregistrer les modifications</button>
                                            </form>
                                            <form method="post" class="b2b-site-edit__status">
                                                <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="statut"><input type="hidden" name="site_id" value="<?= (int) $site['id'] ?>">
                                                <button class="b2b-button b2b-button--secondary" type="submit" name="statut" value="<?= $estSiteActif ? 'inactif' : 'actif' ?>"><?= $estSiteActif ? 'Désactiver le site' : 'Réactiver le site' ?></button>
                                            </form>
                                        </div>
                                    </details>
                                <?php else: ?>
                                    <p class="b2b-site-card__legacy"><?= icone('info', 15) ?> Site ancien : ajoutez un nouveau site avec une zone active pour créer des demandes.</p>
                                <?php endif; ?>
                            </footer>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
            <p id="sites-recherche-vide" class="b2b-sites-no-results" hidden>Aucun site ne correspond à votre recherche.</p>
        <?php endif; ?>
    </section>
    <?php if ($estAdmin): ?>
        <?php if ($villes): ?>
            <section class="b2b-sites-create" id="ajouter-site" aria-labelledby="ajouter-site-titre">
                <div class="b2b-sites-create__intro">
                    <span class="b2b-sites-create__icon" aria-hidden="true"><?= icone('plus', 20) ?></span>
                    <span class="b2b-eyebrow">AGRANDIR VOTRE RÉSEAU</span>
                    <h2 id="ajouter-site-titre">Ajouter un site</h2>
                    <p>Renseignez l’adresse d’un établissement et son contact pour faciliter le suivi de vos prochaines demandes.</p>
                </div>
                <form method="post" class="b2b-form b2b-sites-create__form">
                    <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>"><input type="hidden" name="action" value="creer">
                    <label>Nom du site<input name="nom" maxlength="100" placeholder="Ex. Agence du Plateau" required></label>
                    <div class="b2b-sites-create__row">
                        <label>Ville<select name="ville_id" class="b2b-ville" data-zone-cible="zone-nouveau" required><?php foreach ($villes as $ville): ?><option value="<?= (int) $ville['id'] ?>"><?= $e($ville['nom']) ?></option><?php endforeach; ?></select></label>
                        <label>Quartier / zone<select id="zone-nouveau" name="zone_id" class="b2b-zone" required></select></label>
                    </div>
                    <label>Complément d’adresse<textarea name="details" maxlength="2000" placeholder="Bâtiment, étage, repère…"></textarea></label>
                    <div class="b2b-sites-create__row">
                        <label>Téléphone du contact<input name="telephone_contact" type="tel" maxlength="20" placeholder="Téléphone professionnel"></label>
                        <label>E-mail du contact<input name="email_contact" type="email" maxlength="150" placeholder="contact@entreprise.com"></label>
                    </div>
                    <button class="b2b-button" type="submit"><?= icone('plus', 16) ?> Ajouter ce site</button>
                </form>
            </section>
        <?php else: ?>
            <div class="b2b-alert" role="status">Aucune ville avec des zones de service actives n’est disponible pour le moment.</div>
        <?php endif; ?>
    <?php endif; ?>
</main></div>
<script>
const zonesParVille = <?= json_encode($zonesParVille, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
document.querySelectorAll('.b2b-ville').forEach((ville) => {
    const zone = document.getElementById(ville.dataset.zoneCible);
    const remplir = () => {
        const selection = zone.dataset.zoneSelection || '';
        zone.replaceChildren();
        (zonesParVille[ville.value] || []).forEach((optionZone) => {
            const option = document.createElement('option');
            option.value = optionZone.id;
            option.textContent = optionZone.nom;
            option.selected = String(optionZone.id) === selection;
            zone.append(option);
        });
        if (!zone.options.length) {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = 'Aucune zone disponible';
            zone.append(option);
        }
        zone.dataset.zoneSelection = '';
    };
    ville.addEventListener('change', remplir);
    remplir();
});
const rechercheSites = document.getElementById('recherche-sites-entreprise');
if (rechercheSites) {
    const cartesSites = Array.from(document.querySelectorAll('.b2b-site-card'));
    const resultatVide = document.getElementById('sites-recherche-vide');
    const normaliserTexte = (texte) => texte.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('fr').trim();
    rechercheSites.addEventListener('input', () => {
        const terme = normaliserTexte(rechercheSites.value);
        let visibles = 0;
        cartesSites.forEach((carte) => {
            const correspond = normaliserTexte(carte.dataset.siteTexte || '').includes(terme);
            carte.hidden = !correspond;
            if (correspond) visibles += 1;
        });
        resultatVide.hidden = visibles !== 0;
    });
}
</script>
</body>
</html>
