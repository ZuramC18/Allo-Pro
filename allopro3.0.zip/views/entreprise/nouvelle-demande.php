<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';

$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$sites = $entrepriseModele->getSites($entrepriseId, true);
$contrats = $entrepriseModele->getContrats($entrepriseId);
$contratActif = null;
foreach ($contrats as $contrat) {
    if ($contrat['statut'] === 'actif' && $contrat['date_debut'] <= date('Y-m-d')
        && $contrat['date_fin'] >= date('Y-m-d')) {
        $contratActif = $contrat;
        break;
    }
}
$categories = (new Database())->getConnection()->query(
    "SELECT id, nom FROM categories WHERE parent_id IS NULL AND statut = 'active' ORDER BY nom"
)->fetchAll(PDO::FETCH_ASSOC);
$erreur = '';
$csrfKey = 'csrf_entreprise_demande';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $siteId = filter_var($_POST['site_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $categorieId = filter_var($_POST['categorie_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $description = is_string($_POST['description'] ?? null) ? trim($_POST['description']) : '';
    $urgence = is_string($_POST['urgence'] ?? null) ? $_POST['urgence'] : '';
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif ($siteId === false || $categorieId === false) {
        $erreur = 'Choisissez un site actif et une catégorie disponible.';
    } else {
        try {
            $numero = $entrepriseModele->creerDemandeSousContrat(
                $entrepriseId,
                (int) $_SESSION['user_id'],
                (int) $siteId,
                (int) $categorieId,
                $description,
                $urgence
            );
            $_SESSION['flash_entreprise'] = 'La demande ' . $numero . ' a été enregistrée. Notre équipe organisera son traitement.';
            header('Location: demandes.php?entreprise_id=' . $entrepriseId . '&nouvelle=1');
            exit;
        } catch (PDOException $exception) {
            error_log('Création demande entreprise ' . $entrepriseId . ' : ' . $exception->getMessage());
            $erreur = 'La demande n’a pas pu être enregistrée. Réessayez.';
        } catch (InvalidArgumentException | RuntimeException $exception) {
            $erreur = $exception->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Nouvelle demande — <?= $e($entreprise['nom']) ?></title><link rel="stylesheet" href="../../public/css/entreprise-b2b.css?v=<?= filemtime(__DIR__ . '/../../public/css/entreprise-b2b.css') ?>"><script src="../../public/js/entreprise-b2b.js?v=<?= filemtime(__DIR__ . '/../../public/js/entreprise-b2b.js') ?>" defer></script></head>
<body><div class="b2b-app"><?php include __DIR__ . '/../../includes/sidebar-entreprise.php'; ?><main class="b2b-main">
    <header class="b2b-header"><div><h1>Nouvelle demande</h1><p>La demande sera visible par les membres autorisés de <?= $e($entreprise['nom']) ?>.</p></div></header>
    <?php if ($erreur !== ''): ?><div class="b2b-alert" role="alert"><?= $e($erreur) ?></div><?php endif; ?>
    <?php if (!$sites): ?><section class="b2b-panel"><p>Ajoutez d’abord un site actif avant de créer une demande.</p><?php if ($entrepriseAutorisePermission('sites')): ?><a class="b2b-button" href="sites.php?entreprise_id=<?= $entrepriseId ?>">Gérer les sites</a><?php else: ?><p>Demandez à un administrateur de créer un site pour pouvoir envoyer une demande.</p><?php endif; ?></section>
    <?php elseif (!$contratActif): ?><section class="b2b-panel"><span class="b2b-eyebrow">CONTRAT REQUIS</span><h2>Aucun contrat actif</h2><p>Les interventions entreprise sont couvertes par un contrat distinct des demandes des particuliers. Demandez un devis pour mettre en place votre contrat B2B.</p><?php if ($entrepriseAutorisePermission('devis')): ?><a class="b2b-button" href="gestion.php?entreprise_id=<?= $entrepriseId ?>&amp;module=devis">Demander un devis</a><?php else: ?><p>Demandez à un administrateur d’envoyer une demande de devis.</p><?php endif; ?></section>
    <?php elseif ((int) $contratActif['credits_disponibles'] < 1): ?><section class="b2b-panel"><span class="b2b-eyebrow">CRÉDITS ÉPUISÉS</span><h2>Votre contrat n’a plus de crédit disponible</h2><p><?= (int) $contratActif['credits_utilises'] ?> crédit(s) consommé(s), <?= (int) $contratActif['credits_reserves'] ?> réservé(s) sur <?= (int) $contratActif['volume_credits'] ?>. Les missions en cours sont déjà prises en compte.</p><?php if ($entrepriseAutorisePermission('devis')): ?><a class="b2b-button" href="gestion.php?entreprise_id=<?= $entrepriseId ?>&amp;module=devis">Demander un renouvellement ou un devis</a><?php else: ?><p>Demandez à un administrateur d’envoyer une demande de devis.</p><?php endif; ?></section>
    <?php else: ?><section class="b2b-panel"><form method="post" class="b2b-form">
        <div class="b2b-contract-quota"><strong>Contrat #<?= (int) $contratActif['id'] ?></strong><span><?= (int) $contratActif['credits_disponibles'] ?> crédit<?= (int) $contratActif['credits_disponibles'] === 1 ? '' : 's' ?> disponible<?= (int) $contratActif['credits_disponibles'] === 1 ? '' : 's' ?></span><small>Un crédit sera réservé à la demande et consommé lorsque l’intervention sera terminée.</small></div>
        <input type="hidden" name="csrf" value="<?= $e($_SESSION[$csrfKey]) ?>">
        <label>Site concerné<select name="site_id" required><option value="">Choisir un site</option><?php foreach ($sites as $site): ?><option value="<?= (int) $site['id'] ?>" <?= (string) $site['id'] === (string) ($_POST['site_id'] ?? '') ? 'selected' : '' ?>><?= $e($site['nom'] . ' — ' . $site['quartier'] . ', ' . $site['ville']) ?></option><?php endforeach; ?></select></label>
        <label>Type de service<select name="categorie_id" required><option value="">Choisir une catégorie</option><?php foreach ($categories as $categorie): ?><option value="<?= (int) $categorie['id'] ?>" <?= (string) $categorie['id'] === (string) ($_POST['categorie_id'] ?? '') ? 'selected' : '' ?>><?= $e($categorie['nom']) ?></option><?php endforeach; ?></select></label>
        <label>Description du besoin<textarea name="description" maxlength="1000" required><?= $e($_POST['description'] ?? '') ?></textarea></label>
        <label>Niveau d’urgence<select name="urgence" required><option value="normale" <?= ($_POST['urgence'] ?? 'normale') === 'normale' ? 'selected' : '' ?>>Normale</option><option value="urgente" <?= ($_POST['urgence'] ?? '') === 'urgente' ? 'selected' : '' ?>>Urgente</option></select></label>
        <button class="b2b-button" type="submit">Envoyer la demande</button>
    </form></section><?php endif; ?>
</main></div></body></html>
