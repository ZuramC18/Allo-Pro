<?php
require_once __DIR__ . '/../../includes/auth-entreprise.php';
$factureId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($factureId === false) {
    http_response_code(404);
    exit('Facture introuvable.');
}
try {
    $facture = $entrepriseModele->getFichierFacture((int) $factureId, $entrepriseId);
} catch (RuntimeException $exception) {
    error_log('Téléchargement facture entreprise refusé ou fichier absent : ' . $exception->getMessage());
    http_response_code(404);
    exit('Facture introuvable.');
}
if (!$facture) {
    http_response_code(404);
    exit('Facture introuvable.');
}
$nom = preg_replace('/[^A-Za-z0-9._-]/', '_', (string) $facture['numero']) . '.pdf';
header('Content-Type: application/pdf');
header('Content-Length: ' . (string) filesize($facture['chemin_absolu']));
header('Content-Disposition: attachment; filename="' . $nom . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($facture['chemin_absolu']);
exit;
