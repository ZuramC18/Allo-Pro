<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('interventions');
require_once __DIR__ . '/../../models/AjustementCreneauAutomatique.php';
$nombreAjustementsCreneaux = (new AjustementCreneauAutomatique())->compterATraiter();
$rolePageCreneaux = 'coordinateur';
require __DIR__ . '/../commun/ajustements-creneaux.php';
