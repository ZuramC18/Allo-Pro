<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierAcces('interventions');
require_once __DIR__ . '/../../models/Intervention.php';

$interventionModel = new Intervention();
$csrfKey = 'csrf_file_refus_interventions';
if (empty($_SESSION[$csrfKey])) {
    $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
}

$erreur = '';
$messageSucces = is_string($_SESSION['flash_file_refus_interventions'] ?? null)
    ? $_SESSION['flash_file_refus_interventions']
    : '';
unset($_SESSION['flash_file_refus_interventions']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $fileId = filter_var($_POST['file_id'] ?? null, FILTER_VALIDATE_INT);
    $technicienId = filter_var($_POST['technicien_id'] ?? null, FILTER_VALIDATE_INT);
    if (!hash_equals($_SESSION[$csrfKey], $csrf)) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (!$fileId || !$technicienId) {
        $erreur = 'Choisissez un technicien valide pour réattribuer cette intervention.';
    } else {
        try {
            if ($interventionModel->reattribuerDepuisFile($fileId, $technicienId, (int) $_SESSION['user_id'])) {
                journaliser(
                    'mission.reattribuee_coordinateur',
                    'intervention',
                    $fileId,
                    null,
                    'Intervention réattribuée à un technicien par le coordinateur.'
                );
                $_SESSION['flash_file_refus_interventions'] = 'L’intervention a été réattribuée. Le nouveau technicien doit confirmer sa prise en charge.';
                header('Location: refus-interventions.php');
                exit;
            }
            $erreur = 'La file a changé ou le technicien choisi n’est plus disponible. Actualisez la page.';
        } catch (PDOException $exception) {
            error_log('Réattribution depuis la file coordinateur ' . $fileId . ' : ' . $exception->getMessage());
            $erreur = 'Une erreur est survenue pendant la réattribution. Réessayez.';
        }
    }
}

$fileAttente = $interventionModel->getFileAttenteCoordinateur();
$candidatsParFile = [];
foreach ($fileAttente as $element) {
    $candidatsParFile[(int) $element['file_id']] = $interventionModel->getTechniciensCompatiblesDemande(
        (int) $element['demande_id']
    );
}
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Refus d’interventions — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/coordinateur.css">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
    <style>
        .coord-refus { width: min(1120px, 100%); margin: 0 auto; padding: 32px 24px 48px; color: var(--coord-texte, #202337); }
        .coord-refus h1 { margin: 0 0 8px; font-size: clamp(24px, 4vw, 34px); }
        .coord-refus__intro { margin: 0 0 24px; color: var(--coord-texte-secondaire, #697086); }
        .coord-refus__message { margin-bottom: 16px; padding: 13px 16px; border-radius: 10px; background: #e9f8ef; color: #176b37; }
        .coord-refus__message--erreur { background: #fff0ed; color: #a52e1e; }
        .coord-refus__carte { display: grid; grid-template-columns: minmax(0, 1fr) minmax(240px, 300px); gap: 20px; margin: 14px 0; padding: 20px; border: 1px solid var(--coord-bordure, #e4e6ef); border-radius: 14px; background: var(--coord-carte, #fff); }
        .coord-refus__dossier { margin: 0 0 7px; font-weight: 750; }
        .coord-refus__meta, .coord-refus__motif { margin: 6px 0; color: var(--coord-texte-secondaire, #697086); font-size: 14px; line-height: 1.5; }
        .coord-refus__motif { padding: 10px 12px; border-radius: 8px; background: var(--coord-fond, #f5f6fa); white-space: pre-wrap; overflow-wrap: anywhere; }
        .coord-refus__form { display: grid; align-content: center; gap: 9px; }
        .coord-refus__form label { font-size: 13px; font-weight: 650; }
        .coord-refus__form select, .coord-refus__form button { min-height: 42px; width: 100%; border: 1px solid var(--coord-bordure, #d9dce7); border-radius: 8px; padding: 9px 11px; font: inherit; }
        .coord-refus__form button { border: 0; background: #6857d8; color: #fff; font-weight: 700; cursor: pointer; }
        .coord-refus__vide { padding: 48px 20px; border: 1px dashed var(--coord-bordure, #d9dce7); border-radius: 14px; color: var(--coord-texte-secondaire, #697086); text-align: center; }
        @media (max-width: 720px) { .coord-refus { padding: 22px 14px 36px; } .coord-refus__carte { grid-template-columns: 1fr; gap: 12px; padding: 16px; } }
    </style>
</head>
<body>
<div class="coord-shell">
<?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
<main class="coord-main">
<section class="coord-refus">
    <h1>Refus d’interventions</h1>
    <p class="coord-refus__intro">Examinez les missions refusées et choisissez un technicien actif ayant une compétence compatible pour les réattribuer.</p>

    <?php if ($messageSucces !== ''): ?><div class="coord-refus__message" role="status"><?= $echapper($messageSucces) ?></div><?php endif; ?>
    <?php if ($erreur !== ''): ?><div class="coord-refus__message coord-refus__message--erreur" role="alert"><?= $echapper($erreur) ?></div><?php endif; ?>

    <?php if (!$fileAttente): ?>
        <div class="coord-refus__vide">Aucun refus n’attend actuellement de traitement.</div>
    <?php else: ?>
        <?php foreach ($fileAttente as $element): ?>
            <article class="coord-refus__carte">
                <div>
                    <p class="coord-refus__dossier"><?= $echapper($element['numero_dossier']) ?> · <?= $echapper($element['categorie_nom']) ?></p>
                    <?php if (!empty($element['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($element['entreprise_b2b_nom']) ? ' · ' . $echapper($element['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                    <p class="coord-refus__meta">
                        <?= $element['urgence'] === 'urgente' ? 'Urgente · ' : '' ?>
                        <?= $echapper($element['client_nom']) ?> · <?= $echapper($element['quartier']) ?>, <?= $echapper($element['ville']) ?>
                    </p>
                    <p class="coord-refus__meta"><?= $echapper($element['description']) ?></p>
                    <p class="coord-refus__meta">
                        Refusé par <?= $echapper($element['technicien_refus_nom']) ?>
                        <?php if (!empty($element['partenaire_refus_nom'])): ?> · <?= $echapper($element['partenaire_refus_nom']) ?><?php endif; ?>
                        · <?= $echapper(date('d/m/Y à H:i', strtotime($element['date_creation']))) ?>
                    </p>
                    <?php if (!empty($element['motif'])): ?><p class="coord-refus__motif"><?= $echapper($element['motif']) ?></p><?php endif; ?>
                </div>
                <?php $candidats = $candidatsParFile[(int) $element['file_id']] ?? []; ?>
                <?php if ($candidats): ?>
                    <form method="POST" class="coord-refus__form" onsubmit="return confirm('Réattribuer cette intervention au technicien sélectionné ?');">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION[$csrfKey]) ?>">
                        <input type="hidden" name="file_id" value="<?= (int) $element['file_id'] ?>">
                        <label for="technicien-<?= (int) $element['file_id'] ?>">Nouveau technicien</label>
                        <select id="technicien-<?= (int) $element['file_id'] ?>" name="technicien_id" required>
                            <option value="">Choisir un technicien</option>
                            <?php foreach ($candidats as $candidat): ?>
                                <option value="<?= (int) $candidat['id'] ?>"><?= $echapper($candidat['nom']) ?> · <?= $echapper($candidat['competences'] ?? 'Compétences non renseignées') ?> · <?= $echapper($candidat['nom_entreprise']) ?> (<?= $echapper($candidat['zones_intervention'] ?? 'Zones non renseignées') ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit">Réattribuer la mission</button>
                    </form>
                <?php else: ?>
                    <p class="coord-refus__meta">Aucun technicien actif ayant une compétence compatible n’est disponible. Cette demande reste dans la file.</p>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>
</section>
</main>
</div>
</body>
</html>
