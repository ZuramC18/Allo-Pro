<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('partenaires');
verifierAcces('techniciens');
require_once __DIR__ . '/../../models/VueOperationnelleCoordinateur.php';

$vue = new VueOperationnelleCoordinateur();
$ressources = $vue->getRessources();
$partenaires = $ressources['partenaires'];
$techniciens = $ressources['techniciens'];
$techniciensDisponibles = count(array_filter($techniciens, static fn($technicien) => $technicien['disponible']));
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ressources — Coordination ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/coordinateur.css">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main">
        <div class="coord-page">
            <header class="coord-page__entete">
                <div>
                    <span class="coord-page__surtitre">Réseau partenaire</span>
                    <h1>Partenaires & techniciens</h1>
                    <p>Consultez la couverture, les compétences, la charge et la disponibilité estimée du réseau.</p>
                </div>
            </header>
            <section class="coord-kpis" aria-label="Capacité actuelle">
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= count($partenaires) ?></span><span class="coord-kpi__libelle">Partenaires actifs</span></article>
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= count($techniciens) ?></span><span class="coord-kpi__libelle">Techniciens actifs</span></article>
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= $techniciensDisponibles ?></span><span class="coord-kpi__libelle">Disponibles maintenant</span></article>
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= count($techniciens) - $techniciensDisponibles ?></span><span class="coord-kpi__libelle">Occupés / indisponibles</span></article>
            </section>

            <div class="coord-colonnes">
                <section class="coord-panel">
                    <div class="coord-panel__entete"><h2>Partenaires disponibles</h2><span class="coord-badge coord-badge--vert"><?= count(array_filter($partenaires, static fn($p) => (int) $p['techniciens_disponibles'] > 0)) ?> avec capacité</span></div>
                    <?php if (!$partenaires): ?>
                        <div class="coord-empty">Aucun partenaire actif.</div>
                    <?php else: ?>
                        <div class="coord-resource-list">
                            <?php foreach ($partenaires as $partenaire):
                                $capables = (int) $partenaire['techniciens_disponibles'];
                            ?>
                                <article class="coord-resource">
                                    <div>
                                        <div class="coord-resource__nom"><?= $e($partenaire['nom_entreprise']) ?></div>
                                        <span class="coord-table__secondaire"><?= $e(ucfirst((string) $partenaire['niveau'])) ?></span>
                                    </div>
                                    <div class="coord-resource__detail">
                                        <strong>Zones :</strong> <?= $e($partenaire['zones'] ?: 'Aucune zone enregistrée') ?>
                                    </div>
                                    <span class="coord-badge <?= $capables ? 'coord-badge--vert' : 'coord-badge--ambre' ?>">
                                        <?= $capables ?>/<?= (int) $partenaire['techniciens_actifs'] ?> techniciens dispo.
                                    </span>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>

                <section class="coord-panel">
                    <div class="coord-panel__entete"><h2>Techniciens actifs</h2><span class="coord-badge coord-badge--bleu"><?= $techniciensDisponibles ?> disponibles</span></div>
                    <?php if (!$techniciens): ?>
                        <div class="coord-empty">Aucun technicien actif chez les partenaires actifs.</div>
                    <?php else: ?>
                        <div class="coord-resource-list">
                            <?php foreach ($techniciens as $technicien):
                                $charge = (int) $technicien['charge'];
                                $chargePct = min(100, $charge * 25);
                            ?>
                                <article class="coord-resource">
                                    <div>
                                        <div class="coord-resource__nom"><?= $e($technicien['nom']) ?></div>
                                        <span class="coord-table__secondaire"><?= $e($technicien['nom_entreprise']) ?></span>
                                    </div>
                                    <div class="coord-resource__detail">
                                        <strong>Compétences :</strong> <?= $e($technicien['competences'] ?: 'Non renseignées') ?>
                                        <span class="coord-table__secondaire">Charge active : <?= $charge ?> mission<?= $charge > 1 ? 's' : '' ?></span>
                                        <div class="coord-progress" role="img" aria-label="Charge de <?= $charge ?> mission<?= $charge > 1 ? 's' : '' ?>"><span style="width:<?= $chargePct ?>%"></span></div>
                                    </div>
                                    <span class="coord-badge <?= $technicien['disponible'] ? 'coord-badge--vert' : 'coord-badge--ambre' ?>">
                                        <?= $technicien['disponible'] ? 'Disponible' : (!empty($technicien['indisponible_actuellement']) ? 'Indisponible maintenant' : 'En mission') ?>
                                    </span>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <p class="coord-legend">La disponibilité est estimée à l’instant présent : technicien actif, aucune mission affectée non terminée, et aucun créneau d’indisponibilité déclaré pour l’heure actuelle. La présence en ligne n’est pas disponible dans les données actuelles.</p>
                </section>
            </div>
            <section class="coord-panel">
                <div class="coord-panel__entete"><h2>Zones couvertes et compétences</h2></div>
                <p class="coord-legend">Les zones affichées sont celles enregistrées pour chaque partenaire ; les compétences sont celles renseignées pour chaque technicien. Lors de l’affectation, la compatibilité métier et les zones de la demande restent vérifiées par les règles d’attribution.</p>
            </section>
        </div>
    </main>
</div>
</body>
</html>
