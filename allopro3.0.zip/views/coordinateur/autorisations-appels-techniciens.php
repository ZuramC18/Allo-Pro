<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur']);
verifierAcces('messagerie');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Autorisations d’appel technicien — ALLÔ PRO Coordinateur</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/dashboard.css">
    <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <link rel="stylesheet" href="../../public/css/admin.css">
    <link rel="stylesheet" href="../../public/css/autorisations-appels-techniciens.css?v=<?= filemtime(__DIR__ . '/../../public/css/autorisations-appels-techniciens.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-autorisations-appels.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-autorisations-appels.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-coordinateur-autorisations-appels">
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main">
        <?php include __DIR__ . '/../../includes/autorisation-appel-technicien-page.php'; ?>
    </main>
</div>
</body>
</html>
