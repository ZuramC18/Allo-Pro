<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('demandes');
require_once __DIR__ . '/../../models/RechercheDossiersCoordinateur.php';

$rechercheClient = trim(is_string($_GET['client'] ?? null) ? $_GET['client'] : '');
$rechercheIntervenant = trim(is_string($_GET['intervenant'] ?? null) ? $_GET['intervenant'] : '');
$erreurs = [];
$resultatsClient = [];
$resultatsIntervenant = [];
$limiteResultats = 50;

foreach (['client' => $rechercheClient, 'intervenant' => $rechercheIntervenant] as $champ => $terme) {
    if (mb_strlen($terme) > 120) {
        $erreurs[$champ] = 'La recherche ne peut pas dépasser 120 caractères.';
    }
}

$recherche = new RechercheDossiersCoordinateur();
if ($rechercheClient !== '' && !isset($erreurs['client'])) {
    $resultatsClient = $recherche->parClientNumeroOuTelephone($rechercheClient, $limiteResultats);
}
if ($rechercheIntervenant !== '' && !isset($erreurs['intervenant'])) {
    $resultatsIntervenant = $recherche->parPartenaireOuTechnicien($rechercheIntervenant, $limiteResultats);
}

$e = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$statuts = [
    'nouvelle' => 'Nouvelle',
    'attribuee' => 'Attribuée',
    'attribuee_a_un_partenaire' => 'Attribuée à un partenaire',
    'attribuee_automatiquement' => 'Attribuée automatiquement',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$statutsIntervention = [
    'en_attente' => 'En attente du technicien',
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'Intervention en cours',
    'terminee' => 'Terminée',
    'refusee' => 'Refusée',
    'annulee' => 'Annulée',
];
$rendreResultats = static function (array $dossiers, string $aucun, int $limite) use ($e, $statuts, $statutsIntervention): void {
    if (!$dossiers) {
        echo '<div class="coord-empty">' . $e($aucun) . '</div>';
        return;
    }

    foreach ($dossiers as $dossier) {
        $statutMission = $dossier['intervention_statut'] ?? null;
        $statut = $statutMission
            ? ($statutsIntervention[$statutMission] ?? str_replace('_', ' ', $statutMission))
            : ($statuts[$dossier['demande_statut']] ?? str_replace('_', ' ', $dossier['demande_statut']));
        ?>
        <article class="coord-recherche__resultat">
            <div class="coord-recherche__resultat-entete">
                <div>
                    <strong><?= $e($dossier['numero_dossier']) ?></strong>
                    <?php if (!empty($dossier['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($dossier['entreprise_b2b_nom']) ? ' · ' . $e($dossier['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                    <span class="coord-badge <?= $dossier['urgence'] === 'urgente' ? 'coord-badge--rouge' : 'coord-badge--bleu' ?>"><?= $e(ucfirst($dossier['urgence'])) ?></span>
                </div>
                <span class="coord-badge"><?= $e($statut) ?></span>
            </div>
            <div class="coord-recherche__infos">
                <span><small>Client</small><?= $e($dossier['client_nom'] ?: 'Client') ?></span>
                <span><small>Téléphone</small><?= $e($dossier['client_telephone'] ?: 'Non renseigné') ?></span>
                <span><small>Catégorie</small><?= $e($dossier['categorie_nom']) ?></span>
                <span><small>Partenaire</small><?= $e($dossier['partenaire_nom'] ?: 'Non attribué') ?></span>
                <span><small>Technicien</small><?= $e($dossier['technicien_nom'] ?: 'Non attribué') ?></span>
            </div>
            <a class="coord-action" href="traiter-demande.php?id=<?= (int) $dossier['demande_id'] ?>">Ouvrir le dossier</a>
        </article>
        <?php
    }
    if (count($dossiers) === $limite) {
        echo '<p class="coord-legend">Les ' . $limite . ' premiers résultats sont affichés. Précisez votre recherche pour affiner.</p>';
    }
};
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Recherche de dossiers — ALLÔ PRO Coordinateur</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main">
        <div class="coord-page coord-recherche">
            <header class="coord-page__entete">
                <div>
                    <span class="coord-page__surtitre">Pilotage</span>
                    <h1>Recherche de dossiers</h1>
                    <p>Retrouvez un dossier par les coordonnées du client, son numéro ou le professionnel affecté.</p>
                </div>
            </header>

            <section class="coord-panel coord-recherche__bloc" aria-labelledby="recherche-client-titre">
                <h2 id="recherche-client-titre">Rechercher par client ou numéro de dossier</h2>
                <form method="GET" class="coord-recherche__formulaire">
                    <label class="sr-only" for="recherche-client">Nom du client, numéro de dossier ou téléphone</label>
                    <input id="recherche-client" name="client" type="search" maxlength="120" value="<?= $e($rechercheClient) ?>" placeholder="Nom du client, AP-2026-000001 ou téléphone" autocomplete="off">
                    <input type="hidden" name="intervenant" value="<?= $e($rechercheIntervenant) ?>">
                    <button type="submit" class="coord-action">Rechercher</button>
                </form>
                <?php if (isset($erreurs['client'])): ?><p class="coord-recherche__erreur" role="alert"><?= $e($erreurs['client']) ?></p><?php endif; ?>
                <?php if ($rechercheClient !== '' && !isset($erreurs['client'])): ?>
                    <p class="coord-recherche__compteur"><?= count($resultatsClient) ?> résultat<?= count($resultatsClient) === 1 ? '' : 's' ?></p>
                    <div class="coord-recherche__resultats">
                        <?php $rendreResultats($resultatsClient, 'Aucun dossier ne correspond à cette recherche.', $limiteResultats); ?>
                    </div>
                <?php endif; ?>
            </section>

            <section class="coord-panel coord-recherche__bloc" aria-labelledby="recherche-intervenant-titre">
                <h2 id="recherche-intervenant-titre">Rechercher par partenaire ou technicien</h2>
                <form method="GET" class="coord-recherche__formulaire">
                    <label class="sr-only" for="recherche-intervenant">Nom du partenaire ou du technicien</label>
                    <input id="recherche-intervenant" name="intervenant" type="search" maxlength="120" value="<?= $e($rechercheIntervenant) ?>" placeholder="Nom du partenaire ou du technicien" autocomplete="off">
                    <input type="hidden" name="client" value="<?= $e($rechercheClient) ?>">
                    <button type="submit" class="coord-action">Rechercher</button>
                </form>
                <?php if (isset($erreurs['intervenant'])): ?><p class="coord-recherche__erreur" role="alert"><?= $e($erreurs['intervenant']) ?></p><?php endif; ?>
                <?php if ($rechercheIntervenant !== '' && !isset($erreurs['intervenant'])): ?>
                    <p class="coord-recherche__compteur"><?= count($resultatsIntervenant) ?> résultat<?= count($resultatsIntervenant) === 1 ? '' : 's' ?></p>
                    <div class="coord-recherche__resultats">
                        <?php $rendreResultats($resultatsIntervenant, 'Aucun dossier associé à ce partenaire ou technicien.', $limiteResultats); ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </main>
</div>
</body>
</html>
