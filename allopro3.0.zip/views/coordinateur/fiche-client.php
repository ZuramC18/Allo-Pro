<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur']);
verifierAcces('demandes');
require __DIR__ . '/../../includes/fiche-client-equipe.php';
