<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('interventions');
require_once __DIR__ . '/../../models/VueOperationnelleCoordinateur.php';

$vue = new VueOperationnelleCoordinateur();
$parametres = new Parametre();
$slaUrgentHeures = $parametres->getSlaDemandeUrgenteHeures();
$slaNormalHeures = $parametres->getSlaDemandeNormaleHeures();
$missions = $vue->getMissions();
$indicateurs = $vue->getIndicateurs();
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$libellesMission = [
    'en_attente' => 'En attente du technicien',
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé sur place',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'Intervention en cours',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Missions — Coordination ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/coordinateur.css">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main">
        <div class="coord-page">
            <header class="coord-page__entete">
                <div>
                    <span class="coord-page__surtitre">Dispatch / suivi opérationnel</span>
                    <h1>Missions</h1>
                    <p>Suivez les missions attribuées, les confirmations technicien et les créneaux clients.</p>
                </div>
                <a class="coord-action" href="demandes.php">Demandes à affecter</a>
            </header>
            <section class="coord-kpis" aria-label="Synthèse des missions">
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= count($missions) ?></span><span class="coord-kpi__libelle">Missions actives</span></article>
                <article class="coord-kpi <?= (int) $indicateurs['missions_en_attente'] ? 'coord-kpi--attention' : '' ?>"><span class="coord-kpi__valeur"><?= (int) $indicateurs['missions_en_attente'] ?></span><span class="coord-kpi__libelle">En attente de réponse</span></article>
                <article class="coord-kpi <?= (int) $indicateurs['sla_depasse'] ? 'coord-kpi--alerte' : '' ?>"><span class="coord-kpi__valeur"><?= (int) $indicateurs['sla_depasse'] ?></span><span class="coord-kpi__libelle">Affectations hors SLA</span></article>
                <article class="coord-kpi <?= (int) $indicateurs['creneaux_depasse'] ? 'coord-kpi--alerte' : '' ?>"><span class="coord-kpi__valeur"><?= (int) $indicateurs['creneaux_depasse'] ?></span><span class="coord-kpi__libelle">Créneaux souhaités passés</span></article>
            </section>
            <section class="coord-panel">
                <div class="coord-panel__entete">
                    <h2>Missions en attente et en cours</h2>
                    <span class="coord-badge coord-badge--bleu"><?= count($missions) ?> dossier<?= count($missions) > 1 ? 's' : '' ?></span>
                </div>
                <?php if (!$missions): ?>
                    <div class="coord-empty">Aucune mission active pour le moment.</div>
                <?php else: ?>
                    <div class="coord-table-wrap">
                        <table class="coord-table">
                            <thead><tr><th>Dossier</th><th>Client / lieu</th><th>Partenaire / technicien</th><th>Statut</th><th>Créneau</th><th>Suivi</th></tr></thead>
                            <tbody>
                            <?php foreach ($missions as $mission):
                                $dateCreneauMission = $mission['date_creneau_planifie'] ?: $mission['date_creneau_souhaite'];
                                $heureCreneauMission = $mission['heure_creneau_planifie'] ?? $mission['heure_creneau_souhaitee'];
                                $retardCreneau = false;
                                if (!empty($dateCreneauMission) && $heureCreneauMission !== null) {
                                    $finCreneau = strtotime($dateCreneauMission . ' ' . sprintf('%02d:00:00', (int) $heureCreneauMission)) + 3600;
                                    $retardCreneau = $finCreneau < time();
                                }
                                $badge = $mission['intervention_statut'] === 'en_attente' ? 'coord-badge--ambre' : 'coord-badge--bleu';
                            ?>
                                <tr>
                                    <td><span class="coord-table__principal"><?= $e($mission['numero_dossier']) ?></span>
                                        <span class="coord-table__secondaire"><?= $e($mission['categorie_nom']) ?></span>
                                        <?php if (!empty($mission['est_demande_entreprise'])): ?><span class="coord-table__secondaire badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($mission['entreprise_b2b_nom']) ? ' · ' . $e($mission['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                                        <?php if ($mission['urgence'] === 'urgente'): ?><span class="coord-table__secondaire"><span class="coord-badge coord-badge--rouge">Urgente</span></span><?php endif; ?>
                                    </td>
                                    <td><span class="coord-table__principal"><?= $e($mission['client_nom']) ?></span><span class="coord-table__secondaire"><?= $e(trim($mission['quartier'] . ', ' . $mission['ville'], ', ')) ?></span></td>
                                    <td><span class="coord-table__principal"><?= $e($mission['nom_entreprise'] ?: 'Partenaire non renseigné') ?></span><span class="coord-table__secondaire"><?= $e($mission['technicien_nom'] ?: 'Technicien à confirmer') ?></span></td>
                                    <td><span class="coord-badge <?= $badge ?>"><?= $e($libellesMission[$mission['intervention_statut']] ?? $mission['intervention_statut']) ?></span></td>
                                    <td>
                                        <?php if (!empty($dateCreneauMission) && $heureCreneauMission !== null): ?>
                                            <?= $e(date('d/m/Y', strtotime($dateCreneauMission))) ?><span class="coord-table__secondaire"><?= sprintf('%02d:00–%02d:00', (int) $heureCreneauMission, ((int) $heureCreneauMission + 1) % 24) ?></span>
                                            <?php if ($retardCreneau): ?><span class="coord-table__secondaire"><span class="coord-badge coord-badge--ambre">À reconfirmer avec le client</span></span><?php endif; ?>
                                        <?php else: ?><span class="coord-table__secondaire">Non précisé</span><?php endif; ?>
                                    </td>
                                    <td><a class="coord-action" href="traiter-demande.php?id=<?= (int) $mission['demande_id'] ?>">Ouvrir</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                <p class="coord-legend">Le SLA <?= $slaUrgentHeures ?> h / <?= $slaNormalHeures ?> h mesure le délai d’affectation depuis la transmission du dossier par le conseiller. Les créneaux souhaités sont des préférences non réservées ; un créneau passé déclenche un rappel pour confirmer le suivi, mais ne constitue pas un retard contractuel.</p>
            </section>
        </div>
    </main>
</div>
</body>
</html>
