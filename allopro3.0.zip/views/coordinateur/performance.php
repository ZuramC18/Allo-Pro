<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('statistiques');
require_once __DIR__ . '/../../models/VueOperationnelleCoordinateur.php';

$periodes = [30 => '30 jours', 90 => '90 jours', 365 => '12 mois', 0 => 'Depuis toujours'];
$periode = filter_var($_GET['periode'] ?? 90, FILTER_VALIDATE_INT);
if (!is_int($periode) || !array_key_exists($periode, $periodes)) {
    $periode = 90;
}
$performances = (new VueOperationnelleCoordinateur())->getPerformancePartenaires($periode);
$totalTerminees = array_sum(array_column($performances, 'missions_terminees'));
$totalAttribuees = array_sum(array_column($performances, 'missions_attribuees'));
$totalAvis = array_sum(array_column($performances, 'nombre_avis'));
$sommeNotesPonderee = 0.0;
foreach ($performances as $performance) {
    if ($performance['note_moyenne'] !== null) {
        $sommeNotesPonderee += (float) $performance['note_moyenne'] * (int) $performance['nombre_avis'];
    }
}
$noteGlobale = $totalAvis ? $sommeNotesPonderee / $totalAvis : null;
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Performance partenaires — Coordination ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/coordinateur.css">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main">
        <div class="coord-page">
            <header class="coord-page__entete">
                <div>
                    <span class="coord-page__surtitre">Qualité du réseau</span>
                    <h1>Performance partenaires</h1>
                    <p>Historique des missions, retours clients et refus pour les partenaires actifs.</p>
                </div>
                <form method="get" class="coord-periode">
                    <label for="periode">Période</label>
                    <select id="periode" name="periode" onchange="this.form.submit()">
                        <?php foreach ($periodes as $jours => $label): ?>
                            <option value="<?= (int) $jours ?>" <?= $periode === $jours ? 'selected' : '' ?>><?= $e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </header>
            <section class="coord-kpis" aria-label="Synthèse de performance">
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= $totalAttribuees ?></span><span class="coord-kpi__libelle">Missions attribuées</span></article>
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= $totalTerminees ?></span><span class="coord-kpi__libelle">Missions terminées</span></article>
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= $totalAvis ? number_format((float) $noteGlobale, 1, ',', '') . '/5' : '—' ?></span><span class="coord-kpi__libelle">Note moyenne pondérée<?= $totalAvis ? ' · ' . $totalAvis . ' avis' : '' ?></span></article>
                <article class="coord-kpi"><span class="coord-kpi__valeur"><?= count($performances) ?></span><span class="coord-kpi__libelle">Partenaires actifs évalués</span></article>
            </section>
            <section class="coord-panel">
                <div class="coord-panel__entete"><h2>Indicateurs par partenaire · <?= $e($periodes[$periode]) ?></h2></div>
                <?php if (!$performances): ?>
                    <div class="coord-empty">Aucun partenaire actif à afficher.</div>
                <?php else: ?>
                    <div class="coord-table-wrap">
                        <table class="coord-table">
                            <thead><tr><th>Partenaire</th><th>Missions attribuées</th><th>Terminées</th><th>Taux d’achèvement</th><th>Affectation → clôture</th><th>Avis clients</th><th>Refus techniciens</th></tr></thead>
                            <tbody>
                            <?php foreach ($performances as $performance):
                                $taux = $performance['taux_achevement'];
                                $duree = $performance['duree_moyenne_minutes'] !== null ? (int) round((float) $performance['duree_moyenne_minutes']) : null;
                            ?>
                                <tr>
                                    <td><span class="coord-table__principal"><?= $e($performance['nom_entreprise']) ?></span><span class="coord-table__secondaire"><?= $e(ucfirst((string) $performance['niveau'])) ?></span></td>
                                    <td><?= (int) $performance['missions_attribuees'] ?></td>
                                    <td><?= (int) $performance['missions_terminees'] ?></td>
                                    <td>
                                        <?php if ($taux !== null): ?>
                                            <span class="coord-badge <?= $taux >= 80 ? 'coord-badge--vert' : ($taux >= 50 ? 'coord-badge--ambre' : 'coord-badge--rouge') ?>"><?= (int) $taux ?> %</span>
                                        <?php else: ?><span class="coord-table__secondaire">Pas encore de mission</span><?php endif; ?>
                                    </td>
                                    <td><?= $duree !== null ? ($duree >= 60 ? floor($duree / 60) . ' h ' . ($duree % 60) . ' min' : $duree . ' min') : '—' ?></td>
                                    <td>
                                        <?php if ($performance['note_moyenne'] !== null): ?>
                                            <span class="coord-table__principal"><?= number_format((float) $performance['note_moyenne'], 1, ',', '') ?>/5</span>
                                            <span class="coord-table__secondaire"><?= (int) $performance['nombre_avis'] ?> avis</span>
                                        <?php else: ?>—<?php endif; ?>
                                    </td>
                                    <td><?= (int) $performance['refus_techniciens'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                <p class="coord-legend">Le taux d’achèvement correspond aux missions terminées divisées par les missions attribuées sur la période. La durée mesure le temps entre l’affectation et la clôture enregistrées. Les refus comptent les refus techniciens enregistrés pendant la période.</p>
            </section>
        </div>
    </main>
</div>
</body>
</html>
