<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur']);
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../includes/AvatarProfil.php';

$userModel = new User();
$userId = (int) $_SESSION['user_id'];
$moi = $userModel->getById($userId);
if (!$moi || ($moi['role'] ?? '') !== 'coordinateur') {
    http_response_code(404);
    exit('Compte coordinateur introuvable.');
}

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$erreur = '';
$succes = is_string($_SESSION['flash_profil_coordinateur'] ?? null)
    ? $_SESSION['flash_profil_coordinateur']
    : '';
unset($_SESSION['flash_profil_coordinateur']);
$prenomSaisi = (string) ($moi['prenom'] ?? '');
$nomSaisi = (string) ($moi['nom'] ?? '');
$telephoneSaisi = (string) ($moi['telephone'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
        http_response_code(403);
        $erreur = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } else {
        $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
        try {
            if ($action === 'profil') {
                $prenomSaisi = trim(is_string($_POST['prenom'] ?? null) ? $_POST['prenom'] : '');
                $nomSaisi = trim(is_string($_POST['nom'] ?? null) ? $_POST['nom'] : '');
                $telephoneSaisi = trim(is_string($_POST['telephone'] ?? null) ? $_POST['telephone'] : '');

                if ($prenomSaisi === '' || $nomSaisi === '') {
                    $erreur = 'Le prénom et le nom sont obligatoires.';
                } elseif (mb_strlen($prenomSaisi) > 100 || mb_strlen($nomSaisi) > 100) {
                    $erreur = 'Le prénom et le nom ne doivent pas dépasser 100 caractères.';
                } elseif (mb_strlen($telephoneSaisi) > 20) {
                    $erreur = 'Le numéro de téléphone ne doit pas dépasser 20 caractères.';
                } elseif (!$userModel->mettreAJourProfilInterne(
                    $userId,
                    $prenomSaisi,
                    $nomSaisi,
                    $telephoneSaisi !== '' ? $telephoneSaisi : null
                )) {
                    throw new RuntimeException('Les informations du profil n’ont pas pu être enregistrées.');
                } else {
                    $_SESSION['nom'] = $nomSaisi;
                    $_SESSION['flash_profil_coordinateur'] = 'Vos informations ont été mises à jour.';
                    header('Location: profil.php');
                    exit;
                }
            } elseif (in_array($action, ['photo_profil', 'supprimer_photo', 'avatar_initiales'], true)) {
                if ($action === 'photo_profil') {
                    $nouveauChemin = AvatarProfil::stocker($_FILES['photo_profil'] ?? [], 'equipe');
                    if (!$userModel->mettreAJourPhotoProfilInterne($userId, $nouveauChemin)) {
                        AvatarProfil::supprimer($nouveauChemin);
                        throw new RuntimeException('La photo n’a pas pu être associée à votre compte.');
                    }
                    AvatarProfil::supprimer($moi['photo_profil'] ?? null);
                    $_SESSION['photo_profil'] = $nouveauChemin;
                    $_SESSION['avatar_initiales'] = false;
                    $_SESSION['flash_profil_coordinateur'] = 'Votre photo de profil a été mise à jour.';
                } elseif ($action === 'supprimer_photo') {
                    if (!$userModel->supprimerPhotoProfilInterne($userId)) {
                        throw new RuntimeException('La photo n’a pas pu être supprimée.');
                    }
                    AvatarProfil::supprimer($moi['photo_profil'] ?? null);
                    $_SESSION['photo_profil'] = null;
                    $_SESSION['flash_profil_coordinateur'] = 'Votre photo a été supprimée.';
                } else {
                    $afficherInitiales = ($_POST['avatar_initiales'] ?? '') === '1';
                    if (!$userModel->definirAvatarInitialesInterne($userId, $afficherInitiales)) {
                        throw new RuntimeException('La préférence d’affichage n’a pas pu être enregistrée.');
                    }
                    $_SESSION['avatar_initiales'] = $afficherInitiales;
                    $_SESSION['flash_profil_coordinateur'] = $afficherInitiales
                        ? 'Les initiales seront affichées à la place de la photo.'
                        : 'La photo sera affichée lorsqu’elle est disponible.';
                }
                header('Location: profil.php');
                exit;
            } elseif ($action === 'mot_de_passe') {
                $actuel = is_string($_POST['mot_de_passe_actuel'] ?? null) ? $_POST['mot_de_passe_actuel'] : '';
                $nouveau = is_string($_POST['nouveau_mot_de_passe'] ?? null) ? $_POST['nouveau_mot_de_passe'] : '';
                $confirmation = is_string($_POST['confirmation_mot_de_passe'] ?? null) ? $_POST['confirmation_mot_de_passe'] : '';

                if ($actuel === '' || $nouveau === '' || $confirmation === '') {
                    $erreur = 'Remplissez tous les champs du changement de mot de passe.';
                } elseif (strlen($nouveau) < 8) {
                    $erreur = 'Le nouveau mot de passe doit contenir au moins 8 caractères.';
                } elseif ($nouveau !== $confirmation) {
                    $erreur = 'La confirmation ne correspond pas au nouveau mot de passe.';
                } elseif ($nouveau === $actuel) {
                    $erreur = 'Choisissez un mot de passe différent de l’actuel.';
                } else {
                    $resultat = $userModel->changerMotDePasseInterne($userId, $actuel, $nouveau);
                    if ($resultat === 'mot_de_passe_incorrect') {
                        $erreur = 'Le mot de passe actuel est incorrect.';
                    } elseif ($resultat === 'ok') {
                        journaliser('coordinateur.mot_de_passe_modifie', 'utilisateur', $userId, $moi['matricule'] ?? null, 'Mot de passe coordinateur modifié');
                        $_SESSION['flash_profil_coordinateur'] = 'Votre mot de passe a été modifié.';
                        header('Location: profil.php');
                        exit;
                    } else {
                        throw new RuntimeException('Le mot de passe n’a pas pu être modifié. Réessayez.');
                    }
                }
            } else {
                http_response_code(400);
                $erreur = 'La demande n’a pas pu être traitée. Rechargez la page et réessayez.';
            }
        } catch (RuntimeException $exception) {
            $erreur = $exception->getMessage();
        } catch (PDOException $exception) {
            error_log('Mise à jour profil coordinateur ' . $userId . ' : ' . $exception->getMessage());
            if (isset($nouveauChemin)) {
                AvatarProfil::supprimer($nouveauChemin);
            }
            $erreur = 'Une erreur est survenue. Vérifiez les informations et réessayez.';
        }
    }
}

$echapper = static fn($valeur) => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$nomComplet = trim((string) ($prenomSaisi ?: $moi['prenom'] ?? '') . ' ' . (string) ($nomSaisi ?: $moi['nom'] ?? ''));
$initiales = AvatarProfil::initiales($nomComplet);
$photo = AvatarProfil::estValide($moi['photo_profil'] ?? null, 'equipe') ? (string) $moi['photo_profil'] : null;
$afficherInitiales = !empty($moi['avatar_initiales']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mon profil — ALLÔ PRO Coordinateur</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <link rel="stylesheet" href="../../public/css/profil-conseiller.css?v=<?= filemtime(__DIR__ . '/../../public/css/profil-conseiller.css') ?>">
    <link rel="stylesheet" href="../../public/css/avatar-profil.css?v=<?= filemtime(__DIR__ . '/../../public/css/avatar-profil.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>

    <main class="coord-main profil-conseiller">
        <header class="contenu__entete profil-conseiller__entete">
            <div>
                <p class="profil-conseiller__surtitre">ESPACE COORDINATEUR</p>
                <h1 class="contenu__titre">Mon profil</h1>
                <p>Gérez vos informations personnelles et la sécurité de votre compte.</p>
            </div>
            <span class="profil-conseiller__role">Coordinateur</span>
        </header>

        <?php if ($succes !== ''): ?><div class="profil-conseiller__message profil-conseiller__message--succes" role="status"><?= $echapper($succes) ?></div><?php endif; ?>
        <?php if ($erreur !== ''): ?><div class="profil-conseiller__message profil-conseiller__message--erreur" role="alert"><?= $echapper($erreur) ?></div><?php endif; ?>

        <section class="profil-conseiller__hero" aria-label="Résumé du compte">
            <div class="profil-conseiller__avatar" aria-hidden="true">
                <?php if (!$afficherInitiales && $photo !== null): ?>
                    <img src="../../public/<?= $echapper($photo) ?>" alt="">
                <?php elseif ($afficherInitiales): ?>
                    <?= $echapper($initiales) ?>
                <?php else: ?>
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                <?php endif; ?>
            </div>
            <div class="profil-conseiller__identite">
                <span>Votre espace de travail</span>
                <h2><?= $echapper($nomComplet !== '' ? $nomComplet : 'Mon compte') ?></h2>
                <p><?= $echapper($moi['email'] ?? '') ?></p>
            </div>
            <div class="profil-conseiller__matricule"><span>Matricule</span><strong><?= $echapper($moi['matricule'] ?? '—') ?></strong></div>
        </section>

        <div class="profil-conseiller__grille">
            <section class="profil-conseiller__carte" aria-labelledby="profil-coordinateur-avatar-titre">
                <header class="profil-conseiller__carte-entete">
                    <span class="profil-conseiller__icone profil-conseiller__icone--photo" aria-hidden="true">◎</span>
                    <div><h2 id="profil-coordinateur-avatar-titre">Photo de profil</h2><p>Choisissez la façon dont votre identité apparaît dans l’équipe.</p></div>
                </header>
                <div class="avatar-profil">
                    <div class="avatar-profil__entete">
                        <div><h2>Votre avatar</h2><p>JPG, PNG ou WebP · 5 Mo maximum</p></div>
                        <div class="avatar-profil__apercu" aria-hidden="true">
                            <?php if (!$afficherInitiales && $photo !== null): ?>
                                <img src="../../public/<?= $echapper($photo) ?>" alt="">
                            <?php elseif ($afficherInitiales): ?>
                                <?= $echapper($initiales) ?>
                            <?php else: ?>
                                <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                            <?php endif; ?>
                        </div>
                    </div>
                    <form method="POST" enctype="multipart/form-data" class="avatar-profil__formulaire">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf']) ?>">
                        <input type="hidden" name="action" value="photo_profil">
                        <input type="hidden" name="MAX_FILE_SIZE" value="5242880">
                        <input class="avatar-profil__input-fichier" id="photo-profil-coordinateur" type="file" name="photo_profil" accept="image/jpeg,image/png,image/webp" aria-label="Choisir une photo de profil" required>
                        <label class="avatar-profil__fichier" for="photo-profil-coordinateur">Choisir une photo</label>
                        <button type="submit" class="avatar-profil__bouton">Enregistrer la photo</button>
                    </form>
                    <?php if ($photo !== null): ?>
                        <form method="POST" class="avatar-profil__action">
                            <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf']) ?>">
                            <input type="hidden" name="action" value="supprimer_photo">
                            <button type="submit" class="avatar-profil__lien">Supprimer la photo</button>
                        </form>
                    <?php endif; ?>
                    <form method="POST" class="avatar-profil__bascule">
                        <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf']) ?>">
                        <input type="hidden" name="action" value="avatar_initiales">
                        <input type="hidden" name="avatar_initiales" value="0">
                        <label for="avatar-initiales-coordinateur">Afficher mes initiales à la place de la photo</label>
                        <input id="avatar-initiales-coordinateur" type="checkbox" name="avatar_initiales" value="1" <?= $afficherInitiales ? 'checked' : '' ?> onchange="this.form.querySelector('input[type=hidden][name=avatar_initiales]').disabled = this.checked; this.form.submit()">
                    </form>
                </div>
            </section>

            <section class="profil-conseiller__carte" aria-labelledby="profil-coordinateur-infos-titre">
                <header class="profil-conseiller__carte-entete">
                    <span class="profil-conseiller__icone profil-conseiller__icone--infos" aria-hidden="true">✦</span>
                    <div><h2 id="profil-coordinateur-infos-titre">Informations personnelles</h2><p>Gardez vos coordonnées à jour.</p></div>
                </header>
                <form method="POST" class="profil-conseiller__formulaire">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf']) ?>">
                    <input type="hidden" name="action" value="profil">
                    <div class="profil-conseiller__champs">
                        <div><label for="coordinateur-prenom">Prénom</label><input id="coordinateur-prenom" name="prenom" value="<?= $echapper($prenomSaisi) ?>" maxlength="100" autocomplete="given-name" required></div>
                        <div><label for="coordinateur-nom">Nom</label><input id="coordinateur-nom" name="nom" value="<?= $echapper($nomSaisi) ?>" maxlength="100" autocomplete="family-name" required></div>
                        <div class="profil-conseiller__champ-large"><label for="coordinateur-email">Adresse e-mail</label><input id="coordinateur-email" value="<?= $echapper($moi['email'] ?? '') ?>" readonly><small>L’adresse de connexion est gérée par l’administration.</small></div>
                        <div class="profil-conseiller__champ-large"><label for="coordinateur-telephone">Téléphone <span>(facultatif)</span></label><input id="coordinateur-telephone" name="telephone" type="tel" value="<?= $echapper($telephoneSaisi) ?>" maxlength="20" autocomplete="tel"></div>
                    </div>
                    <button type="submit" class="profil-conseiller__bouton">Enregistrer mes informations</button>
                </form>
            </section>

            <section class="profil-conseiller__carte profil-conseiller__securite" aria-labelledby="profil-coordinateur-securite-titre">
                <header class="profil-conseiller__carte-entete">
                    <span class="profil-conseiller__icone profil-conseiller__icone--securite" aria-hidden="true">⌑</span>
                    <div><h2 id="profil-coordinateur-securite-titre">Sécurité du compte</h2><p>Utilisez un mot de passe unique d’au moins 8 caractères.</p></div>
                </header>
                <form method="POST" class="profil-conseiller__formulaire">
                    <input type="hidden" name="csrf" value="<?= $echapper($_SESSION['csrf']) ?>">
                    <input type="hidden" name="action" value="mot_de_passe">
                    <div class="profil-conseiller__champs profil-conseiller__champs--mdp">
                        <div><label for="mot-de-passe-actuel">Mot de passe actuel</label><input id="mot-de-passe-actuel" type="password" name="mot_de_passe_actuel" autocomplete="current-password" required></div>
                        <div><label for="nouveau-mot-de-passe">Nouveau mot de passe</label><input id="nouveau-mot-de-passe" type="password" name="nouveau_mot_de_passe" minlength="8" autocomplete="new-password" required></div>
                        <div><label for="confirmation-mot-de-passe">Confirmer le nouveau mot de passe</label><input id="confirmation-mot-de-passe" type="password" name="confirmation_mot_de_passe" minlength="8" autocomplete="new-password" required></div>
                    </div>
                    <button type="submit" class="profil-conseiller__bouton profil-conseiller__bouton--secondaire">Modifier mon mot de passe</button>
                </form>
            </section>
        </div>
    </main>
</div>
</body>
</html>
