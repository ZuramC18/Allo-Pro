<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
$traitementCoordinateur = true;
require __DIR__ . '/../conseiller/traiter-demande.php';
