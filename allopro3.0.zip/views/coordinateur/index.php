<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('tableau_bord');
require_once __DIR__ . '/../../models/VueOperationnelleCoordinateur.php';
require_once __DIR__ . '/../../models/AttributionDemandeCoordinateur.php';
require_once __DIR__ . '/../../models/Tache.php';

$vue = new VueOperationnelleCoordinateur();
$parametres = new Parametre();
$slaUrgentHeures = $parametres->getSlaDemandeUrgenteHeures();
$slaNormalHeures = $parametres->getSlaDemandeNormaleHeures();
$indicateurs = $vue->getIndicateurs();
$demandesAffecter = (new AttributionDemandeCoordinateur())->getFileAttente();
$missions = $vue->getMissions();
$erreurTaches = '';
try {
    $tachesCoordinateur = (new Tache())->getByProprietaire('coordinateur', (int) $_SESSION['user_id']);
} catch (PDOException $exception) {
    error_log('Lecture tâches coordinateur ' . (int) $_SESSION['user_id'] . ' : ' . $exception->getMessage());
    $tachesCoordinateur = [];
    $erreurTaches = 'Impossible de charger vos tâches pour le moment.';
}
$tachesAFaire = array_values(array_filter(
    $tachesCoordinateur,
    static fn(array $tache): bool => $tache['statut'] === 'a_faire'
));
$maintenant = new DateTimeImmutable();
$tachesEnRetard = array_filter(
    $tachesAFaire,
    static fn(array $tache): bool => !empty($tache['date_echeance'])
        && new DateTimeImmutable($tache['date_echeance']) < $maintenant
);
$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$formatDuree = static function (int $secondes): string {
    $secondes = max(0, $secondes);
    $jours = intdiv($secondes, 86400);
    $heures = intdiv($secondes % 86400, 3600);
    $minutes = intdiv($secondes % 3600, 60);
    $reste = $secondes % 60;
    return ($jours > 0 ? $jours . ' j ' : '')
        . sprintf('%02d:%02d:%02d', $heures, $minutes, $reste);
};
$libellesMission = [
    'en_attente' => 'Réponse technicien attendue',
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tableau opérationnel — Coordination ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/coordinateur.css">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main">
        <div class="coord-page">
            <header class="coord-page__entete">
                <div>
                    <span class="coord-page__surtitre">Espace coordinateur / dispatcher</span>
                    <h1>Tableau opérationnel</h1>
                    <p>Demandes qualifiées, capacité du réseau et suivi des interventions.</p>
                </div>
                <span class="coord-badge coord-badge--bleu">Actualisé à <?= date('H:i') ?></span>
            </header>

            <section class="coord-kpis" aria-label="Indicateurs opérationnels">
                <article class="coord-kpi">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['demandes_a_affecter'] ?></span>
                    <span class="coord-kpi__libelle">Demandes qualifiées à affecter</span>
                    <span class="coord-kpi__detail"><?= (int) $indicateurs['demandes_urgentes'] ?> urgente<?= (int) $indicateurs['demandes_urgentes'] === 1 ? '' : 's' ?></span>
                </article>
                <article class="coord-kpi <?= (int) $indicateurs['missions_en_attente'] ? 'coord-kpi--attention' : '' ?>">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['missions_en_attente'] ?></span>
                    <span class="coord-kpi__libelle">Réponses techniciens attendues</span>
                </article>
                <article class="coord-kpi <?= (int) $indicateurs['sla_depasse'] ? 'coord-kpi--alerte' : '' ?>">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['sla_depasse'] ?></span>
                    <span class="coord-kpi__libelle">SLA d’affectation dépassés</span>
                </article>
                <article class="coord-kpi <?= (int) $indicateurs['creneaux_depasse'] ? 'coord-kpi--alerte' : '' ?>">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['creneaux_depasse'] ?></span>
                    <span class="coord-kpi__libelle">Créneaux souhaités passés</span>
                </article>
                <article class="coord-kpi">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['missions_actives'] ?></span>
                    <span class="coord-kpi__libelle">Missions en cours de suivi</span>
                </article>
                <article class="coord-kpi <?= (int) $indicateurs['refus_a_traiter'] ? 'coord-kpi--attention' : '' ?>">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['refus_a_traiter'] ?></span>
                    <span class="coord-kpi__libelle">Refus à réaffecter</span>
                </article>
                <article class="coord-kpi">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['partenaires_disponibles'] ?></span>
                    <span class="coord-kpi__libelle">Partenaires avec capacité disponible</span>
                </article>
                <article class="coord-kpi">
                    <span class="coord-kpi__valeur"><?= (int) $indicateurs['techniciens_disponibles'] ?></span>
                    <span class="coord-kpi__libelle">Techniciens disponibles maintenant</span>
                </article>
            </section>

            <div class="coord-dashboard-grid">
                <section class="coord-panel">
                    <div class="coord-panel__entete">
                        <h2>Demandes qualifiées à affecter</h2>
                        <a href="demandes.php">Ouvrir la file →</a>
                    </div>
                    <?php if (!$demandesAffecter): ?>
                        <div class="coord-empty">Aucune demande qualifiée en attente d’affectation.</div>
                    <?php else: ?>
                        <div class="coord-alertes">
                            <?php foreach (array_slice($demandesAffecter, 0, 5) as $demande):
                                $seuil = ($demande['urgence'] === 'urgente' ? $slaUrgentHeures : $slaNormalHeures) * 60;
                                $dateAttribution = strtotime($demande['date_attribution']);
                                $ageSecondes = max(0, time() - $dateAttribution);
                                $seuilSecondes = $seuil * 60;
                                $depasse = $ageSecondes >= $seuilSecondes;
                                $depassement = max(0, $ageSecondes - $seuilSecondes);
                            ?>
                                <article class="coord-alerte">
                                    <div>
                                        <strong><?= $e($demande['numero_dossier']) ?> · <?= $e($demande['categorie_nom']) ?>
                                            <?php if ($demande['urgence'] === 'urgente'): ?><span class="coord-badge coord-badge--rouge">Urgente</span><?php endif; ?>
                                        </strong>
                                        <?php if (!empty($demande['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($demande['entreprise_b2b_nom']) ? ' · ' . $e($demande['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                                        <small><?= $e($demande['client_nom']) ?> · <?= $e(trim($demande['quartier'] . ', ' . $demande['ville'], ', ')) ?></small>
                                    </div>
                                    <span class="coord-badge <?= $depasse ? 'coord-badge--rouge' : 'coord-badge--bleu' ?>"
                                          data-sla-depart="<?= (int) $dateAttribution ?>"
                                          data-sla-seuil="<?= $seuilSecondes ?>">
                                        <?= $depasse ? 'SLA dépassé · +' . $formatDuree($depassement) : 'Transmise · ' . $formatDuree($ageSecondes) ?>
                                    </span>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <p class="coord-legend">SLA d’affectation : <?= $slaUrgentHeures ?> h pour une demande urgente, <?= $slaNormalHeures ?> h pour une demande normale, à compter de sa transmission au coordinateur.</p>
                    <p class="coord-legend">Un créneau souhaité est une préférence à confirmer, pas un rendez-vous garanti : son passage signale un suivi à faire avec le client.</p>
                </section>

                <section class="coord-panel">
                    <div class="coord-panel__entete">
                        <h2>Suivi des missions</h2>
                        <a href="missions.php">Voir toutes →</a>
                    </div>
                    <?php if (!$missions): ?>
                        <div class="coord-empty">Aucune mission active.</div>
                    <?php else: ?>
                        <div class="coord-alertes">
                            <?php foreach (array_slice($missions, 0, 6) as $mission): ?>
                                <article class="coord-alerte">
                                    <div>
                                        <strong><?= $e($mission['numero_dossier']) ?> · <?= $e($mission['client_nom']) ?></strong>
                                        <small><?= $e($mission['categorie_nom']) ?></small>
                                        <?php if (!empty($mission['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($mission['entreprise_b2b_nom']) ? ' · ' . $e($mission['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                                        <small><?= $e($mission['technicien_nom'] ?: 'Technicien à confirmer') ?> · <?= $e($mission['nom_entreprise'] ?: 'Partenaire non renseigné') ?></small>
                                    </div>
                                    <span class="coord-badge <?= $mission['urgence'] === 'urgente' ? 'coord-badge--rouge' : 'coord-badge--bleu' ?>">
                                        <?= $e($libellesMission[$mission['intervention_statut']] ?? $mission['intervention_statut']) ?>
                                    </span>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>

                <section class="coord-panel">
                    <div class="coord-panel__entete">
                        <h2>Mes tâches</h2>
                        <a href="taches.php">Ouvrir mes tâches →</a>
                    </div>
                    <?php if ($erreurTaches !== ''): ?>
                        <div class="coord-empty" role="alert"><?= $e($erreurTaches) ?></div>
                    <?php else: ?>
                        <p class="coord-taches-resume">
                            <strong><?= count($tachesAFaire) ?></strong> à faire
                            <?php if ($tachesEnRetard): ?>
                                <span class="coord-badge coord-badge--rouge"><?= count($tachesEnRetard) ?> en retard</span>
                            <?php endif; ?>
                        </p>
                        <?php if (!$tachesAFaire): ?>
                            <div class="coord-empty">Aucune tâche à faire. Votre liste est à jour.</div>
                        <?php else: ?>
                            <div class="coord-alertes">
                                <?php foreach (array_slice($tachesAFaire, 0, 5) as $tache):
                                    $echeanceTache = !empty($tache['date_echeance'])
                                        ? new DateTimeImmutable($tache['date_echeance'])
                                        : null;
                                    $tacheEnRetard = $echeanceTache && $echeanceTache < $maintenant;
                                ?>
                                    <article class="coord-alerte">
                                        <div>
                                            <strong><?= $e($tache['titre']) ?></strong>
                                            <small><?= $e($echeanceTache
                                                ? ($tacheEnRetard ? 'En retard · ' : 'Échéance · ') . $echeanceTache->format('d/m/Y à H:i')
                                                : 'Aucune échéance') ?></small>
                                        </div>
                                        <span class="coord-badge <?= $tacheEnRetard ? 'coord-badge--rouge' : 'coord-badge--ambre' ?>">
                                            <?= $tacheEnRetard ? 'En retard' : 'À faire' ?>
                                        </span>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                            <?php if (count($tachesAFaire) > 5): ?>
                                <p class="coord-legend">Et <?= count($tachesAFaire) - 5 ?> autre<?= count($tachesAFaire) - 5 > 1 ? 's' : '' ?> tâche<?= count($tachesAFaire) - 5 > 1 ? 's' : '' ?> dans votre liste.</p>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </main>
</div>
<script src="../../public/js/sla-coordinateur.js?v=<?= filemtime(__DIR__ . '/../../public/js/sla-coordinateur.js') ?>" defer></script>
</body>
</html>
