<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('demandes');
require_once __DIR__ . '/../../models/AttributionDemandeCoordinateur.php';
require_once __DIR__ . '/../../models/Parametre.php';

$modeleAttributions = new AttributionDemandeCoordinateur();
$demandes = $modeleAttributions->getFileAttente();
$parametres = new Parametre();
$slaUrgentHeures = $parametres->getSlaDemandeUrgenteHeures();
$slaNormalHeures = $parametres->getSlaDemandeNormaleHeures();
$echapper = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Demandes à traiter — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-demandes.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-demandes.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
<?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
<main class="coord-main">
<section class="coord-demandes">
    <header class="coord-demandes__entete">
        <div>
            <h1>Demandes à traiter</h1>
            <p>File commune des dossiers transmis par les conseillers. SLA d’affectation : <?= $slaUrgentHeures ?> h pour les demandes urgentes, <?= $slaNormalHeures ?> h pour les demandes normales.</p>
        </div>
        <span class="coord-demandes__compteur"><?= count($demandes) ?> en attente</span>
    </header>

    <?php if (!$demandes): ?>
        <div class="coord-demandes__vide">
            <strong>Aucun dossier en attente</strong>
            <span>Les nouvelles demandes transmises par les conseillers apparaîtront ici.</span>
        </div>
    <?php else: ?>
        <div class="coord-demandes__liste">
            <?php foreach ($demandes as $demande): ?>
                <article class="coord-demande">
                    <div class="coord-demande__entete">
                        <div>
                            <span class="coord-demande__numero"><?= $echapper($demande['numero_dossier']) ?></span>
                            <span class="coord-demande__categorie"><?= $echapper($demande['categorie_nom']) ?></span>
                            <?php if (!empty($demande['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($demande['entreprise_b2b_nom']) ? ' · ' . $echapper($demande['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                        </div>
                        <?php if ($demande['urgence'] === 'urgente'): ?>
                            <span class="coord-demande__urgence">Urgente</span>
                        <?php endif; ?>
                    </div>
                    <p class="coord-demande__meta">
                        <?= $echapper($demande['client_nom']) ?> · <?= $echapper($demande['quartier']) ?>, <?= $echapper($demande['ville']) ?>
                        · Transmise par <?= $echapper($demande['conseiller_nom']) ?>
                    </p>
                    <?php
                        $dateTransmission = strtotime($demande['date_attribution']);
                        $seuilSlaSecondes = ($demande['urgence'] === 'urgente' ? $slaUrgentHeures : $slaNormalHeures) * 3600;
                        $ageSlaSecondes = max(0, time() - $dateTransmission);
                        $slaDepasse = $ageSlaSecondes >= $seuilSlaSecondes;
                    ?>
                    <p class="coord-demande__sla">
                        <strong>SLA d’affectation</strong>
                        <span class="coord-badge <?= $slaDepasse ? 'coord-badge--rouge' : 'coord-badge--bleu' ?>"
                              data-sla-depart="<?= (int) $dateTransmission ?>"
                              data-sla-seuil="<?= $seuilSlaSecondes ?>">
                            <?= $slaDepasse ? 'SLA dépassé' : 'Temps écoulé' ?>
                        </span>
                    </p>
                    <?php if (!empty($demande['date_creneau_souhaite']) && $demande['heure_creneau_souhaitee'] !== null): ?>
                        <p class="coord-demande__meta">
                            Créneau souhaité : <?= $echapper(date('d/m/Y', strtotime($demande['date_creneau_souhaite']))) ?> · <?= sprintf('%02d:00–%02d:00', (int) $demande['heure_creneau_souhaitee'], (int) $demande['heure_creneau_souhaitee'] + 1) ?>
                        </p>
                    <?php endif; ?>
                    <p class="coord-demande__description"><?= $echapper($demande['description']) ?></p>
                    <div class="coord-demande__commentaire">
                        <strong>Commentaire interne du conseiller</strong>
                        <p><?= nl2br($echapper($demande['commentaire_interne'])) ?></p>
                    </div>
                    <a class="coord-demande__action" href="traiter-demande.php?id=<?= (int) $demande['demande_id'] ?>">Ouvrir et attribuer la mission</a>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>
</main>
</div>
<script src="../../public/js/sla-coordinateur.js?v=<?= filemtime(__DIR__ . '/../../public/js/sla-coordinateur.js') ?>" defer></script>
</body>
</html>
