<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur']);
verifierAcces('messagerie_interne');
require_once __DIR__ . '/../../includes/icones.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Messagerie interne — ALLÔ PRO Coordinateur</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <link rel="stylesheet" href="../../public/css/coordinateur.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <link rel="stylesheet" href="../../public/css/messagerie-interne.css?v=<?= filemtime(__DIR__ . '/../../public/css/messagerie-interne.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-messagerie-interne.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-messagerie-interne.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body class="page-coordinateur-messagerie-interne">
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main coord-main--messagerie-interne">
        <?php include __DIR__ . '/../../includes/messagerie-interne-corps.php'; ?>
    </main>
</div>
<script src="../../public/js/messagerie-interne.js?v=<?= filemtime(__DIR__ . '/../../public/js/messagerie-interne.js') ?>"></script>
</body>
</html>
