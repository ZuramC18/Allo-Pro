<?php
require_once __DIR__ . '/../../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('sav');
require_once __DIR__ . '/../../models/TicketSav.php';

$e = static fn($value): string => htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
$ticketModel = new TicketSav();
$erreurCreation = '';
if (empty($_SESSION['csrf_creation_ticket_sav'])) {
    $_SESSION['csrf_creation_ticket_sav'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['creer_ticket_sav'])) {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $demandeId = filter_var($_POST['demande_id'] ?? null, FILTER_VALIDATE_INT);
    $motif = is_string($_POST['motif'] ?? null) ? trim($_POST['motif']) : '';

    if (!hash_equals($_SESSION['csrf_creation_ticket_sav'], $csrf)) {
        http_response_code(403);
        $erreurCreation = 'Votre session a expiré. Rechargez la page puis réessayez.';
    } elseif (!$demandeId || $motif === '' || mb_strlen($motif) > 100) {
        $erreurCreation = 'Choisissez un dossier terminé et indiquez un motif de 100 caractères maximum.';
    } else {
        try {
            if ($ticketModel->creerPourEquipe((int) $demandeId, $motif, 'coordinateur', (int) $_SESSION['user_id'])) {
                journaliser('sav.cree_par_coordinateur', 'demande', (int) $demandeId, (string) $demandeId, $motif);
                $_SESSION['csrf_creation_ticket_sav'] = bin2hex(random_bytes(32));
                header('Location: sav.php?ticket=cree');
                exit;
            }
            $erreurCreation = 'Ce dossier n’est plus éligible ou possède déjà un ticket SAV.';
        } catch (Throwable $exception) {
            error_log('Création ticket SAV coordinateur pour la demande ' . (int) $demandeId . ' : ' . $exception->getMessage());
            $erreurCreation = 'Une erreur est survenue lors de la création du ticket SAV.';
        }
    }
}

$demandesEligibles = $ticketModel->getDemandesEligibleEquipe();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Créer un ticket SAV — Coordination ALLÔ PRO</title>
    <link rel="stylesheet" href="../../public/css/coordinateur.css">
    <link rel="stylesheet" href="../../public/css/coordinateur-espace.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-espace.css') ?>">
    <link rel="stylesheet" href="../../public/css/coordinateur-sav.css?v=<?= filemtime(__DIR__ . '/../../public/css/coordinateur-sav.css') ?>">
    <?php include __DIR__ . '/../../includes/theme-head.php'; ?>
</head>
<body>
<div class="coord-shell">
    <?php include __DIR__ . '/../../includes/sidebar-coordinateur.php'; ?>
    <main class="coord-main coord-sav">
        <header class="coord-sav__entete">
            <div>
                <span class="coord-sav__surtitre">Suivi après intervention</span>
                <h1>Créer un ticket SAV</h1>
                <p>Ouvrez un suivi pour un problème signalé après une intervention terminée.</p>
            </div>
        </header>

        <?php if (($_GET['ticket'] ?? '') === 'cree'): ?>
            <div class="coord-sav__alerte coord-sav__alerte--succes" role="status">Le ticket SAV a été créé.</div>
        <?php endif; ?>
        <?php if ($erreurCreation !== ''): ?>
            <div class="coord-sav__alerte coord-sav__alerte--erreur" role="alert"><?= $e($erreurCreation) ?></div>
        <?php endif; ?>

        <section class="coord-sav__carte" aria-labelledby="coord-sav-formulaire-titre">
            <div class="coord-sav__carte-entete">
                <span class="coord-sav__icone" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8v4l2.5 2.5"/><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6 4 4m14.4 1.6L20 4"/></svg>
                </span>
                <div>
                    <h2 id="coord-sav-formulaire-titre">Nouveau ticket</h2>
                    <p>Seuls les dossiers terminés sans ticket SAV peuvent être sélectionnés.</p>
                </div>
            </div>

            <?php if ($demandesEligibles): ?>
                <form method="post" class="coord-sav__formulaire">
                    <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_creation_ticket_sav']) ?>">
                    <input id="coord-sav-demande-id" type="hidden" name="demande_id">
                    <div class="coord-sav__champ">
                        <label for="coord-sav-demande">Dossier concerné</label>
                        <div class="coord-sav__recherche">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m16 16 4 4"/></svg>
                            <input id="coord-sav-demande" type="search" autocomplete="off" required
                                   placeholder="Rechercher un dossier, un client ou un téléphone"
                                   aria-controls="coord-sav-resultats" aria-autocomplete="list">
                        </div>
                        <div class="coord-sav__resultats" id="coord-sav-resultats" role="listbox" aria-label="Dossiers éligibles" hidden>
                            <?php foreach ($demandesEligibles as $demande):
                                $libelleDemande = (!empty($demande['est_demande_entreprise']) ? 'Demande venant d’une entreprise · ' : '') . $demande['numero_dossier'] . ' · ' . $demande['client_nom'];
                                $rechercheDemande = $demande['numero_dossier'] . ' ' . $demande['client_nom'] . ' ' . ($demande['client_telephone'] ?? '') . ' ' . $demande['categorie_nom'] . ' ' . ($demande['entreprise_b2b_nom'] ?? '');
                            ?>
                                <button type="button" class="coord-sav__resultat" role="option"
                                        data-id="<?= (int) $demande['id'] ?>"
                                        data-libelle="<?= $e($libelleDemande) ?>"
                                        data-recherche="<?= $e(mb_strtolower($rechercheDemande)) ?>">
                                    <span class="coord-sav__resultat-dossier"><?= $e($demande['numero_dossier']) ?></span>
                                    <?php if (!empty($demande['est_demande_entreprise'])): ?><span class="badge-demande-entreprise">Demande venant d’une entreprise<?= !empty($demande['entreprise_b2b_nom']) ? ' · ' . $e($demande['entreprise_b2b_nom']) : '' ?></span><?php endif; ?>
                                    <span class="coord-sav__resultat-client"><?= $e($demande['client_nom']) ?><?= !empty($demande['client_telephone']) ? ' · ' . $e($demande['client_telephone']) : '' ?></span>
                                    <span class="coord-sav__resultat-categorie"><?= $e($demande['categorie_nom']) ?></span>
                                </button>
                            <?php endforeach; ?>
                            <p class="coord-sav__aucun-resultat" hidden>Aucun dossier ne correspond à cette recherche.</p>
                        </div>
                        <small id="coord-sav-aide">Recherchez par numéro de dossier, nom ou téléphone du client, ou catégorie.</small>
                    </div>
                    <div class="coord-sav__champ">
                        <label for="coord-sav-motif">Motif</label>
                        <input id="coord-sav-motif" name="motif" type="text" maxlength="100" required
                               value="<?= $e($_POST['motif'] ?? '') ?>" placeholder="Ex. : problème après intervention">
                    </div>
                    <button type="submit" name="creer_ticket_sav" value="1">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14m-7-7h14"/></svg>
                        Créer le ticket
                    </button>
                </form>
            <?php else: ?>
                <p class="coord-sav__vide">Aucun dossier terminé sans ticket SAV n’est disponible pour le moment.</p>
            <?php endif; ?>
        </section>
    </main>
</div>
<script>
(function () {
    var recherche = document.getElementById('coord-sav-demande');
    var demandeId = document.getElementById('coord-sav-demande-id');
    var formulaire = document.querySelector('.coord-sav__formulaire');
    var resultats = document.getElementById('coord-sav-resultats');
    if (!recherche || !demandeId || !resultats || !formulaire) return;
    var lignesResultats = Array.prototype.slice.call(resultats.querySelectorAll('.coord-sav__resultat'));
    var aucunResultat = resultats.querySelector('.coord-sav__aucun-resultat');
    var selection = null;

    function normaliser(valeur) {
        return valeur.toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }

    function filtrerResultats() {
        var terme = normaliser(recherche.value.trim());
        var visibles = 0;
        lignesResultats.forEach(function (ligne) {
            var correspond = terme === '' || normaliser(ligne.dataset.recherche).indexOf(terme) !== -1;
            ligne.hidden = !correspond;
            ligne.setAttribute('aria-selected', 'false');
            if (correspond) visibles++;
        });
        aucunResultat.hidden = visibles > 0;
        resultats.hidden = false;
        demandeId.value = '';
        selection = null;
        recherche.setCustomValidity('');
    }

    recherche.addEventListener('focus', function () {
        if (!selection) filtrerResultats();
    });
    recherche.addEventListener('input', filtrerResultats);
    lignesResultats.forEach(function (ligne) {
        ligne.addEventListener('click', function () {
            selection = ligne;
            recherche.value = ligne.dataset.libelle;
            demandeId.value = ligne.dataset.id;
            recherche.setCustomValidity('');
            lignesResultats.forEach(function (resultat) {
                resultat.setAttribute('aria-selected', resultat === ligne ? 'true' : 'false');
            });
            resultats.hidden = true;
        });
    });
    document.addEventListener('click', function (event) {
        if (!resultats.contains(event.target) && event.target !== recherche) resultats.hidden = true;
    });
    formulaire.addEventListener('submit', function (event) {
        if (!demandeId.value) {
            event.preventDefault();
            recherche.setCustomValidity('Recherchez et sélectionnez un dossier dans les résultats.');
            recherche.reportValidity();
        }
    });
})();
</script>
</body>
</html>
