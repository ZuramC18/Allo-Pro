<?php
require_once __DIR__ . '/../config/database.php';

class ReponseRapide {
    private $conn;
    private $table = 'reponses_rapides';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} WHERE est_prive = 0 ORDER BY categorie, titre");
        return $stmt->fetchAll();
    }

    public function getVisiblePour(string $type, int $id): array {
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table}
             WHERE est_prive = 0 OR (est_prive = 1 AND cree_par_type = :type AND cree_par_id = :id)
             ORDER BY categorie, titre"
        );
        $stmt->execute([':type' => $type, ':id' => $id]);
        return $stmt->fetchAll();
    }

    public function getPriveesPourUtilisateur(string $type, int $id): array {
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table}
             WHERE est_prive = 1 AND cree_par_type = :type AND cree_par_id = :id
             ORDER BY categorie, titre"
        );
        $stmt->execute([':type' => $type, ':id' => $id]);
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($titre, $contenu, $motsCles, $categorie, $type, $id) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (titre, contenu, mots_cles, categorie, cree_par_type, cree_par_id)
             VALUES (:titre, :contenu, :mots_cles, :categorie, :type, :id)"
        );
        return $stmt->execute([
            ':titre' => $titre, ':contenu' => $contenu, ':mots_cles' => $motsCles,
            ':categorie' => $categorie ?: 'Général', ':type' => $type, ':id' => $id
        ]);
    }

    public function createPrive(string $titre, string $contenu, string $motsCles, string $categorie, string $type, int $id): bool {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (titre, contenu, mots_cles, categorie, cree_par_type, cree_par_id, est_prive)
             VALUES (:titre, :contenu, :mots_cles, :categorie, :type, :id, 1)"
        );
        return $stmt->execute([
            ':titre' => $titre, ':contenu' => $contenu, ':mots_cles' => $motsCles,
            ':categorie' => $categorie ?: 'Général', ':type' => $type, ':id' => $id,
        ]);
    }

    public function modifierPrive(int $id, string $titre, string $contenu, string $motsCles, string $categorie, string $type, int $auteurId): bool {
        $existante = $this->conn->prepare(
            "SELECT id FROM {$this->table}
             WHERE id = :id AND cree_par_type = :type AND cree_par_id = :auteur_id AND est_prive = 1"
        );
        $existante->execute([':id' => $id, ':type' => $type, ':auteur_id' => $auteurId]);
        if (!$existante->fetchColumn()) {
            return false;
        }
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET titre = :titre, contenu = :contenu, mots_cles = :mots_cles, categorie = :categorie
             WHERE id = :id AND cree_par_type = :type AND cree_par_id = :auteur_id AND est_prive = 1"
        );
        $stmt->execute([
            ':titre' => $titre, ':contenu' => $contenu, ':mots_cles' => $motsCles,
            ':categorie' => $categorie ?: 'Général', ':id' => $id, ':type' => $type, ':auteur_id' => $auteurId,
        ]);
        return true;
    }

    public function supprimerPrive(int $id, string $type, int $auteurId): bool {
        $stmt = $this->conn->prepare(
            "DELETE FROM {$this->table}
             WHERE id = :id AND cree_par_type = :type AND cree_par_id = :auteur_id AND est_prive = 1"
        );
        return $stmt->execute([':id' => $id, ':type' => $type, ':auteur_id' => $auteurId]) && $stmt->rowCount() === 1;
    }

    public function modifier($id, $titre, $contenu, $motsCles, $categorie) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET titre = :titre, contenu = :contenu, mots_cles = :mots_cles, categorie = :categorie
             WHERE id = :id AND est_prive = 0"
        );
        return $stmt->execute([
            ':titre' => $titre, ':contenu' => $contenu, ':mots_cles' => $motsCles,
            ':categorie' => $categorie ?: 'Général', ':id' => $id
        ]);
    }

    public function supprimer($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id AND est_prive = 0");
        return $stmt->execute([':id' => $id]);
    }

    public function getParCategorie() {
        $parCat = [];
        foreach ($this->getAll() as $r) { $parCat[$r['categorie']][] = $r; }
        return $parCat;
    }
}