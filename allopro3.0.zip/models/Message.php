<?php
require_once __DIR__ . '/../config/database.php';

class Message {
    private $conn;
    private $table = 'messages';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($clientId, $expediteurType, $expediteurId, $contenu, $demandeId = null, $imagePath = null, $audioPath = null) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (client_id, demande_id, expediteur_type, expediteur_id, contenu, image_path, audio_path)
             VALUES (:client_id, :demande_id, :type, :id, :contenu, :image_path, :audio_path)"
        );
        return $stmt->execute([
            ':client_id' => $clientId, ':demande_id' => $demandeId,
            ':type' => $expediteurType, ':id' => $expediteurId, ':contenu' => $contenu,
            ':image_path' => $imagePath,
            ':audio_path' => $audioPath,
        ]);
    }

    public function getByClient($clientId, $apresId = 0) {
        $stmt = $this->conn->prepare(
            "SELECT m.*,
                    COALESCE(NULLIF(TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))), ''), p.nom_entreprise) AS nom_expediteur,
                    d.numero_dossier
             FROM {$this->table} m
             LEFT JOIN users u ON m.expediteur_id = u.id AND m.expediteur_type IN ('client', 'conseiller')
             LEFT JOIN partenaires p ON m.expediteur_type = 'partenaire' AND m.expediteur_id = p.id
             LEFT JOIN demandes d ON m.demande_id = d.id
             WHERE m.client_id = :client_id AND m.id > :apres_id
             ORDER BY m.date_creation ASC"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->bindParam(':apres_id', $apresId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function marquerLues($clientId, $viewerType) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET lu = 1, lu_date = NOW() 
            WHERE client_id = :client_id AND expediteur_type != :viewer_type AND lu = 0"
        );
        return $stmt->execute([':client_id' => $clientId, ':viewer_type' => $viewerType]);
    }

    // Boîte de réception du conseiller : un client = une conversation, peu importe son nombre de dossiers
    public function getConversationsConseiller() {
        $stmt = $this->conn->query(
            "SELECT u.id, u.prenom, u.nom, u.photo_profil, u.avatar_initiales,
                    TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))) AS nom_complet,
                    u.telephone, u.email, u.conversation_statut,
                    (SELECT CASE
                        WHEN m.image_path IS NOT NULL AND m.contenu = '' THEN 'Image envoyée'
                        WHEN m.audio_path IS NOT NULL AND m.contenu = '' THEN 'Note vocale'
                        ELSE m.contenu
                     END
                     FROM messages m WHERE m.client_id = u.id ORDER BY m.date_creation DESC LIMIT 1) AS dernier_message,
                    (SELECT date_creation FROM messages WHERE client_id = u.id ORDER BY date_creation DESC LIMIT 1) AS derniere_date,
                    (SELECT COUNT(*) FROM messages WHERE client_id = u.id AND expediteur_type = 'client' AND lu = 0) AS non_lus
            FROM users u
            WHERE u.role = 'client' AND u.statut = 'actif' AND EXISTS (SELECT 1 FROM messages WHERE client_id = u.id)
            ORDER BY CASE WHEN u.conversation_statut = 'fermee' THEN 1 ELSE 0 END ASC, derniere_date DESC"
        );
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function compterNonLus($clientId, $viewerType) {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) FROM {$this->table} 
            WHERE client_id = :client_id AND expediteur_type != :viewer_type AND lu = 0"
        );
        $stmt->execute([':client_id' => $clientId, ':viewer_type' => $viewerType]);
        return (int) $stmt->fetchColumn();
    }

    public function getConversationsToutes() {
        $stmt = $this->conn->query(
            "SELECT u.id, u.prenom, u.nom, u.photo_profil, u.avatar_initiales,
                    TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))) AS nom_complet,
                    u.telephone, u.email, u.conversation_statut, u.conseiller_assigne_id,
                    co.nom AS conseiller_nom, co.matricule AS conseiller_matricule,
                    (SELECT CASE
                        WHEN m.image_path IS NOT NULL AND m.contenu = '' THEN 'Image envoyée'
                        WHEN m.audio_path IS NOT NULL AND m.contenu = '' THEN 'Note vocale'
                        ELSE m.contenu
                     END
                     FROM messages m WHERE m.client_id = u.id ORDER BY m.date_creation DESC LIMIT 1) AS dernier_message,
                    (SELECT date_creation FROM messages WHERE client_id = u.id ORDER BY date_creation DESC LIMIT 1) AS derniere_date,
                    (SELECT COUNT(*) FROM messages WHERE client_id = u.id AND expediteur_type = 'client' AND lu = 0) AS non_lus
            FROM users u
            LEFT JOIN users co ON u.conseiller_assigne_id = co.id
            WHERE u.role = 'client' AND u.statut = 'actif' AND EXISTS (SELECT 1 FROM messages WHERE client_id = u.id)
            ORDER BY CASE WHEN u.conversation_statut = 'fermee' THEN 1 ELSE 0 END ASC, derniere_date DESC"
        );
        return $stmt->fetchAll();
    }
    
    public function getConversationsCoordination($filtre = 'non_attribuees') {
        $sql = "SELECT u.id, u.prenom, u.nom, u.photo_profil, u.avatar_initiales,
                    TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))) AS nom_complet,
                    u.conseiller_assigne_id, co.nom AS conseiller_nom, co.matricule AS conseiller_matricule,
                    (SELECT CASE
                        WHEN m.image_path IS NOT NULL AND m.contenu = '' THEN 'Image envoyée'
                        WHEN m.audio_path IS NOT NULL AND m.contenu = '' THEN 'Note vocale'
                        ELSE m.contenu
                     END
                     FROM messages m WHERE m.client_id = u.id ORDER BY m.date_creation DESC LIMIT 1) AS dernier_message,
                    (SELECT date_creation FROM messages WHERE client_id = u.id ORDER BY date_creation DESC LIMIT 1) AS derniere_date,
                    (SELECT COUNT(*) FROM messages WHERE client_id = u.id AND expediteur_type = 'client' AND lu = 0) AS non_lus
                FROM users u
                LEFT JOIN users co ON u.conseiller_assigne_id = co.id
                WHERE u.role = 'client' AND EXISTS (SELECT 1 FROM messages WHERE client_id = u.id)";

        if ($filtre === 'non_attribuees') $sql .= " AND u.conseiller_assigne_id IS NULL";
        elseif ($filtre === 'attribuees') $sql .= " AND u.conseiller_assigne_id IS NOT NULL";

        $sql .= " AND u.statut = 'actif'";
        $sql .= " ORDER BY CASE WHEN u.conversation_statut = 'fermee' THEN 1 ELSE 0 END ASC, derniere_date DESC";
        return $this->conn->query($sql)->fetchAll();
    }

    public function getConversationsPourConseiller($conseillerId) {
        $stmt = $this->conn->prepare(
            "SELECT u.id, u.prenom, u.nom, u.photo_profil, u.avatar_initiales,
                    TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))) AS nom_complet,
                    u.telephone, u.email, u.conversation_statut, u.conseiller_assigne_id,
                    (SELECT CASE
                        WHEN m.image_path IS NOT NULL AND m.contenu = '' THEN 'Image envoyée'
                        WHEN m.audio_path IS NOT NULL AND m.contenu = '' THEN 'Note vocale'
                        ELSE m.contenu
                     END
                     FROM messages m WHERE m.client_id = u.id ORDER BY m.date_creation DESC LIMIT 1) AS dernier_message,
                    (SELECT date_creation FROM messages WHERE client_id = u.id ORDER BY date_creation DESC LIMIT 1) AS derniere_date,
                    (SELECT COUNT(*) FROM messages WHERE client_id = u.id AND expediteur_type = 'client' AND lu = 0) AS non_lus
            FROM users u
            WHERE u.role = 'client' AND u.statut = 'actif'
              AND u.conseiller_assigne_id = :id
              AND EXISTS (SELECT 1 FROM messages WHERE client_id = u.id)
            ORDER BY CASE WHEN u.conversation_statut = 'fermee' THEN 1 ELSE 0 END ASC, derniere_date DESC"
        );
        $stmt->execute([':id' => $conseillerId]);
        return $stmt->fetchAll();
    }

    public function compterNonLusPourConseiller(int $conseillerId): int {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*)
             FROM {$this->table} m
             JOIN users u ON u.id = m.client_id
             WHERE m.expediteur_type = 'client'
               AND m.lu = 0
               AND u.role = 'client'
               AND u.statut = 'actif'
               AND u.conseiller_assigne_id = :conseiller_id"
        );
        $stmt->execute([':conseiller_id' => $conseillerId]);
        return (int) $stmt->fetchColumn();
    }

    public function getClientsAttribuesConseiller($conseillerId) {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.prenom, c.nom,
                    TRIM(CONCAT_WS(' ', NULLIF(c.prenom, ''), NULLIF(c.nom, ''))) AS nom_complet,
                    c.telephone, c.conversation_statut,
                    (SELECT m.contenu FROM messages m WHERE m.client_id = c.id ORDER BY m.id DESC LIMIT 1) AS dernier_message,
                    (SELECT m.date_creation FROM messages m WHERE m.client_id = c.id ORDER BY m.id DESC LIMIT 1) AS derniere_date,
                    (SELECT COUNT(*) FROM messages m WHERE m.client_id = c.id AND m.expediteur_type = 'client' AND m.lu = 0) AS non_lus,
                    EXISTS(SELECT 1 FROM messages m WHERE m.client_id = c.id) AS a_conversation
            FROM users c
            WHERE c.role = 'client' AND c.conseiller_assigne_id = :id
            ORDER BY derniere_date DESC, c.nom"
        );
        $stmt->execute([':id' => $conseillerId]);
        return $stmt->fetchAll();
    }

}