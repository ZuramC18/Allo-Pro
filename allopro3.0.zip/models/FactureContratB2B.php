<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/facture.php';
require_once __DIR__ . '/../includes/PdfFacture.php';
require_once __DIR__ . '/../includes/SmtpMailer.php';

class FactureContratB2B {
    private PDO $conn;
    private array $configuration;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
        $this->configuration = require __DIR__ . '/../config/facture.php';
    }

    public function emettrePourPaiement(int $paiementId, bool $forcerRenvoi = false): array {
        $paiement = $this->getDonneesPaiement($paiementId);
        if (!$paiement) {
            throw new RuntimeException('Le règlement du contrat est introuvable.');
        }

        $facture = $this->obtenirOuCreer($paiement);
        if (($facture['email_statut'] ?? '') === 'envoye' && !$forcerRenvoi) {
            return $facture;
        }

        try {
            $chemin = $this->cheminFichier((string) $facture['chemin_fichier']);
            if (!is_file($chemin)) {
                $this->ecrirePdf($facture, $paiement, $chemin);
            }
            if (!is_readable($chemin)) {
                throw new RuntimeException('Le PDF de la facture est indisponible pour la pièce jointe.');
            }

            $email = trim((string) ($paiement['interlocuteur_email'] ?? ''));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('Renseignez une adresse e-mail valide dans les coordonnées de l’entreprise pour envoyer la facture.');
            }
            $this->mettreAJourDestinataire((int) $facture['id'], $email);

            $this->envoyer($facture, $paiement, $chemin, $email);
            $stmt = $this->conn->prepare(
                "UPDATE factures_contrats_b2b
                 SET email_statut = 'envoye', email_envoye_at = NOW(), email_erreur = NULL
                 WHERE id = :id"
            );
            $stmt->execute([':id' => $facture['id']]);
        } catch (Throwable $exception) {
            $stmt = $this->conn->prepare(
                "UPDATE factures_contrats_b2b
                 SET email_statut = 'echec', email_erreur = :erreur
                 WHERE id = :id"
            );
            $stmt->execute([
                ':erreur' => mb_substr($exception->getMessage(), 0, 1000),
                ':id' => $facture['id'],
            ]);
            error_log('Facture du règlement contrat B2B #' . $paiementId . ' : ' . $exception->getMessage());
        }

        $stmt = $this->conn->prepare("SELECT * FROM factures_contrats_b2b WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $facture['id']]);
        $factureFinale = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$factureFinale) {
            throw new RuntimeException('La facture du règlement n’a pas pu être relue après émission.');
        }
        return $factureFinale;
    }

    public function getFichierPourPaiement(int $paiementId, int $userId): array|false {
        $this->verifierFinanceOuAdmin($userId);
        $stmt = $this->conn->prepare(
            "SELECT f.numero, f.chemin_fichier
             FROM factures_contrats_b2b f
             WHERE f.paiement_contrat_b2b_id = :paiement_id
             LIMIT 1"
        );
        $stmt->execute([':paiement_id' => $paiementId]);
        $facture = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$facture) {
            return false;
        }
        $chemin = $this->cheminFichier((string) $facture['chemin_fichier']);
        if (!is_file($chemin) || !is_readable($chemin)) {
            return false;
        }
        $facture['chemin_absolu'] = $chemin;
        return $facture;
    }

    private function getDonneesPaiement(int $paiementId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT p.id AS paiement_id, p.contrat_b2b_id, p.montant, p.methode,
                    p.reference_transaction, p.date_paiement,
                    ct.date_debut, ct.date_fin, ct.volume_credits, ct.montant_total,
                    e.nom AS entreprise_nom, e.interlocuteur_nom, e.interlocuteur_email
             FROM paiements_contrats_b2b p
             JOIN contrats_b2b ct ON ct.id = p.contrat_b2b_id
             JOIN entreprises_b2b e ON e.id = ct.entreprise_b2b_id
             WHERE p.id = :paiement_id
             LIMIT 1"
        );
        $stmt->execute([':paiement_id' => $paiementId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function obtenirOuCreer(array $paiement): array {
        $stmt = $this->conn->prepare(
            "SELECT * FROM factures_contrats_b2b
             WHERE paiement_contrat_b2b_id = :paiement_id
             LIMIT 1"
        );
        $stmt->execute([':paiement_id' => $paiement['paiement_id']]);
        $facture = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($facture) {
            return $facture;
        }

        $numero = 'FAC-B2B-' . date('Y', strtotime((string) $paiement['date_paiement']))
            . '-' . str_pad((string) $paiement['paiement_id'], 8, '0', STR_PAD_LEFT);
        $nomFichier = 'facture-contrat-b2b-' . (int) $paiement['paiement_id'] . '.pdf';
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO factures_contrats_b2b
                    (paiement_contrat_b2b_id, contrat_b2b_id, numero, email_destinataire, chemin_fichier)
                 VALUES (:paiement_id, :contrat_id, :numero, :email, :chemin)"
            );
            $email = trim((string) ($paiement['interlocuteur_email'] ?? ''));
            $stmt->execute([
                ':paiement_id' => $paiement['paiement_id'],
                ':contrat_id' => $paiement['contrat_b2b_id'],
                ':numero' => $numero,
                ':email' => $email !== '' ? $email : null,
                ':chemin' => $nomFichier,
            ]);
        } catch (PDOException $exception) {
            if ($exception->getCode() !== '23000') {
                throw $exception;
            }
            $lecture = $this->conn->prepare(
                "SELECT * FROM factures_contrats_b2b
                 WHERE paiement_contrat_b2b_id = :paiement_id
                 LIMIT 1"
            );
            $lecture->execute([':paiement_id' => $paiement['paiement_id']]);
            $facture = $lecture->fetch(PDO::FETCH_ASSOC);
            if (!$facture) {
                throw $exception;
            }
            return $facture;
        }

        $stmt = $this->conn->prepare(
            "SELECT * FROM factures_contrats_b2b WHERE paiement_contrat_b2b_id = :paiement_id LIMIT 1"
        );
        $stmt->execute([':paiement_id' => $paiement['paiement_id']]);
        $facture = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$facture) {
            throw new RuntimeException('La facture du règlement n’a pas pu être créée.');
        }
        return $facture;
    }

    private function ecrirePdf(array $facture, array $paiement, string $chemin): void {
        $repertoire = dirname($chemin);
        if (!is_dir($repertoire) && !mkdir($repertoire, 0700, true) && !is_dir($repertoire)) {
            throw new RuntimeException('Impossible de créer le répertoire privé des factures B2B.');
        }
        $vendeur = $this->getParametresVendeur();
        $nomContact = trim((string) ($paiement['interlocuteur_nom'] ?? ''));
        $email = trim((string) ($paiement['interlocuteur_email'] ?? ''));
        $reference = trim((string) ($paiement['reference_transaction'] ?? ''));
        if ($reference === '') {
            $reference = 'Paiement contrat #' . (int) $paiement['contrat_b2b_id']
                . ' · Règlement #' . (int) $paiement['paiement_id'];
        }
        $libelle = 'Règlement du contrat B2B #' . (int) $paiement['contrat_b2b_id']
            . ' — ' . (string) $paiement['entreprise_nom'];
        $detailsVendeur = array_filter([
            $vendeur['vendeur_nom'] ?? 'ALLÔ PRO',
            !empty($vendeur['vendeur_identifiant']) ? 'Identifiant légal : ' . $vendeur['vendeur_identifiant'] : '',
            $vendeur['vendeur_adresse'] ?? '',
            $vendeur['vendeur_telephone'] ?? '',
            $vendeur['vendeur_email'] ?? '',
        ], static fn($ligne): bool => trim((string) $ligne) !== '');
        $pdf = new PdfFacture();
        $contenu = $pdf->generer([
            'vendeur_nom' => (string) ($vendeur['vendeur_nom'] ?? 'ALLÔ PRO'),
            'numero' => (string) $facture['numero'],
            'date' => date('d/m/Y H:i', strtotime((string) $paiement['date_paiement'])),
            'vendeur' => $detailsVendeur,
            'client' => array_values(array_filter(
                [(string) $paiement['entreprise_nom'], $nomContact, $email],
                static fn(string $ligne): bool => trim($ligne) !== ''
            )),
            'designation' => [$libelle],
            'montant' => number_format((float) $paiement['montant'], 2, ',', ' '),
            'reference_courte' => 'Contrat #' . (int) $paiement['contrat_b2b_id'],
            'reference' => $reference,
            'methode' => $this->libelleMethode((string) $paiement['methode']),
        ]);
        if (file_put_contents($chemin, $contenu, LOCK_EX) === false) {
            throw new RuntimeException('Impossible d’archiver le PDF de la facture B2B.');
        }
    }

    private function envoyer(array $facture, array $paiement, string $chemin, string $email): void {
        $vendeur = $this->getParametresVendeur();
        $nomEntreprise = (string) $paiement['entreprise_nom'];
        $numero = (string) $facture['numero'];
        $montant = number_format((float) $paiement['montant'], 2, ',', ' ') . ' FCFA';
        $date = date('d/m/Y à H:i', strtotime((string) $paiement['date_paiement']));
        $methode = $this->libelleMethode((string) $paiement['methode']);
        $reference = trim((string) ($paiement['reference_transaction'] ?? ''));
        $escape = static fn(string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $nomVendeur = $escape((string) ($vendeur['vendeur_nom'] ?? 'ALLÔ PRO'));
        $nomEntrepriseHtml = $escape($nomEntreprise);
        $numeroHtml = $escape($numero);
        $montantHtml = $escape($montant);
        $dateHtml = $escape($date);
        $methodeHtml = $escape($methode);
        $referenceHtml = $escape($reference !== '' ? $reference : 'Non renseignée');
        $html = '<!doctype html><html lang="fr"><meta charset="UTF-8"><body style="margin:0;padding:28px 12px;background:#f1f4f5;font-family:Arial,Helvetica,sans-serif;color:#172b33">'
            . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:640px;margin:0 auto;background:#fff;border:1px solid #e1e7e9;border-radius:14px;overflow:hidden">'
            . '<tr><td style="padding:28px 32px;background:#123c4d;border-bottom:5px solid #e8a33d;color:#fff"><strong style="font-size:22px">' . $nomVendeur . '</strong><div style="margin-top:8px;font-size:20px;font-weight:700">Facture de règlement B2B</div></td></tr>'
            . '<tr><td style="padding:28px 32px"><p>Bonjour ' . $nomEntrepriseHtml . ',</p><p>Nous confirmons la réception de votre règlement. Votre facture <strong>' . $numeroHtml . '</strong> est jointe à ce message.</p>'
            . '<table role="presentation" cellspacing="0" cellpadding="8" style="width:100%;background:#f4f6f7;border-radius:8px"><tr><td>Montant réglé</td><td align="right"><strong>' . $montantHtml . '</strong></td></tr>'
            . '<tr><td>Date</td><td align="right">' . $dateHtml . '</td></tr><tr><td>Moyen</td><td align="right">' . $methodeHtml . '</td></tr>'
            . '<tr><td>Référence</td><td align="right">' . $referenceHtml . '</td></tr></table>'
            . '<p style="margin-top:24px;color:#687a80">Merci pour votre confiance.<br>' . $nomVendeur . '</p></td></tr></table></body></html>';
        $texte = "Bonjour {$nomEntreprise},\n\nNous confirmons la réception de votre règlement.\n"
            . "Facture : {$numero}\nMontant : {$montant}\nDate : {$date}\nMoyen : {$methode}\n"
            . 'Référence : ' . ($reference !== '' ? $reference : 'Non renseignée')
            . "\n\nLa facture PDF est jointe à ce message.\nMerci pour votre confiance.\n"
            . (string) ($vendeur['vendeur_nom'] ?? 'ALLÔ PRO');
        (new SmtpMailer())->envoyer(
            $email,
            $nomEntreprise,
            'Facture ' . $numero . ' — règlement contrat B2B',
            $texte,
            $html,
            [['chemin' => $chemin, 'nom' => $numero . '.pdf', 'mime' => 'application/pdf']]
        );
    }

    private function mettreAJourDestinataire(int $factureId, string $email): void {
        $stmt = $this->conn->prepare(
            "UPDATE factures_contrats_b2b SET email_destinataire = :email WHERE id = :id"
        );
        $stmt->execute([':email' => $email, ':id' => $factureId]);
    }

    private function getParametresVendeur(): array {
        $configuration = $this->configuration;
        $stmt = $this->conn->query(
            "SELECT vendeur_nom, vendeur_identifiant, vendeur_adresse, vendeur_telephone, vendeur_email
             FROM parametres_facturation WHERE id = 1 LIMIT 1"
        );
        $enregistres = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($enregistres) {
            foreach (array_keys($configuration) as $cle) {
                if (array_key_exists($cle, $enregistres) && $enregistres[$cle] !== null) {
                    $configuration[$cle] = $enregistres[$cle];
                }
            }
        }
        return $configuration;
    }

    private function libelleMethode(string $methode): string {
        return [
            'wave' => 'Wave',
            'orange_money' => 'Orange Money',
            'virement' => 'Virement bancaire',
            'cheque' => 'Chèque',
            'especes' => 'Espèces',
            'autre' => 'Autre',
        ][$methode] ?? 'Non renseigné';
    }

    private function cheminFichier(string $nom): string {
        if ($nom === '' || basename($nom) !== $nom) {
            throw new RuntimeException('Le chemin de la facture B2B est invalide.');
        }
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR
            . 'factures' . DIRECTORY_SEPARATOR . 'contrats-b2b' . DIRECTORY_SEPARATOR . $nom;
    }

    private function verifierFinanceOuAdmin(int $userId): void {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM users WHERE id = :id AND role IN ('finance', 'admin') AND statut = 'actif' LIMIT 1"
        );
        $stmt->execute([':id' => $userId]);
        if (!$stmt->fetchColumn()) {
            throw new RuntimeException('Seuls les rôles Finance et Admin peuvent télécharger les factures B2B.');
        }
    }
}
