<?php
require_once __DIR__ . '/../config/database.php';

class Adresse {
    private $conn;
    private $table = 'adresses';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getVillesActives(): array {
        $stmt = $this->conn->query(
            "SELECT id, nom
             FROM zones
             WHERE type = 'ville' AND statut = 'active'
             ORDER BY nom"
        );
        return $stmt->fetchAll();
    }

    public function getZonesActivesParVille(int $villeId): array {
        $stmt = $this->conn->prepare(
            "SELECT id, nom, type
             FROM zones
             WHERE parent_id = :ville_id
               AND type IN ('zone', 'quartier')
               AND statut = 'active'
             ORDER BY nom"
        );
        $stmt->execute([':ville_id' => $villeId]);
        return $stmt->fetchAll();
    }

    private function getZoneSelection(int $zoneId, int $villeId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT z.id, z.nom, v.nom AS ville_nom
             FROM zones z
             JOIN zones v ON v.id = z.parent_id
             WHERE z.id = :zone_id
               AND z.parent_id = :ville_id
               AND z.type IN ('zone', 'quartier')
               AND z.statut = 'active'
               AND v.type = 'ville'
               AND v.statut = 'active'
             LIMIT 1"
        );
        $stmt->execute([
            ':zone_id' => $zoneId,
            ':ville_id' => $villeId,
        ]);
        return $stmt->fetch();
    }

    public function create(
        int $userId,
        string $libelle,
        int $villeId,
        int $zoneId,
        string $details,
        ?string $adresseGoogle = null,
        ?float $latitude = null,
        ?float $longitude = null
    ): bool {
        $zone = $this->getZoneSelection($zoneId, $villeId);
        if (!$zone) {
            return false;
        }

        $stmt = $this->conn->prepare(
            "SELECT id FROM {$this->table}
             WHERE user_id = :user_id
               AND supprimee = 1
               AND (zone_id = :zone_id
                    OR (zone_id IS NULL AND quartier = :quartier AND ville IN (:ville, 'Dakar')))
             ORDER BY id DESC
             LIMIT 1"
        );
        $stmt->execute([
            ':user_id' => $userId,
            ':zone_id' => $zoneId,
            ':quartier' => $zone['nom'],
            ':ville' => $zone['ville_nom'],
        ]);
        $existante = $stmt->fetch();

        if ($existante) {
            $stmt = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET supprimee = 0, libelle = :libelle, details = :details,
                     quartier = :quartier, zone_id = :zone_id, ville = :ville,
                     adresse_google = :adresse_google, latitude = :latitude, longitude = :longitude
                WHERE id = :id AND user_id = :user_id"
            );
            return $stmt->execute([
                ':libelle' => $libelle,
                ':details' => $details,
                ':quartier' => $zone['nom'],
                ':zone_id' => $zoneId,
                ':ville' => $zone['ville_nom'],
                ':adresse_google' => $adresseGoogle,
                ':latitude' => $latitude,
                ':longitude' => $longitude,
                ':id' => $existante['id'],
                ':user_id' => $userId,
            ]);
        }

        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table}
                (user_id, libelle, quartier, zone_id, ville, details, adresse_google, latitude, longitude)
             VALUES
                (:user_id, :libelle, :quartier, :zone_id, :ville, :details, :adresse_google, :latitude, :longitude)"
        );
        return $stmt->execute([
            ':user_id' => $userId,
            ':libelle' => $libelle,
            ':quartier' => $zone['nom'],
            ':zone_id' => $zoneId,
            ':ville' => $zone['ville_nom'],
            ':details' => $details,
            ':adresse_google' => $adresseGoogle,
            ':latitude' => $latitude,
            ':longitude' => $longitude,
        ]);
    }

    public function getByUser($userId) {
        $stmt = $this->conn->prepare(
            "SELECT a.id, a.user_id, a.libelle, a.zone_id, a.details, a.supprimee,
                    a.adresse_google, a.latitude, a.longitude,
                    COALESCE(z.nom, a.quartier) AS quartier,
                    COALESCE(v.nom, a.ville) AS ville
             FROM {$this->table} a
             LEFT JOIN zones z ON z.id = a.zone_id
             LEFT JOIN zones v ON v.id = z.parent_id
             WHERE a.user_id = ? AND a.supprimee = 0
             ORDER BY a.id DESC"
        );
        $stmt->execute([(int) $userId]);
        return $stmt->fetchAll();
    }

    public function supprimer($id, $userId): bool {
        $stmt = $this->conn->prepare("UPDATE adresses SET supprimee = 1 WHERE id = ? AND user_id = ?");
        $stmt->execute([(int) $id, (int) $userId]);
        return $stmt->rowCount() === 1;
    }
}