<?php
require_once __DIR__ . '/../config/database.php';

class TicketSav {
    private $conn;
    private $table = 'tickets_sav';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId, string $motif = 'Demande SAV') {
        $motif = trim($motif);
        if ($motif === '' || mb_strlen($motif) > 100) {
            throw new InvalidArgumentException('Le motif SAV doit contenir entre 1 et 100 caractères.');
        }
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (demande_id, motif, statut, origine)
             VALUES (:demande_id, :motif, 'ouvert', 'historique')"
        );
        return $stmt->execute([':demande_id' => $demandeId, ':motif' => $motif]);
    }

    public function getByClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT t.id, t.demande_id, t.motif, t.statut,
                    t.date_creation, t.date_resolution, d.numero_dossier, c.nom AS categorie_nom,
                    e.nom AS entreprise_b2b_nom, (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
             FROM {$this->table} t
             JOIN demandes d ON d.id = t.demande_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             WHERE d.client_id = :client_id
             ORDER BY t.date_creation DESC, t.id DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll();
    }

    public function getDemandesEligibleClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, c.nom AS categorie_nom, d.date_creation,
                    e.nom AS entreprise_b2b_nom, (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
             FROM demandes d
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             WHERE d.client_id = :client_id
               AND d.statut = 'terminee'
               AND NOT EXISTS (
                   SELECT 1 FROM {$this->table} t WHERE t.demande_id = d.id
               )
             ORDER BY d.date_creation DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll();
    }

    public function getDemandesEligibleConseiller(): array {
        return $this->getDemandesEligibleEquipe();
    }

    public function getDemandesEligibleEquipe(): array {
        return $this->conn->query(
            "SELECT d.id, d.numero_dossier, d.date_creation,
                    u.telephone AS client_telephone,
                    c.nom AS categorie_nom, u.nom AS client_nom,
                    e.nom AS entreprise_b2b_nom, (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
             FROM demandes d
             JOIN categories c ON c.id = d.categorie_id
             JOIN users u ON u.id = d.client_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             WHERE d.statut = 'terminee'
               AND NOT EXISTS (
                   SELECT 1 FROM {$this->table} t WHERE t.demande_id = d.id
               )
             ORDER BY d.date_creation DESC"
        )->fetchAll();
    }

    public function creerPourConseiller(int $demandeId, string $motif, int $userId): bool {
        return $this->creerPourEquipe($demandeId, $motif, 'conseiller', $userId);
    }

    public function creerPourEquipe(int $demandeId, string $motif, string $origine, int $userId): bool {
        $motif = trim($motif);
        if ($motif === '' || mb_strlen($motif) > 100) {
            throw new InvalidArgumentException('Le motif SAV doit contenir entre 1 et 100 caractères.');
        }
        if (!in_array($origine, ['conseiller', 'coordinateur'], true)) {
            throw new InvalidArgumentException('L’origine du ticket SAV est invalide.');
        }

        $this->conn->beginTransaction();
        try {
            $acteur = $this->conn->prepare(
                "SELECT role FROM users WHERE id = :user_id AND statut = 'actif' LIMIT 1"
            );
            $acteur->execute([':user_id' => $userId]);
            if ($acteur->fetchColumn() !== $origine) {
                throw new RuntimeException('Votre compte ne peut pas créer ce ticket SAV.');
            }

            $demande = $this->conn->prepare(
                "SELECT id FROM demandes
                 WHERE id = :demande_id AND statut = 'terminee'
                 FOR UPDATE"
            );
            $demande->execute([':demande_id' => $demandeId]);
            if (!$demande->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            $ticketExistant = $this->conn->prepare(
                "SELECT id FROM {$this->table} WHERE demande_id = :demande_id LIMIT 1 FOR UPDATE"
            );
            $ticketExistant->execute([':demande_id' => $demandeId]);
            if ($ticketExistant->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table} (demande_id, motif, statut, origine)
                 VALUES (:demande_id, :motif, 'ouvert', :origine)"
            );
            $stmt->execute([':demande_id' => $demandeId, ':motif' => $motif, ':origine' => $origine]);
            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $e;
        }
    }

    public function creerPourClient(int $demandeId, int $clientId, string $motif): bool {
        $this->conn->beginTransaction();
        try {
            $demande = $this->conn->prepare(
                "SELECT id FROM demandes
                 WHERE id = :demande_id AND client_id = :client_id AND statut = 'terminee'
                 FOR UPDATE"
            );
            $demande->execute([':demande_id' => $demandeId, ':client_id' => $clientId]);
            if (!$demande->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            $ticketExistant = $this->conn->prepare(
                "SELECT id FROM {$this->table} WHERE demande_id = :demande_id LIMIT 1 FOR UPDATE"
            );
            $ticketExistant->execute([':demande_id' => $demandeId]);
            if ($ticketExistant->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table} (demande_id, motif, statut, origine)
                 VALUES (:demande_id, :motif, 'ouvert', 'client')"
            );
            $stmt->execute([':demande_id' => $demandeId, ':motif' => $motif]);
            $this->conn->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $e;
        }
    }

    public function getAll($statutFiltre = null) {
        $sql = "SELECT t.*, d.numero_dossier, u.nom AS client_nom, u.telephone AS client_telephone, n.note, n.commentaire,
                       e.nom AS entreprise_b2b_nom, (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
                FROM {$this->table} t
                JOIN demandes d ON t.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
                LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
                LEFT JOIN notes n ON n.demande_id = d.id";
        if ($statutFiltre) {
            $sql .= " WHERE t.statut = :statut";
        }
        $sql .= " ORDER BY t.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) {
            $stmt->bindParam(':statut', $statutFiltre);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare(
            "SELECT t.*, d.numero_dossier, d.description, u.nom AS client_nom, u.telephone AS client_telephone, n.note, n.commentaire,
                    e.nom AS entreprise_b2b_nom, (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
             FROM {$this->table} t
             JOIN demandes d ON t.demande_id = d.id
             JOIN users u ON d.client_id = u.id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             LEFT JOIN notes n ON n.demande_id = d.id
             WHERE t.id = :id"
        );
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getHistoriqueMission(int $demandeId): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id, i.statut, i.date_debut, i.date_decision_technicien, i.date_fin,
                    i.date_creneau_planifie, i.heure_creneau_planifie, i.rapport,
                    i.photo_avant, i.photo_apres, t.nom AS technicien_nom, p.nom_entreprise AS partenaire_nom
             FROM interventions i
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             WHERE i.demande_id = :demande_id
             ORDER BY COALESCE(i.date_debut, i.date_decision_technicien, i.date_creneau_planifie) DESC, i.id DESC"
        );
        $stmt->execute([':demande_id' => $demandeId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getPreuvesMission(int $demandeId): array {
        $stmt = $this->conn->prepare(
            "SELECT doc.id, doc.nom_original, doc.chemin, doc.mime_type, doc.taille, doc.date_creation,
                    i.id AS intervention_id
             FROM intervention_documents doc
             JOIN interventions i ON i.id = doc.intervention_id
             WHERE i.demande_id = :demande_id
             ORDER BY doc.date_creation DESC, doc.id DESC"
        );
        $stmt->execute([':demande_id' => $demandeId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getPreuveParId(int $documentId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT doc.nom_original, doc.chemin, doc.mime_type, doc.taille
             FROM intervention_documents doc
             WHERE doc.id = :document_id LIMIT 1"
        );
        $stmt->execute([':document_id' => $documentId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function mettreAJourQualite(int $ticketId, int $userId, string $statut, string $categorie, string $notes): bool {
        $acteur = $this->conn->prepare("SELECT role FROM users WHERE id = :id AND statut = 'actif' LIMIT 1");
        $acteur->execute([':id' => $userId]);
        if (!in_array($acteur->fetchColumn(), ['qualite', 'admin'], true)) {
            throw new RuntimeException('Seul le responsable Qualité / SAV peut traiter ce dossier.');
        }
        $statuts = ['ouvert', 'en_cours', 'resolu'];
        $categories = ['mauvaise_experience', 'reclamation', 'incident', 'retard', 'intervention_incomplete', 'reintervention', 'litige', 'remboursement'];
        $notes = trim($notes);
        if (!in_array($statut, $statuts, true) || !in_array($categorie, $categories, true) || mb_strlen($notes) > 5000) {
            throw new InvalidArgumentException('Le statut, la catégorie ou les notes internes sont invalides.');
        }
        $stmt = $this->conn->prepare(
            "UPDATE tickets_sav SET statut = :statut_set, categorie_qualite = :categorie,
                    commentaire_conseiller = :notes,
                    date_resolution = CASE WHEN :statut_resolution = 'resolu' AND date_resolution IS NULL
                                           THEN CURRENT_TIMESTAMP ELSE date_resolution END
             WHERE id = :id"
        );
        return $stmt->execute([
            ':statut_set' => $statut,
            ':categorie' => $categorie,
            ':notes' => $notes,
            ':statut_resolution' => $statut,
            ':id' => $ticketId,
        ]);
    }

    public function demanderRemboursement(int $ticketId, int $userId, float $montant, string $motif): int {
        $acteur = $this->conn->prepare("SELECT role FROM users WHERE id = :id AND statut = 'actif' LIMIT 1");
        $acteur->execute([':id' => $userId]);
        if (!in_array($acteur->fetchColumn(), ['qualite', 'admin'], true)) {
            throw new RuntimeException('Seul le responsable Qualité / SAV peut soumettre une demande de remboursement.');
        }
        $motif = trim($motif);
        if (!is_finite($montant) || $montant <= 0 || $montant > 9999999999.99 || $motif === '' || mb_strlen($motif) > 3000) {
            throw new InvalidArgumentException('Indiquez un montant positif et un motif (3 000 caractères maximum).');
        }
        $this->conn->beginTransaction();
        try {
            $ticket = $this->conn->prepare("SELECT id FROM tickets_sav WHERE id = :id FOR UPDATE");
            $ticket->execute([':id' => $ticketId]);
            if (!$ticket->fetchColumn()) {
                throw new RuntimeException('Le ticket SAV est introuvable.');
            }
            $pending = $this->conn->prepare(
                "SELECT id FROM remboursements_sav
                 WHERE ticket_sav_id = :ticket_id AND statut = 'en_attente'
                 LIMIT 1 FOR UPDATE"
            );
            $pending->execute([':ticket_id' => $ticketId]);
            if ($pending->fetchColumn()) {
                throw new RuntimeException('Une demande de remboursement est déjà en attente.');
            }
            $stmt = $this->conn->prepare(
                "INSERT INTO remboursements_sav (ticket_sav_id, montant_demande, motif, demande_par_user_id)
                 VALUES (:ticket_id, :montant, :motif, :user_id)"
            );
            $stmt->execute([
                ':ticket_id' => $ticketId,
                ':montant' => number_format($montant, 2, '.', ''),
                ':motif' => $motif,
                ':user_id' => $userId,
            ]);
            $remboursementId = (int) $this->conn->lastInsertId();
            $this->conn->commit();
            return $remboursementId;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getRemboursementsSav(int $ticketId): array {
        $stmt = $this->conn->prepare(
            "SELECT r.*, demandeur.nom AS demandeur_nom, decideur.nom AS decideur_nom
             FROM remboursements_sav r
             JOIN users demandeur ON demandeur.id = r.demande_par_user_id
             LEFT JOIN users decideur ON decideur.id = r.decide_par_user_id
             WHERE r.ticket_sav_id = :ticket_id
             ORDER BY r.date_demande DESC, r.id DESC"
        );
        $stmt->execute([':ticket_id' => $ticketId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getRemboursementsEnAttente(): array {
        return $this->conn->query(
            "SELECT r.*, t.motif AS motif_sav, d.numero_dossier, u.nom AS demandeur_nom,
                    client.nom AS client_nom
             FROM remboursements_sav r
             JOIN tickets_sav t ON t.id = r.ticket_sav_id
             JOIN demandes d ON d.id = t.demande_id
             JOIN users u ON u.id = r.demande_par_user_id
             JOIN users client ON client.id = d.client_id
             WHERE r.statut = 'en_attente'
             ORDER BY r.date_demande ASC, r.id ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getRemboursementsFinance(
        ?string $statut = null,
        ?string $recherche = null,
        int $limite = 25,
        int $decalage = 0
    ): array {
        $conditions = [];
        $parametres = [];
        if ($statut !== null && $statut !== '') {
            $conditions[] = 'r.statut = :statut';
            $parametres[':statut'] = $statut;
        }
        if ($recherche !== null && $recherche !== '') {
            $conditions[] = "(d.numero_dossier LIKE :dossier OR client.nom LIKE :client
                OR demandeur.nom LIKE :demandeur OR r.motif LIKE :motif)";
            $terme = '%' . $recherche . '%';
            $parametres[':dossier'] = $terme;
            $parametres[':client'] = $terme;
            $parametres[':demandeur'] = $terme;
            $parametres[':motif'] = $terme;
        }
        $where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
        $stmt = $this->conn->prepare(
            "SELECT r.*, t.motif AS motif_sav, d.numero_dossier,
                    client.nom AS client_nom, demandeur.nom AS demandeur_nom,
                    decideur.nom AS decideur_nom
             FROM remboursements_sav r
             JOIN tickets_sav t ON t.id = r.ticket_sav_id
             JOIN demandes d ON d.id = t.demande_id
             JOIN users demandeur ON demandeur.id = r.demande_par_user_id
             JOIN users client ON client.id = d.client_id
             LEFT JOIN users decideur ON decideur.id = r.decide_par_user_id
             {$where}
             ORDER BY (r.statut = 'en_attente') DESC, r.date_demande DESC, r.id DESC
             LIMIT :limite OFFSET :decalage"
        );
        foreach ($parametres as $cle => $valeur) {
            $stmt->bindValue($cle, $valeur);
        }
        $stmt->bindValue(':limite', max(1, min(100, $limite)), PDO::PARAM_INT);
        $stmt->bindValue(':decalage', max(0, $decalage), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function compterRemboursementsFinance(?string $statut = null, ?string $recherche = null): int {
        $conditions = [];
        $parametres = [];
        if ($statut !== null && $statut !== '') {
            $conditions[] = 'r.statut = :statut';
            $parametres[':statut'] = $statut;
        }
        if ($recherche !== null && $recherche !== '') {
            $conditions[] = "(d.numero_dossier LIKE :dossier OR client.nom LIKE :client
                OR demandeur.nom LIKE :demandeur OR r.motif LIKE :motif)";
            $terme = '%' . $recherche . '%';
            $parametres[':dossier'] = $terme;
            $parametres[':client'] = $terme;
            $parametres[':demandeur'] = $terme;
            $parametres[':motif'] = $terme;
        }
        $where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*)
             FROM remboursements_sav r
             JOIN tickets_sav t ON t.id = r.ticket_sav_id
             JOIN demandes d ON d.id = t.demande_id
             JOIN users demandeur ON demandeur.id = r.demande_par_user_id
             JOIN users client ON client.id = d.client_id
             {$where}"
        );
        $stmt->execute($parametres);
        return (int) $stmt->fetchColumn();
    }

    public function getStatistiquesRemboursementsFinance(): array {
        $statistiques = $this->conn->query(
            "SELECT statut, COUNT(*) AS nombre, COALESCE(SUM(montant_demande), 0) AS montant
             FROM remboursements_sav
             GROUP BY statut"
        )->fetchAll(PDO::FETCH_ASSOC);
        $resume = [
            'en_attente' => ['nombre' => 0, 'montant' => 0.0],
            'autorise' => ['nombre' => 0, 'montant' => 0.0],
            'refuse' => ['nombre' => 0, 'montant' => 0.0],
        ];
        foreach ($statistiques as $statut) {
            if (isset($resume[$statut['statut']])) {
                $resume[$statut['statut']] = [
                    'nombre' => (int) $statut['nombre'],
                    'montant' => (float) $statut['montant'],
                ];
            }
        }
        return $resume;
    }

    public function getResumeQualite(): array {
        $resume = $this->conn->query(
            "SELECT
                COUNT(*) AS total,
                SUM(statut = 'ouvert') AS ouverts,
                SUM(statut = 'en_cours') AS en_cours,
                SUM(statut = 'resolu') AS resolus,
                SUM(categorie_qualite = 'reintervention' AND statut <> 'resolu') AS reinterventions,
                SUM(categorie_qualite IN ('litige', 'remboursement') AND statut <> 'resolu') AS litiges_remboursements
             FROM tickets_sav"
        )->fetch(PDO::FETCH_ASSOC);
        $resume['remboursements_en_attente'] = (int) $this->conn
            ->query("SELECT COUNT(*) FROM remboursements_sav WHERE statut = 'en_attente'")
            ->fetchColumn();
        $resume['avis_faibles'] = (int) $this->conn
            ->query(
                "SELECT COUNT(DISTINCT t.id)
                 FROM tickets_sav t
                 JOIN notes n ON n.demande_id = t.demande_id
                 WHERE n.note <= 2"
            )
            ->fetchColumn();
        return $resume;
    }

    public function getTicketsRecentsQualite(int $limite = 8): array {
        $limite = max(1, min(20, $limite));
        $stmt = $this->conn->query(
            "SELECT t.id, t.demande_id, t.motif, t.statut, t.categorie_qualite, t.date_creation,
                    d.numero_dossier, u.nom AS client_nom, n.note,
                    p.nom_entreprise AS partenaire_nom
             FROM tickets_sav t
             JOIN demandes d ON d.id = t.demande_id
             JOIN users u ON u.id = d.client_id
             LEFT JOIN notes n ON n.demande_id = d.id
             LEFT JOIN interventions i ON i.id = (
                 SELECT i2.id FROM interventions i2
                 WHERE i2.demande_id = d.id
                 ORDER BY i2.id DESC LIMIT 1
             )
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             ORDER BY FIELD(t.statut, 'ouvert', 'en_cours', 'resolu'), t.date_creation DESC, t.id DESC
             LIMIT {$limite}"
        );
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deciderRemboursement(int $remboursementId, int $userId, string $decision, string $commentaire): bool {
        $acteur = $this->conn->prepare("SELECT role FROM users WHERE id = :id AND statut = 'actif' LIMIT 1");
        $acteur->execute([':id' => $userId]);
        if (!in_array($acteur->fetchColumn(), ['finance', 'admin'], true)) {
            throw new RuntimeException('Seul le responsable Finance ou un administrateur peut autoriser ce remboursement.');
        }
        if (!in_array($decision, ['autorise', 'refuse'], true)) {
            throw new InvalidArgumentException('La décision de remboursement est invalide.');
        }
        $commentaire = trim($commentaire);
        if (mb_strlen($commentaire) > 3000) {
            throw new InvalidArgumentException('Le commentaire ne peut dépasser 3 000 caractères.');
        }
        $stmt = $this->conn->prepare(
            "UPDATE remboursements_sav SET statut = :statut, commentaire_decision = :commentaire,
                    decide_par_user_id = :user_id, date_decision = CURRENT_TIMESTAMP
             WHERE id = :id AND statut = 'en_attente'"
        );
        $stmt->execute([
            ':statut' => $decision,
            ':commentaire' => $commentaire,
            ':user_id' => $userId,
            ':id' => $remboursementId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function mettreAJour($id, $statut, $commentaire) {
        $dateResolution = $statut === 'resolu' ? ', date_resolution = NOW()' : '';
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET statut = :statut, commentaire_conseiller = :commentaire {$dateResolution} WHERE id = :id"
        );
        return $stmt->execute([':statut' => $statut, ':commentaire' => $commentaire, ':id' => $id]);
    }

    public function compterOuverts() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE statut != 'resolu'");
        return $stmt->fetch()['total'];
    }

    public function getAllAvecFiltres(
        $statutFiltre = null,
        ?int $noteMax = null,
        ?string $origineFiltre = null,
        ?string $categorieFiltre = null
    ) {
        $sql = "SELECT t.*, d.numero_dossier, d.id AS demande_id, u.nom AS client_nom, u.telephone AS client_telephone,
                    n.note, n.commentaire, p.nom_entreprise
                FROM {$this->table} t
                JOIN demandes d ON t.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                LEFT JOIN notes n ON n.demande_id = d.id
                LEFT JOIN interventions i ON i.id = (
                    SELECT i2.id
                    FROM interventions i2
                    WHERE i2.demande_id = d.id
                    ORDER BY i2.id DESC
                    LIMIT 1
                )
                LEFT JOIN partenaires p ON i.partenaire_id = p.id";

        $conditions = [];
        if ($statutFiltre) {
            $conditions[] = 't.statut = :statut';
        }
        if ($noteMax !== null && $noteMax >= 1 && $noteMax <= 5) {
            $conditions[] = 'n.note <= :note_max';
        }
        $originesValides = ['client', 'equipe', 'entreprise', 'historique'];
        if (in_array($origineFiltre, $originesValides, true)) {
            $conditions[] = match ($origineFiltre) {
                'client' => 'n.note <= 2',
                'equipe' => "t.origine IN ('conseiller', 'coordinateur')",
                default => 't.origine = :origine',
            };
        } else {
            $origineFiltre = null;
        }
        $categoriesValides = [
            'mauvaise_experience',
            'reclamation',
            'incident',
            'retard',
            'intervention_incomplete',
            'reintervention',
            'litige',
            'remboursement',
        ];
        if (in_array($categorieFiltre, $categoriesValides, true)) {
            $conditions[] = 't.categorie_qualite = :categorie';
        } else {
            $categorieFiltre = null;
        }
        if ($conditions) {
            $sql .= ' WHERE ' . implode(' AND ', $conditions);
        }
        $sql .= " ORDER BY FIELD(t.statut, 'ouvert','en_cours','resolu'), t.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) {
            $stmt->bindValue(':statut', $statutFiltre);
        }
        if ($noteMax !== null && $noteMax >= 1 && $noteMax <= 5) {
            $stmt->bindValue(':note_max', $noteMax, PDO::PARAM_INT);
        }
        if ($origineFiltre !== null && !in_array($origineFiltre, ['client', 'equipe'], true)) {
            $stmt->bindValue(':origine', $origineFiltre);
        }
        if ($categorieFiltre !== null) {
            $stmt->bindValue(':categorie', $categorieFiltre);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterParCategorieQualite(): array {
        $categories = [
            'mauvaise_experience',
            'reclamation',
            'incident',
            'retard',
            'intervention_incomplete',
            'reintervention',
            'litige',
            'remboursement',
        ];
        $compteurs = array_fill_keys($categories, 0);
        $resultats = $this->conn->query(
            "SELECT categorie_qualite, COUNT(*) AS total
             FROM {$this->table}
             GROUP BY categorie_qualite"
        )->fetchAll(PDO::FETCH_ASSOC);
        foreach ($resultats as $resultat) {
            $categorie = (string) $resultat['categorie_qualite'];
            if (array_key_exists($categorie, $compteurs)) {
                $compteurs[$categorie] = (int) $resultat['total'];
            }
        }
        return $compteurs;
    }

    public function compterParOrigine(): array {
        $resultat = $this->conn->query(
            "SELECT
                COALESCE(SUM(n.note <= 2), 0) AS client,
                COALESCE(SUM(t.origine IN ('conseiller', 'coordinateur')), 0) AS equipe,
                COALESCE(SUM(t.origine = 'entreprise'), 0) AS entreprise,
                COALESCE(SUM(t.origine = 'historique'), 0) AS historique
             FROM {$this->table} t
             LEFT JOIN notes n ON n.demande_id = t.demande_id"
        )->fetch(PDO::FETCH_ASSOC);
        return array_map('intval', $resultat);
    }

    public function compterParStatut() {
        $stmt = $this->conn->query("SELECT statut, COUNT(*) as total FROM {$this->table} GROUP BY statut");
        $resultats = $stmt->fetchAll();
        $compteurs = ['ouvert' => 0, 'en_cours' => 0, 'resolu' => 0];
        foreach ($resultats as $r) { $compteurs[$r['statut']] = (int) $r['total']; }
        return $compteurs;
    }

    public function tempsMoyenResolutionHeures() {
        $stmt = $this->conn->query(
            "SELECT AVG(TIMESTAMPDIFF(HOUR, date_creation, date_resolution)) as moyenne 
            FROM {$this->table} WHERE statut = 'resolu' AND date_resolution IS NOT NULL"
        );
        return $stmt->fetch()['moyenne'];
    }

}