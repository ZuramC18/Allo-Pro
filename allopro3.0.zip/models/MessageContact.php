<?php
require_once __DIR__ . '/../config/database.php';

class MessageContact
{
    private PDO $conn;
    private string $table = 'messages_contact';

    public function __construct()
    {
        $this->conn = (new Database())->getConnection();
    }

    public function creer(string $nom, string $email, ?string $telephone, string $raison, string $sujet, string $message): int
    {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (nom, email, telephone, raison, sujet, message)
             VALUES (:nom, :email, :telephone, :raison, :sujet, :message)"
        );
        $stmt->execute([
            ':nom' => $nom,
            ':email' => $email,
            ':telephone' => $telephone !== '' ? $telephone : null,
            ':raison' => $raison,
            ':sujet' => $sujet,
            ':message' => $message,
        ]);

        return (int) $this->conn->lastInsertId();
    }

    public function getRecents(int $limite = 200): array
    {
        $limite = max(1, min(500, $limite));
        return $this->conn->query(
            "SELECT id, nom, email, raison, sujet, statut, date_creation
             FROM {$this->table}
             ORDER BY date_creation DESC, id DESC
             LIMIT {$limite}"
        )->fetchAll();
    }

    public function getParId(int $id): ?array
    {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $message = $stmt->fetch();
        return $message ?: null;
    }

    public function compterNouveaux(): int
    {
        return (int) $this->conn->query(
            "SELECT COUNT(*) FROM {$this->table} WHERE statut = 'nouveau'"
        )->fetchColumn();
    }

    public function marquerLu(int $id): void
    {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = 'lu', date_lecture = COALESCE(date_lecture, NOW())
             WHERE id = :id"
        );
        $stmt->execute([':id' => $id]);
    }
}
