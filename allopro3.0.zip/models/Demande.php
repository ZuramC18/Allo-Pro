<?php
require_once __DIR__ . '/../config/database.php';

class Demande {
    private $conn;
    private $table = 'demandes';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function genererNumeroDossier() {
        $annee = date('Y');
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE numero_dossier LIKE 'AP-{$annee}-%'");
        $total = $stmt->fetch()['total'] + 1;
        return "AP-{$annee}-" . str_pad($total, 6, '0', STR_PAD_LEFT);
    }

    public function create($clientId, $adresseId, $categorieId, $description, $urgence, $photoPath, $modePaiement = 'normal', $abonnementId = null, $passAchatId = null, $dateCreneauSouhaite = null, $heureCreneauSouhaitee = null, ?int $siteB2bId = null) {
        $numeroDossier = $this->genererNumeroDossier();

        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (numero_dossier, client_id, adresse_id, site_b2b_id, categorie_id, description, urgence, photo_path, mode_paiement, abonnement_id, pass_achat_id, date_creneau_souhaite, heure_creneau_souhaitee)
            VALUES (:numero, :client_id, :adresse_id, :site_b2b_id, :categorie_id, :description, :urgence, :photo, :mode, :abo, :pass, :date_creneau, :heure_creneau)"
        );
        $stmt->execute([
            ':numero' => $numeroDossier, ':client_id' => $clientId, ':adresse_id' => $adresseId, ':site_b2b_id' => $siteB2bId,
            ':categorie_id' => $categorieId, ':description' => $description, ':urgence' => $urgence, ':photo' => $photoPath,
            ':mode' => $modePaiement, ':abo' => $abonnementId, ':pass' => $passAchatId,
            ':date_creneau' => $dateCreneauSouhaite, ':heure_creneau' => $heureCreneauSouhaitee
        ]);
        return $numeroDossier;
    }

    public function getByClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT d.*, c.nom AS categorie_nom, i.id AS intervention_id,
                    i.statut AS intervention_statut, i.montant AS intervention_montant,
                    p.montant AS paiement_montant, p.methode AS paiement_methode,
                    p.statut AS paiement_statut
             FROM {$this->table} d 
             JOIN categories c ON d.categorie_id = c.id 
             LEFT JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN paiements p ON p.id = (
                 SELECT p2.id FROM paiements p2
                 WHERE p2.demande_id = d.id
                 ORDER BY CASE p2.statut
                     WHEN 'valide' THEN 0
                     WHEN 'en_attente' THEN 1
                     ELSE 2
                 END, p2.id DESC
                 LIMIT 1
             )
             WHERE d.client_id = :client_id AND d.site_b2b_id IS NULL
             ORDER BY d.date_creation DESC"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getDossiersEntreprisePourMembre(int $userId): array {
        $stmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, d.statut, d.date_creation,
                    e.id AS entreprise_id, e.nom AS entreprise_nom, s.nom AS site_nom
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             WHERE d.site_b2b_id IS NOT NULL
               AND (
                   d.client_id = :createur_id
                   OR (
                       e.statut = 'actif'
                       AND EXISTS (
                           SELECT 1
                           FROM entreprises_b2b_membres m
                           WHERE m.entreprise_b2b_id = e.id
                             AND m.user_id = :membre_id
                             AND m.statut = 'actif'
                             AND m.role = 'admin'
                       )
                   )
               )
             ORDER BY e.nom, d.date_creation DESC, d.id DESC"
        );
        $stmt->execute([':membre_id' => $userId, ':createur_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAll($statutFiltre = null, bool $avecStatutCoordinateur = false) {
        $sql = "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom, u.telephone AS client_telephone,
                    a.quartier, a.ville, s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise";
        if ($avecStatutCoordinateur) {
            $sql .= ", adc.statut AS attribution_coordinateur_statut";
        }
        $sql .= "
                FROM {$this->table} d
                JOIN categories c ON d.categorie_id = c.id
                JOIN users u ON d.client_id = u.id
                JOIN adresses a ON d.adresse_id = a.id
                LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
                LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id";
        if ($avecStatutCoordinateur) {
            $sql .= "
                LEFT JOIN attributions_demandes_coordinateurs adc ON adc.demande_id = d.id";
        }

        if ($statutFiltre) {
            $sql .= " WHERE d.statut = :statut";
        }
        $sql .= " ORDER BY d.urgence DESC, d.date_creation DESC";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) {
            $stmt->bindParam(':statut', $statutFiltre);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare(
            "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom,
                    TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))) AS demandeur_nom,
                    u.telephone AS client_telephone,
                    a.quartier, a.ville, a.details AS adresse_details,
                    a.adresse_google, a.latitude AS adresse_latitude, a.longitude AS adresse_longitude,
                    i.montant, d.contrat_b2b_id, s.entreprise_b2b_id,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
            FROM {$this->table} d
            JOIN categories c ON d.categorie_id = c.id
            JOIN users u ON d.client_id = u.id
            JOIN adresses a ON d.adresse_id = a.id
            LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
            LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
            LEFT JOIN interventions i ON i.demande_id = d.id
            WHERE d.id = :id"
        );
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getStatutByNumeroDossier(string $numero): ?string {
        $stmt = $this->conn->prepare(
            "SELECT statut FROM {$this->table} WHERE numero_dossier = :numero LIMIT 1"
        );
        $stmt->execute([':numero' => $numero]);
        $statut = $stmt->fetchColumn();
        return $statut === false ? null : (string) $statut;
    }

    public function mettreAJourStatut($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function fermerMessagerie($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET messagerie_statut = 'fermee' WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function reouvrirMessagerie($id) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET messagerie_statut = 'ouverte' WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function compterParStatutClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT statut, COUNT(*) as total FROM {$this->table}
             WHERE client_id = :client_id AND site_b2b_id IS NULL GROUP BY statut"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        $resultats = $stmt->fetchAll();

        $compteurs = ['toutes' => 0, 'nouvelle' => 0, 'attribuee' => 0, 'en_cours' => 0, 'terminee' => 0, 'annulee' => 0];
        foreach ($resultats as $r) {
            $compteurs[$r['statut']] = (int) $r['total'];
            $compteurs['toutes'] += (int) $r['total'];
        }
        return $compteurs;
    }

    public function compterAujourdhui() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE DATE(date_creation) = CURDATE()");
        return $stmt->fetch()['total'];
    }

    public function compterNouvelles(): int {
        return (int) $this->conn->query(
            "SELECT COUNT(*)
             FROM {$this->table} d
             WHERE d.statut = 'nouvelle'
               AND NOT EXISTS (
                   SELECT 1
                   FROM attributions_demandes_coordinateurs adc
                   WHERE adc.demande_id = d.id
                     AND adc.statut = 'en_attente'
               )"
        )->fetchColumn();
    }

    public function compterEnCours() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM {$this->table} WHERE statut IN ('attribuee', 'en_cours')");
        return $stmt->fetch()['total'];
    }

    public function compterTermineesAujourdhui() {
        $stmt = $this->conn->query(
            "SELECT COUNT(*) as total FROM {$this->table} d JOIN interventions i ON i.demande_id = d.id 
            WHERE d.statut = 'terminee' AND DATE(i.date_fin) = CURDATE()"
        );
        return $stmt->fetch()['total'];
    }

    public function getRecentes($limite = 6) {
        $stmt = $this->conn->prepare(
            "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
            FROM {$this->table} d 
            JOIN categories c ON d.categorie_id = c.id
            JOIN users u ON d.client_id = u.id
            LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
            LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
            ORDER BY d.date_creation DESC LIMIT :limite"
        );
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getAllAvecFiltres($recherche = null, $statutFiltre = null, $urgenceFiltre = null) {
        $sql = "SELECT d.*, c.nom AS categorie_nom, u.nom AS client_nom, u.telephone AS client_telephone,
                    a.quartier, i.partenaire_id, p.nom_entreprise, t.nom AS technicien_nom,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
                FROM {$this->table} d
                JOIN categories c ON d.categorie_id = c.id
                JOIN users u ON d.client_id = u.id
                JOIN adresses a ON d.adresse_id = a.id
                LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
                LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
                LEFT JOIN interventions i ON i.demande_id = d.id
                LEFT JOIN partenaires p ON i.partenaire_id = p.id
                LEFT JOIN techniciens t ON i.technicien_id = t.id
                WHERE 1=1";

        if ($recherche) {
            $sql .= " AND (d.numero_dossier LIKE :recherche1 OR u.nom LIKE :recherche2)";
        }
        if ($statutFiltre) {
            $sql .= " AND d.statut = :statut";
        }
        if ($urgenceFiltre) {
            $sql .= " AND d.urgence = :urgence";
        }
        $sql .= " ORDER BY d.date_creation DESC LIMIT 200";

        $stmt = $this->conn->prepare($sql);
        if ($recherche) {
            $terme = '%' . $recherche . '%';
            $stmt->bindParam(':recherche1', $terme);
            $stmt->bindParam(':recherche2', $terme);
        }
        if ($statutFiltre) $stmt->bindParam(':statut', $statutFiltre);
        if ($urgenceFiltre) $stmt->bindParam(':urgence', $urgenceFiltre);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterParStatutGlobal() {
        $stmt = $this->conn->query("SELECT statut, COUNT(*) as total FROM {$this->table} GROUP BY statut");
        $resultats = $stmt->fetchAll();
        $compteurs = ['toutes' => 0, 'nouvelle' => 0, 'attribuee' => 0, 'en_cours' => 0, 'terminee' => 0, 'annulee' => 0];
        foreach ($resultats as $r) {
            $compteurs[$r['statut']] = (int) $r['total'];
            $compteurs['toutes'] += (int) $r['total'];
        }
        return $compteurs;
    }

}