<?php
require_once __DIR__ . '/../config/database.php';

class AdminPilotage {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getTotauxGlobaux(): array {
        $stmt = $this->conn->query(
            "SELECT
                (SELECT COUNT(*) FROM users WHERE role = 'client') AS clients_total,
                (SELECT COUNT(*) FROM demandes) AS demandes_total,
                (SELECT COUNT(*) FROM demandes WHERE site_b2b_id IS NOT NULL) AS demandes_b2b,
                (SELECT COUNT(*) FROM interventions) AS interventions_total,
                (SELECT COUNT(*) FROM interventions WHERE statut IN ('en_attente', 'acceptee', 'en_route', 'en_cours')) AS interventions_actives,
                (SELECT COUNT(*) FROM partenaires) AS partenaires_total,
                (SELECT COUNT(*) FROM partenaires WHERE statut = 'actif') AS partenaires_actifs,
                (SELECT COUNT(*) FROM techniciens WHERE statut != 'corbeille') AS techniciens_total,
                (SELECT COUNT(*) FROM techniciens WHERE statut = 'actif') AS techniciens_actifs,
                (SELECT COUNT(*) FROM entreprises_b2b) AS entreprises_total,
                (SELECT COUNT(*) FROM entreprises_b2b WHERE statut = 'actif') AS entreprises_actives,
                (SELECT COUNT(*) FROM contrats_b2b) AS contrats_total,
                (SELECT COUNT(*) FROM contrats_b2b WHERE statut = 'actif') AS contrats_actifs,
                (SELECT COALESCE(SUM(montant), 0) FROM paiements WHERE statut = 'valide') AS paiements_clients_total,
                (SELECT COALESCE(SUM(montant), 0) FROM paiements WHERE statut = 'valide'
                    AND MONTH(date_paiement) = MONTH(CURDATE()) AND YEAR(date_paiement) = YEAR(CURDATE())) AS paiements_clients_mois,
                (SELECT COALESCE(SUM(montant), 0) FROM paiements_contrats_b2b) AS paiements_b2b_total,
                (SELECT COALESCE(SUM(montant), 0) FROM paiements_contrats_b2b
                    WHERE MONTH(date_paiement) = MONTH(CURDATE()) AND YEAR(date_paiement) = YEAR(CURDATE())) AS paiements_b2b_mois,
                (SELECT COUNT(*) FROM tickets_sav WHERE statut != 'resolu') AS sav_ouverts,
                (SELECT COUNT(*) FROM remboursements_sav WHERE statut = 'en_attente') AS remboursements_en_attente,
                (SELECT COALESCE(SUM(montant_demande), 0) FROM remboursements_sav WHERE statut = 'en_attente') AS montant_remboursements_en_attente,
                (SELECT COUNT(*) FROM ajustements_creneaux_automatiques WHERE statut = 'a_traiter') AS creneaux_a_traiter"
        );

        $totaux = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($totaux === false) {
            throw new RuntimeException('Impossible de charger les totaux globaux du tableau de bord.');
        }

        foreach ($totaux as $cle => $valeur) {
            $totaux[$cle] = str_starts_with($cle, 'paiements_') || $cle === 'montant_remboursements_en_attente'
                ? (float) $valeur
                : (int) $valeur;
        }

        $totaux['chiffre_affaires_total'] = $totaux['paiements_clients_total'] + $totaux['paiements_b2b_total'];
        $totaux['chiffre_affaires_mois'] = $totaux['paiements_clients_mois'] + $totaux['paiements_b2b_mois'];

        return $totaux;
    }
}
