<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Parametre.php';
require_once __DIR__ . '/ConfigurationAttributionDemandes.php';
require_once __DIR__ . '/AjustementCreneauAutomatique.php';
require_once __DIR__ . '/NoteInterne.php';
require_once __DIR__ . '/../includes/audit.php';

class AttributionDemandes {
    private PDO $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function traiterFile(?string $numeroDossier = null): array {
        if (!(new Parametre())->attributionAutomatiqueDemandesActive()) {
            return ['active' => false, 'attribuees' => [], 'en_attente' => 0];
        }

        $configuration = (new ConfigurationAttributionDemandes($this->conn))->getAll();
        $this->conn->beginTransaction();
        try {
            $sql = "SELECT d.id, d.client_id, d.numero_dossier, d.categorie_id, d.urgence,
                        d.mode_paiement, d.abonnement_id,
                        d.date_creneau_souhaite, d.heure_creneau_souhaitee,
                        a.quartier AS adresse_quartier, a.ville AS adresse_ville,
                        z.nom AS zone_nom, z.type AS zone_type,
                        COALESCE(v.nom, a.ville) AS zone_ville
                 FROM demandes d
                 JOIN adresses a ON a.id = d.adresse_id
                 LEFT JOIN zones z ON z.id = a.zone_id
                 LEFT JOIN zones v ON v.id = z.parent_id AND v.type = 'ville'
                 WHERE d.statut = 'nouvelle'
                   AND d.site_b2b_id IS NULL
                   AND NOT EXISTS (
                       SELECT 1 FROM interventions i WHERE i.demande_id = d.id
                   )
                 ";
            $parametres = [];
            if ($numeroDossier !== null) {
                $sql .= " AND d.numero_dossier = :numero_dossier";
                $parametres[':numero_dossier'] = $numeroDossier;
            }
            $ordre = [];
            if ($configuration['priorite_urgence_active'] === '1') {
                $ordre[] = "CASE WHEN d.urgence = 'urgente' THEN 0 ELSE 1 END";
            }
            if ($configuration['priorite_abonnement_active'] === '1') {
                $ordre[] = "CASE WHEN d.mode_paiement = 'abonnement'
                                      AND d.abonnement_id IS NOT NULL THEN 0 ELSE 1 END";
            }
            $ordre[] = 'd.date_creation ' . (
                $configuration['priorite_anciennete_active'] === '1' ? 'ASC' : 'DESC'
            );
            $ordre[] = 'd.id ASC';
            $sql .= "\n                 ORDER BY " . implode(', ', $ordre) . "\n                 FOR UPDATE";
            $selection = $this->conn->prepare($sql);
            $selection->execute($parametres);
            $demandes = $selection->fetchAll();

            $attribuees = [];
            foreach ($demandes as $demande) {
                $dateCreneau = $demande['date_creneau_souhaite'] !== null
                    ? (string) $demande['date_creneau_souhaite']
                    : null;
                $heureCreneau = $demande['heure_creneau_souhaitee'] !== null
                    ? (int) $demande['heure_creneau_souhaitee']
                    : null;
                $this->verrouillerCandidats((int) $demande['categorie_id']);
                $candidats = $this->getCandidats((int) $demande['categorie_id']);
                $candidatsEligibles = [];
                foreach ($candidats as $candidat) {
                    $score = $this->evaluerCandidat($demande, $candidat, $configuration);
                    if ($score === null) {
                        continue;
                    }
                    $candidat['score_attribution'] = $score['score'];
                    $candidat['details_attribution'] = $score['details'];
                    $candidat['zone_priorite'] = $configuration['score_zone_active'] === '1'
                        ? $score['zone']
                        : 0;
                    $candidatsEligibles[] = $candidat;
                }

                $creneauAttribue = $this->trouverCreneauDisponible(
                    $candidatsEligibles,
                    $dateCreneau,
                    $heureCreneau,
                    $configuration
                );
                if ($creneauAttribue === null) {
                    continue;
                }
                $meilleur = $creneauAttribue['candidat'];
                $dateCreneauAttribue = $creneauAttribue['date'];
                $heureCreneauAttribue = $creneauAttribue['heure'];
                $creneauModifie = $dateCreneau === null
                    || $heureCreneau === null
                    || $dateCreneauAttribue !== $dateCreneau
                    || $heureCreneauAttribue !== $heureCreneau;
                $descriptionCreneau = sprintf(
                    'Créneau réservé le %s à %02d:00%s.',
                    date('d/m/Y', strtotime($dateCreneauAttribue)),
                    $heureCreneauAttribue,
                    $creneauModifie && $dateCreneau !== null && $heureCreneau !== null
                        ? sprintf(
                            ' au lieu du %s à %02d:00',
                            date('d/m/Y', strtotime($dateCreneau)),
                            $heureCreneau
                        )
                        : ($creneauModifie ? ' sans créneau souhaité' : ' comme demandé')
                );
                $meilleur['details_attribution'] = mb_substr(
                    $meilleur['details_attribution'] . ' ' . $descriptionCreneau,
                    0,
                    500
                );

                $insert = $this->conn->prepare(
                    "INSERT INTO interventions
                        (demande_id, partenaire_id, technicien_id, date_creneau_planifie,
                         heure_creneau_planifie, technicien_nom, statut,
                         date_debut, attribution_mode, score_attribution, details_attribution)
                     VALUES
                        (:demande_id, :partenaire_id, :technicien_id, :date_creneau_planifie,
                         :heure_creneau_planifie, :technicien_nom, 'en_attente',
                         NOW(), 'automatique', :score, :details)"
                );
                $insert->execute([
                    ':demande_id' => (int) $demande['id'],
                    ':partenaire_id' => (int) $meilleur['partenaire_id'],
                    ':technicien_id' => (int) $meilleur['technicien_id'],
                    ':date_creneau_planifie' => $dateCreneauAttribue,
                    ':heure_creneau_planifie' => $heureCreneauAttribue,
                    ':technicien_nom' => $meilleur['technicien_nom'],
                    ':score' => $meilleur['score_attribution'],
                    ':details' => $meilleur['details_attribution'],
                ]);
                $interventionId = (int) $this->conn->lastInsertId();
                if ($creneauModifie) {
                    (new NoteInterne($this->conn))->creerNoteAutomatiqueCreneau(
                        (int) $demande['client_id'],
                        (int) $demande['id'],
                        $interventionId,
                        sprintf(
                            'Note auto : rendez-vous dossier %s fixé au %s à %02d:00%s, en attente du technicien.',
                            $demande['numero_dossier'],
                            date('d/m/Y', strtotime($dateCreneauAttribue)),
                            $heureCreneauAttribue,
                            $dateCreneau !== null && $heureCreneau !== null
                                ? sprintf(
                                    ' (créneau souhaité : %s à %02d:00)',
                                    date('d/m/Y', strtotime($dateCreneau)),
                                    $heureCreneau
                                )
                                : ' (aucun créneau souhaité)'
                        )
                    );
                }
                if ($dateCreneau !== null && $heureCreneau !== null && $creneauModifie) {
                    (new AjustementCreneauAutomatique($this->conn))->ajouter(
                        (int) $demande['id'],
                        $interventionId,
                        (int) $meilleur['technicien_id'],
                        $dateCreneau,
                        $heureCreneau,
                        $dateCreneauAttribue,
                        $heureCreneauAttribue
                    );
                }

                $maj = $this->conn->prepare(
                    "UPDATE demandes
                     SET statut = 'attribuee'
                     WHERE id = :id AND statut = 'nouvelle'
                       AND NOT EXISTS (
                           SELECT 1 FROM interventions i
                           WHERE i.demande_id = demandes.id AND i.id <> :intervention_id
                       )"
                );
                $maj->execute([
                    ':id' => (int) $demande['id'],
                    ':intervention_id' => $interventionId,
                ]);
                if ($maj->rowCount() !== 1) {
                    throw new RuntimeException('La demande a changé pendant son affectation automatique.');
                }

                $attribuees[] = [
                    'demande_id' => (int) $demande['id'],
                    'numero_dossier' => $demande['numero_dossier'],
                    'partenaire_id' => (int) $meilleur['partenaire_id'],
                    'technicien_id' => (int) $meilleur['technicien_id'],
                    'partenaire_nom' => $meilleur['partenaire_nom'],
                    'technicien_nom' => $meilleur['technicien_nom'],
                    'score' => $meilleur['score_attribution'],
                    'details' => $meilleur['details_attribution'],
                    'date_creneau_demande' => $dateCreneau,
                    'heure_creneau_demande' => $heureCreneau,
                    'date_creneau_attribue' => $dateCreneauAttribue,
                    'heure_creneau_attribue' => $heureCreneauAttribue,
                ];
            }

            $this->conn->commit();
            foreach ($attribuees as $affectation) {
                journaliser(
                    'demande.attribuee',
                    'demande',
                    $affectation['demande_id'],
                    $affectation['numero_dossier'],
                    'Affectation automatique · ' . $affectation['partenaire_nom']
                        . ' · ' . $affectation['technicien_nom']
                        . ' · score ' . $affectation['score']
                        . ' · ' . $affectation['details']
                        . ($affectation['date_creneau_demande'] === null
                            || $affectation['heure_creneau_demande'] === null
                            || $affectation['date_creneau_demande'] !== $affectation['date_creneau_attribue']
                            || $affectation['heure_creneau_demande'] !== $affectation['heure_creneau_attribue']
                            ? ($affectation['date_creneau_demande'] === null
                                || $affectation['heure_creneau_demande'] === null
                                ? ' · aucun créneau souhaité, attribué '
                                    . $affectation['date_creneau_attribue'] . ' '
                                    . sprintf('%02d:00', $affectation['heure_creneau_attribue'])
                                : sprintf(
                                ' · créneau demandé %s %02d:00, déplacé au %s %02d:00',
                                $affectation['date_creneau_demande'],
                                $affectation['heure_creneau_demande'],
                                $affectation['date_creneau_attribue'],
                                $affectation['heure_creneau_attribue']
                                ))
                            : ''),
                    ACTEUR_SYSTEME
                );
            }
            return [
                'active' => true,
                'attribuees' => $attribuees,
                'en_attente' => count($demandes) - count($attribuees),
            ];
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getAttributionsAutomatiques(): array {
        $stmt = $this->conn->query(
            "SELECT i.id AS intervention_id, i.demande_id, i.statut AS intervention_statut,
                    i.date_debut AS date_attribution,
                    i.date_creneau_planifie, i.heure_creneau_planifie,
                    i.score_attribution, i.details_attribution,
                    d.numero_dossier, d.urgence, d.statut AS demande_statut,
                    c.nom AS categorie_nom, u.nom AS client_nom,
                    a.quartier, a.ville,
                    p.nom_entreprise,
                    COALESCE(t.nom, i.technicien_nom) AS technicien_nom
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN users u ON u.id = d.client_id
             JOIN adresses a ON a.id = d.adresse_id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             WHERE i.attribution_mode = 'automatique'
             ORDER BY i.date_debut DESC, i.id DESC"
        );
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function verrouillerCandidats(int $categorieId): void {
        $stmt = $this->conn->prepare(
            "SELECT t.id
             FROM techniciens t
             JOIN partenaires p ON p.id = t.partenaire_id
             WHERE t.statut = 'actif'
               AND p.statut = 'actif'
               AND EXISTS (
                   SELECT 1
                   FROM technicien_competences tcomp
                   JOIN categories tc ON tc.id = tcomp.categorie_id
                   LEFT JOIN categories dc ON dc.id = :categorie_demandee
                   WHERE tcomp.technicien_id = t.id
                     AND (tc.id = :categorie_technicien
                          OR tc.parent_id = :categorie_pole
                          OR dc.parent_id = tc.id)
               )
             ORDER BY t.id
             FOR UPDATE"
        );
        $stmt->execute([
            ':categorie_demandee' => $categorieId,
            ':categorie_technicien' => $categorieId,
            ':categorie_pole' => $categorieId,
        ]);
        $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    private function getCandidats(
        int $categorieId
    ): array {
        $stmt = $this->conn->prepare(
            "SELECT t.id AS technicien_id, t.nom AS technicien_nom,
                    p.id AS partenaire_id, p.nom_entreprise AS partenaire_nom,
                    (SELECT JSON_ARRAYAGG(z.nom)
                     FROM partenaire_zones pz
                     JOIN zones z ON z.id = pz.zone_id
                     WHERE pz.partenaire_id = p.id) AS zones_intervention_json,
                    p.score AS reputation, p.niveau,
                    CASE WHEN EXISTS (
                        SELECT 1 FROM technicien_competences exactes
                        WHERE exactes.technicien_id = t.id AND exactes.categorie_id = :categorie_exacte
                    ) THEN 1 ELSE 0 END AS competence_exacte,
                    (SELECT COUNT(*)
                     FROM interventions i
                     WHERE i.technicien_id = t.id
                       AND i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')) AS charge
             FROM techniciens t
             JOIN partenaires p ON p.id = t.partenaire_id
             WHERE t.statut = 'actif'
               AND p.statut = 'actif'
               AND EXISTS (
                   SELECT 1
                   FROM technicien_competences tcomp
                   JOIN categories tc ON tc.id = tcomp.categorie_id
                   LEFT JOIN categories dc ON dc.id = :categorie_demandee
                   WHERE tcomp.technicien_id = t.id
                     AND (tc.id = :categorie_technicien
                          OR tc.parent_id = :categorie_pole
                          OR dc.parent_id = tc.id)
               )
             ORDER BY t.id"
        );
        $stmt->execute([
            ':categorie_exacte' => $categorieId,
            ':categorie_demandee' => $categorieId,
            ':categorie_technicien' => $categorieId,
            ':categorie_pole' => $categorieId,
        ]);
        return $stmt->fetchAll();
    }

    private function trouverCreneauDisponible(
        array $candidats,
        ?string $dateDemandee,
        ?int $heureDemandee,
        array $configuration
    ): ?array {
        if (!$candidats) {
            return null;
        }

        $parametres = (new Parametre($this->conn))->getAll();
        $heureOuverture = (int) $parametres['heure_debut_indisponibilites'];
        $heureFermeture = (int) $parametres['heure_fin_indisponibilites'];
        $maintenant = new DateTimeImmutable();
        $dateRechercheDemandee = $dateDemandee ?? $maintenant->format('Y-m-d');
        $dateDebutRecherche = max($dateRechercheDemandee, $maintenant->format('Y-m-d'));
        $horizonJours = $configuration['horizon_creneaux_active'] === '1'
            ? (int) $configuration['horizon_creneaux_jours']
            : 365;
        $dateFinRecherche = $maintenant->modify('+' . $horizonJours . ' days')->format('Y-m-d');
        $technicienIds = array_values(array_unique(array_map(
            static fn(array $candidat): int => (int) $candidat['technicien_id'],
            $candidats
        )));
        $creneauxIndisponibles = $this->chargerCreneauxIndisponibles(
            $technicienIds,
            $dateDebutRecherche,
            $dateFinRecherche
        );

        for ($date = $dateDebutRecherche; $date <= $dateFinRecherche; $date = date('Y-m-d', strtotime($date . ' +1 day'))) {
            $premiereHeure = $date === $dateDemandee && $heureDemandee !== null
                ? $heureDemandee
                : $heureOuverture;
            $premiereHeure = max($heureOuverture, $premiereHeure);
            for ($heure = $premiereHeure; $heure < $heureFermeture; $heure++) {
                $debutCreneau = new DateTimeImmutable(sprintf('%s %02d:00:00', $date, $heure));
                if ($debutCreneau < $maintenant) {
                    continue;
                }

                $meilleur = null;
                foreach ($candidats as $candidat) {
                    $cle = $this->cleCreneau((int) $candidat['technicien_id'], $date, $heure);
                    if (isset($creneauxIndisponibles[$cle])) {
                        continue;
                    }
                    if ($meilleur === null || $this->candidatPrioritaire($candidat, $meilleur, $configuration)) {
                        $meilleur = $candidat;
                    }
                }
                if ($meilleur !== null) {
                    return ['candidat' => $meilleur, 'date' => $date, 'heure' => $heure];
                }
            }
        }

        return null;
    }

    private function chargerCreneauxIndisponibles(array $technicienIds, string $dateDebut, string $dateFin): array {
        if (!$technicienIds) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($technicienIds), '?'));
        $sql = "SELECT technicien_id, date_indisponibilite AS date_creneau,
                       heure_debut AS heure_creneau
                FROM technicien_indisponibilites
                WHERE technicien_id IN ({$placeholders})
                  AND date_indisponibilite BETWEEN ? AND ?
                UNION ALL
                SELECT technicien_id, date_creneau_planifie AS date_creneau,
                       heure_creneau_planifie AS heure_creneau
                FROM interventions
                WHERE technicien_id IN ({$placeholders})
                  AND date_creneau_planifie BETWEEN ? AND ?
                  AND heure_creneau_planifie IS NOT NULL
                  AND statut NOT IN ('terminee', 'annulee', 'refusee')";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(array_merge(
            $technicienIds,
            [$dateDebut, $dateFin],
            $technicienIds,
            [$dateDebut, $dateFin]
        ));
        $indisponibilites = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $creneau) {
            $indisponibilites[$this->cleCreneau(
                (int) $creneau['technicien_id'],
                (string) $creneau['date_creneau'],
                (int) $creneau['heure_creneau']
            )] = true;
        }
        return $indisponibilites;
    }

    private function cleCreneau(int $technicienId, string $date, int $heure): string {
        return $technicienId . '|' . $date . '|' . $heure;
    }

    private function evaluerCandidat(array $demande, array $candidat, array $configuration): ?array {
        $charge = (int) $candidat['charge'];
        if ($configuration['limite_charge_active'] === '1'
            && $charge >= (int) $configuration['charge_maximale']) {
            return null;
        }

        $zonesIntervention = $candidat['zones_intervention_json'] ?? null;
        $zonesIntervention = $zonesIntervention === null
            ? []
            : json_decode((string) $zonesIntervention, true, 512, JSON_THROW_ON_ERROR);
        $couverture = $this->evaluerCouverture(
            is_array($zonesIntervention) ? $zonesIntervention : [],
            (string) ($demande['zone_nom'] ?: $demande['adresse_quartier']),
            (string) ($demande['zone_ville'] ?: $demande['adresse_ville']),
            $configuration
        );
        if ($couverture === null) {
            return null;
        }

        // Poids de départ à recalibrer avec les données d'acceptation, de délai et de qualité.
        // Les compétences et la zone sont des prérequis : le score ne peut pas les compenser.
        $zonePoints = $configuration['score_zone_active'] === '1' ? (int) $couverture['points'] : 0;
        $reputation = max(0.0, min(5.0, (float) ($candidat['reputation'] ?? 0)));
        $reputationPoints = $configuration['score_reputation_active'] === '1'
            ? (int) round($reputation * (int) $configuration['score_reputation_par_point'])
            : 0;
        $niveauPoints = [
            'partenaire' => 0,
            'certifie' => (int) $configuration['score_niveau_certifie'],
            'premium' => (int) $configuration['score_niveau_premium'],
            'excellence' => (int) $configuration['score_niveau_excellence'],
        ][$candidat['niveau']] ?? 0;
        if ($configuration['score_niveau_active'] !== '1') {
            $niveauPoints = 0;
        }
        $competencePoints = $configuration['score_competence_active'] === '1'
            ? (int) $configuration[(int) $candidat['competence_exacte'] === 1
                ? 'score_competence_exacte'
                : 'score_competence_compatible']
            : 0;
        $chargePoints = $configuration['score_charge_active'] === '1'
            ? $charge * (int) $configuration['penalite_charge']
            : 0;
        $score = $zonePoints + $competencePoints + $reputationPoints + $niveauPoints - $chargePoints;
        $details = sprintf(
            'Zone %s (+%d), compétence %s (+%d), réputation %.1f/5 (+%d), niveau %s (+%d), charge %d (-%d).',
            $couverture['libelle'],
            $zonePoints,
            (int) $candidat['competence_exacte'] === 1 ? 'exacte' : 'pôle compatible',
            $competencePoints,
            $reputation,
            $reputationPoints,
            $candidat['niveau'],
            $niveauPoints,
            $charge,
            $chargePoints
        );
        return [
            'score' => max(0, $score),
            'details' => mb_substr($details, 0, 500),
            'zone' => $couverture['points'],
        ];
    }

    private function evaluerCouverture(
        array $zonesIntervention,
        string $quartier,
        string $ville,
        array $configuration
    ): ?array {
        $zones = array_values(array_filter(array_map(
            fn($zone) => $this->normaliser((string) $zone),
            $zonesIntervention
        )));
        if (!$zones) {
            return null;
        }

        $quartierNormalise = $this->normaliser($quartier);
        if ($quartierNormalise !== '' && in_array($quartierNormalise, $zones, true)) {
            return ['points' => (int) $configuration['score_zone_quartier'], 'libelle' => 'exacte'];
        }

        foreach ($zones as $zoneCouverte) {
            if ($zoneCouverte !== '' && str_starts_with($quartierNormalise, $zoneCouverte . ' ')) {
                return ['points' => (int) $configuration['score_zone_elargie'], 'libelle' => 'zone élargie'];
            }
        }

        $villeNormalisee = $this->normaliser($ville);
        if ($villeNormalisee !== '' && in_array($villeNormalisee, $zones, true)) {
            return ['points' => (int) $configuration['score_zone_ville'], 'libelle' => 'ville/zone'];
        }

        return null;
    }

    private function normaliser(string $texte): string {
        $translittere = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texte);
        $texte = $translittere === false ? $texte : $translittere;
        return mb_strtolower(trim($texte), 'UTF-8');
    }

    private function candidatPrioritaire(array $candidat, array $courant, array $configuration): bool {
        if ($candidat['score_attribution'] !== $courant['score_attribution']) {
            return $candidat['score_attribution'] > $courant['score_attribution'];
        }
        if ($configuration['score_charge_active'] === '1'
            && (int) $candidat['charge'] !== (int) $courant['charge']) {
            return (int) $candidat['charge'] < (int) $courant['charge'];
        }
        if ((int) $candidat['zone_priorite'] !== (int) $courant['zone_priorite']) {
            return (int) $candidat['zone_priorite'] > (int) $courant['zone_priorite'];
        }
        return (int) $candidat['technicien_id'] < (int) $courant['technicien_id'];
    }
}
