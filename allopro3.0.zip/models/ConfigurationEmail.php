<?php
require_once __DIR__ . '/../config/database.php';

class ConfigurationEmail {
    private PDO $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getStatutGoogle(): array {
        $stmt = $this->conn->query(
            "SELECT compte_google, mot_de_passe_chiffre
             FROM parametres_email WHERE id = 1 LIMIT 1"
        );
        $parametres = $stmt->fetch();
        return [
            'compte_google' => (string) ($parametres['compte_google'] ?? ''),
            'configure' => !empty($parametres['compte_google']) && !empty($parametres['mot_de_passe_chiffre']),
        ];
    }

    public function enregistrerGoogle(string $email, string $motDePasseApplication, int $adminId): void {
        $email = trim($email);
        $motDePasseApplication = preg_replace('/\s+/', '', trim($motDePasseApplication));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) {
            throw new InvalidArgumentException('Saisissez une adresse e-mail Google valide.');
        }
        if ($motDePasseApplication !== '' && !preg_match('/\A[A-Za-z0-9]{16}\z/', $motDePasseApplication)) {
            throw new InvalidArgumentException('Le mot de passe d’application Google doit contenir 16 lettres ou chiffres.');
        }

        $stmtExistant = $this->conn->query(
            "SELECT mot_de_passe_chiffre FROM parametres_email WHERE id = 1 LIMIT 1"
        );
        $motDePasseChiffreExistant = $stmtExistant->fetchColumn();
        if ($motDePasseApplication === '' && !$motDePasseChiffreExistant) {
            throw new InvalidArgumentException('Saisissez un mot de passe d’application pour configurer Gmail.');
        }

        $chiffre = $motDePasseApplication !== ''
            ? $this->chiffrer($motDePasseApplication)
            : $motDePasseChiffreExistant;
        $stmt = $this->conn->prepare(
            "INSERT INTO parametres_email
                (id, compte_google, mot_de_passe_chiffre, modifie_par)
             VALUES (1, :email, :mot_de_passe_chiffre, :admin_id)
             ON DUPLICATE KEY UPDATE
                compte_google = VALUES(compte_google),
                mot_de_passe_chiffre = VALUES(mot_de_passe_chiffre),
                modifie_par = VALUES(modifie_par)"
        );
        $stmt->execute([
            ':email' => $email,
            ':mot_de_passe_chiffre' => $chiffre,
            ':admin_id' => $adminId,
        ]);
    }

    public function appliquerConfigurationGoogle(array $configuration): array {
        $stmt = $this->conn->query(
            "SELECT compte_google, mot_de_passe_chiffre
             FROM parametres_email WHERE id = 1 LIMIT 1"
        );
        $parametres = $stmt->fetch();
        if (!$parametres || empty($parametres['compte_google']) || empty($parametres['mot_de_passe_chiffre'])) {
            return $configuration;
        }

        $configuration['smtp_host'] = 'smtp.gmail.com';
        $configuration['smtp_port'] = 587;
        $configuration['smtp_security'] = 'tls';
        $configuration['smtp_username'] = (string) $parametres['compte_google'];
        $configuration['smtp_password'] = $this->dechiffrer((string) $parametres['mot_de_passe_chiffre']);
        $configuration['from_email'] = (string) $parametres['compte_google'];
        return $configuration;
    }

    private function chiffrer(string $valeur): string {
        $cle = $this->obtenirCleChiffrement();
        $nonce = random_bytes(12);
        $tag = '';
        $chiffre = openssl_encrypt($valeur, 'aes-256-gcm', $cle, OPENSSL_RAW_DATA, $nonce, $tag);
        if ($chiffre === false || strlen($tag) !== 16) {
            throw new RuntimeException('Le chiffrement des identifiants Gmail a échoué.');
        }
        return base64_encode($nonce . $tag . $chiffre);
    }

    private function dechiffrer(string $valeur): string {
        $donnees = base64_decode($valeur, true);
        if ($donnees === false || strlen($donnees) < 29) {
            throw new RuntimeException('Les identifiants Gmail enregistrés sont illisibles.');
        }
        $nonce = substr($donnees, 0, 12);
        $tag = substr($donnees, 12, 16);
        $chiffre = substr($donnees, 28);
        $clair = openssl_decrypt($chiffre, 'aes-256-gcm', $this->obtenirCleChiffrement(), OPENSSL_RAW_DATA, $nonce, $tag);
        if ($clair === false) {
            throw new RuntimeException('La clé de chiffrement Gmail est absente ou ne correspond pas aux identifiants enregistrés.');
        }
        return $clair;
    }

    private function obtenirCleChiffrement(): string {
        $cle = getenv('ALLOPRO_CREDENTIALS_KEY');
        if (is_string($cle) && $cle !== '') {
            if (preg_match('/\A[a-fA-F0-9]{64}\z/', $cle) !== 1) {
                throw new RuntimeException('ALLOPRO_CREDENTIALS_KEY doit contenir exactement 64 caractères hexadécimaux.');
            }
            $cleBinaire = hex2bin($cle);
            if ($cleBinaire === false) {
                throw new RuntimeException('La clé de chiffrement Gmail est invalide.');
            }
            return $cleBinaire;
        }

        $chemin = $this->cheminCleLocale();
        if (is_link($chemin)) {
            throw new RuntimeException('Le fichier de clé de chiffrement Gmail ne peut pas être un lien symbolique.');
        }
        if (is_file($chemin)) {
            $cleLocale = file_get_contents($chemin);
            if (!is_string($cleLocale) || strlen($cleLocale) !== 32) {
                throw new RuntimeException('Le fichier de clé de chiffrement Gmail est illisible ou corrompu.');
            }
            return $cleLocale;
        }

        $repertoire = dirname($chemin);
        if (!is_dir($repertoire) && !mkdir($repertoire, 0700, true) && !is_dir($repertoire)) {
            throw new RuntimeException('Impossible de créer le stockage privé de la clé Gmail.');
        }
        $cleLocale = random_bytes(32);
        $fichier = @fopen($chemin, 'x+b');
        if ($fichier === false) {
            if (is_file($chemin) && !is_link($chemin)) {
                $cleLocaleExistante = file_get_contents($chemin);
                if (is_string($cleLocaleExistante) && strlen($cleLocaleExistante) === 32) {
                    return $cleLocaleExistante;
                }
            }
            throw new RuntimeException('Impossible de créer le fichier privé de clé de chiffrement Gmail.');
        }
        try {
            if (fwrite($fichier, $cleLocale) !== 32 || !fflush($fichier)) {
                throw new RuntimeException('Impossible d’enregistrer la clé de chiffrement Gmail.');
            }
        } catch (Throwable $e) {
            fclose($fichier);
            @unlink($chemin);
            throw $e;
        }
        fclose($fichier);
        if (DIRECTORY_SEPARATOR !== '\\') {
            @chmod($chemin, 0600);
        }
        return $cleLocale;
    }

    private function cheminCleLocale(): string {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage'
            . DIRECTORY_SEPARATOR . 'credentials.key';
    }
}
