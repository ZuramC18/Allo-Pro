<?php
require_once __DIR__ . '/../config/database.php';

class NoteDemande {
    private PDO $conn;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function ajouter(int $demandeId, int $auteurId, string $note): void {
        $stmt = $this->conn->prepare(
            "INSERT INTO notes_demandes (demande_id, auteur_id, note)
             VALUES (:demande_id, :auteur_id, :note)"
        );
        $stmt->execute([
            ':demande_id' => $demandeId,
            ':auteur_id' => $auteurId,
            ':note' => $note,
        ]);
    }

    public function getByDemande(int $demandeId): array {
        $stmt = $this->conn->prepare(
            "SELECT n.note, n.date_creation, u.nom AS auteur_nom
             FROM notes_demandes n
             JOIN users u ON u.id = n.auteur_id
             WHERE n.demande_id = :demande_id
             ORDER BY n.date_creation DESC, n.id DESC"
        );
        $stmt->execute([':demande_id' => $demandeId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
