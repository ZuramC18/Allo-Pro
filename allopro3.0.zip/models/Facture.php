<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/facture.php';
require_once __DIR__ . '/../includes/PdfFacture.php';
require_once __DIR__ . '/../includes/SmtpMailer.php';

class Facture {
    private PDO $conn;
    private array $configuration;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
        $this->configuration = require __DIR__ . '/../config/facture.php';
    }

    public function getParametresVendeur(): array {
        $stmt = $this->conn->query(
            "SELECT vendeur_nom, vendeur_identifiant, vendeur_adresse, vendeur_telephone, vendeur_email
             FROM parametres_facturation WHERE id = 1 LIMIT 1"
        );
        $enregistres = $stmt->fetch();
        if (!$enregistres) {
            return $this->configuration;
        }

        foreach (['vendeur_nom', 'vendeur_identifiant', 'vendeur_adresse', 'vendeur_telephone', 'vendeur_email'] as $cle) {
            if ($enregistres[$cle] !== null) {
                $this->configuration[$cle] = $enregistres[$cle];
            }
        }
        return $this->configuration;
    }

    public function enregistrerParametresVendeur(array $parametres, int $adminId): bool {
        $champs = ['vendeur_nom', 'vendeur_identifiant', 'vendeur_adresse', 'vendeur_telephone', 'vendeur_email'];
        if (array_diff(array_keys($parametres), $champs) || array_diff($champs, array_keys($parametres))) {
            throw new InvalidArgumentException('Les champs des coordonnées vendeur sont invalides.');
        }
        foreach ($parametres as $cle => $valeur) {
            if (!is_string($valeur)) {
                throw new InvalidArgumentException('Les coordonnées vendeur doivent être du texte.');
            }
            $parametres[$cle] = trim($valeur);
        }
        $limites = [
            'vendeur_nom' => 150,
            'vendeur_identifiant' => 100,
            'vendeur_adresse' => 255,
            'vendeur_telephone' => 30,
            'vendeur_email' => 150,
        ];
        foreach ($limites as $cle => $limite) {
            if (mb_strlen($parametres[$cle]) > $limite) {
                throw new InvalidArgumentException('Vérifiez la longueur du champ « ' . $cle . ' ».');
            }
        }
        if ($parametres['vendeur_nom'] === '') {
            throw new InvalidArgumentException('Le nom légal du vendeur est obligatoire.');
        }
        if ($parametres['vendeur_email'] !== '' && !filter_var($parametres['vendeur_email'], FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Saisissez une adresse e-mail valide pour le vendeur.');
        }

        $stmt = $this->conn->prepare(
            "INSERT INTO parametres_facturation
                (id, vendeur_nom, vendeur_identifiant, vendeur_adresse, vendeur_telephone, vendeur_email, modifie_par)
             VALUES (1, :nom, :identifiant, :adresse, :telephone, :email, :admin)
             ON DUPLICATE KEY UPDATE
                vendeur_nom = VALUES(vendeur_nom),
                vendeur_identifiant = VALUES(vendeur_identifiant),
                vendeur_adresse = VALUES(vendeur_adresse),
                vendeur_telephone = VALUES(vendeur_telephone),
                vendeur_email = VALUES(vendeur_email),
                modifie_par = VALUES(modifie_par)"
        );
        return $stmt->execute([
            ':nom' => $parametres['vendeur_nom'],
            ':identifiant' => $parametres['vendeur_identifiant'] !== '' ? $parametres['vendeur_identifiant'] : null,
            ':adresse' => $parametres['vendeur_adresse'] !== '' ? $parametres['vendeur_adresse'] : null,
            ':telephone' => $parametres['vendeur_telephone'] !== '' ? $parametres['vendeur_telephone'] : null,
            ':email' => $parametres['vendeur_email'] !== '' ? $parametres['vendeur_email'] : null,
            ':admin' => $adminId,
        ]);
    }

    public function genererEtEnvoyerPourReference(string $type, string $reference): array {
        $donnees = $this->chargerOperation($type, $reference);
        if (!$donnees) {
            throw new RuntimeException('La transaction payee est introuvable.');
        }

        $facture = $this->obtenirOuCreer($type, $reference, $donnees);
        $chemin = $this->cheminFichier((string) $facture['chemin_fichier']);
        if (!is_file($chemin)) {
            $this->ecrirePdf($facture, $donnees, $chemin);
        }
        if (($facture['email_statut'] ?? '') !== 'envoye') {
            $this->envoyer($facture, $donnees, $chemin);
            $facture = $this->getById((int) $facture['id']);
        }
        return $facture;
    }

    public function getPourClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT id, numero, type_operation, libelle, montant, devise, date_emission,
                    email_statut
             FROM factures
             WHERE client_id = :client_id
             ORDER BY date_emission DESC, id DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll();
    }

    public function getAllPourFinance(
        int $limite = 25,
        int $decalage = 0,
        ?string $recherche = null,
        ?string $statut = null,
        ?string $type = null
    ): array {
        $limite = max(1, min(100, $limite));
        $decalage = max(0, $decalage);
        $conditions = [];
        $parametres = [];
        if ($recherche !== null && $recherche !== '') {
            $conditions[] = "(f.numero LIKE :numero OR f.libelle LIKE :libelle
                OR f.email_destinataire LIKE :email OR u.nom LIKE :nom OR u.prenom LIKE :prenom
                OR CONCAT_WS(' ', u.prenom, u.nom) LIKE :client_complet)";
            $terme = '%' . $recherche . '%';
            $parametres[':numero'] = $terme;
            $parametres[':libelle'] = $terme;
            $parametres[':email'] = $terme;
            $parametres[':nom'] = $terme;
            $parametres[':prenom'] = $terme;
            $parametres[':client_complet'] = $terme;
        }
        if ($statut !== null && $statut !== '') {
            $conditions[] = 'f.email_statut = :statut';
            $parametres[':statut'] = $statut;
        }
        if ($type !== null && $type !== '') {
            $conditions[] = 'f.type_operation = :type';
            $parametres[':type'] = $type;
        }
        $where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
        $stmt = $this->conn->prepare(
            "SELECT f.id, f.numero, f.type_operation, f.libelle, f.montant, f.devise,
                    f.email_destinataire, f.email_statut, f.date_emission,
                    u.nom AS client_nom, u.prenom AS client_prenom
             FROM factures f
             JOIN users u ON u.id = f.client_id
             {$where}
             ORDER BY f.date_emission DESC, f.id DESC
             LIMIT :limite"
            . ' OFFSET :decalage'
        );
        foreach ($parametres as $cle => $valeur) {
            $stmt->bindValue($cle, $valeur);
        }
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->bindValue(':decalage', $decalage, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterPourFinance(?string $recherche = null, ?string $statut = null, ?string $type = null): int {
        $conditions = [];
        $parametres = [];
        if ($recherche !== null && $recherche !== '') {
            $conditions[] = "(f.numero LIKE :numero OR f.libelle LIKE :libelle
                OR f.email_destinataire LIKE :email OR u.nom LIKE :nom OR u.prenom LIKE :prenom
                OR CONCAT_WS(' ', u.prenom, u.nom) LIKE :client_complet)";
            $terme = '%' . $recherche . '%';
            $parametres = [
                ':numero' => $terme,
                ':libelle' => $terme,
                ':email' => $terme,
                ':nom' => $terme,
                ':prenom' => $terme,
                ':client_complet' => $terme,
            ];
        }
        if ($statut !== null && $statut !== '') {
            $conditions[] = 'f.email_statut = :statut';
            $parametres[':statut'] = $statut;
        }
        if ($type !== null && $type !== '') {
            $conditions[] = 'f.type_operation = :type';
            $parametres[':type'] = $type;
        }
        $where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) FROM factures f JOIN users u ON u.id = f.client_id{$where}"
        );
        $stmt->execute($parametres);
        return (int) $stmt->fetchColumn();
    }

    public function getStatistiquesFinance(): array {
        $stmt = $this->conn->query(
            "SELECT COUNT(*) AS nombre,
                    COALESCE(SUM(montant), 0) AS montant_total,
                    SUM(email_statut = 'envoye') AS envoyees,
                    SUM(email_statut = 'en_attente') AS en_attente,
                    SUM(email_statut = 'echec') AS echecs
             FROM factures"
        );
        $statistiques = $stmt->fetch();
        return [
            'nombre' => (int) $statistiques['nombre'],
            'montant_total' => (float) $statistiques['montant_total'],
            'envoyees' => (int) $statistiques['envoyees'],
            'en_attente' => (int) $statistiques['en_attente'],
            'echecs' => (int) $statistiques['echecs'],
        ];
    }

    public function getPourFinanceParId(int $id): ?array {
        $stmt = $this->conn->prepare(
            "SELECT f.id, f.numero, f.reference_source, f.type_operation, f.client_id,
                    f.libelle, f.montant, f.devise, f.email_destinataire, f.chemin_fichier,
                    f.email_statut, f.email_envoye_at, f.email_erreur, f.date_emission,
                    u.nom AS client_nom, u.prenom AS client_prenom, u.email AS client_email,
                    u.telephone AS client_telephone
             FROM factures f
             JOIN users u ON u.id = f.client_id
             WHERE f.id = :id
             LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $facture = $stmt->fetch();
        return $facture ?: null;
    }

    public function getFichierPourFinance(int $id): ?array {
        $stmt = $this->conn->prepare(
            "SELECT id, numero, chemin_fichier FROM factures WHERE id = :id LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $facture = $stmt->fetch();
        if (!$facture) {
            return null;
        }
        if ((string) $facture['chemin_fichier'] === '') {
            throw new RuntimeException('Aucun PDF n’est archivé pour cette facture.');
        }
        $chemin = $this->cheminFichier((string) $facture['chemin_fichier']);
        if (!is_file($chemin) || !is_readable($chemin)) {
            throw new RuntimeException('Le fichier de cette facture est indisponible.');
        }
        $facture['chemin_absolu'] = $chemin;
        return $facture;
    }

    public function getFichierPourClient(int $id, int $clientId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT id, numero, chemin_fichier
             FROM factures
             WHERE id = :id AND client_id = :client_id
             LIMIT 1"
        );
        $stmt->execute([':id' => $id, ':client_id' => $clientId]);
        $facture = $stmt->fetch();
        if (!$facture) {
            return null;
        }
        $chemin = $this->cheminFichier((string) $facture['chemin_fichier']);
        if (!is_file($chemin) || !is_readable($chemin)) {
            throw new RuntimeException('Le fichier de cette facture est indisponible.');
        }
        $facture['chemin_absolu'] = $chemin;
        return $facture;
    }

    public function renvoyerPourClient(int $id, int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT reference_source, type_operation, email_statut
             FROM factures WHERE id = :id AND client_id = :client_id LIMIT 1"
        );
        $stmt->execute([':id' => $id, ':client_id' => $clientId]);
        $facture = $stmt->fetch();
        if (!$facture) {
            throw new RuntimeException('Cette facture est introuvable dans votre compte.');
        }
        if ($facture['email_statut'] === 'envoye') {
            throw new RuntimeException('Cette facture a deja ete envoyee a votre adresse email.');
        }
        return $this->genererEtEnvoyerPourReference(
            (string) $facture['type_operation'],
            (string) $facture['reference_source']
        );
    }

    public function getById(int $id): array {
        $stmt = $this->conn->prepare("SELECT * FROM factures WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $facture = $stmt->fetch();
        if (!$facture) {
            throw new RuntimeException('La facture archivee est introuvable.');
        }
        return $facture;
    }

    private function chargerOperation(string $type, string $reference): ?array {
        if ($reference === '' || strlen($reference) > 100) {
            throw new InvalidArgumentException('La reference de paiement est invalide.');
        }
        $requete = match ($type) {
            'intervention' => [
                "SELECT p.reference_transaction, p.montant, p.methode, p.date_paiement AS date_payee,
                        p.statut AS statut_paiement, u.id AS client_id, u.prenom, u.nom, u.email,
                        d.numero_dossier, c.nom AS categorie_nom
                 FROM paiements p
                 JOIN demandes d ON d.id = p.demande_id
                 JOIN categories c ON c.id = d.categorie_id
                 JOIN users u ON u.id = d.client_id
                 WHERE p.reference_transaction = :reference AND p.statut = 'valide'
                 LIMIT 1",
                'Intervention',
            ],
            'abonnement' => [
                "SELECT ac.reference_transaction, ac.montant_achat AS montant, NULL AS methode,
                        COALESCE(ac.date_paiement, ac.date_debut, ac.date_creation) AS date_payee,
                        ac.statut AS statut_paiement, u.id AS client_id, u.prenom, u.nom, u.email,
                        f.nom AS formule_nom
                 FROM abonnements_clients ac
                 JOIN formules_abonnement f ON f.id = ac.formule_id
                 JOIN users u ON u.id = ac.client_id
                 WHERE ac.reference_transaction = :reference AND ac.statut <> 'en_attente'
                 LIMIT 1",
                'Abonnement',
            ],
            'pass' => [
                "SELECT pa.reference_transaction, COALESCE(pa.montant_achat, pt.prix) AS montant,
                        NULL AS methode, COALESCE(pa.date_paiement, pa.date_achat) AS date_payee,
                        pa.statut AS statut_paiement, u.id AS client_id, u.prenom, u.nom, u.email,
                        pt.nom AS pass_nom, d.numero_dossier
                 FROM pass_achats pa
                 JOIN pass_types pt ON pt.id = pa.pass_type_id
                 JOIN users u ON u.id = pa.client_id
                 LEFT JOIN demandes d ON d.id = pa.demande_id AND d.client_id = pa.client_id
                 WHERE pa.reference_transaction = :reference AND pa.statut <> 'en_attente'
                 LIMIT 1",
                'Pass',
            ],
            default => throw new InvalidArgumentException('Le type de facture est invalide.'),
        };
        $stmt = $this->conn->prepare($requete[0]);
        $stmt->execute([':reference' => $reference]);
        $donnees = $stmt->fetch();
        if (!$donnees) {
            return null;
        }
        $donnees['type_operation'] = $type;
        $donnees['libelle'] = match ($type) {
            'intervention' => 'Intervention ' . ($donnees['categorie_nom'] ?? '') . (!empty($donnees['numero_dossier']) ? ' - dossier ' . $donnees['numero_dossier'] : ''),
            'abonnement' => 'Abonnement ' . ($donnees['formule_nom'] ?? ''),
            'pass' => 'Pass ' . ($donnees['pass_nom'] ?? '') . (!empty($donnees['numero_dossier']) ? ' - utilise pour le dossier ' . $donnees['numero_dossier'] : ''),
        };
        $donnees['date_payee'] = $donnees['date_payee'] ?: date('Y-m-d H:i:s');
        return $donnees;
    }

    private function obtenirOuCreer(string $type, string $reference, array $donnees): array {
        $stmt = $this->conn->prepare("SELECT * FROM factures WHERE reference_source = :reference LIMIT 1");
        $stmt->execute([':reference' => $reference]);
        $facture = $stmt->fetch();
        if ($facture) {
            return $facture;
        }

        $insert = $this->conn->prepare(
            "INSERT INTO factures
                (reference_source, type_operation, client_id, libelle, montant, devise, email_destinataire, email_statut)
             VALUES (:reference, :type, :client_id, :libelle, :montant, 'FCFA', :email, 'en_attente')"
        );
        try {
            $insert->execute([
                ':reference' => $reference,
                ':type' => $type,
                ':client_id' => (int) $donnees['client_id'],
                ':libelle' => $donnees['libelle'],
                ':montant' => $donnees['montant'],
                ':email' => $donnees['email'],
            ]);
            $id = (int) $this->conn->lastInsertId();
            $numero = 'FAC-' . date('Y', strtotime((string) $donnees['date_payee'])) . '-' . str_pad((string) $id, 8, '0', STR_PAD_LEFT);
            $maj = $this->conn->prepare("UPDATE factures SET numero = :numero WHERE id = :id");
            $maj->execute([':numero' => $numero, ':id' => $id]);
            return $this->getById($id);
        } catch (PDOException $e) {
            if ($e->getCode() !== '23000') {
                throw $e;
            }
            $stmt->execute([':reference' => $reference]);
            $facture = $stmt->fetch();
            if (!$facture) {
                throw $e;
            }
            return $facture;
        }
    }

    private function ecrirePdf(array $facture, array $donnees, string $chemin): void {
        $repertoire = dirname($chemin);
        if (!is_dir($repertoire) && !mkdir($repertoire, 0700, true) && !is_dir($repertoire)) {
            throw new RuntimeException('Impossible de creer le repertoire prive des factures.');
        }
        $configVendeur = $this->getParametresVendeur();
        $vendeur = array_filter([
            $configVendeur['vendeur_nom'] ?? 'ALLÔ PRO',
            !empty($configVendeur['vendeur_identifiant']) ? 'Identifiant legal : ' . $configVendeur['vendeur_identifiant'] : '',
            $configVendeur['vendeur_adresse'] ?? '',
            $configVendeur['vendeur_telephone'] ?? '',
            $configVendeur['vendeur_email'] ?? '',
        ], static fn(string $ligne): bool => $ligne !== '');
        $nomClient = trim((string) ($donnees['prenom'] ?? '') . ' ' . (string) ($donnees['nom'] ?? ''));
        $pdf = new PdfFacture();
        $contenu = $pdf->generer([
            'vendeur_nom' => (string) ($configVendeur['vendeur_nom'] ?? 'ALLÔ PRO'),
            'numero' => (string) $facture['numero'],
            'date' => date('d/m/Y H:i', strtotime((string) $donnees['date_payee'])),
            'vendeur' => $vendeur,
            'client' => array_filter([$nomClient, (string) ($donnees['email'] ?? '')], static fn(string $ligne): bool => $ligne !== ''),
            'designation' => [$donnees['libelle']],
            'montant' => number_format((float) $donnees['montant'], 0, ',', ' '),
            'reference_courte' => substr((string) $donnees['reference_transaction'], 0, 18),
            'reference' => (string) $donnees['reference_transaction'],
            'methode' => $this->libelleMethode($donnees['methode'] ?? null),
        ]);
        if (file_put_contents($chemin, $contenu, LOCK_EX) === false) {
            throw new RuntimeException('Impossible d’archiver le PDF de la facture.');
        }
        $maj = $this->conn->prepare("UPDATE factures SET chemin_fichier = :chemin WHERE id = :id");
        $maj->execute([':chemin' => basename($chemin), ':id' => $facture['id']]);
    }

    private function envoyer(array $facture, array $donnees, string $chemin): void {
        try {
            $nomClient = trim((string) ($donnees['prenom'] ?? '') . ' ' . (string) ($donnees['nom'] ?? ''));
            $vendeur = $this->getParametresVendeur();
            $montant = number_format((float) $facture['montant'], 0, ',', ' ') . ' FCFA';
            $reference = (string) ($donnees['reference_transaction'] ?? '');
            $methode = $this->libelleMethode($donnees['methode'] ?? null);
            $escape = static fn(string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            $detailsVendeur = array_filter([
                $vendeur['vendeur_identifiant'] ?? '',
                $vendeur['vendeur_adresse'] ?? '',
                $vendeur['vendeur_telephone'] ?? '',
                $vendeur['vendeur_email'] ?? '',
            ], static fn($value): bool => trim((string) $value) !== '');
            $detailsClient = array_filter([
                $nomClient,
                (string) ($donnees['email'] ?? ''),
            ], static fn($value): bool => trim((string) $value) !== '');
            $designation = $escape((string) $facture['libelle']);
            $numero = $escape((string) $facture['numero']);
            $date = $escape(date('d/m/Y', strtotime((string) ($donnees['date_payee'] ?? 'now'))));
            $referenceHtml = $escape($reference);
            $methodeHtml = $escape($methode);
            $nomVendeur = $escape((string) ($vendeur['vendeur_nom'] ?? 'ALLÔ PRO'));
            $blocVendeur = implode('<br>', array_map($escape, array_map('strval', $detailsVendeur)));
            $blocClient = implode('<br>', array_map($escape, array_map('strval', $detailsClient)));
            $html = '<!doctype html><html lang="fr"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                . '<body style="margin:0;padding:28px 12px;background:#f1f4f5;font-family:Arial,Helvetica,sans-serif;color:#172b33">'
                . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:680px;margin:0 auto;background:#fff;border:1px solid #e1e7e9;border-radius:14px;overflow:hidden">'
                . '<tr><td style="padding:30px 34px 25px;background:#123c4d;border-bottom:5px solid #e8a33d">'
                . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr>'
                . '<td style="font-size:22px;font-weight:700;letter-spacing:.2px;color:#fff">' . $nomVendeur . '<div style="margin-top:7px;font-size:10px;font-weight:400;letter-spacing:1.5px;color:#c4d5da">SERVICES ET INTERVENTIONS</div></td>'
                . '<td align="right" style="font-size:25px;font-weight:700;letter-spacing:1.5px;color:#fff">FACTURE<div style="margin-top:8px;font-size:13px;letter-spacing:0;color:#f2bd72">' . $numero . '</div></td>'
                . '</tr></table></td></tr>'
                . '<tr><td style="padding:26px 34px 6px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr>'
                . '<td width="50%" valign="top" style="padding:0 12px 16px 0"><div style="margin-bottom:10px;font-size:10px;font-weight:700;letter-spacing:1.2px;color:#73868d">VENDEUR</div>'
                . '<div style="padding:14px;background:#f4f6f7;border-top:3px solid #e8a33d;font-size:13px;line-height:1.7"><strong>' . $nomVendeur . '</strong><br>' . $blocVendeur . '</div></td>'
                . '<td width="50%" valign="top" style="padding:0 0 16px 12px"><div style="margin-bottom:10px;font-size:10px;font-weight:700;letter-spacing:1.2px;color:#73868d">FACTURE À</div>'
                . '<div style="padding:14px;background:#f4f6f7;border-top:3px solid #e8a33d;font-size:13px;line-height:1.7">' . $blocClient . '</div></td>'
                . '</tr></table></td></tr>'
                . '<tr><td style="padding:0 34px 20px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse">'
                . '<tr style="background:#123c4d;color:#fff"><th align="left" style="padding:12px;font-size:10px;letter-spacing:.7px">DESCRIPTION</th><th align="right" style="padding:12px;font-size:10px;letter-spacing:.7px">MONTANT</th></tr>'
                . '<tr><td style="padding:18px 12px;border-bottom:1px solid #e4e9eb;font-size:13px;line-height:1.6">' . $designation . '<div style="margin-top:4px;font-size:11px;color:#72838a">Réf. paiement : ' . $referenceHtml . '</div></td>'
                . '<td align="right" valign="top" style="padding:18px 12px;border-bottom:1px solid #e4e9eb;font-size:13px;white-space:nowrap">' . $escape($montant) . '</td></tr>'
                . '<tr><td align="right" style="padding:16px 12px;font-size:12px;font-weight:700;letter-spacing:.7px;color:#52656c">TOTAL PAYÉ</td>'
                . '<td align="right" style="padding:16px 12px;background:#123c4d;font-size:17px;font-weight:700;color:#fff;white-space:nowrap">' . $escape($montant) . '</td></tr>'
                . '</table></td></tr>'
                . '<tr><td style="padding:0 34px 24px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#edf6f2;border:1px solid #d8ebe2;border-radius:8px"><tr>'
                . '<td style="padding:14px;font-size:12px;line-height:1.7;color:#285844"><strong style="color:#1b6844">✓ PAIEMENT CONFIRMÉ</strong><br>Émis le ' . $date . ' · ' . $methodeHtml . '</td>'
                . '</tr></table></td></tr>'
                . '<tr><td style="padding:18px 34px;background:#f4f6f7;border-top:1px solid #e4e9eb;text-align:center;font-size:11px;line-height:1.6;color:#718087">'
                . 'Cette facture est archivée dans votre espace ALLÔ PRO.<br>Merci pour votre confiance.</td></tr>'
                . '</table></body></html>';
            $texte = "FACTURE {$facture['numero']}\n"
                . "Vendeur : " . ($vendeur['vendeur_nom'] ?? 'ALLÔ PRO') . "\n"
                . (count($detailsVendeur) ? implode("\n", array_map('strval', $detailsVendeur)) . "\n" : '')
                . "\nFacture à : " . implode(' — ', array_map('strval', $detailsClient)) . "\n"
                . "Date d’émission : {$date}\n\n"
                . "DESCRIPTION : {$facture['libelle']}\n"
                . "Référence de paiement : {$reference}\n"
                . "Moyen de paiement : {$methode}\n"
                . "TOTAL PAYÉ : {$montant}\n\n"
                . "Paiement confirmé. Cette facture est archivée dans votre espace ALLÔ PRO.\n"
                . "Merci pour votre confiance.";
            (new SmtpMailer())->envoyer(
                (string) $facture['email_destinataire'],
                $nomClient,
                'Facture ' . $facture['numero'] . ' — ALLÔ PRO',
                $texte,
                $html,
                [['chemin' => $chemin, 'nom' => $facture['numero'] . '.pdf', 'mime' => 'application/pdf']]
            );
            $stmt = $this->conn->prepare(
                "UPDATE factures SET email_statut = 'envoye', email_envoye_at = NOW(), email_erreur = NULL
                 WHERE id = :id"
            );
            $stmt->execute([':id' => $facture['id']]);
        } catch (Throwable $e) {
            $stmt = $this->conn->prepare(
                "UPDATE factures SET email_statut = 'echec', email_erreur = :erreur WHERE id = :id"
            );
            $stmt->execute([
                ':erreur' => mb_substr($e->getMessage(), 0, 1000),
                ':id' => $facture['id'],
            ]);
            error_log('Envoi de la facture ' . $facture['numero'] . ' impossible : ' . $e->getMessage());
        }
    }

    private function cheminFichier(string $nom): string {
        if ($nom !== '' && basename($nom) !== $nom) {
            throw new RuntimeException('Le chemin de facture archive est invalide.');
        }
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'factures'
            . DIRECTORY_SEPARATOR . ($nom !== '' ? $nom : 'facture-' . bin2hex(random_bytes(12)) . '.pdf');
    }

    private function libelleMethode(?string $methode): string {
        return match ($methode) {
            'wave' => 'Wave',
            'orange_money' => 'Orange Money',
            'autre' => 'Autre',
            default => 'Paiement confirme',
        };
    }
}
