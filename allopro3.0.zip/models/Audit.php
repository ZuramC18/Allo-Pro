<?php
require_once __DIR__ . '/../config/database.php';

class Audit {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    private function construireFiltres(array $f, array &$params) {
        $where = " WHERE 1=1";
        if (!empty($f['debut'])) { $where .= " AND date_creation >= :debut"; $params[':debut'] = $f['debut']; }
        if (!empty($f['acteur_type'])) { $where .= " AND acteur_type = :acteur_type"; $params[':acteur_type'] = $f['acteur_type']; }
        if (!empty($f['matricule'])) { $where .= " AND acteur_matricule = :matricule"; $params[':matricule'] = $f['matricule']; }
        if (!empty($f['categorie'])) { $where .= " AND action LIKE :categorie"; $params[':categorie'] = $f['categorie'] . '.%'; }
        if (!empty($f['pays'])) { $where .= " AND pays = :pays"; $params[':pays'] = $f['pays']; }
        if (!empty($f['q'])) {
            $where .= " AND (cible LIKE :q1 OR detail LIKE :q2 OR acteur_nom LIKE :q3 OR action LIKE :q4)";
            $terme = '%' . $f['q'] . '%';
            $params[':q1'] = $terme; $params[':q2'] = $terme; $params[':q3'] = $terme; $params[':q4'] = $terme;
        }
        return $where;
    }

    public function rechercher(array $filtres, $limite, $offset) {
        $params = [];
        $sql = "SELECT * FROM audit_log" . $this->construireFiltres($filtres, $params) . " ORDER BY id DESC LIMIT :limite OFFSET :offset";
        $stmt = $this->conn->prepare($sql);
        foreach ($params as $cle => $valeur) { $stmt->bindValue($cle, $valeur); }
        $stmt->bindValue(':limite', (int) $limite, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int) $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById(int $id): array|false {
        $stmt = $this->conn->prepare("SELECT * FROM audit_log WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    public function compter(array $filtres) {
        $params = [];
        $stmt = $this->conn->prepare("SELECT COUNT(*) AS total FROM audit_log" . $this->construireFiltres($filtres, $params));
        $stmt->execute($params);
        return (int) $stmt->fetch()['total'];
    }

    public function stats() {
        return $this->conn->query(
            "SELECT
                COALESCE(SUM(date_creation >= CURDATE()), 0) AS aujourdhui,
                COALESCE(SUM(date_creation >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)), 0) AS sept_jours,
                COALESCE(SUM(action = 'connexion.echec' AND date_creation >= DATE_SUB(NOW(), INTERVAL 24 HOUR)), 0) AS echecs_24h,
                COUNT(DISTINCT CASE WHEN date_creation >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) THEN acteur_matricule END) AS acteurs_7j
             FROM audit_log"
        )->fetch();
    }

    public function categories() {
        return $this->conn->query("SELECT DISTINCT SUBSTRING_INDEX(action, '.', 1) AS categorie FROM audit_log ORDER BY categorie")->fetchAll(PDO::FETCH_COLUMN);
    }

    public function typesActeurs() {
        return $this->conn->query("SELECT DISTINCT acteur_type FROM audit_log ORDER BY acteur_type")->fetchAll(PDO::FETCH_COLUMN);
    }

    public function paysDistincts() {
        return $this->conn->query("SELECT DISTINCT pays FROM audit_log WHERE pays IS NOT NULL ORDER BY pays")->fetchAll(PDO::FETCH_COLUMN);
    }
}