<?php
require_once __DIR__ . '/../config/database.php';

class ConfigurationAttributionDemandes {
    private const VALEURS_DEFAUT = [
        'limite_charge_active' => '1',
        'charge_maximale' => '3',
        'score_zone_active' => '1',
        'score_zone_quartier' => '45',
        'score_zone_elargie' => '34',
        'score_zone_ville' => '28',
        'score_competence_active' => '1',
        'score_competence_exacte' => '25',
        'score_competence_compatible' => '15',
        'score_reputation_active' => '1',
        'score_reputation_par_point' => '4',
        'score_niveau_active' => '1',
        'score_niveau_certifie' => '4',
        'score_niveau_premium' => '7',
        'score_niveau_excellence' => '10',
        'score_charge_active' => '1',
        'penalite_charge' => '12',
        'priorite_urgence_active' => '1',
        'priorite_abonnement_active' => '1',
        'priorite_anciennete_active' => '1',
        'horizon_creneaux_active' => '1',
        'horizon_creneaux_jours' => '30',
    ];

    private const PLAGES_NUMERIQUES = [
        'charge_maximale' => [1, 100],
        'score_zone_quartier' => [0, 1000],
        'score_zone_elargie' => [0, 1000],
        'score_zone_ville' => [0, 1000],
        'score_competence_exacte' => [0, 1000],
        'score_competence_compatible' => [0, 1000],
        'score_reputation_par_point' => [0, 100],
        'score_niveau_certifie' => [0, 100],
        'score_niveau_premium' => [0, 100],
        'score_niveau_excellence' => [0, 100],
        'penalite_charge' => [0, 100],
        'horizon_creneaux_jours' => [1, 365],
    ];

    private const LIBELLES = [
        'charge_maximale' => 'le plafond d’interventions actives',
        'score_zone_quartier' => 'le score de quartier exact',
        'score_zone_elargie' => 'le score de zone élargie',
        'score_zone_ville' => 'le score de ville',
        'score_competence_exacte' => 'le score de compétence exacte',
        'score_competence_compatible' => 'le score de pôle compatible',
        'score_reputation_par_point' => 'les points par étoile de réputation',
        'score_niveau_certifie' => 'le bonus du niveau certifié',
        'score_niveau_premium' => 'le bonus du niveau premium',
        'score_niveau_excellence' => 'le bonus du niveau excellence',
        'penalite_charge' => 'la pénalité par intervention active',
        'horizon_creneaux_jours' => 'l’horizon de recherche des créneaux',
    ];

    private PDO $conn;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function getAll(): array {
        $configuration = self::VALEURS_DEFAUT;
        $stmt = $this->conn->query(
            'SELECT cle, valeur FROM attribution_demandes_configuration'
        );
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $ligne) {
            if (array_key_exists($ligne['cle'], $configuration)) {
                $configuration[$ligne['cle']] = (string) $ligne['valeur'];
            }
        }
        return $configuration;
    }

    public function validerSoumission(array $soumission): array {
        $configuration = [];
        $erreur = '';
        foreach (self::VALEURS_DEFAUT as $cle => $defaut) {
            if (str_ends_with($cle, '_active')) {
                $configuration[$cle] = isset($soumission[$cle]) ? '1' : '0';
                continue;
            }

            $brut = is_string($soumission[$cle] ?? null)
                ? trim($soumission[$cle])
                : (string) ($soumission[$cle] ?? '');
            [$minimum, $maximum] = self::PLAGES_NUMERIQUES[$cle];
            $valeur = filter_var($brut, FILTER_VALIDATE_INT, [
                'options' => ['min_range' => $minimum, 'max_range' => $maximum],
            ]);
            if ($valeur === false) {
                $configuration[$cle] = $brut;
                if ($erreur === '') {
                    $erreur = sprintf(
                        'Le paramètre %s doit être un entier compris entre %d et %d.',
                        self::LIBELLES[$cle],
                        $minimum,
                        $maximum
                    );
                }
                continue;
            }
            $configuration[$cle] = (string) $valeur;
        }

        return [
            'valide' => $erreur === '',
            'configuration' => $configuration,
            'erreur' => $erreur,
        ];
    }

    public function enregistrer(array $configuration): bool {
        if (array_diff_key($configuration, self::VALEURS_DEFAUT)
            || array_diff_key(self::VALEURS_DEFAUT, $configuration)) {
            throw new InvalidArgumentException('La configuration de l’algorithme est incomplète.');
        }

        foreach (self::VALEURS_DEFAUT as $cle => $_) {
            if (str_ends_with($cle, '_active')) {
                if (!in_array((string) $configuration[$cle], ['0', '1'], true)) {
                    throw new InvalidArgumentException('Une option de l’algorithme est invalide.');
                }
                continue;
            }
            [$minimum, $maximum] = self::PLAGES_NUMERIQUES[$cle];
            if (filter_var($configuration[$cle], FILTER_VALIDATE_INT, [
                'options' => ['min_range' => $minimum, 'max_range' => $maximum],
            ]) === false) {
                throw new InvalidArgumentException(sprintf(
                    'Le paramètre « %s » doit être compris entre %d et %d.',
                    $cle,
                    $minimum,
                    $maximum
                ));
            }
        }

        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                'INSERT INTO attribution_demandes_configuration (cle, valeur)
                 VALUES (:cle, :valeur)
                 ON DUPLICATE KEY UPDATE valeur = VALUES(valeur)'
            );
            foreach ($configuration as $cle => $valeur) {
                $stmt->execute([':cle' => $cle, ':valeur' => (string) $valeur]);
            }
            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }
}
