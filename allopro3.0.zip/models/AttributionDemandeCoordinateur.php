<?php
require_once __DIR__ . '/../config/database.php';

class AttributionDemandeCoordinateur {
    private PDO $conn;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function transmettre(int $demandeId, int $conseillerId, string $commentaire): bool {
        $this->conn->beginTransaction();
        try {
            $verrou = $this->conn->prepare(
                "SELECT statut FROM demandes WHERE id = :demande_id FOR UPDATE"
            );
            $verrou->execute([':demande_id' => $demandeId]);
            if ($verrou->fetchColumn() !== 'nouvelle') {
                $this->conn->rollBack();
                return false;
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO attributions_demandes_coordinateurs
                    (demande_id, conseiller_id, commentaire_interne)
                 VALUES (:demande_id, :conseiller_id, :commentaire)"
            );
            $stmt->execute([
                ':demande_id' => $demandeId,
                ':conseiller_id' => $conseillerId,
                ':commentaire' => $commentaire,
            ]);
            $this->conn->commit();
            return true;
        } catch (PDOException $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            if ((int) ($exception->errorInfo[1] ?? 0) === 1062) {
                return false;
            }
            throw $exception;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getByDemande(int $demandeId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT a.*, conseiller.nom AS conseiller_nom, coordinateur.nom AS coordinateur_nom
             FROM attributions_demandes_coordinateurs a
             JOIN users conseiller ON conseiller.id = a.conseiller_id
             LEFT JOIN users coordinateur ON coordinateur.id = a.coordinateur_id
             WHERE a.demande_id = :demande_id
             LIMIT 1"
        );
        $stmt->execute([':demande_id' => $demandeId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getFileAttente(): array {
        return $this->conn->query(
            "SELECT a.id AS attribution_id, a.demande_id, a.commentaire_interne,
                    a.date_attribution, conseiller.nom AS conseiller_nom,
                    d.numero_dossier, d.urgence, d.date_creation, d.date_creneau_souhaite,
                    d.heure_creneau_souhaitee, d.description,
                    client.nom AS client_nom, categorie.nom AS categorie_nom,
                    s.nom AS site_b2b_nom, entreprise.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    adresse.quartier, adresse.ville
             FROM attributions_demandes_coordinateurs a
             JOIN demandes d ON d.id = a.demande_id
             JOIN users conseiller ON conseiller.id = a.conseiller_id
             JOIN users client ON client.id = d.client_id
             JOIN categories categorie ON categorie.id = d.categorie_id
             JOIN adresses adresse ON adresse.id = d.adresse_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b entreprise ON entreprise.id = s.entreprise_b2b_id
             WHERE a.statut = 'en_attente' AND d.statut = 'nouvelle'
             ORDER BY d.urgence DESC, a.date_attribution ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function compterEnAttente(): int {
        return (int) $this->conn->query(
            "SELECT COUNT(*)
             FROM attributions_demandes_coordinateurs a
             JOIN demandes d ON d.id = a.demande_id
             WHERE a.statut = 'en_attente' AND d.statut = 'nouvelle'"
        )->fetchColumn();
    }
}
