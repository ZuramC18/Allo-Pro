<?php
require_once __DIR__ . '/../config/database.php';

class EntrepriseB2B {
    private PDO $conn;

    private const PERMISSIONS_MEMBRE = [
        'accueil' => 'Accueil',
        'sites' => 'Sites',
        'demandes' => 'Demandes et suivi des dossiers',
        'devis' => 'Devis',
        'tickets' => 'Tickets / SAV',
        'interventions' => 'Interventions en cours',
        'contrats' => 'Contrats et SLA',
        'factures' => 'Factures',
        'paiements' => 'Paiements',
        'rapports' => 'Rapports',
        'historique' => 'Historique des interventions',
        'documents' => 'Documents',
        'parametres' => 'Paramètres du compte',
    ];

    private const PERMISSIONS_MEMBRE_DEFAUT = [
        'accueil',
        'sites',
        'demandes',
        'devis',
        'interventions',
        'historique',
        'documents',
    ];

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    private function verifierGestionContratFinance(int $userId): void {
        $acteur = $this->conn->prepare(
            "SELECT role FROM users
             WHERE id = :id AND role IN ('admin', 'finance') AND statut = 'actif'
             LIMIT 1"
        );
        $acteur->execute([':id' => $userId]);
        if (!$acteur->fetchColumn()) {
            throw new RuntimeException('Seuls les rôles Finance et Admin peuvent gérer les contrats entreprise.');
        }
    }

    public function nomExiste(string $nom, ?int $saufEntrepriseId = null): bool {
        $nomNormalise = $this->normaliserNom($nom);
        if ($nomNormalise === '') {
            return false;
        }
        $sql = 'SELECT 1 FROM entreprises_b2b WHERE nom_normalise = :nom';
        $parametres = [':nom' => $nomNormalise];
        if ($saufEntrepriseId !== null) {
            $sql .= ' AND id <> :entreprise_id';
            $parametres[':entreprise_id'] = $saufEntrepriseId;
        }
        $sql .= ' LIMIT 1';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($parametres);
        return (bool) $stmt->fetchColumn();
    }

    public function creerPourClient(int $userId, string $nom): int {
        $nom = trim($nom);
        if ($nom === '' || mb_strlen($nom) > 150) {
            throw new InvalidArgumentException('Le nom de l’entreprise doit contenir entre 1 et 150 caractères.');
        }
        if ($this->nomExiste($nom)) {
            throw new InvalidArgumentException('Une entreprise porte déjà ce nom. Choisissez un nom différent.');
        }
        $nomNormalise = $this->normaliserNom($nom);

        $stmt = $this->conn->prepare(
            "SELECT prenom, nom, email, telephone
             FROM users
             WHERE id = :user_id AND role = 'client' AND email_verifie = 1 AND statut = 'actif'
             LIMIT 1"
        );
        $stmt->execute([':user_id' => $userId]);
        $client = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$client) {
            throw new RuntimeException('Un compte client actif avec une adresse e-mail vérifiée est nécessaire.');
        }

        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO entreprises_b2b
                    (nom, nom_normalise, interlocuteur_nom, interlocuteur_telephone, interlocuteur_email, cree_par_user_id, statut)
                 VALUES (:nom, :nom_normalise, :interlocuteur, :telephone, :email, :createur, 'actif')"
            );
            $stmt->execute([
                ':nom' => $nom,
                ':nom_normalise' => $nomNormalise,
                ':interlocuteur' => trim($client['prenom'] . ' ' . $client['nom']),
                ':telephone' => $client['telephone'],
                ':email' => $client['email'],
                ':createur' => $userId,
            ]);
            $entrepriseId = (int) $this->conn->lastInsertId();
            $this->ajouterMembreAdmin($entrepriseId, $userId, $userId);
            $this->conn->commit();
            return $entrepriseId;
        } catch (PDOException $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            if ((int) ($exception->errorInfo[1] ?? 0) === 1062) {
                throw new InvalidArgumentException('Une entreprise porte déjà ce nom. Choisissez un nom différent.', 0, $exception);
            }
            throw $exception;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getEntreprisesParMembre(int $userId): array {
        $stmt = $this->conn->prepare(
            "SELECT e.id, e.nom, e.statut, m.role AS role_membre
             FROM entreprises_b2b e
             JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = e.id
             WHERE m.user_id = :user_id AND m.statut = 'actif' AND e.statut = 'actif'
             ORDER BY e.nom"
        );
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getEntreprisePourMembre(int $entrepriseId, int $userId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT e.*, m.role AS role_membre
             FROM entreprises_b2b e
             JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = e.id
             WHERE e.id = :entreprise_id AND m.user_id = :user_id
               AND m.statut = 'actif' AND e.statut = 'actif'
             LIMIT 1"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId, ':user_id' => $userId]);
        $entreprise = $stmt->fetch(PDO::FETCH_ASSOC);
        return $entreprise ?: null;
    }

    public static function getCataloguePermissionsMembre(): array {
        return self::PERMISSIONS_MEMBRE;
    }

    public function getPermissionsPourMembre(int $entrepriseId, int $userId, string $role): array {
        if ($role === 'admin') {
            return array_keys(self::PERMISSIONS_MEMBRE);
        }
        $stmt = $this->conn->prepare(
            "SELECT permission_key, autorise
             FROM entreprises_b2b_membres_permissions
             WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId, ':user_id' => $userId]);
        $lignes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!$lignes) {
            return self::PERMISSIONS_MEMBRE_DEFAUT;
        }
        return array_values(array_map(
            static fn(array $ligne): string => (string) $ligne['permission_key'],
            array_filter($lignes, static fn(array $ligne): bool => (int) $ligne['autorise'] === 1)
        ));
    }

    public function getPermissionsMembre(int $entrepriseId, int $adminId, int $membreId): array {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur peut gérer les permissions.');
        }
        $membre = $this->conn->prepare(
            "SELECT role FROM entreprises_b2b_membres
             WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id AND statut = 'actif'
             LIMIT 1"
        );
        $membre->execute([':entreprise_id' => $entrepriseId, ':user_id' => $membreId]);
        if ($membre->fetchColumn() !== 'membre') {
            throw new InvalidArgumentException('Ce membre ne peut pas être configuré.');
        }
        $stmt = $this->conn->prepare(
            "SELECT permission_key, autorise
             FROM entreprises_b2b_membres_permissions
             WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId, ':user_id' => $membreId]);
        $lignes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!$lignes) {
            return self::PERMISSIONS_MEMBRE_DEFAUT;
        }
        return array_values(array_map(
            static fn(array $ligne): string => (string) $ligne['permission_key'],
            array_filter($lignes, static fn(array $ligne): bool => (int) $ligne['autorise'] === 1)
        ));
    }

    public function enregistrerPermissionsMembre(int $entrepriseId, int $adminId, int $membreId, array $permissions): void {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur peut gérer les permissions.');
        }
        $membre = $this->conn->prepare(
            "SELECT role FROM entreprises_b2b_membres
             WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id AND statut = 'actif'
             LIMIT 1"
        );
        $membre->execute([':entreprise_id' => $entrepriseId, ':user_id' => $membreId]);
        if ($membre->fetchColumn() !== 'membre') {
            throw new InvalidArgumentException('Ce membre ne peut pas être configuré.');
        }
        foreach ($permissions as $permission) {
            if (!is_string($permission) || !array_key_exists($permission, self::PERMISSIONS_MEMBRE)) {
                throw new InvalidArgumentException('Une permission sélectionnée est invalide.');
            }
        }
        $permissions = array_fill_keys($permissions, true);
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO entreprises_b2b_membres_permissions
                    (entreprise_b2b_id, user_id, permission_key, autorise)
                 VALUES (:entreprise_id, :user_id, :permission_key, :autorise)
                 ON DUPLICATE KEY UPDATE autorise = VALUES(autorise)"
            );
            foreach (self::PERMISSIONS_MEMBRE as $permissionKey => $_label) {
                $stmt->execute([
                    ':entreprise_id' => $entrepriseId,
                    ':user_id' => $membreId,
                    ':permission_key' => $permissionKey,
                    ':autorise' => isset($permissions[$permissionKey]) ? 1 : 0,
                ]);
            }
            $this->conn->commit();
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    private function initialiserPermissionsMembre(int $entrepriseId, int $userId): void {
        $stmt = $this->conn->prepare(
            "INSERT INTO entreprises_b2b_membres_permissions
                (entreprise_b2b_id, user_id, permission_key, autorise)
             VALUES (:entreprise_id, :user_id, :permission_key, :autorise)
             ON DUPLICATE KEY UPDATE autorise = VALUES(autorise)"
        );
        foreach (self::PERMISSIONS_MEMBRE as $permissionKey => $_label) {
            $stmt->execute([
                ':entreprise_id' => $entrepriseId,
                ':user_id' => $userId,
                ':permission_key' => $permissionKey,
                ':autorise' => in_array($permissionKey, self::PERMISSIONS_MEMBRE_DEFAUT, true) ? 1 : 0,
            ]);
        }
    }

    public function getSites(int $entrepriseId, bool $actifsSeulement = false): array {
        $sql =
            "SELECT s.*, a.adresse_google, a.latitude, a.longitude, a.zone_id,
                    z.parent_id AS ville_id
             FROM sites_b2b s
             LEFT JOIN adresses a ON a.id = s.adresse_id
             LEFT JOIN zones z ON z.id = a.zone_id
             WHERE s.entreprise_b2b_id = :entreprise_id";
        if ($actifsSeulement) {
            $sql .= " AND s.statut = 'actif' AND s.adresse_id IS NOT NULL";
        }
        $sql .= " ORDER BY s.nom, s.id";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getVillesActives(): array {
        return $this->conn->query(
            "SELECT id, nom FROM zones WHERE type = 'ville' AND statut = 'active' ORDER BY nom"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getZonesActivesParVille(int $villeId): array {
        $stmt = $this->conn->prepare(
            "SELECT id, nom FROM zones
             WHERE parent_id = :ville_id AND type IN ('zone', 'quartier') AND statut = 'active'
             ORDER BY nom"
        );
        $stmt->execute([':ville_id' => $villeId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function creerSite(int $entrepriseId, int $createurId, array $site): int {
        $site = $this->validerSite($site);

        if (!$this->getEntreprisePourMembre($entrepriseId, $createurId)
            || !$this->estAdministrateur($entrepriseId, $createurId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut ajouter un site.');
        }

        $this->conn->beginTransaction();
        try {
            $adresse = $this->conn->prepare(
                "INSERT INTO adresses (user_id, libelle, quartier, zone_id, ville, details, supprimee)
                 VALUES (:user_id, :libelle, :quartier, :zone_id, :ville, :details, 0)"
            );
            $adresse->execute([
                ':user_id' => $createurId,
                ':libelle' => $site['nom'],
                ':quartier' => $site['quartier'],
                ':zone_id' => $site['zone_id'],
                ':ville' => $site['ville'],
                ':details' => $site['details'],
            ]);
            $adresseId = (int) $this->conn->lastInsertId();

            $stmt = $this->conn->prepare(
                "INSERT INTO sites_b2b
                    (entreprise_b2b_id, adresse_id, nom, quartier, ville, details, telephone_contact, email_contact)
                 VALUES (:entreprise_id, :adresse_id, :nom, :quartier, :ville, :details, :telephone, :email)"
            );
            $stmt->execute([
                ':entreprise_id' => $entrepriseId,
                ':adresse_id' => $adresseId,
                ':nom' => $site['nom'],
                ':quartier' => $site['quartier'],
                ':ville' => $site['ville'],
                ':details' => $site['details'] !== '' ? $site['details'] : null,
                ':telephone' => $site['telephone_contact'] !== '' ? $site['telephone_contact'] : null,
                ':email' => $site['email_contact'] !== '' ? $site['email_contact'] : null,
            ]);
            $siteId = (int) $this->conn->lastInsertId();
            $this->conn->commit();
            return $siteId;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function modifierSite(int $entrepriseId, int $adminId, int $siteId, array $donnees): bool {
        $site = $this->validerSite($donnees);
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut gérer les sites.');
        }

        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT adresse_id FROM sites_b2b
                 WHERE id = :site_id AND entreprise_b2b_id = :entreprise_id FOR UPDATE"
            );
            $stmt->execute([':site_id' => $siteId, ':entreprise_id' => $entrepriseId]);
            $adresseId = $stmt->fetchColumn();
            if (!$adresseId) {
                $this->conn->rollBack();
                return false;
            }

            $adresse = $this->conn->prepare(
                "UPDATE adresses SET libelle = :libelle, quartier = :quartier, zone_id = :zone_id, ville = :ville, details = :details
                 WHERE id = :adresse_id"
            );
            $adresse->execute([
                ':libelle' => $site['nom'], ':quartier' => $site['quartier'], ':zone_id' => $site['zone_id'],
                ':ville' => $site['ville'], ':details' => $site['details'], ':adresse_id' => (int) $adresseId,
            ]);
            $stmt = $this->conn->prepare(
                "UPDATE sites_b2b
                 SET nom = :nom, quartier = :quartier, ville = :ville, details = :details,
                     telephone_contact = :telephone, email_contact = :email
                 WHERE id = :site_id AND entreprise_b2b_id = :entreprise_id"
            );
            $stmt->execute([
                ':nom' => $site['nom'], ':quartier' => $site['quartier'], ':ville' => $site['ville'], ':details' => $site['details'] ?: null,
                ':telephone' => $site['telephone_contact'] ?: null, ':email' => $site['email_contact'] ?: null,
                ':site_id' => $siteId, ':entreprise_id' => $entrepriseId,
            ]);
            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function changerStatutSite(int $entrepriseId, int $adminId, int $siteId, string $statut): bool {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut gérer les sites.');
        }
        if (!in_array($statut, ['actif', 'inactif'], true)) {
            throw new InvalidArgumentException('Le statut du site est invalide.');
        }
        $stmt = $this->conn->prepare(
            "UPDATE sites_b2b SET statut = :statut
             WHERE id = :site_id AND entreprise_b2b_id = :entreprise_id"
        );
        $stmt->execute([
            ':statut' => $statut, ':site_id' => $siteId, ':entreprise_id' => $entrepriseId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function getMembres(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT u.id, u.prenom, u.nom, u.email, u.telephone, m.role, m.date_ajout
             FROM entreprises_b2b_membres m
             JOIN users u ON u.id = m.user_id
             WHERE m.entreprise_b2b_id = :entreprise_id AND m.statut = 'actif'
             ORDER BY FIELD(m.role, 'admin', 'membre'), u.nom, u.prenom"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getInvitationsEnAttenteEntreprise(int $entrepriseId, int $adminId): array {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut gérer les accès.');
        }
        $stmt = $this->conn->prepare(
            "SELECT i.id, i.date_creation, u.prenom, u.nom, u.email,
                    auteur.prenom AS auteur_prenom, auteur.nom AS auteur_nom
             FROM entreprises_b2b_invitations i
             JOIN users u ON u.id = i.invitee_user_id
             LEFT JOIN users auteur ON auteur.id = i.invite_par_user_id
             WHERE i.entreprise_b2b_id = :entreprise_id AND i.statut = 'en_attente'
             ORDER BY i.date_creation DESC, i.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function envoyerInvitationMembre(int $entrepriseId, int $adminId, string $email): void {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut gérer les accès.');
        }
        $email = trim($email);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) {
            throw new InvalidArgumentException('Saisissez une adresse e-mail valide.');
        }

        $this->conn->beginTransaction();
        try {
            $entrepriseStmt = $this->conn->prepare(
                "SELECT nom FROM entreprises_b2b WHERE id = :entreprise_id AND statut = 'actif' FOR UPDATE"
            );
            $entrepriseStmt->execute([':entreprise_id' => $entrepriseId]);
            $nomEntreprise = $entrepriseStmt->fetchColumn();
            if ($nomEntreprise === false) {
                throw new InvalidArgumentException('Cette entreprise est introuvable ou inactive.');
            }
            if (!$this->estAdministrateur($entrepriseId, $adminId)) {
                throw new RuntimeException('Seul un administrateur de l’entreprise peut gérer les accès.');
            }

            $stmt = $this->conn->prepare(
                "SELECT id FROM users
                 WHERE email = :email AND role = 'client' AND statut = 'actif' AND email_verifie = 1
                 LIMIT 1"
            );
            $stmt->execute([':email' => $email]);
            $userId = $stmt->fetchColumn();
            if (!$userId) {
                throw new InvalidArgumentException('Aucun compte client actif et vérifié ne correspond à cette adresse e-mail.');
            }
            $userId = (int) $userId;
            if ($userId === $adminId) {
                throw new InvalidArgumentException('Vous êtes déjà administrateur de cette entreprise.');
            }

            $membreStmt = $this->conn->prepare(
                "SELECT role, statut FROM entreprises_b2b_membres
                 WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id
                 LIMIT 1 FOR UPDATE"
            );
            $membreStmt->execute([':entreprise_id' => $entrepriseId, ':user_id' => $userId]);
            $membre = $membreStmt->fetch(PDO::FETCH_ASSOC);
            if ($membre && $membre['statut'] === 'actif') {
                throw new InvalidArgumentException('Cette personne a déjà accès à l’espace entreprise.');
            }

            $invitationExistante = $this->conn->prepare(
                "SELECT id FROM entreprises_b2b_invitations
                 WHERE entreprise_b2b_id = :entreprise_id AND invitee_user_id = :user_id
                   AND statut = 'en_attente'
                 LIMIT 1 FOR UPDATE"
            );
            $invitationExistante->execute([':entreprise_id' => $entrepriseId, ':user_id' => $userId]);
            if ($invitationExistante->fetchColumn()) {
                throw new InvalidArgumentException('Une invitation est déjà en attente pour cette adresse e-mail.');
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO entreprises_b2b_invitations
                    (entreprise_b2b_id, invitee_user_id, invite_par_user_id, statut)
                 VALUES (:entreprise_id, :user_id, :admin_id, 'en_attente')"
            );
            $stmt->execute([
                ':entreprise_id' => $entrepriseId,
                ':user_id' => $userId,
                ':admin_id' => $adminId,
            ]);
            $invitationId = (int) $this->conn->lastInsertId();

            $notification = $this->conn->prepare(
                "INSERT INTO notifications (user_id, message, lien)
                 VALUES (:user_id, :message, :lien)"
            );
            $notification->execute([
                ':user_id' => $userId,
                ':message' => 'Vous êtes invité à rejoindre l’espace entreprise « ' . $nomEntreprise . ' ». Acceptez ou refusez cette invitation.',
                ':lien' => '/allopro/views/client/invitations-entreprise.php?id=' . $invitationId,
            ]);

            $this->conn->commit();
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function annulerInvitationMembre(int $entrepriseId, int $adminId, int $invitationId): bool {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut gérer les accès.');
        }
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT invitee_user_id FROM entreprises_b2b_invitations
                 WHERE id = :id AND entreprise_b2b_id = :entreprise_id AND statut = 'en_attente'
                 LIMIT 1 FOR UPDATE"
            );
            $stmt->execute([':id' => $invitationId, ':entreprise_id' => $entrepriseId]);
            $inviteeId = $stmt->fetchColumn();
            if (!$inviteeId) {
                throw new InvalidArgumentException('Cette invitation n’est plus en attente.');
            }

            $annuler = $this->conn->prepare(
                "UPDATE entreprises_b2b_invitations
                 SET statut = 'annulee', date_reponse = CURRENT_TIMESTAMP
                 WHERE id = :id AND statut = 'en_attente'"
            );
            $annuler->execute([':id' => $invitationId]);
            $this->marquerNotificationInvitationLue((int) $inviteeId, $invitationId);
            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getInvitationsEnAttenteUtilisateur(int $userId): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id, i.entreprise_b2b_id, i.date_creation, e.nom AS entreprise_nom,
                    auteur.prenom AS auteur_prenom, auteur.nom AS auteur_nom, auteur.email AS auteur_email
             FROM entreprises_b2b_invitations i
             JOIN entreprises_b2b e ON e.id = i.entreprise_b2b_id
             LEFT JOIN users auteur ON auteur.id = i.invite_par_user_id
             WHERE i.invitee_user_id = :user_id AND i.statut = 'en_attente'
               AND e.statut = 'actif'
             ORDER BY i.date_creation DESC, i.id DESC"
        );
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getInvitationPourUtilisateur(int $invitationId, int $userId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT i.id, i.entreprise_b2b_id, i.date_creation, e.nom AS entreprise_nom,
                    auteur.prenom AS auteur_prenom, auteur.nom AS auteur_nom, auteur.email AS auteur_email
             FROM entreprises_b2b_invitations i
             JOIN entreprises_b2b e ON e.id = i.entreprise_b2b_id
             LEFT JOIN users auteur ON auteur.id = i.invite_par_user_id
             WHERE i.id = :id AND i.invitee_user_id = :user_id
               AND i.statut = 'en_attente' AND e.statut = 'actif'
             LIMIT 1"
        );
        $stmt->execute([':id' => $invitationId, ':user_id' => $userId]);
        $invitation = $stmt->fetch(PDO::FETCH_ASSOC);
        return $invitation ?: null;
    }

    public function repondreInvitationMembre(int $invitationId, int $userId, string $reponse): int {
        if (!in_array($reponse, ['acceptee', 'refusee'], true)) {
            throw new InvalidArgumentException('La réponse à l’invitation est invalide.');
        }
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT i.entreprise_b2b_id, i.invitee_user_id, i.statut, e.nom
                 FROM entreprises_b2b_invitations i
                 JOIN entreprises_b2b e ON e.id = i.entreprise_b2b_id
                 WHERE i.id = :id AND e.statut = 'actif'
                 LIMIT 1 FOR UPDATE"
            );
            $stmt->execute([':id' => $invitationId]);
            $invitation = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$invitation || (int) $invitation['invitee_user_id'] !== $userId || $invitation['statut'] !== 'en_attente') {
                throw new InvalidArgumentException('Cette invitation n’est plus disponible.');
            }

            $compte = $this->conn->prepare(
                "SELECT 1 FROM users
                 WHERE id = :user_id AND role = 'client' AND statut = 'actif' AND email_verifie = 1
                 LIMIT 1"
            );
            $compte->execute([':user_id' => $userId]);
            if (!$compte->fetchColumn()) {
                throw new RuntimeException('Un compte client actif et vérifié est nécessaire pour répondre à cette invitation.');
            }

            if ($reponse === 'acceptee') {
                $membre = $this->conn->prepare(
                    "SELECT role, statut FROM entreprises_b2b_membres
                     WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id
                     LIMIT 1 FOR UPDATE"
                );
                $membre->execute([
                    ':entreprise_id' => (int) $invitation['entreprise_b2b_id'],
                    ':user_id' => $userId,
                ]);
                $accesExistant = $membre->fetch(PDO::FETCH_ASSOC);
                if ($accesExistant && $accesExistant['statut'] === 'actif') {
                    throw new InvalidArgumentException('Vous avez déjà accès à cet espace entreprise.');
                }
                if ($accesExistant && $accesExistant['role'] === 'admin') {
                    throw new InvalidArgumentException('Cette invitation ne peut pas remplacer un rôle administrateur.');
                }

                $ajouter = $this->conn->prepare(
                    "INSERT INTO entreprises_b2b_membres
                        (entreprise_b2b_id, user_id, role, statut, ajoute_par_user_id, date_revocation)
                     SELECT :entreprise_id, :user_id, 'membre', 'actif', i.invite_par_user_id, NULL
                     FROM entreprises_b2b_invitations i WHERE i.id = :invitation_id
                     ON DUPLICATE KEY UPDATE
                        role = 'membre', statut = 'actif', ajoute_par_user_id = VALUES(ajoute_par_user_id),
                        date_revocation = NULL, date_ajout = CURRENT_TIMESTAMP"
                );
                $ajouter->execute([
                    ':entreprise_id' => (int) $invitation['entreprise_b2b_id'],
                    ':user_id' => $userId,
                    ':invitation_id' => $invitationId,
                ]);
                $this->initialiserPermissionsMembre((int) $invitation['entreprise_b2b_id'], $userId);
            }

            $maj = $this->conn->prepare(
                "UPDATE entreprises_b2b_invitations
                 SET statut = :statut, date_reponse = CURRENT_TIMESTAMP
                 WHERE id = :id AND statut = 'en_attente'"
            );
            $maj->execute([':statut' => $reponse, ':id' => $invitationId]);
            if ($maj->rowCount() !== 1) {
                throw new RuntimeException('Cette invitation a déjà reçu une réponse.');
            }

            $this->marquerNotificationInvitationLue($userId, $invitationId);
            $this->conn->commit();
            return (int) $invitation['entreprise_b2b_id'];
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    private function marquerNotificationInvitationLue(int $userId, int $invitationId): void {
        $stmt = $this->conn->prepare(
            "UPDATE notifications SET lu = 1
             WHERE user_id = :user_id
               AND lien = :lien"
        );
        $stmt->execute([
            ':user_id' => $userId,
            ':lien' => '/allopro/views/client/invitations-entreprise.php?id=' . $invitationId,
        ]);
    }

    public function ajouterMembre(int $entrepriseId, int $adminId, string $email): void {
        $this->envoyerInvitationMembre($entrepriseId, $adminId, $email);
    }

    public function retirerMembre(int $entrepriseId, int $adminId, int $membreId): bool {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut gérer les accès.');
        }
        if ($adminId === $membreId) {
            throw new InvalidArgumentException('Un administrateur ne peut pas retirer son propre accès.');
        }
        $stmt = $this->conn->prepare(
            "UPDATE entreprises_b2b_membres
             SET statut = 'revoque', date_revocation = CURRENT_TIMESTAMP
             WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id
               AND statut = 'actif' AND role = 'membre'"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId, ':user_id' => $membreId]);
        return $stmt->rowCount() === 1;
    }

    public function getResume(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(DISTINCT d.id) AS demandes,
                    COUNT(DISTINCT CASE WHEN d.statut NOT IN ('terminee', 'annulee') THEN d.id END) AS demandes_en_cours,
                    COUNT(DISTINCT CASE WHEN d.statut = 'terminee' THEN d.id END) AS demandes_terminees,
                    COUNT(DISTINCT CASE WHEN i.id IS NOT NULL AND i.statut NOT IN ('terminee', 'annulee', 'refusee') THEN i.id END) AS interventions_actives,
                    COUNT(DISTINCT t.id) AS tickets_sav
             FROM sites_b2b s
             LEFT JOIN demandes d ON d.site_b2b_id = s.id
             LEFT JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN tickets_sav t ON t.demande_id = d.id
             WHERE s.entreprise_b2b_id = :entreprise_id"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    public function getDemandes(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, d.description, d.urgence, d.statut, d.date_creation,
                    c.nom AS categorie_nom, s.nom AS site_nom,
                    i.id AS intervention_id, i.statut AS intervention_statut,
                    adc.date_attribution AS date_transmission,
                    (SELECT ct.sla_urgent_minutes FROM contrats_b2b ct
                     WHERE ct.id = d.contrat_b2b_id) AS sla_urgent_minutes,
                    (SELECT ct.sla_normal_minutes FROM contrats_b2b ct
                     WHERE ct.id = d.contrat_b2b_id) AS sla_normal_minutes
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN attributions_demandes_coordinateurs adc ON adc.demande_id = d.id
             WHERE s.entreprise_b2b_id = :entreprise_id
             ORDER BY d.date_creation DESC, d.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDemandeDetail(int $entrepriseId, int $demandeId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, d.description, d.urgence, d.statut AS demande_statut,
                    d.mode_paiement, d.contrat_b2b_id, d.date_creation, d.date_creneau_souhaite,
                    d.heure_creneau_souhaitee, d.photo_path,
                    demandeur.prenom AS demandeur_prenom, demandeur.nom AS demandeur_nom,
                    c.nom AS categorie_nom, s.id AS site_id, s.nom AS site_nom,
                    s.quartier AS site_quartier, s.ville AS site_ville, s.details AS site_details,
                    s.telephone_contact AS site_telephone, s.email_contact AS site_email,
                    a.quartier AS adresse_quartier, a.ville AS adresse_ville, a.details AS adresse_details,
                    a.adresse_google, a.latitude, a.longitude,
                    i.id AS intervention_id, i.statut AS intervention_statut, i.date_debut,
                    i.date_decision_technicien, i.date_fin, i.date_creneau_planifie,
                    i.heure_creneau_planifie, i.rapport, i.montant AS intervention_montant,
                    i.photo_avant, i.photo_apres, t.nom AS technicien_nom,
                    p.nom_entreprise AS partenaire_nom,
                    adc.date_attribution AS date_transmission, adc.date_traitement,
                    sav.id AS ticket_sav_id, sav.motif AS ticket_sav_motif,
                    sav.statut AS ticket_sav_statut, sav.date_creation AS ticket_sav_date,
                    paye.montant AS paiement_montant, paye.methode AS paiement_methode,
                    paye.statut AS paiement_statut, paye.date_paiement,
                    ct.sla_urgent_minutes, ct.sla_normal_minutes,
                    ct.volume_credits AS contrat_volume_credits,
                    ct.credits_utilises AS contrat_credits_utilises,
                    ct.montant_total AS contrat_montant_total,
                    ct.statut AS contrat_statut,
                    conso.date_consommation AS contrat_credit_consomme_le
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id AND s.entreprise_b2b_id = :entreprise_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN users demandeur ON demandeur.id = d.client_id
             LEFT JOIN adresses a ON a.id = s.adresse_id
             LEFT JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN contrats_b2b_consommations conso ON conso.demande_id = d.id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             LEFT JOIN attributions_demandes_coordinateurs adc ON adc.demande_id = d.id
             LEFT JOIN tickets_sav sav ON sav.demande_id = d.id
             LEFT JOIN paiements paye ON paye.id = (
                 SELECT p2.id FROM paiements p2
                 WHERE p2.demande_id = d.id
                 ORDER BY CASE p2.statut WHEN 'valide' THEN 0 WHEN 'en_attente' THEN 1 ELSE 2 END,
                          p2.id DESC
                 LIMIT 1
             )
             LEFT JOIN contrats_b2b ct ON ct.id = d.contrat_b2b_id
             WHERE d.id = :demande_id
             LIMIT 1"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId, ':demande_id' => $demandeId]);
        $demande = $stmt->fetch(PDO::FETCH_ASSOC);
        return $demande ?: null;
    }

    public function getDocumentsDemande(int $entrepriseId, int $demandeId): array {
        $stmt = $this->conn->prepare(
            "SELECT doc.id, doc.nom_original, doc.chemin, doc.mime_type, doc.taille, doc.date_creation
             FROM intervention_documents doc
             JOIN interventions i ON i.id = doc.intervention_id
             JOIN demandes d ON d.id = i.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE s.entreprise_b2b_id = :entreprise_id AND d.id = :demande_id
             ORDER BY doc.date_creation DESC, doc.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId, ':demande_id' => $demandeId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getInterventions(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id, i.statut, i.date_debut, i.date_decision_technicien, i.date_fin,
                    i.date_creneau_planifie, i.heure_creneau_planifie, i.rapport,
                    d.id AS demande_id, d.numero_dossier, d.urgence, d.date_creation,
                    c.nom AS categorie_nom, s.nom AS site_nom, p.nom_entreprise AS partenaire_nom,
                    t.nom AS technicien_nom
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             WHERE s.entreprise_b2b_id = :entreprise_id
             ORDER BY COALESCE(i.date_debut, d.date_creation) DESC, i.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTicketsSav(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT t.id, t.motif, t.statut, t.date_creation, t.date_resolution,
                    d.id AS demande_id, d.numero_dossier, s.nom AS site_nom
             FROM tickets_sav t
             JOIN demandes d ON d.id = t.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE s.entreprise_b2b_id = :entreprise_id
             ORDER BY t.date_creation DESC, t.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDemandesEligiblesSav(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, s.nom AS site_nom
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE s.entreprise_b2b_id = :entreprise_id AND d.statut = 'terminee'
               AND NOT EXISTS (SELECT 1 FROM tickets_sav t WHERE t.demande_id = d.id)
             ORDER BY d.date_creation DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function creerTicketSav(int $entrepriseId, int $userId, int $demandeId, string $motif): bool {
        $motif = trim($motif);
        if ($motif === '' || mb_strlen($motif) > 100) {
            throw new InvalidArgumentException('Le motif SAV doit contenir entre 1 et 100 caractères.');
        }
        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT d.id FROM demandes d
                 JOIN sites_b2b s ON s.id = d.site_b2b_id
                 JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = s.entreprise_b2b_id
                 WHERE d.id = :demande_id AND s.entreprise_b2b_id = :entreprise_id
                   AND m.user_id = :user_id AND m.statut = 'actif'
                   AND d.statut = 'terminee'
                   AND NOT EXISTS (SELECT 1 FROM tickets_sav t WHERE t.demande_id = d.id)
                 FOR UPDATE"
            );
            $stmt->execute([
                ':demande_id' => $demandeId,
                ':entreprise_id' => $entrepriseId,
                ':user_id' => $userId,
            ]);
            if (!$stmt->fetchColumn()) {
                $this->conn->rollBack();
                throw new InvalidArgumentException('Ce dossier ne peut pas faire l’objet d’un nouveau ticket SAV.');
            }
            $insert = $this->conn->prepare(
                "INSERT INTO tickets_sav (demande_id, motif, statut, origine)
                 VALUES (:demande_id, :motif, 'ouvert', 'entreprise')"
            );
            $insert->execute([':demande_id' => $demandeId, ':motif' => $motif]);
            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getContrats(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT ct.id, ct.date_debut, ct.date_fin, ct.volume_credits, ct.credits_utilises,
                    ct.montant_total, ct.conditions, ct.sla_urgent_minutes, ct.sla_normal_minutes,
                    ct.statut, ct.cree_par_admin_id,
                    (SELECT COUNT(*) FROM demandes d
                     WHERE d.contrat_b2b_id = ct.id AND d.statut NOT IN ('terminee', 'annulee')) AS credits_reserves,
                    GREATEST(0, ct.volume_credits - ct.credits_utilises - (
                        SELECT COUNT(*) FROM demandes d
                        WHERE d.contrat_b2b_id = ct.id AND d.statut NOT IN ('terminee', 'annulee')
                    )) AS credits_disponibles,
                    COALESCE((SELECT SUM(p.montant) FROM paiements_contrats_b2b p
                              WHERE p.contrat_b2b_id = ct.id), 0) AS montant_regle,
                    GREATEST(0, ct.montant_total - COALESCE((SELECT SUM(p.montant)
                              FROM paiements_contrats_b2b p WHERE p.contrat_b2b_id = ct.id), 0)) AS solde
             FROM contrats_b2b ct
             WHERE ct.entreprise_b2b_id = :entreprise_id
             ORDER BY ct.date_debut DESC, ct.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getEntreprisesPourContratAdmin(): array {
        return $this->conn->query(
            "SELECT id, nom FROM entreprises_b2b WHERE statut = 'actif' ORDER BY nom, id"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getContratsPourAdmin(): array {
        return $this->conn->query(
            "SELECT ct.id, ct.entreprise_b2b_id, e.nom AS entreprise_nom, ct.date_debut, ct.date_fin,
                    ct.volume_credits, ct.credits_utilises, ct.montant_total, ct.conditions,
                    ct.sla_urgent_minutes, ct.sla_normal_minutes, ct.statut,
                    (SELECT COUNT(*) FROM demandes d
                     WHERE d.contrat_b2b_id = ct.id AND d.statut NOT IN ('terminee', 'annulee')) AS credits_reserves,
                    GREATEST(0, ct.volume_credits - ct.credits_utilises - (
                        SELECT COUNT(*) FROM demandes d
                        WHERE d.contrat_b2b_id = ct.id AND d.statut NOT IN ('terminee', 'annulee')
                    )) AS credits_disponibles,
                    COALESCE((SELECT SUM(p.montant) FROM paiements_contrats_b2b p
                              WHERE p.contrat_b2b_id = ct.id), 0) AS montant_regle,
                    GREATEST(0, ct.montant_total - COALESCE((SELECT SUM(p.montant)
                              FROM paiements_contrats_b2b p WHERE p.contrat_b2b_id = ct.id), 0)) AS solde
             FROM contrats_b2b ct
             JOIN entreprises_b2b e ON e.id = ct.entreprise_b2b_id
             ORDER BY ct.date_debut DESC, ct.id DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getContratDetailAdmin(int $contratId, int $userId): ?array {
        $this->verifierGestionContratFinance($userId);

        $contratStmt = $this->conn->prepare(
            "SELECT ct.id, ct.entreprise_b2b_id, e.nom AS entreprise_nom,
                    e.interlocuteur_nom, e.interlocuteur_telephone, e.interlocuteur_email,
                    ct.date_debut, ct.date_fin, ct.volume_credits, ct.credits_utilises,
                    ct.montant_total, ct.conditions, ct.sla_urgent_minutes, ct.sla_normal_minutes,
                    ct.statut, ct.cree_par_admin_id, createur.nom AS createur_nom,
                    createur.matricule AS createur_matricule,
                    (SELECT COUNT(*) FROM demandes d
                     WHERE d.contrat_b2b_id = ct.id AND d.statut NOT IN ('terminee', 'annulee')) AS credits_reserves,
                    GREATEST(0, ct.volume_credits - ct.credits_utilises - (
                        SELECT COUNT(*) FROM demandes d
                        WHERE d.contrat_b2b_id = ct.id AND d.statut NOT IN ('terminee', 'annulee')
                    )) AS credits_disponibles,
                    COALESCE((SELECT SUM(p.montant) FROM paiements_contrats_b2b p
                              WHERE p.contrat_b2b_id = ct.id), 0) AS montant_regle,
                    GREATEST(0, ct.montant_total - COALESCE((SELECT SUM(p.montant)
                              FROM paiements_contrats_b2b p WHERE p.contrat_b2b_id = ct.id), 0)) AS solde
             FROM contrats_b2b ct
             JOIN entreprises_b2b e ON e.id = ct.entreprise_b2b_id
             LEFT JOIN users createur ON createur.id = ct.cree_par_admin_id
             WHERE ct.id = :contrat_id
             LIMIT 1"
        );
        $contratStmt->execute([':contrat_id' => $contratId]);
        $contrat = $contratStmt->fetch(PDO::FETCH_ASSOC);
        if (!$contrat) {
            return null;
        }

        $paiementsStmt = $this->conn->prepare(
            "SELECT p.id, p.montant, p.methode, p.reference_transaction, p.date_paiement,
                    u.nom AS enregistre_par_nom, u.matricule AS enregistre_par_matricule,
                    f.numero AS facture_numero, f.email_destinataire AS facture_destinataire,
                    f.chemin_fichier AS facture_chemin, f.email_statut AS facture_email_statut,
                    f.email_envoye_at AS facture_email_envoye_at, f.email_erreur AS facture_email_erreur
             FROM paiements_contrats_b2b p
             JOIN users u ON u.id = p.enregistre_par_admin_id
             LEFT JOIN factures_contrats_b2b f ON f.paiement_contrat_b2b_id = p.id
             WHERE p.contrat_b2b_id = :contrat_id
             ORDER BY p.date_paiement DESC, p.id DESC"
        );
        $paiementsStmt->execute([':contrat_id' => $contratId]);
        $contrat['paiements'] = $paiementsStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($contrat['paiements'] as &$paiement) {
            $paiement['facture_pdf_disponible'] = !empty($paiement['facture_chemin'])
                && is_file(
                    dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR
                    . 'factures' . DIRECTORY_SEPARATOR . 'contrats-b2b' . DIRECTORY_SEPARATOR
                    . basename((string) $paiement['facture_chemin'])
                );
        }
        unset($paiement);

        $demandesStmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, d.statut, d.urgence, d.date_creation,
                    c.nom AS categorie_nom, s.nom AS site_nom,
                    conso.credits AS credits_consommes, conso.date_consommation,
                    i.statut AS intervention_statut
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN contrats_b2b_consommations conso
                    ON conso.demande_id = d.id AND conso.contrat_b2b_id = d.contrat_b2b_id
             LEFT JOIN interventions i ON i.id = (
                 SELECT MAX(i2.id) FROM interventions i2 WHERE i2.demande_id = d.id
             )
             WHERE d.contrat_b2b_id = :contrat_id
             ORDER BY d.date_creation DESC, d.id DESC"
        );
        $demandesStmt->execute([':contrat_id' => $contratId]);
        $contrat['demandes'] = $demandesStmt->fetchAll(PDO::FETCH_ASSOC);

        return $contrat;
    }

    public function getDemandesB2BSansContrat(): array {
        return $this->conn->query(
            "SELECT d.id, d.numero_dossier, d.statut, d.date_creation, e.id AS entreprise_b2b_id,
                    e.nom AS entreprise_nom, s.nom AS site_nom
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             WHERE d.contrat_b2b_id IS NULL AND d.statut NOT IN ('terminee', 'annulee')
             ORDER BY d.date_creation ASC, d.id ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function compterDemandesB2BSansContrat(): int {
        return (int) $this->conn->query(
            "SELECT COUNT(*)
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE d.contrat_b2b_id IS NULL
               AND d.statut NOT IN ('terminee', 'annulee')"
        )->fetchColumn();
    }

    public function lierDemandeAuContratAdmin(int $demandeId, int $contratId, int $adminId): bool {
        $admin = $this->conn->prepare(
            "SELECT 1 FROM users WHERE id = :id AND role = 'admin' AND statut = 'actif' LIMIT 1"
        );
        $admin->execute([':id' => $adminId]);
        if (!$admin->fetchColumn()) {
            throw new RuntimeException('Seul un administrateur ALLÔ PRO peut rattacher une demande à un contrat.');
        }
        $this->conn->beginTransaction();
        try {
            $contratStmt = $this->conn->prepare(
                "SELECT id, entreprise_b2b_id, volume_credits, credits_utilises
                 FROM contrats_b2b
                 WHERE id = :contrat_id AND statut = 'actif'
                   AND date_debut <= CURRENT_DATE() AND date_fin >= CURRENT_DATE()
                 FOR UPDATE"
            );
            $contratStmt->execute([':contrat_id' => $contratId]);
            $contrat = $contratStmt->fetch(PDO::FETCH_ASSOC);
            if (!$contrat) {
                throw new InvalidArgumentException('Choisissez un contrat actif et en cours de validité.');
            }
            $demandeStmt = $this->conn->prepare(
                "SELECT d.id, d.statut, s.entreprise_b2b_id
                 FROM demandes d
                 JOIN sites_b2b s ON s.id = d.site_b2b_id
                 WHERE d.id = :demande_id AND d.contrat_b2b_id IS NULL
                   AND d.statut NOT IN ('terminee', 'annulee')
                 FOR UPDATE"
            );
            $demandeStmt->execute([':demande_id' => $demandeId]);
            $demande = $demandeStmt->fetch(PDO::FETCH_ASSOC);
            if (!$demande || (int) $demande['entreprise_b2b_id'] !== (int) $contrat['entreprise_b2b_id']) {
                throw new InvalidArgumentException('La demande doit appartenir à la même entreprise et être encore ouverte.');
            }
            $reservees = $this->conn->prepare(
                "SELECT COUNT(*) FROM demandes
                 WHERE contrat_b2b_id = :contrat_id AND statut NOT IN ('terminee', 'annulee')"
            );
            $reservees->execute([':contrat_id' => $contratId]);
            if ((int) $contrat['credits_utilises'] + (int) $reservees->fetchColumn()
                >= (int) $contrat['volume_credits']) {
                throw new RuntimeException('Ce contrat n’a plus de crédit disponible pour rattacher la demande.');
            }
            $maj = $this->conn->prepare(
                "UPDATE demandes SET contrat_b2b_id = :contrat_id
                 WHERE id = :demande_id AND contrat_b2b_id IS NULL"
            );
            $maj->execute([':contrat_id' => $contratId, ':demande_id' => $demandeId]);
            if ($maj->rowCount() !== 1) {
                throw new RuntimeException('La demande a été modifiée entre-temps. Rechargez la page.');
            }
            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function creerContratAdmin(int $entrepriseId, int $adminId, array $donnees): int {
        $dateDebut = trim((string) ($donnees['date_debut'] ?? ''));
        $dateFin = trim((string) ($donnees['date_fin'] ?? ''));
        $credits = filter_var($donnees['volume_credits'] ?? null, FILTER_VALIDATE_INT);
        $slaUrgent = filter_var($donnees['sla_urgent_heures'] ?? null, FILTER_VALIDATE_INT);
        $slaNormal = filter_var($donnees['sla_normal_heures'] ?? null, FILTER_VALIDATE_INT);
        $montantBrut = str_replace(',', '.', trim((string) ($donnees['montant_total'] ?? '')));
        $montant = filter_var($montantBrut, FILTER_VALIDATE_FLOAT);
        $conditions = trim((string) ($donnees['conditions'] ?? ''));
        foreach ([$dateDebut, $dateFin] as $date) {
            $dateValide = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
            if (!$dateValide || $dateValide->format('Y-m-d') !== $date) {
                throw new InvalidArgumentException('Les dates du contrat sont invalides.');
            }
        }
        if ($dateFin < $dateDebut || $dateFin < date('Y-m-d') || $credits === false || $credits < 1 || $credits > 1000000
            || $slaUrgent === false || $slaUrgent < 1 || $slaUrgent > 8760
            || $slaNormal === false || $slaNormal < 1 || $slaNormal > 8760
            || $montant === false || !is_finite((float) $montant) || $montant < 0 || $montant > 9999999999.99
            || mb_strlen($conditions) > 10000) {
            throw new InvalidArgumentException('Vérifiez la période, le volume de crédits, les SLA et les conditions du contrat.');
        }
        $this->verifierGestionContratFinance($adminId);

        $this->conn->beginTransaction();
        try {
            $entreprise = $this->conn->prepare(
                "SELECT id FROM entreprises_b2b WHERE id = :id AND statut = 'actif' FOR UPDATE"
            );
            $entreprise->execute([':id' => $entrepriseId]);
            if (!$entreprise->fetchColumn()) {
                throw new InvalidArgumentException('Cette entreprise est introuvable ou inactive.');
            }
            $chevauchement = $this->conn->prepare(
                "SELECT id FROM contrats_b2b
                 WHERE entreprise_b2b_id = :entreprise_id AND statut = 'actif'
                   AND date_debut <= :date_fin AND date_fin >= :date_debut
                 LIMIT 1"
            );
            $chevauchement->execute([
                ':entreprise_id' => $entrepriseId,
                ':date_debut' => $dateDebut,
                ':date_fin' => $dateFin,
            ]);
            if ($chevauchement->fetchColumn()) {
                throw new InvalidArgumentException('Un contrat actif chevauche déjà cette période pour l’entreprise.');
            }

            $insert = $this->conn->prepare(
                "INSERT INTO contrats_b2b
                    (entreprise_b2b_id, date_debut, date_fin, volume_credits, credits_utilises,
                     montant_total, conditions, cree_par_admin_id, sla_urgent_minutes, sla_normal_minutes, statut)
                 VALUES (:entreprise_id, :date_debut, :date_fin, :credits, 0,
                         :montant, :conditions, :admin_id, :sla_urgent, :sla_normal, 'actif')"
            );
            $insert->execute([
                ':entreprise_id' => $entrepriseId,
                ':date_debut' => $dateDebut,
                ':date_fin' => $dateFin,
                ':credits' => $credits,
                ':montant' => number_format((float) $montant, 2, '.', ''),
                ':conditions' => $conditions !== '' ? $conditions : null,
                ':admin_id' => $adminId,
                ':sla_urgent' => $slaUrgent * 60,
                ':sla_normal' => $slaNormal * 60,
            ]);
            $contratId = (int) $this->conn->lastInsertId();
            $this->conn->commit();
            return $contratId;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function resilierContratAdmin(int $contratId, int $adminId): bool {
        $this->verifierGestionContratFinance($adminId);

        $this->conn->beginTransaction();
        try {
            $contrat = $this->conn->prepare(
                "SELECT id FROM contrats_b2b WHERE id = :id AND statut = 'actif' FOR UPDATE"
            );
            $contrat->execute([':id' => $contratId]);
            if (!$contrat->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }
            $missions = $this->conn->prepare(
                "SELECT 1 FROM demandes
                 WHERE contrat_b2b_id = :contrat_id AND statut NOT IN ('terminee', 'annulee')
                 LIMIT 1"
            );
            $missions->execute([':contrat_id' => $contratId]);
            if ($missions->fetchColumn()) {
                throw new RuntimeException('Terminez ou annulez les interventions réservées avant de résilier le contrat.');
            }
            $maj = $this->conn->prepare(
                "UPDATE contrats_b2b SET statut = 'resilie' WHERE id = :id AND statut = 'actif'"
            );
            $maj->execute([':id' => $contratId]);
            $this->conn->commit();
            return $maj->rowCount() === 1;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function enregistrerPaiementContratAdmin(int $contratId, int $adminId, array $donnees): int {
        $montantBrut = str_replace(',', '.', trim((string) ($donnees['montant'] ?? '')));
        $montant = filter_var($montantBrut, FILTER_VALIDATE_FLOAT);
        $methode = is_string($donnees['methode'] ?? null) ? $donnees['methode'] : '';
        $reference = trim((string) ($donnees['reference_transaction'] ?? ''));
        if ($montant === false || !is_finite((float) $montant) || $montant <= 0 || $montant > 9999999999.99
            || !in_array($methode, ['wave', 'orange_money', 'virement', 'cheque', 'especes', 'autre'], true)
            || mb_strlen($reference) > 100) {
            throw new InvalidArgumentException('Vérifiez le montant, le moyen et la référence du règlement.');
        }
        $this->verifierGestionContratFinance($adminId);
        $this->conn->beginTransaction();
        try {
            $contrat = $this->conn->prepare(
                "SELECT montant_total, statut FROM contrats_b2b WHERE id = :id FOR UPDATE"
            );
            $contrat->execute([':id' => $contratId]);
            $donneesContrat = $contrat->fetch(PDO::FETCH_ASSOC);
            if (!$donneesContrat || $donneesContrat['statut'] !== 'actif') {
                throw new RuntimeException('Ce contrat ne peut pas recevoir de règlement.');
            }
            $paye = $this->conn->prepare(
                "SELECT COALESCE(SUM(montant), 0) FROM paiements_contrats_b2b WHERE contrat_b2b_id = :id"
            );
            $paye->execute([':id' => $contratId]);
            $solde = (float) $donneesContrat['montant_total'] - (float) $paye->fetchColumn();
            if ((float) $montant > $solde + 0.001) {
                throw new InvalidArgumentException('Le montant dépasse le solde restant du contrat.');
            }
            $insert = $this->conn->prepare(
                "INSERT INTO paiements_contrats_b2b
                    (contrat_b2b_id, montant, methode, reference_transaction, enregistre_par_admin_id)
                 VALUES (:contrat_id, :montant, :methode, :reference, :admin_id)"
            );
            $insert->execute([
                ':contrat_id' => $contratId,
                ':montant' => number_format((float) $montant, 2, '.', ''),
                ':methode' => $methode,
                ':reference' => $reference !== '' ? $reference : null,
                ':admin_id' => $adminId,
            ]);
            $paiementId = (int) $this->conn->lastInsertId();
            $this->conn->commit();
            return $paiementId;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getPaiementsContrat(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT p.id, p.montant, p.methode, p.reference_transaction, p.date_paiement,
                    ct.id AS contrat_id, e.nom AS entreprise_nom
             FROM paiements_contrats_b2b p
             JOIN contrats_b2b ct ON ct.id = p.contrat_b2b_id
             JOIN entreprises_b2b e ON e.id = ct.entreprise_b2b_id
             WHERE ct.entreprise_b2b_id = :entreprise_id
             ORDER BY p.date_paiement DESC, p.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function creerDemandeSousContrat(
        int $entrepriseId,
        int $userId,
        int $siteId,
        int $categorieId,
        string $description,
        string $urgence
    ): string {
        $description = trim($description);
        if ($description === '' || mb_strlen($description) > 1000) {
            throw new InvalidArgumentException('La description est obligatoire et ne doit pas dépasser 1 000 caractères.');
        }
        if (!in_array($urgence, ['normale', 'urgente'], true)) {
            throw new InvalidArgumentException('Le niveau d’urgence est invalide.');
        }
        $this->conn->beginTransaction();
        try {
            $contratStmt = $this->conn->prepare(
                "SELECT id, volume_credits, credits_utilises
                 FROM contrats_b2b
                 WHERE entreprise_b2b_id = :entreprise_id AND statut = 'actif'
                   AND date_debut <= CURRENT_DATE() AND date_fin >= CURRENT_DATE()
                 ORDER BY id DESC LIMIT 1 FOR UPDATE"
            );
            $contratStmt->execute([':entreprise_id' => $entrepriseId]);
            $contrat = $contratStmt->fetch(PDO::FETCH_ASSOC);
            if (!$contrat) {
                throw new RuntimeException('Aucun contrat actif ne couvre votre entreprise. Demandez un devis avant de créer une intervention.');
            }

            $site = $this->conn->prepare(
                "SELECT s.id, s.adresse_id FROM sites_b2b s
                 JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = s.entreprise_b2b_id
                 WHERE s.id = :site_id AND s.entreprise_b2b_id = :entreprise_id AND s.statut = 'actif'
                   AND s.adresse_id IS NOT NULL AND m.user_id = :user_id AND m.statut = 'actif' LIMIT 1"
            );
            $site->execute([
                ':site_id' => $siteId,
                ':entreprise_id' => $entrepriseId,
                ':user_id' => $userId,
            ]);
            $siteData = $site->fetch(PDO::FETCH_ASSOC);
            if (!$siteData) {
                throw new InvalidArgumentException('Choisissez un site actif de votre entreprise.');
            }
            $categorie = $this->conn->prepare(
                "SELECT 1 FROM categories WHERE id = :categorie_id AND parent_id IS NULL AND statut = 'active' LIMIT 1"
            );
            $categorie->execute([':categorie_id' => $categorieId]);
            if (!$categorie->fetchColumn()) {
                throw new InvalidArgumentException('Choisissez une catégorie disponible.');
            }

            $reservees = $this->conn->prepare(
                "SELECT COUNT(*) FROM demandes
                 WHERE contrat_b2b_id = :contrat_id AND statut NOT IN ('terminee', 'annulee')"
            );
            $reservees->execute([':contrat_id' => $contrat['id']]);
            $creditsDisponibles = (int) $contrat['volume_credits'] - (int) $contrat['credits_utilises']
                - (int) $reservees->fetchColumn();
            if ($creditsDisponibles < 1) {
                throw new RuntimeException('Les crédits du contrat sont utilisés ou réservés. Demandez un renouvellement ou un devis.');
            }

            $prefixe = 'AP-' . date('Y') . '-';
            $numeroStmt = $this->conn->prepare(
                "SELECT numero_dossier FROM demandes WHERE numero_dossier LIKE :prefixe
                 ORDER BY numero_dossier DESC LIMIT 1 FOR UPDATE"
            );
            $numeroStmt->execute([':prefixe' => $prefixe . '%']);
            $dernierNumero = $numeroStmt->fetchColumn();
            $sequence = $dernierNumero === false ? 1 : ((int) substr((string) $dernierNumero, strlen($prefixe)) + 1);
            $numero = $prefixe . str_pad((string) $sequence, 6, '0', STR_PAD_LEFT);
            $insert = $this->conn->prepare(
                "INSERT INTO demandes
                    (numero_dossier, client_id, adresse_id, site_b2b_id, contrat_b2b_id,
                     categorie_id, description, urgence, mode_paiement)
                 VALUES (:numero, :user_id, :adresse_id, :site_id, :contrat_id,
                         :categorie_id, :description, :urgence, 'normal')"
            );
            $insert->execute([
                ':numero' => $numero,
                ':user_id' => $userId,
                ':adresse_id' => $siteData['adresse_id'],
                ':site_id' => $siteId,
                ':contrat_id' => $contrat['id'],
                ':categorie_id' => $categorieId,
                ':description' => $description,
                ':urgence' => $urgence,
            ]);
            $this->conn->commit();
            return $numero;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getDevis(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT q.id, q.numero, q.demande_id, q.description, q.montant, q.details,
                    CASE WHEN q.statut = 'emis' AND q.date_validite < CURRENT_DATE() THEN 'expire' ELSE q.statut END AS statut,
                    q.date_validite, q.date_creation, q.date_emission, q.date_reponse, d.numero_dossier
             FROM devis_b2b q
             LEFT JOIN demandes d ON d.id = q.demande_id
                 AND EXISTS (
                     SELECT 1 FROM sites_b2b sx
                     WHERE sx.id = d.site_b2b_id AND sx.entreprise_b2b_id = q.entreprise_b2b_id
                 )
             WHERE q.entreprise_b2b_id = :entreprise_id
             ORDER BY q.date_creation DESC, q.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDevisDetail(int $entrepriseId, int $devisId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT q.id, q.numero, q.demande_id, q.description, q.montant, q.details,
                    CASE WHEN q.statut = 'emis' AND q.date_validite < CURRENT_DATE()
                         THEN 'expire' ELSE q.statut END AS statut,
                    q.date_validite, q.date_creation, q.date_emission, q.date_reponse,
                    d.numero_dossier, s.nom AS site_nom
             FROM devis_b2b q
             LEFT JOIN demandes d ON d.id = q.demande_id
                 AND EXISTS (
                     SELECT 1 FROM sites_b2b sx
                     WHERE sx.id = d.site_b2b_id AND sx.entreprise_b2b_id = q.entreprise_b2b_id
                 )
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE q.id = :devis_id AND q.entreprise_b2b_id = :entreprise_id
             LIMIT 1"
        );
        $stmt->execute([':devis_id' => $devisId, ':entreprise_id' => $entrepriseId]);
        $devis = $stmt->fetch(PDO::FETCH_ASSOC);
        return $devis ?: null;
    }

    public function demanderDevis(int $entrepriseId, int $userId, ?int $demandeId, string $description): int {
        $description = trim($description);
        if ($description === '' || mb_strlen($description) > 3000) {
            throw new InvalidArgumentException('Décrivez le besoin en 1 à 3 000 caractères.');
        }
        if ($demandeId !== null) {
            $stmt = $this->conn->prepare(
                "SELECT 1 FROM demandes d
                 JOIN sites_b2b s ON s.id = d.site_b2b_id
                 JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = s.entreprise_b2b_id
                 WHERE d.id = :demande_id AND s.entreprise_b2b_id = :entreprise_id
                   AND m.user_id = :user_id AND m.statut = 'actif' LIMIT 1"
            );
            $stmt->execute([
                ':demande_id' => $demandeId,
                ':entreprise_id' => $entrepriseId,
                ':user_id' => $userId,
            ]);
            if (!$stmt->fetchColumn()) {
                throw new InvalidArgumentException('Le dossier choisi ne fait pas partie de votre entreprise.');
            }
        }

        $stmt = $this->conn->prepare(
            "INSERT INTO devis_b2b (entreprise_b2b_id, demande_id, cree_par_user_id, description, statut)
             VALUES (:entreprise_id, :demande_id, :user_id, :description, 'demande')"
        );
        $stmt->execute([
            ':entreprise_id' => $entrepriseId,
            ':demande_id' => $demandeId,
            ':user_id' => $userId,
            ':description' => $description,
        ]);
        $devisId = (int) $this->conn->lastInsertId();
        $numero = 'DEV-' . date('Y') . '-' . str_pad((string) $devisId, 6, '0', STR_PAD_LEFT);
        $maj = $this->conn->prepare("UPDATE devis_b2b SET numero = :numero WHERE id = :id");
        $maj->execute([':numero' => $numero, ':id' => $devisId]);
        return $devisId;
    }

    public function repondreDevis(int $entrepriseId, int $userId, int $devisId, string $reponse): bool {
        if (!in_array($reponse, ['accepte', 'refuse'], true)) {
            throw new InvalidArgumentException('La réponse au devis est invalide.');
        }
        $stmt = $this->conn->prepare(
            "UPDATE devis_b2b q
             JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = q.entreprise_b2b_id
             SET q.statut = :statut, q.date_reponse = CURRENT_TIMESTAMP
             WHERE q.id = :devis_id AND q.entreprise_b2b_id = :entreprise_id
               AND m.user_id = :user_id AND m.statut = 'actif'
               AND q.statut = 'emis'
               AND (q.date_validite IS NULL OR q.date_validite >= CURRENT_DATE())"
        );
        $stmt->execute([
            ':statut' => $reponse, ':devis_id' => $devisId,
            ':entreprise_id' => $entrepriseId, ':user_id' => $userId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function getDevisB2BPourQualite(): array {
        return $this->conn->query(
            "SELECT q.id, q.numero, q.demande_id, q.description, q.statut, q.date_creation,
                    q.qualite_statut, q.qualite_commentaire, q.qualite_le,
                    e.nom AS entreprise_nom, d.numero_dossier
             FROM devis_b2b q
             JOIN entreprises_b2b e ON e.id = q.entreprise_b2b_id
             LEFT JOIN demandes d ON d.id = q.demande_id
                 AND EXISTS (
                     SELECT 1 FROM sites_b2b s
                     WHERE s.id = d.site_b2b_id AND s.entreprise_b2b_id = q.entreprise_b2b_id
                 )
             WHERE q.statut = 'demande' AND q.qualite_statut IN ('a_traiter', 'a_preciser')
             ORDER BY q.date_creation ASC, q.id ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDevisB2BPourEmission(): array {
        return $this->conn->query(
            "SELECT q.id, q.numero, q.demande_id, q.description, q.statut, q.date_creation,
                    q.qualite_commentaire, q.qualite_le,
                    e.nom AS entreprise_nom, d.numero_dossier
             FROM devis_b2b q
             JOIN entreprises_b2b e ON e.id = q.entreprise_b2b_id
             LEFT JOIN demandes d ON d.id = q.demande_id
                 AND EXISTS (
                     SELECT 1 FROM sites_b2b s
                     WHERE s.id = d.site_b2b_id AND s.entreprise_b2b_id = q.entreprise_b2b_id
                 )
             WHERE q.statut = 'demande' AND q.qualite_statut = 'valide'
             ORDER BY q.date_creation ASC, q.id ASC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDemandeIdPourConsultationDevisB2B(int $devisId, string $role): ?int {
        if (!in_array($role, ['qualite', 'finance', 'admin'], true)) {
            return null;
        }

        $conditionsRole = match ($role) {
            'qualite' => "q.statut = 'demande' AND q.qualite_statut IN ('a_traiter', 'a_preciser', 'valide')",
            'finance' => "q.statut = 'demande' AND q.qualite_statut = 'valide'",
            default => '1 = 1',
        };
        $stmt = $this->conn->prepare(
            "SELECT d.id
             FROM devis_b2b q
             JOIN demandes d ON d.id = q.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id AND s.entreprise_b2b_id = q.entreprise_b2b_id
             WHERE q.id = :devis_id AND {$conditionsRole}
             LIMIT 1"
        );
        $stmt->execute([':devis_id' => $devisId]);
        $demandeId = $stmt->fetchColumn();

        return $demandeId === false ? null : (int) $demandeId;
    }

    public function traiterQualificationDevis(int $devisId, int $userId, string $decision, string $commentaire): bool {
        $user = $this->conn->prepare("SELECT role FROM users WHERE id = :id AND statut = 'actif' LIMIT 1");
        $user->execute([':id' => $userId]);
        if (!in_array($user->fetchColumn(), ['qualite', 'admin'], true)) {
            throw new RuntimeException('Seul le responsable Qualité / SAV peut qualifier une demande de devis.');
        }
        if (!in_array($decision, ['valide', 'a_preciser'], true)) {
            throw new InvalidArgumentException('La décision de qualification est invalide.');
        }
        $commentaire = trim($commentaire);
        if ($commentaire === '' || mb_strlen($commentaire) > 3000) {
            throw new InvalidArgumentException('Renseignez les éléments techniques ou les précisions attendues (3 000 caractères maximum).');
        }
        $stmt = $this->conn->prepare(
            "UPDATE devis_b2b SET qualite_statut = :decision, qualite_commentaire = :commentaire,
                    qualite_par_user_id = :user_id, qualite_le = CURRENT_TIMESTAMP
             WHERE id = :id AND statut = 'demande' AND qualite_statut IN ('a_traiter', 'a_preciser')"
        );
        $stmt->execute([
            ':decision' => $decision,
            ':commentaire' => $commentaire,
            ':user_id' => $userId,
            ':id' => $devisId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function emettreDevis(int $devisId, int $userId, float $montant, string $details, ?string $validite): bool {
        $finance = $this->conn->prepare("SELECT role FROM users WHERE id = :id AND statut = 'actif' LIMIT 1");
        $finance->execute([':id' => $userId]);
        if (!in_array($finance->fetchColumn(), ['finance', 'admin'], true)) {
            throw new RuntimeException('Seul le responsable Finance peut émettre un devis.');
        }
        $details = trim($details);
        if (!is_finite($montant) || $montant <= 0 || $montant > 9999999999.99
            || $details === '' || mb_strlen($details) > 3000) {
            throw new InvalidArgumentException('Le montant doit être positif et les conditions du devis doivent être renseignées.');
        }
        if ($validite !== null) {
            $date = DateTimeImmutable::createFromFormat('!Y-m-d', $validite);
            if (!$date || $date->format('Y-m-d') !== $validite || $validite < date('Y-m-d')) {
                throw new InvalidArgumentException('La date de validité doit être aujourd’hui ou ultérieure.');
            }
        }
        $stmt = $this->conn->prepare(
            "UPDATE devis_b2b SET montant = :montant, details = :details, date_validite = :validite,
                    statut = 'emis', date_emission = CURRENT_TIMESTAMP
            WHERE id = :id AND statut = 'demande' AND qualite_statut = 'valide'"
        );
        return $stmt->execute([
            ':montant' => number_format($montant, 2, '.', ''),
            ':details' => $details, ':validite' => $validite, ':id' => $devisId,
        ]) && $stmt->rowCount() === 1;
    }

    public function modifierEntreprise(int $entrepriseId, int $adminId, array $donnees): bool {
        if (!$this->estAdministrateur($entrepriseId, $adminId)) {
            throw new RuntimeException('Seul un administrateur de l’entreprise peut modifier ses paramètres.');
        }
        $nom = trim((string) ($donnees['nom'] ?? ''));
        $interlocuteur = trim((string) ($donnees['interlocuteur_nom'] ?? ''));
        $telephone = trim((string) ($donnees['interlocuteur_telephone'] ?? ''));
        $email = trim((string) ($donnees['interlocuteur_email'] ?? ''));
        if ($nom === '' || mb_strlen($nom) > 150 || $interlocuteur === '' || mb_strlen($interlocuteur) > 100
            || mb_strlen($telephone) > 20 || mb_strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Vérifiez le nom, le contact, le téléphone et l’adresse e-mail.');
        }
        if ($this->nomExiste($nom, $entrepriseId)) {
            throw new InvalidArgumentException('Une entreprise porte déjà ce nom. Choisissez un nom différent.');
        }
        $stmt = $this->conn->prepare(
            "UPDATE entreprises_b2b
             SET nom = :nom, nom_normalise = :nom_normalise, interlocuteur_nom = :interlocuteur,
                 interlocuteur_telephone = :telephone, interlocuteur_email = :email
             WHERE id = :entreprise_id AND statut = 'actif'"
        );
        return $stmt->execute([
            ':nom' => $nom, ':nom_normalise' => $this->normaliserNom($nom),
            ':interlocuteur' => $interlocuteur, ':telephone' => $telephone,
            ':email' => $email, ':entreprise_id' => $entrepriseId,
        ]);
    }

    public function getFactures(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT DISTINCT f.id, f.numero, f.libelle, f.montant, f.devise, f.date_emission, f.chemin_fichier,
                    f.email_statut, d.numero_dossier, s.nom AS site_nom
             FROM factures f
             JOIN paiements p ON p.reference_transaction = f.reference_source
             JOIN demandes d ON d.id = p.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE s.entreprise_b2b_id = :entreprise_id AND f.type_operation = 'intervention'
             ORDER BY f.date_emission DESC, f.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getFichierFacture(int $factureId, int $entrepriseId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT f.numero, f.chemin_fichier
             FROM factures f
             JOIN paiements p ON p.reference_transaction = f.reference_source
             JOIN demandes d ON d.id = p.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE f.id = :facture_id AND s.entreprise_b2b_id = :entreprise_id
               AND f.type_operation = 'intervention'
             LIMIT 1"
        );
        $stmt->execute([':facture_id' => $factureId, ':entreprise_id' => $entrepriseId]);
        $facture = $stmt->fetch(PDO::FETCH_ASSOC);
        $nomFichier = is_array($facture) ? (string) ($facture['chemin_fichier'] ?? '') : '';
        if (!$facture || $nomFichier === '' || basename($nomFichier) !== $nomFichier) {
            return false;
        }
        $dossier = realpath(__DIR__ . '/../storage/factures');
        $fichier = realpath(__DIR__ . '/../storage/factures/' . $facture['chemin_fichier']);
        if ($dossier === false || $fichier === false
            || !str_starts_with($fichier, $dossier . DIRECTORY_SEPARATOR) || !is_file($fichier)) {
            throw new RuntimeException('Le fichier de cette facture est indisponible.');
        }
        $facture['chemin_absolu'] = $fichier;
        return $facture;
    }

    public function getPaiements(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT p.id, p.montant, p.methode, p.reference_transaction, p.statut, p.date_paiement,
                    d.numero_dossier, s.nom AS site_nom
             FROM paiements p
             JOIN demandes d ON d.id = p.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE s.entreprise_b2b_id = :entreprise_id
             ORDER BY p.date_paiement DESC, p.id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDocuments(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT id, nom_original, chemin, mime_type, taille, date_creation, intervention_id,
                    numero_dossier, site_nom
             FROM (
                 SELECT doc.id, doc.nom_original, doc.chemin, doc.mime_type, doc.taille, doc.date_creation,
                        i.id AS intervention_id, d.numero_dossier, s.nom AS site_nom
                 FROM intervention_documents doc
                 JOIN interventions i ON i.id = doc.intervention_id
                 JOIN demandes d ON d.id = i.demande_id
                 JOIN sites_b2b s ON s.id = d.site_b2b_id
                 WHERE s.entreprise_b2b_id = :entreprise_id
             ) AS documents_entreprise
             ORDER BY date_creation DESC, id DESC"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getFichierDocument(int $documentId, int $entrepriseId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT doc.nom_original, doc.chemin, doc.mime_type
             FROM intervention_documents doc
             JOIN interventions i ON i.id = doc.intervention_id
             JOIN demandes d ON d.id = i.demande_id
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             WHERE doc.id = :document_id AND s.entreprise_b2b_id = :entreprise_id
             LIMIT 1"
        );
        $stmt->execute([':document_id' => $documentId, ':entreprise_id' => $entrepriseId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getRapport(int $entrepriseId): array {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(DISTINCT d.id) AS demandes,
                    COUNT(DISTINCT CASE WHEN d.statut = 'terminee' THEN d.id END) AS terminees,
                    COUNT(DISTINCT CASE WHEN d.statut = 'annulee' THEN d.id END) AS annulees,
                    COUNT(DISTINCT i.id) AS interventions,
                    COUNT(DISTINCT CASE WHEN i.statut = 'terminee' THEN i.id END) AS interventions_terminees,
                    COUNT(DISTINCT CASE WHEN t.id IS NOT NULL THEN d.id END) AS dossiers_sav
             FROM sites_b2b s
             LEFT JOIN demandes d ON d.site_b2b_id = s.id
             LEFT JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN tickets_sav t ON t.demande_id = d.id
             WHERE s.entreprise_b2b_id = :entreprise_id"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    public function getEntrepriseIdPourDemande(int $demandeId, int $userId): ?int {
        $stmt = $this->conn->prepare(
            "SELECT s.entreprise_b2b_id
             FROM demandes d
             JOIN sites_b2b s ON s.id = d.site_b2b_id
             JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = s.entreprise_b2b_id
             WHERE d.id = :demande_id AND m.user_id = :user_id AND m.statut = 'actif'
             LIMIT 1"
        );
        $stmt->execute([':demande_id' => $demandeId, ':user_id' => $userId]);
        $entrepriseId = $stmt->fetchColumn();
        return $entrepriseId === false ? null : (int) $entrepriseId;
    }

    public function estAdministrateur(int $entrepriseId, int $userId): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM entreprises_b2b_membres
             WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id
               AND role = 'admin' AND statut = 'actif' LIMIT 1"
        );
        $stmt->execute([':entreprise_id' => $entrepriseId, ':user_id' => $userId]);
        return (bool) $stmt->fetchColumn();
    }

    public function quitterEntreprise(int $entrepriseId, int $userId): void {
        $this->conn->beginTransaction();
        try {
            $entrepriseStmt = $this->conn->prepare(
                "SELECT e.nom, m.role
                 FROM entreprises_b2b e
                 JOIN entreprises_b2b_membres m ON m.entreprise_b2b_id = e.id
                 WHERE e.id = :entreprise_id AND e.statut = 'actif'
                   AND m.user_id = :user_id AND m.statut = 'actif'
                 LIMIT 1 FOR UPDATE"
            );
            $entrepriseStmt->execute([':entreprise_id' => $entrepriseId, ':user_id' => $userId]);
            $entreprise = $entrepriseStmt->fetch(PDO::FETCH_ASSOC);
            if (!$entreprise) {
                throw new InvalidArgumentException('Vous n’êtes plus membre de cette entreprise.');
            }
            if ($entreprise['role'] !== 'membre') {
                throw new RuntimeException('Un administrateur ne peut pas quitter l’entreprise sans transférer son rôle au préalable.');
            }

            $utilisateurStmt = $this->conn->prepare(
                "SELECT prenom, nom, email FROM users WHERE id = :user_id LIMIT 1"
            );
            $utilisateurStmt->execute([':user_id' => $userId]);
            $utilisateur = $utilisateurStmt->fetch(PDO::FETCH_ASSOC);
            if (!$utilisateur) {
                throw new RuntimeException('Impossible d’identifier votre compte utilisateur.');
            }

            $retirer = $this->conn->prepare(
                "UPDATE entreprises_b2b_membres
                 SET statut = 'revoque', date_revocation = CURRENT_TIMESTAMP
                 WHERE entreprise_b2b_id = :entreprise_id AND user_id = :user_id
                   AND statut = 'actif' AND role = 'membre'"
            );
            $retirer->execute([':entreprise_id' => $entrepriseId, ':user_id' => $userId]);
            if ($retirer->rowCount() !== 1) {
                throw new RuntimeException('Votre accès à cette entreprise a déjà été modifié.');
            }

            $nomMembre = trim((string) $utilisateur['prenom'] . ' ' . (string) $utilisateur['nom']);
            if ($nomMembre === '') {
                $nomMembre = (string) $utilisateur['email'];
            }
            $notification = $this->conn->prepare(
                "INSERT INTO notifications (user_id, message, lien)
                 SELECT m.user_id, :message, :lien
                 FROM entreprises_b2b_membres m
                 WHERE m.entreprise_b2b_id = :entreprise_id AND m.role = 'admin'
                   AND m.statut = 'actif' AND m.user_id <> :user_id"
            );
            $notification->execute([
                ':message' => $nomMembre . ' (' . $utilisateur['email'] . ') a quitté l’entreprise « ' . $entreprise['nom'] . ' ».',
                ':lien' => '/allopro/views/entreprise/membres.php?entreprise_id=' . $entrepriseId . '&membre_parti=1',
                ':entreprise_id' => $entrepriseId,
                ':user_id' => $userId,
            ]);
            if ($notification->rowCount() < 1) {
                throw new RuntimeException('Aucun administrateur actif ne peut être informé de votre départ.');
            }

            $this->conn->commit();
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    private function ajouterMembreAdmin(int $entrepriseId, int $userId, int $createurId): void {
        $stmt = $this->conn->prepare(
            "INSERT INTO entreprises_b2b_membres (entreprise_b2b_id, user_id, role, statut, ajoute_par_user_id)
             VALUES (:entreprise_id, :user_id, 'admin', 'actif', :createur_id)"
        );
        $stmt->execute([
            ':entreprise_id' => $entrepriseId,
            ':user_id' => $userId,
            ':createur_id' => $createurId,
        ]);
    }

    private function validerSite(array $site): array {
        $nom = trim((string) ($site['nom'] ?? ''));
        $villeId = filter_var($site['ville_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $zoneId = filter_var($site['zone_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $details = trim((string) ($site['details'] ?? ''));
        $telephone = trim((string) ($site['telephone_contact'] ?? ''));
        $email = trim((string) ($site['email_contact'] ?? ''));
        if ($nom === '' || mb_strlen($nom) > 100 || $villeId === false || $zoneId === false
            || mb_strlen($details) > 2000
            || mb_strlen($telephone) > 20 || mb_strlen($email) > 150
            || ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL))) {
            throw new InvalidArgumentException('Vérifiez le nom, la ville, le quartier et les coordonnées du site.');
        }
        $zone = $this->conn->prepare(
            "SELECT z.nom AS quartier, v.nom AS ville
             FROM zones z
             JOIN zones v ON v.id = z.parent_id
             WHERE z.id = :zone_id AND z.parent_id = :ville_id
               AND z.type IN ('zone', 'quartier') AND z.statut = 'active'
               AND v.type = 'ville' AND v.statut = 'active'
             LIMIT 1"
        );
        $zone->execute([':zone_id' => $zoneId, ':ville_id' => $villeId]);
        $localisation = $zone->fetch(PDO::FETCH_ASSOC);
        if (!$localisation) {
            throw new InvalidArgumentException('Choisissez une ville et un quartier ou une zone actifs.');
        }
        return [
            'nom' => $nom,
            'ville' => $localisation['ville'],
            'ville_id' => (int) $villeId,
            'quartier' => $localisation['quartier'],
            'zone_id' => (int) $zoneId,
            'details' => $details,
            'telephone_contact' => $telephone,
            'email_contact' => $email,
        ];
    }

    private function normaliserNom(string $nom): string {
        $nom = preg_replace('/\s+/u', ' ', trim($nom));
        if (!is_string($nom)) {
            throw new InvalidArgumentException('Le nom de l’entreprise contient un format de texte invalide.');
        }
        return mb_strtolower($nom, 'UTF-8');
    }
}
