<?php
require_once __DIR__ . '/../config/database.php';

class Note {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId, $note, $commentaire) {
        $this->conn->beginTransaction();
        try {
            $demande = $this->conn->prepare(
                "SELECT id FROM demandes WHERE id = :demande_id AND statut = 'terminee' FOR UPDATE"
            );
            $demande->execute([':demande_id' => $demandeId]);
            if (!$demande->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO notes (demande_id, note, commentaire) VALUES (:demande_id, :note, :commentaire)"
            );
            $stmt->execute([
                ':demande_id' => $demandeId,
                ':note' => $note,
                ':commentaire' => $commentaire
            ]);

            if ((int) $note <= 2) {
                $ticket = $this->conn->prepare(
                    "SELECT id FROM tickets_sav WHERE demande_id = :demande_id LIMIT 1"
                );
                $ticket->execute([':demande_id' => $demandeId]);
                if (!$ticket->fetchColumn()) {
                    $creerTicket = $this->conn->prepare(
                        "INSERT INTO tickets_sav (demande_id, motif, statut, origine)
                         VALUES (:demande_id, :motif, 'ouvert', 'client')"
                    );
                    $creerTicket->execute([
                        ':demande_id' => $demandeId,
                        ':motif' => 'Avis client négatif (' . (int) $note . '/5)',
                    ]);
                }
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function existePour($demandeId) {
        $stmt = $this->conn->prepare("SELECT id FROM notes WHERE demande_id = :demande_id");
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return (bool) $stmt->fetch();
    }
    public function getByDemandeId($demandeId) {
        $stmt = $this->conn->prepare("SELECT * FROM notes WHERE demande_id = :demande_id");
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return $stmt->fetch();
    }
}