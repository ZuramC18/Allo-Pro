<?php
require_once __DIR__ . '/../config/database.php';

class Zone {
    private PDO $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getVillesActives(): array {
        $stmt = $this->conn->query(
            "SELECT id, nom
             FROM zones
             WHERE type = 'ville' AND statut = 'active'
             ORDER BY nom"
        );
        return $stmt->fetchAll();
    }

    public function rechercherQuartiers(?int $villeId = null, string $recherche = '', string $statut = 'tous', string $tri = 'ville_asc'): array {
        $sql = "SELECT z.id, z.nom, z.statut, z.type, z.osm_id, v.id AS ville_id, v.nom AS ville_nom
                FROM zones z
                JOIN zones v ON v.id = z.parent_id AND v.type = 'ville'
                WHERE z.type IN ('zone', 'quartier')";
        $params = [];
        if ($villeId !== null) {
            $sql .= ' AND v.id = :ville_id';
            $params[':ville_id'] = $villeId;
        }
        if ($recherche !== '') {
            $sql .= ' AND z.nom LIKE :recherche';
            $params[':recherche'] = '%' . $recherche . '%';
        }
        if (in_array($statut, ['active', 'inactive'], true)) {
            $sql .= ' AND z.statut = :statut';
            $params[':statut'] = $statut;
        }

        $ordres = [
            'ville_asc' => 'v.nom ASC, z.nom ASC',
            'quartier_asc' => 'z.nom ASC, v.nom ASC',
            'quartier_desc' => 'z.nom DESC, v.nom ASC',
        ];
        $sql .= ' ORDER BY ' . ($ordres[$tri] ?? $ordres['ville_asc']);

        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function ajouterQuartier(int $villeId, string $nom): bool {
        $nom = trim($nom);
        if ($nom === '' || mb_strlen($nom) > 100) {
            return false;
        }

        $villeStmt = $this->conn->prepare(
            "SELECT nom
             FROM zones
             WHERE id = :ville_id AND type = 'ville' AND statut = 'active'
             LIMIT 1"
        );
        $villeStmt->execute([':ville_id' => $villeId]);
        $ville = $villeStmt->fetchColumn();
        if ($ville === false) {
            return false;
        }

        $stmt = $this->conn->prepare(
            "INSERT INTO zones (nom, ville, pays, statut, type, parent_id)
             VALUES (:nom, :ville, 'Sénégal', 'active', 'quartier', :parent_id)"
        );
        return $stmt->execute([
            ':nom' => $nom,
            ':ville' => $ville,
            ':parent_id' => $villeId,
        ]);
    }

    public function changerStatut(int $id, string $statut): bool {
        if (!in_array($statut, ['active', 'inactive'], true)) {
            return false;
        }
        $stmt = $this->conn->prepare(
            "UPDATE zones
             SET statut = :statut
            WHERE id = :id AND type IN ('zone', 'quartier')"
        );
        $stmt->execute([':statut' => $statut, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }
}
