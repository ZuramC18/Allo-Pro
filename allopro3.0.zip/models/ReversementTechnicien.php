<?php
require_once __DIR__ . '/../config/database.php';

class ReversementTechnicien {
    private PDO $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getTechniciensPartenaire(int $partenaireId): array {
        $stmt = $this->conn->prepare(
            "SELECT t.id, t.nom, t.prenom, t.nom_famille, t.matricule, t.statut,
                    COALESCE(SUM(missions.nombre_interventions), 0) AS nombre_interventions,
                    COALESCE(SUM(missions.nombre_a_payer), 0) AS nombre_a_payer,
                    COALESCE(SUM(missions.nombre_payees), 0) AS nombre_payees,
                    COALESCE(SUM(missions.total_verse), 0) AS total_verse
             FROM techniciens t
             LEFT JOIN (
                 SELECT i.technicien_id,
                        COUNT(*) AS nombre_interventions,
                        SUM(rt.id IS NULL) AS nombre_a_payer,
                        SUM(rt.id IS NOT NULL) AS nombre_payees,
                        SUM(COALESCE(rt.montant, 0)) AS total_verse
                 FROM interventions i
                 JOIN demandes d ON d.id = i.demande_id
                 LEFT JOIN reversements_techniciens rt
                    ON rt.intervention_id = i.id
                    AND rt.partenaire_id = i.partenaire_id
                    AND rt.technicien_id = i.technicien_id
                 WHERE i.partenaire_id = :partenaire_missions
                   AND i.technicien_id IS NOT NULL
                   AND i.statut = 'terminee'
                   AND d.statut = 'terminee'
                 GROUP BY i.technicien_id
             ) missions ON missions.technicien_id = t.id
             WHERE t.partenaire_id = :partenaire_techniciens
               AND t.statut IN ('actif', 'inactif')
             GROUP BY t.id, t.nom, t.prenom, t.nom_famille, t.matricule, t.statut
             ORDER BY t.statut = 'actif' DESC, t.nom, t.prenom"
        );
        $stmt->execute([
            ':partenaire_missions' => $partenaireId,
            ':partenaire_techniciens' => $partenaireId,
        ]);
        return $stmt->fetchAll();
    }

    public function getTechnicienParPartenaire(int $technicienId, int $partenaireId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT id, nom, prenom, nom_famille, matricule, statut
             FROM techniciens
             WHERE id = :technicien_id AND partenaire_id = :partenaire_id
             LIMIT 1"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->fetch();
    }

    public function getMissionsParTechnicien(int $technicienId, int $partenaireId): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.technicien_id, i.technicien_nom,
                    i.montant AS montant_intervention, i.date_fin,
                    d.numero_dossier, c.nom AS categorie_nom,
                    rt.id AS reversement_id, rt.montant AS montant_verse,
                    rt.methode, rt.reference, rt.date_paiement
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             LEFT JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN reversements_techniciens rt ON rt.intervention_id = i.id
                  AND rt.partenaire_id = i.partenaire_id
                  AND rt.technicien_id = i.technicien_id
             WHERE i.partenaire_id = :partenaire_id
               AND i.technicien_id = :technicien_id
               AND i.statut = 'terminee'
               AND d.statut = 'terminee'
             ORDER BY i.date_fin DESC, i.id DESC"
        );
        $stmt->execute([
            ':partenaire_id' => $partenaireId,
            ':technicien_id' => $technicienId,
        ]);
        return $stmt->fetchAll();
    }

    public function enregistrerPaiement(
        int $interventionId,
        int $partenaireId,
        int $technicienId,
        string $montant,
        string $methode,
        ?string $reference
    ): int {
        $this->conn->beginTransaction();
        try {
            $mission = $this->conn->prepare(
                "SELECT i.id
                 FROM interventions i
                 JOIN demandes d ON d.id = i.demande_id
                 JOIN techniciens t ON t.id = i.technicien_id
                    AND t.partenaire_id = i.partenaire_id
                 WHERE i.id = :intervention_id
                   AND i.partenaire_id = :partenaire_id
                   AND i.technicien_id = :technicien_id
                   AND i.statut = 'terminee'
                   AND d.statut = 'terminee'
                 FOR UPDATE"
            );
            $mission->execute([
                ':intervention_id' => $interventionId,
                ':partenaire_id' => $partenaireId,
                ':technicien_id' => $technicienId,
            ]);
            if (!$mission->fetchColumn()) {
                throw new RuntimeException('Cette intervention terminée ne correspond pas à votre technicien.');
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO reversements_techniciens
                    (intervention_id, partenaire_id, technicien_id, montant, methode, reference)
                 VALUES
                    (:intervention_id, :partenaire_id, :technicien_id, :montant, :methode, :reference)"
            );
            $stmt->execute([
                ':intervention_id' => $interventionId,
                ':partenaire_id' => $partenaireId,
                ':technicien_id' => $technicienId,
                ':montant' => str_replace(',', '.', $montant),
                ':methode' => $methode,
                ':reference' => $reference !== '' ? $reference : null,
            ]);
            $reversementId = (int) $this->conn->lastInsertId();
            $this->conn->commit();
            return $reversementId;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }
}
