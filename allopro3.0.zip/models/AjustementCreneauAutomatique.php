<?php
require_once __DIR__ . '/../config/database.php';

class AjustementCreneauAutomatique {
    private PDO $conn;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function ajouter(
        int $demandeId,
        int $interventionId,
        int $technicienId,
        string $dateDemandee,
        int $heureDemandee,
        string $dateAttribuee,
        int $heureAttribuee
    ): void {
        $stmt = $this->conn->prepare(
            "INSERT INTO ajustements_creneaux_automatiques
                (demande_id, intervention_id, technicien_id, date_creneau_demande,
                 heure_creneau_demandee, date_creneau_attribue, heure_creneau_attribuee)
             VALUES
                (:demande_id, :intervention_id, :technicien_id, :date_demandee,
                 :heure_demandee, :date_attribuee, :heure_attribuee)"
        );
        $stmt->execute([
            ':demande_id' => $demandeId,
            ':intervention_id' => $interventionId,
            ':technicien_id' => $technicienId,
            ':date_demandee' => $dateDemandee,
            ':heure_demandee' => $heureDemandee,
            ':date_attribuee' => $dateAttribuee,
            ':heure_attribuee' => $heureAttribuee,
        ]);
    }

    public function getRecentes(): array {
        return $this->conn->query(
            "SELECT a.id, a.demande_id, a.intervention_id, a.technicien_id,
                    a.date_creneau_demande, a.heure_creneau_demandee,
                    a.date_creneau_attribue, a.heure_creneau_attribuee,
                    a.statut, a.date_traitement, a.date_creation,
                    d.numero_dossier, d.urgence,
                    technicien.nom AS technicien_nom,
                    traiteur.nom AS traiteur_nom
             FROM ajustements_creneaux_automatiques a
             JOIN demandes d ON d.id = a.demande_id
             JOIN techniciens technicien ON technicien.id = a.technicien_id
             LEFT JOIN users traiteur ON traiteur.id = a.traitee_par
             ORDER BY (a.statut = 'a_traiter') DESC, a.date_creation DESC, a.id DESC
             LIMIT 200"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function compterATraiter(): int {
        return (int) $this->conn->query(
            "SELECT COUNT(*) FROM ajustements_creneaux_automatiques WHERE statut = 'a_traiter'"
        )->fetchColumn();
    }

    public function marquerTraitee(int $id, int $utilisateurId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE ajustements_creneaux_automatiques
             SET statut = 'traitee', traitee_par = :utilisateur_id, date_traitement = NOW()
             WHERE id = :id AND statut = 'a_traiter'"
        );
        $stmt->execute([':id' => $id, ':utilisateur_id' => $utilisateurId]);
        return $stmt->rowCount() === 1;
    }
}
