<?php
require_once __DIR__ . '/../config/database.php';

class AppelWeb {
    private PDO $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function actualiserPresence(int $userId, string $role, ?int $technicienId = null): void {
        $stmt = $this->conn->prepare(
            "INSERT INTO messagerie_appels_web_presence (user_id, technicien_id, role, dernier_ping)
             VALUES (:user_id, :technicien_id, :role, NOW())
             ON DUPLICATE KEY UPDATE role = VALUES(role), dernier_ping = NOW()"
        );
        $stmt->execute([
            ':user_id' => $technicienId === null ? $userId : null,
            ':technicien_id' => $technicienId,
            ':role' => $role,
        ]);
    }

    public function clientDisponible(int $clientId): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM messagerie_appels_web_presence
             WHERE user_id = :client_id AND role = 'client'
               AND dernier_ping >= DATE_SUB(NOW(), INTERVAL 15 SECOND)
             LIMIT 1"
        );
        $stmt->execute([':client_id' => $clientId]);
        return (bool) $stmt->fetchColumn();
    }

    public function creer(int $clientId, ?int $appelantId, string $role, ?int $technicienId = null, ?int $interventionId = null): int {
        $this->conn->beginTransaction();
        try {
            $this->conn->exec(
                "DELETE FROM messagerie_appels_web
                 WHERE date_creation < DATE_SUB(NOW(), INTERVAL 7 DAY)"
            );
            $this->conn->prepare(
                "UPDATE messagerie_appels_web SET statut = 'expire'
                 WHERE client_id = :client_id AND statut = 'sonnerie'
                   AND date_creation < DATE_SUB(NOW(), INTERVAL 35 SECOND)"
            )->execute([':client_id' => $clientId]);
            $this->terminerAppelsObsoletesDuClient($clientId);

            $verifier = $this->conn->prepare(
                "SELECT id FROM messagerie_appels_web
                 WHERE client_id = :client_id AND statut IN ('sonnerie', 'accepte')
                 LIMIT 1 FOR UPDATE"
            );
            $verifier->execute([':client_id' => $clientId]);
            if ($verifier->fetchColumn()) {
                throw new DomainException('Le client est déjà en appel ou reçoit un autre appel. Terminez l’appel en cours sur l’autre appareil, puis réessayez.');
            }

            $insert = $this->conn->prepare(
                "INSERT INTO messagerie_appels_web
                    (client_id, appelant_id, appelant_technicien_id, intervention_id, appelant_role)
                 VALUES (:client_id, :appelant_id, :technicien_id, :intervention_id, :role)"
            );
            $insert->execute([
                ':client_id' => $clientId,
                ':appelant_id' => $appelantId,
                ':technicien_id' => $technicienId,
                ':intervention_id' => $interventionId,
                ':role' => $role,
            ]);
            $appelId = (int) $this->conn->lastInsertId();
            $notification = $this->conn->prepare(
                "INSERT INTO notifications (user_id, message, lien)
                 VALUES (:client_id, :message, :lien)"
            );
            $notification->execute([
                ':client_id' => $clientId,
                ':message' => 'Appel entrant — Allô PRO vous appelle. Ouvrez la messagerie pour répondre.',
                ':lien' => '/allopro/views/client/messagerie.php?appel_id=' . $appelId,
            ]);
            $this->conn->commit();
            return $appelId;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            throw $exception;
        }
    }

    public function appelEntrant(int $clientId): ?array {
        $stmt = $this->conn->prepare(
            "SELECT a.id, a.client_id, a.appelant_id, a.appelant_technicien_id, a.appelant_role, a.statut,
                    COALESCE(u.nom, t.nom) AS appelant_nom
             FROM messagerie_appels_web a
             LEFT JOIN users u ON u.id = a.appelant_id
             LEFT JOIN techniciens t ON t.id = a.appelant_technicien_id
             WHERE a.client_id = :client_id AND a.statut = 'sonnerie'
               AND a.date_creation >= DATE_SUB(NOW(), INTERVAL 35 SECOND)
             ORDER BY a.id DESC LIMIT 1"
        );
        $stmt->execute([':client_id' => $clientId]);
        $appel = $stmt->fetch();
        return $appel ?: null;
    }

    public function obtenir(int $appelId): ?array {
        $this->conn->prepare(
            "UPDATE messagerie_appels_web SET statut = 'expire'
             WHERE id = :id AND statut = 'sonnerie'
               AND date_creation < DATE_SUB(NOW(), INTERVAL 35 SECOND)"
        )->execute([':id' => $appelId]);
        $stmt = $this->conn->prepare("SELECT * FROM messagerie_appels_web WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $appelId]);
        $appel = $stmt->fetch();
        return $appel ?: null;
    }

    public function changerStatut(
        int $appelId,
        string $statut,
        int $userId,
        bool $coteClient = false,
        ?int $technicienId = null
    ): bool {
        $conditionParticipant = $coteClient
            ? 'client_id = :user_id'
            : ($technicienId === null ? 'appelant_id = :user_id' : 'appelant_technicien_id = :technicien_id');
        $stmt = $this->conn->prepare(
            "UPDATE messagerie_appels_web SET statut = :statut
             WHERE id = :id AND {$conditionParticipant} AND statut IN ('sonnerie', 'accepte')"
        );
        $parametres = [':statut' => $statut, ':id' => $appelId];
        if ($coteClient || $technicienId === null) $parametres[':user_id'] = $userId;
        if ($technicienId !== null && !$coteClient) $parametres[':technicien_id'] = $technicienId;
        $stmt->execute($parametres);
        return $stmt->rowCount() === 1;
    }

    public function enregistrerSignal(
        int $appelId,
        int $expediteurId,
        string $type,
        string $contenu,
        ?int $technicienId = null
    ): void {
        $stmt = $this->conn->prepare(
            "INSERT INTO messagerie_appels_web_signaux
                (appel_id, expediteur_id, expediteur_technicien_id, type_signal, contenu)
             VALUES (:appel_id, :expediteur_id, :technicien_id, :type, :contenu)"
        );
        $stmt->execute([
            ':appel_id' => $appelId,
            ':expediteur_id' => $technicienId === null ? $expediteurId : null,
            ':technicien_id' => $technicienId,
            ':type' => $type,
            ':contenu' => $contenu,
        ]);
    }

    public function compterSignaux(int $appelId): int {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) FROM messagerie_appels_web_signaux WHERE appel_id = :appel_id"
        );
        $stmt->execute([':appel_id' => $appelId]);
        return (int) $stmt->fetchColumn();
    }

    public function signauxDepuis(int $appelId, int $userId, int $apresId, ?int $technicienId = null): array {
        $stmt = $this->conn->prepare(
            "SELECT id, expediteur_id, expediteur_technicien_id, type_signal, contenu
             FROM messagerie_appels_web_signaux
             WHERE appel_id = :appel_id
               AND NOT (expediteur_id <=> :user_id AND expediteur_technicien_id <=> :technicien_id)
               AND id > :apres_id
             ORDER BY id ASC LIMIT 100"
        );
        $stmt->execute([
            ':appel_id' => $appelId,
            ':user_id' => $technicienId === null ? $userId : null,
            ':technicien_id' => $technicienId,
            ':apres_id' => $apresId,
        ]);
        return $stmt->fetchAll();
    }

    public function expirerAppelsSansPresence(int $appelId): void {
        $stmt = $this->conn->prepare(
            "UPDATE messagerie_appels_web a
             LEFT JOIN messagerie_appels_web_presence pc ON pc.user_id = a.client_id
             LEFT JOIN messagerie_appels_web_presence pa
                ON (a.appelant_id IS NOT NULL AND pa.user_id = a.appelant_id)
                OR (a.appelant_technicien_id IS NOT NULL AND pa.technicien_id = a.appelant_technicien_id)
             SET a.statut = 'termine'
             WHERE a.id = :id AND a.statut = 'accepte'
               AND (a.date_maj < DATE_SUB(NOW(), INTERVAL 30 SECOND)
                    OR pc.dernier_ping IS NULL OR pc.dernier_ping < DATE_SUB(NOW(), INTERVAL 30 SECOND)
                    OR pa.dernier_ping IS NULL OR pa.dernier_ping < DATE_SUB(NOW(), INTERVAL 30 SECOND))"
        );
        $stmt->execute([':id' => $appelId]);
    }

    public function actualiserActivite(int $appelId): void {
        $stmt = $this->conn->prepare(
            "UPDATE messagerie_appels_web SET date_maj = NOW()
             WHERE id = :id AND statut = 'accepte'"
        );
        $stmt->execute([':id' => $appelId]);
    }

    private function terminerAppelsObsoletesDuClient(int $clientId): void {
        $stmt = $this->conn->prepare(
            "UPDATE messagerie_appels_web a
             LEFT JOIN messagerie_appels_web_presence pc ON pc.user_id = a.client_id
             LEFT JOIN messagerie_appels_web_presence pa
                ON (a.appelant_id IS NOT NULL AND pa.user_id = a.appelant_id)
                OR (a.appelant_technicien_id IS NOT NULL AND pa.technicien_id = a.appelant_technicien_id)
             SET a.statut = CASE WHEN a.statut = 'sonnerie' THEN 'expire' ELSE 'termine' END
             WHERE a.client_id = :client_id AND a.statut IN ('sonnerie', 'accepte')
               AND ((a.statut = 'sonnerie' AND a.date_creation < DATE_SUB(NOW(), INTERVAL 35 SECOND))
                    OR (a.statut = 'accepte' AND
                        (a.date_maj < DATE_SUB(NOW(), INTERVAL 30 SECOND)
                         OR pc.dernier_ping IS NULL OR pc.dernier_ping < DATE_SUB(NOW(), INTERVAL 30 SECOND)
                         OR pa.dernier_ping IS NULL OR pa.dernier_ping < DATE_SUB(NOW(), INTERVAL 30 SECOND))))"
        );
        $stmt->execute([':client_id' => $clientId]);
    }
}
