<?php
require_once __DIR__ . '/../config/database.php';

class AutorisationAppelTechnicien {
    private PDO $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function listerMissions(string $recherche = ''): array {
        $sql =
            "SELECT i.id AS intervention_id, i.statut, i.date_creneau_planifie,
                    d.id AS demande_id, d.numero_dossier, d.client_id,
                    u.nom AS client_nom, u.prenom AS client_prenom,
                    t.id AS technicien_id, t.nom AS technicien_nom, t.prenom AS technicien_prenom,
                    p.nom_entreprise AS partenaire_nom,
                    a.id AS autorisation_id, a.date_autorisation, auteur.nom AS autorise_par_nom
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN users u ON u.id = d.client_id
             JOIN techniciens t ON t.id = i.technicien_id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             LEFT JOIN autorisations_appels_web_techniciens a
                ON a.intervention_id = i.id AND a.date_revocation IS NULL
             LEFT JOIN users auteur ON auteur.id = a.autorise_par
             WHERE d.site_b2b_id IS NULL
               AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
               AND (
                    :recherche_vide = ''
                    OR d.numero_dossier LIKE :recherche_dossier
                    OR CONCAT_WS(' ', u.prenom, u.nom) LIKE :recherche_client
                    OR CONCAT_WS(' ', t.prenom, t.nom) LIKE :recherche_technicien
                    OR p.nom_entreprise LIKE :recherche_partenaire
                    OR CAST(i.id AS CHAR) LIKE :recherche_id
               )
             ORDER BY (a.id IS NOT NULL) ASC, i.id DESC";
        $stmt = $this->conn->prepare($sql);
        $terme = '%' . $recherche . '%';
        $stmt->execute([
            ':recherche_vide' => $recherche,
            ':recherche_dossier' => $terme,
            ':recherche_client' => $terme,
            ':recherche_technicien' => $terme,
            ':recherche_partenaire' => $terme,
            ':recherche_id' => $terme,
        ]);
        return $stmt->fetchAll();
    }

    public function modifier(int $interventionId, bool $autoriser, int $acteurId, string $role): bool {
        $this->conn->beginTransaction();
        try {
            $mission = $this->conn->prepare(
                "SELECT i.id, i.technicien_id, d.client_id
                 FROM interventions i
                 JOIN demandes d ON d.id = i.demande_id
                 WHERE i.id = :id AND d.site_b2b_id IS NULL
                   AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
                 FOR UPDATE"
            );
            $mission->execute([':id' => $interventionId]);
            $donneesMission = $mission->fetch();
            if (!$donneesMission) {
                $this->conn->rollBack();
                return false;
            }

            if ($autoriser) {
                $stmt = $this->conn->prepare(
                    "INSERT INTO autorisations_appels_web_techniciens
                        (intervention_id, client_id, technicien_id, autorise_par, autorise_par_role)
                     VALUES (:intervention_id, :client_id, :technicien_id, :acteur_id, :role)
                     ON DUPLICATE KEY UPDATE
                        client_id = VALUES(client_id),
                        technicien_id = VALUES(technicien_id),
                        autorise_par = VALUES(autorise_par),
                        autorise_par_role = VALUES(autorise_par_role),
                        date_autorisation = NOW(),
                        revoque_par = NULL,
                        date_revocation = NULL"
                );
                $stmt->execute([
                    ':intervention_id' => $interventionId,
                    ':client_id' => $donneesMission['client_id'],
                    ':technicien_id' => $donneesMission['technicien_id'],
                    ':acteur_id' => $acteurId,
                    ':role' => $role,
                ]);
            } else {
                $stmt = $this->conn->prepare(
                    "UPDATE autorisations_appels_web_techniciens
                     SET revoque_par = :acteur_id, date_revocation = NOW()
                     WHERE intervention_id = :intervention_id AND date_revocation IS NULL"
                );
                $stmt->execute([':acteur_id' => $acteurId, ':intervention_id' => $interventionId]);
            }
            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            throw $exception;
        }
    }

    public function estAutorise(int $interventionId, int $technicienId): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1
             FROM autorisations_appels_web_techniciens a
             JOIN interventions i ON i.id = a.intervention_id
             JOIN demandes d ON d.id = i.demande_id AND d.client_id = a.client_id
             WHERE a.intervention_id = :intervention_id
               AND a.technicien_id = :autorise_technicien_id
               AND a.date_revocation IS NULL
               AND i.technicien_id = :mission_technicien_id
               AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
               AND d.site_b2b_id IS NULL
             LIMIT 1"
        );
        $stmt->execute([
            ':intervention_id' => $interventionId,
            ':autorise_technicien_id' => $technicienId,
            ':mission_technicien_id' => $technicienId,
        ]);
        return (bool) $stmt->fetchColumn();
    }

    public function clientPourMissionAutorisee(int $interventionId, int $technicienId): ?int {
        $stmt = $this->conn->prepare(
            "SELECT a.client_id
             FROM autorisations_appels_web_techniciens a
             JOIN interventions i ON i.id = a.intervention_id
             JOIN demandes d ON d.id = i.demande_id AND d.client_id = a.client_id
             WHERE a.intervention_id = :intervention_id
               AND a.technicien_id = :autorise_technicien_id
               AND a.date_revocation IS NULL
               AND i.technicien_id = :mission_technicien_id
               AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
               AND d.site_b2b_id IS NULL
             LIMIT 1"
        );
        $stmt->execute([
            ':intervention_id' => $interventionId,
            ':autorise_technicien_id' => $technicienId,
            ':mission_technicien_id' => $technicienId,
        ]);
        $clientId = $stmt->fetchColumn();
        return $clientId === false ? null : (int) $clientId;
    }
}
