<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Parametre.php';

class VueOperationnelleCoordinateur {
    private PDO $conn;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function getIndicateurs(): array {
        $parametres = new Parametre($this->conn);
        $sql = "
            SELECT
                (SELECT COUNT(*)
                 FROM attributions_demandes_coordinateurs a
                 JOIN demandes d ON d.id = a.demande_id
                 WHERE a.statut = 'en_attente' AND d.statut = 'nouvelle') AS demandes_a_affecter,
                (SELECT COUNT(*)
                 FROM interventions
                 WHERE statut = 'en_attente') AS missions_en_attente,
                (SELECT COUNT(*)
                 FROM interventions
                 WHERE statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')) AS missions_actives,
                (SELECT COUNT(*)
                 FROM file_attente_interventions
                 WHERE statut = 'en_attente') AS refus_a_traiter,
                (SELECT COUNT(*)
                 FROM attributions_demandes_coordinateurs a
                 JOIN demandes d ON d.id = a.demande_id
                 WHERE a.statut = 'en_attente'
                   AND d.statut = 'nouvelle'
                   AND d.urgence = 'urgente') AS demandes_urgentes,
                (SELECT COUNT(*)
                 FROM attributions_demandes_coordinateurs a
                 JOIN demandes d ON d.id = a.demande_id
                 WHERE a.statut = 'en_attente'
                   AND d.statut = 'nouvelle'
                   AND TIMESTAMPDIFF(MINUTE, a.date_attribution, NOW()) >=
                       CASE WHEN d.urgence = 'urgente' THEN :sla_urgent_minutes ELSE :sla_normal_minutes END) AS sla_depasse,
                (SELECT COUNT(*)
                 FROM interventions i
                 JOIN demandes d ON d.id = i.demande_id
                 WHERE i.statut NOT IN ('terminee', 'annulee', 'refusee')
                   AND d.date_creneau_souhaite IS NOT NULL
                   AND TIMESTAMP(DATE_ADD(d.date_creneau_souhaite, INTERVAL (d.heure_creneau_souhaitee + 1) HOUR)) < NOW()) AS creneaux_depasse,
                (SELECT COUNT(*)
                 FROM techniciens t
                 JOIN partenaires p ON p.id = t.partenaire_id AND p.statut = 'actif'
                 WHERE t.statut = 'actif'
                   AND NOT EXISTS (
                       SELECT 1 FROM interventions i
                       WHERE i.technicien_id = t.id
                         AND i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
                   )
                   AND NOT EXISTS (
                       SELECT 1 FROM technicien_indisponibilites ti
                       WHERE ti.technicien_id = t.id
                         AND ti.date_indisponibilite = CURDATE()
                         AND ti.heure_debut = HOUR(NOW())
                   )) AS techniciens_disponibles,
                (SELECT COUNT(*)
                 FROM partenaires p
                 WHERE p.statut = 'actif'
                   AND EXISTS (
                       SELECT 1 FROM techniciens t
                       WHERE t.partenaire_id = p.id AND t.statut = 'actif'
                         AND NOT EXISTS (
                             SELECT 1 FROM interventions i
                             WHERE i.technicien_id = t.id
                               AND i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
                         )
                         AND NOT EXISTS (
                             SELECT 1 FROM technicien_indisponibilites ti
                             WHERE ti.technicien_id = t.id
                               AND ti.date_indisponibilite = CURDATE()
                               AND ti.heure_debut = HOUR(NOW())
                         )
                   )) AS partenaires_disponibles";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            ':sla_urgent_minutes' => $parametres->getSlaDemandeUrgenteHeures() * 60,
            ':sla_normal_minutes' => $parametres->getSlaDemandeNormaleHeures() * 60,
        ]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getMissions(): array {
        $stmt = $this->conn->query(
            "SELECT i.id AS intervention_id, i.demande_id, i.statut AS intervention_statut,
                    i.date_debut, i.date_decision_technicien,
                    i.date_creneau_planifie, i.heure_creneau_planifie,
                    d.numero_dossier, d.urgence, d.date_creation,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    d.date_creneau_souhaite, d.heure_creneau_souhaitee,
                    c.nom AS categorie_nom, u.nom AS client_nom,
                    a.quartier, a.ville, p.nom_entreprise,
                    COALESCE(t.nom, i.technicien_nom) AS technicien_nom
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN users u ON u.id = d.client_id
             JOIN adresses a ON a.id = d.adresse_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             WHERE i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
             ORDER BY CASE WHEN d.urgence = 'urgente' THEN 0 ELSE 1 END,
                      FIELD(i.statut, 'en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours'),
                      i.date_debut ASC"
        );
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getRessources(): array {
        $stmt = $this->conn->query(
            "SELECT p.id, p.nom_entreprise, p.niveau, p.score, p.telephone,
                    (SELECT GROUP_CONCAT(DISTINCT z.nom ORDER BY v.nom, z.nom SEPARATOR ', ')
                     FROM partenaire_zones pz
                     JOIN zones z ON z.id = pz.zone_id
                     LEFT JOIN zones v ON v.id = z.parent_id
                     WHERE pz.partenaire_id = p.id AND z.statut = 'active') AS zones,
                    (SELECT COUNT(*) FROM techniciens t
                     WHERE t.partenaire_id = p.id AND t.statut = 'actif') AS techniciens_actifs,
                    (SELECT COUNT(*) FROM techniciens t
                     WHERE t.partenaire_id = p.id AND t.statut = 'actif'
                       AND NOT EXISTS (
                           SELECT 1 FROM interventions i
                           WHERE i.technicien_id = t.id
                             AND i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
                       )
                       AND NOT EXISTS (
                           SELECT 1 FROM technicien_indisponibilites ti
                           WHERE ti.technicien_id = t.id
                             AND ti.date_indisponibilite = CURDATE()
                             AND ti.heure_debut = HOUR(NOW())
                       )) AS techniciens_disponibles
             FROM partenaires p
             WHERE p.statut = 'actif'
             ORDER BY p.nom_entreprise"
        );
        $partenaires = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $techniciensStmt = $this->conn->query(
            "SELECT t.id, t.nom, t.statut, p.nom_entreprise,
                    (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY cp.nom, c.nom SEPARATOR ', ')
                     FROM technicien_competences tc
                     JOIN categories c ON c.id = tc.categorie_id
                     LEFT JOIN categories cp ON cp.id = c.parent_id
                     WHERE tc.technicien_id = t.id) AS competences,
                    (SELECT COUNT(*)
                     FROM interventions i
                     WHERE i.technicien_id = t.id
                       AND i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')) AS charge,
                    (SELECT EXISTS(
                        SELECT 1 FROM technicien_indisponibilites ti
                        WHERE ti.technicien_id = t.id
                          AND ti.date_indisponibilite = CURDATE()
                          AND ti.heure_debut = HOUR(NOW())
                    )) AS indisponible_actuellement
             FROM techniciens t
             JOIN partenaires p ON p.id = t.partenaire_id AND p.statut = 'actif'
             WHERE t.statut = 'actif'
             ORDER BY p.nom_entreprise, t.nom"
        );
        $techniciens = $techniciensStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($techniciens as &$technicien) {
            $technicien['charge'] = (int) $technicien['charge'];
            $technicien['disponible'] = $technicien['charge'] === 0 && empty($technicien['indisponible_actuellement']);
        }
        unset($technicien);

        return ['partenaires' => $partenaires, 'techniciens' => $techniciens];
    }

    public function getPerformancePartenaires(int $jours = 90): array {
        $jours = in_array($jours, [30, 90, 365, 0], true) ? $jours : 90;
        $periodeIntervention = $jours > 0 ? ' AND i.date_debut >= DATE_SUB(NOW(), INTERVAL ' . $jours . ' DAY)' : '';
        $periodeRefus = $jours > 0 ? ' AND f.date_creation >= DATE_SUB(NOW(), INTERVAL ' . $jours . ' DAY)' : '';
        $stmt = $this->conn->query(
            "SELECT p.id, p.nom_entreprise, p.niveau,
                    COUNT(DISTINCT i.id) AS missions_attribuees,
                    COUNT(DISTINCT CASE WHEN i.statut = 'terminee' THEN i.id END) AS missions_terminees,
                    AVG(CASE WHEN i.statut = 'terminee' AND i.date_fin IS NOT NULL AND i.date_debut IS NOT NULL
                        THEN TIMESTAMPDIFF(MINUTE, i.date_debut, i.date_fin) END) AS duree_moyenne_minutes,
                    AVG(n.note) AS note_moyenne,
                    COUNT(DISTINCT n.id) AS nombre_avis,
                    (SELECT COUNT(*)
                     FROM file_attente_interventions f
                     JOIN interventions fi ON fi.id = f.intervention_id
                     WHERE fi.partenaire_id = p.id{$periodeRefus}) AS refus_techniciens
             FROM partenaires p
             LEFT JOIN interventions i ON i.partenaire_id = p.id{$periodeIntervention}
             LEFT JOIN notes n ON n.demande_id = i.demande_id
             WHERE p.statut = 'actif'
             GROUP BY p.id, p.nom_entreprise, p.niveau
             ORDER BY missions_terminees DESC, note_moyenne DESC, p.nom_entreprise"
        );
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) {
            $row['missions_attribuees'] = (int) $row['missions_attribuees'];
            $row['missions_terminees'] = (int) $row['missions_terminees'];
            $row['refus_techniciens'] = (int) $row['refus_techniciens'];
            $row['nombre_avis'] = (int) $row['nombre_avis'];
            $row['taux_achevement'] = $row['missions_attribuees'] > 0
                ? round(100 * $row['missions_terminees'] / $row['missions_attribuees'])
                : null;
        }
        unset($row);
        return $rows;
    }

}
