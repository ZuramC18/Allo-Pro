<?php
require_once __DIR__ . '/../config/database.php';

class Paiement {
    private $conn;
    private $table = 'paiements';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId, $montant, $methode) {
        $reference = 'PAY-' . strtoupper(uniqid());
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (demande_id, montant, methode, reference_transaction, statut) 
             VALUES (:demande_id, :montant, :methode, :reference, 'en_attente')"
        );
        $stmt->execute([
            ':demande_id' => $demandeId,
            ':montant' => $montant,
            ':methode' => $methode,
            ':reference' => $reference
        ]);
        return $reference;
    }

    public function getByReference($reference) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE reference_transaction = :ref");
        $stmt->bindParam(':ref', $reference);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getByReferenceForClient($reference, $clientId) {
        $stmt = $this->conn->prepare(
            "SELECT p.*, d.id AS demande_id, d.numero_dossier, d.client_id
             FROM {$this->table} p
             JOIN demandes d ON d.id = p.demande_id
             WHERE p.reference_transaction = :reference AND d.client_id = :client_id
             LIMIT 1"
        );
        $stmt->execute([':reference' => $reference, ':client_id' => $clientId]);
        return $stmt->fetch();
    }

    public function getByDemandeId($demandeId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table} WHERE demande_id = :demande_id
             ORDER BY CASE statut
                 WHEN 'valide' THEN 0
                 WHEN 'en_attente' THEN 1
                 ELSE 2
             END, id DESC
             LIMIT 1"
        );
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getHistoriqueClient(int $clientId, ?string $statut = null): array {
        $sql = "SELECT 'intervention' AS type, p.demande_id, d.numero_dossier, p.montant,
                       p.methode, p.reference_transaction, p.statut, p.date_paiement AS date_operation
                FROM {$this->table} p
                JOIN demandes d ON d.id = p.demande_id
                WHERE d.client_id = :client_intervention
                UNION ALL
                SELECT 'abonnement' AS type, NULL AS demande_id, NULL AS numero_dossier,
                       ac.montant_achat AS montant, NULL AS methode, ac.reference_transaction,
                       ac.statut, ac.date_creation AS date_operation
                FROM abonnements_clients ac
                WHERE ac.client_id = :client_abonnement
                UNION ALL
                SELECT 'pass' AS type, pa.demande_id, d.numero_dossier,
                       COALESCE(pa.montant_achat, pt.prix) AS montant, NULL AS methode,
                       pa.reference_transaction, pa.statut, pa.date_achat AS date_operation
                FROM pass_achats pa
                JOIN pass_types pt ON pt.id = pa.pass_type_id
                LEFT JOIN demandes d ON d.id = pa.demande_id AND d.client_id = pa.client_id
                WHERE pa.client_id = :client_pass";
        if ($statut !== null) {
            $sql = "SELECT * FROM ({$sql}) transactions WHERE statut = :statut";
        }
        $sql .= " ORDER BY date_operation DESC";

        $stmt = $this->conn->prepare($sql);
        $params = [
            ':client_intervention' => $clientId,
            ':client_abonnement' => $clientId,
            ':client_pass' => $clientId,
        ];
        if ($statut !== null) {
            $params[':statut'] = $statut;
        }
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function marquerValide($reference) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = 'valide', date_paiement = NOW()
             WHERE reference_transaction = :ref AND statut = 'en_attente'"
        );
        $stmt->execute([':ref' => $reference]);
        return $stmt->rowCount() === 1;
    }

    public function sommeAujourdhui() {
        $stmt = $this->conn->query("SELECT COALESCE(SUM(montant),0) as total FROM {$this->table} WHERE statut = 'valide' AND DATE(date_paiement) = CURDATE()");
        return $stmt->fetch()['total'];
    }

    public function getAllAvecFiltres($statutFiltre = null, $methodeFiltre = null, $recherche = null) {
        $sql = "SELECT p.*, d.numero_dossier, u.nom AS client_nom
                FROM {$this->table} p
                JOIN demandes d ON p.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                WHERE 1=1";

        if ($statutFiltre) $sql .= " AND p.statut = :statut";
        if ($methodeFiltre) $sql .= " AND p.methode = :methode";
        if ($recherche) $sql .= " AND (p.reference_transaction LIKE :recherche_ref OR d.numero_dossier LIKE :recherche_dossier OR u.nom LIKE :recherche_client)";
        $sql .= " ORDER BY p.date_paiement DESC LIMIT 200";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) $stmt->bindParam(':statut', $statutFiltre);
        if ($methodeFiltre) $stmt->bindParam(':methode', $methodeFiltre);
        if ($recherche) {
            $terme = '%' . $recherche . '%';
            $stmt->bindValue(':recherche_ref', $terme);
            $stmt->bindValue(':recherche_dossier', $terme);
            $stmt->bindValue(':recherche_client', $terme);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterAvecFiltres($statutFiltre = null, $methodeFiltre = null, $recherche = null) {
        $sql = "SELECT COUNT(*) FROM {$this->table} p
                JOIN demandes d ON p.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                WHERE 1=1";

        if ($statutFiltre) $sql .= " AND p.statut = :statut";
        if ($methodeFiltre) $sql .= " AND p.methode = :methode";
        if ($recherche) $sql .= " AND (p.reference_transaction LIKE :recherche_ref OR d.numero_dossier LIKE :recherche_dossier OR u.nom LIKE :recherche_client)";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) $stmt->bindParam(':statut', $statutFiltre);
        if ($methodeFiltre) $stmt->bindParam(':methode', $methodeFiltre);
        if ($recherche) {
            $terme = '%' . $recherche . '%';
            $stmt->bindValue(':recherche_ref', $terme);
            $stmt->bindValue(':recherche_dossier', $terme);
            $stmt->bindValue(':recherche_client', $terme);
        }
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }

    public function getHistoriqueAvecFiltres($statutFiltre = null, $methodeFiltre = null, $limite = 25, $decalage = 0, $recherche = null) {
        $sql = "SELECT p.*, d.numero_dossier, u.nom AS client_nom
                FROM {$this->table} p
                JOIN demandes d ON p.demande_id = d.id
                JOIN users u ON d.client_id = u.id
                WHERE 1=1";

        if ($statutFiltre) $sql .= " AND p.statut = :statut";
        if ($methodeFiltre) $sql .= " AND p.methode = :methode";
        if ($recherche) $sql .= " AND (p.reference_transaction LIKE :recherche_ref OR d.numero_dossier LIKE :recherche_dossier OR u.nom LIKE :recherche_client)";
        $sql .= " ORDER BY p.date_paiement DESC LIMIT :limite OFFSET :decalage";

        $stmt = $this->conn->prepare($sql);
        if ($statutFiltre) $stmt->bindParam(':statut', $statutFiltre);
        if ($methodeFiltre) $stmt->bindParam(':methode', $methodeFiltre);
        if ($recherche) {
            $terme = '%' . $recherche . '%';
            $stmt->bindValue(':recherche_ref', $terme);
            $stmt->bindValue(':recherche_dossier', $terme);
            $stmt->bindValue(':recherche_client', $terme);
        }
        $stmt->bindValue(':limite', max(1, (int) $limite), PDO::PARAM_INT);
        $stmt->bindValue(':decalage', max(0, (int) $decalage), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function sommeParStatut() {
        $stmt = $this->conn->query("SELECT statut, COALESCE(SUM(montant),0) as total, COUNT(*) as nb FROM {$this->table} GROUP BY statut");
        $resultats = $stmt->fetchAll();
        $sommes = ['valide' => ['total' => 0, 'nb' => 0], 'en_attente' => ['total' => 0, 'nb' => 0], 'echoue' => ['total' => 0, 'nb' => 0]];
        foreach ($resultats as $r) { $sommes[$r['statut']] = ['total' => (float) $r['total'], 'nb' => (int) $r['nb']]; }
        return $sommes;
    }

    public function sommeParMethode() {
        $stmt = $this->conn->query("SELECT methode, COALESCE(SUM(montant),0) as total FROM {$this->table} WHERE statut = 'valide' GROUP BY methode");
        return $stmt->fetchAll();
    }

    public function sommeMoisEnCours() {
        $stmt = $this->conn->query("SELECT COALESCE(SUM(montant),0) as total FROM {$this->table} WHERE statut = 'valide' AND MONTH(date_paiement) = MONTH(CURDATE()) AND YEAR(date_paiement) = YEAR(CURDATE())");
        return $stmt->fetch()['total'];
    }
    
    public function getPassParDemande($demandeId) {
        $stmt = $this->conn->prepare("SELECT id FROM pass_achats WHERE demande_id = :d AND statut = 'utilise' LIMIT 1");
        $stmt->execute([':d' => $demandeId]);
        return $stmt->fetch();
    }

}