<?php
require_once __DIR__ . '/../config/database.php';

class Abonnement {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getFormules() {
        $stmt = $this->conn->query("SELECT * FROM formules_abonnement ORDER BY prix ASC");
        return $stmt->fetchAll();
    }

    public function getFormuleById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM formules_abonnement WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function creerFormule($nom, $prix, $credits, $description) {
        $stmt = $this->conn->prepare("INSERT INTO formules_abonnement (nom, prix, nombre_credits, description) VALUES (:nom, :prix, :credits, :description)");
        return $stmt->execute([':nom' => $nom, ':prix' => $prix, ':credits' => $credits, ':description' => $description]);
    }

    public function modifierFormule($id, $prix, $credits, $description) {
        $stmt = $this->conn->prepare("UPDATE formules_abonnement SET prix = :prix, nombre_credits = :credits, description = :description WHERE id = :id");
        return $stmt->execute([':prix' => $prix, ':credits' => $credits, ':description' => $description, ':id' => $id]);
    }

    public function changerStatutFormule($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE formules_abonnement SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function getAbonnementsActifs() {
        $stmt = $this->conn->query(
            "SELECT ac.*, u.nom AS client_nom, u.telephone AS client_telephone, f.nom AS formule_nom, f.nombre_credits
             FROM abonnements_clients ac
             JOIN users u ON ac.client_id = u.id
             JOIN formules_abonnement f ON ac.formule_id = f.id
             WHERE ac.statut = 'actif'
             ORDER BY ac.date_fin ASC"
        );
        return $stmt->fetchAll();
    }

    public function compterActifsParFormule() {
        $stmt = $this->conn->query(
            "SELECT f.nom, COUNT(ac.id) as total 
             FROM formules_abonnement f 
             LEFT JOIN abonnements_clients ac ON ac.formule_id = f.id AND ac.statut = 'actif'
             GROUP BY f.id, f.nom"
        );
        return $stmt->fetchAll();
    }

    // Pass
    public function getPassTypes() {
        $stmt = $this->conn->query("SELECT pt.*, c.nom AS categorie_nom FROM pass_types pt LEFT JOIN categories c ON pt.categorie_id = c.id ORDER BY pt.prix ASC");
        return $stmt->fetchAll();
    }

    public function creerPassType($nom, $prix, $categorieId) {
        $stmt = $this->conn->prepare("INSERT INTO pass_types (nom, prix, categorie_id) VALUES (:nom, :prix, :categorie_id)");
        return $stmt->execute([':nom' => $nom, ':prix' => $prix, ':categorie_id' => $categorieId ?: null]);
    }

    public function changerStatutPassType($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE pass_types SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function compterPassVendus() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total, COALESCE(SUM(COALESCE(pa.montant_achat, pt.prix)),0) as montant FROM pass_achats pa JOIN pass_types pt ON pa.pass_type_id = pt.id");
        return $stmt->fetch();
    }

    public function creerDemandeSouscription($clientId, $formuleId) {
        $formule = $this->getFormuleById($formuleId);
        if (!$formule || (int) $formule['nombre_credits'] < 1) {
            throw new InvalidArgumentException('La formule d’abonnement sélectionnée est invalide.');
        }
        $reference = 'ABO-' . strtoupper(uniqid());

        $stmt = $this->conn->prepare(
            "INSERT INTO abonnements_clients
                (client_id, formule_id, montant_achat, credits_inclus, credits_restants, statut, reference_transaction)
             VALUES (:client_id, :formule_id, :montant_achat, :credits_inclus, :credits, 'en_attente', :reference)"
        );
        $stmt->execute([
            ':client_id' => $clientId,
            ':formule_id' => $formuleId,
            ':montant_achat' => $formule['prix'],
            ':credits_inclus' => $formule['nombre_credits'],
            ':credits' => $formule['nombre_credits'],
            ':reference' => $reference
        ]);
        return $reference;
    }

    public function getByReference($reference) {
        $stmt = $this->conn->prepare("SELECT * FROM abonnements_clients WHERE reference_transaction = :ref");
        $stmt->bindParam(':ref', $reference);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function activerParReference($reference) {
        $stmt = $this->conn->prepare(
            "UPDATE abonnements_clients 
            SET statut = 'actif', date_debut = CURDATE(), date_fin = DATE_ADD(CURDATE(), INTERVAL 1 MONTH),
                date_paiement = NOW()
            WHERE reference_transaction = :ref AND statut = 'en_attente'"
        );
        $stmt->execute([':ref' => $reference]);
        return $stmt->rowCount() === 1;
    }

    public function getActifParClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT ac.*, f.nom AS formule_nom, f.prix, f.nombre_credits, f.description
            FROM abonnements_clients ac
            JOIN formules_abonnement f ON ac.formule_id = f.id
            WHERE ac.client_id = :client_id AND ac.statut = 'actif' AND ac.date_fin >= CURDATE()
            ORDER BY ac.id DESC LIMIT 1"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getHistoriqueParClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT ac.id, ac.montant_achat, ac.credits_inclus, ac.credits_restants,
                    ac.statut, ac.date_debut, ac.date_fin, ac.date_creation, f.nom AS formule_nom
             FROM abonnements_clients ac
             JOIN formules_abonnement f ON f.id = ac.formule_id
             WHERE ac.client_id = :client_id
             ORDER BY ac.date_creation DESC, ac.id DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll();
    }

    public function getFormulesActives() {
        $stmt = $this->conn->query("SELECT * FROM formules_abonnement WHERE statut = 'active' ORDER BY prix ASC");
        return $stmt->fetchAll();
    }

    public function getCategoriesEligibles($formuleId) {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.nom, c.parent_id, p.nom AS parent_nom
            FROM formule_categories fc
            JOIN categories c ON fc.categorie_id = c.id
            LEFT JOIN categories p ON c.parent_id = p.id
            WHERE fc.formule_id = :formule_id"
        );
        $stmt->bindParam(':formule_id', $formuleId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function setCategoriesEligibles($formuleId, array $categorieIds) {
        $stmt = $this->conn->prepare("DELETE FROM formule_categories WHERE formule_id = :formule_id");
        $stmt->execute([':formule_id' => $formuleId]);

        if (empty($categorieIds)) return true; // aucune sélection = toutes catégories

        $stmtInsert = $this->conn->prepare("INSERT INTO formule_categories (formule_id, categorie_id) VALUES (:formule_id, :categorie_id)");
        foreach ($categorieIds as $catId) {
            $stmtInsert->execute([':formule_id' => $formuleId, ':categorie_id' => $catId]);
        }
        return true;
    }

    public function creerFormuleComplete($nom, $prix, $credits, $description, array $categorieIds) {
        $stmt = $this->conn->prepare("INSERT INTO formules_abonnement (nom, prix, nombre_credits, description) VALUES (:nom, :prix, :credits, :description)");
        $stmt->execute([':nom' => $nom, ':prix' => $prix, ':credits' => $credits, ':description' => $description]);
        $formuleId = $this->conn->lastInsertId();
        $this->setCategoriesEligibles($formuleId, $categorieIds);
        return $formuleId;
    }

    public function modifierFormuleComplete($id, $nom, $prix, $credits, $description, array $categorieIds) {
        $stmt = $this->conn->prepare("UPDATE formules_abonnement SET nom = :nom, prix = :prix, nombre_credits = :credits, description = :description WHERE id = :id");
        $stmt->execute([':nom' => $nom, ':prix' => $prix, ':credits' => $credits, ':description' => $description, ':id' => $id]);
        $this->setCategoriesEligibles($id, $categorieIds);
        return true;
    }

    public function estUtilisee($formuleId) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM abonnements_clients WHERE formule_id = :id");
        $stmt->bindParam(':id', $formuleId);
        $stmt->execute();
        return $stmt->fetch()['total'] > 0;
    }

    public function supprimerFormule($id) {
        if ($this->estUtilisee($id)) return false; // sécurité : on ne supprime jamais une formule ayant déjà des souscripteurs
        $stmt = $this->conn->prepare("DELETE FROM formules_abonnement WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function compterAbonnementsActifs() {
        $stmt = $this->conn->query("SELECT COUNT(*) as total FROM abonnements_clients WHERE statut = 'actif' AND date_fin >= CURDATE()");
        return (int) $stmt->fetch()['total'];
    }

    public function decrementerCredit($abonnementId) {
        $stmt = $this->conn->prepare(
            "UPDATE abonnements_clients SET credits_restants = credits_restants - 1
            WHERE id = :id AND statut = 'actif' AND credits_restants > 0"
        );
        $stmt->execute([':id' => $abonnementId]);
        return $stmt->rowCount() > 0; // false si déjà à 0 : protège contre une double consommation
    }

    // ===== Pass : cycle d'achat complet =====
    public function creerAchatPass($clientId, $passTypeId) {
        $stmt = $this->conn->prepare("SELECT prix FROM pass_types WHERE id = :id AND statut = 'actif'");
        $stmt->execute([':id' => $passTypeId]);
        $prix = $stmt->fetchColumn();
        if ($prix === false) {
            throw new InvalidArgumentException('Le pass sélectionné est indisponible.');
        }

        $reference = 'PASS-' . strtoupper(uniqid());
        $stmt = $this->conn->prepare(
            "INSERT INTO pass_achats (client_id, pass_type_id, montant_achat, statut, reference_transaction)
             VALUES (:client_id, :pass_type_id, :montant_achat, 'en_attente', :reference)"
        );
        $stmt->execute([
            ':client_id' => $clientId,
            ':pass_type_id' => $passTypeId,
            ':montant_achat' => $prix,
            ':reference' => $reference,
        ]);
        return $reference;
    }

    public function getPassAchatByReference($reference) {
        $stmt = $this->conn->prepare("SELECT * FROM pass_achats WHERE reference_transaction = :ref");
        $stmt->bindParam(':ref', $reference);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function activerPassParReference($reference) {
        $stmt = $this->conn->prepare(
            "UPDATE pass_achats
             SET statut = 'disponible', date_paiement = NOW()
             WHERE reference_transaction = :ref AND statut = 'en_attente'"
        );
        $stmt->execute([':ref' => $reference]);
        return $stmt->rowCount() === 1;
    }

    public function getPassDisponiblesClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT pa.*, pt.nom, COALESCE(pa.montant_achat, pt.prix) AS prix, pt.categorie_id
            FROM pass_achats pa JOIN pass_types pt ON pa.pass_type_id = pt.id
            WHERE pa.client_id = :client_id AND pa.statut = 'disponible'
            ORDER BY pa.date_achat ASC"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getHistoriquePassClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT pa.*, pt.nom, COALESCE(pa.montant_achat, pt.prix) AS prix, d.numero_dossier
             FROM pass_achats pa
             JOIN pass_types pt ON pt.id = pa.pass_type_id
             LEFT JOIN demandes d ON d.id = pa.demande_id AND d.client_id = pa.client_id
             WHERE pa.client_id = :client_id
             ORDER BY pa.date_achat DESC, pa.id DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll();
    }

    public function marquerPassUtilise($passAchatId, $demandeId) {
        $stmt = $this->conn->prepare(
            "UPDATE pass_achats SET statut = 'utilise', demande_id = :demande_id, date_utilisation = NOW() WHERE id = :id AND statut = 'disponible'"
        );
        $stmt->execute([':demande_id' => $demandeId, ':id' => $passAchatId]);
        return $stmt->rowCount() > 0;
    }

}