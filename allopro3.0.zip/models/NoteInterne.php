<?php
require_once __DIR__ . '/../config/database.php';

class NoteInterne {
    private $conn;
    private $table = 'notes_internes_client';

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function create($clientId, $conseillerId, $contenu) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (client_id, conseiller_id, contenu) VALUES (:client_id, :conseiller_id, :contenu)"
        );
        return $stmt->execute([':client_id' => $clientId, ':conseiller_id' => $conseillerId, ':contenu' => $contenu]);
    }

    public function getByClient($clientId) {
        $stmt = $this->conn->prepare(
            "SELECT n.*, u.nom AS conseiller_nom 
             FROM {$this->table} n
             JOIN users u ON n.conseiller_id = u.id
             WHERE n.client_id = :client_id
             ORDER BY n.date_creation DESC"
        );
        $stmt->bindParam(':client_id', $clientId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function creerNoteAutomatiqueCreneau(
        int $clientId,
        int $demandeId,
        int $interventionId,
        string $contenu
    ): void {
        $stmt = $this->conn->prepare(
            "INSERT INTO notes_automatiques_interventions
                (client_id, demande_id, intervention_id, contenu)
             VALUES (:client_id, :demande_id, :intervention_id, :contenu)"
        );
        $stmt->execute([
            ':client_id' => $clientId,
            ':demande_id' => $demandeId,
            ':intervention_id' => $interventionId,
            ':contenu' => $contenu,
        ]);
    }

    public function getNotesAutomatiquesByClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT contenu, date_creation, 'Système' AS conseiller_nom
             FROM notes_automatiques_interventions
             WHERE client_id = :client_id
             ORDER BY date_creation DESC, id DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}