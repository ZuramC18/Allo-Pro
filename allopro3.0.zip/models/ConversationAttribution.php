<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Parametre.php';
require_once __DIR__ . '/../includes/audit.php';

class ConversationAttribution {
    private const PRESENCE_RECENTE_MINUTES = 2;
    private const DELAI_REATTRIBUTION_MINUTES = 5;
    private const DELAI_PRIORITE_ABONNEMENT_MINUTES = 30;
    private const VERROU = 'allopro_conversation_attribution';

    private PDO $conn;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function traiterFile(): array {
        $verrou = $this->conn->query("SELECT GET_LOCK('" . self::VERROU . "', 0)")->fetchColumn();
        if ($verrou === false || $verrou === null) {
            throw new RuntimeException('Le verrou de traitement des conversations n’a pas pu être obtenu.');
        }
        if ((int) $verrou !== 1) {
            return ['active' => false, 'attribuees' => [], 'transferees' => 0];
        }

        try {
            $this->conn->beginTransaction();
            $this->initialiserHorodatagesEnAttente();
            $transferees = $this->transfererConversationsSansReponse();
            $attribuees = [];

            if ((new Parametre())->attributionAutomatiqueActive()) {
                $parametres = new Parametre();
                $limite = $parametres->getLimiteClientsParConseiller();

                while (true) {
                    $conversation = $this->prochaineConversationEnAttente();
                    if (!$conversation) {
                        break;
                    }

                    $conseiller = $this->prochainConseillerDisponible($limite);
                    if (!$conseiller) {
                        break;
                    }

                    $affecter = $this->conn->prepare(
                        "UPDATE users
                         SET conseiller_assigne_id = :conseiller_id,
                             conversation_en_attente_depuis = NULL
                         WHERE id = :client_id AND role = 'client'
                           AND conversation_statut = 'ouverte'
                           AND conseiller_assigne_id IS NULL"
                    );
                    $affecter->execute([
                        ':conseiller_id' => (int) $conseiller['id'],
                        ':client_id' => (int) $conversation['id'],
                    ]);
                    if ($affecter->rowCount() !== 1) {
                        continue;
                    }

                    $affectees = [
                        'client_id' => (int) $conversation['id'],
                        'conseiller_id' => (int) $conseiller['id'],
                    ];
                    $attribuees[] = $affectees;
                    journaliser(
                        'conversation.attribuee',
                        'compte',
                        $affectees['client_id'],
                        null,
                        'File automatique attribuée au conseiller ID ' . $affectees['conseiller_id'],
                        ACTEUR_SYSTEME
                    );
                }
            }

            $this->conn->commit();
            return ['active' => true, 'attribuees' => $attribuees, 'transferees' => $transferees];
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        } finally {
            $liberer = $this->conn->prepare("SELECT RELEASE_LOCK(:nom)");
            $liberer->execute([':nom' => self::VERROU]);
        }
    }

    private function initialiserHorodatagesEnAttente(): void {
        $this->conn->exec(
            "UPDATE users c
             SET c.conversation_en_attente_depuis = COALESCE(
                 c.conversation_en_attente_depuis,
                 (
                     SELECT MIN(m.date_creation)
                     FROM messages m
                     WHERE m.client_id = c.id AND m.expediteur_type = 'client'
                 ),
                 NOW()
             )
             WHERE c.role = 'client' AND c.statut = 'actif'
               AND c.conversation_statut = 'ouverte'
               AND c.conseiller_assigne_id IS NULL
               AND EXISTS (SELECT 1 FROM messages msg WHERE msg.client_id = c.id)"
        );
    }

    private function transfererConversationsSansReponse(): int {
        $candidats = $this->conn->query(
            "SELECT c.id, c.conseiller_assigne_id,
                    (SELECT m.id FROM messages m
                     WHERE m.client_id = c.id AND m.expediteur_type = 'client'
                     ORDER BY m.id DESC LIMIT 1) AS dernier_message_client_id,
                    (SELECT m.date_creation FROM messages m
                     WHERE m.client_id = c.id AND m.expediteur_type = 'client'
                     ORDER BY m.id DESC LIMIT 1) AS dernier_message_client_date,
                    (SELECT m.id FROM messages m
                     WHERE m.client_id = c.id AND m.expediteur_type = 'conseiller'
                     ORDER BY m.id DESC LIMIT 1) AS derniere_reponse_conseiller_id
             FROM users c
             JOIN users conseiller ON conseiller.id = c.conseiller_assigne_id
             WHERE c.role = 'client' AND c.statut = 'actif'
               AND c.conversation_statut = 'ouverte'
               AND conseiller.role = 'conseiller'
               AND (conseiller.statut <> 'actif'
                    OR conseiller.presence_status <> 'online'
                    OR conseiller.presence_last_seen IS NULL
                    OR conseiller.presence_last_seen < DATE_SUB(NOW(), INTERVAL " . self::PRESENCE_RECENTE_MINUTES . " MINUTE))
             HAVING dernier_message_client_id IS NOT NULL
                AND dernier_message_client_id > COALESCE(derniere_reponse_conseiller_id, 0)
                AND dernier_message_client_date <= DATE_SUB(NOW(), INTERVAL " . self::DELAI_REATTRIBUTION_MINUTES . " MINUTE)"
        )->fetchAll(PDO::FETCH_ASSOC);

        $transferees = 0;
        $mettreEnFile = $this->conn->prepare(
            "UPDATE users
             SET conseiller_assigne_id = NULL,
                 conversation_en_attente_depuis = NOW()
             WHERE id = :client_id AND role = 'client'
               AND conseiller_assigne_id = :conseiller_id
               AND conversation_statut = 'ouverte'
               AND NOT EXISTS (
                   SELECT 1 FROM messages reponse
                   WHERE reponse.client_id = :client_id_reponse
                     AND reponse.expediteur_type = 'conseiller'
                     AND reponse.id > :dernier_message_client_id
               )
               AND :dernier_message_client_id_verification = (
                   SELECT MAX(message.id)
                   FROM messages message
                   WHERE message.client_id = :client_id_verification
                     AND message.expediteur_type = 'client'
               )"
        );

        foreach ($candidats as $candidat) {
            $mettreEnFile->execute([
                ':client_id' => (int) $candidat['id'],
                ':conseiller_id' => (int) $candidat['conseiller_assigne_id'],
                ':client_id_reponse' => (int) $candidat['id'],
                ':dernier_message_client_id' => (int) $candidat['dernier_message_client_id'],
                ':dernier_message_client_id_verification' => (int) $candidat['dernier_message_client_id'],
                ':client_id_verification' => (int) $candidat['id'],
            ]);
            if ($mettreEnFile->rowCount() === 1) {
                $transferees++;
                journaliser(
                    'conversation.reassignee',
                    'compte',
                    (int) $candidat['id'],
                    null,
                    'Conversation remise en file après absence du conseiller ID ' . (int) $candidat['conseiller_assigne_id'],
                    ACTEUR_SYSTEME
                );
            }
        }

        return $transferees;
    }

    private function prochaineConversationEnAttente(): ?array {
        $stmt = $this->conn->query(
            "SELECT c.id
             FROM users c
             WHERE c.role = 'client' AND c.statut = 'actif'
               AND c.conversation_statut = 'ouverte'
               AND c.conseiller_assigne_id IS NULL
               AND c.conversation_en_attente_depuis IS NOT NULL
             ORDER BY
               CASE WHEN EXISTS (
                   SELECT 1 FROM abonnements_clients ac
                   WHERE ac.client_id = c.id AND ac.statut = 'actif'
                     AND ac.date_fin >= CURDATE()
               )
               THEN c.conversation_en_attente_depuis
               ELSE DATE_ADD(c.conversation_en_attente_depuis, INTERVAL " . self::DELAI_PRIORITE_ABONNEMENT_MINUTES . " MINUTE)
               END ASC,
               c.conversation_en_attente_depuis ASC, c.id ASC
             LIMIT 1
             FOR UPDATE"
        );
        $conversation = $stmt->fetch(PDO::FETCH_ASSOC);
        return $conversation ?: null;
    }

    private function prochainConseillerDisponible(int $limite): ?array {
        $sql = "SELECT c.id,
                       (SELECT COUNT(*) FROM users client
                        WHERE client.role = 'client'
                          AND client.conseiller_assigne_id = c.id
                          AND client.conversation_statut = 'ouverte') AS charge
                FROM users c
                WHERE c.role = 'conseiller' AND c.statut = 'actif'
                  AND c.presence_status = 'online'
                  AND c.presence_last_seen >= DATE_SUB(NOW(), INTERVAL " . self::PRESENCE_RECENTE_MINUTES . " MINUTE)";
        if ($limite > 0) {
            $sql .= ' HAVING charge < :limite';
        }
        $sql .= ' ORDER BY charge ASC, c.id ASC LIMIT 1 FOR UPDATE';
        $stmt = $this->conn->prepare($sql);
        if ($limite > 0) {
            $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        }
        $stmt->execute();
        $conseiller = $stmt->fetch(PDO::FETCH_ASSOC);
        return $conseiller ?: null;
    }
}
