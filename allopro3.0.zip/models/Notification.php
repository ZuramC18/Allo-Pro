<?php
require_once __DIR__ . '/../config/database.php';

class Notification {
    private $conn;
    private $table = 'notifications';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($userId, $message, $lien = null) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (user_id, message, lien) VALUES (:user_id, :message, :lien)"
        );
        return $stmt->execute([':user_id' => $userId, ':message' => $message, ':lien' => $lien]);
    }

    public function getNonLues($userId) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table} WHERE user_id = :user_id AND lu = 0 ORDER BY date_creation DESC"
        );
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getDernieresPourUtilisateur(int $userId, int $limite = 5): array {
        $limite = max(1, min(5, $limite));
        $stmt = $this->conn->prepare(
            "SELECT n.id, n.message, n.lien, n.lu, n.date_creation,
                    (n.message LIKE 'Appel entrant —%') AS appel_entrant
             FROM {$this->table} n
             WHERE n.user_id = :user_id
               AND (
                   n.message NOT LIKE 'Appel entrant —%'
                   OR EXISTS (
                       SELECT 1
                       FROM messagerie_appels_web a
                       WHERE n.lien = CONCAT('/allopro/views/client/messagerie.php?appel_id=', a.id)
                         AND a.client_id = n.user_id
                         AND a.statut = 'sonnerie'
                         AND a.date_creation >= DATE_SUB(NOW(), INTERVAL 35 SECOND)
                   )
               )
             ORDER BY n.message LIKE 'Appel entrant —%' DESC, n.date_creation DESC, n.id DESC
             LIMIT :limite"
        );
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getToutesPourUtilisateur(int $userId): array {
        $stmt = $this->conn->prepare(
            "SELECT id, message, lien, lu, date_creation,
                    (message LIKE 'Appel entrant —%') AS appel_entrant
             FROM {$this->table}
             WHERE user_id = :user_id
             ORDER BY date_creation DESC, id DESC"
        );
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function compterNonLues(int $userId): int {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*)
             FROM {$this->table} n
             WHERE n.user_id = :user_id AND n.lu = 0
               AND (
                   n.message NOT LIKE 'Appel entrant —%'
                   OR EXISTS (
                       SELECT 1
                       FROM messagerie_appels_web a
                       WHERE n.lien = CONCAT('/allopro/views/client/messagerie.php?appel_id=', a.id)
                         AND a.client_id = n.user_id
                         AND a.statut = 'sonnerie'
                         AND a.date_creation >= DATE_SUB(NOW(), INTERVAL 35 SECOND)
                   )
               )"
        );
        $stmt->execute([':user_id' => $userId]);
        return (int) $stmt->fetchColumn();
    }

    public function marquerLue(int $id, int $userId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET lu = 1 WHERE id = :id AND user_id = :user_id"
        );
        return $stmt->execute([':id' => $id, ':user_id' => $userId]);
    }
}