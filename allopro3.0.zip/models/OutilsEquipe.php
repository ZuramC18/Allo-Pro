<?php
require_once __DIR__ . '/../config/database.php';

class OutilsEquipe {
    private PDO $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getCollegues(): array {
        $stmt = $this->conn->query(
            "SELECT id, nom, role FROM users
             WHERE statut = 'actif' AND role IN ('admin', 'conseiller', 'coordinateur', 'finance', 'qualite')
             ORDER BY nom, id"
        );
        return $stmt->fetchAll();
    }

    public function creerTache(string $titre, string $description, int $assigneA, ?string $echeance, int $auteur): bool {
        $stmt = $this->conn->prepare(
            "INSERT INTO outils_equipe_taches (titre, description, assigne_a, cree_par, date_echeance)
             SELECT :titre, :description, u.id, :auteur, :echeance
             FROM users u
             WHERE u.id = :assigne_a AND u.statut = 'actif'
               AND u.role IN ('admin', 'conseiller', 'coordinateur', 'finance', 'qualite')"
        );
        $stmt->execute([
            ':titre' => $titre, ':description' => $description ?: null, ':assigne_a' => $assigneA,
            ':auteur' => $auteur, ':echeance' => $echeance,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function getTachesPourUtilisateur(int $userId, bool $assigneesSeulement = false): array {
        $sql = "SELECT t.*, assigne.nom AS assigne_nom, assigne.role AS assigne_role,
                       auteur.nom AS auteur_nom,
                       (t.statut = 'a_faire' AND t.date_echeance < CURDATE()) AS en_retard
                FROM outils_equipe_taches t
                JOIN users assigne ON assigne.id = t.assigne_a
                JOIN users auteur ON auteur.id = t.cree_par
                WHERE (t.assigne_a = :assigne_a";
        if (!$assigneesSeulement) {
            $sql .= " OR t.cree_par = :cree_par";
        }
        $sql .= ") ORDER BY (t.statut = 'a_faire') DESC, t.date_echeance IS NULL, t.date_echeance, t.date_creation DESC";
        $stmt = $this->conn->prepare($sql);
        $params = [':assigne_a' => $userId];
        if (!$assigneesSeulement) {
            $params[':cree_par'] = $userId;
        }
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function terminerTache(int $id, int $assigneA): bool {
        $stmt = $this->conn->prepare(
            "UPDATE outils_equipe_taches
             SET statut = 'terminee', date_completion = NOW()
             WHERE id = :id AND assigne_a = :assigne_a AND statut = 'a_faire'"
        );
        return $stmt->execute([':id' => $id, ':assigne_a' => $assigneA]) && $stmt->rowCount() === 1;
    }

    public function reouvrirTache(int $id, int $assigneA): bool {
        $stmt = $this->conn->prepare(
            "UPDATE outils_equipe_taches
             SET statut = 'a_faire', date_completion = NULL
             WHERE id = :id AND assigne_a = :assigne_a AND statut = 'terminee'"
        );
        return $stmt->execute([':id' => $id, ':assigne_a' => $assigneA]) && $stmt->rowCount() === 1;
    }

    public function annulerTache(int $id, int $auteurId): bool {
        $stmt = $this->conn->prepare(
            "DELETE FROM outils_equipe_taches
             WHERE id = :id AND cree_par = :auteur_id AND statut = 'a_faire'"
        );
        return $stmt->execute([':id' => $id, ':auteur_id' => $auteurId]) && $stmt->rowCount() === 1;
    }

    public function getTachesAujourdhui(int $userId): array {
        $stmt = $this->conn->prepare(
            "SELECT t.id, t.titre, t.date_echeance, t.statut, t.assigne_a,
                    (t.date_echeance < CURDATE()) AS en_retard, u.nom AS assigne_nom
             FROM outils_equipe_taches t JOIN users u ON u.id = t.assigne_a
             WHERE t.assigne_a = :user_id AND t.statut = 'a_faire'
               AND (t.date_echeance IS NULL OR t.date_echeance <= CURDATE())
             ORDER BY t.date_echeance IS NULL, t.date_echeance, t.id DESC LIMIT 8"
        );
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll();
    }

    public function getResumeTachesAujourdhui(int $userId): array {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(date_echeance < CURDATE()), 0) AS en_retard
             FROM outils_equipe_taches
             WHERE assigne_a = :user_id AND statut = 'a_faire'
               AND (date_echeance IS NULL OR date_echeance <= CURDATE())"
        );
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetch();
    }

    public function compterNouvellesDemandes(): int {
        return (int) $this->conn->query(
            "SELECT COUNT(*) FROM demandes WHERE statut = 'nouvelle'"
        )->fetchColumn();
    }

    public function rechercher(string $terme): array {
        $terme = trim($terme);
        $termes = preg_split('/\s+/u', $terme, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (preg_match('/^[+\d()\s.-]+$/u', $terme) === 1) {
            $chiffresTelephone = preg_replace('/\D+/u', '', $terme) ?? '';
            if (mb_strlen($chiffresTelephone) >= 6) {
                $termes = [$chiffresTelephone];
            }
        }
        $termes = array_slice($termes, 0, 8);
        if (!$termes) {
            return [];
        }
        $construireFiltre = static function (array $colonnes, string $prefixe) use ($termes): array {
            $conditions = [];
            $parametres = [];
            foreach ($termes as $index => $mot) {
                $alternatives = [];
                foreach ($colonnes as $colonneIndex => $colonne) {
                    $texteRecherche = $mot;
                    if (str_starts_with($colonne, 'REPLACE(')) {
                        $texteRecherche = preg_replace('/\D+/u', '', $mot) ?? '';
                        if (mb_strlen($texteRecherche) < 4) {
                            continue;
                        }
                    }
                    $nom = ':' . $prefixe . $index . '_' . $colonneIndex;
                    $alternatives[] = $colonne . ' LIKE ' . $nom . " ESCAPE '='";
                    $parametres[$nom] = '%' . strtr($texteRecherche, ['=' => '==', '%' => '=%', '_' => '=_']) . '%';
                }
                if (!$alternatives) {
                    $alternatives[] = '1 = 0';
                }
                $conditions[] = '(' . implode(' OR ', $alternatives) . ')';
            }
            return [implode(' AND ', $conditions), $parametres];
        };
        [$filtreDossiers, $paramsDossiers] = $construireFiltre([
            'd.numero_dossier', 'u.nom', 'u.prenom', "CONCAT_WS(' ', u.prenom, u.nom)",
            'u.email', "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(u.telephone, ''), ' ', ''), '+', ''), '-', ''), '(', ''), ')', '')",
            'd.description', 'c.nom',
        ], 'd');
        $stmt = $this->conn->prepare(
            "SELECT 'dossier' AS type, d.numero_dossier AS reference, d.numero_dossier,
                    d.id AS id, d.client_id,
                    CONCAT_WS(' ', u.prenom, u.nom) AS client, u.telephone, u.email,
                    c.nom AS sujet, d.statut, d.date_creation
             FROM demandes d
             JOIN users u ON u.id = d.client_id
             JOIN categories c ON c.id = d.categorie_id
             WHERE $filtreDossiers
             ORDER BY (d.numero_dossier = :exact_dossier) DESC, d.date_creation DESC LIMIT 30"
        );
        $stmt->execute($paramsDossiers + [':exact_dossier' => $terme]);
        $dossiers = $stmt->fetchAll();

        [$filtreTickets, $paramsTickets] = $construireFiltre([
            "CAST(t.id AS CHAR)", 't.motif', 'd.numero_dossier', 'u.nom', 'u.prenom',
            "CONCAT_WS(' ', u.prenom, u.nom)", 'u.email',
            "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(u.telephone, ''), ' ', ''), '+', ''), '-', ''), '(', ''), ')', '')",
        ], 't');
        $idTicketExact = preg_match('/^SAV-(\d+)$/i', $terme, $correspondanceTicket) === 1
            ? (string) (int) $correspondanceTicket[1]
            : (preg_match('/^\d+$/', $terme) === 1 ? $terme : '');
        $stmt = $this->conn->prepare(
            "SELECT 'ticket' AS type, CONCAT('SAV-', t.id) AS reference, d.numero_dossier,
                    d.id AS id, d.client_id,
                    CONCAT_WS(' ', u.prenom, u.nom) AS client, u.telephone, u.email,
                    t.motif AS sujet, t.statut, t.date_creation
             FROM tickets_sav t
             JOIN demandes d ON d.id = t.demande_id
             JOIN users u ON u.id = d.client_id
             WHERE ($filtreTickets OR CAST(t.id AS CHAR) = :ticket_id_exact)
             ORDER BY (CAST(t.id AS CHAR) = :exact_ticket) DESC, t.date_creation DESC LIMIT 30"
        );
        $stmt->execute($paramsTickets + [
            ':ticket_id_exact' => $idTicketExact,
            ':exact_ticket' => $idTicketExact,
        ]);
        $tickets = $stmt->fetchAll();

        [$filtreClients, $paramsClients] = $construireFiltre([
            'u.nom', 'u.prenom', "CONCAT_WS(' ', u.prenom, u.nom)", 'u.email',
            "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(u.telephone, ''), ' ', ''), '+', ''), '-', ''), '(', ''), ')', '')",
        ], 'c');
        $rechercheIdClient = preg_match('/^(?:CLIENT-|#)?(\d+)$/i', $terme, $correspondance) === 1
            ? (int) $correspondance[1]
            : 0;
        $stmt = $this->conn->prepare(
            "SELECT 'client' AS type, CONCAT('CLIENT-', u.id) AS reference,
                    NULL AS numero_dossier, u.id AS id, u.id AS client_id,
                    CONCAT_WS(' ', u.prenom, u.nom) AS client, u.telephone, u.email,
                    'Profil client' AS sujet, u.statut, u.date_creation
             FROM users u
             WHERE u.role = 'client'
               AND ($filtreClients OR (:client_id > 0 AND u.id = :exact_client_id))
             ORDER BY (u.id = :rank_client_id) DESC, u.date_creation DESC LIMIT 20"
        );
        $stmt->execute($paramsClients + [
            ':client_id' => $rechercheIdClient,
            ':exact_client_id' => $rechercheIdClient,
            ':rank_client_id' => $rechercheIdClient,
        ]);
        $clients = $stmt->fetchAll();
        return array_merge($clients, $dossiers, $tickets);
    }

    public function getFicheClient(int $clientId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT id, prenom, nom, email, telephone, photo_profil, avatar_initiales,
                    statut, date_creation, email_verifie
             FROM users WHERE id = :id AND role = 'client' LIMIT 1"
        );
        $stmt->execute([':id' => $clientId]);
        return $stmt->fetch();
    }

    public function getAdressesClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT libelle, details, quartier, ville, adresse_google
             FROM adresses
             WHERE user_id = :client_id AND COALESCE(supprimee, 0) = 0
             ORDER BY id DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll();
    }

    public function getDossiersClient(int $clientId): array {
        $stmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, d.description, d.urgence, d.statut,
                    d.date_creneau_souhaite, d.heure_creneau_souhaitee, d.date_creation,
                    d.site_b2b_id, c.nom AS categorie,
                    a.libelle AS adresse_libelle, a.details AS adresse_details,
                    a.quartier AS adresse_quartier, a.ville AS adresse_ville,
                    (SELECT i.statut FROM interventions i
                     WHERE i.demande_id = d.id ORDER BY i.id DESC LIMIT 1) AS intervention_statut,
                    (SELECT i.technicien_nom FROM interventions i
                     WHERE i.demande_id = d.id ORDER BY i.id DESC LIMIT 1) AS technicien_nom,
                    (SELECT p.statut FROM paiements p
                     WHERE p.demande_id = d.id ORDER BY p.id DESC LIMIT 1) AS paiement_statut
             FROM demandes d
             LEFT JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN adresses a ON a.id = d.adresse_id
             WHERE d.client_id = :client_id
             ORDER BY d.date_creation DESC, d.id DESC"
        );
        $stmt->execute([':client_id' => $clientId]);
        return $stmt->fetchAll();
    }

    public function getDossier(string $numero): array|false {
        $stmt = $this->conn->prepare(
            "SELECT d.id, d.numero_dossier, u.nom AS client_nom
             FROM demandes d JOIN users u ON u.id = d.client_id
             WHERE d.numero_dossier = :numero LIMIT 1"
        );
        $stmt->execute([':numero' => $numero]);
        return $stmt->fetch();
    }

    public function creerPassation(int $demandeId, int $auteurId, string $note, string $prochaineAction): bool {
        $stmt = $this->conn->prepare(
            "INSERT INTO passations_demandes (demande_id, auteur_id, note, prochaine_action)
             SELECT d.id, :auteur_id, :note, :prochaine_action FROM demandes d WHERE d.id = :demande_id"
        );
        $stmt->execute([
            ':demande_id' => $demandeId, ':auteur_id' => $auteurId,
            ':note' => $note, ':prochaine_action' => $prochaineAction,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function getPassations(?int $demandeId = null): array {
        $sql = "SELECT p.*, d.numero_dossier, u.nom AS auteur_nom
                FROM passations_demandes p
                JOIN demandes d ON d.id = p.demande_id
                JOIN users u ON u.id = p.auteur_id";
        if ($demandeId !== null) {
            $sql .= " WHERE p.demande_id = :demande_id";
        }
        $sql .= " ORDER BY p.date_creation DESC, p.id DESC LIMIT 50";
        $stmt = $this->conn->prepare($sql);
        if ($demandeId !== null) {
            $stmt->execute([':demande_id' => $demandeId]);
        } else {
            $stmt->execute();
        }
        return $stmt->fetchAll();
    }

    public function getAgenda(): array {
        $stmt = $this->conn->query(
            "SELECT * FROM (
                SELECT d.id AS source_id, 'intervention' AS source,
                       d.numero_dossier, u.nom AS client_nom, c.nom AS categorie,
                       i.date_creneau_planifie AS date_creneau,
                       i.heure_creneau_planifie AS heure_creneau
                FROM interventions i
                JOIN demandes d ON d.id = i.demande_id
                JOIN users u ON u.id = d.client_id
                JOIN categories c ON c.id = d.categorie_id
                WHERE i.statut = 'acceptee'
                  AND i.date_creneau_planifie IS NOT NULL
                  AND i.heure_creneau_planifie IS NOT NULL
                  AND i.date_creneau_planifie >= CURDATE()
                UNION ALL
                SELECT d.id AS source_id, 'demande' AS source,
                       d.numero_dossier, u.nom AS client_nom, c.nom AS categorie,
                       d.date_creneau_souhaite AS date_creneau,
                       d.heure_creneau_souhaitee AS heure_creneau
                FROM demandes d
                JOIN users u ON u.id = d.client_id
                JOIN categories c ON c.id = d.categorie_id
                WHERE d.statut = 'nouvelle'
                  AND d.date_creneau_souhaite IS NOT NULL
                  AND d.heure_creneau_souhaitee IS NOT NULL
                  AND d.date_creneau_souhaite >= CURDATE()
                  AND NOT EXISTS (
                      SELECT 1 FROM interventions i
                      WHERE i.demande_id = d.id AND i.statut = 'acceptee'
                        AND i.date_creneau_planifie = d.date_creneau_souhaite
                        AND i.heure_creneau_planifie = d.heure_creneau_souhaitee
                  )
             ) agenda
             ORDER BY date_creneau, heure_creneau, numero_dossier"
        );
        return $stmt->fetchAll();
    }

    public function getProcedures(): array {
        return $this->conn->query(
            "SELECT p.*, u.nom AS auteur_nom FROM procedures_equipe p
             JOIN users u ON u.id = p.auteur_id
             WHERE p.publie = 1 ORDER BY p.titre, p.id"
        )->fetchAll();
    }

    public function getProcedure(int $id): array|false {
        $stmt = $this->conn->prepare("SELECT * FROM procedures_equipe WHERE id = :id AND publie = 1");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    public function enregistrerProcedure(string $titre, string $contenu, int $auteurId, ?int $id = null): bool {
        if ($id === null) {
            $stmt = $this->conn->prepare(
                "INSERT INTO procedures_equipe (titre, contenu, auteur_id, modifie_par)
                 VALUES (:titre, :contenu, :auteur_id, :modifie_par)"
            );
            return $stmt->execute([
                ':titre' => $titre, ':contenu' => $contenu, ':auteur_id' => $auteurId, ':modifie_par' => $auteurId,
            ]);
        }
        $autorisee = $this->conn->prepare(
            "SELECT id FROM procedures_equipe
             WHERE id = :id AND (auteur_id = :auteur_id OR EXISTS (
                 SELECT 1 FROM users WHERE id = :admin_id AND role = 'admin'
             ))"
        );
        $autorisee->execute([':id' => $id, ':auteur_id' => $auteurId, ':admin_id' => $auteurId]);
        if (!$autorisee->fetchColumn()) {
            return false;
        }
        $stmt = $this->conn->prepare(
            "UPDATE procedures_equipe SET titre = :titre, contenu = :contenu, modifie_par = :modifie_par
             WHERE id = :id"
        );
        $stmt->execute([
            ':titre' => $titre, ':contenu' => $contenu, ':modifie_par' => $auteurId,
            ':id' => $id,
        ]);
        return true;
    }

    public function creerAnnonce(string $titre, string $contenu, int $auteurId): bool {
        $stmt = $this->conn->prepare(
            "INSERT INTO annonces_equipe (titre, contenu, auteur_id) VALUES (:titre, :contenu, :auteur_id)"
        );
        return $stmt->execute([':titre' => $titre, ':contenu' => $contenu, ':auteur_id' => $auteurId]);
    }

    public function marquerAnnoncesLues(int $userId): void {
        $stmt = $this->conn->prepare(
            "INSERT IGNORE INTO annonces_equipe_lectures (annonce_id, user_id)
             SELECT a.id, :user_id FROM annonces_equipe a"
        );
        $stmt->execute([':user_id' => $userId]);
    }

    public function compterAnnoncesNonLues(int $userId): int {
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) FROM annonces_equipe a
             WHERE NOT EXISTS (
                 SELECT 1 FROM annonces_equipe_lectures l
                 WHERE l.annonce_id = a.id AND l.user_id = :user_id
             )"
        );
        $stmt->execute([':user_id' => $userId]);
        return (int) $stmt->fetchColumn();
    }

    public function getAnnonces(int $userId): array {
        $stmt = $this->conn->prepare(
            "SELECT a.*, u.nom AS auteur_nom, l.date_lecture,
                    (SELECT COUNT(*) FROM annonces_equipe_lectures lr WHERE lr.annonce_id = a.id) AS nombre_lectures
             FROM annonces_equipe a
             JOIN users u ON u.id = a.auteur_id
             LEFT JOIN annonces_equipe_lectures l ON l.annonce_id = a.id AND l.user_id = :user_id
             ORDER BY a.date_creation DESC, a.id DESC LIMIT 30"
        );
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll();
    }

    public function getLecturesAnnonce(int $annonceId): array {
        $stmt = $this->conn->prepare(
            "SELECT u.nom, u.role, l.date_lecture
             FROM annonces_equipe_lectures l JOIN users u ON u.id = l.user_id
             WHERE l.annonce_id = :annonce_id
               AND u.role IN ('admin', 'conseiller', 'coordinateur', 'finance', 'qualite')
             ORDER BY l.date_lecture DESC, u.nom"
        );
        $stmt->execute([':annonce_id' => $annonceId]);
        return $stmt->fetchAll();
    }
}
