<?php
require_once __DIR__ . '/../config/database.php';

class ActiviteConseiller {
    private PDO $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public static function enregistrer(string $type, int $conseillerId, string $cible, ?string $detail = null): void {
        if ($type !== 'presence') {
            throw new InvalidArgumentException('Type d’activité conseiller invalide.');
        }
        try {
            $stmt = (new Database())->getConnection()->prepare(
                "INSERT INTO activites_conseillers (conseiller_id, type, cible, detail)
                 SELECT id, :type, :cible, :detail
                 FROM users
                 WHERE id = :conseiller_id AND role IN ('conseiller', 'coordinateur', 'finance')"
            );
            $stmt->execute([
                ':conseiller_id' => $conseillerId,
                ':type' => $type,
                ':cible' => mb_substr($cible, 0, 120),
                ':detail' => $detail !== null ? mb_substr($detail, 0, 255) : null,
            ]);
        } catch (PDOException $exception) {
            error_log('Journal d’activité conseiller indisponible : ' . $exception->getMessage());
        }
    }

    public static function ajouterTempsPresence(PDO $conn, int $conseillerId, string $statut, string $debut, string $fin): void {
        if (!in_array($statut, ['online', 'pause'], true)) {
            return;
        }

        $debutPresence = new DateTimeImmutable($debut);
        $finPresence = new DateTimeImmutable($fin);
        if ($finPresence <= $debutPresence) {
            return;
        }

        $finMaximale = $debutPresence->modify('+90 seconds');
        if ($finPresence > $finMaximale) {
            $finPresence = $finMaximale;
        }
        $colonne = $statut === 'online' ? 'secondes_en_ligne' : 'secondes_en_pause';
        $requeteJour = $conn->prepare(
            "INSERT INTO temps_presence_conseillers
                (conseiller_id, date_presence, secondes_en_ligne, secondes_en_pause)
             VALUES (:conseiller_id, :date_presence, :secondes_en_ligne, :secondes_en_pause)
             ON DUPLICATE KEY UPDATE $colonne = $colonne + VALUES($colonne)"
        );
        $requeteHeure = $conn->prepare(
            "INSERT INTO temps_presence_equipe_heures
                (user_id, date_presence, heure, secondes_en_ligne, secondes_en_pause)
             VALUES (:user_id, :date_presence, :heure, :secondes_en_ligne, :secondes_en_pause)
             ON DUPLICATE KEY UPDATE $colonne = $colonne + VALUES($colonne)"
        );

        while ($debutPresence < $finPresence) {
            $heureSuivante = $debutPresence->setTime((int) $debutPresence->format('H'), 0)->modify('+1 hour');
            $finSegment = $finPresence < $heureSuivante ? $finPresence : $heureSuivante;
            $secondes = $finSegment->getTimestamp() - $debutPresence->getTimestamp();
            $valeurs = [
                ':conseiller_id' => $conseillerId,
                ':date_presence' => $debutPresence->format('Y-m-d'),
                ':secondes_en_ligne' => $statut === 'online' ? $secondes : 0,
                ':secondes_en_pause' => $statut === 'pause' ? $secondes : 0,
            ];
            $requeteJour->execute($valeurs);
            $requeteHeure->execute([
                ':user_id' => $conseillerId,
                ':date_presence' => $debutPresence->format('Y-m-d'),
                ':heure' => (int) $debutPresence->format('G'),
                ':secondes_en_ligne' => $valeurs[':secondes_en_ligne'],
                ':secondes_en_pause' => $valeurs[':secondes_en_pause'],
            ]);
            $debutPresence = $finSegment;
        }
    }

    public function getMembresEquipe(string $recherche = ''): array {
        $stmt = $this->conn->prepare(
            "SELECT u.id, u.nom, u.matricule, u.statut,
                    u.role,
                    CASE
                        WHEN u.statut <> 'actif' THEN 'suspendu'
                        WHEN u.presence_status = 'offline'
                            OR u.presence_last_seen IS NULL
                            OR u.presence_last_seen < DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                        THEN 'offline'
                        ELSE u.presence_status
                    END AS presence_status,
                    u.presence_last_seen
             FROM users u
             WHERE u.role IN ('conseiller', 'coordinateur', 'finance')
               AND (:recherche = '' OR u.nom LIKE :nom OR u.matricule LIKE :matricule)
             ORDER BY CASE
                 WHEN u.statut <> 'actif' THEN 3
                 WHEN u.presence_status = 'offline'
                     OR u.presence_last_seen IS NULL
                     OR u.presence_last_seen < DATE_SUB(NOW(), INTERVAL 2 MINUTE) THEN 2
                 WHEN u.presence_status = 'pause' THEN 1
                 ELSE 0
             END, u.nom"
        );
        $like = '%' . $recherche . '%';
        $stmt->execute([':recherche' => $recherche, ':nom' => $like, ':matricule' => $like]);
        return $stmt->fetchAll();
    }

    public function getMembreEquipe(int $id): ?array {
        $stmt = $this->conn->prepare(
            "SELECT id, nom, matricule, role, statut,
                    CASE
                        WHEN statut <> 'actif' THEN 'suspendu'
                        WHEN presence_status = 'offline'
                            OR presence_last_seen IS NULL
                            OR presence_last_seen < DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                        THEN 'offline'
                        ELSE presence_status
                    END AS presence_status,
                    presence_last_seen
             FROM users
             WHERE id = :id AND role IN ('conseiller', 'coordinateur', 'finance')
             LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public function getDureesPresence(string $debut, string $fin): array {
        $stmt = $this->conn->prepare(
            "SELECT conseiller_id,
                    SUM(secondes_en_ligne) AS secondes_en_ligne,
                    SUM(secondes_en_pause) AS secondes_en_pause
             FROM temps_presence_conseillers
             WHERE date_presence BETWEEN :debut AND :fin
             GROUP BY conseiller_id"
        );
        $stmt->execute([':debut' => $debut, ':fin' => $fin]);
        $durees = [];
        foreach ($stmt->fetchAll() as $ligne) {
            $durees[(int) $ligne['conseiller_id']] = [
                'en_ligne' => (int) $ligne['secondes_en_ligne'],
                'en_pause' => (int) $ligne['secondes_en_pause'],
            ];
        }
        return $durees;
    }

    public function getPresenceParJour(int $userId, string $debut, string $fin): array {
        $stmt = $this->conn->prepare(
            "SELECT date_presence,
                    SUM(secondes_en_ligne) AS secondes_en_ligne,
                    SUM(secondes_en_pause) AS secondes_en_pause
             FROM temps_presence_equipe_heures
             WHERE user_id = :user_id AND date_presence BETWEEN :debut AND :fin
             GROUP BY date_presence
             ORDER BY date_presence"
        );
        $stmt->execute([':user_id' => $userId, ':debut' => $debut, ':fin' => $fin]);
        $presenceParJour = [];
        foreach ($stmt->fetchAll() as $ligne) {
            $presenceParJour[$ligne['date_presence']] = [
                'en_ligne' => (int) $ligne['secondes_en_ligne'],
                'en_pause' => (int) $ligne['secondes_en_pause'],
            ];
        }
        return $presenceParJour;
    }

    public function getHeuresPresence(int $userId, string $date): array {
        $stmt = $this->conn->prepare(
            "SELECT heure, secondes_en_ligne, secondes_en_pause
             FROM temps_presence_equipe_heures
             WHERE user_id = :user_id AND date_presence = :date_presence"
        );
        $stmt->execute([':user_id' => $userId, ':date_presence' => $date]);
        $heures = [];
        foreach ($stmt->fetchAll() as $ligne) {
            $heures[(int) $ligne['heure']] = [
                'en_ligne' => (int) $ligne['secondes_en_ligne'],
                'en_pause' => (int) $ligne['secondes_en_pause'],
            ];
        }
        return $heures;
    }
}
