<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/roles.php';

/**
 * Messagerie interne : qui peut écrire à qui.
 *
 * Profils : admin, conseiller, coordinateur (membres « équipe », identifiés par users.role),
 *           partenaire, technicien.
 *
 *   admin         -> tout le monde
 *   conseiller    -> admin, conseillers, coordinateurs
 *   coordinateur  -> admin, coordinateurs, conseillers, partenaires
 *   partenaire    -> admin, coordinateurs + SES techniciens (jamais un autre partenaire)
 *   technicien    -> admin + SON partenaire employeur + les techniciens du même employeur
 *   autre rôle interne (non listé ci-dessus) -> admin uniquement
 *
 * Pour modifier une règle, il suffit d'éditer la constante REGLES ci-dessous.
 */
class MessagerieInterne {
    private $conn;
    private $cacheParticipants = [];

    const ROLE_ADMIN = 'admin';

    // Pour chaque profil : les profils avec lesquels il peut échanger ('*' = tous).
    // Les règles doivent être SYMÉTRIQUES : la conversation n'est possible que si les deux profils s'autorisent.
    const REGLES = [
        'admin'        => ['*'],
        'conseiller'   => ['admin', 'conseiller', 'coordinateur'],
        'coordinateur' => ['admin', 'coordinateur', 'conseiller', 'partenaire'],
        'partenaire'   => ['admin', 'coordinateur', 'technicien'], // uniquement ses propres techniciens (vérifié plus bas)
        'technicien'   => ['admin', 'technicien', 'partenaire'], // uniquement collègues et employeur (vérifié plus bas)
    ];
    const REGLE_PAR_DEFAUT = ['admin'];                          // autres rôles internes

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    private function ordrePriorite($type) {
        return ['equipe' => 0, 'partenaire' => 1, 'technicien' => 2][$type] ?? 9;
    }

    private function normaliser($t1, $i1, $t2, $i2) {
        $p1 = [$t1, (int) $i1]; $p2 = [$t2, (int) $i2];
        $o1 = $this->ordrePriorite($t1); $o2 = $this->ordrePriorite($t2);
        if ($o1 < $o2 || ($o1 === $o2 && $p1[1] <= $p2[1])) return [$p1, $p2];
        return [$p2, $p1];
    }

    private function libelleRole($role) {
        return defined('LIBELLES_ROLES') ? (LIBELLES_ROLES[$role] ?? $role) : $role;
    }

    // ===== Identité d'un participant =====
    // Renvoie ['type', 'id', 'profil', 'partenaire_id', 'actif'] ou null s'il n'existe pas.
    private function getParticipant($type, $id) {
        $id = (int) $id;
        $cle = $type . ':' . $id;
        if (array_key_exists($cle, $this->cacheParticipants)) return $this->cacheParticipants[$cle];

        $participant = null;

        if ($type === 'equipe') {
            $stmt = $this->conn->prepare("SELECT id, role, statut FROM users WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $r = $stmt->fetch();
            if ($r && in_array($r['role'], ROLES_INTERNES, true)) {
                $participant = ['type' => 'equipe', 'id' => $id, 'profil' => $r['role'], 'partenaire_id' => null, 'actif' => $r['statut'] === 'actif'];
            }
        } elseif ($type === 'partenaire') {
            $stmt = $this->conn->prepare("SELECT id, statut FROM partenaires WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $r = $stmt->fetch();
            if ($r) $participant = ['type' => 'partenaire', 'id' => $id, 'profil' => 'partenaire', 'partenaire_id' => $id, 'actif' => $r['statut'] === 'actif'];
        } elseif ($type === 'technicien') {
            $stmt = $this->conn->prepare("SELECT id, partenaire_id, statut FROM techniciens WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $r = $stmt->fetch();
            if ($r) $participant = ['type' => 'technicien', 'id' => $id, 'profil' => 'technicien', 'partenaire_id' => $r['partenaire_id'] !== null ? (int) $r['partenaire_id'] : null, 'actif' => $r['statut'] === 'actif'];
        }

        return $this->cacheParticipants[$cle] = $participant;
    }

    // ===== Règles métier : qui peut parler à qui =====
    private function profilAutorise($profil, $autre) {
        $regles = self::REGLES[$profil] ?? self::REGLE_PAR_DEFAUT;
        return in_array('*', $regles, true) || in_array($autre, $regles, true);
    }

    // Les deux profils doivent s'autoriser mutuellement
    private function profilsCompatibles($p1, $p2) {
        return $this->profilAutorise($p1, $p2) && $this->profilAutorise($p2, $p1);
    }

    public function peutContacter($t1, $i1, $t2, $i2) {
        if ($t1 === $t2 && (int) $i1 === (int) $i2) return false;

        $a = $this->getParticipant($t1, $i1);
        $b = $this->getParticipant($t2, $i2);
        if (!$a || !$b || !$a['actif'] || !$b['actif']) return false;   // inconnu ou désactivé

        if (!$this->profilsCompatibles($a['profil'], $b['profil'])) return false;

        // Partenaire <-> technicien : uniquement ses propres techniciens
        if ($a['type'] === 'partenaire' && $b['type'] === 'technicien') return $b['partenaire_id'] !== null && $b['partenaire_id'] === $a['id'];
        if ($a['type'] === 'technicien' && $b['type'] === 'partenaire') return $a['partenaire_id'] !== null && $a['partenaire_id'] === $b['id'];

        // Technicien <-> technicien : uniquement le même employeur
        if ($a['type'] === 'technicien' && $b['type'] === 'technicien') return $a['partenaire_id'] !== null && $a['partenaire_id'] === $b['partenaire_id'];

        return true;
    }

    // ===== Conversations =====

    // Conversation existante entre deux participants (null si ils ne se sont jamais écrit).
    // Ne vérifie pas les droits et ne crée rien.
    public function trouverConversation($t1, $i1, $t2, $i2) {
        [$a, $b] = $this->normaliser($t1, $i1, $t2, $i2);
        $stmt = $this->conn->prepare("SELECT id FROM conversations_internes WHERE type_a = :ta AND id_a = :ia AND type_b = :tb AND id_b = :ib");
        $stmt->execute([':ta' => $a[0], ':ia' => $a[1], ':tb' => $b[0], ':ib' => $b[1]]);
        $existante = $stmt->fetch();
        return $existante ? (int) $existante['id'] : null;
    }

    public function getOuCreerConversation($t1, $i1, $t2, $i2) {
        if (!$this->peutContacter($t1, $i1, $t2, $i2)) return null;

        $existante = $this->trouverConversation($t1, $i1, $t2, $i2);
        if ($existante) return $existante;

        [$a, $b] = $this->normaliser($t1, $i1, $t2, $i2);
        try {
            $stmt = $this->conn->prepare("INSERT INTO conversations_internes (type_a, id_a, type_b, id_b) VALUES (:ta, :ia, :tb, :ib)");
            $stmt->execute([':ta' => $a[0], ':ia' => $a[1], ':tb' => $b[0], ':ib' => $b[1]]);
            return (int) $this->conn->lastInsertId();
        } catch (PDOException $e) {
            // Deux envois simultanés : la conversation vient d'être créée par l'autre requête
            if ($e->getCode() === '23000') {
                $existante = $this->trouverConversation($t1, $i1, $t2, $i2);
                if ($existante) return $existante;
            }
            throw $e;
        }
    }

    // Premier message vers un contact : la conversation n'est enregistrée qu'à ce moment-là.
    // Conversation + message sont créés dans la même transaction : si l'enregistrement du message
    // échoue, aucune conversation vide ne reste en base.
    // Renvoie l'id de la conversation, ou null si l'échange n'est pas autorisé.
    public function envoyerAuContact($moiType, $moiId, $autreType, $autreId, $contenu) {
        if (!$this->peutContacter($moiType, $moiId, $autreType, $autreId)) return null;

        $this->conn->beginTransaction();
        try {
            $convId = $this->getOuCreerConversation($moiType, $moiId, $autreType, $autreId);
            if (!$convId) { $this->conn->rollBack(); return null; }
            $this->envoyerMessage($convId, $moiType, $moiId, $contenu);
            $this->conn->commit();
            return $convId;
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            throw $e;
        }
    }

    private function autreParticipant($conv, $moiType, $moiId) {
        $estA = $conv['type_a'] === $moiType && (int) $conv['id_a'] === (int) $moiId;
        return $estA ? [$conv['type_b'], $conv['id_b']] : [$conv['type_a'], $conv['id_a']];
    }

    // Une conversation existante reste-t-elle autorisée ? (les règles ont pu changer, un technicien
    // a pu quitter son employeur, un compte a pu être désactivé...) À vérifier avant chaque envoi.
    public function conversationAutorisee($conversationId, $moiType, $moiId) {
        $stmt = $this->conn->prepare("SELECT type_a, id_a, type_b, id_b FROM conversations_internes WHERE id = :id");
        $stmt->execute([':id' => $conversationId]);
        $c = $stmt->fetch();
        if (!$c) return false;

        $estA = $c['type_a'] === $moiType && (int) $c['id_a'] === (int) $moiId;
        $estB = $c['type_b'] === $moiType && (int) $c['id_b'] === (int) $moiId;
        if (!$estA && !$estB) return false;

        [$autreType, $autreId] = $this->autreParticipant($c, $moiType, $moiId);
        return $this->peutContacter($moiType, $moiId, $autreType, $autreId);
    }

    public function getNomContact($type, $id) {
        if ($type === 'equipe') {
            $stmt = $this->conn->prepare("SELECT nom, role, matricule FROM users WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $r = $stmt->fetch();
            if (!$r) return ['nom' => 'Membre ALLÔ PRO', 'sous_titre' => '', 'matricule' => null];
            return ['nom' => $r['nom'], 'sous_titre' => $this->libelleRole($r['role']), 'matricule' => $r['matricule']];
        }
        if ($type === 'partenaire') {
            $stmt = $this->conn->prepare("SELECT nom_entreprise FROM partenaires WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $r = $stmt->fetch();
            return ['nom' => $r['nom_entreprise'] ?? 'Partenaire', 'sous_titre' => 'Partenaire', 'matricule' => null];
        }
        $stmt = $this->conn->prepare(
            "SELECT t.nom, t.photo_profil, t.avatar_initiales,
                    (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY p.nom, c.nom SEPARATOR ', ')
                     FROM technicien_competences tc
                     JOIN categories c ON c.id = tc.categorie_id
                     LEFT JOIN categories p ON p.id = c.parent_id
                     WHERE tc.technicien_id = t.id) AS competences
             FROM techniciens t WHERE t.id = :id"
        );
        $stmt->execute([':id' => $id]);
        $r = $stmt->fetch();
        return [
            'nom' => $r['nom'] ?? 'Technicien',
            'sous_titre' => $r['competences'] ?? 'Technicien',
            'matricule' => null,
            'photo_profil' => $r['photo_profil'] ?? null,
            'avatar_initiales' => (bool) ($r['avatar_initiales'] ?? false),
        ];
    }

    // Une seule requête pour toute la liste (dernier message + non lus), au lieu de 3 requêtes par conversation
    public function getConversationsListe($moiType, $moiId) {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.type_a, c.id_a, c.type_b, c.id_b,
                (SELECT m.contenu FROM messages_internes m WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) AS dernier_message,
                (SELECT m.date_creation FROM messages_internes m WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) AS derniere_date,
                (SELECT COUNT(*) FROM messages_internes m
                    WHERE m.conversation_id = c.id AND m.lu = 0
                      AND NOT (m.expediteur_type = :type AND m.expediteur_id = :moi)) AS non_lus
            FROM conversations_internes c
            WHERE (c.type_a = :t1 AND c.id_a = :i1) OR (c.type_b = :t2 AND c.id_b = :i2)"
        );
        $stmt->execute([':type' => $moiType, ':moi' => $moiId, ':t1' => $moiType, ':i1' => $moiId, ':t2' => $moiType, ':i2' => $moiId]);

        $resultat = [];
        foreach ($stmt->fetchAll() as $c) {
            if ($c['derniere_date'] === null) continue; // aucune conversation vide dans la liste

            [$autreType, $autreId] = $this->autreParticipant($c, $moiType, $moiId);
            $contact = $this->getNomContact($autreType, $autreId);

            $resultat[] = [
                'conversation_id' => $c['id'],
                'autre_type' => $autreType,
                'autre_id' => $autreId,
                'nom' => $contact['nom'],
                'sous_titre' => $contact['sous_titre'],
                'photo_profil' => $contact['photo_profil'] ?? null,
                'avatar_initiales' => $contact['avatar_initiales'] ?? false,
                'dernier_message' => $c['dernier_message'],
                'derniere_date' => $c['derniere_date'],
                'non_lus' => (int) $c['non_lus'],
            ];
        }
        usort($resultat, fn($a, $b) => strtotime($b['derniere_date']) <=> strtotime($a['derniere_date']));
        return $resultat;
    }

    public function getMessages($conversationId, $apresId = 0) {
        // ORDER BY id : cohérent avec « id > :apres » (deux messages de la même seconde ne s'inversent plus)
        $stmt = $this->conn->prepare("SELECT * FROM messages_internes WHERE conversation_id = :id AND id > :apres ORDER BY id ASC");
        $stmt->execute([':id' => $conversationId, ':apres' => $apresId]);
        return $stmt->fetchAll();
    }

    public function envoyerMessage($conversationId, $expediteurType, $expediteurId, $contenu) {
        $stmt = $this->conn->prepare("INSERT INTO messages_internes (conversation_id, expediteur_type, expediteur_id, contenu) VALUES (:cid, :type, :id, :contenu)");
        return $stmt->execute([':cid' => $conversationId, ':type' => $expediteurType, ':id' => $expediteurId, ':contenu' => $contenu]);
    }

    // Marque comme lus les messages de l'AUTRE personne. Il faut comparer le type ET l'identifiant :
    // entre deux conseillers (ou deux techniciens) le type est identique, comparer le type seul
    // ne marquerait jamais rien comme lu.
    public function marquerLues($conversationId, $moiType, $moiId = null) {
        if ($moiId === null) { // ancien appel (sans identifiant)
            $stmt = $this->conn->prepare("UPDATE messages_internes SET lu = 1 WHERE conversation_id = :id AND expediteur_type != :type AND lu = 0");
            return $stmt->execute([':id' => $conversationId, ':type' => $moiType]);
        }
        $stmt = $this->conn->prepare(
            "UPDATE messages_internes SET lu = 1
            WHERE conversation_id = :id AND lu = 0 AND NOT (expediteur_type = :type AND expediteur_id = :moi)"
        );
        return $stmt->execute([':id' => $conversationId, ':type' => $moiType, ':moi' => $moiId]);
    }

    public function estParticipant($conversationId, $moiType, $moiId) {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM conversations_internes WHERE id = :id AND ((type_a = :t1 AND id_a = :i1) OR (type_b = :t2 AND id_b = :i2))"
        );
        $stmt->execute([':id' => $conversationId, ':t1' => $moiType, ':i1' => $moiId, ':t2' => $moiType, ':i2' => $moiId]);
        return (bool) $stmt->fetch();
    }

    // ===== Carnet d'adresses, selon qui consulte =====

    // Membres de l'équipe que le profil demandé a le droit de contacter (ex. : un partenaire ne voit que les admins)
    private function membresEquipeAutorises($profilDemandeur, $exclureId = 0) {
        $placeholders = implode(',', array_fill(0, count(ROLES_INTERNES), '?'));
        $stmt = $this->conn->prepare("SELECT id, nom, matricule, role FROM users WHERE role IN ($placeholders) AND statut = 'actif' ORDER BY nom");
        $stmt->execute(array_values(ROLES_INTERNES));

        $membres = [];
        foreach ($stmt->fetchAll() as $m) {
            if ($exclureId && (int) $m['id'] === (int) $exclureId) continue;
            if (!$this->profilsCompatibles($profilDemandeur, $m['role'])) continue;
            $m['role_libelle'] = $this->libelleRole($m['role']);
            $membres[] = $m;
        }
        return $membres;
    }

    private function partenairesAvecTechniciens() {
        $stmt = $this->conn->query(
            "SELECT p.id, p.nom_entreprise, t.id AS tech_id, t.nom AS tech_nom,
                    t.photo_profil AS tech_photo_profil, t.avatar_initiales AS tech_avatar_initiales,
                    (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY parent.nom, c.nom SEPARATOR ', ')
                     FROM technicien_competences tc
                     JOIN categories c ON c.id = tc.categorie_id
                     LEFT JOIN categories parent ON parent.id = c.parent_id
                     WHERE tc.technicien_id = t.id) AS tech_competences
            FROM partenaires p
            LEFT JOIN techniciens t ON t.partenaire_id = p.id AND t.statut = 'actif'
            WHERE p.statut = 'actif' ORDER BY p.nom_entreprise, t.nom"
        );
        $partenaires = [];
        foreach ($stmt->fetchAll() as $l) {
            if (!isset($partenaires[$l['id']])) $partenaires[$l['id']] = ['id' => $l['id'], 'nom' => $l['nom_entreprise'], 'techniciens' => []];
            if ($l['tech_id']) $partenaires[$l['id']]['techniciens'][] = [
                'id' => $l['tech_id'],
                'nom' => $l['tech_nom'],
                'competences' => $l['tech_competences'],
                'photo_profil' => $l['tech_photo_profil'],
                'avatar_initiales' => (bool) $l['tech_avatar_initiales'],
            ];
        }
        return array_values($partenaires);
    }

    private function partenairesAutorises(): array {
        return $this->conn->query(
            "SELECT id, nom_entreprise AS nom
             FROM partenaires
             WHERE statut = 'actif'
             ORDER BY nom_entreprise"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    // Admin : toute l'équipe + tous les partenaires et leurs techniciens.
    // Coordinateur : équipe autorisée et partenaires actifs. Conseiller : membres autorisés de l'équipe.
    public function getContactsEquipe($moiId) {
        $moi = $this->getParticipant('equipe', $moiId);
        if (!$moi || !$moi['actif']) return ['equipe' => [], 'partenaires' => []];

        return [
            'equipe' => $this->membresEquipeAutorises($moi['profil'], $moiId),
            'partenaires' => match ($moi['profil']) {
                self::ROLE_ADMIN => $this->partenairesAvecTechniciens(),
                'coordinateur' => $this->partenairesAutorises(),
                default => [],
            },
        ];
    }

    // Partenaire : les admins + ses propres techniciens
    public function getContactsPartenaire($partenaireId) {
        $stmtTech = $this->conn->prepare(
            "SELECT t.id, t.nom, t.photo_profil, t.avatar_initiales,
                    (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY p.nom, c.nom SEPARATOR ', ')
                     FROM technicien_competences tc
                     JOIN categories c ON c.id = tc.categorie_id
                     LEFT JOIN categories p ON p.id = c.parent_id
                     WHERE tc.technicien_id = t.id) AS competences
             FROM techniciens t
             WHERE t.partenaire_id = :id AND t.statut = 'actif' ORDER BY t.nom"
        );
        $stmtTech->execute([':id' => $partenaireId]);

        return ['equipe' => $this->membresEquipeAutorises('partenaire'), 'techniciens' => $stmtTech->fetchAll()];
    }

    // Technicien : les admins + son employeur + ses collègues du même employeur
    public function getContactsTechnicien($technicienId) {
        $moi = $this->getParticipant('technicien', $technicienId);
        $partenaireId = $moi['partenaire_id'] ?? null;

        $employeur = null; $collegues = [];
        if ($partenaireId) {
            $stmtP = $this->conn->prepare("SELECT id, nom_entreprise FROM partenaires WHERE id = :id AND statut = 'actif'");
            $stmtP->execute([':id' => $partenaireId]);
            $employeur = $stmtP->fetch() ?: null;

            $stmtC = $this->conn->prepare(
                "SELECT t.id, t.nom, t.photo_profil, t.avatar_initiales,
                        (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY p.nom, c.nom SEPARATOR ', ')
                         FROM technicien_competences tc
                         JOIN categories c ON c.id = tc.categorie_id
                         LEFT JOIN categories p ON p.id = c.parent_id
                         WHERE tc.technicien_id = t.id) AS competences
                 FROM techniciens t
                WHERE t.partenaire_id = :pid AND t.id != :moi AND t.statut = 'actif' ORDER BY t.nom"
            );
            $stmtC->execute([':pid' => $partenaireId, ':moi' => $technicienId]);
            $collegues = $stmtC->fetchAll();
        }
        return ['equipe' => $this->membresEquipeAutorises('technicien'), 'employeur' => $employeur, 'collegues' => $collegues];
    }
}