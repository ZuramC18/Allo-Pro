<?php
require_once __DIR__ . '/../config/database.php';

class RechercheDossiersCoordinateur {
    private PDO $conn;

    public function __construct(?PDO $connexion = null) {
        $this->conn = $connexion ?? (new Database())->getConnection();
    }

    public function parClientNumeroOuTelephone(string $recherche, int $limite = 50): array {
        $stmt = $this->conn->prepare(
            "SELECT DISTINCT d.id AS demande_id, d.numero_dossier, d.statut AS demande_statut,
                    d.urgence, d.date_creation, c.nom AS categorie_nom,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))) AS client_nom,
                    u.telephone AS client_telephone,
                    p.nom_entreprise AS partenaire_nom,
                    COALESCE(t.nom, i.technicien_nom) AS technicien_nom,
                    i.statut AS intervention_statut
             FROM demandes d
             JOIN users u ON u.id = d.client_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             LEFT JOIN interventions i ON i.demande_id = d.id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             WHERE d.numero_dossier LIKE :numero_dossier ESCAPE '!'
                OR CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, '')) LIKE :client_nom ESCAPE '!'
                OR u.telephone LIKE :telephone ESCAPE '!'
             ORDER BY d.date_creation DESC
             LIMIT :limite"
        );
        $terme = '%' . $this->echapperJokerLike($recherche) . '%';
        $stmt->bindValue(':numero_dossier', $terme, PDO::PARAM_STR);
        $stmt->bindValue(':client_nom', $terme, PDO::PARAM_STR);
        $stmt->bindValue(':telephone', $terme, PDO::PARAM_STR);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function parPartenaireOuTechnicien(string $recherche, int $limite = 50): array {
        $stmt = $this->conn->prepare(
            "SELECT DISTINCT d.id AS demande_id, d.numero_dossier, d.statut AS demande_statut,
                    d.urgence, d.date_creation, c.nom AS categorie_nom,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    TRIM(CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))) AS client_nom,
                    u.telephone AS client_telephone,
                    p.nom_entreprise AS partenaire_nom,
                    COALESCE(t.nom, i.technicien_nom) AS technicien_nom,
                    i.statut AS intervention_statut
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN users u ON u.id = d.client_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             LEFT JOIN partenaires p ON p.id = i.partenaire_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id
             WHERE p.nom_entreprise LIKE :partenaire ESCAPE '!'
                OR t.nom LIKE :technicien ESCAPE '!'
                OR i.technicien_nom LIKE :technicien_historique ESCAPE '!'
             ORDER BY d.date_creation DESC
             LIMIT :limite"
        );
        $terme = '%' . $this->echapperJokerLike($recherche) . '%';
        $stmt->bindValue(':partenaire', $terme, PDO::PARAM_STR);
        $stmt->bindValue(':technicien', $terme, PDO::PARAM_STR);
        $stmt->bindValue(':technicien_historique', $terme, PDO::PARAM_STR);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function echapperJokerLike(string $recherche): string {
        return strtr($recherche, ['!' => '!!', '%' => '!%', '_' => '!_']);
    }
}
