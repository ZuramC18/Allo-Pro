<?php
require_once __DIR__ . '/../config/database.php';

class Intervention {
    private $conn;
    private $table = 'interventions';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create($demandeId, $technicienNom) {
        $stmt = $this->conn->prepare(
            "INSERT INTO {$this->table} (demande_id, technicien_nom, statut, date_debut) 
             VALUES (:demande_id, :technicien_nom, 'en_attente', NOW())"
        );
        return $stmt->execute([
            ':demande_id' => $demandeId,
            ':technicien_nom' => $technicienNom
        ]);
    }

    public function getByDemandeId($demandeId) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, p.nom_entreprise, p.niveau AS partenaire_niveau, t.nom AS technicien_nom_reel,
                    (SELECT GROUP_CONCAT(DISTINCT z.nom ORDER BY z.nom SEPARATOR ', ')
                     FROM partenaire_zones pz
                     JOIN zones z ON z.id = pz.zone_id
                     WHERE pz.partenaire_id = p.id AND z.nom = a.quartier) AS quartier_partenaire,
                    (SELECT GROUP_CONCAT(DISTINCT cc.nom ORDER BY cp.nom, cc.nom SEPARATOR ', ')
                     FROM technicien_competences tcomp
                     JOIN categories cc ON cc.id = tcomp.categorie_id
                     LEFT JOIN categories cp ON cp.id = cc.parent_id
                     WHERE tcomp.technicien_id = t.id) AS technicien_competences,
                    (SELECT GROUP_CONCAT(DISTINCT cc.nom ORDER BY cp.nom, cc.nom SEPARATOR ', ')
                     FROM technicien_competences tcomp
                     JOIN categories cc ON cc.id = tcomp.categorie_id
                     LEFT JOIN categories cp ON cp.id = cc.parent_id
                     JOIN categories dc ON dc.id = d.categorie_id
                     WHERE tcomp.technicien_id = t.id
                       AND (cc.id = d.categorie_id
                            OR cc.parent_id = d.categorie_id
                            OR dc.parent_id = cc.id)) AS technicien_competences_pertinentes
            FROM {$this->table} i
            JOIN demandes d ON d.id = i.demande_id
            JOIN adresses a ON a.id = d.adresse_id
            LEFT JOIN partenaires p ON i.partenaire_id = p.id
            LEFT JOIN techniciens t ON i.technicien_id = t.id
            WHERE i.demande_id = :demande_id"
        );
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        $intervention = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($intervention) {
            $pertinentes = array_values(array_filter(
                explode(', ', (string) ($intervention['technicien_competences_pertinentes'] ?? '')),
                static fn(string $competence): bool => $competence !== ''
            ));
            $intervention['technicien_competences_affichage'] = implode(', ', array_slice($pertinentes, 0, 3));
        }
        return $intervention;
    }

    public function getMissionByIdEtPartenaire(int $interventionId, int $partenaireId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.demande_id, i.partenaire_id, i.technicien_id,
                    i.statut AS intervention_statut, i.date_debut, i.date_fin,
                    i.date_creneau_planifie, i.heure_creneau_planifie,
                    d.numero_dossier, d.description, d.urgence, d.date_creation,
                    d.contrat_b2b_id,
                    d.date_creneau_souhaite, d.heure_creneau_souhaitee,
                    d.mode_paiement, d.statut AS demande_statut,
                    u.nom AS client_nom, u.email AS client_email, u.telephone AS client_telephone,
                    d.categorie_id AS demande_categorie_id,
                    c.nom AS categorie_nom, a.quartier, a.ville, a.details AS adresse_details,
                    s.nom AS site_b2b_nom, s.details AS site_b2b_details,
                    s.telephone_contact AS site_b2b_telephone, s.email_contact AS site_b2b_email,
                    e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    a.adresse_google, a.latitude AS adresse_latitude, a.longitude AS adresse_longitude,
                    t.nom AS technicien_nom
             FROM {$this->table} i
             JOIN demandes d ON d.id = i.demande_id
             JOIN users u ON u.id = d.client_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             LEFT JOIN techniciens t ON t.id = i.technicien_id AND t.partenaire_id = i.partenaire_id
             WHERE i.id = :intervention_id AND i.partenaire_id = :partenaire_id
             LIMIT 1"
        );
        $stmt->execute([
            ':intervention_id' => $interventionId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->fetch();
    }

    public function redistribuerMission(int $interventionId, int $partenaireId, int $technicienId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} i
             JOIN techniciens t ON t.id = :technicien_id
                 AND t.partenaire_id = i.partenaire_id
                 AND t.statut = 'actif'
             JOIN demandes d ON d.id = i.demande_id
             SET i.technicien_id = t.id, i.technicien_nom = t.nom,
                 i.statut = 'en_attente', i.date_debut = NOW(),
                 i.date_creneau_planifie = NULL, i.heure_creneau_planifie = NULL,
                 i.date_decision_technicien = NULL, i.attribution_mode = 'manuel',
                 i.score_attribution = NULL, i.details_attribution = NULL
             WHERE i.id = :intervention_id
               AND i.partenaire_id = :partenaire_id
               AND i.statut IN ('en_attente', 'acceptee')
               AND (i.technicien_id IS NULL OR i.technicien_id <> t.id)
               AND EXISTS (
                   SELECT 1
                   FROM technicien_competences tcomp
                   JOIN categories tc ON tc.id = tcomp.categorie_id
                   JOIN categories dc ON dc.id = d.categorie_id
                   WHERE tcomp.technicien_id = t.id
                     AND (tc.id = dc.id OR tc.parent_id = dc.id OR dc.parent_id = tc.id)
               )"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':intervention_id' => $interventionId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function mettreAJourStatut($demandeId, $statut) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = :statut
             WHERE demande_id = :demande_id
               AND statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')"
        );
        $stmt->execute([':statut' => $statut, ':demande_id' => $demandeId]);
        if ($stmt->rowCount() === 1) {
            return true;
        }
        $verifier = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE demande_id = :demande_id AND statut = :statut
               AND statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
             LIMIT 1"
        );
        $verifier->execute([':demande_id' => $demandeId, ':statut' => $statut]);
        return (bool) $verifier->fetchColumn();
    }

    public function cloturer($demandeId, $rapport, $montant = null) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table} SET statut = 'terminee', rapport = :rapport, montant = :montant, date_fin = NOW() 
            WHERE demande_id = :demande_id"
        );
        return $stmt->execute([':rapport' => $rapport, ':montant' => $montant, ':demande_id' => $demandeId]);
    }

    public function creerAvecPartenaire(
        int $demandeId,
        int $partenaireId,
        int $technicienId,
        ?int $coordinateurId = null,
        ?string $dateCreneau = null,
        ?int $heureCreneau = null,
        int $heureDebut = 8,
        int $heureFin = 20
    ): bool {
        if (($dateCreneau === null) !== ($heureCreneau === null)
            || ($coordinateurId !== null && ($dateCreneau === null || $heureCreneau === null))) {
            return false;
        }
        if ($dateCreneau !== null
            && (!$this->dateCreneauValide($dateCreneau)
                || $dateCreneau < date('Y-m-d')
                || $dateCreneau > date('Y-m-d', strtotime('+30 days'))
                || $heureCreneau < $heureDebut
                || $heureCreneau >= $heureFin
                || ($dateCreneau === date('Y-m-d') && $heureCreneau < (int) date('G'))
                || $heureDebut < 0 || $heureFin > 24 || $heureFin <= $heureDebut)) {
            return false;
        }

        $this->conn->beginTransaction();
        try {
            $verrou = $this->conn->prepare(
                "SELECT statut FROM demandes WHERE id = :demande_id FOR UPDATE"
            );
            $verrou->execute([':demande_id' => $demandeId]);
            if ($verrou->fetchColumn() !== 'nouvelle') {
                $this->conn->rollBack();
                return false;
            }

            $existante = $this->conn->prepare(
                "SELECT id FROM {$this->table} WHERE demande_id = :demande_id LIMIT 1 FOR UPDATE"
            );
            $existante->execute([':demande_id' => $demandeId]);
            if ($existante->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            $candidat = $this->conn->prepare(
                "SELECT t.id
                 FROM techniciens t
                 JOIN partenaires p ON p.id = t.partenaire_id
                 WHERE t.id = :technicien_id
                   AND t.partenaire_id = :partenaire_id
                   AND t.statut = 'actif' AND p.statut = 'actif'
                 LIMIT 1"
            );
            $candidat->execute([
                ':technicien_id' => $technicienId,
                ':partenaire_id' => $partenaireId,
            ]);
            if (!$candidat->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            if ($dateCreneau !== null && $heureCreneau !== null) {
                $verrouTechnicien = $this->conn->prepare(
                    "SELECT id FROM techniciens
                     WHERE id = :technicien_id AND statut = 'actif'
                     FOR UPDATE"
                );
                $verrouTechnicien->execute([':technicien_id' => $technicienId]);
                if (!$verrouTechnicien->fetchColumn()
                    || !$this->creneauTechnicienDisponible($technicienId, $dateCreneau, $heureCreneau)) {
                    $this->conn->rollBack();
                    return false;
                }

                $compatibilite = $this->conn->prepare(
                    "SELECT EXISTS (
                         SELECT 1
                         FROM demandes d
                         JOIN categories dc ON dc.id = d.categorie_id
                         JOIN technicien_competences tc ON tc.technicien_id = :technicien_id
                         JOIN categories c ON c.id = tc.categorie_id
                         WHERE d.id = :demande_id
                           AND (c.id = d.categorie_id OR c.parent_id = d.categorie_id OR dc.parent_id = c.id)
                     )"
                );
                $compatibilite->execute([
                    ':technicien_id' => $technicienId,
                    ':demande_id' => $demandeId,
                ]);
                if (!(bool) $compatibilite->fetchColumn()) {
                    $this->conn->rollBack();
                    return false;
                }
            }

            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table}
                    (demande_id, partenaire_id, technicien_id, date_creneau_planifie,
                     heure_creneau_planifie, statut, date_debut)
                 VALUES (:demande_id, :partenaire_id, :technicien_id, :date_creneau_planifie,
                         :heure_creneau_planifie, 'en_attente', NOW())"
            );
            $stmt->execute([
                ':demande_id' => $demandeId,
                ':partenaire_id' => $partenaireId,
                ':technicien_id' => $technicienId,
                ':date_creneau_planifie' => $dateCreneau,
                ':heure_creneau_planifie' => $heureCreneau,
            ]);

            $maj = $this->conn->prepare(
                "UPDATE demandes SET statut = 'attribuee'
                 WHERE id = :demande_id AND statut = 'nouvelle'"
            );
            $maj->execute([':demande_id' => $demandeId]);
            if ($maj->rowCount() !== 1) {
                throw new RuntimeException('La demande n’a pas pu être marquée comme attribuée.');
            }

            if ($coordinateurId !== null) {
                $traiterAttribution = $this->conn->prepare(
                    "UPDATE attributions_demandes_coordinateurs
                     SET statut = 'traitee', coordinateur_id = :coordinateur_id, date_traitement = NOW()
                     WHERE demande_id = :demande_id AND statut = 'en_attente'"
                );
                $traiterAttribution->execute([
                    ':coordinateur_id' => $coordinateurId,
                    ':demande_id' => $demandeId,
                ]);
                if ($traiterAttribution->rowCount() !== 1) {
                    throw new RuntimeException('Le dossier n’est plus en attente dans la file des coordinateurs.');
                }
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getPartenaireIdByDemande($demandeId) {
        $stmt = $this->conn->prepare("SELECT partenaire_id FROM {$this->table} WHERE demande_id = :demande_id");
        $stmt->bindParam(':demande_id', $demandeId);
        $stmt->execute();
        return $stmt->fetch()['partenaire_id'] ?? null;
    }

    public function getByTechnicien($technicienId) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, d.numero_dossier, d.description, d.urgence, d.photo_path,
                    d.contrat_b2b_id, s.entreprise_b2b_id, s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    d.date_creneau_souhaite, d.heure_creneau_souhaitee,
                    a.quartier, a.ville, a.details AS adresse_details,
                    a.adresse_google, a.latitude AS adresse_latitude, a.longitude AS adresse_longitude,
                    c.nom AS categorie_nom
            FROM {$this->table} i
            JOIN demandes d ON i.demande_id = d.id
            LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
            LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
            JOIN adresses a ON d.adresse_id = a.id
            JOIN categories c ON d.categorie_id = c.id
            WHERE i.technicien_id = :technicien_id
              AND i.statut <> 'refusee'
            ORDER BY FIELD(i.statut, 'en_attente','acceptee','en_route','arrive','diagnostic','en_cours','terminee'), i.id DESC"
        );
        $stmt->bindParam(':technicien_id', $technicienId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getByIdEtTechnicien($id, $technicienId) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, d.numero_dossier, d.description, d.urgence, d.photo_path, d.id AS demande_id,
                    d.client_id,
                    d.contrat_b2b_id, s.entreprise_b2b_id, s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    s.details AS site_b2b_details, s.telephone_contact AS site_b2b_telephone,
                    s.email_contact AS site_b2b_email,
                    d.date_creneau_souhaite, d.heure_creneau_souhaitee,
                    d.mode_paiement,
                    a.quartier, a.ville, a.details AS adresse_details,
                    a.adresse_google, a.latitude AS adresse_latitude, a.longitude AS adresse_longitude,
                    c.nom AS categorie_nom
            FROM {$this->table} i
            JOIN demandes d ON i.demande_id = d.id
            LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
            LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
            JOIN adresses a ON d.adresse_id = a.id
            JOIN categories c ON d.categorie_id = c.id
            WHERE i.id = :id AND i.technicien_id = :technicien_id
              AND i.statut <> 'refusee'"
        );
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':technicien_id', $technicienId);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function mettreAJourStatutParId($id, $statut) {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = :statut
             WHERE id = :id
               AND statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')"
        );
        $stmt->execute([':statut' => $statut, ':id' => $id]);
        if ($stmt->rowCount() === 1) {
            return true;
        }
        $verifier = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE id = :id AND statut = :statut
               AND statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
             LIMIT 1"
        );
        $verifier->execute([':id' => $id, ':statut' => $statut]);
        return (bool) $verifier->fetchColumn();
    }

    public function repondreAProposition(int $interventionId, int $technicienId, bool $accepter, ?string $motif = null): bool {
        $this->conn->beginTransaction();
        try {
            $verrou = $this->conn->prepare(
                "SELECT demande_id, statut
                 FROM {$this->table}
                 WHERE id = :intervention_id AND technicien_id = :technicien_id
                 FOR UPDATE"
            );
            $verrou->execute([
                ':intervention_id' => $interventionId,
                ':technicien_id' => $technicienId,
            ]);
            $intervention = $verrou->fetch();
            if (!$intervention || $intervention['statut'] !== 'en_attente') {
                $this->conn->rollBack();
                return false;
            }

            $statut = $accepter ? 'acceptee' : 'refusee';
            $maj = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET statut = :statut, date_decision_technicien = NOW()
                 WHERE id = :intervention_id AND statut = 'en_attente'"
            );
            $maj->execute([
                ':statut' => $statut,
                ':intervention_id' => $interventionId,
            ]);
            if ($maj->rowCount() !== 1) {
                $this->conn->rollBack();
                return false;
            }

            if ($accepter) {
                $majNoteAuto = $this->conn->prepare(
                    "UPDATE notes_automatiques_interventions
                     SET contenu = REPLACE(
                         contenu,
                         'en attente du technicien.',
                         'mission acceptée par le technicien.'
                     )
                     WHERE intervention_id = :intervention_id
                       AND contenu LIKE '%en attente du technicien.'"
                );
                $majNoteAuto->execute([':intervention_id' => $interventionId]);
            }

            if (!$accepter) {
                $file = $this->conn->prepare(
                    "INSERT INTO file_attente_interventions (intervention_id, technicien_id, motif)
                     VALUES (:intervention_id, :technicien_id, :motif)"
                );
                $file->execute([
                    ':intervention_id' => $interventionId,
                    ':technicien_id' => $technicienId,
                    ':motif' => $motif,
                ]);
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function getFileAttenteCoordinateur(): array {
        $stmt = $this->conn->query(
            "SELECT f.id AS file_id, f.intervention_id, f.technicien_id AS technicien_refus_id,
                    f.motif, f.date_creation, i.demande_id, d.numero_dossier, d.description,
                    d.urgence, c.nom AS categorie_nom, a.quartier, a.ville,
                    u.nom AS client_nom, t.nom AS technicien_refus_nom,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    p.nom_entreprise AS partenaire_refus_nom
             FROM file_attente_interventions f
             JOIN interventions i ON i.id = f.intervention_id
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             JOIN users u ON u.id = d.client_id
             JOIN techniciens t ON t.id = f.technicien_id
             LEFT JOIN partenaires p ON p.id = t.partenaire_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             WHERE f.statut = 'en_attente'
             ORDER BY CASE WHEN d.urgence = 'urgente' THEN 0 ELSE 1 END, f.date_creation, f.id"
        );
        return $stmt->fetchAll();
    }

    private function conditionRechercheHistoriqueRefus(?string $recherche, array &$parametres): string {
        if ($recherche === null || $recherche === '') {
            return '';
        }

        $terme = '%' . strtr($recherche, ['!' => '!!', '%' => '!%', '_' => '!_']) . '%';
        $champs = [
            'd.numero_dossier',
            'u.nom',
            "CONCAT_WS(' ', NULLIF(u.prenom, ''), NULLIF(u.nom, ''))",
            't.nom',
            'p.nom_entreprise',
            'f.motif',
            'c.nom',
            'a.quartier',
            'a.ville',
        ];
        $conditions = [];
        foreach ($champs as $index => $champ) {
            $parametre = ':recherche_' . $index;
            $conditions[] = $champ . " LIKE " . $parametre . " ESCAPE '!'";
            $parametres[$parametre] = $terme;
        }

        return ' AND (' . implode(' OR ', $conditions) . ')';
    }

    private function conditionStatutHistoriqueRefus(?string $statut): string {
        return in_array($statut, ['en_attente', 'traitee'], true)
            ? ' AND f.statut = ' . ($statut === 'en_attente' ? "'en_attente'" : "'traitee'")
            : '';
    }

    public function compterHistoriqueRefusParStatut(?string $recherche = null): array {
        $parametres = [];
        $conditionRecherche = $this->conditionRechercheHistoriqueRefus($recherche, $parametres);
        $stmt = $this->conn->prepare(
            "SELECT f.statut, COUNT(*) AS total
             FROM file_attente_interventions f
             JOIN interventions i ON i.id = f.intervention_id
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             JOIN users u ON u.id = d.client_id
             JOIN techniciens t ON t.id = f.technicien_id
             LEFT JOIN partenaires p ON p.id = t.partenaire_id
             WHERE 1 = 1" . $conditionRecherche . "
             GROUP BY f.statut"
        );
        $stmt->execute($parametres);
        $compteurs = ['en_attente' => 0, 'traitee' => 0];
        foreach ($stmt->fetchAll() as $ligne) {
            if (array_key_exists($ligne['statut'], $compteurs)) {
                $compteurs[$ligne['statut']] = (int) $ligne['total'];
            }
        }
        return $compteurs;
    }

    public function compterHistoriqueRefus(?string $recherche = null, ?string $statut = null): int {
        $parametres = [];
        $conditionRecherche = $this->conditionRechercheHistoriqueRefus($recherche, $parametres);
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*)
             FROM file_attente_interventions f
             JOIN interventions i ON i.id = f.intervention_id
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             JOIN users u ON u.id = d.client_id
             JOIN techniciens t ON t.id = f.technicien_id
             LEFT JOIN partenaires p ON p.id = t.partenaire_id
             WHERE 1 = 1" . $conditionRecherche . $this->conditionStatutHistoriqueRefus($statut)
        );
        $stmt->execute($parametres);
        return (int) $stmt->fetchColumn();
    }

    public function getHistoriqueRefus(
        ?string $recherche = null,
        int $limite = 25,
        int $decalage = 0,
        ?string $statut = null
    ): array {
        $parametres = [];
        $conditionRecherche = $this->conditionRechercheHistoriqueRefus($recherche, $parametres);
        $stmt = $this->conn->prepare(
            "SELECT f.id AS file_id, f.intervention_id, f.technicien_id AS technicien_refus_id,
                    f.motif, f.statut AS statut_file, f.date_creation, f.date_traitement,
                    f.coordinateur_id, i.demande_id, i.technicien_nom AS technicien_actuel_nom,
                    d.numero_dossier, d.description, d.urgence, c.nom AS categorie_nom,
                    a.quartier, a.ville, u.nom AS client_nom, t.nom AS technicien_refus_nom,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    p.nom_entreprise AS partenaire_refus_nom,
                    acteur.nom AS acteur_traitement_nom
             FROM file_attente_interventions f
             JOIN interventions i ON i.id = f.intervention_id
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             JOIN adresses a ON a.id = d.adresse_id
             JOIN users u ON u.id = d.client_id
             JOIN techniciens t ON t.id = f.technicien_id
             LEFT JOIN partenaires p ON p.id = t.partenaire_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             LEFT JOIN users acteur ON acteur.id = f.coordinateur_id
             WHERE 1 = 1" . $conditionRecherche . $this->conditionStatutHistoriqueRefus($statut) . "
             ORDER BY f.date_creation DESC, f.id DESC
             LIMIT :limite OFFSET :decalage"
        );
        foreach ($parametres as $parametre => $valeur) {
            $stmt->bindValue($parametre, $valeur);
        }
        $stmt->bindValue(':limite', max(1, $limite), PDO::PARAM_INT);
        $stmt->bindValue(':decalage', max(0, $decalage), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getFileAttentePourIntervention(int $interventionId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT id AS file_id, motif, date_creation
             FROM file_attente_interventions
             WHERE intervention_id = :intervention_id AND statut = 'en_attente'
             ORDER BY id DESC
             LIMIT 1"
        );
        $stmt->execute([':intervention_id' => $interventionId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getTechniciensCompatiblesDemande(int $demandeId): array {
        $stmt = $this->conn->prepare(
            "SELECT t.id, t.nom, t.partenaire_id, p.nom_entreprise,
                    p.niveau AS partenaire_niveau,
                    (SELECT GROUP_CONCAT(DISTINCT z.nom ORDER BY v.nom, z.nom SEPARATOR ', ')
                     FROM partenaire_zones pz
                     JOIN zones z ON z.id = pz.zone_id
                     JOIN zones v ON v.id = z.parent_id
                     WHERE pz.partenaire_id = p.id
                       AND z.nom = a.quartier) AS zones_intervention,
                    (SELECT AVG(n.note)
                     FROM notes n
                     JOIN interventions ni ON ni.demande_id = n.demande_id
                     WHERE ni.technicien_id = t.id) AS note_moyenne,
                    (SELECT COUNT(*)
                     FROM notes n
                     JOIN interventions ni ON ni.demande_id = n.demande_id
                     WHERE ni.technicien_id = t.id) AS nombre_avis,
                    (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY cp.nom, c.nom SEPARATOR ', ')
                     FROM technicien_competences tcomp
                     JOIN categories c ON c.id = tcomp.categorie_id
                     LEFT JOIN categories cp ON cp.id = c.parent_id
                     WHERE tcomp.technicien_id = t.id) AS competences,
                    (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY cp.nom, c.nom SEPARATOR ', ')
                     FROM technicien_competences tcomp
                     JOIN categories c ON c.id = tcomp.categorie_id
                     LEFT JOIN categories cp ON cp.id = c.parent_id
                     WHERE tcomp.technicien_id = t.id
                       AND (c.id = d.categorie_id
                            OR c.parent_id = d.categorie_id
                            OR dc.parent_id = c.id)) AS competences_pertinentes
             FROM demandes d
             JOIN adresses a ON a.id = d.adresse_id
             JOIN categories dc ON dc.id = d.categorie_id
             JOIN techniciens t ON t.statut = 'actif'
             JOIN partenaires p ON p.id = t.partenaire_id AND p.statut = 'actif'
             WHERE d.id = :demande_id
               AND NOT EXISTS (
                   SELECT 1 FROM interventions i
                   WHERE i.demande_id = d.id
                     AND i.technicien_id = t.id
               )
               AND EXISTS (
                   SELECT 1
                   FROM technicien_competences tcomp
                   JOIN categories tc ON tc.id = tcomp.categorie_id
                   WHERE tcomp.technicien_id = t.id
                     AND (tc.id = d.categorie_id
                          OR tc.parent_id = d.categorie_id
                          OR dc.parent_id = tc.id)
               )
             ORDER BY p.nom_entreprise, t.nom"
        );
        $stmt->execute([':demande_id' => $demandeId]);
        $techniciens = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($techniciens as &$technicien) {
            $pertinentes = array_values(array_filter(
                explode(', ', (string) ($technicien['competences_pertinentes'] ?? '')),
                static fn(string $competence): bool => $competence !== ''
            ));
            $competencesAffichees = array_slice($pertinentes, 0, 3);
            $technicien['competences_affichage'] = implode(', ', $competencesAffichees);
        }
        unset($technicien);
        return $techniciens;
    }

    public function getCreneauxDisponiblesTechnicien(
        int $technicienId,
        string $date,
        int $heureDebut,
        int $heureFin,
        ?int $ignorerInterventionId = null
    ): array {
        if ($technicienId < 1 || !$this->dateCreneauValide($date)
            || $date < date('Y-m-d') || $date > date('Y-m-d', strtotime('+30 days'))
            || $heureDebut < 0 || $heureFin > 24 || $heureFin <= $heureDebut) {
            return [];
        }

        $technicien = $this->conn->prepare(
            "SELECT id FROM techniciens WHERE id = :technicien_id AND statut = 'actif'"
        );
        $technicien->execute([':technicien_id' => $technicienId]);
        if (!$technicien->fetchColumn()) {
            return [];
        }

        $indisponibilites = $this->conn->prepare(
            "SELECT heure_debut FROM technicien_indisponibilites
             WHERE technicien_id = :technicien_id AND date_indisponibilite = :date"
        );
        $indisponibilites->execute([':technicien_id' => $technicienId, ':date' => $date]);
        $heuresBloquees = array_fill_keys(array_map('intval', $indisponibilites->fetchAll(PDO::FETCH_COLUMN)), true);

        $missions = $this->conn->prepare(
            "SELECT heure_creneau_planifie FROM {$this->table}
             WHERE technicien_id = :technicien_id
               AND date_creneau_planifie = :date
               AND heure_creneau_planifie IS NOT NULL
               AND statut NOT IN ('terminee', 'annulee', 'refusee')
               AND (:ignore_null_id IS NULL OR id <> :ignore_intervention_id)"
        );
        $missions->execute([
            ':technicien_id' => $technicienId,
            ':date' => $date,
            ':ignore_null_id' => $ignorerInterventionId,
            ':ignore_intervention_id' => $ignorerInterventionId,
        ]);
        foreach ($missions->fetchAll(PDO::FETCH_COLUMN) as $heureOccupee) {
            $heuresBloquees[(int) $heureOccupee] = true;
        }

        $heuresDisponibles = [];
        for ($heure = $heureDebut; $heure < $heureFin; $heure++) {
            if (!isset($heuresBloquees[$heure])
                && !($date === date('Y-m-d') && $heure < (int) date('G'))) {
                $heuresDisponibles[] = $heure;
            }
        }
        return $heuresDisponibles;
    }

    private function creneauTechnicienDisponible(
        int $technicienId,
        string $date,
        int $heure,
        ?int $ignorerInterventionId = null
    ): bool {
        $indisponibilite = $this->conn->prepare(
            "SELECT 1 FROM technicien_indisponibilites
             WHERE technicien_id = :technicien_id
               AND date_indisponibilite = :date
               AND heure_debut = :heure
             LIMIT 1"
        );
        $indisponibilite->execute([
            ':technicien_id' => $technicienId,
            ':date' => $date,
            ':heure' => $heure,
        ]);
        if ($indisponibilite->fetchColumn()) {
            return false;
        }

        $mission = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE technicien_id = :technicien_id
               AND date_creneau_planifie = :date
               AND heure_creneau_planifie = :heure
               AND statut NOT IN ('terminee', 'annulee', 'refusee')
               AND (:ignore_null_id IS NULL OR id <> :ignore_intervention_id)
             LIMIT 1"
        );
        $mission->execute([
            ':technicien_id' => $technicienId,
            ':date' => $date,
            ':heure' => $heure,
            ':ignore_null_id' => $ignorerInterventionId,
            ':ignore_intervention_id' => $ignorerInterventionId,
        ]);
        return !(bool) $mission->fetchColumn();
    }

    public function modifierCreneauPlanifie(
        int $interventionId,
        int $demandeId,
        string $dateCreneau,
        int $heureCreneau,
        int $heureDebut,
        int $heureFin
    ): bool {
        if ($interventionId < 1 || $demandeId < 1
            || !$this->dateCreneauValide($dateCreneau)
            || $dateCreneau < date('Y-m-d')
            || $dateCreneau > date('Y-m-d', strtotime('+30 days'))
            || $heureDebut < 0 || $heureFin > 24 || $heureFin <= $heureDebut
            || $heureCreneau < $heureDebut || $heureCreneau >= $heureFin
            || ($dateCreneau === date('Y-m-d') && $heureCreneau < (int) date('G'))) {
            return false;
        }

        $this->conn->beginTransaction();
        try {
            $verrouMission = $this->conn->prepare(
                "SELECT technicien_id, statut, date_creneau_planifie, heure_creneau_planifie
                 FROM {$this->table}
                 WHERE id = :intervention_id AND demande_id = :demande_id
                 FOR UPDATE"
            );
            $verrouMission->execute([
                ':intervention_id' => $interventionId,
                ':demande_id' => $demandeId,
            ]);
            $mission = $verrouMission->fetch(PDO::FETCH_ASSOC);
            if (!$mission || !in_array($mission['statut'], ['en_attente', 'acceptee'], true)) {
                $this->conn->rollBack();
                return false;
            }

            $technicienId = (int) $mission['technicien_id'];
            $verrouTechnicien = $this->conn->prepare(
                "SELECT id FROM techniciens
                 WHERE id = :technicien_id AND statut = 'actif'
                 FOR UPDATE"
            );
            $verrouTechnicien->execute([':technicien_id' => $technicienId]);
            if (!$verrouTechnicien->fetchColumn()
                || !$this->creneauTechnicienDisponible(
                    $technicienId,
                    $dateCreneau,
                    $heureCreneau,
                    $interventionId
                )) {
                $this->conn->rollBack();
                return false;
            }
            if ($mission['date_creneau_planifie'] === $dateCreneau
                && $mission['heure_creneau_planifie'] !== null
                && (int) $mission['heure_creneau_planifie'] === $heureCreneau) {
                $this->conn->commit();
                return true;
            }

            $maj = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET date_creneau_planifie = :date_creneau,
                     heure_creneau_planifie = :heure_creneau
                 WHERE id = :intervention_id
                   AND demande_id = :demande_id
                   AND statut IN ('en_attente', 'acceptee')"
            );
            $maj->execute([
                ':date_creneau' => $dateCreneau,
                ':heure_creneau' => $heureCreneau,
                ':intervention_id' => $interventionId,
                ':demande_id' => $demandeId,
            ]);
            if ($maj->rowCount() !== 1) {
                $this->conn->rollBack();
                return false;
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function reattribuerMissionEnAttente(
        int $interventionId,
        int $demandeId,
        int $technicienId,
        int $coordinateurId,
        bool $estAdmin,
        string $dateCreneau,
        int $heureCreneau,
        int $heureDebut,
        int $heureFin
    ): bool {
        if ($interventionId < 1 || $demandeId < 1 || $technicienId < 1
            || !$this->dateCreneauValide($dateCreneau)
            || $dateCreneau < date('Y-m-d')
            || $dateCreneau > date('Y-m-d', strtotime('+30 days'))
            || $heureDebut < 0 || $heureFin > 24 || $heureFin <= $heureDebut
            || $heureCreneau < $heureDebut || $heureCreneau >= $heureFin
            || ($dateCreneau === date('Y-m-d') && $heureCreneau < (int) date('G'))) {
            return false;
        }

        $this->conn->beginTransaction();
        try {
            $verrouMission = $this->conn->prepare(
                "SELECT technicien_id, statut
                 FROM {$this->table}
                 WHERE id = :intervention_id AND demande_id = :demande_id
                 FOR UPDATE"
            );
            $verrouMission->execute([
                ':intervention_id' => $interventionId,
                ':demande_id' => $demandeId,
            ]);
            $mission = $verrouMission->fetch(PDO::FETCH_ASSOC);
            if (!$mission || $mission['statut'] !== 'en_attente'
                || (int) $mission['technicien_id'] === $technicienId) {
                $this->conn->rollBack();
                return false;
            }

            $attribution = $this->conn->prepare(
                "SELECT coordinateur_id, statut
                 FROM attributions_demandes_coordinateurs
                 WHERE demande_id = :demande_id
                 LIMIT 1
                 FOR UPDATE"
            );
            $attribution->execute([':demande_id' => $demandeId]);
            $priseEnCharge = $attribution->fetch(PDO::FETCH_ASSOC);
            if ((!$priseEnCharge && !$estAdmin)
                || ($priseEnCharge && $priseEnCharge['statut'] !== 'traitee')
                || ($priseEnCharge && !$estAdmin
                    && (int) $priseEnCharge['coordinateur_id'] !== $coordinateurId)) {
                $this->conn->rollBack();
                return false;
            }

            $technicien = $this->conn->prepare(
                "SELECT t.id, t.nom, t.partenaire_id
                 FROM techniciens t
                 JOIN partenaires p ON p.id = t.partenaire_id
                 JOIN demandes d ON d.id = :demande_id
                 JOIN categories dc ON dc.id = d.categorie_id
                 WHERE t.id = :technicien_id
                   AND t.statut = 'actif' AND p.statut = 'actif'
                   AND EXISTS (
                       SELECT 1 FROM technicien_competences tc
                       JOIN categories c ON c.id = tc.categorie_id
                       WHERE tc.technicien_id = t.id
                         AND (c.id = d.categorie_id OR c.parent_id = d.categorie_id OR dc.parent_id = c.id)
                   )
                 LIMIT 1
                 FOR UPDATE"
            );
            $technicien->execute([
                ':demande_id' => $demandeId,
                ':technicien_id' => $technicienId,
            ]);
            $candidat = $technicien->fetch(PDO::FETCH_ASSOC);
            if (!$candidat || !$this->creneauTechnicienDisponible(
                $technicienId,
                $dateCreneau,
                $heureCreneau,
                $interventionId
            )) {
                $this->conn->rollBack();
                return false;
            }

            $maj = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET partenaire_id = :partenaire_id,
                     technicien_id = :technicien_id,
                     technicien_nom = :technicien_nom,
                     date_creneau_planifie = :date_creneau,
                     heure_creneau_planifie = :heure_creneau,
                     date_debut = NOW(),
                     date_decision_technicien = NULL,
                     attribution_mode = 'manuel',
                     score_attribution = NULL,
                     details_attribution = NULL
                 WHERE id = :intervention_id AND demande_id = :demande_id AND statut = 'en_attente'"
            );
            $maj->execute([
                ':partenaire_id' => (int) $candidat['partenaire_id'],
                ':technicien_id' => $technicienId,
                ':technicien_nom' => $candidat['nom'],
                ':date_creneau' => $dateCreneau,
                ':heure_creneau' => $heureCreneau,
                ':intervention_id' => $interventionId,
                ':demande_id' => $demandeId,
            ]);
            if ($maj->rowCount() !== 1) {
                $this->conn->rollBack();
                return false;
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    private function dateCreneauValide(string $date): bool {
        $dateValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        return $dateValidee !== false && $dateValidee->format('Y-m-d') === $date;
    }

    public function reattribuerDepuisFile(int $fileId, int $technicienId, int $coordinateurId): bool {
        $this->conn->beginTransaction();
        try {
            $verrou = $this->conn->prepare(
                "SELECT f.intervention_id, i.demande_id, i.technicien_id AS technicien_refus_id
                 FROM file_attente_interventions f
                 JOIN interventions i ON i.id = f.intervention_id
                 WHERE f.id = :file_id AND f.statut = 'en_attente'
                   AND i.statut = 'refusee'
                 FOR UPDATE"
            );
            $verrou->execute([':file_id' => $fileId]);
            $file = $verrou->fetch();
            if (!$file) {
                $this->conn->rollBack();
                return false;
            }

            $technicien = $this->conn->prepare(
                "SELECT t.nom, t.partenaire_id
                 FROM techniciens t
                 JOIN partenaires p ON p.id = t.partenaire_id
                 JOIN demandes d ON d.id = :demande_id
                 JOIN categories dc ON dc.id = d.categorie_id
                 WHERE t.id = :technicien_id
                   AND t.statut = 'actif' AND p.statut = 'actif'
                   AND EXISTS (
                       SELECT 1
                       FROM technicien_competences tcomp
                       JOIN categories tc ON tc.id = tcomp.categorie_id
                       WHERE tcomp.technicien_id = t.id
                         AND (tc.id = d.categorie_id
                              OR tc.parent_id = d.categorie_id
                              OR dc.parent_id = tc.id)
                   )
                 LIMIT 1"
            );
            $technicien->execute([
                ':demande_id' => (int) $file['demande_id'],
                ':technicien_id' => $technicienId,
            ]);
            $candidat = $technicien->fetch();
            if (!$candidat || (int) $file['technicien_refus_id'] === $technicienId) {
                $this->conn->rollBack();
                return false;
            }

            $majIntervention = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET partenaire_id = :partenaire_id, technicien_id = :technicien_id,
                     technicien_nom = :technicien_nom, statut = 'en_attente',
                     date_debut = NOW(), date_decision_technicien = NULL,
                     date_creneau_planifie = NULL, heure_creneau_planifie = NULL,
                     attribution_mode = 'manuel', score_attribution = NULL,
                     details_attribution = NULL
                 WHERE id = :intervention_id AND statut = 'refusee'"
            );
            $majIntervention->execute([
                ':partenaire_id' => (int) $candidat['partenaire_id'],
                ':technicien_id' => $technicienId,
                ':technicien_nom' => $candidat['nom'],
                ':intervention_id' => (int) $file['intervention_id'],
            ]);
            if ($majIntervention->rowCount() !== 1) {
                $this->conn->rollBack();
                return false;
            }

            $majFile = $this->conn->prepare(
                "UPDATE file_attente_interventions
                 SET statut = 'traitee', date_traitement = NOW(), coordinateur_id = :coordinateur_id
                 WHERE id = :file_id AND statut = 'en_attente'"
            );
            $majFile->execute([
                ':coordinateur_id' => $coordinateurId,
                ':file_id' => $fileId,
            ]);
            if ($majFile->rowCount() !== 1) {
                throw new RuntimeException('La demande a été prise en charge par un autre coordinateur.');
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function ajouterPhoto($id, $colonne, $chemin) {
        $colonne = $colonne === 'avant' ? 'photo_avant' : 'photo_apres';
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET {$colonne} = :chemin
             WHERE id = :id
               AND statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')"
        );
        $stmt->execute([':chemin' => $chemin, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function initialiserChecklist(int $interventionId): void {
        $elements = [
            ['consignes', 'Vérifier l’adresse et les consignes du client', 1],
            ['materiel', 'Préparer les outils et pièces nécessaires', 2],
            ['diagnostic', 'Réaliser et expliquer le diagnostic', 3],
            ['intervention', 'Effectuer l’intervention en sécurité', 4],
            ['tests', 'Tester le fonctionnement après intervention', 5],
            ['client', 'Présenter le résultat au client et ranger', 6],
        ];
        $stmt = $this->conn->prepare(
            "INSERT IGNORE INTO intervention_checklist (intervention_id, cle, libelle, ordre)
             VALUES (:intervention_id, :cle, :libelle, :ordre)"
        );
        foreach ($elements as [$cle, $libelle, $ordre]) {
            $stmt->execute([
                ':intervention_id' => $interventionId,
                ':cle' => $cle,
                ':libelle' => $libelle,
                ':ordre' => $ordre,
            ]);
        }
    }

    public function getChecklist(int $interventionId, int $technicienId): array {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.cle, c.libelle, c.ordre, c.terminee
             FROM intervention_checklist c
             JOIN interventions i ON i.id = c.intervention_id
             WHERE c.intervention_id = :intervention_id AND i.technicien_id = :technicien_id
             ORDER BY c.ordre, c.id"
        );
        $stmt->execute([':intervention_id' => $interventionId, ':technicien_id' => $technicienId]);
        return $stmt->fetchAll();
    }

    public function definirElementChecklist(int $elementId, int $interventionId, int $technicienId, bool $terminee): bool {
        $stmt = $this->conn->prepare(
            "UPDATE intervention_checklist c
             JOIN interventions i ON i.id = c.intervention_id
             SET c.terminee = :terminee
             WHERE c.id = :element_id
               AND c.intervention_id = :intervention_id
               AND i.technicien_id = :technicien_id
               AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')"
        );
        $stmt->execute([
            ':terminee' => $terminee ? 1 : 0,
            ':element_id' => $elementId,
            ':intervention_id' => $interventionId,
            ':technicien_id' => $technicienId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function ajouterDocument(int $interventionId, int $technicienId, string $nomOriginal, string $chemin, string $mimeType, int $taille): bool {
        $stmt = $this->conn->prepare(
            "INSERT INTO intervention_documents
                (intervention_id, technicien_id, nom_original, chemin, mime_type, taille)
             SELECT i.id, :technicien_insert_id, :nom_original, :chemin, :mime_type, :taille
             FROM interventions i
             WHERE i.id = :intervention_id
               AND i.technicien_id = :technicien_filter_id
               AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')"
        );
        $stmt->execute([
            ':intervention_id' => $interventionId,
            ':technicien_insert_id' => $technicienId,
            ':technicien_filter_id' => $technicienId,
            ':nom_original' => $nomOriginal,
            ':chemin' => $chemin,
            ':mime_type' => $mimeType,
            ':taille' => $taille,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function getDocumentsTechnicien(int $technicienId, ?int $interventionId = null): array {
        $sql = "SELECT d.id, d.intervention_id, d.nom_original, d.chemin, d.mime_type, d.taille, d.date_creation
                FROM intervention_documents d
                JOIN interventions i ON i.id = d.intervention_id
                WHERE i.technicien_id = :technicien_id";
        $params = [':technicien_id' => $technicienId];
        if ($interventionId !== null) {
            $sql .= " AND d.intervention_id = :intervention_id";
            $params[':intervention_id'] = $interventionId;
        }
        $sql .= " ORDER BY d.date_creation DESC, d.id DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getDocumentByIdTechnicien(int $documentId, int $technicienId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT d.nom_original, d.chemin, d.mime_type, d.taille
             FROM intervention_documents d
             JOIN interventions i ON i.id = d.intervention_id
             WHERE d.id = :document_id AND i.technicien_id = :technicien_id
             LIMIT 1"
        );
        $stmt->execute([':document_id' => $documentId, ':technicien_id' => $technicienId]);
        return $stmt->fetch();
    }
}