<?php
require_once __DIR__ . '/../config/database.php';

class Technicien {
    private $conn;
    private $table = 'techniciens';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function findByEmail($email) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($partenaireId, $nom, $email, $motDePasse, $telephone, array $competenceIds) {
        $competenceIds = array_values(array_unique(array_map('intval', $competenceIds)));
        if (!$competenceIds) {
            throw new InvalidArgumentException('Au moins une compétence est requise.');
        }
        $hash = password_hash($motDePasse, PASSWORD_DEFAULT);
        $this->conn->beginTransaction();
        try {
            if (!$this->competencesActivesValides($competenceIds)) {
                throw new InvalidArgumentException('Les compétences sélectionnées ne sont pas actives.');
            }
            $stmt = $this->conn->prepare(
                "INSERT INTO {$this->table} (partenaire_id, nom, email, mot_de_passe, telephone)
                VALUES (:partenaire_id, :nom, :email, :mot_de_passe, :telephone)"
            );
            $stmt->execute([':partenaire_id' => $partenaireId, ':nom' => $nom, ':email' => $email, ':mot_de_passe' => $hash, ':telephone' => $telephone]);
            $id = (int) $this->conn->lastInsertId();

            $maj = $this->conn->prepare("UPDATE {$this->table} SET matricule = :matricule WHERE id = :id");
            $maj->execute([':matricule' => 'TE-' . str_pad($id, 5, '0', STR_PAD_LEFT), ':id' => $id]);

            $this->remplacerCompetences($id, $competenceIds);
            $this->conn->commit();
            return $id;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    public function getByPartenaire($partenaireId) {
        $stmt = $this->conn->prepare(
            "SELECT t.*,
                    (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY p.nom, c.nom SEPARATOR ', ')
                     FROM technicien_competences tc
                     JOIN categories c ON c.id = tc.categorie_id
                     LEFT JOIN categories p ON p.id = c.parent_id
                     WHERE tc.technicien_id = t.id) AS competences
             FROM {$this->table} t
             WHERE t.partenaire_id = :id ORDER BY t.nom"
        );
        $stmt->bindParam(':id', $partenaireId);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getEquipePartenaire(int $partenaireId, bool $corbeille = false): array {
        $statut = $corbeille ? 'corbeille' : null;
        $sql = "SELECT t.id, t.nom, t.email, t.telephone, t.matricule, t.statut,
                       (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY p.nom, c.nom SEPARATOR ', ')
                        FROM technicien_competences tc
                        JOIN categories c ON c.id = tc.categorie_id
                        LEFT JOIN categories p ON p.id = c.parent_id
                        WHERE tc.technicien_id = t.id) AS competences
                FROM {$this->table} t
                WHERE t.partenaire_id = :partenaire_id";
        if ($statut !== null) {
            $sql .= " AND t.statut = :statut";
        } else {
            $sql .= " AND t.statut IN ('actif', 'inactif')";
        }
        $sql .= " ORDER BY t.nom";
        $stmt = $this->conn->prepare($sql);
        $params = [':partenaire_id' => $partenaireId];
        if ($statut !== null) {
            $params[':statut'] = $statut;
        }
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getDetailsByIdEtPartenaire(int $technicienId, int $partenaireId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT t.id, t.nom, t.email, t.telephone, t.matricule, t.statut,
                    t.photo_profil, t.avatar_initiales,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS nb_missions,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id
                       AND i.statut = 'terminee') AS nb_terminees,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id
                       AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')) AS nb_en_cours,
                    (SELECT AVG(n.note) FROM notes n
                     JOIN interventions i ON i.demande_id = n.demande_id
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS note_moyenne,
                    (SELECT COUNT(*) FROM notes n
                     JOIN interventions i ON i.demande_id = n.demande_id
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS nb_avis,
                    (SELECT COUNT(*) FROM file_attente_interventions f
                     WHERE f.technicien_id = t.id) AS nb_refus,
                    (SELECT COUNT(*) FROM file_attente_interventions f
                     WHERE f.technicien_id = t.id
                       AND f.date_creation >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
                       AND f.date_creation < DATE_ADD(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 1 MONTH)) AS nb_refus_mois
             FROM {$this->table} t
             WHERE t.id = :technicien_id AND t.partenaire_id = :partenaire_id
             LIMIT 1"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->fetch();
    }

    public function getCompetences(int $technicienId): array {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.nom, c.statut, p.nom AS parent_nom
             FROM technicien_competences tc
             JOIN categories c ON c.id = tc.categorie_id
             LEFT JOIN categories p ON p.id = c.parent_id
             WHERE tc.technicien_id = :technicien_id
             ORDER BY p.nom, c.nom"
        );
        $stmt->execute([':technicien_id' => $technicienId]);
        return $stmt->fetchAll();
    }

    public function ajouterCompetencesParTechnicien(int $technicienId, array $competenceIds): int|false {
        $idsValides = [];
        if (count($competenceIds) > 100) {
            return false;
        }
        foreach ($competenceIds as $competenceId) {
            if ((!is_string($competenceId) && !is_int($competenceId))
                || filter_var($competenceId, FILTER_VALIDATE_INT) === false
                || (int) $competenceId < 1) {
                return false;
            }
            $idsValides[] = (int) $competenceId;
        }
        $competenceIds = array_values(array_unique($idsValides));
        if (!$competenceIds) {
            return false;
        }

        $this->conn->beginTransaction();
        try {
            $proprietaire = $this->conn->prepare(
                "SELECT id FROM {$this->table}
                 WHERE id = :technicien_id AND statut = 'actif'
                 FOR UPDATE"
            );
            $proprietaire->execute([':technicien_id' => $technicienId]);
            if (!$proprietaire->fetchColumn() || !$this->competencesActivesValides($competenceIds)) {
                $this->conn->rollBack();
                return false;
            }

            $ajouter = $this->conn->prepare(
                "INSERT IGNORE INTO technicien_competences (technicien_id, categorie_id)
                 VALUES (:technicien_id, :categorie_id)"
            );
            $nombreAjoute = 0;
            foreach ($competenceIds as $competenceId) {
                $ajouter->execute([
                    ':technicien_id' => $technicienId,
                    ':categorie_id' => $competenceId,
                ]);
                $nombreAjoute += $ajouter->rowCount();
            }

            $this->conn->commit();
            return $nombreAjoute;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function retirerCompetenceParTechnicien(int $technicienId, int $competenceId): bool {
        if ($technicienId < 1 || $competenceId < 1) {
            return false;
        }

        $this->conn->beginTransaction();
        try {
            $proprietaire = $this->conn->prepare(
                "SELECT id FROM {$this->table}
                 WHERE id = :technicien_id AND statut = 'actif'
                 FOR UPDATE"
            );
            $proprietaire->execute([':technicien_id' => $technicienId]);
            if (!$proprietaire->fetchColumn()) {
                $this->conn->rollBack();
                return false;
            }

            $competences = $this->conn->prepare(
                "SELECT categorie_id FROM technicien_competences
                 WHERE technicien_id = :technicien_id
                 FOR UPDATE"
            );
            $competences->execute([':technicien_id' => $technicienId]);
            $competenceIds = array_map('intval', $competences->fetchAll(PDO::FETCH_COLUMN));
            if (count($competenceIds) <= 1 || !in_array($competenceId, $competenceIds, true)) {
                $this->conn->rollBack();
                return false;
            }

            $supprimer = $this->conn->prepare(
                "DELETE FROM technicien_competences
                 WHERE technicien_id = :technicien_id AND categorie_id = :categorie_id"
            );
            $supprimer->execute([
                ':technicien_id' => $technicienId,
                ':categorie_id' => $competenceId,
            ]);
            if ($supprimer->rowCount() !== 1) {
                $this->conn->rollBack();
                return false;
            }

            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    public function definirCompetencesParPartenaire(int $technicienId, int $partenaireId, array $competenceIds): bool {
        $competenceIds = array_values(array_unique(array_map('intval', $competenceIds)));
        if (!$competenceIds) {
            return false;
        }

        $this->conn->beginTransaction();
        try {
            $proprietaire = $this->conn->prepare(
                "SELECT id FROM {$this->table}
                 WHERE id = :technicien_id AND partenaire_id = :partenaire_id
                   AND statut IN ('actif', 'inactif')
                 FOR UPDATE"
            );
            $proprietaire->execute([
                ':technicien_id' => $technicienId,
                ':partenaire_id' => $partenaireId,
            ]);
            if (!$proprietaire->fetchColumn() || !$this->competencesValidesPourTechnicien($technicienId, $competenceIds)) {
                $this->conn->rollBack();
                return false;
            }

            $this->remplacerCompetences($technicienId, $competenceIds);
            $this->conn->commit();
            return true;
        } catch (Throwable $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $exception;
        }
    }

    private function competencesActivesValides(array $competenceIds): bool {
        $placeholders = implode(',', array_fill(0, count($competenceIds), '?'));
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) FROM categories
             WHERE id IN ({$placeholders}) AND parent_id IS NOT NULL AND statut = 'active'"
        );
        $stmt->execute($competenceIds);
        return (int) $stmt->fetchColumn() === count($competenceIds);
    }

    private function competencesValidesPourTechnicien(int $technicienId, array $competenceIds): bool {
        $placeholders = implode(',', array_fill(0, count($competenceIds), '?'));
        $stmt = $this->conn->prepare(
            "SELECT COUNT(*) FROM categories c
             WHERE c.id IN ({$placeholders}) AND c.parent_id IS NOT NULL
               AND (c.statut = 'active' OR EXISTS (
                   SELECT 1 FROM technicien_competences tc
                   WHERE tc.technicien_id = ? AND tc.categorie_id = c.id
               ))"
        );
        $stmt->execute(array_merge($competenceIds, [$technicienId]));
        return (int) $stmt->fetchColumn() === count($competenceIds);
    }

    private function remplacerCompetences(int $technicienId, array $competenceIds): void {
        $supprimer = $this->conn->prepare(
            "DELETE FROM technicien_competences WHERE technicien_id = :technicien_id"
        );
        $supprimer->execute([':technicien_id' => $technicienId]);
        $ajouter = $this->conn->prepare(
            "INSERT INTO technicien_competences (technicien_id, categorie_id)
             VALUES (:technicien_id, :categorie_id)"
        );
        foreach (array_unique(array_map('intval', $competenceIds)) as $competenceId) {
            $ajouter->execute([
                ':technicien_id' => $technicienId,
                ':categorie_id' => $competenceId,
            ]);
        }
    }

    public function getMissionsRecentesParTechnicien(int $technicienId, int $partenaireId, int $limite = 10): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id, i.demande_id, i.statut, i.date_debut, i.date_fin,
                    d.numero_dossier, c.nom AS categorie_nom,
                    s.nom AS site_b2b_nom, e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise,
                    n.note, n.commentaire
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             LEFT JOIN notes n ON n.demande_id = d.id
             WHERE i.technicien_id = :technicien_id AND i.partenaire_id = :partenaire_id
             ORDER BY i.id DESC
             LIMIT :limite"
        );
        $stmt->bindValue(':technicien_id', $technicienId, PDO::PARAM_INT);
        $stmt->bindValue(':partenaire_id', $partenaireId, PDO::PARAM_INT);
        $stmt->bindValue(':limite', max(1, min(20, $limite)), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getDetailsAdminById(int $technicienId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT t.*, p.nom_entreprise,
                    (SELECT GROUP_CONCAT(DISTINCT cc.nom ORDER BY cp.nom, cc.nom SEPARATOR ', ')
                     FROM technicien_competences tc
                     JOIN categories cc ON cc.id = tc.categorie_id
                     LEFT JOIN categories cp ON cp.id = cc.parent_id
                     WHERE tc.technicien_id = t.id) AS competences,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS nb_missions,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id
                       AND i.statut = 'terminee') AS nb_terminees,
                    (SELECT COUNT(*) FROM interventions i
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id
                       AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')) AS nb_en_cours,
                    (SELECT AVG(n.note) FROM notes n
                     JOIN interventions i ON i.demande_id = n.demande_id
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS note_moyenne,
                    (SELECT COUNT(*) FROM notes n
                     JOIN interventions i ON i.demande_id = n.demande_id
                     WHERE i.technicien_id = t.id AND i.partenaire_id = t.partenaire_id) AS nb_avis,
                    (SELECT COUNT(*) FROM file_attente_interventions f
                     WHERE f.technicien_id = t.id) AS nb_refus
             FROM {$this->table} t
             JOIN partenaires p ON p.id = t.partenaire_id
             WHERE t.id = :technicien_id
             LIMIT 1"
        );
        $stmt->execute([':technicien_id' => $technicienId]);
        return $stmt->fetch();
    }

    public function getNotesActivite(int $technicienId): array|false {
        $stmt = $this->conn->prepare(
            "SELECT
                (SELECT AVG(n.note)
                 FROM notes n
                 JOIN interventions i ON i.demande_id = n.demande_id
                 WHERE i.technicien_id = t.id) AS note_clients,
                (SELECT COUNT(*)
                 FROM notes n
                 JOIN interventions i ON i.demande_id = n.demande_id
                 WHERE i.technicien_id = t.id) AS nb_avis_clients,
                (SELECT COUNT(*)
                 FROM interventions i
                 WHERE i.technicien_id = t.id
                   AND i.statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours', 'terminee')) AS nb_missions_acceptees,
                (SELECT COUNT(*)
                 FROM file_attente_interventions f
                 WHERE f.technicien_id = t.id) AS nb_missions_refusees
             FROM {$this->table} t
             WHERE t.id = :technicien_id
             LIMIT 1"
        );
        $stmt->execute([':technicien_id' => $technicienId]);
        $notes = $stmt->fetch();
        if (!$notes) {
            return false;
        }

        $decisions = (int) $notes['nb_missions_acceptees'] + (int) $notes['nb_missions_refusees'];
        $notes['note_allopro'] = $decisions > 0
            ? 5 * (int) $notes['nb_missions_acceptees'] / $decisions
            : null;
        $notes['nb_decisions'] = $decisions;
        return $notes;
    }

    public function getActifsByPartenaire($partenaireId, $categorieId = null) {
        $sql = "SELECT t.id, t.nom,
                       (SELECT GROUP_CONCAT(DISTINCT c.nom ORDER BY p.nom, c.nom SEPARATOR ', ')
                        FROM technicien_competences tc
                        JOIN categories c ON c.id = tc.categorie_id
                        LEFT JOIN categories p ON p.id = c.parent_id
                        WHERE tc.technicien_id = t.id) AS competences
                FROM {$this->table} t
                WHERE t.partenaire_id = :id AND t.statut = 'actif'";

        if ($categorieId) {
            $sql .= " AND EXISTS (
                SELECT 1 FROM technicien_competences tc
                JOIN categories c ON c.id = tc.categorie_id
                LEFT JOIN categories demandee ON demandee.id = :categorie_demandee
                WHERE tc.technicien_id = t.id
                  AND (c.id = :categorie_id OR c.parent_id = :categorie_id2 OR demandee.parent_id = c.id)
            )";
        }
        $sql .= " ORDER BY t.nom";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $partenaireId);
        if ($categorieId) {
            $stmt->bindParam(':categorie_id', $categorieId);
            $stmt->bindParam(':categorie_id2', $categorieId);
            $stmt->bindParam(':categorie_demandee', $categorieId);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function updateProfil(int $id, string $prenom, string $nomFamille, string $telephone): bool {
        $nomComplet = trim($prenom . ' ' . $nomFamille);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET prenom = :prenom, nom_famille = :nom_famille, nom = :nom, telephone = :telephone
             WHERE id = :id"
        );
        return $stmt->execute([
            ':prenom' => $prenom,
            ':nom_famille' => $nomFamille,
            ':nom' => $nomComplet,
            ':telephone' => $telephone,
            ':id' => $id,
        ]);
    }

    public function updatePhotoProfil(int $id, ?string $chemin): bool {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET photo_profil = :photo WHERE id = :id");
        return $stmt->execute([':photo' => $chemin, ':id' => $id]);
    }

    public function definirAvatarInitiales(int $id, bool $afficherInitiales): bool {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET avatar_initiales = :initiales WHERE id = :id");
        return $stmt->execute([':initiales' => $afficherInitiales ? 1 : 0, ':id' => $id]);
    }

    public function updateMotDePasse($id, $nouveauMotDePasse) {
        $hash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET mot_de_passe = :mot_de_passe WHERE id = :id");
        return $stmt->execute([':mot_de_passe' => $hash, ':id' => $id]);
    }

    public function reinitialiserMotDePasseParPartenaire(int $technicienId, int $partenaireId, string $nouveauMotDePasse): bool {
        $hash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET mot_de_passe = :mot_de_passe,
                 reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE id = :technicien_id
               AND partenaire_id = :partenaire_id
               AND statut IN ('actif', 'inactif')"
        );
        $stmt->execute([
            ':mot_de_passe' => $hash,
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function creerJetonReinitialisation($id, string $hash, string $expiration): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = :hash,
                 reinitialisation_expires_at = :expiration,
                 reinitialisation_sent_at = UTC_TIMESTAMP()
             WHERE id = :id
               AND (reinitialisation_sent_at IS NULL
                    OR reinitialisation_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MINUTE))"
        );
        $stmt->execute([':hash' => $hash, ':expiration' => $expiration, ':id' => $id]);
        return $stmt->rowCount() === 1;
    }

    public function annulerJetonReinitialisation($id, string $hash): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE id = :id AND reinitialisation_token_hash = :hash"
        );
        $stmt->execute([':id' => $id, ':hash' => $hash]);
    }

    public function telephoneReinitialisationBloque($id): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE id = :id AND reinitialisation_phone_blocked_until > UTC_TIMESTAMP()"
        );
        $stmt->execute([':id' => $id]);
        return (bool) $stmt->fetchColumn();
    }

    public function enregistrerEchecTelephoneReinitialisation($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_blocked_until = IF(
                     reinitialisation_phone_attempts + 1 >= 5,
                     DATE_ADD(UTC_TIMESTAMP(), INTERVAL 15 MINUTE),
                     reinitialisation_phone_blocked_until
                 ),
                 reinitialisation_phone_attempts = LEAST(reinitialisation_phone_attempts + 1, 5)
             WHERE id = :id
               AND (reinitialisation_phone_blocked_until IS NULL
                    OR reinitialisation_phone_blocked_until <= UTC_TIMESTAMP())"
        );
        $stmt->execute([':id' => $id]);
    }

    public function reinitialiserTentativesTelephone($id): void {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET reinitialisation_phone_attempts = 0,
                 reinitialisation_phone_blocked_until = NULL
             WHERE id = :id"
        );
        $stmt->execute([':id' => $id]);
    }

    public function jetonReinitialisationValide(string $hash): bool {
        $stmt = $this->conn->prepare(
            "SELECT 1 FROM {$this->table}
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP() LIMIT 1"
        );
        $stmt->execute([':hash' => $hash]);
        return (bool) $stmt->fetchColumn();
    }

    public function reinitialiserMotDePasseParJeton(string $hash, string $nouveauMotDePasse): bool {
        $motDePasseHash = password_hash($nouveauMotDePasse, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET mot_de_passe = :mot_de_passe,
                 reinitialisation_token_hash = NULL,
                 reinitialisation_expires_at = NULL,
                 reinitialisation_sent_at = NULL
             WHERE reinitialisation_token_hash = :hash
               AND reinitialisation_expires_at > UTC_TIMESTAMP()"
        );
        $stmt->execute([':mot_de_passe' => $motDePasseHash, ':hash' => $hash]);
        return $stmt->rowCount() === 1;
    }

    public function getAllAvecStats($recherche = null, $partenaireId = null, $categorieId = null, $statut = null) {
        $sql = "SELECT t.*, p.nom_entreprise,
                    (SELECT GROUP_CONCAT(DISTINCT cc.nom ORDER BY cp.nom, cc.nom SEPARATOR ', ')
                     FROM technicien_competences tcc
                     JOIN categories cc ON cc.id = tcc.categorie_id
                     LEFT JOIN categories cp ON cp.id = cc.parent_id
                     WHERE tcc.technicien_id = t.id) AS competences,
                    (SELECT COUNT(*) FROM interventions WHERE technicien_id = t.id) AS nb_missions,
                    (SELECT COUNT(*) FROM interventions WHERE technicien_id = t.id AND statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')) AS nb_actives,
                    (SELECT AVG(n.note) FROM notes n JOIN interventions i ON i.demande_id = n.demande_id WHERE i.technicien_id = t.id) AS note_moyenne,
                    (SELECT COUNT(*) FROM file_attente_interventions f WHERE f.technicien_id = t.id) AS nb_refus
                FROM {$this->table} t
                JOIN partenaires p ON t.partenaire_id = p.id
                WHERE 1=1";
        $params = [];

        if ($recherche) {
            $sql .= " AND (t.nom LIKE :recherche1 OR t.email LIKE :recherche2 OR t.telephone LIKE :recherche3)";
            $terme = '%' . $recherche . '%';
            $params[':recherche1'] = $terme;
            $params[':recherche2'] = $terme;
            $params[':recherche3'] = $terme;
        }
        if ($partenaireId) {
            $sql .= " AND t.partenaire_id = :partenaire_id";
            $params[':partenaire_id'] = $partenaireId;
        }
        if ($categorieId) {
            $sql .= " AND EXISTS (
                SELECT 1 FROM technicien_competences tc
                WHERE tc.technicien_id = t.id AND tc.categorie_id = :categorie_id
            )";
            $params[':categorie_id'] = $categorieId;
        }
        if ($statut) {
            $sql .= " AND t.statut = :statut";
            $params[':statut'] = $statut;
        }
        $sql .= " ORDER BY p.nom_entreprise, t.nom";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function changerStatut($id, $statut) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET statut = :statut WHERE id = :id");
        return $stmt->execute([':statut' => $statut, ':id' => $id]);
    }

    public function changerStatutParPartenaire(int $technicienId, int $partenaireId, string $statut): bool {
        if (!in_array($statut, ['actif', 'inactif'], true)) {
            return false;
        }
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = :statut
             WHERE id = :technicien_id AND partenaire_id = :partenaire_id
               AND statut IN ('actif', 'inactif')"
        );
        $stmt->execute([
            ':statut' => $statut,
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function mettreEnCorbeille(int $technicienId, int $partenaireId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = 'corbeille'
             WHERE id = :technicien_id AND partenaire_id = :partenaire_id
               AND statut IN ('actif', 'inactif')
               AND NOT EXISTS (
                   SELECT 1 FROM interventions i
                   WHERE i.technicien_id = {$this->table}.id
                     AND i.partenaire_id = {$this->table}.partenaire_id
                     AND i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
               )"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function restaurerDeLaCorbeille(int $technicienId, int $partenaireId): bool {
        $stmt = $this->conn->prepare(
            "UPDATE {$this->table}
             SET statut = 'inactif'
             WHERE id = :technicien_id AND partenaire_id = :partenaire_id
               AND statut = 'corbeille'"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':partenaire_id' => $partenaireId,
        ]);
        return $stmt->rowCount() === 1;
    }

    public function compterGlobal() {
        $stmt = $this->conn->query(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(statut = 'actif'), 0) AS actifs,
                    (SELECT COUNT(DISTINCT technicien_id) FROM interventions WHERE statut != 'terminee' AND technicien_id IS NOT NULL) AS en_mission
            FROM {$this->table}"
        );
        return $stmt->fetch();
    }

}