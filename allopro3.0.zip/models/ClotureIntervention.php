<?php
require_once __DIR__ . '/../config/database.php';

class ClotureIntervention {
    private $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getCouvertureDisponible(int $demandeId): ?array {
        if ($demandeId < 1) {
            return null;
        }

        $stmt = $this->conn->prepare(
            "SELECT d.*, c.parent_id AS categorie_parent_id
             FROM demandes d
             JOIN categories c ON c.id = d.categorie_id
             WHERE d.id = :id"
        );
        $stmt->execute([':id' => $demandeId]);
        $demande = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$demande || !empty($demande['contrat_b2b_id'])) {
            return null;
        }

        return $this->trouverCouverture($demande, true, true, false);
    }

    public function cloturer(
        $demandeId,
        $rapport,
        $montantBrut,
        bool $encaisseEspeces = false,
        bool $chercherAbonnementAutomatique = true
    ): array {
        $rapport = trim((string) $rapport);
        if ($rapport === '') {
            return ['ok' => false, 'erreur' => "Le rapport d'intervention est obligatoire."];
        }

        $this->conn->beginTransaction();
        try {
            $stmt = $this->conn->prepare(
                "SELECT d.*, c.parent_id AS categorie_parent_id
                 FROM demandes d
                 JOIN categories c ON c.id = d.categorie_id
                 WHERE d.id = :id
                 FOR UPDATE"
            );
            $stmt->execute([':id' => $demandeId]);
            $demande = $stmt->fetch();

            if (!$demande || !in_array($demande['statut'], ['attribuee', 'en_cours'], true)) {
                return $this->refuser("Cette demande ne peut plus être clôturée.");
            }
            $contratB2bId = !empty($demande['contrat_b2b_id']) ? (int) $demande['contrat_b2b_id'] : null;
            if (!empty($demande['site_b2b_id']) && $contratB2bId === null) {
                return $this->refuser('Cette intervention entreprise doit être rattachée à un contrat B2B avant sa clôture.');
            }
            if ($encaisseEspeces && ($demande['mode_paiement'] !== 'normal' || $contratB2bId !== null)) {
                if ($contratB2bId !== null) {
                    return $this->refuser('Une intervention couverte par un contrat B2B ne donne pas lieu à un paiement individuel.');
                }
                return $this->refuser("Un paiement en espèces ne peut pas remplacer la couverture Pass ou abonnement choisie pour cette demande.");
            }

            $stmt = $this->conn->prepare(
                "SELECT id, statut FROM interventions WHERE demande_id = :demande_id FOR UPDATE"
            );
            $stmt->execute([':demande_id' => $demandeId]);
            $intervention = $stmt->fetch();
            if (!$intervention || !in_array(
                $intervention['statut'],
                ['acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours'],
                true
            )) {
                return $this->refuser("Cette intervention est déjà clôturée ou n'est pas disponible.");
            }

            if ($contratB2bId !== null) {
                $contrat = $this->conn->prepare(
                    "SELECT id, volume_credits, credits_utilises
                     FROM contrats_b2b
                     WHERE id = :contrat_id AND entreprise_b2b_id = (
                         SELECT entreprise_b2b_id FROM sites_b2b WHERE id = :site_id
                     )
                     FOR UPDATE"
                );
                $contrat->execute([':contrat_id' => $contratB2bId, ':site_id' => $demande['site_b2b_id']]);
                $contratData = $contrat->fetch();
                if (!$contratData || (int) $contratData['credits_utilises'] >= (int) $contratData['volume_credits']) {
                    return $this->refuser("Le contrat B2B associé ne dispose plus de crédit pour clôturer cette intervention.");
                }
                $consommation = $this->conn->prepare(
                    "INSERT INTO contrats_b2b_consommations (contrat_b2b_id, demande_id, credits)
                     VALUES (:contrat_id, :demande_id, 1)"
                );
                $consommation->execute([':contrat_id' => $contratB2bId, ':demande_id' => $demandeId]);
                $majCredits = $this->conn->prepare(
                    "UPDATE contrats_b2b SET credits_utilises = credits_utilises + 1
                     WHERE id = :contrat_id AND credits_utilises < volume_credits"
                );
                $majCredits->execute([':contrat_id' => $contratB2bId]);
                if ($majCredits->rowCount() !== 1) {
                    return $this->refuser("Le crédit du contrat B2B a changé. Actualisez la page puis réessayez.");
                }
                $couverture = ['type' => 'contrat_b2b', 'id' => $contratB2bId];
                $montant = null;
            } else {
                $couverture = $this->trouverCouverture(
                    $demande,
                    !$encaisseEspeces,
                    $chercherAbonnementAutomatique
                );
                if ($encaisseEspeces && $couverture !== null) {
                    return $this->refuser("Cette intervention est couverte par un Pass ou un abonnement : aucun paiement en espèces ne peut être enregistré.");
                }
                $montant = null;
                if ($couverture === null) {
                    if (!is_numeric($montantBrut) || !is_finite((float) $montantBrut)
                        || (float) $montantBrut <= 0 || (float) $montantBrut > 99999999.99) {
                        return $this->refuser("Saisissez un montant supérieur à 0 lorsque l'intervention n'est pas couverte.");
                    }
                    $montant = (float) $montantBrut;
                } elseif (!$this->consommerCouverture($couverture, $demandeId)) {
                    return $this->refuser("La couverture n'est plus disponible. Actualisez la page puis réessayez.");
                }
            }

            $stmt = $this->conn->prepare(
                "UPDATE interventions
                 SET statut = 'terminee', rapport = :rapport, montant = :montant, date_fin = NOW()
                 WHERE id = :id
                   AND statut IN ('acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')"
            );
            $stmt->execute([
                ':rapport' => $rapport,
                ':montant' => $montant,
                ':id' => $intervention['id']
            ]);
            if ($stmt->rowCount() !== 1) {
                return $this->refuser("Cette intervention a déjà été clôturée.");
            }

            $modePaiement = in_array($couverture['type'] ?? '', ['abonnement', 'pass'], true)
                ? $couverture['type']
                : 'normal';
            $stmt = $this->conn->prepare(
                "UPDATE demandes
                 SET statut = 'terminee', mode_paiement = :mode,
                     abonnement_id = :abonnement_id, pass_achat_id = :pass_id
                 WHERE id = :id"
            );
            $stmt->execute([
                ':mode' => $modePaiement,
                ':abonnement_id' => ($modePaiement === 'abonnement') ? $couverture['id'] : null,
                ':pass_id' => ($modePaiement === 'pass') ? $couverture['id'] : null,
                ':id' => $demandeId
            ]);

            if ($encaisseEspeces) {
                $reference = 'PAY-' . strtoupper(bin2hex(random_bytes(8)));
                $stmt = $this->conn->prepare(
                    "INSERT INTO paiements (demande_id, montant, methode, reference_transaction, statut, date_paiement)
                     VALUES (:demande_id, :montant, 'especes', :reference, 'valide', NOW())"
                );
                $stmt->execute([
                    ':demande_id' => $demandeId,
                    ':montant' => $montant,
                    ':reference' => $reference,
                ]);
            }

            $this->conn->commit();
            return [
                'ok' => true,
                'couverture' => $couverture,
                'montant' => $montant,
                'encaisse_especes' => $encaisseEspeces,
            ];
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            throw $e;
        }
    }

    private function trouverCouverture(
        array $demande,
        bool $chercherCouvertureAutomatique = true,
        bool $chercherAbonnementAutomatique = true,
        bool $verrouiller = true
    ): ?array {
        $categorieRacine = $demande['categorie_parent_id'] ?: $demande['categorie_id'];

        if ($demande['mode_paiement'] === 'abonnement' && !empty($demande['abonnement_id'])) {
            $abonnement = $this->getAbonnement(
                (int) $demande['abonnement_id'],
                (int) $demande['client_id'],
                $verrouiller
            );
            if ($abonnement && $this->abonnementCompatible((int) $abonnement['formule_id'], (int) $categorieRacine)) {
                return ['type' => 'abonnement', 'id' => (int) $abonnement['id']];
            }
        }

        if ($demande['mode_paiement'] === 'pass' && !empty($demande['pass_achat_id'])) {
            $pass = $this->getPass(
                (int) $demande['pass_achat_id'],
                (int) $demande['client_id'],
                $verrouiller
            );
            if ($pass && $this->passCompatible($pass, (int) $categorieRacine)) {
                return ['type' => 'pass', 'id' => (int) $pass['id']];
            }
        }

        if (!$chercherCouvertureAutomatique) {
            return null;
        }

        if ($chercherAbonnementAutomatique) {
            $stmt = $this->conn->prepare(
                "SELECT ac.id, ac.formule_id
                 FROM abonnements_clients ac
                 WHERE ac.client_id = :client_id AND ac.statut = 'actif'
                     AND ac.date_fin >= CURDATE() AND ac.credits_restants > 0" .
                ($verrouiller ? "
                 ORDER BY ac.id DESC
                 FOR UPDATE" : "
                 ORDER BY ac.id DESC")
            );
            $stmt->execute([':client_id' => $demande['client_id']]);
            foreach ($stmt->fetchAll() as $abonnement) {
                if ($this->abonnementCompatible((int) $abonnement['formule_id'], (int) $categorieRacine)) {
                    return ['type' => 'abonnement', 'id' => (int) $abonnement['id']];
                }
            }
        }

        $stmt = $this->conn->prepare(
            "SELECT pa.id, pt.categorie_id
             FROM pass_achats pa
             JOIN pass_types pt ON pt.id = pa.pass_type_id
             WHERE pa.client_id = :client_id AND pa.statut = 'disponible'
             ORDER BY pa.date_achat ASC" . ($verrouiller ? "
             FOR UPDATE" : "")
        );
        $stmt->execute([':client_id' => $demande['client_id']]);
        foreach ($stmt->fetchAll() as $pass) {
            if ($this->passCompatible($pass, (int) $categorieRacine)) {
                return ['type' => 'pass', 'id' => (int) $pass['id']];
            }
        }

        return null;
    }

    private function getAbonnement(int $id, int $clientId, bool $verrouiller = true): ?array {
        $stmt = $this->conn->prepare(
            "SELECT id, formule_id
             FROM abonnements_clients
             WHERE id = :id AND client_id = :client_id AND statut = 'actif'
                 AND date_fin >= CURDATE() AND credits_restants > 0" .
            ($verrouiller ? "
             FOR UPDATE" : "")
        );
        $stmt->execute([':id' => $id, ':client_id' => $clientId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    private function getPass(int $id, int $clientId, bool $verrouiller = true): ?array {
        $stmt = $this->conn->prepare(
            "SELECT pa.id, pt.categorie_id
             FROM pass_achats pa
             JOIN pass_types pt ON pt.id = pa.pass_type_id
             WHERE pa.id = :id AND pa.client_id = :client_id AND pa.statut = 'disponible'" .
            ($verrouiller ? "
             FOR UPDATE" : "")
        );
        $stmt->execute([':id' => $id, ':client_id' => $clientId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    private function abonnementCompatible(int $formuleId, int $categorieRacine): bool {
        $stmt = $this->conn->prepare(
            "SELECT c.id, c.parent_id
             FROM formule_categories fc
             JOIN categories c ON c.id = fc.categorie_id
             WHERE fc.formule_id = :formule_id"
        );
        $stmt->execute([':formule_id' => $formuleId]);
        $categories = $stmt->fetchAll();
        if (!$categories) {
            return true;
        }
        foreach ($categories as $categorie) {
            if ((int) ($categorie['parent_id'] ?: $categorie['id']) === $categorieRacine) {
                return true;
            }
        }
        return false;
    }

    private function passCompatible(array $pass, int $categorieRacine): bool {
        if ($pass['categorie_id'] === null) {
            return true;
        }
        $stmt = $this->conn->prepare("SELECT id, parent_id FROM categories WHERE id = :id");
        $stmt->execute([':id' => $pass['categorie_id']]);
        $categorie = $stmt->fetch();
        return $categorie
            && (int) ($categorie['parent_id'] ?: $categorie['id']) === $categorieRacine;
    }

    private function consommerCouverture(array $couverture, int $demandeId): bool {
        if ($couverture['type'] === 'abonnement') {
            $stmt = $this->conn->prepare(
                "UPDATE abonnements_clients
                 SET credits_restants = credits_restants - 1
                 WHERE id = :id AND statut = 'actif' AND date_fin >= CURDATE() AND credits_restants > 0"
            );
            $stmt->execute([':id' => $couverture['id']]);
        } else {
            $stmt = $this->conn->prepare(
                "UPDATE pass_achats
                 SET statut = 'utilise', demande_id = :demande_id, date_utilisation = NOW()
                 WHERE id = :id AND statut = 'disponible'"
            );
            $stmt->execute([':demande_id' => $demandeId, ':id' => $couverture['id']]);
        }
        return $stmt->rowCount() === 1;
    }

    private function refuser(string $message): array {
        if ($this->conn->inTransaction()) {
            $this->conn->rollBack();
        }
        return ['ok' => false, 'erreur' => $message];
    }
}
