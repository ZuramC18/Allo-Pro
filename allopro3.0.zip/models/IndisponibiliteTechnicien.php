<?php
require_once __DIR__ . '/../config/database.php';

class IndisponibiliteTechnicien {
    private PDO $conn;

    public function __construct() {
        $this->conn = (new Database())->getConnection();
    }

    public function getParPeriode(int $technicienId, string $dateDebut, string $dateFin): array {
        $stmt = $this->conn->prepare(
            "SELECT date_indisponibilite, heure_debut
             FROM technicien_indisponibilites
             WHERE technicien_id = :technicien_id
               AND date_indisponibilite BETWEEN :date_debut AND :date_fin
             ORDER BY date_indisponibilite, heure_debut"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':date_debut' => $dateDebut,
            ':date_fin' => $dateFin,
        ]);
        return $stmt->fetchAll();
    }

    public function getMissionsPlanifieesParPeriode(int $technicienId, string $dateDebut, string $dateFin): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.date_creneau_planifie, i.heure_creneau_planifie,
                    i.statut AS intervention_statut, d.numero_dossier,
                    e.nom AS entreprise_b2b_nom,
                    (d.site_b2b_id IS NOT NULL) AS est_demande_entreprise
             FROM interventions i
             JOIN demandes d ON d.id = i.demande_id
             LEFT JOIN sites_b2b s ON s.id = d.site_b2b_id
             LEFT JOIN entreprises_b2b e ON e.id = s.entreprise_b2b_id
             WHERE i.technicien_id = :technicien_id
               AND i.date_creneau_planifie BETWEEN :date_debut AND :date_fin
               AND i.heure_creneau_planifie IS NOT NULL
               AND i.statut NOT IN ('terminee', 'annulee', 'refusee')
             ORDER BY i.date_creneau_planifie, i.heure_creneau_planifie"
        );
        $stmt->execute([
            ':technicien_id' => $technicienId,
            ':date_debut' => $dateDebut,
            ':date_fin' => $dateFin,
        ]);
        return $stmt->fetchAll();
    }

    public function getMissionsEquipeParPeriode(int $partenaireId, string $dateDebut, string $dateFin): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.technicien_id, t.nom AS technicien_nom,
                    i.date_creneau_planifie, i.heure_creneau_planifie,
                    i.statut AS intervention_statut, d.numero_dossier, c.nom AS categorie_nom
             FROM interventions i
             JOIN techniciens t ON t.id = i.technicien_id
                 AND t.partenaire_id = i.partenaire_id AND t.statut IN ('actif', 'inactif')
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             WHERE i.partenaire_id = :partenaire_id
               AND i.date_creneau_planifie BETWEEN :date_debut AND :date_fin
               AND i.heure_creneau_planifie IS NOT NULL
               AND i.statut NOT IN ('annulee', 'refusee')
             ORDER BY i.date_creneau_planifie, i.heure_creneau_planifie, t.nom"
        );
        $stmt->execute([
            ':partenaire_id' => $partenaireId,
            ':date_debut' => $dateDebut,
            ':date_fin' => $dateFin,
        ]);
        return $stmt->fetchAll();
    }

    public function getIndisponibilitesEquipeParPeriode(int $partenaireId, string $dateDebut, string $dateFin): array {
        $stmt = $this->conn->prepare(
            "SELECT ti.technicien_id, t.nom AS technicien_nom,
                    ti.date_indisponibilite, ti.heure_debut
             FROM technicien_indisponibilites ti
             JOIN techniciens t ON t.id = ti.technicien_id
             WHERE t.partenaire_id = :partenaire_id
               AND t.statut IN ('actif', 'inactif')
               AND ti.date_indisponibilite BETWEEN :date_debut AND :date_fin
             ORDER BY ti.date_indisponibilite, ti.heure_debut, t.nom"
        );
        $stmt->execute([
            ':partenaire_id' => $partenaireId,
            ':date_debut' => $dateDebut,
            ':date_fin' => $dateFin,
        ]);
        return $stmt->fetchAll();
    }

    public function getMissionsEquipeSansCreneau(int $partenaireId): array {
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.technicien_id, t.nom AS technicien_nom,
                    i.statut AS intervention_statut, d.numero_dossier, c.nom AS categorie_nom
             FROM interventions i
             JOIN techniciens t ON t.id = i.technicien_id
                 AND t.partenaire_id = i.partenaire_id AND t.statut IN ('actif', 'inactif')
             JOIN demandes d ON d.id = i.demande_id
             JOIN categories c ON c.id = d.categorie_id
             WHERE i.partenaire_id = :partenaire_id
               AND i.statut NOT IN ('terminee', 'annulee', 'refusee')
               AND (i.date_creneau_planifie IS NULL OR i.heure_creneau_planifie IS NULL)
             ORDER BY t.nom, i.id DESC"
        );
        $stmt->execute([':partenaire_id' => $partenaireId]);
        return $stmt->fetchAll();
    }

    public function getMissionsNonTerminees($technicienId) {
        $stmt = $this->conn->prepare(
            "SELECT i.id AS intervention_id, i.statut AS statut_mission,
                    i.date_creneau_planifie, i.heure_creneau_planifie,
                    d.numero_dossier, d.statut AS statut_demande
            FROM interventions i
            JOIN demandes d ON d.id = i.demande_id
            WHERE i.technicien_id = :id
            AND i.statut IN ('en_attente', 'acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours')
            AND d.statut IN ('attribuee', 'en_cours')
            ORDER BY i.date_creneau_planifie IS NULL, i.date_creneau_planifie, i.heure_creneau_planifie"
        );
        $stmt->execute([':id' => (int) $technicienId]);
        return $stmt->fetchAll();
    }
    
    public function definir(
        int $technicienId,
        string $date,
        int $heureDebut,
        bool $indisponible
    ): bool {
        if (!$this->dateValide($date) || $technicienId < 1 || $heureDebut < 0 || $heureDebut > 23) {
            throw new InvalidArgumentException('Le technicien, la date ou le créneau est invalide.');
        }

        if ($indisponible) {
            $this->conn->beginTransaction();
            try {
                $verrouTechnicien = $this->conn->prepare(
                    "SELECT id FROM techniciens WHERE id = :technicien_id FOR UPDATE"
                );
                $verrouTechnicien->execute([':technicien_id' => $technicienId]);
                if (!$verrouTechnicien->fetchColumn()) {
                    $this->conn->rollBack();
                    return false;
                }

                $mission = $this->conn->prepare(
                    "SELECT id FROM interventions
                     WHERE technicien_id = :technicien_id
                       AND date_creneau_planifie = :date_indisponibilite
                       AND heure_creneau_planifie = :heure_debut
                       AND statut NOT IN ('terminee', 'annulee', 'refusee')
                     LIMIT 1 FOR UPDATE"
                );
                $mission->execute([
                    ':technicien_id' => $technicienId,
                    ':date_indisponibilite' => $date,
                    ':heure_debut' => $heureDebut,
                ]);
                if ($mission->fetchColumn()) {
                    $this->conn->rollBack();
                    throw new DomainException('Ce créneau est réservé pour une mission et ne peut pas être bloqué.');
                }

                $stmt = $this->conn->prepare(
                    "INSERT IGNORE INTO technicien_indisponibilites
                        (technicien_id, date_indisponibilite, heure_debut)
                     VALUES (:technicien_id, :date_indisponibilite, :heure_debut)"
                );
                $stmt->execute([
                    ':technicien_id' => $technicienId,
                    ':date_indisponibilite' => $date,
                    ':heure_debut' => $heureDebut,
                ]);
                $this->conn->commit();
                return true;
            } catch (Throwable $exception) {
                if ($this->conn->inTransaction()) {
                    $this->conn->rollBack();
                }
                throw $exception;
            }
        }

        $stmt = $this->conn->prepare(
            "DELETE FROM technicien_indisponibilites
             WHERE technicien_id = :technicien_id
               AND date_indisponibilite = :date_indisponibilite
               AND heure_debut = :heure_debut"
        );
        return $stmt->execute([
            ':technicien_id' => $technicienId,
            ':date_indisponibilite' => $date,
            ':heure_debut' => $heureDebut,
        ]);
    }

    private function dateValide(string $date): bool {
        $dateValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        return $dateValidee !== false && $dateValidee->format('Y-m-d') === $date;
    }
}
