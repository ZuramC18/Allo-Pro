<?php
$miMoiType = isset($_SESSION['technicien_id']) ? 'technicien' : (isset($_SESSION['partenaire_id']) ? 'partenaire' : 'equipe');
$miMoiId = isset($_SESSION['technicien_id']) ? (int) $_SESSION['technicien_id'] : (isset($_SESSION['partenaire_id']) ? (int) $_SESSION['partenaire_id'] : (int) ($_SESSION['user_id'] ?? 0));
$miSousTitre = $miMoiType === 'technicien'
    ? 'Échangez avec votre partenaire et l’équipe'
    : ($miMoiType === 'partenaire'
        ? 'Échangez avec l’équipe et vos techniciens'
        : (($_SESSION['role'] ?? '') === 'coordinateur'
            ? 'Échangez avec l’équipe et les partenaires'
            : 'Échangez avec les membres de l’équipe'));
$miTexteVide = $miMoiType === 'technicien'
    ? 'Sélectionnez une conversation ou démarrez un nouvel échange avec votre partenaire ou un membre de l’équipe.'
    : ($miMoiType === 'partenaire'
        ? 'Sélectionnez une conversation ou démarrez un nouvel échange avec un membre de l’équipe ou l’un de vos techniciens.'
        : (($_SESSION['role'] ?? '') === 'coordinateur'
            ? 'Sélectionnez une conversation ou démarrez un nouvel échange avec un membre de l’équipe ou un partenaire.'
            : 'Sélectionnez une conversation ou démarrez un nouvel échange avec un membre de l’équipe.'));
?>
<script>
    window.MI_MOI_TYPE = <?= json_encode($miMoiType) ?>;
    window.MI_MOI_ID = <?= json_encode($miMoiId) ?>;
    window.MI_MOI_ROLE = <?= json_encode($_SESSION['role'] ?? '') ?>;
</script>

<div class="mi-shell">
    <div class="mi-sidebar">
        <div class="mi-sidebar__entete">
            <div>
                <div class="mi-sidebar__titre">Conversations</div>
                <div class="mi-sidebar__soustitre"><?= htmlspecialchars($miSousTitre, ENT_QUOTES, 'UTF-8') ?></div>
            </div>
            <button type="button" class="mi-bouton-plus" id="mi-ouvrir-contacts" title="Nouvelle conversation" aria-label="Démarrer une nouvelle conversation">
                <?= icone('plus', 19) ?>
            </button>
        </div>
        <label class="mi-recherche-conversations">
            <?= icone('search', 17) ?>
            <span class="sr-only">Rechercher une conversation</span>
            <input type="search" id="mi-recherche-conversations" placeholder="Rechercher une conversation…" autocomplete="off">
        </label>
        <div class="mi-liste" id="mi-conversations"><div class="mi-squelette"></div><div class="mi-squelette"></div></div>
    </div>

    <div class="mi-fil-zone">
        <div class="mi-fil-vide" id="mi-fil-vide">
            <div class="mi-fil-vide__icone"><?= icone('messages', 34) ?></div>
            <h3>Vos échanges, au même endroit</h3>
            <p><?= htmlspecialchars($miTexteVide, ENT_QUOTES, 'UTF-8') ?></p>
            <button type="button" class="mi-fil-vide__action" id="mi-demarrer-conversation"><?= icone('plus', 17) ?> Nouvelle conversation</button>
        </div>
        <div class="mi-fil" id="mi-fil">
            <div class="mi-fil__entete">
                <button type="button" class="mi-fil__retour" id="mi-retour" aria-label="Retour à la liste des conversations" title="Retour à la liste">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/><path d="M9 12h12"/></svg>
                </button>
                <div class="mi-fil__avatar" id="mi-fil-avatar"></div>
                <div class="mi-fil__identite">
                    <div class="mi-fil__nom" id="mi-fil-nom"></div>
                    <div class="mi-fil__soustitre" id="mi-fil-soustitre"></div>
                </div>
                <a class="mi-fil__infos-technicien" id="mi-fil-infos-technicien" href="#" hidden>
                    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M5 21a7 7 0 0 1 14 0"/><path d="M19 8v6m-3-3h6"/></svg>
                    <span id="mi-fil-infos-technicien-libelle">Voir le profil</span>
                </a>
            </div>
            <div class="mi-fil__corps" id="mi-fil-corps"></div>
            <div class="mi-fil__pied">
                <textarea id="mi-champ-message" rows="1" placeholder="Écrire un message..."></textarea>
                <button id="mi-btn-envoyer" aria-label="Envoyer">➤</button>
            </div>
        </div>
    </div>
</div>

<div class="mi-modale-fond" id="mi-modale-contacts">
    <div class="mi-modale" role="dialog" aria-modal="true" aria-labelledby="mi-modale-titre">
        <div class="mi-modale__entete">
            <div><span class="mi-modale__surtitre">Messagerie interne</span><h3 id="mi-modale-titre">Nouvelle conversation</h3></div>
            <button type="button" class="mi-modale__fermer" id="mi-fermer-contacts" aria-label="Fermer">✕</button>
        </div>
        <label class="mi-recherche-contact">
            <?= icone('search', 17) ?>
            <span class="sr-only">Rechercher un contact</span>
            <input type="search" id="mi-recherche-contact" class="mi-recherche" placeholder="Nom du contact…" autocomplete="off">
        </label>
        <div class="mi-contacts-liste" id="mi-contacts-liste"></div>
    </div>
</div>