<?php
$pageActuelle = basename($_SERVER['PHP_SELF']);
require_once __DIR__ . '/icones.php';
$roleSidebar = $_SESSION['role'] ?? '';
if ($pageActuelle === 'ajustements-creneaux.php' && $roleSidebar === 'admin') {
    require_once __DIR__ . '/../models/AjustementCreneauAutomatique.php';
    $nombreAjustementsCreneaux = (new AjustementCreneauAutomatique())->compterATraiter();
}
if ($roleSidebar === 'admin') {
    require_once __DIR__ . '/../models/EntrepriseB2B.php';
    $nombreDemandesB2BSansContrat = (new EntrepriseB2B())->compterDemandesB2BSansContrat();
}
if ($roleSidebar === 'finance') {
    if (isset($reversementsDus) && is_array($reversementsDus)) {
        $nombrePartenairesAPayerSidebar = count($reversementsDus);
    } else {
        require_once __DIR__ . '/../models/Reversement.php';
        $nombrePartenairesAPayerSidebar = count((new Reversement())->getReversementsDus());
    }
}
$prefixeLiensAdmin = in_array($roleSidebar, ['qualite', 'finance'], true) ? '../admin/' : '';
$lienAccueil = $roleSidebar === 'qualite' ? '../qualite/accueil.php' : 'accueil.php';
$lienDevisEntreprise = match ($roleSidebar) {
    'qualite' => '../qualite/devis-entreprises.php',
    'finance' => '../finance/devis-entreprises.php',
    default => 'devis-entreprises.php',
};
$lienSav = $roleSidebar === 'qualite' ? '../qualite/sav.php' : 'sav.php';
$lienRemboursementsSav = $roleSidebar === 'finance' ? '../finance/remboursements-sav.php' : 'remboursements-sav.php';
$lienProfil = $roleSidebar === 'finance' ? '../finance/profil.php' : 'profil.php';
if (in_array($_SESSION['role'] ?? '', ['conseiller', 'coordinateur', 'finance'], true) && empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

// [fichier, nom de l'icône SVG (voir includes/icones.php), libellé, module requis]
$menu = [
    "Vue d'ensemble" => [
        [$lienAccueil, 'dashboard', 'Tableau de bord', 'tableau_bord'],
        ['statistiques.php', 'chart', 'Statistiques', 'statistiques'],
    ],
    'Opérations' => [
        ['liste-demandes.php', 'inbox', 'Demandes', 'demandes'],
        ['conversations.php', 'shuffle', 'Suivi des conversations', 'coordination'],
        ['messagerie.php', 'message', 'Messagerie', 'messagerie'],
        ['autorisations-appels-techniciens.php', 'radio', 'Appels clients', 'messagerie'],
        ['messagerie-interne.php', 'messages', 'Messagerie interne', 'messagerie_interne'],
        ['interventions.php', 'receipt', 'Interventions', 'interventions'],
        ['refus-interventions.php', 'refresh', 'Refus à réaffecter', 'interventions'],
        ['historique-refus.php', 'file-text', 'Historique de refus', 'interventions'],
        ['attributions-automatiques.php', 'shuffle', 'Attributions automatiques', 'interventions'],
        ['ajustements-creneaux.php', 'calendar', 'Changements de créneaux', 'interventions'],
        [$lienDevisEntreprise, 'file-text', 'Devis entreprises', 'devis_entreprises'],
        ['contrats-entreprises.php', 'file-text', 'Contrats entreprises', 'parametres'],
        ['paiements.php', 'card', 'Paiements', 'paiements'],
        ['livre-comptes.php', 'file-text', 'Livre des comptes', 'reversements'],
        ['partage-benefices.php', 'refresh', 'Partage des bénéfices', 'reversements'],
        ['reversements.php', 'refresh', 'Reversements', 'reversements'],
        [$lienSav, 'headset', 'Qualité / SAV', 'sav'],
        [$lienRemboursementsSav, 'card', 'Remboursements SAV', 'remboursements_sav'],
    ],
    'Gestion' => [
        ['clients.php', 'users', 'Clients', 'clients'],
        ['partenaires.php', 'building', 'Partenaires', 'partenaires'],
        ['techniciens.php', 'wrench', 'Techniciens', 'techniciens'],
        ['utilisateurs.php', 'key', 'Équipe ALLÔ PRO', 'equipe'],
        ['activite-conseillers.php', 'chart', 'Présence de l’équipe', 'audit'],
    ],
    'Configuration' => [
        ['categories.php', 'folder', 'Catégories', 'categories'],
        ['quartiers.php', 'pin', 'Villes & quartiers', 'quartiers'],
        ['abonnements.php', 'gem', 'Abonnements & Pass', 'abonnements'],
        ['messages-contact.php', 'message', 'Messages de contact', 'parametres'],
        ['roles.php', 'shield', 'Rôles & permissions', 'roles'],
        ['themes-evenementiels.php', 'calendar', 'Thèmes événementiels', 'parametres'],
        ['audit.php', 'file-text', "Journal d'audit", 'audit'],
        ['parametres.php', 'settings', 'Paramètres', 'parametres'],
        ['serveur.php', 'settings', 'Informations serveur', 'parametres'],
    ],
];
if (in_array($roleSidebar, ['admin', 'conseiller', 'coordinateur', 'qualite'], true)) {
    $menu['Espace équipe'] = [
        [$roleSidebar === 'qualite' ? '../commun/equipe' : 'equipe', 'calendar', 'Ma journée', 'tableau_bord'],
    ];
}

if ($roleSidebar === 'finance') {
    $menu = [
        'Vue d’ensemble' => [
            ['accueil.php', 'dashboard', 'Tableau de bord', 'paiements'],
        ],
        'Encaissements' => [
            ['paiements-clients.php', 'card', 'Paiements clients', 'paiements'],
            ['paiements-echoues.php', 'card', 'Paiements échoués', 'paiements'],
            ['factures.php', 'file-text', 'Factures', 'paiements'],
            [$lienRemboursementsSav, 'refresh', 'Remboursements', 'remboursements_sav'],
            ['revenus.php', 'chart', 'Revenus', 'paiements'],
        ],
        'Entreprises' => [
            [$lienDevisEntreprise, 'file-text', 'Devis entreprises', 'devis_entreprises'],
            ['contrats-entreprises.php', 'file-text', 'Contrats entreprises', 'devis_entreprises'],
        ],
        'Partenaires' => [
            ['couts-partenaires.php', 'file-text', 'Coûts partenaires', 'reversements'],
            ['commissions.php', 'chart', 'Commissions', 'reversements'],
            ['marges.php', 'chart', 'Marges', 'reversements'],
            ['remunerations-partenaires.php', 'refresh', 'Rémunérations partenaires', 'reversements'],
            ['paiements-a-effectuer.php', 'card', 'Paiements à effectuer', 'reversements'],
        ],
        'Analyse' => [
            ['equipe', 'calendar', 'Ma journée', 'paiements'],
            ['historique-financier.php', 'file-text', 'Historique financier', 'reversements'],
            ['export-donnees.php', 'file-text', 'Export des données', 'paiements'],
            ['reporting.php', 'chart', 'Reporting', 'reversements'],
            ['taches.php', 'clipboard', 'Mes tâches', 'paiements'],
        ],
    ];
}
?>
<!-- Thème : appliqué dès le début de la page pour éviter un flash clair -->
<script>
(function () {
    try {
        var t = localStorage.getItem('allopro_theme');
        if (t !== 'dark' && t !== 'light') t = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', t);
    } catch (e) { document.documentElement.setAttribute('data-theme', 'light'); }

    // Sidebar : masquée par défaut sur tablette/mobile, sinon selon le dernier choix de l'utilisateur
    try {
        var etroit = window.matchMedia('(max-width: 1024px)').matches;
        var pref = localStorage.getItem('allopro_sidebar');
        if (etroit || pref === 'closed') document.documentElement.classList.add('sidebar-fermee');
    } catch (e) {}
})();
</script>
<link rel="stylesheet" href="../../public/css/theme-admin.css?v=<?= filemtime(__DIR__ . '/../public/css/theme-admin.css') ?>">
<link rel="stylesheet" href="../../public/css/admin-sidebar-groups.css?v=<?= filemtime(__DIR__ . '/../public/css/admin-sidebar-groups.css') ?>">
<link rel="stylesheet" href="../../public/css/admin-theme-coherence.css?v=<?= filemtime(__DIR__ . '/../public/css/admin-theme-coherence.css') ?>" data-admin-theme-coherence>


<?php require_once __DIR__ . '/acces.php'; afficherFlashAcces(); ?>
<div class="admin-sidebar">
    <div class="tete">
        <a href="../../public/index.php" class="admin-sidebar__logo">ALLÔ<span> PRO</span></a>

        <div class="admin-sidebar__actions">
        <!-- Bascule mode sombre -->
        <button type="button" class="admin-sidebar__theme" id="theme-toggle" role="switch" aria-checked="false" aria-label="Mode sombre" title="Mode sombre">
            <svg class="theme-ico theme-ico--lune" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
            <svg class="theme-ico theme-ico--soleil" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
        </button>
        <!-- Masquer la sidebar -->
        <button type="button" class="admin-sidebar__fermer" id="sidebar-fermer" aria-label="Masquer le menu" title="Masquer le menu">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m11 17-5-5 5-5"/><path d="m18 17-5-5 5-5"/></svg>
        </button>
        </div>
    </div>
    <?php $moiSidebar = acteurCourant(); ?>
    <div class="admin-sidebar__role"><?= htmlspecialchars((LIBELLES_ROLES[$_SESSION['role']] ?? '') . ' · ' . ($moiSidebar['matricule'] ?? '—')) ?></div>
    <?php if (in_array($_SESSION['role'] ?? '', ['conseiller', 'finance'], true)): ?>
        <div class="sidebar__presence admin-sidebar__presence <?= ($_SESSION['role'] ?? '') === 'finance' ? 'admin-sidebar__presence--finance' : '' ?>" data-csrf="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
            <label class="sidebar__presence-label" for="statut-presence-conseiller">Disponibilité</label>
            <div class="sidebar__presence-select-wrap">
                <span class="sidebar__presence-point" aria-hidden="true"></span>
                <select id="statut-presence-conseiller" class="sidebar__presence-select" aria-label="Choisir mon statut de présence">
                    <option value="online">En ligne</option>
                    <option value="pause">En pause</option>
                    <option value="offline">Hors ligne</option>
                </select>
            </div>
            <?php if (($_SESSION['role'] ?? '') === 'finance'): ?>
                <button type="button" class="sidebar__presence-en-ligne" data-presence-en-ligne>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2v5"/><path d="M7.5 4.8a9 9 0 1 0 9 0"/></svg>
                    <span data-presence-button-label>Se mettre en ligne</span>
                </button>
            <?php endif; ?>
            <span class="sidebar__presence-message" id="presence-message" role="status" aria-live="polite" hidden></span>
        </div>
    <?php endif; ?>

    <?php $liensCatalogueOutils = []; ?>
    <?php foreach ($menu as $titre => $liens):
        $visibles = array_filter($liens, fn($l) => peut($l[3])
            && ($l[0] !== 'autorisations-appels-techniciens.php' || $roleSidebar === 'admin'));
        if (empty($visibles)) continue;
        $sectionActive = false;
        foreach ($visibles as $lienVisible) {
            if (basename($lienVisible[0]) === $pageActuelle) {
                $sectionActive = true;
                break;
            }
        }
        $estSousCategorieAdmin = $roleSidebar === 'admin' && $titre === 'Opérations';
        $groupesVisibles = [];
        if ($estSousCategorieAdmin) {
            foreach ($visibles as $lienVisible) {
                $sousCategorie = match ($lienVisible[0]) {
                    'liste-demandes.php', 'conversations.php', 'messagerie.php',
                    'autorisations-appels-techniciens.php', 'messagerie-interne.php' => 'Demandes & coordination',
                    'interventions.php', 'refus-interventions.php', 'historique-refus.php',
                    'attributions-automatiques.php', 'ajustements-creneaux.php' => 'Interventions',
                    'devis-entreprises.php', 'contrats-entreprises.php' => 'Entreprises',
                    'paiements.php', 'livre-comptes.php', 'partage-benefices.php', 'reversements.php' => 'Finance',
                    'sav.php', 'remboursements-sav.php' => 'Qualité & remboursements',
                    default => 'Autres opérations',
                };
                $groupesVisibles[$sousCategorie][] = $lienVisible;
            }
        } else {
            $groupesVisibles[$titre] = $visibles;
        }
    ?>
        <?php if ($roleSidebar === 'admin'): ?>
            <details class="admin-sidebar__section" <?= $sectionActive ? 'open' : '' ?>>
                <summary>
                    <?= htmlspecialchars($titre, ENT_QUOTES, 'UTF-8') ?>
                    <?php if ($titre === 'Opérations'): ?><span class="mi-sidebar-badge admin-sidebar__group-badge" data-admin-group-badge="section" hidden></span><?php endif; ?>
                </summary>
        <?php else: ?>
            <div>
                <div class="admin-sidebar__section-titre"><?= htmlspecialchars($titre, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
            <?php foreach ($groupesVisibles as $titreGroupe => $liensGroupe):
                $groupeActif = false;
                foreach ($liensGroupe as $lienVisible) {
                    if (basename($lienVisible[0]) === $pageActuelle) {
                        $groupeActif = true;
                        break;
                    }
                }
            ?>
                <?php if ($estSousCategorieAdmin): ?>
                    <details class="admin-sidebar__sous-section" <?= $groupeActif ? 'open' : '' ?>>
                        <summary>
                            <?= htmlspecialchars($titreGroupe, ENT_QUOTES, 'UTF-8') ?>
                            <span class="mi-sidebar-badge admin-sidebar__group-badge" data-admin-group-badge="subcategory" hidden></span>
                        </summary>
                <?php endif; ?>
                <?php foreach ($liensGroupe as $l): ?>
                    <?php $hrefSidebar = $roleSidebar === 'finance'
                        ? $l[0]
                        : (in_array($l[0], [$lienAccueil, $lienDevisEntreprise, $lienSav, $lienRemboursementsSav], true) ? $l[0] : $prefixeLiensAdmin . $l[0]); ?>
                    <?php $pageMenuActuelle = $roleSidebar === 'finance' && $pageActuelle === 'partage-benefices.php' ? 'commissions.php' : $pageActuelle; ?>
                    <?php if ($roleSidebar === 'admin'): ?>
                        <?php $liensCatalogueOutils[] = ['href' => $hrefSidebar, 'icone' => icone($l[1], 22), 'titre' => $l[2], 'categorie' => $titreGroupe]; ?>
                    <?php endif; ?>
                    <a href="<?= htmlspecialchars($hrefSidebar, ENT_QUOTES, 'UTF-8') ?>" class="admin-sidebar__lien <?= $pageMenuActuelle === basename($l[0]) ? 'admin-sidebar__lien--actif' : '' ?>" <?= $l[0] === 'messagerie-interne.php' ? 'data-mi-notification' : '' ?>>
                        <span class="admin-sidebar__icone"><?= icone($l[1], 18) ?></span> <?= $l[2] ?>
                        <?php if ($l[0] === 'refus-interventions.php' && $roleSidebar === 'admin'): ?>
                            <span class="mi-sidebar-badge" data-admin-badge="refus" hidden></span>
                        <?php endif; ?>
                        <?php if ($l[0] === 'devis-entreprises.php' && $roleSidebar === 'admin'): ?>
                            <span class="mi-sidebar-badge" data-admin-badge="devis" hidden></span>
                        <?php endif; ?>
                        <?php if ($l[0] === 'contrats-entreprises.php' && $roleSidebar === 'admin' && $nombreDemandesB2BSansContrat > 0): ?>
                            <span class="mi-sidebar-badge" aria-label="<?= (int) $nombreDemandesB2BSansContrat ?> demande<?= $nombreDemandesB2BSansContrat === 1 ? '' : 's' ?> à rattacher à un contrat"><?= (int) $nombreDemandesB2BSansContrat ?></span>
                        <?php endif; ?>
                        <?php if ($l[0] === $lienRemboursementsSav && $roleSidebar === 'admin'): ?>
                            <span class="mi-sidebar-badge" data-admin-badge="remboursements" hidden></span>
                        <?php endif; ?>
                        <?php if ($l[0] === 'messagerie-interne.php'): ?>
                            <span class="mi-sidebar-badge" data-mi-badge hidden></span>
                        <?php endif; ?>
                        <?php if ($l[0] === 'ajustements-creneaux.php'): ?>
                            <span class="mi-sidebar-badge" data-ajustements-creneaux-badge data-count="<?= (int) ($nombreAjustementsCreneaux ?? 0) ?>" <?= empty($nombreAjustementsCreneaux) ? 'hidden' : '' ?>><?= (int) ($nombreAjustementsCreneaux ?? 0) ?></span>
                        <?php endif; ?>
                        <?php if ($roleSidebar === 'finance' && $l[0] === 'paiements-a-effectuer.php' && $nombrePartenairesAPayerSidebar > 0): ?>
                            <span class="finance-sidebar-badge" aria-label="<?= (int) $nombrePartenairesAPayerSidebar ?> partenaire<?= $nombrePartenairesAPayerSidebar === 1 ? '' : 's' ?> à payer"><?= (int) $nombrePartenairesAPayerSidebar ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
                <?php if ($estSousCategorieAdmin): ?>
                    <?php if ($roleSidebar === 'admin'): ?>
                    </details>
                    <?php else: ?>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; ?>
            <?php if ($roleSidebar === 'admin'): ?>
            </details>
            <?php else: ?>
            </div>
            <?php endif; ?>
    <?php endforeach; ?>

    <div class="admin-sidebar__bas">
        <?php if ($roleSidebar === 'admin'): ?>
            <div class="admin-sidebar__recherche-outils">
                <label for="admin-recherche-outils">Rechercher un outil</label>
                <div class="admin-sidebar__recherche-champ">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m16 16 4 4"></path></svg>
                    <input id="admin-recherche-outils" type="search" placeholder="Ex. paiements, clients..." autocomplete="off" aria-autocomplete="list" aria-controls="admin-recherche-outils-resultats" aria-expanded="false">
                    <kbd aria-hidden="true">↵</kbd>
                </div>
                <div class="admin-sidebar__recherche-resultats" id="admin-recherche-outils-resultats" role="listbox" hidden></div>
                <a class="admin-sidebar__recherche-catalogue" href="/admin/outils">Parcourir tous les outils</a>
            </div>
        <?php endif; ?>
        <a href="<?= htmlspecialchars($lienProfil, ENT_QUOTES, 'UTF-8') ?>" class="admin-sidebar__lien <?= $pageActuelle === 'profil.php' ? 'admin-sidebar__lien--actif' : '' ?>">
            <span class="admin-sidebar__icone"><?= icone('user', 18) ?></span> Mon profil
        </a>
        <a href="../../public/deconnexion.php" class="admin-sidebar__lien"><span class="admin-sidebar__icone"><?= icone('logout', 18) ?></span> Déconnexion</a>
    </div>
</div>

<!-- Voile derrière la sidebar (mobile) et bouton pour la ré-afficher -->
<div class="admin-sidebar__voile" id="sidebar-voile"></div>
<button type="button" class="admin-sidebar__ouvrir" id="sidebar-ouvrir" aria-label="Afficher le menu" aria-expanded="false" title="Afficher le menu">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
</button>
<a class="admin-sidebar__site-link" href="accueil.php" aria-label="ALLÔ PRO — Accueil">
    ALLÔ<span> PRO</span>
</a>
<div class="admin-sidebar__top-actions">
    <?php if ($pageActuelle !== 'accueil.php'): ?>
    <span class="admin-sidebar__nom-utilisateur" title="<?= htmlspecialchars($_SESSION['nom'] ?? 'Admin', ENT_QUOTES, 'UTF-8') ?>">
        <?= htmlspecialchars($_SESSION['nom'] ?? 'Admin', ENT_QUOTES, 'UTF-8') ?>
    </span>
    <?php endif; ?>
    <button type="button" class="admin-sidebar__theme-top" id="theme-toggle-top" role="switch" aria-checked="false" aria-label="Passer en mode sombre" title="Passer en mode sombre">
        <svg class="theme-ico theme-ico--lune" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
        <svg class="theme-ico theme-ico--soleil" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
    </button>
</div>

<?php if ($roleSidebar === 'admin'): ?>
<script>
(function () {
    if (window.adminOutilsRechercheInitialisee) return;
    window.adminOutilsRechercheInitialisee = true;

    var champ = document.getElementById('admin-recherche-outils');
    var resultats = document.getElementById('admin-recherche-outils-resultats');
    if (!champ || !resultats) return;
    var cleNouvelOnglet = 'allopro_admin_outils_nouvel_onglet';
    var cleUtilisation = 'allopro_admin_outils_utilisation';

    function nouvelOngletActive() {
        try { return localStorage.getItem(cleNouvelOnglet) === '1'; } catch (erreur) { return false; }
    }

    function appliquerOuverture(lien) {
        if (nouvelOngletActive()) {
            lien.target = '_blank';
            lien.rel = 'noopener noreferrer';
        }
    }

    function cleOutil(lien) {
        return new URL(lien.href, window.location.href).pathname;
    }

    document.querySelectorAll('.admin-sidebar details a.admin-sidebar__lien').forEach(appliquerOuverture);

    document.addEventListener('click', function (evenement) {
        var cible = evenement.target instanceof Element ? evenement.target : evenement.target.parentElement;
        var lien = cible && cible.closest('.admin-sidebar details a.admin-sidebar__lien, .admin-sidebar__recherche-resultats a:not(.admin-sidebar__recherche-tout)');
        if (!lien) return;
        try {
            var utilisation = JSON.parse(localStorage.getItem(cleUtilisation) || '{}');
            if (!utilisation || typeof utilisation !== 'object' || Array.isArray(utilisation)) utilisation = {};
            var cle = cleOutil(lien);
            utilisation[cle] = (Number(utilisation[cle]) || 0) + 1;
            localStorage.setItem(cleUtilisation, JSON.stringify(utilisation));
        } catch (erreur) {
            return;
        }
    });

    function fermer() {
        resultats.hidden = true;
        champ.setAttribute('aria-expanded', 'false');
    }

    function rechercher() {
        var terme = champ.value.trim().toLocaleLowerCase('fr');
        resultats.replaceChildren();
        if (!terme) {
            fermer();
            return;
        }

        var liens = Array.from(document.querySelectorAll('.admin-sidebar a.admin-sidebar__lien'))
            .filter(function (lien) { return lien.querySelector('.admin-sidebar__icone'); })
            .filter(function (lien) { return lien.textContent.trim().toLocaleLowerCase('fr').includes(terme); })
            .slice(0, 6);

        if (liens.length === 0) {
            var vide = document.createElement('p');
            vide.className = 'admin-sidebar__recherche-vide';
            vide.textContent = 'Aucun outil trouvé.';
            resultats.appendChild(vide);
        } else {
            liens.forEach(function (lien) {
                var resultat = document.createElement('a');
                resultat.href = lien.href;
                resultat.setAttribute('role', 'option');
                resultat.textContent = lien.textContent.trim();
                appliquerOuverture(resultat);
                resultats.appendChild(resultat);
            });
        }

        var toutVoir = document.createElement('a');
        toutVoir.className = 'admin-sidebar__recherche-tout';
        toutVoir.href = '/admin/outils?q=' + encodeURIComponent(champ.value.trim());
        toutVoir.textContent = 'Voir tous les outils';
        resultats.appendChild(toutVoir);
        resultats.hidden = false;
        champ.setAttribute('aria-expanded', 'true');
    }

    champ.addEventListener('input', rechercher);
    champ.addEventListener('keydown', function (evenement) {
        if (evenement.key === 'Escape') fermer();
        if (evenement.key === 'Enter' && champ.value.trim() && !resultats.hidden) {
            evenement.preventDefault();
            window.location.href = '/admin/outils?q=' + encodeURIComponent(champ.value.trim());
        }
    });
    document.addEventListener('click', function (evenement) {
        if (!resultats.contains(evenement.target) && evenement.target !== champ) fermer();
    });
})();
</script>
<?php endif; ?>

<script data-admin-shell-script>
(function () {
    const html = document.documentElement;
    const boutons = [document.getElementById('theme-toggle'), document.getElementById('theme-toggle-top')].filter(Boolean);
    if (!boutons.length) return;
    const reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function appliquer(theme, animer) {
        if (animer && !reduit) {
            html.classList.add('theme-anim');
            setTimeout(() => html.classList.remove('theme-anim'), 350);
        }
        html.setAttribute('data-theme', theme);
        const sombre = theme === 'dark';
        boutons.forEach((bouton) => {
            bouton.setAttribute('aria-checked', sombre ? 'true' : 'false');
            bouton.setAttribute('aria-label', sombre ? 'Passer en mode clair' : 'Passer en mode sombre');
            bouton.title = sombre ? 'Passer en mode clair' : 'Passer en mode sombre';
        });
    }
    appliquer(html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light', false);

    boutons.forEach((bouton) => bouton.addEventListener('click', () => {
        const suivant = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        appliquer(suivant, true);
        try { localStorage.setItem('allopro_theme', suivant); } catch (e) {}
    }));
    // Synchronisation entre onglets (et avec l'espace client : même clé)
    window.addEventListener('storage', (e) => {
        if (e.key === 'allopro_theme' && (e.newValue === 'dark' || e.newValue === 'light')) appliquer(e.newValue, false);
    });
})();
</script>

<script data-admin-shell-script>
// Afficher / masquer la sidebar
(function () {
    const html = document.documentElement;
    const sidebar = document.querySelector('.admin-sidebar');
    const ouvrir = document.getElementById('sidebar-ouvrir');
    const fermer = document.getElementById('sidebar-fermer');
    const voile = document.getElementById('sidebar-voile');
    if (!sidebar || !ouvrir || !fermer || !voile) return;
    const mobile = window.matchMedia('(max-width: 1024px)');

    const estFermee = () => html.classList.contains('sidebar-fermee');
    function definir(fermee, memoriser) {
        html.classList.toggle('sidebar-fermee', fermee);
        ouvrir.setAttribute('aria-expanded', fermee ? 'false' : 'true');
        // Le choix n'est mémorisé que sur grand écran (sur mobile, le menu est toujours fermé au départ)
        if (memoriser && !mobile.matches) { try { localStorage.setItem('allopro_sidebar', fermee ? 'closed' : 'open'); } catch (e) {} }
    }
    definir(estFermee(), false);

    ouvrir.addEventListener('click', () => { definir(false, true); fermer.focus(); });
    fermer.addEventListener('click', () => { definir(true, true); ouvrir.focus(); });
    voile.addEventListener('click', () => { definir(true, false); ouvrir.focus(); });
    sidebar.querySelectorAll('.admin-sidebar__lien').forEach((a) => a.addEventListener('click', () => { if (mobile.matches) definir(true, false); }));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mobile.matches && !estFermee()) { definir(true, false); ouvrir.focus(); }
    });

    // Passage mobile <-> bureau (rotation d'une tablette, redimensionnement)
    const surChangement = () => {
        if (mobile.matches) { definir(true, false); return; }
        let pref = null; try { pref = localStorage.getItem('allopro_sidebar'); } catch (e) {}
        definir(pref === 'closed', false);
    };
    if (mobile.addEventListener) mobile.addEventListener('change', surChangement); else mobile.addListener(surChangement);
})();
</script>

<script src="../../public/js/messagerie-interne-notifications.js?v=<?= filemtime(__DIR__ . '/../public/js/messagerie-interne-notifications.js') ?>" defer></script>
<?php if ($roleSidebar === 'admin'): ?>
<script src="../../public/js/admin-sidebar-notifications.js?v=<?= filemtime(__DIR__ . '/../public/js/admin-sidebar-notifications.js') ?>" defer></script>
<script src="../../public/js/admin-navigation-dynamique.js?v=<?= md5_file(__DIR__ . '/../public/js/admin-navigation-dynamique.js') ?>" defer></script>
<?php endif; ?>
<?php if (in_array($_SESSION['role'] ?? '', ['conseiller', 'finance'], true)): ?>
<script src="../../public/js/presence-conseiller.js?v=<?= filemtime(__DIR__ . '/../public/js/presence-conseiller.js') ?>" defer></script>
<?php endif; ?>