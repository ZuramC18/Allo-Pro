<?php
$pageCoordinateur = basename($_SERVER['PHP_SELF'] ?? '');
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
if (!isset($nombreAjustementsCreneaux)) {
    require_once __DIR__ . '/../models/AjustementCreneauAutomatique.php';
    $nombreAjustementsCreneaux = (new AjustementCreneauAutomatique())->compterATraiter();
}
$navCoordinateur = [
    'Pilotage' => [
        ['equipe', 'Ma journée', 'grid'],
        ['index.php', 'Tableau opérationnel', 'grid'],
        ['recherche.php', 'Recherche de dossiers', 'search'],
        ['demandes.php', 'Demandes qualifiées', 'inbox'],
        ['missions.php', 'Missions', 'route'],
        ['attributions-automatiques.php', 'Attributions automatiques', 'refresh'],
        ['ajustements-creneaux.php', 'Changements de créneaux', 'calendar'],
        ['taches.php', 'Mes tâches', 'tasks'],
        ['refus-interventions.php', 'Refus à réaffecter', 'refresh'],
        ['sav.php', 'Tickets SAV', 'sav'],
    ],
    'Ressources' => [
        ['ressources.php', 'Partenaires & techniciens', 'people'],
        ['performance.php', 'Performance partenaires', 'chart'],
    ],
    'Équipe' => [
        ['conversations.php', 'Conversations', 'chat'],
        ['messagerie.php', 'Messagerie clients', 'chat'],
        ['autorisations-appels-techniciens.php', 'Appels clients', 'chat'],
        ['messagerie-interne.php', 'Messagerie interne', 'chat'],
    ],
    'Mon espace' => [
        ['profil.php', 'Mon profil', 'profile'],
    ],
];
$iconesCoordinateur = [
    'grid' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    'inbox' => '<path d="M4 4h16v16H4z"/><path d="M4 13h4l2 3h4l2-3h4"/>',
    'route' => '<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h3a3 3 0 0 0 3-3V9a3 3 0 0 1 3-3"/>',
    'refresh' => '<path d="M20 7v5h-5"/><path d="M4 17v-5h5"/><path d="M5.6 9a7 7 0 0 1 11.6-2L20 12M4 12l2.8 5a7 7 0 0 0 11.6-2"/>',
    'people' => '<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    'chart' => '<path d="M4 19V5m0 14h16"/><path d="m7 15 4-4 3 2 5-6"/>',
    'chat' => '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>',
    'profile' => '<circle cx="12" cy="8" r="4"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/>',
    'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    'tasks' => '<path d="M9 5h10a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h1"/><path d="M9 3h6v4H9zM9 12h8M9 16h8"/>',
    'sav' => '<path d="M12 8v4l2.5 2.5"/><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6 4 4m14.4 1.6L20 4"/>',
    'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
];
?>
<div class="coord-mobile-bar">
    <strong>ALLÔ PRO · Coordination</strong>
    <button type="button" id="coord-menu-toggle" aria-controls="coord-sidebar-nav" aria-expanded="false">Menu</button>
</div>
<button type="button" class="coord-mobile-fond" id="coord-menu-fond" aria-label="Fermer la navigation"></button>
<aside class="coord-sidebar-nav" id="coord-sidebar-nav">
    <a class="coord-sidebar-nav__marque" href="index.php" aria-label="ALLÔ PRO, tableau opérationnel">
        <span class="coord-sidebar-nav__logo">A</span>
        <span>ALLÔ <strong>PRO</strong><small>ESPACE COORDINATEUR</small></span>
    </a>
    <nav aria-label="Navigation coordinateur">
        <?php foreach ($navCoordinateur as $groupe => $liens): ?>
            <div class="coord-sidebar-nav__groupe">
                <span class="coord-sidebar-nav__titre"><?= htmlspecialchars($groupe, ENT_QUOTES, 'UTF-8') ?></span>
                <?php foreach ($liens as [$fichier, $libelle, $icone]):
                    $actif = basename($fichier) === $pageCoordinateur
                        || ($fichier === 'demandes.php' && $pageCoordinateur === 'traiter-demande.php' && empty($intervention))
                        || ($fichier === 'missions.php' && $pageCoordinateur === 'traiter-demande.php' && !empty($intervention));
                ?>
                    <a class="coord-sidebar-nav__lien <?= $actif ? 'actif' : '' ?>"
                       href="<?= htmlspecialchars($fichier, ENT_QUOTES, 'UTF-8') ?>"
                       <?= $fichier === 'messagerie-interne.php' ? 'data-mi-notification' : '' ?>
                       <?= $actif ? 'aria-current="page"' : '' ?>>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><?= $iconesCoordinateur[$icone] ?></svg>
                        <span><?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?></span>
                        <?php if ($fichier === 'demandes.php'): ?><span class="mi-sidebar-badge coord-demandes-badge" data-coordinateur-demandes-badge hidden></span><?php endif; ?>
                        <?php if ($fichier === 'ajustements-creneaux.php'): ?><span class="mi-sidebar-badge" data-ajustements-creneaux-badge data-count="<?= (int) ($nombreAjustementsCreneaux ?? 0) ?>" <?= empty($nombreAjustementsCreneaux) ? 'hidden' : '' ?>><?= (int) ($nombreAjustementsCreneaux ?? 0) ?></span><?php endif; ?>
                        <?php if ($fichier === 'messagerie-interne.php'): ?><span class="mi-sidebar-badge" data-mi-badge hidden></span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </nav>
    <div class="coord-sidebar-nav__pied">
        <span><?= htmlspecialchars($_SESSION['nom'] ?? 'Coordinateur', ENT_QUOTES, 'UTF-8') ?></span>
        <div class="sidebar__presence presence-equipe" data-csrf="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
            <label class="sidebar__presence-label" for="statut-presence-conseiller">Mon statut</label>
            <div class="sidebar__presence-select-wrap">
                <span class="sidebar__presence-point" aria-hidden="true"></span>
                <select id="statut-presence-conseiller" class="sidebar__presence-select" aria-label="Choisir mon statut de présence">
                    <option value="online">En ligne</option>
                    <option value="pause">En pause</option>
                    <option value="offline" selected>Hors ligne</option>
                </select>
            </div>
            <button type="button" class="sidebar__presence-en-ligne" data-presence-en-ligne>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2v5"/><path d="M7.5 4.8a9 9 0 1 0 9 0"/></svg>
                <span data-presence-button-label>Se mettre en ligne</span>
            </button>
            <span class="sidebar__presence-message" id="presence-message" role="status" aria-live="polite" hidden></span>
        </div>
        <button type="button" class="coord-navbar__theme" id="coord-theme-toggle" aria-label="Passer en mode sombre" title="Passer en mode sombre">
            <svg class="coord-theme-ico coord-theme-ico--lune" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
            <svg class="coord-theme-ico coord-theme-ico--soleil" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
            <span class="coord-navbar__theme-libelle">Mode sombre</span>
        </button>
        <a href="../../public/deconnexion.php">Déconnexion</a>
    </div>
</aside>
<script>
(function () {
    var sidebar = document.getElementById('coord-sidebar-nav');
    var toggle = document.getElementById('coord-menu-toggle');
    var fond = document.getElementById('coord-menu-fond');
    if (!sidebar || !toggle || !fond) return;
    function fermer() {
        sidebar.classList.remove('coord-sidebar-nav--ouverte');
        fond.classList.remove('coord-mobile-fond--visible');
        toggle.setAttribute('aria-expanded', 'false');
    }
    toggle.addEventListener('click', function () {
        var ouverte = sidebar.classList.toggle('coord-sidebar-nav--ouverte');
        fond.classList.toggle('coord-mobile-fond--visible', ouverte);
        toggle.setAttribute('aria-expanded', ouverte ? 'true' : 'false');
    });
    fond.addEventListener('click', fermer);
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') fermer();
    });
    var theme = document.getElementById('coord-theme-toggle');
    if (theme && <?= json_encode($pageCoordinateur !== 'conversations.php') ?>) {
        function actualiserTheme(sombre) {
            if (sombre) document.documentElement.setAttribute('data-theme', 'dark');
            else document.documentElement.removeAttribute('data-theme');
            theme.setAttribute('aria-checked', String(sombre));
            theme.setAttribute('aria-label', sombre ? 'Passer en mode clair' : 'Passer en mode sombre');
            theme.title = sombre ? 'Passer en mode clair' : 'Passer en mode sombre';
            var libelle = theme.querySelector('.coord-navbar__theme-libelle');
            if (libelle) libelle.textContent = sombre ? 'Mode clair' : 'Mode sombre';
        }
        actualiserTheme(document.documentElement.getAttribute('data-theme') === 'dark');
        theme.addEventListener('click', function () {
            var sombre = document.documentElement.getAttribute('data-theme') !== 'dark';
            actualiserTheme(sombre);
            try { localStorage.setItem('allopro_theme', sombre ? 'dark' : 'light'); } catch (e) {}
        });
    }
})();
</script>
<link rel="stylesheet" href="../../public/css/presence-equipe.css?v=<?= filemtime(__DIR__ . '/../public/css/presence-equipe.css') ?>">
<script src="../../public/js/presence-conseiller.js?v=<?= filemtime(__DIR__ . '/../public/js/presence-conseiller.js') ?>" defer></script>
<script src="../../public/js/messagerie-interne-notifications.js?v=<?= filemtime(__DIR__ . '/../public/js/messagerie-interne-notifications.js') ?>" defer></script>
<script src="../../public/js/coordinateur-demandes-notifications.js?v=<?= filemtime(__DIR__ . '/../public/js/coordinateur-demandes-notifications.js') ?>" defer></script>
