
<?php require_once __DIR__ . '/acces.php'; afficherFlashAcces(); ?>
<div class="sidebar">
    <a href="../../public/index.php" style="text-decoration:none; color:inherit; display:block;" class="sidebar__logo">ALLÔ PRO</a>
    <a href="accueil.php" class="sidebar__lien <?= basename($_SERVER['PHP_SELF']) === 'accueil.php' ? 'sidebar__lien--actif' : '' ?>">Accueil</a>
    <a href="messagerie.php" class="sidebar__lien <?= basename($_SERVER['PHP_SELF']) === 'messagerie.php' ? 'sidebar__lien--actif' : '' ?>">Messages</a>
    <a href="nouvelle-demande.php" class="sidebar__lien <?= basename($_SERVER['PHP_SELF']) === 'nouvelle-demande.php' ? 'sidebar__lien--actif' : '' ?>">Nouvelle demande</a>
    <a href="mes-demandes.php" class="sidebar__lien <?= basename($_SERVER['PHP_SELF']) === 'mes-demandes.php' ? 'sidebar__lien--actif' : '' ?>">Mes demandes</a>
    <a href="ajouter-adresse.php" class="sidebar__lien <?= basename($_SERVER['PHP_SELF']) === 'ajouter-adresse.php' ? 'sidebar__lien--actif' : '' ?>">Mes adresses</a>
    <a href="../../public/deconnexion.php" class="sidebar__lien">Déconnexion</a>
</div>