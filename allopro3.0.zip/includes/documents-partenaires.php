<?php
const VERSION_DOCUMENTS_PARTENAIRE = '2026-10-07-v1';

function sectionsContratPartenaire(array $partenaire): array {
    return [
        [
            'titre' => '1. Parties et objet',
            'paragraphes' => [
                'Le présent projet de contrat est conclu entre ALLÔ PRO, plateforme de mise en relation et de coordination de services, et ' . (string) ($partenaire['nom_entreprise'] ?? '[Nom de l’entreprise partenaire]') . ', représentée par ' . (string) ($partenaire['nom_representant'] ?? '[Nom du représentant]') . '.',
                'Il décrit le cadre de collaboration applicable à la présentation de demandes d’intervention et à leur prise en charge par le partenaire et ses techniciens.',
            ],
        ],
        [
            'titre' => '2. Rôle de la plateforme',
            'paragraphes' => [
                'ALLÔ PRO reçoit et transmet des demandes, facilite les échanges entre les clients et les partenaires, et met à disposition des outils de suivi des interventions.',
                'La transmission d’une demande ne garantit ni un volume minimal de missions, ni l’acceptation d’une demande par le partenaire.',
            ],
        ],
        [
            'titre' => '3. Engagements du partenaire',
            'paragraphes' => [
                'Le partenaire veille à l’exactitude des informations de son compte, à l’actualisation de son équipe et à la disponibilité des techniciens qu’il déclare.',
                'Pour chaque intervention acceptée, le partenaire organise une prestation professionnelle, informe le client de son avancement, respecte les consignes communiquées et renseigne les éléments de suivi demandés dans l’espace partenaire.',
                'Le partenaire reste responsable de la sélection, de l’encadrement et des actes de ses techniciens ainsi que des autorisations, qualifications et assurances nécessaires à son activité.',
            ],
        ],
        [
            'titre' => '4. Relations avec les clients',
            'paragraphes' => [
                'Le partenaire et ses techniciens traitent les coordonnées et informations des clients uniquement pour préparer, réaliser et suivre l’intervention concernée, et en préservent la confidentialité.',
                'Le partenaire informe le client des modalités pratiques de l’intervention et de tout coût qui lui incombe avant la réalisation de travaux payants. Les modalités précises de devis, de paiement, de garanties et de réclamation restent à compléter et à valider pour la version définitive.',
            ],
        ],
        [
            'titre' => '5. Rémunération et frais',
            'paragraphes' => [
                'Les commissions, frais de service, modalités de facturation et délais de reversement applicables doivent être précisés dans une grille financière validée et communiquée au partenaire avant l’entrée en vigueur du contrat définitif.',
                'Les paramètres affichés dans l’espace partenaire ne remplacent pas cette grille contractuelle.',
            ],
        ],
        [
            'titre' => '6. Données et confidentialité',
            'paragraphes' => [
                'Chaque partie limite l’accès aux informations reçues aux personnes qui en ont besoin pour leurs missions et met en œuvre des mesures adaptées pour empêcher leur divulgation ou leur utilisation non autorisée.',
                'À la fin d’une intervention ou de la collaboration, le partenaire cesse d’utiliser les informations client qui ne sont plus nécessaires, sous réserve des obligations légales de conservation qui lui sont applicables.',
            ],
        ],
        [
            'titre' => '7. Durée, suspension et fin de collaboration',
            'paragraphes' => [
                'La durée de la collaboration, les conditions de renouvellement, de suspension et de résiliation, ainsi que le traitement des interventions en cours, devront être précisés dans la version définitive du présent contrat.',
            ],
        ],
        [
            'titre' => '8. Projet à compléter',
            'paragraphes' => [
                'Ce document est une première trame de travail. Les identités légales complètes, coordonnées de notification, règles financières, garanties, responsabilités, modalités de règlement des différends et droit applicable doivent être vérifiés et complétés avant toute publication définitive.',
            ],
        ],
    ];
}

function sectionsConditionsGeneralesPartenaire(): array {
    return [
        [
            'titre' => '1. Objet des conditions',
            'paragraphes' => [
                'Ces conditions générales de travail décrivent, sous forme de projet, les règles d’utilisation de l’espace partenaire ALLÔ PRO. Elles devront être complétées et validées avant leur publication définitive.',
            ],
        ],
        [
            'titre' => '2. Compte partenaire',
            'paragraphes' => [
                'Le partenaire fournit des informations exactes lors de la création et de la mise à jour de son compte, protège ses identifiants et signale sans délai toute utilisation non autorisée.',
                'Le partenaire maintient à jour son profil, ses coordonnées, ses zones d’intervention et les informations des techniciens associés à son équipe.',
            ],
        ],
        [
            'titre' => '3. Utilisation de l’espace',
            'paragraphes' => [
                'L’espace partenaire sert à consulter et traiter les demandes confiées, suivre les interventions, gérer les techniciens et communiquer les informations utiles au suivi du service.',
                'Le partenaire n’utilise pas l’espace pour transmettre des contenus illicites, trompeurs, malveillants ou sans rapport avec les services concernés.',
            ],
        ],
        [
            'titre' => '4. Demandes et interventions',
            'paragraphes' => [
                'Le partenaire examine les demandes qui lui sont proposées et tient à jour leur état dans l’espace. Une demande attribuée n’est considérée comme prise en charge qu’après la confirmation prévue par l’application.',
                'Le partenaire veille à ce que les informations renseignées sur l’intervention soient sincères, suffisamment précises et limitées à ce qui est nécessaire.',
            ],
        ],
        [
            'titre' => '5. Techniciens et qualité de service',
            'paragraphes' => [
                'Le partenaire est responsable de l’habilitation de ses techniciens à accéder à l’espace et retire leurs accès lorsqu’ils ne sont plus autorisés à agir pour son compte.',
                'Il organise les interventions avec diligence, courtoisie et professionnalisme et signale les incidents ou retards affectant le client ou la plateforme.',
            ],
        ],
        [
            'titre' => '6. Confidentialité et données personnelles',
            'paragraphes' => [
                'Les données des clients sont consultées et utilisées uniquement pour répondre à leur demande. Elles ne sont ni copiées dans des fichiers non protégés, ni communiquées à des tiers non autorisés, ni réutilisées à des fins de prospection indépendante.',
                'Le partenaire protège les appareils et comptes utilisés pour accéder aux données et informe ALLÔ PRO de tout incident susceptible de les compromettre.',
            ],
        ],
        [
            'titre' => '7. Disponibilité et évolutions',
            'paragraphes' => [
                'ALLÔ PRO s’efforce de maintenir l’accès à l’espace et peut le faire évoluer pour assurer son fonctionnement et améliorer le service. Des interruptions temporaires peuvent survenir notamment pour maintenance ou en cas de difficulté technique.',
                'Les modalités de support, de disponibilité garantie et de responsabilité en cas d’interruption restent à définir dans la version définitive.',
            ],
        ],
        [
            'titre' => '8. Conditions commerciales et fin d’accès',
            'paragraphes' => [
                'Les commissions, frais, paiements, conditions de suspension ou de clôture du compte et conséquences sur les interventions en cours doivent être précisés dans le contrat et les documents commerciaux définitifs.',
            ],
        ],
        [
            'titre' => '9. Projet à compléter',
            'paragraphes' => [
                'Cette première version ne remplace pas les vérifications juridiques nécessaires. Les mentions légales de l’éditeur, les coordonnées de contact, le droit applicable, les recours, la durée de conservation des données et les modalités de modification des conditions doivent être ajoutés avant publication.',
            ],
        ],
    ];
}
