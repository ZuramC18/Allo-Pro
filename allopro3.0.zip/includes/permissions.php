<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/roles.php';
require_once __DIR__ . '/audit.php';
require_once __DIR__ . '/helpers.php';

// Recharge rôle et statut réels depuis la base à chaque page — la session ne fait plus foi seule
function rafraichirCompteConnecte() {
    if (!isset($_SESSION['user_id'])) return;

    $stmt = (new Database())->getConnection()->prepare(
        "SELECT nom, role, statut, photo_profil, avatar_initiales FROM users WHERE id = :id"
    );
    $stmt->execute([':id' => $_SESSION['user_id']]);
    $u = $stmt->fetch();

    if (!$u) {
        session_unset();
        session_destroy();
        header("Location: /allopro/public/connexion.php?raison=compte_introuvable");
        exit;
    }

    if ($u['statut'] === 'suspendu') {
        journaliser('session.coupee', 'compte', $_SESSION['user_id'], $_SESSION['nom'] ?? null, 'Compte suspendu pendant une session active');
        session_unset();
        session_destroy();
        header("Location: /allopro/public/connexion.php?raison=suspendu");
        exit;
    }

    if ($_SESSION['role'] !== $u['role']) {
        journaliser('session.role_actualise', 'compte', $_SESSION['user_id'], $u['nom'], $_SESSION['role'] . ' → ' . $u['role']);
        $_SESSION['role'] = $u['role'];
    }

    $_SESSION['nom'] = $u['nom'];
    $_SESSION['photo_profil'] = $u['photo_profil'];
    $_SESSION['avatar_initiales'] = (bool) $u['avatar_initiales'];

}

function permissionsDuRole($role) {
    static $cache = [];
    if ($role === 'admin') return array_merge(array_keys(MODULES), MODULES_ADMIN_SEULEMENT);
    if (!in_array($role, ROLES_INTERNES, true)) return [];

    if (!isset($cache[$role])) {
        $stmt = (new Database())->getConnection()->prepare("SELECT module FROM role_permissions WHERE role = :role");
        $stmt->execute([':role' => $role]);
        $cache[$role] = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    return $cache[$role];
}

function peut($module) {
    rafraichirCompteConnecte();
    $role = $_SESSION['role'] ?? null;
    if (!$role) return false;
    return in_array($module, permissionsDuRole($role), true);
}

function verifierAcces($module) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /allopro/public/connexion.php");
        exit;
    }
    rafraichirCompteConnecte(); // peut() la rappelle aussi, mais ça reste bon marché et évite tout oubli
    if (!peut($module)) {
        require_once __DIR__ . '/acces.php';
        refuserAcces();
    }
}

function pageAccueilPourRole($role) {
    switch ($role) {
        case 'client':       return '/allopro/views/client/accueil.php';
        case 'conseiller':   return '/allopro/views/conseiller/liste-demandes.php';
        case 'coordinateur': return '/allopro/views/coordinateur/index.php';
        case 'qualite':      return '/allopro/views/qualite/accueil.php';
        case 'finance':      return '/allopro/views/finance/accueil.php';
        default:             return '/allopro/views/admin/accueil.php';
    }
}
