<?php
require_once __DIR__ . '/../models/AutorisationAppelTechnicien.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
$messageAutorisation = '';
$erreurAutorisation = '';
$rechercheAutorisation = mb_substr(trim((string) ($_GET['q'] ?? $_POST['q'] ?? '')), 0, 100, 'UTF-8');
$roleGestionnaireAppel = (string) ($_SESSION['role'] ?? '');
$texteRoleAppel = $roleGestionnaireAppel === 'admin' ? 'Administrateur' : 'Coordinateur';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf'], $csrf)) {
        http_response_code(403);
        $erreurAutorisation = 'La session du formulaire a expiré. Rechargez la page puis réessayez.';
    } else {
        $interventionId = filter_var($_POST['intervention_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $actionAutorisation = (string) ($_POST['action'] ?? '');
        if (!$interventionId || !in_array($actionAutorisation, ['autoriser', 'revoquer'], true)) {
            http_response_code(400);
            $erreurAutorisation = 'La mission ou l’action demandée est invalide.';
        } else {
            try {
                $modifie = (new AutorisationAppelTechnicien())->modifier(
                    $interventionId,
                    $actionAutorisation === 'autoriser',
                    (int) $_SESSION['user_id'],
                    $roleGestionnaireAppel
                );
                if (!$modifie) {
                    http_response_code(409);
                    $erreurAutorisation = 'La mission est terminée, a été réaffectée ou ne permet plus cette autorisation.';
                } else {
                    journaliser(
                        $actionAutorisation === 'autoriser' ? 'appel_web.technicien_autorise' : 'appel_web.technicien_autorisation_revoquee',
                        'intervention',
                        $interventionId,
                        null,
                        ucfirst($actionAutorisation) . ' par ' . $roleGestionnaireAppel . ' ID ' . (int) $_SESSION['user_id']
                    );
                    header('Location: ' . basename($_SERVER['PHP_SELF']) . '?' . http_build_query(array_filter([
                        'resultat' => $actionAutorisation,
                        'q' => $rechercheAutorisation !== '' ? $rechercheAutorisation : null,
                    ])));
                    exit;
                }
            } catch (Throwable $exception) {
                error_log('[autorisation appel technicien] ' . $exception->getMessage());
                http_response_code(500);
                $erreurAutorisation = 'L’autorisation n’a pas pu être enregistrée. Réessayez.';
            }
        }
    }
}

try {
    $missionsAppel = (new AutorisationAppelTechnicien())->listerMissions($rechercheAutorisation);
} catch (Throwable $exception) {
    error_log('[liste autorisations appel technicien] ' . $exception->getMessage());
    http_response_code(500);
    $missionsAppel = [];
    $erreurAutorisation = 'La liste des missions est momentanément indisponible.';
}
$nombreMissionsAutorisees = count(array_filter(
    $missionsAppel,
    static fn(array $mission): bool => !empty($mission['autorisation_id'])
));
$nombreMissionsSansAutorisation = count($missionsAppel) - $nombreMissionsAutorisees;
$echapperAutorisation = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
?>
<div class="admin-contenu autorisations-appels-page">
    <div class="admin-entete">
        <div class="autorisation-appel__intro">
            <span class="autorisation-appel__icone" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M2 10v4m4-7v10m4-13v16m4-12v8m4-11v14m4-9v4"/>
                </svg>
            </span>
            <div>
                <div class="autorisation-appel__sur-titre">Appels clients</div>
                <div class="admin-entete__titre">Accès aux appels clients</div>
                <div class="admin-entete__sous-titre">Gérez l’accès à l’appel audio web entre le technicien et son client, mission par mission.</div>
            </div>
        </div>
    </div>

    <?php if (($_GET['resultat'] ?? '') === 'autoriser'): ?>
        <div class="admin-badge admin-badge--vert">L’autorisation exceptionnelle a été accordée.</div>
    <?php elseif (($_GET['resultat'] ?? '') === 'revoquer'): ?>
        <div class="admin-badge admin-badge--gris">L’autorisation a été révoquée.</div>
    <?php endif; ?>
    <?php if ($erreurAutorisation !== ''): ?>
        <p class="autorisation-appel__message autorisation-appel__message--erreur" role="alert"><?= $echapperAutorisation($erreurAutorisation) ?></p>
    <?php endif; ?>

    <section class="autorisation-appel__resume" aria-label="Résumé des autorisations">
        <article class="autorisation-appel__indicateur">
            <span class="autorisation-appel__indicateur-icone autorisation-appel__indicateur-icone--total" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v14H4z"/><path d="M8 9h8m-8 4h5"/></svg>
            </span>
            <span class="autorisation-appel__indicateur-texte"><span>Missions affichées</span><strong><?= count($missionsAppel) ?></strong></span>
        </article>
        <article class="autorisation-appel__indicateur">
            <span class="autorisation-appel__indicateur-icone autorisation-appel__indicateur-icone--autorise" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11.1V12a8 8 0 1 1-4.7-7.3"/><path d="m8.5 11.5 3 3L21 5"/></svg>
            </span>
            <span class="autorisation-appel__indicateur-texte"><span>Autorisations actives</span><strong><?= $nombreMissionsAutorisees ?></strong></span>
        </article>
        <article class="autorisation-appel__indicateur">
            <span class="autorisation-appel__indicateur-icone autorisation-appel__indicateur-icone--attente" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
            </span>
            <span class="autorisation-appel__indicateur-texte"><span>À autoriser</span><strong><?= $nombreMissionsSansAutorisation ?></strong></span>
        </article>
    </section>

    <section class="autorisation-appel__liste" aria-labelledby="autorisation-appel-titre-liste">
        <div class="autorisation-appel__liste-entete">
            <div>
                <h2 id="autorisation-appel-titre-liste">Missions concernées</h2>
                <p>Retrouvez une mission et modifiez son accès à l’appel web.</p>
            </div>
            <form method="get" class="admin-recherche autorisation-appel__recherche" role="search">
                <label class="visually-hidden" for="recherche-autorisation-appel">Rechercher une mission, un client ou un technicien</label>
                <span class="autorisation-appel__champ-recherche">
                    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg>
                    <input id="recherche-autorisation-appel" type="search" name="q" maxlength="100"
                           value="<?= $echapperAutorisation($rechercheAutorisation) ?>"
                           placeholder="Dossier, client, technicien…">
                </span>
                <button type="submit">Rechercher</button>
                <?php if ($rechercheAutorisation !== ''): ?>
                    <a class="admin-recherche__reset" href="<?= $echapperAutorisation(basename($_SERVER['PHP_SELF'])) ?>">Effacer</a>
                <?php endif; ?>
            </form>
        </div>
        <?php if ($rechercheAutorisation !== ''): ?>
            <p class="autorisation-appel__resultats" role="status"><?= count($missionsAppel) ?> mission<?= count($missionsAppel) === 1 ? '' : 's' ?> trouvée<?= count($missionsAppel) === 1 ? '' : 's' ?> pour « <?= $echapperAutorisation($rechercheAutorisation) ?> »</p>
        <?php endif; ?>

    <div class="admin-panneau autorisation-appel__panneau">
        <div class="admin-table-wrapper">
            <table class="admin-table autorisations-appels-table">
                <thead>
                    <tr>
                        <th>Mission</th>
                        <th>Client</th>
                        <th>Technicien</th>
                        <th>Statut mission</th>
                        <th>Autorisation</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$missionsAppel): ?>
                        <tr><td class="autorisation-appel__vide" colspan="6">
                            <span class="autorisation-appel__vide-icone" aria-hidden="true">♪</span>
                            <strong><?= $rechercheAutorisation !== '' ? 'Aucun résultat' : 'Aucune mission à traiter' ?></strong>
                            <span><?= $rechercheAutorisation !== '' ? 'Essayez avec un autre dossier, client ou technicien.' : 'Les missions client actives avec un technicien affecté apparaîtront ici.' ?></span>
                        </td></tr>
                    <?php endif; ?>
                    <?php foreach ($missionsAppel as $missionAppel): ?>
                        <?php
                        $autorise = !empty($missionAppel['autorisation_id']);
                        $nomClientAppel = trim((string) ($missionAppel['client_prenom'] ?? '') . ' ' . (string) ($missionAppel['client_nom'] ?? ''));
                        $nomTechnicienAppel = trim((string) ($missionAppel['technicien_prenom'] ?? '') . ' ' . (string) ($missionAppel['technicien_nom'] ?? ''));
                        $dateMissionAppel = $missionAppel['date_creneau_planifie']
                            ? date('d/m/Y', strtotime($missionAppel['date_creneau_planifie']))
                            : 'Sans créneau';
                        ?>
                        <tr>
                            <td><span class="autorisation-appel__mission"><?= $echapperAutorisation($missionAppel['numero_dossier']) ?></span><small><?= $echapperAutorisation($dateMissionAppel) ?></small></td>
                            <td><span class="autorisation-appel__contact"><?= $echapperAutorisation($nomClientAppel) ?></span></td>
                            <td><span class="autorisation-appel__contact"><?= $echapperAutorisation($nomTechnicienAppel) ?></span><?php if (!empty($missionAppel['partenaire_nom'])): ?><small><?= $echapperAutorisation($missionAppel['partenaire_nom']) ?></small><?php endif; ?></td>
                            <td><span class="autorisation-appel__statut-mission"><?= $echapperAutorisation(ucfirst(str_replace('_', ' ', $missionAppel['statut']))) ?></span></td>
                            <td>
                                <?php if ($autorise): ?>
                                    <span class="admin-badge admin-badge--vert">Autorisée</span><br>
                                    <small>par <?= $echapperAutorisation($missionAppel['autorise_par_nom'] ?: $texteRoleAppel) ?></small>
                                <?php else: ?>
                                    <span class="admin-badge admin-badge--gris">Non autorisée</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="post">
                                    <input type="hidden" name="csrf" value="<?= $echapperAutorisation($_SESSION['csrf']) ?>">
                                    <input type="hidden" name="intervention_id" value="<?= (int) $missionAppel['intervention_id'] ?>">
                                    <?php if ($rechercheAutorisation !== ''): ?><input type="hidden" name="q" value="<?= $echapperAutorisation($rechercheAutorisation) ?>"><?php endif; ?>
                                    <button class="autorisation-appel__action <?= $autorise ? 'autorisation-appel__action--revoquer' : '' ?>" type="submit" name="action" value="<?= $autorise ? 'revoquer' : 'autoriser' ?>">
                                        <?= $autorise ? 'Révoquer' : 'Autoriser' ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    </section>
    <p class="autorisation-appel__aide"><span aria-hidden="true">ℹ</span> Le bouton d’appel apparaît dans le détail de mission du technicien après vérification de l’autorisation. Le statut est revérifié toutes les 10 secondes. Les missions entreprise ne sont pas incluses.</p>
</div>
