<?php
$pageActuelle = basename($_SERVER['PHP_SELF']);
require_once __DIR__ . '/../models/Message.php';
require_once __DIR__ . '/../models/EntrepriseB2B.php';
require_once __DIR__ . '/icones.php';
require_once __DIR__ . '/AvatarProfil.php';
$nbNonLus = (new Message())->compterNonLus($_SESSION['user_id'], 'client');
$espacesEntrepriseClient = (new EntrepriseB2B())->getEntreprisesParMembre((int) $_SESSION['user_id']);
$nomAvatarClient = trim((string) ($_SESSION['prenom'] ?? '') . ' ' . (string) ($_SESSION['nom_famille'] ?? ''));
$photoAvatarClient = AvatarProfil::estValide($_SESSION['photo_profil'] ?? null, 'clients')
    ? (string) $_SESSION['photo_profil']
    : null;
$initialesAvatarClient = AvatarProfil::initiales($nomAvatarClient);
$estClientNavbar = ($_SESSION['role'] ?? '') === 'client';
?>
<!-- Thème : appliqué avant l'affichage du reste de la page pour éviter un flash clair -->
<script>
(function () {
    try {
        var t = localStorage.getItem('allopro_theme');
        if (t !== 'dark' && t !== 'light') t = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', t);
    } catch (e) { document.documentElement.setAttribute('data-theme', 'light'); }
})();
</script>
<link rel="stylesheet" href="../../public/css/theme.css?v=<?= filemtime(__DIR__ . '/../public/css/theme.css') ?>">
<link rel="stylesheet" href="../../public/css/navbar-responsive.css?v=<?= filemtime(__DIR__ . '/../public/css/navbar-responsive.css') ?>">
<link rel="stylesheet" href="../../public/css/avatar-profil.css">
<?php include __DIR__ . '/event-theme-head.php'; ?>

<nav class="navbar-client" id="navbar">
    <div class="navbar-client__gauche">
        <button type="button" class="navbar-client__burger" id="navbar-burger" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="navbar-liens">
            <span></span><span></span><span></span>
        </button>
        <a href="../../public/index.php" class="navbar-client__logo">ALLÔ<span>PRO</span></a>
        <div class="navbar-client__liens" id="navbar-liens">
            <a href="accueil.php" class="<?= $pageActuelle === 'accueil.php' ? 'navbar-client__lien--actif' : '' ?>">Tableau de bord</a>
            <a href="nouvelle-demande.php" class="<?= $pageActuelle === 'nouvelle-demande.php' ? 'navbar-client__lien--actif' : '' ?>">Nouvelle demande</a>
            <?php if ($espacesEntrepriseClient): ?>
                <a href="../entreprise/accueil.php" class="<?= str_contains($_SERVER['PHP_SELF'], '/entreprise/') ? 'navbar-client__lien--actif' : '' ?>">Espace entreprise</a>
            <?php endif; ?>
            <a href="mes-demandes.php" class="<?= $pageActuelle === 'mes-demandes.php' ? 'navbar-client__lien--actif' : '' ?>">Mes demandes</a>
            <?php $groupeInterventionsActif = $pageActuelle === 'mes-interventions.php'; ?>
            <details class="navbar-client__groupe">
                <summary class="<?= $groupeInterventionsActif ? 'navbar-client__lien--actif' : '' ?>">Interventions</summary>
                <div class="navbar-client__sous-menu">
                    <a href="mes-interventions.php" class="<?= $groupeInterventionsActif && ($_GET['vue'] ?? '') !== 'suivi' ? 'navbar-client__lien--actif' : '' ?>">Mes interventions</a>
                    <a href="mes-interventions.php?vue=suivi" class="<?= $groupeInterventionsActif && ($_GET['vue'] ?? '') === 'suivi' ? 'navbar-client__lien--actif' : '' ?>">Suivi d’intervention</a>
                </div>
            </details>
            <?php $groupePaiementsActif = in_array($pageActuelle, ['mes-paiements.php', 'mes-factures.php'], true); ?>
            <details class="navbar-client__groupe">
                <summary class="<?= $groupePaiementsActif ? 'navbar-client__lien--actif' : '' ?>">Paiements</summary>
                <div class="navbar-client__sous-menu">
                    <a href="mes-paiements.php" class="<?= $pageActuelle === 'mes-paiements.php' ? 'navbar-client__lien--actif' : '' ?>">Mes paiements</a>
                    <a href="mes-factures.php" class="<?= $pageActuelle === 'mes-factures.php' ? 'navbar-client__lien--actif' : '' ?>">Mes factures</a>
                </div>
            </details>
            <?php $groupeAvantagesActif = in_array($pageActuelle, ['abonnement.php', 'pass.php'], true); ?>
            <details class="navbar-client__groupe">
                <summary class="<?= $groupeAvantagesActif ? 'navbar-client__lien--actif' : '' ?>">Mes avantages</summary>
                <div class="navbar-client__sous-menu">
                    <a href="pass.php" class="<?= $pageActuelle === 'pass.php' ? 'navbar-client__lien--actif' : '' ?>">Mes Pass</a>
                    <a href="abonnement.php" class="<?= $pageActuelle === 'abonnement.php' ? 'navbar-client__lien--actif' : '' ?>">Mes abonnements</a>
                    <a href="abonnement.php#credits-restants">Mes crédits</a>
                </div>
            </details>
            <?php $groupeAssistanceActif = in_array($pageActuelle, ['messagerie.php', 'sav.php'], true); ?>
            <details class="navbar-client__groupe">
                <summary class="<?= $groupeAssistanceActif ? 'navbar-client__lien--actif' : '' ?>">Assistance</summary>
                <div class="navbar-client__sous-menu">
                    <a href="messagerie.php" class="navbar-client__lien-messages <?= $pageActuelle === 'messagerie.php' ? 'navbar-client__lien--actif' : '' ?>">
                        Mes messages avec ALLÔ PRO
                        <span class="navbar-client__badge" id="badge-messages" style="<?= $nbNonLus > 0 ? '' : 'display:none;' ?>"><?= $nbNonLus ?></span>
                    </a>
                    <a href="sav.php" class="<?= $pageActuelle === 'sav.php' ? 'navbar-client__lien--actif' : '' ?>">Mon SAV</a>
                </div>
            </details>
            <details class="navbar-client__groupe">
                <summary class="<?= $pageActuelle === 'profil.php' || $pageActuelle === 'ajouter-adresse.php' ? 'navbar-client__lien--actif' : '' ?>">Mon compte</summary>
                <div class="navbar-client__sous-menu">
                    <a href="ajouter-adresse.php" class="<?= $pageActuelle === 'ajouter-adresse.php' ? 'navbar-client__lien--actif' : '' ?>">Mes adresses</a>
                    <a href="profil.php" class="<?= $pageActuelle === 'profil.php' && !isset($_GET['section']) ? 'navbar-client__lien--actif' : '' ?>">Mon profil</a>
                    <a href="../../public/deconnexion.php">Déconnexion</a>
                </div>
            </details>
        </div>
    </div>

    <div class="navbar-client__droite">
        <?php if ($estClientNavbar): ?>
            <div class="navbar-client__notifications" id="notifications-menu">
                <button type="button" class="navbar-client__notifications-bouton" id="notifications-bouton"
                    aria-label="Notifications" aria-haspopup="true" aria-expanded="false" aria-controls="notifications-dropdown">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>
                    <span class="navbar-client__badge navbar-client__badge--notifications" id="badge-notifications" hidden></span>
                </button>
                <div class="navbar-client__notifications-dropdown" id="notifications-dropdown" aria-label="Notifications récentes">
                    <div class="navbar-client__notifications-titre">Notifications</div>
                    <div class="navbar-client__notifications-liste" id="notifications-liste">
                        <p class="navbar-client__notifications-vide">Chargement des notifications…</p>
                    </div>
                    <a class="navbar-client__notifications-tout" href="notifications.php">Voir toutes les notifications</a>
                </div>
            </div>
        <?php endif; ?>
        <div class="navbar-client__profil" id="profil-menu">
            <button type="button" class="navbar-client__avatar" id="profil-bouton"
                aria-label="Ouvrir le menu de profil de <?= htmlspecialchars($nomAvatarClient !== '' ? $nomAvatarClient : 'mon compte', ENT_QUOTES, 'UTF-8') ?>"
                aria-haspopup="true" aria-expanded="false" aria-controls="profil-dropdown">
                <?php if (empty($_SESSION['avatar_initiales']) && $photoAvatarClient !== null): ?>
                    <img src="../../public/<?= htmlspecialchars($photoAvatarClient, ENT_QUOTES, 'UTF-8') ?>" alt="">
                <?php elseif (!empty($_SESSION['avatar_initiales'])): ?>
                    <?= htmlspecialchars($initialesAvatarClient, ENT_QUOTES, 'UTF-8') ?>
                <?php else: ?>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5"/></svg>
                <?php endif; ?>
            </button>
            <div class="navbar-client__dropdown" id="profil-dropdown">
                <div class="navbar-client__dropdown-nom"><?= htmlspecialchars($_SESSION['nom'] ?? '') ?> <?= htmlspecialchars($_SESSION['prenom'] ?? '') ?></div>

                <?php
                require_once __DIR__ . '/../models/User.php';
                $infosCompte = (new User())->getById($_SESSION['user_id']);
                if (!empty($infosCompte['mdp_a_definir'])):
                ?>
                    <a href="../../public/definir-mot-de-passe.php" style="display:flex; align-items:center; gap:8px; padding:9px 12px; color:#92400E; background:#FEF3E2; border-radius:6px; font-size:13px; font-weight:600; text-decoration:none; margin:4px 0;">
                        <?= icone('key', 16) ?> Définir un mot de passe
                    </a>
                <?php endif; ?>
                <a href="profil.php">Mon profil</a>

                <!-- Bascule mode sombre -->
                <button type="button" class="navbar-client__theme" id="theme-toggle" role="switch" aria-checked="false">
                    <span class="navbar-client__theme-label">Mode sombre</span>
                    <svg class="theme-ico theme-ico--lune" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
                    <svg class="theme-ico theme-ico--soleil" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
                    <span class="theme-switch" aria-hidden="true"></span>
                </button>

                <a href="../../public/deconnexion.php">Déconnexion</a>
            </div>
        </div>
    </div>
    <div class="navbar-client__fond" id="navbar-fond"></div>
</nav>

<?php if ($estClientNavbar): ?>
<script src="../../public/js/navbar-client-notifications.js?v=<?= filemtime(__DIR__ . '/../public/js/navbar-client-notifications.js') ?>" defer></script>
<?php endif; ?>
<script>
(function() {
    const bouton = document.getElementById('profil-bouton');
    const dropdown = document.getElementById('profil-dropdown');
    const notificationsDropdown = document.getElementById('notifications-dropdown');
    const notificationsBouton = document.getElementById('notifications-bouton');
    function fermerNotifications() {
        if (!notificationsDropdown || !notificationsBouton) return;
        notificationsDropdown.classList.remove('navbar-client__notifications-dropdown--ouvert');
        notificationsBouton.setAttribute('aria-expanded', 'false');
    }
    bouton.addEventListener('click', (e) => {
        e.stopPropagation();
        fermerNotifications();
        const ouvert = dropdown.classList.toggle('navbar-client__dropdown--ouvert');
        bouton.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
    });
    document.addEventListener('click', (e) => {
        if (!document.getElementById('profil-menu').contains(e.target)) {
            dropdown.classList.remove('navbar-client__dropdown--ouvert');
            bouton.setAttribute('aria-expanded', 'false');
        }
    });

    const groupesNavigation = Array.from(document.querySelectorAll('#navbar-liens .navbar-client__groupe'));
    groupesNavigation.forEach((groupe) => {
        groupe.addEventListener('toggle', () => {
            if (!groupe.open) return;
            groupesNavigation.forEach((autreGroupe) => {
                if (autreGroupe !== groupe) autreGroupe.open = false;
            });
        });
    });
    document.addEventListener('click', (e) => {
        if (e.target.closest('#navbar-liens .navbar-client__groupe')) return;
        groupesNavigation.forEach((groupe) => { groupe.open = false; });
    });

    // ----- Menu mobile -----
    const nav = document.getElementById('navbar');
    if (getComputedStyle(nav).position === 'static') nav.style.position = 'relative';   // nécessaire pour que le z-index s'applique
    const burger = document.getElementById('navbar-burger');
    const fond = document.getElementById('navbar-fond');
    const mobile = window.matchMedia('(max-width: 1440px)');

    function positionnerMenu() {
        nav.style.setProperty('--nav-bas', Math.max(0, Math.round(nav.getBoundingClientRect().bottom)) + 'px');
    }
    function menuOuvert() { return nav.classList.contains('navbar-client--ouvert'); }
    function ouvrirMenu(ouvert) {
        if (ouvert) {
            dropdown.classList.remove('navbar-client__dropdown--ouvert');
            bouton.setAttribute('aria-expanded', 'false');
            fermerNotifications();
            positionnerMenu();
        }
        nav.classList.toggle('navbar-client--ouvert', ouvert);
        document.body.classList.toggle('navbar-menu-ouvert', ouvert);
        burger.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
        burger.setAttribute('aria-label', ouvert ? 'Fermer le menu' : 'Ouvrir le menu');
    }
    burger.addEventListener('click', (e) => { e.stopPropagation(); ouvrirMenu(!menuOuvert()); });
    fond.addEventListener('click', () => ouvrirMenu(false));
    bouton.addEventListener('click', () => ouvrirMenu(false));
    document.querySelectorAll('#navbar-liens a').forEach((a) => a.addEventListener('click', () => ouvrirMenu(false)));
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            groupesNavigation.forEach((groupe) => { groupe.open = false; });
            dropdown.classList.remove('navbar-client__dropdown--ouvert');
            bouton.setAttribute('aria-expanded', 'false');
            if (menuOuvert()) { ouvrirMenu(false); burger.focus(); }
        }
    });
    const surChangement = (e) => { if (!e.matches) ouvrirMenu(false); };
    if (mobile.addEventListener) mobile.addEventListener('change', surChangement); else mobile.addListener(surChangement);
    window.addEventListener('scroll', () => { if (menuOuvert()) positionnerMenu(); }, { passive: true });
    window.addEventListener('resize', () => { if (menuOuvert()) positionnerMenu(); });

    // ----- Mode sombre -----
    const html = document.documentElement;
    const themeBtn = document.getElementById('theme-toggle');
    const reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function appliquerTheme(theme, animer) {
        if (animer && !reduit) {
            html.classList.add('theme-anim');
            setTimeout(() => html.classList.remove('theme-anim'), 350);
        }
        html.setAttribute('data-theme', theme);
        themeBtn.setAttribute('aria-checked', theme === 'dark' ? 'true' : 'false');
    }
    appliquerTheme(html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light', false);

    themeBtn.addEventListener('click', () => {
        const suivant = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        appliquerTheme(suivant, true);
        try { localStorage.setItem('allopro_theme', suivant); } catch (e) {}
    });
    // Synchronisation entre onglets
    window.addEventListener('storage', (e) => {
        if (e.key === 'allopro_theme' && (e.newValue === 'dark' || e.newValue === 'light')) appliquerTheme(e.newValue, false);
    });

    // Badge messages non lus - vérification en temps réel
    const badge = document.getElementById('badge-messages');
    if (!badge) return;
    function verifierMessagesNonLus() {
        fetch('../../public/messages-non-lus.php')
            .then(r => r.json())
            .then(data => {
                if (data.count > 0) {
                    badge.textContent = data.count;
                    badge.style.display = 'inline-flex';
                } else {
                    badge.style.display = 'none';
                }
            })
            .catch(() => {});
    }
    setInterval(verifierMessagesNonLus, 5000); // toutes les 5 secondes
})();
</script>