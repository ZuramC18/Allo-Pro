<?php
require_once __DIR__ . '/icones.php';
$totalTaches = $compteursTaches['a_faire'] + $compteursTaches['terminee'];
$urlFiltreTaches = static function (string $statut = '') use ($urlTaches, $rechercheTache): string {
    $parametres = array_filter(['statut' => $statut, 'q' => $rechercheTache], static fn($valeur) => $valeur !== '');
    return $urlTaches . ($parametres ? '?' . http_build_query($parametres) : '');
};
?>
<header class="taches-entete">
    <div>
        <span class="taches-surtitre"><?= in_array($typeProprietaire, ['partenaire', 'coordinateur'], true) ? 'Organisation personnelle' : 'Organisation quotidienne' ?></span>
        <h1>Mes tâches</h1>
        <p><?= $typeProprietaire === 'partenaire'
            ? 'Gardez le suivi de vos priorités, rappels et échéances au même endroit.'
            : ($typeProprietaire === 'coordinateur'
                ? 'Organisez vos rappels, priorités et échéances de coordination.'
                : ($typeProprietaire === 'finance'
                    ? 'Organisez vos rappels, priorités et échéances financières.'
                    : 'Organisez vos rappels et vos priorités sans perdre le fil de vos interventions.')) ?></p>
    </div>
    <a class="taches-entete__action" href="#ajouter-tache"><?= icone('plus', 17) ?> Ajouter une tâche</a>
</header>

<?php if ($erreurTache !== ''): ?>
    <div class="taches-message taches-message--erreur" role="alert"><?= $echapperTache($erreurTache) ?></div>
<?php endif; ?>
<?php if ($messageTache !== ''): ?>
    <div class="taches-message taches-message--succes" role="status"><?= $echapperTache($messageTache) ?></div>
<?php endif; ?>

<section class="taches-resume" aria-label="Résumé des tâches">
    <a class="taches-resume__carte <?= $statutTache === '' ? 'taches-resume__carte--active' : '' ?>" href="<?= $echapperTache($urlFiltreTaches()) ?>">
        <span class="taches-resume__icone taches-resume__icone--total"><?= icone('clipboard', 20) ?></span>
        <span class="taches-resume__nombre"><?= $totalTaches ?></span>
        <span class="taches-resume__libelle">Toutes les tâches</span>
    </a>
    <a class="taches-resume__carte <?= $statutTache === 'a_faire' ? 'taches-resume__carte--active' : '' ?>" href="<?= $echapperTache($urlFiltreTaches('a_faire')) ?>">
        <span class="taches-resume__icone taches-resume__icone--todo"><?= icone('clock', 20) ?></span>
        <span class="taches-resume__nombre"><?= $compteursTaches['a_faire'] ?></span>
        <span class="taches-resume__libelle">À faire</span>
    </a>
    <a class="taches-resume__carte <?= $statutTache === 'terminee' ? 'taches-resume__carte--active' : '' ?>" href="<?= $echapperTache($urlFiltreTaches('terminee')) ?>">
        <span class="taches-resume__icone taches-resume__icone--done"><?= icone('check', 20) ?></span>
        <span class="taches-resume__nombre"><?= $compteursTaches['terminee'] ?></span>
        <span class="taches-resume__libelle">Terminées</span>
    </a>
    <div class="taches-resume__carte <?= $compteursTaches['en_retard'] > 0 ? 'taches-resume__carte--retard' : '' ?>">
        <span class="taches-resume__icone taches-resume__icone--late"><?= icone('alert', 20) ?></span>
        <span class="taches-resume__nombre"><?= $compteursTaches['en_retard'] ?></span>
        <span class="taches-resume__libelle">En retard</span>
    </div>
</section>

<div class="taches-layout">
    <section class="taches-liste" aria-label="Liste des tâches">
        <div class="taches-liste__barre">
            <div>
                <h2><?= $statutTache === 'terminee' ? 'Tâches terminées' : ($statutTache === 'a_faire' ? 'Tâches à faire' : 'Votre liste') ?></h2>
                <p><?= count($tachesFiltrees) ?> résultat<?= count($tachesFiltrees) === 1 ? '' : 's' ?><?= $rechercheTache !== '' ? ' pour « ' . $echapperTache($rechercheTache) . ' »' : '' ?></p>
            </div>
            <form class="taches-recherche" method="GET" action="<?= $echapperTache($urlTaches) ?>" role="search">
                <?php if ($statutTache !== ''): ?><input type="hidden" name="statut" value="<?= $echapperTache($statutTache) ?>"><?php endif; ?>
                <label>
                    <?= icone('search', 17) ?>
                    <span class="sr-only">Rechercher une tâche</span>
                    <input type="search" name="q" value="<?= $echapperTache($rechercheTache) ?>" placeholder="Rechercher…" maxlength="100">
                </label>
                <button type="submit">Rechercher</button>
            </form>
        </div>

        <?php if (!$tachesFiltrees): ?>
            <div class="taches-vide">
                <span class="taches-vide__icone"><?= icone($rechercheTache !== '' || $statutTache !== '' ? 'search' : 'clipboard', 28) ?></span>
                <strong><?= $rechercheTache !== '' || $statutTache !== '' ? 'Aucune tâche ne correspond à ces filtres.' : 'Votre liste de tâches est vide.' ?></strong>
                <p><?= $rechercheTache !== '' || $statutTache !== '' ? 'Modifiez la recherche ou consultez une autre catégorie.' : 'Ajoutez une tâche pour noter un rappel ou une échéance.' ?></p>
                <?php if ($rechercheTache !== '' || $statutTache !== ''): ?><a href="<?= $echapperTache($urlTaches) ?>">Réinitialiser les filtres</a><?php endif; ?>
            </div>
        <?php else: ?>
            <div class="taches-cartes">
                <?php foreach ($tachesFiltrees as $tache): ?>
                    <?php
                    $terminee = $tache['statut'] === 'terminee';
                    $date = $tache['date_echeance'] ? new DateTimeImmutable($tache['date_echeance']) : null;
                    $enRetard = !$terminee && $date && $date < $maintenant;
                    ?>
                    <article class="tache-carte <?= $terminee ? 'tache-carte--terminee' : '' ?> <?= $enRetard ? 'tache-carte--retard' : '' ?>">
                        <span class="tache-carte__etat" aria-hidden="true"><?= icone($terminee ? 'check' : ($enRetard ? 'alert' : 'clock'), 18) ?></span>
                        <div class="tache-carte__contenu">
                            <div class="tache-carte__titre-ligne">
                                <h3><?= $echapperTache($tache['titre']) ?></h3>
                                <span class="tache-badge <?= $terminee ? 'tache-badge--terminee' : ($enRetard ? 'tache-badge--retard' : 'tache-badge--a-faire') ?>">
                                    <?= $terminee ? 'Terminée' : ($enRetard ? 'En retard' : 'À faire') ?>
                                </span>
                            </div>
                            <?php if (!empty($tache['description'])): ?><p class="tache-carte__description"><?= nl2br($echapperTache($tache['description'])) ?></p><?php endif; ?>
                            <div class="tache-carte__meta">
                                <?php if ($date): ?>
                                    <span class="<?= $enRetard ? 'tache-carte__echeance--retard' : '' ?>">
                                        <?= icone('clock', 14) ?>
                                        <?= $enRetard ? 'Échue le ' : 'Échéance : ' ?><?= $echapperTache($date->format('d/m/Y à H:i')) ?>
                                    </span>
                                <?php else: ?>
                                    <span><?= icone('clock', 14) ?> Aucune échéance</span>
                                <?php endif; ?>
                                <?php if (!empty($tache['date_creation'])): ?><span>Ajoutée le <?= $echapperTache((new DateTimeImmutable($tache['date_creation']))->format('d/m/Y')) ?></span><?php endif; ?>
                            </div>
                        </div>
                        <div class="tache-carte__actions">
                            <form method="POST">
                                <input type="hidden" name="csrf" value="<?= $echapperTache($_SESSION[$csrfSession]) ?>">
                                <input type="hidden" name="tache_id" value="<?= (int) $tache['id'] ?>">
                                <input type="hidden" name="action" value="<?= $terminee ? 'reprendre' : 'terminer' ?>">
                                <button class="tache-action <?= $terminee ? 'tache-action--reprendre' : 'tache-action--terminer' ?>" type="submit">
                                    <?= icone($terminee ? 'refresh' : 'check', 15) ?> <?= $terminee ? 'À faire' : 'Terminer' ?>
                                </button>
                            </form>
                            <form method="POST" onsubmit="return confirm('Supprimer définitivement cette tâche ?');">
                                <input type="hidden" name="csrf" value="<?= $echapperTache($_SESSION[$csrfSession]) ?>">
                                <input type="hidden" name="tache_id" value="<?= (int) $tache['id'] ?>">
                                <input type="hidden" name="action" value="supprimer">
                                <button class="tache-action tache-action--supprimer" type="submit" aria-label="Supprimer <?= $echapperTache($tache['titre']) ?>" title="Supprimer"><?= icone('x', 15) ?></button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <aside class="taches-ajout" id="ajouter-tache">
        <div class="taches-ajout__entete">
            <span><?= icone('plus', 17) ?></span>
            <div><h2>Nouvelle tâche</h2><p>Notez ce qu’il ne faut pas oublier.</p></div>
        </div>
        <form method="POST" class="taches-formulaire">
            <input type="hidden" name="csrf" value="<?= $echapperTache($_SESSION[$csrfSession]) ?>">
            <input type="hidden" name="action" value="creer">
            <label for="tache-titre">Titre <span aria-hidden="true">*</span></label>
            <input id="tache-titre" type="text" name="titre" value="<?= $echapperTache($titreFormulaire) ?>" placeholder="Ex. Rappeler le client" maxlength="150" required>
            <label for="tache-description">Détails <small>Facultatif</small></label>
            <textarea id="tache-description" name="description" rows="4" maxlength="2000" placeholder="Ajoutez une note ou des informations utiles…"><?= $echapperTache($descriptionFormulaire) ?></textarea>
            <label for="tache-echeance">Échéance <small>Facultative</small></label>
            <input id="tache-echeance" type="datetime-local" name="date_echeance" value="<?= $echapperTache($echeanceFormulaire) ?>">
            <button type="submit"><?= icone('plus', 16) ?> Ajouter à ma liste</button>
        </form>
        <p class="taches-ajout__note"><?= icone('shield', 14) ?> Seules vos tâches sont visibles dans cet espace.</p>
    </aside>
</div>
