<?php
require_once __DIR__ . '/permissions.php';

function verifierConnexion() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /allopro/public/connexion.php");
        exit;
    }
    rafraichirCompteConnecte();
}

function verifierRole($rolesAutorises) {
    verifierConnexion();

    if (!in_array($_SESSION['role'], $rolesAutorises)) {
        require_once __DIR__ . '/acces.php';
        $_SESSION['flash_acces'] = "Accès refusé — vous n'avez pas les droits nécessaires.";
        header('Location: ' . accueilPourRole());
        exit;
    }
}