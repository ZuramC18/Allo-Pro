<?php
function nomComplet($prenom, $nom) {
    return trim(($prenom ?? '') . ' ' . ($nom ?? ''));
}

function tempsRelatifConversation($date): string {
    if (!is_string($date) || $date === '') {
        return '';
    }

    $timestamp = strtotime($date);
    if ($timestamp === false) {
        return '';
    }

    $secondes = max(0, time() - $timestamp);
    if ($secondes < 60) {
        return 'À l’instant';
    }

    $unites = [
        'an' => 31536000,
        'mois' => 2592000,
        'sem' => 604800,
        'j' => 86400,
        'h' => 3600,
        'min' => 60,
    ];
    $parties = [];

    foreach ($unites as $libelle => $duree) {
        $quantite = intdiv($secondes, $duree);
        if ($quantite > 0) {
            $parties[] = $quantite . ' ' . $libelle;
            $secondes %= $duree;
            if (count($parties) === 2) {
                break;
            }
        }
    }

    return 'Il y a ' . implode(' ', $parties);
}

function libelleJourConversation($date): string {
    if (!is_string($date) || $date === '') {
        return '';
    }

    $timestamp = strtotime($date);
    if ($timestamp === false) {
        return '';
    }

    $jourMessage = date('Y-m-d', $timestamp);
    $aujourdhui = date('Y-m-d');
    if ($jourMessage === $aujourdhui) {
        return 'Aujourd’hui';
    }
    if ($jourMessage === date('Y-m-d', strtotime('-1 day'))) {
        return 'Hier';
    }

    $jour = new DateTimeImmutable('@' . $timestamp);
    $jour = $jour->setTimezone(new DateTimeZone(date_default_timezone_get()));
    $libelleJour = $jour->format('l');
    $jours = [
        'Monday' => 'Lundi',
        'Tuesday' => 'Mardi',
        'Wednesday' => 'Mercredi',
        'Thursday' => 'Jeudi',
        'Friday' => 'Vendredi',
        'Saturday' => 'Samedi',
        'Sunday' => 'Dimanche',
    ];
    $mois = [
        1 => 'janvier',
        2 => 'février',
        3 => 'mars',
        4 => 'avril',
        5 => 'mai',
        6 => 'juin',
        7 => 'juillet',
        8 => 'août',
        9 => 'septembre',
        10 => 'octobre',
        11 => 'novembre',
        12 => 'décembre',
    ];
    $annee = $jour->format('Y') !== date('Y') ? ' ' . $jour->format('Y') : '';

    return ($jours[$libelleJour] ?? '') . ' ' . $jour->format('j') . ' '
        . ($mois[(int) $jour->format('n')] ?? '') . $annee;
}