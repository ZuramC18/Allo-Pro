<section class="appel-web" id="interface-appel-web" data-csrf="<?= htmlspecialchars((string) ($csrfAppelWeb ?? $_SESSION['csrf'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" data-role="<?= htmlspecialchars((string) ($roleAppelWeb ?? $_SESSION['role'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" hidden aria-live="polite" aria-label="Appel audio">
    <div class="appel-web__carte">
        <div class="appel-web__identite">
            <span class="appel-web__avatar" aria-hidden="true">A</span>
            <p class="appel-web__titre" id="appel-web-titre"><span>Allo</span><span class="appel-web__titre-pro">Pro</span></p>
        </div>
        <p class="appel-web__statut" id="appel-web-statut">Connexion en cours…</p>
        <p class="appel-web__micro-distant" id="appel-web-micro-distant" hidden>Le client a coupé son micro</p>
        <p class="appel-web__duree" id="appel-web-duree" hidden>00:00</p>
        <p class="appel-web__erreur" id="appel-web-erreur" role="alert" hidden></p>
        <div class="appel-web__actions">
            <button type="button" id="appel-web-repondre" hidden>Répondre</button>
            <button type="button" id="appel-web-refuser" hidden>Refuser</button>
            <button type="button" id="appel-web-retour" hidden>Retour à la conversation</button>
            <button type="button" id="appel-web-muet" aria-pressed="false" hidden>Couper le micro</button>
            <button type="button" id="appel-web-raccrocher" hidden>Raccrocher</button>
        </div>
    </div>
    <audio id="appel-web-audio" autoplay playsinline></audio>
</section>
