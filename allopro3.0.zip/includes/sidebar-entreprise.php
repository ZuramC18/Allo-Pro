<?php
require_once __DIR__ . '/icones.php';

$pageEntreprise = basename($_SERVER['PHP_SELF']);
$lienEntreprise = static fn(string $page): string => $page . '?entreprise_id=' . (int) $entrepriseId;
$estAdminEntreprise = ($entreprise['role_membre'] ?? '') === 'admin';
$peutVoirEntreprise = static fn(string $permission): bool => $estAdminEntreprise
    || in_array($permission, $permissionsEntreprise ?? [], true);
$elementNavigationEntreprise = static function (string $label, string $url, string $icon, bool $active = false, string $class = ''): string {
    $classes = trim('b2b-sidebar__link ' . ($active ? 'actif ' : '') . $class);
    return '<a class="' . htmlspecialchars($classes, ENT_QUOTES, 'UTF-8') . '" href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"' . ($active ? ' aria-current="page"' : '') . '>'
        . '<span class="b2b-sidebar__nav-icon">' . icone($icon, 17) . '</span>'
        . '<span class="b2b-sidebar__nav-label">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>'
        . '</a>';
};
$moduleActif = is_string($_GET['module'] ?? null) ? $_GET['module'] : '';
?>
<aside class="b2b-sidebar">
    <div class="b2b-sidebar__top">
        <a class="b2b-logo" href="<?= htmlspecialchars($lienEntreprise('accueil.php'), ENT_QUOTES, 'UTF-8') ?>">
            <span class="b2b-logo__mark" aria-hidden="true"><?= icone('building', 20) ?></span>
            <span class="b2b-logo__wordmark">ALLÔ PRO<span>ENTREPRISE</span></span>
        </a>
        <button class="b2b-sidebar__toggle" type="button" aria-expanded="false" aria-controls="navigation-entreprise" aria-label="Ouvrir le menu entreprise">
            <span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span>
        </button>
    </div>
    <div class="b2b-sidebar__identity">
        <span class="b2b-sidebar__identity-label"><?= icone('shield', 13) ?> ESPACE PROFESSIONNEL</span>
        <p class="b2b-sidebar__entreprise"><?= htmlspecialchars($entreprise['nom'], ENT_QUOTES, 'UTF-8') ?></p>
    </div>
    <nav id="navigation-entreprise" aria-label="Navigation entreprise">
        <div class="b2b-sidebar__group">
            <span class="b2b-sidebar__group-title">PILOTAGE</span>
            <?php if ($peutVoirEntreprise('accueil')): ?><?= $elementNavigationEntreprise('Tableau de bord', $lienEntreprise('accueil.php'), 'dashboard', $pageEntreprise === 'accueil.php') ?><?php endif; ?>
            <?php if ($peutVoirEntreprise('sites')): ?><?= $elementNavigationEntreprise('Sites', $lienEntreprise('sites.php'), 'pin', $pageEntreprise === 'sites.php') ?><?php endif; ?>
            <?php if ($estAdminEntreprise): ?><?= $elementNavigationEntreprise('Utilisateurs autorisés', $lienEntreprise('membres.php'), 'users', $pageEntreprise === 'membres.php') ?><?php endif; ?>
        </div>
        <?php if ($peutVoirEntreprise('demandes') || $peutVoirEntreprise('devis') || $peutVoirEntreprise('tickets') || $peutVoirEntreprise('interventions') || $peutVoirEntreprise('contrats')): ?>
            <div class="b2b-sidebar__group">
                <span class="b2b-sidebar__group-title">ACTIVITÉ</span>
                <?php if ($peutVoirEntreprise('devis')): ?><?= $elementNavigationEntreprise('Devis', $lienEntreprise('gestion.php') . '&module=devis', 'file-text', $moduleActif === 'devis' || $pageEntreprise === 'detail-devis.php') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('demandes')): ?><?= $elementNavigationEntreprise('Demandes et interventions', $lienEntreprise('demandes.php'), 'inbox', in_array($pageEntreprise, ['demandes.php', 'nouvelle-demande.php', 'detail-demande.php'], true)) ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('tickets')): ?><?= $elementNavigationEntreprise('Tickets / SAV', $lienEntreprise('gestion.php') . '&module=tickets', 'ticket', $moduleActif === 'tickets') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('interventions')): ?><?= $elementNavigationEntreprise('Suivi des interventions', $lienEntreprise('gestion.php') . '&module=interventions', 'wrench', $moduleActif === 'interventions') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('contrats')): ?><?= $elementNavigationEntreprise('Contrats et SLA', $lienEntreprise('gestion.php') . '&module=contrats', 'clock', in_array($moduleActif, ['contrats', 'sla'], true)) ?><?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if ($peutVoirEntreprise('factures') || $peutVoirEntreprise('paiements') || $peutVoirEntreprise('rapports') || $peutVoirEntreprise('historique') || $peutVoirEntreprise('documents') || $peutVoirEntreprise('parametres')): ?>
            <div class="b2b-sidebar__group">
                <span class="b2b-sidebar__group-title">FINANCES &amp; RESSOURCES</span>
                <?php if ($peutVoirEntreprise('factures')): ?><?= $elementNavigationEntreprise('Factures', $lienEntreprise('gestion.php') . '&module=factures', 'receipt', $moduleActif === 'factures') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('paiements')): ?><?= $elementNavigationEntreprise('Paiements', $lienEntreprise('gestion.php') . '&module=paiements', 'wallet', $moduleActif === 'paiements') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('rapports')): ?><?= $elementNavigationEntreprise('Rapports', $lienEntreprise('gestion.php') . '&module=rapports', 'chart', $moduleActif === 'rapports') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('historique')): ?><?= $elementNavigationEntreprise('Historique', $lienEntreprise('gestion.php') . '&module=historique', 'refresh', $moduleActif === 'historique') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('documents')): ?><?= $elementNavigationEntreprise('Documents', $lienEntreprise('gestion.php') . '&module=documents', 'folder', $moduleActif === 'documents') ?><?php endif; ?>
                <?php if ($peutVoirEntreprise('parametres')): ?><?= $elementNavigationEntreprise('Paramètres du compte', $lienEntreprise('gestion.php') . '&module=parametres', 'settings', $moduleActif === 'parametres') ?><?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="b2b-sidebar__footer">
            <?php if (!$estAdminEntreprise): ?><?= $elementNavigationEntreprise('Quitter cette entreprise', $lienEntreprise('quitter-entreprise.php'), 'x', $pageEntreprise === 'quitter-entreprise.php', 'b2b-sidebar__link--secondary') ?><?php endif; ?>
            <?= $elementNavigationEntreprise('Revenir à mon espace client', '../client/accueil.php', 'home', false, 'b2b-sidebar__link--secondary') ?>
            <?= $elementNavigationEntreprise('Déconnexion', '../../public/deconnexion.php', 'logout', false, 'b2b-sidebar__link--secondary') ?>
        </div>
    </nav>
</aside>
