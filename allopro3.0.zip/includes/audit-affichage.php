<?php
function libellesActionsAudit(): array {
    static $libelles = [
        'connexion.reussie' => 'Connexion', 'connexion.echec' => 'Échec de connexion', 'connexion.refusee' => 'Connexion refusée',
        'compte.cree' => 'Compte créé', 'compte.role_modifie' => 'Rôle modifié', 'compte.suspendu' => 'Compte suspendu',
        'compte.reactive' => 'Compte réactivé', 'compte.mdp_reinitialise' => 'Mot de passe réinitialisé',
        'permissions.modifiees' => 'Permissions modifiées', 'parametre.commission_modifiee' => 'Commission modifiée',
        'parametre.attribution_modifiee' => 'Attribution automatique modifiée', 'parametre.limite_attribution_modifiee' => 'Plafond de conseillers modifié',
        'reversement.cree' => 'Reversement créé', 'reversement.paye' => 'Reversement payé',
        'client.suspendu' => 'Client suspendu', 'client.reactive' => 'Client réactivé',
        'partenaire.statut_modifie' => 'Statut partenaire modifié', 'partenaire.niveau_modifie' => 'Niveau partenaire modifié',
        'technicien.statut_modifie' => 'Statut technicien modifié',
        'demande.attribuee' => 'Mission attribuée', 'mission.statut_modifie' => 'Statut de mission modifié', 'mission.cloturee' => 'Mission clôturée',
        'sav.mis_a_jour' => 'Ticket SAV mis à jour', 'message.modifie' => 'Message modifié',
        'formule.creee' => 'Formule créée', 'formule.modifiee' => 'Formule modifiée', 'formule.supprimee' => 'Formule supprimée',
        'paiement.valide' => 'Paiement validé', 'abonnement.active' => 'Abonnement activé', 'audit.exporte' => 'Journal exporté',
        'session.coupee' => 'Session coupée (suspension)', 'session.role_actualise' => 'Rôle actualisé en session',
        'conversation.reassignee' => 'Conversation réassignée',
        'conversation.fermee' => 'Conversation clôturée',
        'conversation.reouverte' => 'Conversation réouverte',
        'conversation.attribuee' => 'Conversation attribuée',
    ];
    return $libelles;
}

function libelleActionAudit(string $action): string {
    $libelles = libellesActionsAudit();
    return $libelles[$action] ?? $action;
}

function couleurActionAudit(string $action): string {
    if (in_array($action, ['connexion.echec', 'connexion.refusee', 'compte.suspendu', 'client.suspendu', 'formule.supprimee'], true)) return 'rouge';
    $categorie = explode('.', $action)[0];
    return ['compte' => 'amber', 'permissions' => 'amber', 'parametre' => 'amber', 'reversement' => 'violet', 'paiement' => 'violet', 'formule' => 'violet', 'abonnement' => 'violet'][$categorie] ?? 'gris';
}

function libelleActeurAudit(string $type): string {
    $libelles = [
        'partenaire' => 'Partenaire',
        'technicien' => 'Technicien',
        'systeme' => 'Système',
        'inconnu' => 'Non identifié',
    ];
    return LIBELLES_ROLES[$type] ?? $libelles[$type] ?? $type;
}
