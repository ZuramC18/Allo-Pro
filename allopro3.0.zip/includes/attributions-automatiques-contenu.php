<?php
$statutsAttributionsAutomatiques = [
    'en_attente' => 'En attente du technicien',
    'acceptee' => 'Acceptée',
    'en_route' => 'En route',
    'arrive' => 'Arrivé sur place',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
    'refusee' => 'Refusée',
];
$missionsEnAttenteAutomatiques = count(array_filter(
    $attributions,
    static fn(array $attribution): bool => $attribution['intervention_statut'] === 'en_attente'
));
$missionsEnCoursAutomatiques = count(array_filter(
    $attributions,
    static fn(array $attribution): bool => in_array(
        $attribution['intervention_statut'],
        ['acceptee', 'en_route', 'arrive', 'diagnostic', 'en_cours'],
        true
    )
));
$missionsTermineesAutomatiques = count(array_filter(
    $attributions,
    static fn(array $attribution): bool => $attribution['intervention_statut'] === 'terminee'
));
?>
<section class="attributions-auto">
    <header class="attributions-auto__entete">
        <div>
            <span class="attributions-auto__surtitre">Dispatch / historique</span>
            <h1>Attributions automatiques</h1>
            <p>Demandes attribuées par l’algorithme, technicien retenu et créneau réservé.</p>
        </div>
        <a class="attributions-auto__action" href="<?= $e($lienMissions) ?>">Voir les missions</a>
    </header>

    <div class="attributions-auto__indicateurs" aria-label="Synthèse des attributions automatiques">
        <article><strong><?= count($attributions) ?></strong><span>Attribuées automatiquement</span></article>
        <article><strong><?= $missionsEnAttenteAutomatiques ?></strong><span>En attente du technicien</span></article>
        <article><strong><?= $missionsEnCoursAutomatiques ?></strong><span>En cours</span></article>
        <article><strong><?= $missionsTermineesAutomatiques ?></strong><span>Terminées</span></article>
    </div>

    <section class="attributions-auto__panneau">
        <div class="attributions-auto__panneau-entete">
            <h2>Demandes attribuées par l’algorithme</h2>
            <span><?= count($attributions) ?> dossier<?= count($attributions) > 1 ? 's' : '' ?></span>
        </div>
        <?php if (!$attributions): ?>
            <div class="attributions-auto__vide">
                <strong>Aucune attribution automatique pour le moment</strong>
                <span>Cette page liste uniquement les missions choisies par l’algorithme. Les attributions manuelles sont consultables dans les missions.</span>
            </div>
        <?php else: ?>
            <div class="attributions-auto__table-wrap" role="region" aria-label="Demandes attribuées automatiquement" tabindex="0">
                <table>
                    <thead>
                    <tr>
                        <th>Dossier</th>
                        <th>Client / adresse</th>
                        <th>Partenaire / technicien</th>
                        <th>Créneau réservé</th>
                        <th>Statut</th>
                        <th>Attribution</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($attributions as $attribution): ?>
                        <tr>
                            <td>
                                <strong><?= $e($attribution['numero_dossier']) ?></strong>
                                <span class="attributions-auto__secondaire"><?= $e($attribution['categorie_nom']) ?></span>
                                <?php if ($attribution['urgence'] === 'urgente'): ?><span class="attributions-auto__urgence">Urgente</span><?php endif; ?>
                            </td>
                            <td>
                                <strong><?= $e($attribution['client_nom']) ?></strong>
                                <span class="attributions-auto__secondaire"><?= $e(trim($attribution['quartier'] . ', ' . $attribution['ville'], ', ')) ?></span>
                            </td>
                            <td>
                                <strong><?= $e($attribution['nom_entreprise'] ?: 'Partenaire non renseigné') ?></strong>
                                <span class="attributions-auto__secondaire"><?= $e($attribution['technicien_nom'] ?: 'Technicien non renseigné') ?></span>
                            </td>
                            <td>
                                <?php if (!empty($attribution['date_creneau_planifie']) && $attribution['heure_creneau_planifie'] !== null): ?>
                                    <strong><?= $e(date('d/m/Y', strtotime($attribution['date_creneau_planifie']))) ?></strong>
                                    <span class="attributions-auto__secondaire"><?= sprintf('%02d:00–%02d:00', (int) $attribution['heure_creneau_planifie'], (int) $attribution['heure_creneau_planifie'] + 1) ?></span>
                                <?php else: ?>
                                    <span class="attributions-auto__secondaire">Non renseigné</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="attributions-auto__statut"><?= $e($statutsAttributionsAutomatiques[$attribution['intervention_statut']] ?? $attribution['intervention_statut']) ?></span></td>
                            <td>
                                <strong><?= $e($attribution['score_attribution'] ?? '—') ?><?= $attribution['score_attribution'] !== null ? ' / 100' : '' ?></strong>
                                <?php if (!empty($attribution['details_attribution'])): ?>
                                    <details class="attributions-auto__details">
                                        <summary>Voir le détail</summary>
                                        <span><?= $e($attribution['details_attribution']) ?></span>
                                    </details>
                                <?php endif; ?>
                                <span class="attributions-auto__secondaire"><?= $e(date('d/m/Y H:i', strtotime($attribution['date_attribution']))) ?></span>
                            </td>
                            <td><a class="attributions-auto__ouvrir" href="traiter-demande.php?id=<?= (int) $attribution['demande_id'] ?>">Ouvrir</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</section>
