<?php
require_once __DIR__ . '/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../models/EntrepriseB2B.php';

$entrepriseModele = new EntrepriseB2B();
$entrepriseId = filter_var($_GET['entreprise_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($entrepriseId === false || $entrepriseId === null) {
    $entreprisesMembre = $entrepriseModele->getEntreprisesParMembre((int) $_SESSION['user_id']);
    if (!$entreprisesMembre) {
        header('Location: accueil.php');
        exit;
    }
    if (count($entreprisesMembre) === 1) {
        $entrepriseId = (int) $entreprisesMembre[0]['id'];
    } else {
        header('Location: accueil.php');
        exit;
    }
}

$entreprise = $entrepriseModele->getEntreprisePourMembre((int) $entrepriseId, (int) $_SESSION['user_id']);
if (!$entreprise) {
    header('Location: accueil.php');
    exit;
}
$entrepriseId = (int) $entrepriseId;
$clePermissionPage = match (basename($_SERVER['PHP_SELF'] ?? '')) {
    'accueil.php' => 'accueil',
    'sites.php' => 'sites',
    'membres.php' => $entreprise['role_membre'] === 'admin' ? null : '__admin__',
    'quitter-entreprise.php' => null,
    'demandes.php', 'nouvelle-demande.php', 'detail-demande.php' => 'demandes',
    'detail-devis.php' => 'devis',
    'telecharger-document.php' => 'documents',
    'telecharger-facture.php' => 'factures',
    'gestion.php' => [
        'tickets' => 'tickets',
        'interventions' => 'interventions',
        'contrats' => 'contrats',
        'devis' => 'devis',
        'factures' => 'factures',
        'paiements' => 'paiements',
        'rapports' => 'rapports',
        'historique' => 'historique',
        'documents' => 'documents',
        'parametres' => 'parametres',
    ][is_string($_GET['module'] ?? null) ? $_GET['module'] : ''] ?? '__invalide__',
    default => '__invalide__',
};
$permissionsEntreprise = $entrepriseModele->getPermissionsPourMembre(
    $entrepriseId,
    (int) $_SESSION['user_id'],
    (string) $entreprise['role_membre']
);
$entrepriseAutorisePermission = static fn(string $permission): bool => in_array($permission, $permissionsEntreprise, true);
if ($clePermissionPage === '__admin__'
    || ($clePermissionPage !== null && !$entrepriseAutorisePermission($clePermissionPage))) {
    http_response_code(403);
    exit('Vous n’avez pas la permission d’accéder à cette page de l’espace entreprise.');
}
