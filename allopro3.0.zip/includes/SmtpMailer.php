<?php
require_once __DIR__ . '/../models/ConfigurationEmail.php';

class SmtpMailer {
    private array $configuration;

    public function __construct(?array $configuration = null) {
        $base = $configuration ?? require __DIR__ . '/../config/mail.php';
        $this->configuration = (new ConfigurationEmail())->appliquerConfigurationGoogle($base);
    }

    public function envoyer(
        string $destinataire,
        string $nomDestinataire,
        string $sujet,
        string $texte,
        string $html,
        array $piecesJointes = []
    ): void {
        $config = $this->configuration;
        foreach (['smtp_host', 'smtp_username', 'smtp_password', 'from_email'] as $cle) {
            if (empty($config[$cle])) {
                throw new RuntimeException('Configuration SMTP manquante : ' . $cle);
            }
        }
        if (!filter_var($destinataire, FILTER_VALIDATE_EMAIL) || !filter_var($config['from_email'], FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Adresse email SMTP ou destinataire invalide.');
        }

        $securite = $config['smtp_security'] ?? 'tls';
        if (!in_array($securite, ['tls', 'ssl'], true)) {
            throw new RuntimeException('Sécurité SMTP non prise en charge.');
        }

        $hote = (string) $config['smtp_host'];
        $port = (int) ($config['smtp_port'] ?? 587);
        if ((!filter_var($hote, FILTER_VALIDATE_IP) && !preg_match('/\A[a-zA-Z0-9.-]+\z/', $hote))
            || $port < 1 || $port > 65535) {
            throw new RuntimeException('Adresse ou port du serveur SMTP invalide.');
        }
        $contexte = stream_context_create([
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
                'peer_name' => $hote,
            ],
        ]);
        $adresseSocket = ($securite === 'ssl' ? 'ssl://' : 'tcp://') . $hote . ':' . $port;
        $socket = @stream_socket_client($adresseSocket, $codeErreur, $messageErreur, 15, STREAM_CLIENT_CONNECT, $contexte);
        if (!$socket) {
            throw new RuntimeException('Connexion au serveur SMTP impossible (' . $codeErreur . ').');
        }

        stream_set_timeout($socket, 15);
        try {
            $this->attendre($socket, [220]);
            $this->commande($socket, 'EHLO allopro.local', [250]);

            if ($securite === 'tls') {
                $this->commande($socket, 'STARTTLS', [220]);
                if (stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) !== true) {
                    throw new RuntimeException('Impossible d’établir la connexion TLS SMTP.');
                }
                $this->commande($socket, 'EHLO allopro.local', [250]);
            }

            $this->commande($socket, 'AUTH LOGIN', [334]);
            $this->commande($socket, base64_encode((string) $config['smtp_username']), [334]);
            $this->commande($socket, base64_encode((string) $config['smtp_password']), [235]);
            $this->commande($socket, 'MAIL FROM:<' . $config['from_email'] . '>', [250]);
            $this->commande($socket, 'RCPT TO:<' . $destinataire . '>', [250, 251]);
            $this->commande($socket, 'DATA', [354]);

            $frontiere = 'alt_' . bin2hex(random_bytes(16));
            $frontiereMixte = 'mix_' . bin2hex(random_bytes(16));
            $nomExpediteur = $this->encoderEntete((string) ($config['from_name'] ?? 'ALLÔ PRO'));
            $nomDestinataireEncode = $this->encoderEntete($nomDestinataire);
            $message = [
                'Date: ' . date(DATE_RFC2822),
                'From: ' . $nomExpediteur . ' <' . $config['from_email'] . '>',
                'To: ' . $nomDestinataireEncode . ' <' . $destinataire . '>',
                'Subject: ' . $this->encoderEntete($sujet),
                'MIME-Version: 1.0',
                'Content-Type: ' . ($piecesJointes ? 'multipart/mixed; boundary="' . $frontiereMixte . '"' : 'multipart/alternative; boundary="' . $frontiere . '"'),
                '',
            ];
            if ($piecesJointes) {
                array_push($message,
                    '--' . $frontiereMixte,
                    'Content-Type: multipart/alternative; boundary="' . $frontiere . '"',
                    ''
                );
            }
            array_push($message,
                '--' . $frontiere,
                'Content-Type: text/plain; charset=UTF-8',
                'Content-Transfer-Encoding: base64',
                '',
                chunk_split(base64_encode($texte), 76, "\r\n"),
                '--' . $frontiere,
                'Content-Type: text/html; charset=UTF-8',
                'Content-Transfer-Encoding: base64',
                '',
                chunk_split(base64_encode($html), 76, "\r\n"),
                '--' . $frontiere . '--',
            );
            if ($piecesJointes) {
                foreach ($piecesJointes as $pieceJointe) {
                    if (!is_array($pieceJointe)
                        || !isset($pieceJointe['chemin'], $pieceJointe['nom'], $pieceJointe['mime'])
                        || !is_string($pieceJointe['chemin'])
                        || !is_string($pieceJointe['nom'])
                        || !is_string($pieceJointe['mime'])
                        || !preg_match('/\A[a-zA-Z0-9!#$&^_.+-]+\/[a-zA-Z0-9!#$&^_.+-]+\z/', $pieceJointe['mime'])
                        || str_contains($pieceJointe['nom'], "\r")
                        || str_contains($pieceJointe['nom'], "\n")) {
                        throw new InvalidArgumentException('Une piece jointe est invalide.');
                    }
                    $contenuFichier = file_get_contents($pieceJointe['chemin']);
                    if ($contenuFichier === false) {
                        throw new RuntimeException('Impossible de lire une piece jointe du courriel.');
                    }
                    $nomAscii = preg_replace('/[^A-Za-z0-9._-]/', '_', $pieceJointe['nom']);
                    array_push($message,
                        '--' . $frontiereMixte,
                        'Content-Type: ' . $pieceJointe['mime'] . '; name="' . $nomAscii . '"',
                        "Content-Transfer-Encoding: base64",
                        'Content-Disposition: attachment; filename="' . $nomAscii . '"; filename*=UTF-8\'\'' . rawurlencode($pieceJointe['nom']),
                        '',
                        chunk_split(base64_encode($contenuFichier), 76, "\r\n")
                    );
                }
                $message[] = '--' . $frontiereMixte . '--';
            }
            $message[] = '';
            $contenu = implode("\r\n", $message);
            $contenu = preg_replace('/(?m)^\./', '..', $contenu);
            if (fwrite($socket, $contenu . ".\r\n") === false) {
                throw new RuntimeException('Échec de transmission du message SMTP.');
            }
            $this->attendre($socket, [250]);
            $this->commande($socket, 'QUIT', [221]);
        } finally {
            fclose($socket);
        }
    }

    private function commande($socket, string $commande, array $codesAttendus): string {
        if (fwrite($socket, $commande . "\r\n") === false) {
            throw new RuntimeException('Échec de transmission de la commande SMTP.');
        }
        return $this->attendre($socket, $codesAttendus);
    }

    private function attendre($socket, array $codesAttendus): string {
        $reponse = '';
        do {
            $ligne = fgets($socket, 515);
            if ($ligne === false) {
                throw new RuntimeException('Le serveur SMTP n’a pas répondu.');
            }
            $reponse .= $ligne;
            if (isset($ligne[3]) && $ligne[3] === ' ') {
                break;
            }
        } while (true);

        $code = (int) substr($reponse, 0, 3);
        if (!in_array($code, $codesAttendus, true)) {
            throw new RuntimeException('Le serveur SMTP a refusé une étape de l’envoi (code ' . $code . ').');
        }
        return $reponse;
    }

    private function encoderEntete(string $valeur): string {
        return '=?UTF-8?B?' . base64_encode($valeur) . '?=';
    }
}
