<?php

class PdfFacture {
    private string $contenu = '';

    public function generer(array $lignes): string {
        $this->contenu = '';

        $this->rectangle(0, 690, 595, 152, '0.07 0.22 0.29');
        $this->rectangle(0, 684, 595, 6, '0.91 0.62 0.22');
        $this->texte(44, 790, 22, (string) ($lignes['vendeur_nom'] ?? 'ALLÔ PRO'), '1 1 1', true);
        $this->texte(44, 769, 9, 'SERVICES ET INTERVENTIONS', '0.77 0.85 0.87');

        $this->texte(392, 794, 22, 'FACTURE', '1 1 1', true);
        $this->texte(393, 773, 10, (string) ($lignes['numero'] ?? ''), '0.95 0.71 0.35', true);
        $this->texte(393, 752, 9, 'EMISE LE ' . strtoupper((string) ($lignes['date'] ?? '')), '0.84 0.89 0.90');
        $this->pastille(393, 718, 'PAYEE', '0.10 0.42 0.34', '0.81 0.96 0.87');

        $this->texte(44, 654, 9, 'VENDEUR', '0.39 0.48 0.52', true);
        $this->texte(310, 654, 9, 'FACTURE A', '0.39 0.48 0.52', true);
        $this->rectangle(38, 555, 250, 84, '0.96 0.97 0.97');
        $this->rectangle(302, 555, 255, 84, '0.96 0.97 0.97');
        $this->trait(44, 628, 100, 628, '0.91 0.62 0.22', 2);
        $this->trait(308, 628, 364, 628, '0.91 0.62 0.22', 2);

        $yVendeur = 613;
        $vendeur = array_values(array_filter($lignes['vendeur'] ?? [], static fn($ligne): bool => trim((string) $ligne) !== ''));
        foreach (array_slice($vendeur, 0, 4) as $index => $ligne) {
            $this->texte(44, $yVendeur, $index === 0 ? 10 : 8, (string) $ligne, '0.12 0.18 0.21', $index === 0);
            $yVendeur -= 14;
        }

        $yClient = 613;
        $client = array_values(array_filter($lignes['client'] ?? [], static fn($ligne): bool => trim((string) $ligne) !== ''));
        foreach (array_slice($client, 0, 4) as $index => $ligne) {
            $this->texte(310, $yClient, $index === 0 ? 10 : 8, (string) $ligne, '0.12 0.18 0.21', $index === 0);
            $yClient -= 14;
        }

        $this->rectangle(38, 512, 519, 28, '0.07 0.22 0.29');
        $this->texte(50, 522, 8, 'DESCRIPTION', '1 1 1', true);
        $this->texte(430, 522, 8, 'REFERENCE', '1 1 1', true);
        $this->texte(514, 522, 8, 'MONTANT', '1 1 1', true);

        $y = 489;
        $descriptions = $lignes['designation'] ?? [];
        foreach (array_slice($descriptions, 0, 3) as $index => $description) {
            $segments = $this->retournerALaLigne((string) $description, 49, 2);
            $hauteur = max(42, count($segments) * 13 + 17);
            $bas = $y - $hauteur + 8;
            if ($index % 2 === 0) {
                $this->rectangle(38, $bas, 519, $hauteur, '0.97 0.98 0.98');
            }
            $this->texte(50, $y - 7, 9, implode("\n", $segments), '0.12 0.18 0.21');
            $this->texte(430, $y - 7, 8, (string) ($lignes['reference_courte'] ?? 'Paiement'), '0.39 0.48 0.52');
            $this->texte(514, $y - 7, 9, (string) ($lignes['montant'] ?? '0') . ' F', '0.12 0.18 0.21', true);
            $y -= $hauteur;
        }
        if (!$descriptions) {
            $this->texte(50, $y - 7, 9, 'Prestation', '0.12 0.18 0.21');
            $this->texte(514, $y - 7, 9, (string) ($lignes['montant'] ?? '0') . ' F', '0.12 0.18 0.21', true);
            $y -= 42;
        }

        $this->trait(330, $y - 4, 557, $y - 4, '0.84 0.88 0.89', 1);
        $this->texte(340, $y - 25, 9, 'TOTAL TTC', '0.39 0.48 0.52', true);
        $this->rectangle(430, $y - 44, 127, 35, '0.07 0.22 0.29');
        $this->texte(441, $y - 32, 11, (string) ($lignes['montant'] ?? '0') . ' FCFA', '1 1 1', true);

        $yPaiement = max(120, $y - 120);
        $this->rectangle(38, $yPaiement, 519, 57, '0.96 0.97 0.97');
        $this->texte(50, $yPaiement + 39, 8, 'PAIEMENT CONFIRME', '0.10 0.42 0.34', true);
        $this->texte(50, $yPaiement + 20, 8, 'Reference : ' . (string) ($lignes['reference'] ?? ''), '0.25 0.34 0.38');
        $this->texte(340, $yPaiement + 20, 8, 'Moyen : ' . (string) ($lignes['methode'] ?? 'Paiement confirme'), '0.25 0.34 0.38');

        $this->trait(38, 66, 557, 66, '0.84 0.88 0.89', 1);
        $this->texte(38, 48, 8, (string) ($lignes['vendeur_nom'] ?? 'ALLÔ PRO') . ' - Merci pour votre confiance.', '0.39 0.48 0.52');
        $this->texte(494, 48, 8, 'DOCUMENT PDF', '0.39 0.48 0.52', true);

        return $this->construireDocument($this->contenu);
    }

    private function texte(float $x, float $y, int $taille, string $texte, string $couleur = '0.15 0.18 0.20', bool $gras = false): void {
        $police = $gras ? '/F2' : '/F1';
        $segments = explode("\n", $texte);
        foreach ($segments as $index => $segment) {
            $ascii = iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $segment);
            if ($ascii === false) {
                throw new RuntimeException('Impossible de convertir le texte de la facture.');
            }
            $ascii = str_replace(["\r", "\n"], ' ', $ascii);
            $escape = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $ascii);
            $this->contenu .= "BT {$couleur} rg {$police} {$taille} Tf {$x} " . ($y - ($index * ($taille + 4))) . " Td ({$escape}) Tj ET\n";
        }
    }

    private function rectangle(float $x, float $y, float $largeur, float $hauteur, string $couleur): void {
        $this->contenu .= "{$couleur} rg {$x} {$y} {$largeur} {$hauteur} re f\n";
    }

    private function trait(float $x1, float $y1, float $x2, float $y2, string $couleur, float $epaisseur): void {
        $this->contenu .= "{$couleur} RG {$epaisseur} w {$x1} {$y1} m {$x2} {$y2} l S\n";
    }

    private function pastille(float $x, float $y, string $texte, string $fond, string $couleur): void {
        $this->rectangle($x, $y, 72, 21, $fond);
        $this->texte($x + 11, $y + 7, 8, $texte, $couleur, true);
    }

    private function retournerALaLigne(string $texte, int $longueur, int $maximum): array {
        $texte = trim((string) preg_replace('/\s+/', ' ', $texte));
        if ($texte === '') {
            return [''];
        }
        $segments = preg_split('/\n/', wordwrap($texte, $longueur, "\n", true)) ?: [$texte];
        if (count($segments) <= $maximum) {
            return $segments;
        }
        $segments = array_slice($segments, 0, $maximum);
        $segments[$maximum - 1] = rtrim($segments[$maximum - 1], " .") . '...';
        return $segments;
    }

    private function construireDocument(string $contenu): string {
        $objets = [
            '<< /Type /Catalog /Pages 2 0 R >>',
            '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
            '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>',
            '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
            '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
            '<< /Length ' . strlen($contenu) . " >>\nstream\n{$contenu}endstream",
        ];
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $positions = [0];
        foreach ($objets as $index => $objet) {
            $positions[] = strlen($pdf);
            $pdf .= ($index + 1) . " 0 obj\n{$objet}\nendobj\n";
        }
        $positionXref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objets) + 1) . "\n0000000000 65535 f \n";
        foreach (array_slice($positions, 1) as $position) {
            $pdf .= sprintf("%010d 00000 n \n", $position);
        }
        $pdf .= 'trailer << /Size ' . (count($objets) + 1) . " /Root 1 0 R >>\nstartxref\n{$positionXref}\n%%EOF";
        return $pdf;
    }
}
