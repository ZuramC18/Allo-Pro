<?php
$moiNav = acteurCourant();
$pageCoordinateur = basename($_SERVER['PHP_SELF']);
?>
<nav class="coord-navbar">
    <div class="coord-navbar__gauche">
        <a href="../../public/index.php" class="coord-navbar__logo">ALLÔ<span> PRO</span></a>
        <div class="coord-navbar__liens">
            <a href="conversations.php" class="<?= $pageCoordinateur === 'conversations.php' ? 'actif' : '' ?>">Conversations</a>
            <a href="demandes.php" class="<?= in_array($pageCoordinateur, ['demandes.php', 'traiter-demande.php'], true) ? 'actif' : '' ?>">Demandes à traiter</a>
            <a href="refus-interventions.php" class="<?= $pageCoordinateur === 'refus-interventions.php' ? 'actif' : '' ?>">Refus d’interventions</a>
        </div>
    </div>
    <div class="coord-navbar__droite">
        <span>Coordinateur · <?= htmlspecialchars($moiNav['matricule'] ?? '') ?></span>
        <button type="button" class="coord-navbar__theme" id="coord-theme-toggle" role="switch" aria-checked="false" aria-label="Passer en mode sombre" title="Passer en mode sombre">
            <svg class="coord-theme-ico coord-theme-ico--lune" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
            <svg class="coord-theme-ico coord-theme-ico--soleil" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
        </button>
        <a href="../../public/deconnexion.php" class="coord-navbar__deconnexion">Déconnexion</a>
    </div>
</nav>