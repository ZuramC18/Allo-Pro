<?php

require_once __DIR__ . '/event-themes-manager.php';
$eventThemeConfig = chargerConfigurationThemesEvenementiels();
$eventThemeTimezone = new DateTimeZone('Africa/Dakar');
$eventThemeToday = (new DateTimeImmutable('now', $eventThemeTimezone))->format('m-d');
$activeEventTheme = null;
$activeEventThemePriority = PHP_INT_MIN;

foreach (($eventThemeConfig['enabled'] ?? false) ? $eventThemeConfig['themes'] : [] as $eventTheme) {
    if (
        !is_array($eventTheme)
        || empty($eventTheme['enabled'])
        || !isset($eventTheme['slug'], $eventTheme['start'], $eventTheme['end'], $eventTheme['priority'])
        || !is_string($eventTheme['slug'])
        || !is_string($eventTheme['start'])
        || !is_string($eventTheme['end'])
    ) {
        continue;
    }

    $start = $eventTheme['start'];
    $end = $eventTheme['end'];
    $isActive = $start <= $end
        ? $eventThemeToday >= $start && $eventThemeToday <= $end
        : $eventThemeToday >= $start || $eventThemeToday <= $end;

    $priority = $eventTheme['priority'];

    if ($isActive && $priority > $activeEventThemePriority) {
        $stylesheetPath = __DIR__ . '/../public/css/event-themes/' . $eventTheme['slug'] . '.css';
        if (is_file($stylesheetPath)) {
            $activeEventTheme = [
                'slug' => $eventTheme['slug'],
                'stylesheetPath' => $stylesheetPath,
                'animations' => $eventTheme['animations'] ?? true,
                'name' => $eventTheme['name'] ?? '',
                'greetingEnabled' => $eventTheme['greeting_enabled'] ?? true,
                'greetingMessage' => $eventTheme['greeting_message'] ?? '',
            ];
            $activeEventThemePriority = $priority;
        }
    }
}

if ($activeEventTheme !== null) {
    $scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $isClientView = strpos($scriptPath, '/views/client/') !== false;
    $isAdminView = strpos($scriptPath, '/views/admin/') !== false;
    $stylesheetUrl = ($isClientView || $isAdminView)
        ? '../../public/css/event-themes/' . $activeEventTheme['slug'] . '.css'
        : 'css/event-themes/' . $activeEventTheme['slug'] . '.css';
    $scriptUrlBase = ($isClientView || $isAdminView) ? '../../public/js/event-themes/' : 'js/event-themes/';
    ?>
    <script>
        document.documentElement.setAttribute('data-event-theme', <?= json_encode($activeEventTheme['slug'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>);
        document.documentElement.setAttribute('data-event-animations', <?= $activeEventTheme['animations'] ? '"1"' : '"0"' ?>);
    </script>
    <link rel="stylesheet" href="<?= htmlspecialchars($stylesheetUrl, ENT_QUOTES, 'UTF-8') ?>?v=<?= filemtime($activeEventTheme['stylesheetPath']) ?>">
    <?php foreach ($eventThemeConfig['themes'] as $themeConfig): ?>
        <?php if ($themeConfig['slug'] !== $activeEventTheme['slug']) { continue; } ?>
        <?php foreach ($themeConfig['animation_scripts'] ?? [] as $animationScript): ?>
            <?php
            $animationScriptPath = __DIR__ . '/../public/js/event-themes/' . $activeEventTheme['slug'] . '/' . $animationScript;
            if (!is_file($animationScriptPath)) {
                error_log('Fichier d’animation de thème introuvable : ' . $animationScriptPath);
                continue;
            }
            ?>
            <script src="<?= htmlspecialchars($scriptUrlBase . rawurlencode($activeEventTheme['slug']) . '/' . rawurlencode($animationScript), ENT_QUOTES, 'UTF-8') ?>?v=<?= filemtime($animationScriptPath) ?>" defer></script>
        <?php endforeach; ?>
    <?php endforeach; ?>
    <?php
}
