<?php
require_once __DIR__ . '/../models/OutilsEquipe.php';

$idClient = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($idClient === false) {
    http_response_code(400);
    exit('Identifiant client invalide.');
}

$outilEquipe = new OutilsEquipe();
$clientFiche = $outilEquipe->getFicheClient((int) $idClient);
if (!$clientFiche) {
    http_response_code(404);
    exit('Client introuvable.');
}
$dossiersClient = $outilEquipe->getDossiersClient((int) $idClient);
$adressesClient = $outilEquipe->getAdressesClient((int) $idClient);
$photoClient = is_string($clientFiche['photo_profil'] ?? null)
    && preg_match('#^uploads/profils/clients/[a-f0-9]{32}\.(?:jpg|png|webp)$#', $clientFiche['photo_profil']) === 1
    && empty($clientFiche['avatar_initiales'])
        ? $clientFiche['photo_profil']
        : null;
$roleFicheClient = (string) $_SESSION['role'];
$eFicheClient = static fn($valeur): string => htmlspecialchars((string) ($valeur ?? ''), ENT_QUOTES, 'UTF-8');
$fichierSidebarClient = [
    'admin' => 'sidebar-admin.php',
    'conseiller' => 'sidebar-conseiller.php',
    'coordinateur' => 'sidebar-coordinateur.php',
    'finance' => 'sidebar-admin.php',
    'qualite' => 'sidebar-qualite.php',
][$roleFicheClient];
$fichierCssClient = match ($roleFicheClient) {
    'coordinateur' => ['coordinateur.css', 'coordinateur-espace.css'],
    'admin', 'finance', 'qualite' => ['admin.css'],
    default => ['dashboard.css'],
};
$urlRetourRecherche = $roleFicheClient === 'qualite'
    ? '../commun/equipe?section=recherche'
    : 'equipe?section=recherche';
$urlDossier = match ($roleFicheClient) {
    'finance' => '../admin/traiter-demande?id=',
    'qualite' => 'demande?id=',
    default => 'traiter-demande?id=',
};
$statutsDemande = [
    'nouvelle' => 'Nouvelle',
    'attribuee' => 'Attribuée',
    'attribuee_a_un_partenaire' => 'Attribuée à un partenaire',
    'attribuee_automatiquement' => 'Attribuée automatiquement',
    'en_cours' => 'En cours',
    'terminee' => 'Terminée',
    'annulee' => 'Annulée',
];
$statutsIntervention = [
    'en_attente' => 'En attente du technicien',
    'acceptee' => 'Acceptée par le technicien',
    'en_route' => 'Technicien en route',
    'arrive' => 'Technicien arrivé',
    'diagnostic' => 'Diagnostic',
    'en_cours' => 'Intervention en cours',
    'terminee' => 'Intervention terminée',
    'refusee' => 'Refusée',
    'annulee' => 'Annulée',
];
$titreFiche = trim((string) $clientFiche['prenom'] . ' ' . (string) $clientFiche['nom']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $eFicheClient($titreFiche) ?> — Fiche client</title>
    <link rel="icon" type="image/png" href="../../public/images/icon.png">
    <?php foreach ($fichierCssClient as $cssClient): ?>
        <link rel="stylesheet" href="../../public/css/<?= $eFicheClient($cssClient) ?>?v=<?= filemtime(__DIR__ . '/../public/css/' . $cssClient) ?>">
    <?php endforeach; ?>
    <?php include __DIR__ . '/theme-head.php'; ?>
    <link rel="stylesheet" href="../../public/css/employee-tools.css?v=<?= filemtime(__DIR__ . '/../public/css/employee-tools.css') ?>">
</head>
<body class="fiche-client-equipe">
<?php if ($roleFicheClient === 'coordinateur'): ?>
    <div class="coord-shell">
        <?php include __DIR__ . '/' . $fichierSidebarClient; ?>
        <main class="coord-main"><div class="equipe-page fiche-client-equipe__contenu">
<?php elseif (in_array($roleFicheClient, ['admin', 'finance', 'qualite'], true)): ?>
    <div class="admin-app">
        <?php include __DIR__ . '/' . $fichierSidebarClient; ?>
        <main class="admin-contenu"><div class="equipe-page fiche-client-equipe__contenu">
<?php else: ?>
    <div class="app">
        <?php include __DIR__ . '/' . $fichierSidebarClient; ?>
        <main class="contenu"><div class="equipe-page fiche-client-equipe__contenu">
<?php endif; ?>
            <header class="equipe-entete">
                <div>
                    <a href="<?= $eFicheClient($urlRetourRecherche) ?>" class="fiche-client-equipe__retour">← Retour à la recherche</a>
                    <p class="equipe-surtitre">Fiche client</p>
                    <h1><?= $eFicheClient($titreFiche) ?></h1>
                    <p>Coordonnées, état du compte et historique complet des dossiers.</p>
                </div>
                <span class="equipe-badge <?= $clientFiche['statut'] === 'actif' ? 'equipe-badge--ok' : 'equipe-badge--retard' ?>">
                    <?= $clientFiche['statut'] === 'actif' ? 'Compte actif' : 'Compte ' . $eFicheClient($clientFiche['statut']) ?>
                </span>
            </header>
            <section class="fiche-client-equipe__profil" aria-label="Coordonnées du client">
                <article class="equipe-carte">
                    <h2>Coordonnées</h2>
                    <dl>
                        <div><dt>Nom complet</dt><dd><?= $eFicheClient($titreFiche) ?></dd></div>
                        <div><dt>Téléphone</dt><dd><?= $clientFiche['telephone'] ? $eFicheClient($clientFiche['telephone']) : 'Non renseigné' ?></dd></div>
                        <div><dt>Adresse e-mail</dt><dd><?= $eFicheClient($clientFiche['email']) ?></dd></div>
                        <div><dt>E-mail vérifié</dt><dd><?= !empty($clientFiche['email_verifie']) ? 'Oui' : 'Non' ?></dd></div>
                        <div><dt>Client depuis</dt><dd><?= $eFicheClient(date('d/m/Y', strtotime($clientFiche['date_creation']))) ?></dd></div>
                        <div><dt>Identifiant client</dt><dd>CLIENT-<?= (int) $clientFiche['id'] ?></dd></div>
                    </dl>
                </article>
                <article class="equipe-kpi">
                    <strong><?= count($dossiersClient) ?></strong>
                    <span><?= count($dossiersClient) === 1 ? 'Dossier au total' : 'Dossiers au total' ?></span>
                </article>
            </section>
            <?php if ($photoClient || $adressesClient): ?>
                <section class="fiche-client-equipe__infos" aria-label="Photo et adresses du client">
                    <?php if ($photoClient): ?><article class="equipe-carte"><h2>Photo de profil</h2><img class="fiche-client-equipe__photo" src="../../public/<?= $eFicheClient($photoClient) ?>" alt="Photo de profil de <?= $eFicheClient($titreFiche) ?>"></article><?php endif; ?>
                    <?php if ($adressesClient): ?><article class="equipe-carte"><h2>Adresses enregistrées</h2><?php foreach ($adressesClient as $adresse): ?><p class="fiche-client-equipe__adresse"><strong><?= $eFicheClient($adresse['libelle'] ?: 'Adresse') ?></strong><br><?= $eFicheClient(implode(', ', array_filter([$adresse['details'], $adresse['quartier'], $adresse['ville']]))) ?><?= $adresse['adresse_google'] ? '<br>' . $eFicheClient($adresse['adresse_google']) : '' ?></p><?php endforeach; ?></article><?php endif; ?>
                </section>
            <?php endif; ?>
            <section class="equipe-carte fiche-client-equipe__dossiers" aria-labelledby="fiche-client-dossiers">
                <header><h2 id="fiche-client-dossiers">Historique des dossiers</h2><span><?= count($dossiersClient) ?> au total</span></header>
                <?php if (!$dossiersClient): ?><p class="equipe-vide">Aucun dossier associé à ce client.</p><?php endif; ?>
                <?php foreach ($dossiersClient as $dossier): ?>
                    <article class="fiche-client-equipe__dossier">
                        <header>
                            <div>
                                <a href="<?= $eFicheClient($urlDossier) ?><?= (int) $dossier['id'] ?>"><strong><?= $eFicheClient($dossier['numero_dossier']) ?></strong></a>
                                <span class="equipe-badge"><?= $eFicheClient($dossier['categorie'] ?: 'Catégorie non définie') ?></span>
                                <?php if (!empty($dossier['site_b2b_id'])): ?><span class="equipe-badge">Demande entreprise</span><?php endif; ?>
                            </div>
                            <span class="equipe-badge <?= $dossier['statut'] === 'terminee' ? 'equipe-badge--ok' : '' ?>">
                                <?= $eFicheClient($statutsDemande[$dossier['statut']] ?? str_replace('_', ' ', $dossier['statut'])) ?>
                            </span>
                        </header>
                        <p><?= nl2br($eFicheClient($dossier['description'] ?: 'Aucune description fournie.')) ?></p>
                        <dl>
                            <div><dt>Créé le</dt><dd><?= $eFicheClient(date('d/m/Y H:i', strtotime($dossier['date_creation']))) ?></dd></div>
                            <div><dt>Urgence</dt><dd><?= $eFicheClient(ucfirst((string) $dossier['urgence'])) ?></dd></div>
                            <?php if ($dossier['date_creneau_souhaite']): ?>
                                <div><dt>Créneau souhaité</dt><dd><?= $eFicheClient(date('d/m/Y', strtotime($dossier['date_creneau_souhaite']))) ?><?= $dossier['heure_creneau_souhaitee'] ? ' · ' . $eFicheClient(substr((string) $dossier['heure_creneau_souhaitee'], 0, 5)) : '' ?></dd></div>
                            <?php endif; ?>
                            <?php if ($dossier['adresse_libelle'] || $dossier['adresse_details'] || $dossier['adresse_quartier'] || $dossier['adresse_ville']): ?>
                                <div><dt>Adresse d’intervention</dt><dd><?= $eFicheClient(implode(', ', array_filter([$dossier['adresse_libelle'], $dossier['adresse_details'], $dossier['adresse_quartier'], $dossier['adresse_ville']]))) ?></dd></div>
                            <?php endif; ?>
                            <?php if ($dossier['intervention_statut']): ?>
                                <div><dt>Intervention</dt><dd><?= $eFicheClient($statutsIntervention[$dossier['intervention_statut']] ?? str_replace('_', ' ', $dossier['intervention_statut'])) ?><?= $dossier['technicien_nom'] ? ' · ' . $eFicheClient($dossier['technicien_nom']) : '' ?></dd></div>
                            <?php endif; ?>
                            <?php if ($dossier['paiement_statut']): ?>
                                <div><dt>Paiement</dt><dd><?= $eFicheClient(str_replace('_', ' ', $dossier['paiement_statut'])) ?></dd></div>
                            <?php endif; ?>
                        </dl>
                        <a class="equipe-bouton equipe-bouton--secondaire" href="<?= $eFicheClient($urlDossier) ?><?= (int) $dossier['id'] ?>">Ouvrir le dossier</a>
                    </article>
                <?php endforeach; ?>
            </section>
        </div></main>
    </div>
</body>
</html>
