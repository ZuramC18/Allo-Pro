<?php

function themesEvenementielsParDefaut(): array
{
    return require __DIR__ . '/../config/event-themes.php';
}

function signatureDatesConfirmationAnnuelle(array $themes, int $annee): string
{
    $dates = [];
    foreach ($themes as $theme) {
        if (!is_array($theme) || empty($theme['annual_date_confirmation'])) {
            continue;
        }
        $dates[$theme['slug']] = [
            'start' => $theme['start'],
            'end' => $theme['end'],
        ];
    }
    ksort($dates);

    return hash('sha256', $annee . ':' . json_encode($dates, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
}

function validerConfigurationThemesEvenementiels(array $configuration, ?string &$erreur = null): bool
{
    if (!isset($configuration['enabled']) || !is_bool($configuration['enabled'])) {
        $erreur = 'Le réglage général doit être activé ou désactivé.';
        return false;
    }

    if (!isset($configuration['themes']) || !is_array($configuration['themes'])) {
        $erreur = 'La liste des thèmes est invalide.';
        return false;
    }

    if (
        array_key_exists('dates_confirmation_dismissed_year', $configuration)
        && (
            !is_int($configuration['dates_confirmation_dismissed_year'])
            || $configuration['dates_confirmation_dismissed_year'] < 2000
            || $configuration['dates_confirmation_dismissed_year'] > 9999
        )
    ) {
        $erreur = 'L’année de masquage du rappel est invalide.';
        return false;
    }
    if (
        array_key_exists('dates_confirmation_dismissed_signature', $configuration)
        && (
            !is_string($configuration['dates_confirmation_dismissed_signature'])
            || !preg_match('/^[a-f0-9]{64}$/', $configuration['dates_confirmation_dismissed_signature'])
        )
    ) {
        $erreur = 'La signature du masquage du rappel est invalide.';
        return false;
    }

    $slugs = [];
    foreach ($configuration['themes'] as $theme) {
        if (!is_array($theme) || !is_string($theme['name'] ?? null)) {
            $erreur = 'Un thème doit avoir un nom valide.';
            return false;
        }
        $nomTheme = trim($theme['name']);
        $longueurNomTheme = preg_match_all('/./us', $nomTheme);

        if (
            !isset($theme['name'], $theme['slug'], $theme['start'], $theme['end'], $theme['priority'], $theme['enabled'])
            || $nomTheme === ''
            || $longueurNomTheme === false
            || $longueurNomTheme > 60
            || !is_string($theme['slug'])
            || !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $theme['slug'])
            || strlen($theme['slug']) > 40
            || !is_string($theme['start'])
            || !preg_match('/^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/', $theme['start'])
            || !is_string($theme['end'])
            || !preg_match('/^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/', $theme['end'])
            || !checkdate((int) substr($theme['start'], 0, 2), (int) substr($theme['start'], 3, 2), 2000)
            || !checkdate((int) substr($theme['end'], 0, 2), (int) substr($theme['end'], 3, 2), 2000)
            || !is_int($theme['priority'])
            || $theme['priority'] < -1000
            || $theme['priority'] > 1000
            || !is_bool($theme['enabled'])
            || (array_key_exists('animations', $theme) && !is_bool($theme['animations']))
            || (array_key_exists('greeting_enabled', $theme) && !is_bool($theme['greeting_enabled']))
            || (array_key_exists('greeting_message', $theme) && (
                !is_string($theme['greeting_message'])
                || mb_strlen($theme['greeting_message'], 'UTF-8') > 300
            ))
            || (array_key_exists('annual_date_confirmation', $theme) && !is_bool($theme['annual_date_confirmation']))
            || (
                (
                    array_key_exists('dates_confirmed_year', $theme)
                    || array_key_exists('dates_confirmed_start', $theme)
                    || array_key_exists('dates_confirmed_end', $theme)
                )
                && (
                    !is_int($theme['dates_confirmed_year'] ?? null)
                    || $theme['dates_confirmed_year'] < 2000
                    || $theme['dates_confirmed_year'] > 9999
                    || !is_string($theme['dates_confirmed_start'] ?? null)
                    || !preg_match('/^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/', $theme['dates_confirmed_start'])
                    || !checkdate((int) substr($theme['dates_confirmed_start'], 0, 2), (int) substr($theme['dates_confirmed_start'], 3, 2), 2000)
                    || !is_string($theme['dates_confirmed_end'] ?? null)
                    || !preg_match('/^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/', $theme['dates_confirmed_end'])
                    || !checkdate((int) substr($theme['dates_confirmed_end'], 0, 2), (int) substr($theme['dates_confirmed_end'], 3, 2), 2000)
                )
            )
            || (array_key_exists('animation_scripts', $theme) && (
                !is_array($theme['animation_scripts'])
                || count(array_filter($theme['animation_scripts'], static fn($script): bool => is_string($script) && preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*\.js$/', $script))) !== count($theme['animation_scripts'])
                || count(array_unique($theme['animation_scripts'])) !== count($theme['animation_scripts'])
            ))
        ) {
            $erreur = 'Un thème contient des informations invalides. Vérifiez son nom, son identifiant, ses dates et sa priorité.';
            return false;
        }

        if (isset($slugs[$theme['slug']])) {
            $erreur = 'Chaque thème doit avoir un identifiant unique.';
            return false;
        }
        $slugs[$theme['slug']] = true;
    }

    return true;
}

function chargerConfigurationThemesEvenementiels(?string &$erreur = null): array
{
    $chemin = __DIR__ . '/../storage/event-themes.json';
    if (!is_file($chemin)) {
        return themesEvenementielsParDefaut();
    }

    $contenu = file_get_contents($chemin);
    if ($contenu === false) {
        $erreur = 'Impossible de lire la configuration enregistrée des thèmes.';
        error_log($erreur);
        return ['enabled' => false, 'themes' => []];
    }

    try {
        $configuration = json_decode($contenu, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException $exception) {
        $erreur = 'La configuration enregistrée des thèmes est illisible. Enregistrez une configuration valide pour la réparer.';
        error_log($erreur . ' ' . $exception->getMessage());
        return ['enabled' => false, 'themes' => []];
    }

    $defaultAnimations = [];
    foreach (themesEvenementielsParDefaut()['themes'] as $themeParDefaut) {
        $defaultAnimations[$themeParDefaut['slug']] = [
            'animations' => $themeParDefaut['animations'] ?? true,
            'annual_date_confirmation' => $themeParDefaut['annual_date_confirmation'] ?? false,
            'greeting_enabled' => $themeParDefaut['greeting_enabled'] ?? true,
            'greeting_message' => $themeParDefaut['greeting_message'] ?? '',
            'animation_scripts' => $themeParDefaut['animation_scripts'] ?? [],
        ];
    }
    if (is_array($configuration) && isset($configuration['themes']) && is_array($configuration['themes'])) {
        foreach ($configuration['themes'] as &$theme) {
            if (is_array($theme) && !array_key_exists('animations', $theme)) {
                $theme['animations'] = $defaultAnimations[$theme['slug'] ?? '']['animations'] ?? true;
            }
            if (is_array($theme) && !array_key_exists('animation_scripts', $theme)) {
                $theme['animation_scripts'] = $defaultAnimations[$theme['slug'] ?? '']['animation_scripts'] ?? [];
            }
            if (is_array($theme) && !array_key_exists('annual_date_confirmation', $theme)) {
                $theme['annual_date_confirmation'] = $defaultAnimations[$theme['slug'] ?? '']['annual_date_confirmation'] ?? false;
            }
            if (is_array($theme) && !array_key_exists('greeting_message', $theme)) {
                $theme['greeting_message'] = $defaultAnimations[$theme['slug'] ?? '']['greeting_message'] ?? '';
            }
            if (is_array($theme) && !array_key_exists('greeting_enabled', $theme)) {
                $theme['greeting_enabled'] = $defaultAnimations[$theme['slug'] ?? '']['greeting_enabled'] ?? true;
            }
        }
        unset($theme);
    }

    if (!is_array($configuration) || !validerConfigurationThemesEvenementiels($configuration, $erreur)) {
        $erreur = $erreur ?? 'La configuration enregistrée des thèmes est invalide.';
        error_log($erreur);
        return ['enabled' => false, 'themes' => []];
    }

    return $configuration;
}

function enregistrerConfigurationThemesEvenementiels(array $configuration): void
{
    $erreurValidation = null;
    if (!validerConfigurationThemesEvenementiels($configuration, $erreurValidation)) {
        throw new InvalidArgumentException($erreurValidation ?? 'Configuration de thèmes invalide.');
    }

    $chemin = __DIR__ . '/../storage/event-themes.json';
    $fichierTemporaire = tempnam(dirname($chemin), 'themes-');
    if ($fichierTemporaire === false) {
        throw new RuntimeException('Impossible de préparer l’enregistrement des thèmes.');
    }

    $json = json_encode($configuration, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . PHP_EOL;
    if (file_put_contents($fichierTemporaire, $json, LOCK_EX) === false || !rename($fichierTemporaire, $chemin)) {
        if (is_file($fichierTemporaire)) {
            unlink($fichierTemporaire);
        }
        throw new RuntimeException('Impossible d’enregistrer la configuration des thèmes dans le dossier storage.');
    }
}
