<?php
require_once __DIR__ . '/../config/database.php';

function paysDepuisIp($ip) {
    if (!$ip) return null;

    // Adresses locales (développement sous WAMP, réseau interne) : aucune géolocalisation possible
    if (in_array($ip, ['127.0.0.1', '::1'], true) || preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $ip)) {
        return 'Local';
    }

    $conn = (new Database())->getConnection();

    // 1. Vérifie le cache avant tout appel réseau
    $stmt = $conn->prepare("SELECT pays FROM ip_pays_cache WHERE ip = :ip");
    $stmt->execute([':ip' => $ip]);
    $enCache = $stmt->fetch();
    if ($enCache) return $enCache['pays'];

    // 2. Appel à l'API (gratuite, sans clé, limitée à 45 requêtes/minute) avec un délai court pour ne jamais bloquer une action
    $pays = null;
    $contexte = stream_context_create(['http' => ['timeout' => 2]]);
    $reponse = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,country", false, $contexte);

    if ($reponse) {
        $donnees = json_decode($reponse, true);
        if (($donnees['status'] ?? '') === 'success') {
            $pays = $donnees['country'];
        }
    }

    // 3. Met en cache même un échec (pays = NULL), pour ne pas re-tenter sur chaque action tant que l'IP n'est pas levée manuellement du cache
    $stmtInsert = $conn->prepare("INSERT INTO ip_pays_cache (ip, pays) VALUES (:ip, :pays) ON DUPLICATE KEY UPDATE pays = :pays2");
    $stmtInsert->execute([':ip' => $ip, ':pays' => $pays, ':pays2' => $pays]);

    return $pays;
}