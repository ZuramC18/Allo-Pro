<?php
session_start();
require_once __DIR__ . '/audit.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/documents-partenaires.php';

function verifierPartenaireConnecte() {
    if (!isset($_SESSION['partenaire_id'])) {
        header("Location: /allopro/public/connexion-partenaire.php");
        exit;
    }

    $stmt = (new Database())->getConnection()->prepare(
        "SELECT nom_entreprise, statut, photo_profil, avatar_initiales, contrat_signe_at
         FROM partenaires WHERE id = :id"
    );
    $stmt->execute([':id' => $_SESSION['partenaire_id']]);
    $p = $stmt->fetch();

    if (!$p || $p['statut'] !== 'actif') {
        journaliser('session.coupee', 'compte', $_SESSION['partenaire_id'], $_SESSION['partenaire_nom'] ?? null, 'Partenaire désactivé pendant une session active');
        unset($_SESSION['partenaire_id'], $_SESSION['partenaire_nom']);
        header("Location: /allopro/public/connexion-partenaire.php?raison=suspendu");
        exit;
    }
    $_SESSION['partenaire_nom'] = $p['nom_entreprise'];
    $_SESSION['partenaire_photo_profil'] = $p['photo_profil'];
    $_SESSION['partenaire_avatar_initiales'] = (bool) $p['avatar_initiales'];

    $pageActuelle = basename((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''));
    if (empty($p['contrat_signe_at'])
        && !in_array($pageActuelle, ['contrat.php', 'conditions-generales.php', 'profil.php'], true)) {
        header('Location: /allopro/views/partenaire/contrat.php');
        exit;
    }
}