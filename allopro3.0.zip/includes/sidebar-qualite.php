<?php
$pageActuelle = basename($_SERVER['PHP_SELF']);
require_once __DIR__ . '/icones.php';
require_once __DIR__ . '/acces.php';
require_once __DIR__ . '/../models/TicketSav.php';
$moiSidebar = acteurCourant();
$liensQualite = [
    ['../commun/equipe.php', 'calendar', 'Ma journée', 'tableau_bord'],
    ['accueil.php', 'dashboard', 'Tableau de bord', 'tableau_bord'],
    ['sav.php', 'headset', 'Tous les tickets SAV', 'sav'],
    ['messagerie.php', 'message', 'Messagerie clients', 'messagerie'],
    ['messagerie-interne.php', 'messages', 'Messagerie interne', 'messagerie_interne'],
    ['recherche-clients.php', 'users', 'Recherche clients', 'clients'],
    ['devis-entreprises.php', 'file-text', 'Devis entreprises', 'devis_entreprises'],
];
$categoriesQualite = [
    'mauvaise_experience' => ['Mauvaise expérience', 'star'],
    'reclamation' => ['Réclamations', 'message'],
    'incident' => ['Incidents', 'alert'],
    'retard' => ['Retards', 'clock'],
    'intervention_incomplete' => ['Interventions incomplètes', 'wrench'],
    'reintervention' => ['Réinterventions', 'refresh'],
    'litige' => ['Litiges', 'shield'],
    'remboursement' => ['Remboursements', 'card'],
];
$ticketModelSidebar = isset($ticketModel) && $ticketModel instanceof TicketSav
    ? $ticketModel
    : new TicketSav();
$compteursCategoriesSidebar = $ticketModelSidebar->compterParCategorieQualite();
$compteursStatutSidebar = $ticketModelSidebar->compterParStatut();
$compteursOrigineSidebar = $ticketModelSidebar->compterParOrigine();
$categorieSelectionnee = is_string($_GET['categorie'] ?? null) && array_key_exists($_GET['categorie'], $categoriesQualite)
    ? $_GET['categorie']
    : '';
$statutSelectionne = is_string($_GET['statut'] ?? null) ? $_GET['statut'] : '';
$noteMaxSelectionnee = filter_var($_GET['note_max'] ?? null, FILTER_VALIDATE_INT);
$vueSavActive = in_array($pageActuelle, ['sav.php', 'sav-ticket.php', 'sav-detail.php'], true);
$lienTousTicketsActif = $vueSavActive
    && $categorieSelectionnee === ''
    && $statutSelectionne === ''
    && ($noteMaxSelectionnee === false || $noteMaxSelectionnee === null);
?>
<script>
(function () {
    try {
        var theme = localStorage.getItem('allopro_theme');
        if (theme !== 'dark' && theme !== 'light') theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', theme);
    } catch (e) { document.documentElement.setAttribute('data-theme', 'light'); }
    try {
        if (window.matchMedia('(max-width: 1024px)').matches || localStorage.getItem('allopro_sidebar') === 'closed') {
            document.documentElement.classList.add('sidebar-fermee');
        }
    } catch (e) {}
})();
</script>
<link rel="stylesheet" href="../../public/css/theme-admin.css?v=<?= filemtime(__DIR__ . '/../public/css/theme-admin.css') ?>">
<?php afficherFlashAcces(); ?>
<div class="admin-sidebar">
    <div class="tete">
        <span class="admin-sidebar__logo">ALLÔ<span> PRO</span></span>
        <div class="admin-sidebar__actions">
            <button type="button" class="admin-sidebar__theme" id="theme-toggle" role="switch" aria-checked="false" aria-label="Mode sombre" title="Mode sombre">
                <svg class="theme-ico theme-ico--lune" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
                <svg class="theme-ico theme-ico--soleil" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
            </button>
            <button type="button" class="admin-sidebar__fermer" id="sidebar-fermer" aria-label="Masquer le menu" title="Masquer le menu">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m11 17-5-5 5-5"/><path d="m18 17-5-5 5-5"/></svg>
            </button>
        </div>
    </div>
    <div class="admin-sidebar__role"><?= htmlspecialchars((LIBELLES_ROLES[$_SESSION['role']] ?? 'Qualité') . ' · ' . ($moiSidebar['matricule'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></div>
    <div class="admin-sidebar__section-titre">Espace Qualité</div>
    <?php foreach ($liensQualite as [$href, $icone, $libelle, $module]): ?>
        <?php if ($href === '../commun/equipe.php' || peut($module)): ?>
            <?php
            $lienActif = $href === 'sav.php'
                ? $lienTousTicketsActif
                : (basename($href) === $pageActuelle
                    || ($href === 'recherche-clients.php' && in_array($pageActuelle, ['detail-client.php', 'demande.php'], true)));
            ?>
            <a href="<?= htmlspecialchars($href, ENT_QUOTES, 'UTF-8') ?>" class="admin-sidebar__lien <?= $lienActif ? 'admin-sidebar__lien--actif' : '' ?>">
                <span class="admin-sidebar__icone"><?= icone($icone, 18) ?></span> <?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?>
            </a>
        <?php endif; ?>
    <?php endforeach; ?>
    <?php if (peut('sav')): ?>
        <div class="admin-sidebar__section-titre">Priorités SAV</div>
        <a href="sav.php?statut=ouvert" class="admin-sidebar__lien <?= $vueSavActive && $statutSelectionne === 'ouvert' ? 'admin-sidebar__lien--actif' : '' ?>">
            <span class="admin-sidebar__icone"><?= icone('alert', 18) ?></span>
            À traiter
            <span class="qualite-sidebar-count"><?= (int) ($compteursStatutSidebar['ouvert'] ?? 0) ?></span>
        </a>
        <a href="sav.php?note_max=2" class="admin-sidebar__lien <?= $vueSavActive && (int) $noteMaxSelectionnee === 2 ? 'admin-sidebar__lien--actif' : '' ?>">
            <span class="admin-sidebar__icone"><?= icone('star', 18) ?></span>
            Avis faibles
            <span class="qualite-sidebar-count"><?= (int) ($compteursOrigineSidebar['client'] ?? 0) ?></span>
        </a>
        <div class="admin-sidebar__section-titre">Dossiers par catégorie</div>
        <?php foreach ($categoriesQualite as $categorie => [$libelle, $icone]): ?>
            <a href="sav.php?categorie=<?= rawurlencode($categorie) ?>" class="admin-sidebar__lien <?= $categorieSelectionnee === $categorie && $vueSavActive ? 'admin-sidebar__lien--actif' : '' ?>">
                <span class="admin-sidebar__icone"><?= icone($icone, 18) ?></span>
                <?= htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8') ?>
                <span class="qualite-sidebar-count"><?= (int) ($compteursCategoriesSidebar[$categorie] ?? 0) ?></span>
            </a>
        <?php endforeach; ?>
    <?php endif; ?>
    <div class="admin-sidebar__bas">
        <a href="profil.php" class="admin-sidebar__lien <?= $pageActuelle === 'profil.php' ? 'admin-sidebar__lien--actif' : '' ?>">
            <span class="admin-sidebar__icone"><?= icone('user', 18) ?></span> Mon profil
        </a>
        <a href="../../public/deconnexion.php" class="admin-sidebar__lien">
            <span class="admin-sidebar__icone"><?= icone('logout', 18) ?></span> Déconnexion
        </a>
    </div>
</div>
<div class="admin-sidebar__voile" id="sidebar-voile"></div>
<button type="button" class="admin-sidebar__ouvrir" id="sidebar-ouvrir" aria-label="Afficher le menu" aria-expanded="false" title="Afficher le menu">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
</button>
<span class="admin-sidebar__site-link" aria-label="ALLÔ PRO">ALLÔ<span> PRO</span></span>
<div class="admin-sidebar__top-actions">
    <?php if ($pageActuelle !== 'accueil.php'): ?>
        <span class="admin-sidebar__nom-utilisateur" title="<?= htmlspecialchars($_SESSION['nom'] ?? 'Qualité', ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($_SESSION['nom'] ?? 'Qualité', ENT_QUOTES, 'UTF-8') ?></span>
    <?php endif; ?>
    <button type="button" class="admin-sidebar__theme-top" id="theme-toggle-top" role="switch" aria-checked="false" aria-label="Passer en mode sombre" title="Passer en mode sombre">
        <svg class="theme-ico theme-ico--lune" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
        <svg class="theme-ico theme-ico--soleil" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
    </button>
</div>
<script>
(function () {
    const html = document.documentElement;
    const buttons = [document.getElementById('theme-toggle'), document.getElementById('theme-toggle-top')].filter(Boolean);
    function applyTheme(theme, persist) {
        html.setAttribute('data-theme', theme);
        buttons.forEach(button => {
            button.setAttribute('aria-checked', theme === 'dark' ? 'true' : 'false');
            button.setAttribute('aria-label', theme === 'dark' ? 'Passer en mode clair' : 'Passer en mode sombre');
            button.setAttribute('title', theme === 'dark' ? 'Passer en mode clair' : 'Passer en mode sombre');
        });
        if (persist) { try { localStorage.setItem('allopro_theme', theme); } catch (e) {} }
    }
    applyTheme(html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light', false);
    buttons.forEach(button => button.addEventListener('click', () => applyTheme(html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', true)));
    window.addEventListener('storage', event => {
        if (event.key === 'allopro_theme' && ['dark', 'light'].includes(event.newValue)) applyTheme(event.newValue, false);
    });
})();
(function () {
    const html = document.documentElement;
    const sidebar = document.querySelector('.admin-sidebar');
    const open = document.getElementById('sidebar-ouvrir');
    const close = document.getElementById('sidebar-fermer');
    const veil = document.getElementById('sidebar-voile');
    if (!sidebar || !open || !close || !veil) return;
    const mobile = window.matchMedia('(max-width: 1024px)');
    function setClosed(closed, persist) {
        html.classList.toggle('sidebar-fermee', closed);
        open.setAttribute('aria-expanded', closed ? 'false' : 'true');
        if (persist && !mobile.matches) {
            try { localStorage.setItem('allopro_sidebar', closed ? 'closed' : 'open'); } catch (e) {}
        }
    }
    setClosed(html.classList.contains('sidebar-fermee'), false);
    open.addEventListener('click', () => { setClosed(false, true); close.focus(); });
    close.addEventListener('click', () => { setClosed(true, true); open.focus(); });
    veil.addEventListener('click', () => { setClosed(true, false); open.focus(); });
    sidebar.querySelectorAll('.admin-sidebar__lien').forEach(link => link.addEventListener('click', () => {
        if (mobile.matches) setClosed(true, false);
    }));
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && mobile.matches && !html.classList.contains('sidebar-fermee')) {
            setClosed(true, false);
            open.focus();
        }
    });
    const onBreakpointChange = () => {
        if (mobile.matches) { setClosed(true, false); return; }
        let preference = null;
        try { preference = localStorage.getItem('allopro_sidebar'); } catch (e) {}
        setClosed(preference === 'closed', false);
    };
    if (mobile.addEventListener) mobile.addEventListener('change', onBreakpointChange);
    else mobile.addListener(onBreakpointChange);
})();
</script>
