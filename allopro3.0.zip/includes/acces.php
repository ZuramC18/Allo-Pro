<?php
/**
 * Gestion des accès refusés : plus de message brut « Accès refusé », mais une réaction adaptée.
 *
 *  - Pas connecté                                  -> page de connexion
 *  - Connecté, mais dans l'espace d'un autre rôle  -> page 404 (comme si l'adresse n'existait pas :
 *    un client qui devine /admin/... ne découvre même pas que cet espace existe)
 *  - Connecté, bon espace, mais module non autorisé -> retour à son accueil + petit message
 *
 * Utilisation : dans includes/auth.php, partout où tu affiches « Accès refusé », appelle simplement refuserAcces();
 */

// ---- À ADAPTER : adresse d'accueil de chaque espace --------------------------------------------
if (!function_exists('accueilPourRole')) {
    function accueilPourRole(): string {
        if (isset($_SESSION['technicien_id'])) return '/technicien/accueil';
        if (isset($_SESSION['partenaire_id'])) return '/partenaire/accueil';
        switch ($_SESSION['role'] ?? '') {
            case 'client':       return '/client/accueil';
            case 'conseiller':   return '/conseiller/accueil';
            case 'coordinateur': return '/coordinateur/index';
            case 'qualite':      return '/qualite/accueil';
            case 'finance':      return '/finance/accueil';
            default:             return '/admin/accueil';
        }
    }
}

// Dossiers de views/ que la personne connectée a le droit d'ouvrir
if (!function_exists('espacesAutorises')) {
    function espacesAutorises(): array {
        if (isset($_SESSION['technicien_id'])) return ['technicien'];
        if (isset($_SESSION['partenaire_id'])) return ['partenaire'];
        if (($_SESSION['role'] ?? '') === 'client') return ['client'];

        return ROLES_INTERNES;
    }
}
// -------------------------------------------------------------------------------------------------

if (!function_exists('refuserAcces')) {
    function refuserAcces(): void {
        $connecte = isset($_SESSION['user_id']) || isset($_SESSION['technicien_id']) || isset($_SESSION['partenaire_id']);
        if (!$connecte) { header('Location: /connexion'); exit; }

        // Espace (dossier de views/) de la page demandée, d'après le fichier exécuté
        $espaceDemande = preg_match('#/views/([^/]+)/#', str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), $m) ? $m[1] : null;

        // Mauvais espace : on fait comme si la page n'existait pas
        if ($espaceDemande !== null && !in_array($espaceDemande, espacesAutorises(), true)) {
            header('Location: /404');
            exit;
        }

        if ($espaceDemande === 'qualite' && !in_array(($_SESSION['role'] ?? ''), ['qualite', 'admin'], true)) {
            $_SESSION['flash_acces'] = "Vous n'avez pas accès à cette section.";
            header('Location: ' . accueilPourRole());
            exit;
        }

        // Garde-fou anti-boucle : si la page refusée EST l'accueil de la personne (ex. un rôle sans accès au tableau de bord),
        // la renvoyer vers cet accueil provoquerait une redirection sans fin -> on affiche la 404 à la place.
        $pageCourante = preg_match('#/views/([^/]+)/([^/]+?)(?:\.php)?$#', str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), $p) ? strtolower($p[1] . '/' . $p[2]) : '';
        if ($pageCourante !== '' && $pageCourante === strtolower(trim(accueilPourRole(), '/'))) {
            header('Location: /404');
            exit;
        }

        // Bon espace mais module non autorisé : retour à l'accueil avec un message discret
        $_SESSION['flash_acces'] = "Vous n'avez pas accès à cette section.";
        header('Location: ' . accueilPourRole());
        exit;
    }
}

// Affiche le message ci-dessus une seule fois (à appeler dans la barre de navigation ou la sidebar)
if (!function_exists('afficherFlashAcces')) {
    function afficherFlashAcces(): void {
        if (empty($_SESSION['flash_acces'])) return;
        $message = (string) $_SESSION['flash_acces'];
        unset($_SESSION['flash_acces']);
        ?>
        <div class="flash-acces" id="flash-acces" role="alert"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
        <style>
            .flash-acces { position: fixed; top: 16px; left: 50%; z-index: 3000; max-width: calc(100vw - 32px); padding: 12px 20px;
                transform: translateX(-50%); font: 500 14px/1.4 'Inter', system-ui, sans-serif; color: #7A4B0A; background: #FEF3C7;
                border: 1px solid #F59E0B; border-radius: 10px; box-shadow: 0 10px 28px rgba(0, 0, 0, .18); animation: flash-entree .35s ease both; }
            .flash-acces.flash-sortie { opacity: 0; transform: translate(-50%, -12px); transition: opacity .3s ease, transform .3s ease; }
            @keyframes flash-entree { from { opacity: 0; transform: translate(-50%, -12px); } }
        </style>
        <script>
            setTimeout(function () {
                var e = document.getElementById('flash-acces');
                if (!e) return;
                e.classList.add('flash-sortie');
                setTimeout(function () { e.remove(); }, 350);
            }, 5000);
        </script>
        <?php
    }
}