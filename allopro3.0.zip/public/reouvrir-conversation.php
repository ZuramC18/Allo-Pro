<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../models/User.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    http_response_code(405);
    exit;
}

$csrf = (string) ($_POST['csrf'] ?? '');
if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $csrf)) {
    http_response_code(403);
    exit('Jeton de sécurité invalide. Rechargez la page.');
}

try {
    if (!(new User())->reouvrirConversation((int) $_SESSION['user_id'])) {
        header('Location: /allopro/views/client/messagerie.php?erreur=reouverture');
        exit;
    }
} catch (Throwable $exception) {
    error_log('[réouverture conversation] ' . $exception->getMessage());
    header('Location: /allopro/views/client/messagerie.php?erreur=reouverture');
    exit;
}

header('Location: /allopro/views/client/messagerie.php');
exit;