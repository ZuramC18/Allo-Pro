(function () {
    'use strict';

    const form = document.getElementById('clients-recherche-form');
    const champ = document.getElementById('clients-recherche-q');
    const corps = document.getElementById('clients-resultats');
    const compteur = document.getElementById('clients-resultats-compte');
    const panneau = document.querySelector('.clients-panneau');
    const boutonEffacer = document.getElementById('clients-recherche-reset');
    if (!form || !champ || !corps || !compteur || !panneau || !boutonEffacer) return;

    const api = new URL('../../public/api-recherche-clients-qualite.php', window.location.href);
    let minuteur = null;
    let requeteActive = null;
    let sequence = 0;

    function ajouterCellule(ligne, contenu, classe, libelle) {
        const cellule = document.createElement('td');
        if (classe) cellule.className = classe;
        if (libelle) cellule.dataset.label = libelle;
        cellule.textContent = contenu;
        ligne.appendChild(cellule);
        return cellule;
    }

    function afficherMessage(texte) {
        corps.replaceChildren();
        const ligne = document.createElement('tr');
        ligne.className = 'clients-table__empty';
        const cellule = document.createElement('td');
        cellule.colSpan = 7;
        cellule.textContent = texte;
        ligne.appendChild(cellule);
        corps.appendChild(ligne);
    }

    function afficherClient(client) {
        const ligne = document.createElement('tr');
        const urlFiche = `detail-client.php?id=${encodeURIComponent(client.id)}`;
        const nomComplet = client.nom_complet || 'Client';
        ligne.className = 'clients-table__row';
        ligne.tabIndex = 0;
        ligne.setAttribute('aria-label', `Ouvrir la fiche de ${nomComplet}`);
        ligne.dataset.href = urlFiche;

        const identite = document.createElement('td');
        identite.className = 'clients-table__identity';
        const personne = document.createElement('div');
        personne.className = 'clients-table__person';
        const avatar = document.createElement('div');
        avatar.className = 'clients-table__avatar';
        if (client.photo_profil) {
            const image = document.createElement('img');
            image.src = `../../public/${client.photo_profil}`;
            image.alt = '';
            image.loading = 'lazy';
            avatar.appendChild(image);
        } else if (client.avatar_initiales) {
            avatar.textContent = nomComplet.split(/\s+/).map((partie) => Array.from(partie)[0] || '').slice(0, 2).join('').toLocaleUpperCase('fr-FR');
        } else {
            const icone = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            icone.setAttribute('viewBox', '0 0 24 24');
            icone.setAttribute('aria-hidden', 'true');
            const tete = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            tete.setAttribute('cx', '12');
            tete.setAttribute('cy', '8');
            tete.setAttribute('r', '3.5');
            const corpsPersonne = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            corpsPersonne.setAttribute('d', 'M5 20c.6-3.6 3.1-5.5 7-5.5s6.4 1.9 7 5.5');
            icone.append(tete, corpsPersonne);
            avatar.appendChild(icone);
        }
        const nom = document.createElement('span');
        const nomFamille = document.createElement('strong');
        nomFamille.textContent = client.nom || '';
        const prenom = document.createElement('strong');
        prenom.textContent = ` ${client.prenom || ''}`;
        nom.append(nomFamille, prenom);
        personne.append(avatar, nom);
        identite.appendChild(personne);
        ligne.appendChild(identite);

        const contact = document.createElement('td');
        contact.className = 'clients-table__contact';
        const telephone = document.createElement('span');
        telephone.textContent = client.telephone || '—';
        const email = document.createElement('span');
        email.textContent = client.email || '';
        contact.append(telephone, email);
        ligne.appendChild(contact);

        ajouterCellule(ligne, String(client.nb_demandes), 'clients-table__metric', 'Dossiers');
        const actives = document.createElement('td');
        actives.className = 'clients-table__metric';
        actives.dataset.label = 'En cours';
        if (client.nb_actives > 0) {
            const badgeActives = document.createElement('span');
            badgeActives.className = 'admin-badge admin-badge--amber';
            badgeActives.textContent = String(client.nb_actives);
            actives.appendChild(badgeActives);
        } else {
            actives.textContent = '—';
        }
        ligne.appendChild(actives);

        const date = client.date_creation ? new Date(`${client.date_creation.replace(' ', 'T')}`).toLocaleDateString('fr-FR') : '—';
        ajouterCellule(ligne, date, 'clients-table__metric', 'Inscrit le');

        const statut = document.createElement('td');
        statut.className = 'clients-table__status';
        statut.dataset.label = 'Statut';
        const badgeStatut = document.createElement('span');
        badgeStatut.className = `admin-badge admin-badge--${client.statut === 'actif' ? 'vert' : 'rouge'}`;
        badgeStatut.textContent = client.statut === 'actif' ? 'Actif' : 'Suspendu';
        statut.appendChild(badgeStatut);
        ligne.appendChild(statut);

        const action = document.createElement('td');
        action.className = 'clients-table__action';
        const lien = document.createElement('a');
        lien.href = urlFiche;
        lien.textContent = 'Voir la fiche →';
        action.appendChild(lien);
        ligne.appendChild(action);

        const ouvrirFiche = () => { window.location.href = urlFiche; };
        ligne.addEventListener('click', (evenement) => {
            if (evenement.target.closest('a, button, form, input, select, textarea, [contenteditable="true"]')) return;
            ouvrirFiche();
        });
        ligne.addEventListener('keydown', (evenement) => {
            if (evenement.target !== ligne || (evenement.key !== 'Enter' && evenement.key !== ' ')) return;
            evenement.preventDefault();
            ouvrirFiche();
        });
        corps.appendChild(ligne);
    }

    async function rechercher() {
        const terme = champ.value.trim();
        const idRequete = ++sequence;
        if (requeteActive) requeteActive.abort();
        boutonEffacer.hidden = terme === '';

        if (terme.length < 2) {
            panneau.setAttribute('aria-busy', 'false');
            afficherMessage(terme ? 'Saisissez au moins 2 caractères.' : 'Les résultats apparaîtront ici après votre recherche.');
            compteur.textContent = terme ? 'Recherche à partir de 2 caractères.' : 'Saisissez au moins 2 caractères pour lancer la recherche.';
            return;
        }

        requeteActive = new AbortController();
        const signal = requeteActive.signal;
        api.searchParams.set('q', terme);
        panneau.setAttribute('aria-busy', 'true');
        compteur.textContent = 'Recherche en cours…';
        afficherMessage('Recherche en cours…');
        try {
            const reponse = await fetch(api, { headers: { Accept: 'application/json' }, signal });
            const donnees = await reponse.json();
            if (!reponse.ok) throw new Error(donnees.erreur || 'La recherche a échoué.');
            if (idRequete !== sequence) return;
            corps.replaceChildren();
            donnees.clients.forEach(afficherClient);
            const nombre = donnees.clients.length;
            const limiteAtteinte = nombre >= (donnees.limite || 50);
            compteur.textContent = nombre === 0
                ? 'Aucun client trouvé.'
                : `${nombre} client${nombre === 1 ? '' : 's'} trouvé${nombre === 1 ? '' : 's'}${limiteAtteinte ? ' — affinez la recherche pour réduire les résultats.' : ''}`;
            if (nombre === 0) afficherMessage('Aucun client trouvé pour cette recherche.');
        } catch (erreur) {
            if (erreur.name === 'AbortError' || idRequete !== sequence) return;
            console.error('Recherche clients impossible.', erreur);
            afficherMessage(erreur.message || 'La recherche a échoué. Réessayez.');
            compteur.textContent = 'Impossible de charger les résultats.';
        } finally {
            if (idRequete === sequence) panneau.setAttribute('aria-busy', 'false');
        }
    }

    champ.addEventListener('input', () => {
        clearTimeout(minuteur);
        minuteur = setTimeout(rechercher, 250);
    });
    form.addEventListener('submit', (evenement) => {
        evenement.preventDefault();
        clearTimeout(minuteur);
        rechercher();
    });
    boutonEffacer.addEventListener('click', () => {
        champ.value = '';
        champ.focus();
        clearTimeout(minuteur);
        rechercher();
    });
})();
