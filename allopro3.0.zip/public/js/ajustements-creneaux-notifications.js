(() => {
    const script = document.currentScript;
    const badges = document.querySelectorAll('[data-ajustements-creneaux-badge]');
    if (!script || !badges.length) return;

    const endpoint = new URL('../api-ajustements-creneaux.php', script.src);
    let requeteEnCours = false;

    async function actualiserCompteur() {
        if (requeteEnCours || document.visibilityState !== 'visible') return;
        requeteEnCours = true;
        try {
            const response = await fetch(endpoint, {
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { Accept: 'application/json' }
            });
            if (!response.ok) throw new Error(`Réponse HTTP ${response.status}`);
            const resultat = await response.json();
            if (!Number.isInteger(resultat.count) || resultat.count < 0) {
                throw new Error('Réponse invalide pour le compteur des changements de créneau.');
            }
            badges.forEach((badge) => {
                badge.textContent = resultat.count > 99 ? '99+' : String(resultat.count);
                badge.dataset.count = String(resultat.count);
                badge.hidden = resultat.count === 0;
                badge.setAttribute('aria-label', `${resultat.count} changement${resultat.count === 1 ? '' : 's'} de créneau à traiter`);
            });
        } catch (error) {
            console.error('Impossible d’actualiser les alertes de changement de créneau.', error);
        } finally {
            requeteEnCours = false;
        }
    }

    actualiserCompteur();
    window.setInterval(actualiserCompteur, 15000);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') actualiserCompteur();
    });
    window.addEventListener('focus', actualiserCompteur);
})();
