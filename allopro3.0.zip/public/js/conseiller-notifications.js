(function () {
    'use strict';

    const script = document.currentScript;
    if (!script) return;
    const demandesBadge = document.querySelector('[data-conseiller-demandes-badge]');
    const messagesBadge = document.querySelector('[data-conseiller-messages-badge]');
    if (!demandesBadge && !messagesBadge) return;

    const api = new URL('../api-notifications-conseiller.php', script.src).href;
    let requeteEnCours = false;

    function afficher(badge, nombre, libelleSingulier, libellePluriel) {
        if (!badge) return;
        badge.textContent = nombre > 99 ? '99+' : String(nombre);
        badge.hidden = nombre === 0;
        badge.setAttribute('aria-label', nombre + ' ' + (nombre === 1 ? libelleSingulier : libellePluriel));
        badge.setAttribute('role', 'status');
    }

    async function actualiser() {
        if (requeteEnCours || document.hidden) return;
        requeteEnCours = true;
        try {
            const reponse = await fetch(api, { credentials: 'same-origin', cache: 'no-store' });
            if (!reponse.ok) return;
            const compteurs = await reponse.json();
            const demandes = Number(compteurs.demandes_nouvelles);
            const messages = Number(compteurs.messages_non_lus);
            if (Number.isInteger(demandes) && demandes >= 0) {
                afficher(demandesBadge, demandes, 'demande nouvelle', 'demandes nouvelles');
            }
            if (Number.isInteger(messages) && messages >= 0) {
                afficher(messagesBadge, messages, 'message client non lu', 'messages clients non lus');
            }
        } catch (erreur) {
            // Les badges gardent leur dernier état si le réseau est momentanément indisponible.
        } finally {
            requeteEnCours = false;
        }
    }

    let minuteur;
    function planifier() {
        clearTimeout(minuteur);
        minuteur = setTimeout(async function () {
            await actualiser();
            planifier();
        }, document.hidden ? 20000 : 7000);
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) actualiser();
        planifier();
    });
    window.addEventListener('focus', actualiser);
    actualiser();
    planifier();
})();
