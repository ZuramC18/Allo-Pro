(function () {
    function formaterTemps(secondes) {
        if (!Number.isFinite(secondes) || secondes < 0) return '--:--';
        const total = Math.ceil(secondes);
        const minutes = Math.floor(total / 60);
        const reste = total % 60;
        return `${minutes}:${String(reste).padStart(2, '0')}`;
    }

    function preparerLecteur(audio) {
        if (audio.dataset.lecteurPersonnalise === '1' || !audio.parentNode) return;
        audio.dataset.lecteurPersonnalise = '1';
        audio.removeAttribute('controls');
        audio.tabIndex = -1;
        audio.setAttribute('aria-hidden', 'true');

        const lecteur = document.createElement('div');
        lecteur.className = 'note-vocale';
        lecteur.setAttribute('role', 'group');
        lecteur.setAttribute('aria-label', 'Lecteur de note vocale');

        const bouton = document.createElement('button');
        bouton.type = 'button';
        bouton.className = 'note-vocale__lecture';
        bouton.setAttribute('aria-label', 'Lire la note vocale');
        bouton.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 2.8c0-.6.7-.9 1.2-.6l8 5.2a.7.7 0 0 1 0 1.2l-8 5.2a.7.7 0 0 1-1.2-.6V2.8Z"/></svg>';

        const zoneOnde = document.createElement('div');
        zoneOnde.className = 'note-vocale__onde';
        zoneOnde.setAttribute('aria-hidden', 'true');
        let graine = 0;
        for (const caractere of audio.currentSrc || audio.src || '') {
            graine = (graine * 31 + caractere.charCodeAt(0)) >>> 0;
        }
        for (let i = 0; i < 40; i++) {
            graine = (graine * 1664525 + 1013904223) >>> 0;
            const hauteur = 18 + (graine % 83);
            const barre = document.createElement('span');
            barre.className = 'note-vocale__barre';
            barre.style.setProperty('--hauteur', `${hauteur}%`);
            zoneOnde.appendChild(barre);
        }
        const barresOnde = zoneOnde.querySelectorAll('.note-vocale__barre');

        const progression = document.createElement('input');
        progression.type = 'range';
        progression.className = 'note-vocale__progression';
        progression.min = '0';
        progression.max = '100';
        progression.value = '0';
        progression.setAttribute('aria-label', 'Position de lecture');
        zoneOnde.appendChild(progression);

        const temps = document.createElement('span');
        temps.className = 'note-vocale__temps';
        temps.setAttribute('aria-label', 'Temps restant');
        temps.textContent = '--:--';

        const parent = audio.parentNode;
        parent.insertBefore(lecteur, audio);
        lecteur.append(bouton, zoneOnde, temps, audio);

        function rafraichir() {
            const dureeValide = Number.isFinite(audio.duration) && audio.duration > 0;
            const duree = dureeValide ? audio.duration : 0;
            const courant = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
            const restant = dureeValide ? Math.max(0, duree - courant) : Number.NaN;
            const pourcentage = duree > 0 ? Math.min(100, Math.max(0, courant / duree * 100)) : 0;
            progression.value = String(pourcentage);
            zoneOnde.style.setProperty('--progression', `${pourcentage}%`);
            barresOnde.forEach((barre, index) => {
                barre.classList.toggle('note-vocale__barre--lue', index / barresOnde.length * 100 < pourcentage);
            });
            temps.textContent = formaterTemps(restant);
            temps.setAttribute('aria-label', dureeValide ? `Temps restant ${formaterTemps(restant)}` : 'Temps restant indisponible');
        }

        function actualiserBouton() {
            const enLecture = !audio.paused && !audio.ended;
            bouton.setAttribute('aria-label', enLecture ? 'Mettre en pause' : 'Lire la note vocale');
            bouton.title = enLecture ? 'Mettre en pause' : 'Lire';
            bouton.innerHTML = enLecture
                ? '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 3h3v10H4zM9 3h3v10H9z"/></svg>'
                : '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 2.8c0-.6.7-.9 1.2-.6l8 5.2a.7.7 0 0 1 0 1.2l-8 5.2a.7.7 0 0 1-1.2-.6V2.8Z"/></svg>';
        }

        function afficherErreurAudio() {
            lecteur.classList.add('note-vocale--erreur');
            bouton.disabled = true;
            bouton.setAttribute('aria-label', 'Lecture de la note vocale impossible');

            if (audio.error?.code !== 4) return;
            let repli = lecteur.nextElementSibling?.matches('.bulle__audio-repli')
                ? lecteur.nextElementSibling
                : lecteur.querySelector('.bulle__audio-repli');
            if (!repli) {
                repli = document.createElement('a');
                repli.className = 'bulle__audio-repli';
                repli.href = audio.currentSrc || audio.src;
                repli.download = 'note-vocale';
                repli.textContent = 'Télécharger la note vocale';
            }
            lecteur.appendChild(repli);
        }

        bouton.addEventListener('click', function () {
            if (audio.paused) {
                audio.play().catch(() => {
                    bouton.setAttribute('aria-label', 'Lecture impossible');
                    bouton.title = 'Lecture impossible';
                });
            } else {
                audio.pause();
            }
        });

        progression.addEventListener('input', function () {
            if (!Number.isFinite(audio.duration) || audio.duration <= 0) return;
            audio.currentTime = Number(progression.value) / 100 * audio.duration;
            rafraichir();
        });

        ['loadedmetadata', 'durationchange', 'timeupdate', 'seeked'].forEach(eventName => {
            audio.addEventListener(eventName, rafraichir);
        });
        ['play', 'pause', 'ended'].forEach(eventName => {
            audio.addEventListener(eventName, actualiserBouton);
        });
        audio.addEventListener('error', function () {
            afficherErreurAudio();
        });

        rafraichir();
        actualiserBouton();
        if (audio.error) afficherErreurAudio();
    }

    function preparerDans(noeud) {
        if (noeud.matches?.('.bulle__audio')) preparerLecteur(noeud);
        noeud.querySelectorAll?.('.bulle__audio').forEach(preparerLecteur);
    }

    document.querySelectorAll('.bulle__audio').forEach(preparerLecteur);
    new MutationObserver(mutations => {
        mutations.forEach(mutation => mutation.addedNodes.forEach(noeud => {
            if (noeud.nodeType === Node.ELEMENT_NODE) preparerDans(noeud);
        }));
    }).observe(document.body, { childList: true, subtree: true });

    document.addEventListener('play', event => {
        if (!event.target.matches?.('.bulle__audio')) return;
        document.querySelectorAll('.bulle__audio').forEach(audio => {
            if (audio !== event.target) audio.pause();
        });
    }, true);
})();
