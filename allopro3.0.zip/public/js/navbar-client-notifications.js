(function () {
    const menu = document.getElementById('notifications-menu');
    if (!menu) return;

    const bouton = document.getElementById('notifications-bouton');
    const dropdown = document.getElementById('notifications-dropdown');
    const badge = document.getElementById('badge-notifications');
    const liste = document.getElementById('notifications-liste');
    const profilDropdown = document.getElementById('profil-dropdown');
    const profilBouton = document.getElementById('profil-bouton');
    const apiUrl = '../../public/api-notifications-client.php';
    const urlLecture = '../../public/marquer-notification-lue.php';
    const appelsSignales = new Set();

    function ouvrir(ouvert) {
        if (ouvert && profilDropdown && profilBouton) {
            profilDropdown.classList.remove('navbar-client__dropdown--ouvert');
            profilBouton.setAttribute('aria-expanded', 'false');
        }
        dropdown.classList.toggle('navbar-client__notifications-dropdown--ouvert', ouvert);
        bouton.setAttribute('aria-expanded', ouvert ? 'true' : 'false');
    }

    function urlNotification(notification) {
        const destination = notification.lien || '../client/notifications.php';
        return urlLecture + '?' + new URLSearchParams({
            id: notification.id,
            redirection: destination
        }).toString();
    }

    function dateLisible(date) {
        const valeur = new Date(String(date).replace(' ', 'T'));
        if (Number.isNaN(valeur.getTime())) return '';
        return new Intl.DateTimeFormat('fr-FR', {
            dateStyle: 'short',
            timeStyle: 'short'
        }).format(valeur);
    }

    function afficher(data) {
        const nonLues = Number(data.non_lues) || 0;
        badge.textContent = nonLues > 99 ? '99+' : String(nonLues);
        badge.hidden = nonLues < 1;
        bouton.setAttribute('aria-label', nonLues > 0
            ? 'Notifications, ' + nonLues + ' non lue' + (nonLues > 1 ? 's' : '')
            : 'Notifications');
        liste.replaceChildren();

        if (!Array.isArray(data.notifications) || data.notifications.length === 0) {
            const vide = document.createElement('p');
            vide.className = 'navbar-client__notifications-vide';
            vide.textContent = 'Aucune notification pour le moment.';
            liste.append(vide);
            return;
        }

        let nouvelAppelEntrant = false;
        data.notifications.forEach(function (notification) {
            const lien = document.createElement('a');
            lien.className = 'navbar-client__notification' + (Number(notification.lu) === 0 ? ' navbar-client__notification--non-lue' : '');
            lien.href = urlNotification(notification);
            lien.textContent = notification.message || 'Nouvelle notification';

            if (Number(notification.appel_entrant) === 1 && Number(notification.lu) === 0) {
                lien.classList.add('navbar-client__notification--appel');
                if (!appelsSignales.has(String(notification.id))) {
                    appelsSignales.add(String(notification.id));
                    nouvelAppelEntrant = true;
                }
            }

            const date = dateLisible(notification.date_creation);
            if (date) {
                const temps = document.createElement('span');
                temps.className = 'navbar-client__notification-temps';
                temps.textContent = date;
                lien.append(temps);
            }
            liste.append(lien);
        });
        if (nouvelAppelEntrant) ouvrir(true);
    }

    async function actualiser() {
        try {
            const reponse = await fetch(apiUrl, {
                credentials: 'same-origin',
                headers: { 'Accept': 'application/json' },
                cache: 'no-store'
            });
            if (!reponse.ok) throw new Error('Réponse HTTP ' + reponse.status);
            afficher(await reponse.json());
        } catch (erreur) {
            console.error('Actualisation des notifications impossible :', erreur);
            if (!liste.children.length) {
                const erreurAffichage = document.createElement('p');
                erreurAffichage.className = 'navbar-client__notifications-vide';
                erreurAffichage.textContent = 'Les notifications sont momentanément indisponibles.';
                liste.replaceChildren(erreurAffichage);
            }
        }
    }

    bouton.addEventListener('click', function (evenement) {
        evenement.stopPropagation();
        ouvrir(!dropdown.classList.contains('navbar-client__notifications-dropdown--ouvert'));
    });
    document.addEventListener('click', function (evenement) {
        if (!menu.contains(evenement.target)) ouvrir(false);
    });
    document.addEventListener('keydown', function (evenement) {
        if (evenement.key === 'Escape') ouvrir(false);
    });

    actualiser();
    window.setInterval(actualiser, 5000);
})();
