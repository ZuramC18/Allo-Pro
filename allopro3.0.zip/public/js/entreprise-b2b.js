(() => {
    const sidebar = document.querySelector('.b2b-sidebar');
    const sidebarToggle = sidebar?.querySelector('.b2b-sidebar__toggle');
    const sidebarNavigation = sidebar?.querySelector('#navigation-entreprise');
    if (sidebar && sidebarToggle && sidebarNavigation) {
        const mobileSidebar = window.matchMedia('(max-width: 800px)');
        const fermerMenu = () => {
            sidebar.classList.remove('is-open');
            sidebarToggle.setAttribute('aria-expanded', 'false');
            sidebarToggle.setAttribute('aria-label', 'Ouvrir le menu entreprise');
        };
        sidebarToggle.addEventListener('click', () => {
            const ouvert = sidebar.classList.toggle('is-open');
            sidebarToggle.setAttribute('aria-expanded', String(ouvert));
            sidebarToggle.setAttribute('aria-label', ouvert ? 'Fermer le menu entreprise' : 'Ouvrir le menu entreprise');
        });
        sidebarNavigation.addEventListener('click', (event) => {
            if (mobileSidebar.matches && event.target.closest('a')) fermerMenu();
        });
        sidebar.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && mobileSidebar.matches && sidebar.classList.contains('is-open')) {
                fermerMenu();
                sidebarToggle.focus();
            }
        });
        mobileSidebar.addEventListener('change', (event) => {
            if (!event.matches) fermerMenu();
        });
    }

    document.querySelectorAll('.b2b-row-link[data-href]').forEach((row) => {
        row.addEventListener('click', (event) => {
            if (event.target.closest('a, button, input, select, textarea')) return;
            window.location.assign(row.dataset.href);
        });
        row.addEventListener('keydown', (event) => {
            if (event.target !== row || !['Enter', ' '].includes(event.key)) return;
            event.preventDefault();
            window.location.assign(row.dataset.href);
        });
    });

    const normaliserRecherche = (valeur) => valeur
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLocaleLowerCase('fr')
        .trim();

    const removeMemberDialog = document.querySelector('[data-remove-member-dialog]');
    const removeMemberName = removeMemberDialog?.querySelector('[data-remove-member-name]');
    const confirmRemoveMember = removeMemberDialog?.querySelector('[data-confirm-remove-member]');
    const cancelRemoveMember = removeMemberDialog?.querySelector('[data-cancel-remove-member]');
    let pendingRemoveMemberForm = null;
    let confirmedRemoveMember = false;
    if (removeMemberDialog && removeMemberName && confirmRemoveMember && cancelRemoveMember) {
        document.querySelectorAll('[data-remove-member-form]').forEach((formulaire) => {
            formulaire.addEventListener('submit', (event) => {
                if (confirmedRemoveMember) {
                    confirmedRemoveMember = false;
                    return;
                }
                event.preventDefault();
                pendingRemoveMemberForm = formulaire;
                removeMemberName.textContent = formulaire.dataset.memberName || 'ce membre';
                removeMemberDialog.showModal();
            });
        });

        cancelRemoveMember.addEventListener('click', () => removeMemberDialog.close());
        removeMemberDialog.addEventListener('close', () => {
            pendingRemoveMemberForm = null;
        });
        confirmRemoveMember.addEventListener('click', () => {
            if (!pendingRemoveMemberForm) return;
            confirmedRemoveMember = true;
            removeMemberDialog.close();
            pendingRemoveMemberForm.requestSubmit();
        });
    }

    const permissionMembers = Array.from(document.querySelectorAll('[data-permission-member]'));
    const permissionForms = Array.from(document.querySelectorAll('[data-permission-form]'));
    if (permissionMembers.length && permissionForms.length) {
        const choisirMembre = (membreId) => {
            permissionMembers.forEach((bouton) => {
                const actif = bouton.dataset.permissionMember === membreId;
                bouton.classList.toggle('is-active', actif);
                bouton.setAttribute('aria-pressed', String(actif));
            });
            permissionForms.forEach((permissionForm) => {
                permissionForm.hidden = permissionForm.dataset.permissionForm !== membreId;
            });
        };

        permissionMembers.forEach((bouton) => {
            bouton.addEventListener('click', () => choisirMembre(bouton.dataset.permissionMember));
        });

        permissionForms.forEach((permissionForm) => {
            permissionForm.addEventListener('submit', async (event) => {
                event.preventDefault();
                const boutonEnregistrer = permissionForm.querySelector('button[type="submit"]');
                const statut = permissionForm.querySelector('[data-permission-status]');
                if (!boutonEnregistrer || !statut) return;

                const libelleInitial = boutonEnregistrer.textContent;
                boutonEnregistrer.disabled = true;
                boutonEnregistrer.textContent = 'Enregistrement…';
                statut.textContent = '';
                statut.classList.remove('is-error', 'is-success');

                try {
                    const response = await fetch(permissionForm.dataset.permissionEndpoint || permissionForm.action || window.location.href, {
                        method: 'POST',
                        body: new FormData(permissionForm),
                        headers: {
                            Accept: 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        credentials: 'same-origin',
                    });
                    const resultat = await response.json();
                    if (!response.ok || resultat.success !== true) {
                        throw new Error(resultat.message || 'Les permissions n’ont pas pu être enregistrées.');
                    }
                    statut.textContent = resultat.message;
                    statut.classList.add('is-success');
                } catch (erreur) {
                    statut.textContent = erreur.message || 'Une erreur est survenue. Réessayez.';
                    statut.classList.add('is-error');
                } finally {
                    boutonEnregistrer.disabled = false;
                    boutonEnregistrer.textContent = libelleInitial;
                }
            });
        });
    }

    const rechercheDossier = document.getElementById('recherche-dossier-devis');
    const selectDossier = document.getElementById('devis-demande-id');
    if (rechercheDossier && selectDossier) {
        const optionsDossier = Array.from(selectDossier.options).slice(1);
        rechercheDossier.addEventListener('input', () => {
            const recherche = normaliserRecherche(rechercheDossier.value);
            optionsDossier.forEach((option) => {
                option.hidden = recherche !== '' && !normaliserRecherche(option.textContent).includes(recherche);
            });
            if (selectDossier.selectedOptions.length && selectDossier.selectedOptions[0].hidden) {
                selectDossier.value = '';
            }
        });
    }

    const rechercheDevis = document.getElementById('recherche-devis-envoye');
    const lignesDevis = Array.from(document.querySelectorAll('[data-devis-row]'));
    const filtreStatutDevis = document.getElementById('filtre-statut-devis');
    const resultatVideDevis = document.getElementById('devis-recherche-vide');
    if (lignesDevis.length) {
        const filtrerDevis = () => {
            const recherche = normaliserRecherche(rechercheDevis?.value || '');
            const statut = filtreStatutDevis?.value || '';
            let visibles = 0;
            lignesDevis.forEach((ligne) => {
                const correspond = normaliserRecherche(ligne.textContent).includes(recherche)
                    && (!statut || ligne.dataset.devisStatus === statut);
                ligne.hidden = !correspond;
                if (correspond) visibles += 1;
            });
            if (resultatVideDevis) {
                resultatVideDevis.hidden = visibles !== 0;
            }
        };
        rechercheDevis?.addEventListener('input', filtrerDevis);
        filtreStatutDevis?.addEventListener('change', filtrerDevis);
    }

    document.querySelectorAll('[data-confirm-devis]').forEach((formulaire) => {
        formulaire.addEventListener('submit', (event) => {
            const reponse = event.submitter?.value;
            if (!['accepte', 'refuse'].includes(reponse)) return;
            const action = reponse === 'accepte' ? 'accepter' : 'refuser';
            if (!window.confirm(`Voulez-vous vraiment ${action} ce devis ?`)) {
                event.preventDefault();
            }
        });
    });

    const rechercheTicketsSav = document.getElementById('recherche-tickets-sav');
    const ticketsSav = Array.from(document.querySelectorAll('[data-ticket-sav]'));
    const filtreStatutSav = document.getElementById('filtre-statut-sav');
    const ticketsSavSansResultat = document.getElementById('tickets-sav-sans-resultat');
    if (ticketsSav.length) {
        const filtrerTicketsSav = () => {
            const recherche = normaliserRecherche(rechercheTicketsSav?.value || '');
            const statut = filtreStatutSav?.value || '';
            let visibles = 0;
            ticketsSav.forEach((ticket) => {
                const correspond = normaliserRecherche(ticket.textContent).includes(recherche)
                    && (!statut || ticket.dataset.ticketStatus === statut);
                ticket.hidden = !correspond;
                if (correspond) visibles += 1;
            });
            if (ticketsSavSansResultat) {
                ticketsSavSansResultat.hidden = visibles !== 0;
            }
        };
        rechercheTicketsSav?.addEventListener('input', filtrerTicketsSav);
        filtreStatutSav?.addEventListener('change', filtrerTicketsSav);
    }

    const compteurMotifSav = document.getElementById('sav-motif-compteur');
    const champMotifSav = document.getElementById('sav-motif');
    if (compteurMotifSav && champMotifSav) {
        const actualiserCompteurMotifSav = () => {
            compteurMotifSav.textContent = String(champMotifSav.value.length);
        };
        champMotifSav.addEventListener('input', actualiserCompteurMotifSav);
        actualiserCompteurMotifSav();
    }

    [
        ['recherche-interventions', '.b2b-operation-card', 'interventions-sans-resultat'],
        ['recherche-factures', '[data-module-facture]', 'factures-sans-resultat'],
        ['recherche-documents', '[data-module-document]', 'documents-sans-resultat'],
        ['recherche-rapport', '.b2b-report-row', 'rapport-sans-resultat'],
    ].forEach(([inputId, itemSelector, emptyId]) => {
        const inputRecherche = document.getElementById(inputId);
        const elements = Array.from(document.querySelectorAll(itemSelector));
        const etatVide = document.getElementById(emptyId);
        if (!inputRecherche || !elements.length) return;
        inputRecherche.addEventListener('input', () => {
            const recherche = normaliserRecherche(inputRecherche.value);
            let visibles = 0;
            elements.forEach((element) => {
                const correspond = normaliserRecherche(element.textContent).includes(recherche);
                element.hidden = !correspond;
                if (correspond) visibles += 1;
            });
            if (etatVide) etatVide.hidden = visibles !== 0;
        });
    });

    const rechercheDemandes = document.getElementById('recherche-demandes-entreprise');
    const lignesDemandes = Array.from(document.querySelectorAll('[data-demande-row]'));
    const resultatVideDemandes = document.getElementById('demandes-recherche-vide');
    const filtreStatutDemandes = document.getElementById('filtre-statut-demandes');
    const filtreSiteDemandes = document.getElementById('filtre-site-demandes');
    const filtreUrgenceDemandes = document.getElementById('filtre-urgence-demandes');
    const triDemandes = document.getElementById('tri-demandes');
    const listeDemandes = document.getElementById('liste-demandes');
    if (lignesDemandes.length) {
        const filtrerDemandes = () => {
            const recherche = normaliserRecherche(rechercheDemandes?.value || '');
            const statut = filtreStatutDemandes?.value || '';
            const site = normaliserRecherche(filtreSiteDemandes?.value || '');
            const urgence = filtreUrgenceDemandes?.value || '';
            let visibles = 0;
            lignesDemandes.forEach((ligne) => {
                const correspond = normaliserRecherche(ligne.textContent).includes(recherche)
                    && (!statut || ligne.dataset.demandeStatus === statut)
                    && (!site || normaliserRecherche(ligne.dataset.demandeSite || '') === site)
                    && (!urgence || ligne.dataset.demandeUrgency === urgence);
                ligne.hidden = !correspond;
                if (correspond) visibles += 1;
            });
            if (resultatVideDemandes) {
                resultatVideDemandes.hidden = visibles !== 0;
            }
        };
        rechercheDemandes?.addEventListener('input', filtrerDemandes);
        filtreStatutDemandes?.addEventListener('change', filtrerDemandes);
        filtreSiteDemandes?.addEventListener('change', filtrerDemandes);
        filtreUrgenceDemandes?.addEventListener('change', filtrerDemandes);
    }
    if (triDemandes && listeDemandes && lignesDemandes.length) {
        const collateur = new Intl.Collator('fr', { numeric: true, sensitivity: 'base' });
        const trierDemandes = () => {
            const mode = triDemandes.value;
            const demandesTriees = [...lignesDemandes].sort((a, b) => {
                if (mode === 'reference') {
                    return collateur.compare(a.dataset.demandeReference || '', b.dataset.demandeReference || '');
                }
                const dateA = Number(a.dataset.demandeDate);
                const dateB = Number(b.dataset.demandeDate);
                return mode === 'ancien' ? dateA - dateB : dateB - dateA;
            });
            demandesTriees.forEach((demande) => listeDemandes.appendChild(demande));
        };
        triDemandes.addEventListener('change', trierDemandes);
        trierDemandes();
    }

    const form = document.getElementById('form-entreprise');
    const input = document.getElementById('entreprise-nom');
    const status = document.getElementById('entreprise-nom-statut');
    const submit = document.getElementById('entreprise-creer');
    if (!form || !input || !status || !submit) return;

    let timer = 0;
    let controller = null;
    let sequence = 0;
    let nomVerifie = '';
    let disponible = false;
    const soumissionAutorisee = !submit.disabled;
    const statutInitial = status.textContent.trim();
    const doublonInitial = input.getAttribute('aria-invalid') === 'true';

    const afficher = (message, etat) => {
        status.textContent = message;
        status.dataset.state = etat;
        input.setAttribute('aria-invalid', etat === 'taken' || etat === 'error' ? 'true' : 'false');
    };

    const verifier = async () => {
        const nom = input.value.trim().replace(/\s+/gu, ' ');
        const courant = ++sequence;
        nomVerifie = '';
        disponible = false;
        if (controller) controller.abort();
        submit.disabled = true;

        if (nom.length < 2) {
            afficher(nom.length ? 'Saisissez au moins 2 caractères.' : '', 'idle');
            return;
        }
        if (nom.length > 150) {
            afficher('Le nom ne peut pas dépasser 150 caractères.', 'error');
            return;
        }

        controller = new AbortController();
        afficher('Vérification du nom…', 'checking');
        try {
            const url = new URL(form.dataset.verificationUrl, window.location.href);
            url.searchParams.set('nom', nom);
            const response = await fetch(url, {
                headers: { Accept: 'application/json' },
                cache: 'no-store',
                credentials: 'same-origin',
                signal: controller.signal,
            });
            const resultat = await response.json();
            if (courant !== sequence) return;
            if (!response.ok) throw new Error(resultat.message || 'La vérification a échoué.');
            disponible = resultat.disponible === true;
            nomVerifie = disponible ? nom.toLocaleLowerCase('fr') : '';
            afficher(resultat.message, disponible ? 'available' : 'taken');
            submit.disabled = !soumissionAutorisee || !disponible;
        } catch (erreur) {
            if (erreur.name === 'AbortError' || courant !== sequence) return;
            disponible = false;
            nomVerifie = '';
            afficher(erreur.message || 'Vérification indisponible. Réessayez.', 'error');
        }
    };

    input.addEventListener('input', () => {
        window.clearTimeout(timer);
        if (controller) controller.abort();
        sequence += 1;
        submit.disabled = true;
        disponible = false;
        nomVerifie = '';
        input.setAttribute('aria-invalid', 'false');
        const nom = input.value.trim().replace(/\s+/gu, ' ');
        if (nom.length < 2) {
            afficher(nom.length ? 'Saisissez au moins 2 caractères.' : '', 'idle');
            return;
        }
        afficher('La vérification démarre…', 'checking');
        timer = window.setTimeout(verifier, 350);
    });

    input.addEventListener('blur', () => {
        if (input.value.trim().length >= 2 && nomVerifie !== input.value.trim().replace(/\s+/gu, ' ').toLocaleLowerCase('fr')) {
            window.clearTimeout(timer);
            verifier();
        }
    });

    form.addEventListener('submit', (event) => {
        const nom = input.value.trim().replace(/\s+/gu, ' ').toLocaleLowerCase('fr');
        if (!disponible || !nomVerifie || nom !== nomVerifie) {
            event.preventDefault();
            verifier();
            input.focus();
        }
    });

    submit.disabled = !soumissionAutorisee;
    if (doublonInitial) {
        afficher(statutInitial || 'Une entreprise porte déjà ce nom.', 'taken');
    } else if (input.value.trim().length >= 2) {
        verifier();
    } else {
        afficher('', 'idle');
    }
})();
