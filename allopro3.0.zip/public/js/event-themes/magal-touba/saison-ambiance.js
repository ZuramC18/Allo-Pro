(function () {
    'use strict';
    var source = document.currentScript;
    if (!source) return;
    var url = new URL('../saisons-evenementielles.js', source.src);
    var version = new URL(source.src).searchParams.get('v');
    if (version) url.searchParams.set('v', version);
    var script = document.createElement('script');
    script.src = url.href;
    script.async = false;
    document.head.appendChild(script);
})();
