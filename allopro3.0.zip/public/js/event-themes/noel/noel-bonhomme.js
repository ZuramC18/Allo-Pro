(function () {
    'use strict';

    var bonhomme = document.querySelector('[data-noel-snowman]');
    if (!bonhomme || document.documentElement.dataset.eventTheme !== 'noel') return;

    bonhomme.hidden = false;
    if (bonhomme.dataset.ready === '1') return;
    bonhomme.dataset.ready = '1';

    var namespace = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(namespace, 'svg');
    svg.setAttribute('viewBox', '0 0 100 136');
    svg.setAttribute('focusable', 'false');

    function forme(nom, attributs) {
        var element = document.createElementNS(namespace, nom);
        Object.keys(attributs).forEach(function (cle) {
            element.setAttribute(cle, attributs[cle]);
        });
        svg.appendChild(element);
        return element;
    }

    forme('ellipse', { cx: '50', cy: '129', rx: '35', ry: '5', fill: 'rgba(0,0,0,.2)' });
    forme('path', { d: 'M22 78 7 69m71 9 15-10', fill: 'none', stroke: '#805032', 'stroke-width': '4', 'stroke-linecap': 'round' });
    forme('circle', { cx: '50', cy: '88', r: '29', fill: '#f8fbff', stroke: '#d8e5ec', 'stroke-width': '2' });
    forme('circle', { cx: '50', cy: '43', r: '21', fill: '#fff', stroke: '#d8e5ec', 'stroke-width': '2' });
    forme('path', { d: 'M49 41 70 47 49 50z', fill: '#f18b38', stroke: '#d76d24', 'stroke-width': '1' });
    forme('circle', { cx: '43', cy: '38', r: '2.3', fill: '#243448' });
    forme('circle', { cx: '55', cy: '38', r: '2.3', fill: '#243448' });
    forme('circle', { cx: '49', cy: '57', r: '2.3', fill: '#e58a91' });
    forme('circle', { cx: '51', cy: '78', r: '2.5', fill: '#34495e' });
    forme('circle', { cx: '51', cy: '90', r: '2.5', fill: '#34495e' });
    forme('circle', { cx: '51', cy: '102', r: '2.5', fill: '#34495e' });
    forme('path', { d: 'M30 60q20 8 40 0l-3 9q-18 8-34 0z', fill: '#c93f49' });
    forme('path', { d: 'M60 65 65 83 73 80 68 64z', fill: '#b9343e' });
    forme('path', { d: 'M31 25h38l-4-7H35z', fill: '#b9343e', stroke: '#8f2832', 'stroke-width': '1' });
    forme('path', { d: 'M38 4h24l5 16H33z', fill: '#c93f49', stroke: '#8f2832', 'stroke-width': '1.5' });
    forme('path', { d: 'M37 17h28', fill: 'none', stroke: '#f5d176', 'stroke-width': '3' });
    forme('path', { d: 'M25 106q25 12 50 0l7 13H18z', fill: '#fff', opacity: '.8' });

    bonhomme.appendChild(svg);
})();
