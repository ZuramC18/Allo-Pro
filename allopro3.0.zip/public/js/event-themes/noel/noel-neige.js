(function () {
    'use strict';

    var racine = document.documentElement;
    var hero = document.querySelector('.hero');
    if (!hero || racine.dataset.eventTheme !== 'noel' || racine.dataset.eventAnimations !== '1') return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    var neige = document.createElement('div');
    neige.className = 'noel-neige';
    neige.setAttribute('aria-hidden', 'true');
    Object.assign(neige.style, {
        position: 'absolute',
        inset: '0',
        zIndex: '0',
        overflow: 'hidden',
        pointerEvents: 'none'
    });

    for (var i = 0; i < 28; i++) {
        var flocon = document.createElement('span');
        var taille = 2 + Math.random() * 4;
        var duree = 8 + Math.random() * 12;
        Object.assign(flocon.style, {
            position: 'absolute',
            top: '-10px',
            left: (Math.random() * 100) + '%',
            width: taille + 'px',
            height: taille + 'px',
            borderRadius: '50%',
            background: 'rgba(255,255,255,' + (0.38 + Math.random() * 0.55) + ')',
            boxShadow: '0 0 7px rgba(255,255,255,.36)'
        });
        flocon.animate(
            [
                { transform: 'translate3d(0,-8px,0)', opacity: 0 },
                { transform: 'translate3d(14px,20vh,0)', opacity: 1, offset: .15 },
                { transform: 'translate3d(-12px,75vh,0)', opacity: .9, offset: .75 },
                { transform: 'translate3d(8px,95vh,0)', opacity: 0 }
            ],
            { duration: duree * 1000, delay: Math.random() * -duree * 1000, iterations: Infinity, easing: 'linear' }
        );
        neige.appendChild(flocon);
    }

    hero.appendChild(neige);
})();
