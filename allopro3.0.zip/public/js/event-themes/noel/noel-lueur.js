(function () {
    'use strict';

    var racine = document.documentElement;
    if (racine.dataset.eventTheme !== 'noel' || racine.dataset.eventAnimations !== '1') return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    document.querySelectorAll('.navbar-client__logo span').forEach(function (logo) {
        logo.animate(
            [
                { textShadow: '0 0 0 rgba(201,63,73,0)' },
                { textShadow: '0 0 11px rgba(201,63,73,.48)' },
                { textShadow: '0 0 0 rgba(201,63,73,0)' }
            ],
            { duration: 3500, iterations: Infinity, easing: 'ease-in-out' }
        );
    });
})();
