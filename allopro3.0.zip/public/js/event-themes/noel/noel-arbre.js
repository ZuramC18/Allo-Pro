(function () {
    'use strict';

    var arbre = document.querySelector('[data-noel-tree]');
    if (!arbre || document.documentElement.dataset.eventTheme !== 'noel') return;

    arbre.hidden = false;
    if (arbre.dataset.ready === '1') return;
    arbre.dataset.ready = '1';

    var espaceSvg = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(espaceSvg, 'svg');
    svg.setAttribute('viewBox', '0 0 180 240');
    svg.setAttribute('focusable', 'false');

    function ajouterForme(nom, attributs, parent) {
        var element = document.createElementNS(espaceSvg, nom);
        Object.keys(attributs).forEach(function (cle) {
            element.setAttribute(cle, attributs[cle]);
        });
        (parent || svg).appendChild(element);
        return element;
    }

    ajouterForme('ellipse', { cx: '90', cy: '224', rx: '72', ry: '10', fill: 'rgba(0,0,0,.18)' });
    ajouterForme('path', { d: 'M78 178h24v42H78z', class: 'event-tree__pot' });
    ajouterForme('path', { d: 'M90 12 45 83h21l-36 55h35l-40 58h130l-40-58h35l-36-55h21z', fill: '#176b47', stroke: '#9bc99e', 'stroke-width': '3', 'stroke-linejoin': 'round' });
    ajouterForme('path', { d: 'M90 28 56 82h15l-29 48h28l-32 49h104l-32-49h28l-29-48h15z', fill: '#218557', opacity: '.9' });
    ajouterForme('path', { d: 'm48 84 24 4m-36 51 35 3m-47 57 52 2m56-117-24 4m36 51-35 3m47 57-52 2', fill: 'none', stroke: '#d7ead5', 'stroke-width': '4', 'stroke-linecap': 'round', opacity: '.85' });
    ajouterForme('path', { d: 'm90 4 5 11 12 1-9 8 3 12-11-6-11 6 3-12-9-8 12-1z', class: 'event-tree__star' });

    var couleurs = ['#ffd166', '#f78c6b', '#80d8ff', '#f5a7d7', '#fff3a3'];
    var guirlandes = [
        [71, 83], [107, 84], [56, 111], [86, 111], [120, 112],
        [43, 145], [73, 145], [105, 145], [137, 145],
        [36, 177], [64, 177], [91, 177], [118, 177], [145, 177]
    ];

    guirlandes.forEach(function (position, index) {
        var ampoule = ajouterForme('circle', {
            cx: String(position[0]),
            cy: String(position[1]),
            r: index % 3 === 0 ? '4' : '3',
            fill: couleurs[index % couleurs.length],
            class: 'event-tree__bulb'
        });
        ampoule.style.color = couleurs[index % couleurs.length];
        if (document.documentElement.dataset.eventAnimations === '1'
            && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            ampoule.animate(
                [
                    { opacity: .48, transform: 'scale(.82)' },
                    { opacity: 1, transform: 'scale(1.2)', offset: .55 },
                    { opacity: .58, transform: 'scale(.9)' }
                ],
                { duration: 950 + (index % 5) * 190, delay: index * 115, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' }
            );
        }
    });

    arbre.appendChild(svg);
})();
