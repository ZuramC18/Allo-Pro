(function () {
    'use strict';

    var root = document.documentElement;
    if (root.dataset.eventTheme !== 'halloween' || root.dataset.eventAnimations !== '1') return;

    var illustrations = {
        ghost: '<svg viewBox="0 0 80 100" aria-hidden="true"><path d="M12 91V42C12 20 24 7 40 7s28 13 28 35v49l-12-9-9 10-9-10-10 10-8-10z" fill="#fff7e9" stroke="#e8d8c5" stroke-width="2"/><ellipse cx="31" cy="44" rx="4" ry="6" fill="#392844"/><ellipse cx="50" cy="44" rx="4" ry="6" fill="#392844"/><path d="M36 58q4 5 8 0" fill="none" stroke="#392844" stroke-linecap="round" stroke-width="3"/><path d="M21 26q5-9 12-11" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="3" opacity=".7"/></svg>',
        bat: '<svg viewBox="0 0 80 48" aria-hidden="true"><path d="M40 17c-7-13-16-12-22-8l-3-8-4 17L0 12l6 23 13-3 11 10 10-10 10 10 11-10 13 3 6-23-11 6-4-17-3 8c-6-4-15-5-22 8z" fill="currentColor"/><circle cx="34" cy="22" r="1.8" fill="#ffbd54"/><circle cx="46" cy="22" r="1.8" fill="#ffbd54"/></svg>',
        pumpkin: '<svg viewBox="0 0 100 88" aria-hidden="true"><path d="M50 18c-4-9 0-15 8-16 4 8 1 13-5 17" fill="#6c8e3e" stroke="#42652e" stroke-width="2"/><path d="M50 18C29 8 9 25 8 48 7 70 21 83 50 83s43-13 42-35C91 25 71 8 50 18z" fill="#ed7b20" stroke="#a94c18" stroke-width="3"/><path d="M50 19c-8 9-10 47 0 64M31 18c-12 11-14 44 0 62m38-62c12 11 14 44 0 62" fill="none" stroke="#ffad45" stroke-width="4" opacity=".75"/><path d="m27 40 17 7-15 5zm46 0-17 7 15 5zM38 61h24l-5 12H43z" fill="#ffe18a" stroke="#f9c65b" stroke-width="2" stroke-linejoin="round"/><path d="M19 30q5-7 10-9" fill="none" stroke="#ffc06a" stroke-linecap="round" stroke-width="3" opacity=".8"/></svg>',
        spider: '<svg viewBox="0 0 40 40" aria-hidden="true"><g fill="none" stroke="#21172a" stroke-linecap="round" stroke-width="2.5"><path d="m13 14-7-6m8 11-9-1m10 6-8 6m19-16 7-6m-8 11 9-1m-10 6 8 6"/></g><ellipse cx="20" cy="22" rx="8" ry="10" fill="#21172a"/><circle cx="17" cy="19" r="1.5" fill="#ff6a3d"/><circle cx="23" cy="19" r="1.5" fill="#ff6a3d"/></svg>'
    };

    function createScene(className, footerScene) {
        var scene = document.createElement('div');
        scene.className = className;
        scene.setAttribute('aria-hidden', 'true');
        scene.innerHTML =
            (footerScene ? '' : '<span class="halloween-moon"></span>') +
            '<span class="halloween-bat halloween-bat--one">' + illustrations.bat + '</span>' +
            '<span class="halloween-bat halloween-bat--two">' + illustrations.bat + '</span>' +
            (footerScene ? '' : '<span class="halloween-bat halloween-bat--three">' + illustrations.bat + '</span>') +
            '<span class="halloween-ghost halloween-ghost--one">' + illustrations.ghost + '</span>' +
            '<span class="halloween-ghost halloween-ghost--two">' + illustrations.ghost + '</span>' +
            '<span class="halloween-pumpkin">' + illustrations.pumpkin + '</span>' +
            '<span class="halloween-spider"><i class="halloween-spider__thread"></i>' + illustrations.spider + '</span>' +
            (footerScene ? '' : '<span class="halloween-mist"></span>');
        return scene;
    }

    var hero = document.querySelector('.hero');
    if (hero) {
        hero.insertBefore(createScene('halloween-scene', false), hero.firstChild);
    }

    var footer = document.querySelector('.footer');
    if (footer) {
        footer.insertBefore(createScene('halloween-footer-scene', true), footer.firstChild);
    }
})();
