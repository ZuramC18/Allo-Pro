(function () {
    'use strict';

    var root = document.documentElement;
    var theme = root.dataset.eventTheme;
    if (
        root.dataset.eventAnimations !== '1'
        || !['ramadan', 'magal-touba', 'tamkharit'].includes(theme)
    ) return;

    var lantern = '<span class="saison-lanterne saison-lanterne--1"><i class="saison-lanterne__fil"></i><svg viewBox="0 0 40 68" aria-hidden="true"><path d="M14 10h12l5 8-3 4v25l5 8H7l5-8V22l-3-4z" fill="var(--saison-decor)" stroke="var(--saison-lueur)" stroke-width="2"/><path d="M15 23h10v23H15z" fill="var(--saison-lueur)" opacity=".88"/><path d="M9 55h22M14 10V5h12v5" fill="none" stroke="var(--saison-lueur)" stroke-linecap="round" stroke-width="2"/><path d="M20 27c-5 6 5 8 0 15" fill="none" stroke="#fff6ca" stroke-linecap="round" stroke-width="2"/></svg></span>';
    var mosque = '<span class="saison-mosquee"><svg viewBox="0 0 440 142" preserveAspectRatio="xMaxYMax meet" aria-hidden="true"><path d="M0 140V104h40V83h17V57h7V35h5v22h7v26h18v21h28V87h16V72h8V57h8v15h8v15h30v-6h8V68h8V59h5V45h5v14h7v23h12v8h24v-7h13V66h7V43h5V28h6v15h7v23h13v8h24V81h18V58h7V36h5v22h7v23h34v20h28v39z" fill="var(--ink)" opacity=".96"/><path d="M180 140V94q0-41 40-58 40 17 40 58v46zm86 0V77q0-28 28-40 28 12 28 40v63z" fill="var(--ink2)"/><path d="M211 140v-37q0-13 9-13t9 13v37zm65 0v-34q0-10 8-10t8 10v34zm28 0v-34q0-10 8-10t8 10v34z" fill="var(--saison-lueur)" opacity=".7"/></svg></span>';

    function makeScene(className, footer) {
        var scene = document.createElement('div');
        scene.className = className;
        scene.setAttribute('aria-hidden', 'true');

        scene.innerHTML =
            '<span class="saison-croissant"></span>' +
            '<span class="saison-etoile saison-etoile--1"></span>' +
            '<span class="saison-etoile saison-etoile--2"></span>' +
            '<span class="saison-etoile saison-etoile--3"></span>' +
            '<span class="saison-etoile saison-etoile--4"></span>' +
            '<span class="saison-etoile saison-etoile--5"></span>' +
            '<span class="saison-etoile saison-etoile--6"></span>' +
            lantern +
            lantern.replace('saison-lanterne--1', 'saison-lanterne--2') +
            ((theme === 'ramadan' || theme === 'magal-touba') ? mosque : '');
        return scene;
    }

    var hero = document.querySelector('.hero');
    if (hero) hero.insertBefore(makeScene('saison-scene', false), hero.firstChild);

    var footer = document.querySelector('.footer');
    if (footer) footer.insertBefore(makeScene('saison-footer-scene', true), footer.firstChild);
})();
