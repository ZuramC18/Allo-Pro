(function () {
    'use strict';

    var racine = document.documentElement;
    var hero = document.querySelector('.hero');
    if (racine.dataset.eventTheme !== 'nouvel-an' || racine.dataset.eventAnimations !== '1') return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    var couleurs = ['#ffe8a6', '#ffffff', '#e8bd58', '#a9c8f0'];

    function tirerFeu(cible, zone, options) {
        zone = zone || { gauche: 54, largeur: 40, haut: 12, hauteur: 48 };
        options = options || {};
        var couleursFeu = options.couleurs || couleurs;
        var centreX = zone.gauche + Math.random() * zone.largeur;
        var centreY = zone.haut + Math.random() * zone.hauteur;
        var couleur = couleursFeu[Math.floor(Math.random() * couleursFeu.length)];
        var particules = options.particules || 16;
        var eclat = document.createElement('span');

        Object.assign(eclat.style, {
            position: 'absolute',
            left: centreX + '%',
            top: centreY + '%',
            width: (options.tailleEclat || 5) + 'px',
            height: (options.tailleEclat || 5) + 'px',
            borderRadius: '50%',
            background: couleur,
            boxShadow: '0 0 16px 5px ' + couleur,
            transform: 'translate(-50%, -50%)',
            opacity: '0',
            willChange: 'transform, opacity'
        });
        cible.appendChild(eclat);
        var animationEclat = eclat.animate(
            [
                { opacity: 0, transform: 'translate(-50%, -50%) scale(.2)' },
                { opacity: .95, offset: .12, transform: 'translate(-50%, -50%) scale(1)' },
                { opacity: 0, transform: 'translate(-50%, -50%) scale(.1)' }
            ],
                { duration: options.dureeEclat || 950, easing: 'ease-out' }
        );
        animationEclat.onfinish = function () { eclat.remove(); };

        for (var i = 0; i < particules; i++) {
            var particule = document.createElement('span');
            var angle = (Math.PI * 2 * i / particules) + (Math.random() * .18);
            var distance = (options.distanceMin || 28) + Math.random() * (options.distanceEtendue || 48);
            var deltaX = Math.cos(angle) * distance;
            var deltaY = Math.sin(angle) * distance;
            var taille = (options.tailleMin || 2) + Math.random() * (options.tailleEtendue || 2);
            var couleurParticule = couleursFeu[Math.floor(Math.random() * couleursFeu.length)];

            Object.assign(particule.style, {
                position: 'absolute',
                left: centreX + '%',
                top: centreY + '%',
                width: taille + 'px',
                height: taille + 'px',
                borderRadius: '50%',
                color: couleurParticule,
                background: couleurParticule,
                boxShadow: '0 0 8px currentColor',
                willChange: 'transform, opacity'
            });
            cible.appendChild(particule);
            var animationParticule = particule.animate(
                [
                    { opacity: 1, transform: 'translate3d(0, 0, 0) scale(1)' },
                    { opacity: 0, transform: 'translate3d(' + deltaX + 'px, ' + deltaY + 'px, 0) scale(.15)' }
                ],
                { duration: (options.dureeMin || 900) + Math.random() * (options.dureeEtendue || 450), easing: 'cubic-bezier(.12,.65,.35,1)' }
            );
            animationParticule.onfinish = function (event) { event.currentTarget.effect.target.remove(); };
        }
    }

    if (hero) {
    var etincelles = document.createElement('div');
    etincelles.className = 'nouvel-an-etincelles';
    etincelles.setAttribute('aria-hidden', 'true');
    Object.assign(etincelles.style, {
        position: 'absolute',
        inset: '0',
        zIndex: '0',
        pointerEvents: 'none',
        backgroundImage: 'radial-gradient(circle,#ffe8a6 1.5px,transparent 2px),radial-gradient(circle,rgba(255,255,255,.9) 1px,transparent 1.5px),radial-gradient(circle,rgba(232,189,88,.8) 1px,transparent 1.5px)',
        backgroundSize: '137px 113px,89px 107px,61px 79px',
        backgroundPosition: '10px 16px,44px 52px,20px 30px',
        maskImage: 'linear-gradient(90deg,transparent 3%,#000 48%,#000 100%)'
    });
    etincelles.animate(
        [
            { backgroundPosition: '10px 16px,44px 52px,20px 30px', opacity: .28 },
            { backgroundPosition: '28px 4px,32px 68px,36px 18px', opacity: .65 }
        ],
        { duration: 12000, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' }
    );
    hero.appendChild(etincelles);

    var feux = document.createElement('div');
    feux.className = 'nouvel-an-feux';
    feux.setAttribute('aria-hidden', 'true');
    Object.assign(feux.style, {
        position: 'absolute',
        inset: '0',
        zIndex: '0',
        overflow: 'hidden',
        pointerEvents: 'none'
    });
    hero.appendChild(feux);

    window.setTimeout(function () { tirerFeu(feux); }, 450);
    window.setInterval(function () { tirerFeu(feux); }, 2600);

    function tirerEtoileFilante() {
        var etoile = document.createElement('span');
        var departX = 62 + Math.random() * 38;
        var departY = 8 + Math.random() * 42;
        var distance = 220 + Math.random() * 180;

        Object.assign(etoile.style, {
            position: 'absolute',
            left: departX + '%',
            top: departY + '%',
            width: '110px',
            height: '2px',
            borderRadius: '50%',
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,.45) 55%, #fff4c4)',
            boxShadow: '0 0 9px rgba(255,232,166,.75)',
            opacity: '0',
            transform: 'rotate(-25deg)',
            transformOrigin: 'right center',
            willChange: 'transform, opacity'
        });
        feux.appendChild(etoile);

        var animationEtoile = etoile.animate(
            [
                { opacity: 0, transform: 'translate3d(0, 0, 0) rotate(-25deg)' },
                { opacity: .95, offset: .18, transform: 'translate3d(-18px, 10px, 0) rotate(-25deg)' },
                { opacity: 0, transform: 'translate3d(-' + distance + 'px, ' + (distance * .55) + 'px, 0) rotate(-25deg)' }
            ],
            { duration: 1100 + Math.random() * 500, easing: 'ease-out' }
        );
        animationEtoile.onfinish = function () { etoile.remove(); };
    }

    window.setTimeout(tirerEtoileFilante, 1800);
    window.setTimeout(tirerEtoileFilante, 4600);
    window.setTimeout(tirerEtoileFilante, 7200);

    function programmerEtoileSuivante() {
        window.setTimeout(function () {
            tirerEtoileFilante();
            programmerEtoileSuivante();
        }, 9000 + Math.random() * 6000);
    }
    programmerEtoileSuivante();
    }

    var footer = document.querySelector('.footer');
    if (footer) {
        var feuxFooter = document.createElement('div');
        feuxFooter.className = 'nouvel-an-feux-footer';
        feuxFooter.setAttribute('aria-hidden', 'true');
        footer.appendChild(feuxFooter);

        var zoneFooter = { gauche: 6, largeur: 88, haut: 12, hauteur: 72 };
        var optionsFooter = {
            couleurs: ['#ff3864', '#ffad1f', '#38e8a8', '#39b9ff', '#c879ff', '#fff15c'],
            particules: 24,
            tailleEclat: 7,
            tailleMin: 3,
            tailleEtendue: 3,
            distanceMin: 42,
            distanceEtendue: 72,
            dureeEclat: 1150,
            dureeMin: 1100,
            dureeEtendue: 600
        };
        function tirerSalveFooter() {
            var nombreDeFeux = 2 + Math.floor(Math.random() * 2);
            for (var i = 0; i < nombreDeFeux; i++) {
                window.setTimeout(function () {
                    tirerFeu(feuxFooter, zoneFooter, optionsFooter);
                }, i * 180);
            }
        }
        window.setTimeout(tirerSalveFooter, 900);
        window.setInterval(tirerSalveFooter, 3000);
    }
})();
