(function () {
    'use strict';

    var root = document.documentElement;
    if (root.dataset.eventTheme !== 'aid-el-fitr' || root.dataset.eventAnimations !== '1') return;

    var lantern = '<span class="aid-lantern"><i class="aid-lantern__fil"></i><svg viewBox="0 0 40 68" aria-hidden="true"><path d="M14 10h12l5 8-3 4v25l5 8H7l5-8V22l-3-4z" fill="#d5a943" stroke="#f4d982" stroke-width="2"/><path d="M15 23h10v23H15z" fill="#ffdf83" opacity=".88"/><path d="M9 55h22M14 10V5h12v5" fill="none" stroke="#f4d982" stroke-linecap="round" stroke-width="2"/><path d="M20 27c-5 6 5 8 0 15" fill="none" stroke="#fff6ca" stroke-linecap="round" stroke-width="2"/></svg></span>';
    var mosque = '<span class="aid-mosque"><svg viewBox="0 0 440 142" preserveAspectRatio="xMaxYMax meet" aria-hidden="true"><path d="M0 140V104h40V83h17V57h7V35h5v22h7v26h18v21h28V87h16V72h8V57h8v15h8v15h30v-6h8V68h8V59h5V45h5v14h7v23h12v8h24v-7h13V66h7V43h5V28h6v15h7v23h13v8h24V81h18V58h7V36h5v22h7v23h34v20h28v39z" fill="#0c241f" opacity=".96"/><path d="M180 140V94q0-41 40-58 40 17 40 58v46zm86 0V77q0-28 28-40 28 12 28 40v63z" fill="#14382e"/><path d="M211 140v-37q0-13 9-13t9 13v37zm65 0v-34q0-10 8-10t8 10v34zm28 0v-34q0-10 8-10t8 10v34z" fill="#e7c768" opacity=".7"/><path d="M40 104h36M118 87h35m53 7h58m2-17h56m2 4h57m18-23h33" stroke="#d4b75e" stroke-width="2" opacity=".6"/></svg></span>';

    function creerScene(className) {
        var scene = document.createElement('div');
        scene.className = className;
        scene.setAttribute('aria-hidden', 'true');
        scene.innerHTML =
            '<span class="aid-crescent"></span>' +
            '<span class="aid-star aid-star--one"></span>' +
            '<span class="aid-star aid-star--two"></span>' +
            '<span class="aid-star aid-star--three"></span>' +
            '<span class="aid-star aid-star--four"></span>' +
            '<span class="aid-star aid-star--five"></span>' +
            lantern +
            lantern.replace('class="aid-lantern"', 'class="aid-lantern aid-lantern--two"') +
            mosque;
        return scene;
    }

    var hero = document.querySelector('.hero');
    if (hero) hero.insertBefore(creerScene('aid-scene'), hero.firstChild);

    var footer = document.querySelector('.footer');
    if (footer) footer.insertBefore(creerScene('aid-footer-scene'), footer.firstChild);
})();
