(function () {
    'use strict';

    const script = document.currentScript;
    const badges = {
        refus: document.querySelector('[data-admin-badge="refus"]'),
        devis: document.querySelector('[data-admin-badge="devis"]'),
        remboursements: document.querySelector('[data-admin-badge="remboursements"]')
    };
    if (!script || !Object.values(badges).some(Boolean)) return;

    const api = new URL('../api-badges-admin.php', script.src).href;
    let requeteEnCours = false;

    function afficher(badge, nombre, libelle) {
        if (!badge) return;
        badge.dataset.count = String(nombre);
        badge.textContent = nombre > 99 ? '99+' : String(nombre);
        badge.hidden = nombre === 0;
        badge.setAttribute('aria-label', nombre + ' ' + libelle);
        badge.setAttribute('role', 'status');
    }

    function actualiserBadgesGroupes() {
        const selecteurBadges = 'a [data-admin-badge], a [data-mi-badge]';
        document.querySelectorAll('[data-admin-group-badge]').forEach((badgeGroupe) => {
            const conteneur = badgeGroupe.closest('details');
            if (!conteneur) return;
            const badgesLiens = conteneur.querySelectorAll(selecteurBadges);
            let total = 0;
            badgesLiens.forEach((badgeLien) => {
                const nombre = Number(badgeLien.dataset.count ?? badgeLien.textContent.replace('+', ''));
                if (Number.isInteger(nombre) && nombre > 0) total += nombre;
            });
            badgeGroupe.textContent = total > 99 ? '99+' : String(total);
            badgeGroupe.hidden = total === 0;
            badgeGroupe.setAttribute('aria-label', total + (total === 1 ? ' élément à traiter' : ' éléments à traiter'));
        });
    }

    async function actualiser() {
        if (requeteEnCours || document.hidden) return;
        requeteEnCours = true;
        try {
            const reponse = await fetch(api, { credentials: 'same-origin', cache: 'no-store' });
            if (!reponse.ok) return;
            const compteurs = await reponse.json();
            const definitions = [
                ['refus', 'refus à réaffecter'],
                ['devis', 'devis à traiter'],
                ['remboursements', 'autorisations de remboursement en attente']
            ];
            definitions.forEach(([cle, libelle]) => {
                const nombre = Number(compteurs[cle]);
                if (Number.isInteger(nombre) && nombre >= 0) afficher(badges[cle], nombre, libelle);
            });
            actualiserBadgesGroupes();
        } catch (erreur) {
            // Conserver les derniers nombres si le réseau est momentanément indisponible.
        } finally {
            requeteEnCours = false;
        }
    }

    let minuteur;
    function planifier() {
        clearTimeout(minuteur);
        minuteur = setTimeout(async function () {
            await actualiser();
            planifier();
        }, document.hidden ? 20000 : 7000);
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) actualiser();
        planifier();
    });
    const observateur = new MutationObserver(actualiserBadgesGroupes);
    document.querySelectorAll('a [data-admin-badge], a [data-mi-badge]').forEach((badge) => {
        observateur.observe(badge, { attributes: true, childList: true, characterData: true, subtree: true });
    });
    window.addEventListener('focus', actualiser);
    actualiserBadgesGroupes();
    actualiser();
    planifier();
})();
