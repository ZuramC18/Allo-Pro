(function () {
    'use strict';

    const script = document.currentScript;
    const badge = document.querySelector('[data-coordinateur-demandes-badge]');
    if (!script || !badge) return;

    const api = new URL('../api-demandes-coordinateur.php', script.src).href;
    let requeteEnCours = false;

    function afficherNombre(nombre) {
        badge.textContent = nombre > 99 ? '99+' : String(nombre);
        badge.hidden = nombre === 0;
        badge.setAttribute('aria-label', nombre + (nombre > 1 ? ' nouvelles demandes' : ' nouvelle demande'));
        badge.setAttribute('role', 'status');
    }

    async function actualiser() {
        if (requeteEnCours || document.hidden) return;
        requeteEnCours = true;
        try {
            const reponse = await fetch(api, { credentials: 'same-origin', cache: 'no-store' });
            if (!reponse.ok) return;
            const resultat = await reponse.json();
            const nombre = Number(resultat.nouvelles);
            if (Number.isInteger(nombre) && nombre >= 0) afficherNombre(nombre);
        } catch (erreur) {
            // Garde le dernier compteur affiché si le réseau est momentanément indisponible.
        } finally {
            requeteEnCours = false;
        }
    }

    let minuteur;
    function planifier() {
        clearTimeout(minuteur);
        minuteur = setTimeout(async function () {
            await actualiser();
            planifier();
        }, document.hidden ? 20000 : 7000);
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) actualiser();
        planifier();
    });
    window.addEventListener('focus', actualiser);
    actualiser();
    planifier();
})();
