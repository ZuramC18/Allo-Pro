// ---------- Utilitaires ----------
function echapper(s) {
    return String(s ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
const versHtml = (t) => echapper(t).replace(/\n/g, '<br>');

// Petit message de confirmation (3 secondes)
function afficherToast(texte) {
    document.querySelectorAll('.toast-msg').forEach(el => el.remove());
    const t = document.createElement('div');
    t.className = 'toast-msg';
    t.textContent = texte;
    t.setAttribute('role', 'status');
    t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);' +
        'background:#111827;color:#fff;padding:8px 16px;border-radius:8px;font-size:14px;z-index:10000;';
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}

// ---------- Fil de messages ----------
const filCorps = document.getElementById('fil-corps');
const racinePublique = new URL('../../public/', window.location.href);
const urlApiMessages = new URL('api-messages.php', racinePublique).href;
function afficherRepliLecteurAudio(audio) {
    if (audio.error?.code !== 4 || audio.dataset.repliAffiche === '1') return;
    audio.dataset.repliAffiche = '1';
    const repli = document.createElement('a');
    repli.className = 'bulle__audio-repli';
    repli.href = audio.currentSrc;
    repli.download = 'note-vocale';
    repli.textContent = 'Format non pris en charge — télécharger la note vocale';
    audio.insertAdjacentElement('afterend', repli);
}
function surveillerLecteurAudio(audio) {
    audio.addEventListener('error', () => afficherRepliLecteurAudio(audio));
    if (audio.error) afficherRepliLecteurAudio(audio);
}
document.querySelectorAll('.bulle__audio').forEach(surveillerLecteurAudio);
let clientActifId = filCorps ? filCorps.dataset.clientId : null;
let quitterConversation = null;
if (filCorps) {
    const clientId = filCorps.dataset.clientId;
    const viewer = filCorps.dataset.viewer;
    let dernierId = 0;

    const bulles = filCorps.querySelectorAll('[data-id]');
    if (bulles.length > 0) dernierId = bulles[bulles.length - 1].dataset.id;

    filCorps.scrollTop = filCorps.scrollHeight;

    function dateMessage(dateTexte) {
        const texte = String(dateTexte || '');
        const morceaux = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/.exec(texte);
        const date = morceaux
            ? new Date(Number(morceaux[1]), Number(morceaux[2]) - 1, Number(morceaux[3]), Number(morceaux[4]), Number(morceaux[5]), Number(morceaux[6] || 0))
            : new Date(texte);
        if (Number.isNaN(date.getTime())) return null;
        const cle = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        const aujourdhui = new Date();
        const cleAujourdhui = `${aujourdhui.getFullYear()}-${String(aujourdhui.getMonth() + 1).padStart(2, '0')}-${String(aujourdhui.getDate()).padStart(2, '0')}`;
        const hier = new Date(aujourdhui.getFullYear(), aujourdhui.getMonth(), aujourdhui.getDate() - 1);
        const cleHier = `${hier.getFullYear()}-${String(hier.getMonth() + 1).padStart(2, '0')}-${String(hier.getDate()).padStart(2, '0')}`;
        const options = { weekday: 'long', day: 'numeric', month: 'long' };
        if (date.getFullYear() !== aujourdhui.getFullYear()) options.year = 'numeric';
        let libelle = new Intl.DateTimeFormat('fr-FR', options).format(date);
        libelle = libelle.charAt(0).toLocaleUpperCase('fr-FR') + libelle.slice(1);
        if (cle === cleAujourdhui) libelle = 'Aujourd’hui';
        else if (cle === cleHier) libelle = 'Hier';
        return { date, cle, libelle };
    }

    function ajouterSeparateurJour(dateTexte) {
        const jour = dateMessage(dateTexte);
        if (!jour) return;
        const messages = filCorps.querySelectorAll('.bulle[data-jour]');
        const dernierMessage = messages[messages.length - 1];
        if (dernierMessage?.dataset.jour === jour.cle) return;
        const separateur = document.createElement('div');
        separateur.className = 'fil__separateur-jour';
        separateur.dataset.jour = jour.cle;
        const libelle = document.createElement('span');
        libelle.textContent = jour.libelle;
        separateur.appendChild(libelle);
        filCorps.appendChild(separateur);
    }

    function creerBulle(m) {
        const div = document.createElement('div');
        div.className = 'bulle ' + (m.expediteur_type === viewer ? 'bulle--moi' : 'bulle--autre');
        div.dataset.id = m.id;
        const jour = dateMessage(m.date_creation);
        if (jour) div.dataset.jour = jour.cle;
        div.dataset.lu = m.lu ?? 0;
        div.dataset.luDate = m.lu_date ?? '';
        div.dataset.modifie = m.modifie ?? 0;
        const date = dateMessage(m.date_creation)?.date;
        const heure = date ? date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '';
        const image = m.image_path
            ? `<a class="bulle__piece-jointe" href="${racinePublique.href}${echapper(m.image_path)}" target="_blank" rel="noopener"><img class="bulle__image" src="${racinePublique.href}${echapper(m.image_path)}" alt="Image jointe au message" loading="lazy"></a>`
            : '';
        const audio = m.audio_path
            ? `<audio class="bulle__audio" playsinline preload="metadata" aria-label="Lire la note vocale" title="Note vocale" src="${racinePublique.href}${echapper(m.audio_path)}"></audio>`
            : '';
        const texte = m.contenu ? `<div class="bulle__texte">${versHtml(m.contenu)}</div>` : '';
        div.innerHTML =
            `<div class="bulle__meta">${echapper(m.nom_expediteur || m.expediteur_type)} · ${heure}</div>` +
            image + audio + texte;
        const lecteurAudio = div.querySelector('.bulle__audio');
        if (lecteurAudio) surveillerLecteurAudio(lecteurAudio);
        return div;
    }

    // ----- Défilement : bouton « nouveaux messages » quand on a remonté l'historique -----
    const btnNouveaux = document.getElementById('btn-nouveaux');
    function estEnBas() { return filCorps.scrollHeight - filCorps.scrollTop - filCorps.clientHeight < 80; }
    function afficherBoutonNouveaux(visible) { if (btnNouveaux) btnNouveaux.hidden = !visible; }

    filCorps.addEventListener('scroll', () => { if (estEnBas()) afficherBoutonNouveaux(false); }, { passive: true });
    if (btnNouveaux) {
        btnNouveaux.addEventListener('click', () => {
            filCorps.scrollTo({ top: filCorps.scrollHeight, behavior: 'smooth' });
            afficherBoutonNouveaux(false);
        });
    }

    let enCours = false;
    let relancer = false;

    async function verifierNouveaux() {
        if (enCours) { relancer = true; return; }
        enCours = true;
        try {
            const res = await fetch(`${urlApiMessages}?client_id=${encodeURIComponent(clientId)}&apres_id=${encodeURIComponent(dernierId)}`);
            if (!res.ok) throw new Error();
            const nouveaux = await res.json();
            if (Array.isArray(nouveaux) && nouveaux.length > 0) {
                document.getElementById('fil-vide')?.remove();   // message d'accueil de la conversation vide
                const enBas = estEnBas();
                let recuDeLAutre = false;
                nouveaux.forEach(m => {
                    if (!filCorps.querySelector(`[data-id="${m.id}"]`)) {
                        ajouterSeparateurJour(m.date_creation);
                        filCorps.appendChild(creerBulle(m));
                        if (m.expediteur_type !== viewer) recuDeLAutre = true;
                    }
                    dernierId = m.id;
                });
                if (enBas) filCorps.scrollTop = filCorps.scrollHeight;
                else if (recuDeLAutre) afficherBoutonNouveaux(true);
            }
        } catch (e) { /* silencieux */ }
        finally {
            enCours = false;
            if (relancer) { relancer = false; verifierNouveaux(); }
        }
    }

    const pollTimer = setInterval(verifierNouveaux, 3000);

    // Quitter la conversation sans recharger la page
    let conversationOuverte = true;
    quitterConversation = function () {
        if (!conversationOuverte) return;
        conversationOuverte = false;
        clearInterval(pollTimer);

        const fil = filCorps.closest('.fil') || filCorps;
        fil.style.display = 'none';

        if (!document.getElementById('fil-placeholder')) {
            const p = document.createElement('div');
            p.id = 'fil-placeholder';
            p.style.cssText = 'flex:1;display:flex;align-items:center;justify-content:center;color:#6B7280;font-size:14px;';
            p.textContent = 'Sélectionnez une conversation';
            fil.insertAdjacentElement('afterend', p);
        }

        // Masque le panneau d'informations du client
        document.querySelectorAll('[data-fiche-client], .info-client, #infos-client, .infos-client, .fiche-client, .reponses-rapides')
            .forEach(el => { el.style.display = 'none'; });

        document.body.classList.remove('a-conversation');   // mobile : réaffiche la liste

        clientActifId = null;
        document.querySelectorAll('.conv-item--active').forEach(el => el.classList.remove('conv-item--active'));

        const url = filCorps.dataset.retour;
        if (url) history.pushState(null, '', url);
    };
    document.querySelector('.fil__retour')?.addEventListener('click', quitterConversation);

    // Bouton « précédent » du navigateur : on recharge l'état correspondant
    window.addEventListener('popstate', () => location.reload());

    // ----- Zone de saisie (peut être créée après coup, ex. conversation réouverte) -----
    function initialiserSaisie() {
        const btnEnvoyer = document.getElementById('btn-envoyer');
        const champMessage = document.getElementById('champ-message');
        if (!btnEnvoyer || !champMessage || btnEnvoyer.dataset.pret) return;
        btnEnvoyer.dataset.pret = '1';

        const btnPlusMedia = document.getElementById('btn-plus-media');
        const mediaActions = document.getElementById('media-actions');
        const composer = champMessage.closest('.composer');
        const compteur = document.getElementById('compteur-message');
        const champImage = document.getElementById('champ-image');
        const apercuImage = document.getElementById('apercu-image');
        const apercuImageImg = document.getElementById('apercu-image-img');
        const apercuImageNom = document.getElementById('apercu-image-nom');
        const retirerImage = document.getElementById('retirer-image');
        const btnEnregistrerAudio = document.getElementById('btn-enregistrer-audio');
        const apercuVoice = document.getElementById('apercu-voice');
        const apercuVoiceNom = document.getElementById('apercu-voice-nom');
        const apercuVoiceDuree = document.getElementById('apercu-voice-duree');
        const apercuVoiceAudio = document.getElementById('apercu-voice-audio');
        const retirerVoice = document.getElementById('retirer-voice');
        let urlApercuImage = null;
        let urlApercuAudio = null;
        let audioMediaStream = null;
        let audioRecorder = null;
        let audioChunks = [];
        let audioContext = null;
        let audioSource = null;
        let audioProcessor = null;
        let audioSilence = null;
        let audioFile = null;
        let enregistrementStart = null;
        const limite = parseInt(champMessage.getAttribute('maxlength'), 10) || 0;
        const cleBrouillon = `brouillon:${viewer}:${clientId}`;
        const tactile = window.matchMedia ? window.matchMedia('(pointer: coarse)').matches : false;

        // Le champ grandit avec le texte (repli pour les navigateurs sans field-sizing)
        const ajusterHauteur = () => {
            champMessage.style.height = 'auto';
            champMessage.style.height = Math.min(champMessage.scrollHeight, 140) + 'px';
            if (composer) {
                const styles = window.getComputedStyle(champMessage);
                const lineHeight = parseFloat(styles.lineHeight) || parseFloat(styles.fontSize) * 1.4;
                const paddingVertical = parseFloat(styles.paddingTop) + parseFloat(styles.paddingBottom);
                const lignes = Math.max(1, Math.round((champMessage.scrollHeight - paddingVertical) / lineHeight));
                composer.classList.toggle('composer--micro-en-haut', lignes >= 3);
            }
        };

        // Bouton grisé si le champ est vide, compteur près de la limite
        const majEtat = () => {
            const longueur = champMessage.value.length;
            const avecImage = !!champImage?.files?.length;
            const avecVoice = !!audioFile;
            if (composer) {
                composer.classList.toggle('composer--vide', champMessage.value.trim() === '' && !avecImage && !avecVoice);
                composer.classList.toggle('composer--avec-image', avecImage);
                composer.classList.toggle('composer--avec-voice', avecVoice);
            }
            if (compteur && limite) {
                compteur.hidden = longueur < limite * 0.8;
                compteur.textContent = `${longueur}/${limite}`;
                compteur.classList.toggle('composer__compteur--limite', longueur >= limite);
            }
        };

        // Brouillon conservé si on quitte ou recharge la page
        const sauverBrouillon = () => {
            try {
                if (champMessage.value.trim() !== '') localStorage.setItem(cleBrouillon, champMessage.value);
                else localStorage.removeItem(cleBrouillon);
            } catch (e) { /* stockage indisponible : on ignore */ }
        };
        try {
            const brouillon = localStorage.getItem(cleBrouillon);
            if (brouillon && champMessage.value === '') champMessage.value = brouillon;
        } catch (e) { /* ignore */ }

        if (btnPlusMedia && mediaActions) {
            const toggleMedia = () => {
                const visible = mediaActions.hidden;
                mediaActions.hidden = !visible;
                btnPlusMedia.setAttribute('aria-expanded', String(visible));
            };
            btnPlusMedia.addEventListener('click', (event) => {
                event.stopPropagation();
                toggleMedia();
            });
            document.addEventListener('click', (event) => {
                if (!event.target.closest('.composer__media-wrap')) {
                    mediaActions.hidden = true;
                    btnPlusMedia.setAttribute('aria-expanded', 'false');
                }
            });
        }

        champMessage.addEventListener('input', () => { ajusterHauteur(); majEtat(); sauverBrouillon(); });

        function viderImage() {
            if (urlApercuImage) URL.revokeObjectURL(urlApercuImage);
            urlApercuImage = null;
            if (champImage) champImage.value = '';
            if (apercuImage) apercuImage.hidden = true;
            if (apercuImageImg) apercuImageImg.removeAttribute('src');
            if (apercuImageNom) apercuImageNom.textContent = '';
            majEtat();
        }

        function formaterDuree(seconde) {
            const total = Math.max(0, Math.floor(seconde));
            const min = String(Math.floor(total / 60)).padStart(2, '0');
            const sec = String(total % 60).padStart(2, '0');
            return `${min}:${sec}`;
        }

        function viderAudio() {
            if (urlApercuAudio) URL.revokeObjectURL(urlApercuAudio);
            urlApercuAudio = null;
            if (apercuVoiceAudio) {
                apercuVoiceAudio.pause();
                apercuVoiceAudio.removeAttribute('src');
                apercuVoiceAudio.load();
            }
            if (audioProcessor) {
                audioProcessor.disconnect();
                audioProcessor.onaudioprocess = null;
                audioProcessor = null;
            }
            if (audioSource) {
                audioSource.disconnect();
                audioSource = null;
            }
            if (audioSilence) {
                audioSilence.disconnect();
                audioSilence = null;
            }
            if (audioMediaStream) {
                audioMediaStream.getTracks().forEach(track => track.stop());
                audioMediaStream = null;
            }
            if (audioContext && audioContext.state !== 'closed') {
                void audioContext.close();
            }
            audioContext = null;
            audioFile = null;
            audioChunks = [];
            audioRecorder = null;
            enregistrementStart = null;
            if (apercuVoice) apercuVoice.hidden = true;
            if (apercuVoice) apercuVoice.classList.remove('is-recording');
            if (apercuVoiceNom) apercuVoiceNom.textContent = 'Note vocale';
            if (apercuVoiceDuree) apercuVoiceDuree.textContent = '00:00';
            if (btnEnregistrerAudio) {
                btnEnregistrerAudio.classList.remove('is-recording');
                btnEnregistrerAudio.setAttribute('aria-label', 'Enregistrer une note vocale');
            }
            if (btnEnregistrerAudio) btnEnregistrerAudio.title = 'Enregistrer une note vocale';
            majEtat();
        }

        function creerFichierWav(blocsAudio, frequence) {
            const nombreEchantillons = blocsAudio.reduce((total, bloc) => total + bloc.length, 0);
            if (!nombreEchantillons) return null;

            const donnees = new ArrayBuffer(44 + nombreEchantillons * 2);
            const vue = new DataView(donnees);
            const ecrireTexte = (decalage, texte) => {
                for (let i = 0; i < texte.length; i++) {
                    vue.setUint8(decalage + i, texte.charCodeAt(i));
                }
            };
            ecrireTexte(0, 'RIFF');
            vue.setUint32(4, donnees.byteLength - 8, true);
            ecrireTexte(8, 'WAVE');
            ecrireTexte(12, 'fmt ');
            vue.setUint32(16, 16, true);
            vue.setUint16(20, 1, true);
            vue.setUint16(22, 1, true);
            vue.setUint32(24, frequence, true);
            vue.setUint32(28, frequence * 2, true);
            vue.setUint16(32, 2, true);
            vue.setUint16(34, 16, true);
            ecrireTexte(36, 'data');
            vue.setUint32(40, nombreEchantillons * 2, true);

            let position = 44;
            blocsAudio.forEach((bloc) => {
                for (let i = 0; i < bloc.length; i++) {
                    const echantillon = Math.max(-1, Math.min(1, bloc[i]));
                    vue.setInt16(position, echantillon < 0 ? echantillon * 0x8000 : echantillon * 0x7fff, true);
                    position += 2;
                }
            });
            return new Blob([donnees], { type: 'audio/wav' });
        }

        function terminerEnregistrementAudio() {
            if (!audioRecorder || audioRecorder.state !== 'recording') return;
            audioRecorder.state = 'stopping';
            const contexte = audioContext;
            const blocsAudio = audioChunks;
            const frequence = contexte?.sampleRate || 48000;

            if (audioProcessor) {
                audioProcessor.disconnect();
                audioProcessor.onaudioprocess = null;
                audioProcessor = null;
            }
            if (audioSource) {
                audioSource.disconnect();
                audioSource = null;
            }
            if (audioSilence) {
                audioSilence.disconnect();
                audioSilence = null;
            }
            if (audioMediaStream) {
                audioMediaStream.getTracks().forEach(track => track.stop());
                audioMediaStream = null;
            }
            if (contexte && contexte.state !== 'closed') {
                void contexte.close().catch((error) => console.error('Fermeture du contexte audio impossible.', error));
            }
            audioContext = null;

            const blob = creerFichierWav(blocsAudio, frequence);
            audioChunks = [];
            audioRecorder = null;
            if (!blob || blob.size <= 44 || blob.size > 10 * 1024 * 1024) {
                viderAudio();
                alert(blob?.size > 10 * 1024 * 1024
                    ? 'La note vocale dépasse la taille maximale de 10 Mo.'
                    : 'Aucun audio n’a été capturé.');
                return;
            }

            audioFile = new File([blob], `note-vocale-${Date.now()}.wav`, { type: 'audio/wav' });
            if (urlApercuAudio) URL.revokeObjectURL(urlApercuAudio);
            urlApercuAudio = URL.createObjectURL(blob);
            if (apercuVoiceAudio) {
                apercuVoiceAudio.src = urlApercuAudio;
                apercuVoiceAudio.load();
                apercuVoiceAudio.onloadedmetadata = () => {
                    if (apercuVoiceDuree) apercuVoiceDuree.textContent = formaterDuree(apercuVoiceAudio.duration || 0);
                };
            }
            if (apercuVoiceNom) apercuVoiceNom.textContent = 'Note vocale prête à envoyer';
            if (apercuVoice) apercuVoice.hidden = false;
            if (apercuVoice) apercuVoice.classList.remove('is-recording');
            if (apercuImage) apercuImage.hidden = true;
            if (btnEnregistrerAudio) {
                btnEnregistrerAudio.classList.remove('is-recording');
                btnEnregistrerAudio.title = 'Réenregistrer une note vocale';
                btnEnregistrerAudio.setAttribute('aria-label', 'Réenregistrer une note vocale');
            }
            majEtat();
        }

        champImage?.addEventListener('change', () => {
            const fichier = champImage.files?.[0];
            if (!fichier) { viderImage(); return; }
            if (!['image/jpeg', 'image/png', 'image/webp'].includes(fichier.type)) {
                viderImage();
                alert('Choisissez une image JPG, PNG ou WebP.');
                return;
            }
            if (fichier.size > 4 * 1024 * 1024) {
                viderImage();
                alert('L’image doit faire 4 Mo maximum.');
                return;
            }
            if (urlApercuImage) URL.revokeObjectURL(urlApercuImage);
            urlApercuImage = URL.createObjectURL(fichier);
            if (apercuImageImg) apercuImageImg.src = urlApercuImage;
            if (apercuImageNom) apercuImageNom.textContent = fichier.name;
            if (apercuImage) apercuImage.hidden = false;
            if (apercuVoice) apercuVoice.hidden = true;
            majEtat();
        });
        retirerImage?.addEventListener('click', viderImage);

        btnEnregistrerAudio?.addEventListener('click', async () => {
            if (!navigator.mediaDevices || !(window.AudioContext || window.webkitAudioContext)) {
                alert('L’enregistrement audio n’est pas compatible avec ce navigateur.');
                return;
            }
            if (audioRecorder && audioRecorder.state === 'recording') {
                void terminerEnregistrementAudio();
                return;
            }
            try {
                if (audioFile) {
                    viderAudio();
                }
                const flux = await navigator.mediaDevices.getUserMedia({ audio: true });
                audioMediaStream = flux;
                audioChunks = [];
                const AudioContextClasse = window.AudioContext || window.webkitAudioContext;
                audioContext = new AudioContextClasse();
                await audioContext.resume();
                audioSource = audioContext.createMediaStreamSource(flux);
                audioProcessor = audioContext.createScriptProcessor(4096, 1, 1);
                audioSilence = audioContext.createGain();
                audioSilence.gain.value = 0;
                audioProcessor.onaudioprocess = (event) => {
                    audioChunks.push(new Float32Array(event.inputBuffer.getChannelData(0)));
                };
                audioSource.connect(audioProcessor);
                audioProcessor.connect(audioSilence);
                audioSilence.connect(audioContext.destination);
                audioRecorder = { state: 'recording' };
                enregistrementStart = Date.now();
                if (apercuVoice) {
                    apercuVoice.hidden = false;
                    apercuVoice.classList.add('is-recording');
                }
                if (apercuVoiceNom) apercuVoiceNom.textContent = 'Enregistrement en cours';
                if (apercuVoiceDuree) apercuVoiceDuree.textContent = '00:00';
                if (btnEnregistrerAudio) {
                    btnEnregistrerAudio.classList.add('is-recording');
                    btnEnregistrerAudio.title = 'Stopper l’enregistrement';
                    btnEnregistrerAudio.setAttribute('aria-label', 'Arrêter l’enregistrement');
                }
                const dureeMax = 60000;
                setTimeout(() => {
                    if (audioRecorder && audioRecorder.state === 'recording') {
                        void terminerEnregistrementAudio();
                    }
                }, dureeMax);
                const timerVoice = setInterval(() => {
                    if (!enregistrementStart || !audioRecorder || audioRecorder.state !== 'recording') {
                        clearInterval(timerVoice);
                        return;
                    }
                    if (apercuVoiceDuree) {
                        apercuVoiceDuree.textContent = formaterDuree((Date.now() - enregistrementStart) / 1000);
                    }
                }, 250);
            } catch (e) {
                console.error('Enregistrement note vocale impossible.', e);
                alert('Le microphone ou l’enregistrement audio est indisponible. Vérifiez les autorisations du navigateur puis réessayez.');
                viderAudio();
            }
        });

        retirerVoice?.addEventListener('click', () => {
            viderAudio();
            if (apercuVoice) apercuVoice.hidden = true;
        });

        ajusterHauteur();
        majEtat();

        // Sur ordinateur, on place le curseur dans le champ (pas sur mobile : évite d'ouvrir le clavier)
        if (!tactile && document.activeElement === document.body) champMessage.focus({ preventScroll: true });

        btnEnvoyer.addEventListener('click', async () => {
            const contenu = champMessage.value.trim();
            const fichierImage = champImage?.files?.[0] || null;
            const fichierAudio = audioFile || null;
            if ((!contenu && !fichierImage && !fichierAudio) || btnEnvoyer.disabled) return;
            btnEnvoyer.disabled = true;
            try {
                const donnees = new FormData();
                donnees.append('client_id', clientId);
                donnees.append('contenu', contenu);
                donnees.append('csrf', filCorps.dataset.csrf || '');
                if (fichierImage) donnees.append('image', fichierImage);
                if (fichierAudio) donnees.append('audio', fichierAudio);

                const res = await fetch(urlApiMessages, {
                    method: 'POST',
                    body: donnees
                });
                const resultat = await res.json().catch(() => {
                    throw new Error('Le serveur a renvoyé une réponse invalide. Rechargez la page et réessayez.');
                });
                if (!res.ok) throw new Error(resultat.erreur || 'Échec de l’envoi.');
                champMessage.value = '';
                viderImage();
                viderAudio();
                ajusterHauteur();
                majEtat();
                sauverBrouillon();
                await verifierNouveaux();
                filCorps.scrollTop = filCorps.scrollHeight;
                afficherBoutonNouveaux(false);
            } catch (e) {
                alert(e.message || "Le message n'a pas pu être envoyé.");
            } finally {
                btnEnvoyer.disabled = false;
                champMessage.focus();
            }
        });

        // Entrée envoie (ordinateur) ; Maj+Entrée = nouvelle ligne ; Ctrl/Cmd+Entrée envoie partout.
        // Sur écran tactile, Entrée fait un retour à la ligne : on envoie avec le bouton.
        champMessage.addEventListener('keydown', (e) => {
            if (e.key !== 'Enter' || e.isComposing) return;
            if (e.ctrlKey || e.metaKey || (!e.shiftKey && !tactile)) {
                e.preventDefault();
                btnEnvoyer.click();
            }
        });
    }
    initialiserSaisie();

    // ----- Suggestions de départ (puces cliquables sur une conversation vide) -----
    document.addEventListener('click', (e) => {
        const puce = e.target.closest('[data-suggestion]');
        const champ = document.getElementById('champ-message');
        if (!puce || !champ) return;
        champ.value = puce.dataset.suggestion;
        champ.dispatchEvent(new Event('input'));
        champ.focus();
    });

    // ----- Réouverture de la conversation sans recharger la page -----
    const formReouvrir = document.getElementById('form-reouvrir');
    if (formReouvrir) {
        formReouvrir.addEventListener('submit', async (e) => {
            e.preventDefault();
            const bouton = formReouvrir.querySelector('button[type="submit"]');
            if (bouton.disabled) return;
            bouton.disabled = true;
            try {
                const res = await fetch(formReouvrir.action, { method: 'POST', body: new FormData(formReouvrir) });
                if (!res.ok) throw new Error();

                const modele = document.getElementById('tpl-saisie');
                const zone = document.getElementById('zone-saisie');
                if (!modele || !zone) { location.reload(); return; }

                zone.replaceChildren(modele.content.cloneNode(true));
                initialiserSaisie();
                document.getElementById('champ-message')?.focus();
                afficherToast('Conversation réouverte');
            } catch (err) {
                bouton.disabled = false;
                alert("Impossible de réouvrir la conversation.");
            }
        });
    }
}

// ---------- Liste des conversations ----------
const convListe = document.getElementById('conv-liste');
if (convListe) {
    function tempsRelatifConversation(dateTexte) {
        if (!dateTexte) return '';
        const date = new Date(String(dateTexte).replace(' ', 'T'));
        if (Number.isNaN(date.getTime())) return '';

        let secondes = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
        if (secondes < 60) return 'À l’instant';

        const unites = [
            ['an', 31536000],
            ['mois', 2592000],
            ['sem', 604800],
            ['j', 86400],
            ['h', 3600],
            ['min', 60]
        ];
        const parties = [];
        for (const [libelle, duree] of unites) {
            const quantite = Math.floor(secondes / duree);
            if (quantite > 0) {
                parties.push(`${quantite} ${libelle}`);
                secondes %= duree;
                if (parties.length === 2) break;
            }
        }
        return `Il y a ${parties.join(' ')}`;
    }

    function initiales(nom) {
        const parties = String(nom ?? '').trim().split(/\s+/);
        const premiere = parties[0]?.[0] || '';
        const derniere = parties.length > 1 ? parties[parties.length - 1][0] : '';
        return (premiere + derniere).toUpperCase();
    }

    function rendreListe(conversations) {
        const active = convListe.querySelector('.conv-item--active');
        const conserverActive = active
            && !conversations.some(c => String(c.id) === String(clientActifId));
        if (conversations.length === 0 && !conserverActive) {
            convListe.innerHTML = '<div class="conv-liste__entete">Conversations</div><p style="padding:20px; color:#6B7280; font-size:14px;">Aucune conversation pour le moment.</p>';
            return;
        }

        let html = '<div class="conv-liste__entete">Conversations</div>';
        if (conserverActive) html += active.outerHTML;
        conversations.forEach(c => {
            const actif = String(c.id) === String(clientActifId) ? 'conv-item--active' : '';
            const fermee = c.conversation_statut === 'fermee';
            const etatClasse = fermee ? 'conv-item--fermee' : '';
            const etatConversation = fermee
                ? `<span class="conv-item__etat">${c.conseiller_assigne_id ? 'Conversation fermée' : 'Fermée · À reprendre'}</span>`
                : '';
            const apercu = c.dernier_message
                ? echapper(c.dernier_message)
                : '<em>Aucun message</em>';
            const date = tempsRelatifConversation(c.derniere_date);
            const badge = c.non_lus > 0 ? `<span class="conv-item__badge">${echapper(c.non_lus)}</span>` : '';
            const nom = c.nom_complet || c.nom || 'Client';

            html += `
                <a href="messagerie.php?client_id=${encodeURIComponent(c.id)}" class="conv-item ${actif} ${etatClasse}">
                    <div class="conv-item__avatar">${echapper(initiales(nom))}</div>
                    <div class="conv-item__contenu">
                        <div class="conv-item__haut">
                            <span class="conv-item__nom">${echapper(nom)}</span>
                            <span class="conv-item__date">${date}</span>
                        </div>
                        <div class="conv-item__apercu">${apercu}</div>
                        ${etatConversation}
                    </div>
                    ${badge}
                </a>`;
        });
        convListe.innerHTML = html;
    }

    let listeEnCours = false;
    async function actualiserListe() {
        if (listeEnCours) return;
        listeEnCours = true;
        try {
            const res = await fetch('/allopro/public/api-conversations.php');
            if (!res.ok) throw new Error();
            const conversations = await res.json();
            if (Array.isArray(conversations)) {
                rendreListe(conversations);
            }
        } catch (e) { /* silencieux */ }
        finally { listeEnCours = false; }
    }

    setInterval(actualiserListe, 5000);
}

// ---------- Menu contextuel (Copier / Modifier) ----------
const menuContextuel = document.getElementById('menu-contextuel');
if (menuContextuel) {
    const btnCopier = document.getElementById('btn-copier');
    let bulleCiblee = null;

    function fermerMenu() { menuContextuel.style.display = 'none'; }

    // Petit message de confirmation
    function toast(texte) { afficherToast(texte); }

    // Copie : clipboard API (HTTPS/localhost) avec repli pour HTTP
    async function copierTexte(texte) {
        if (navigator.clipboard && window.isSecureContext) {
            try { await navigator.clipboard.writeText(texte); return true; } catch (e) { /* repli */ }
        }
        const ta = document.createElement('textarea');
        ta.value = texte;
        ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
        document.body.appendChild(ta);
        ta.select();
        let ok = false;
        try { ok = document.execCommand('copy'); } catch (e) { /* ignore */ }
        ta.remove();
        return ok;
    }

    function ouvrirMenu(bulle, x, y) {
        bulleCiblee = bulle;
        menuContextuel.style.display = 'block';
        const px = Math.min(x, window.innerWidth - menuContextuel.offsetWidth - 8);
        const py = Math.min(y, window.innerHeight - menuContextuel.offsetHeight - 8);
        menuContextuel.style.left = Math.max(8, px) + 'px';
        menuContextuel.style.top = Math.max(8, py) + 'px';
    }

    // Clic droit (ordinateur)
    document.addEventListener('contextmenu', (e) => {
        const bulle = e.target.closest('.bulle');
        if (!bulle) return;
        e.preventDefault();
        ouvrirMenu(bulle, e.clientX, e.clientY);
    });

    // Appui long (mobile)
    let timerAppui = null;
    document.addEventListener('touchstart', (e) => {
        const bulle = e.target.closest('.bulle');
        if (!bulle) return;
        const t = e.touches[0];
        timerAppui = setTimeout(() => ouvrirMenu(bulle, t.clientX, t.clientY), 500);
    }, { passive: true });
    ['touchend', 'touchmove', 'touchcancel'].forEach(ev =>
        document.addEventListener(ev, () => clearTimeout(timerAppui), { passive: true })
    );

    document.addEventListener('click', (e) => {
        if (!menuContextuel.contains(e.target)) fermerMenu();
    });

    // Copier
    btnCopier.addEventListener('click', async () => {
        const zone = bulleCiblee?.querySelector('.bulle__texte');
        fermerMenu();
        if (!zone) return;
        const ok = await copierTexte(zone.innerText);
        toast(ok ? 'Message copié' : 'Copie impossible');
    });

}

// ---------- Échap : ferme d'abord menu/modale, sinon quitte la conversation ----------
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || e.isComposing) return;

    const estOuvert = (el) => el && getComputedStyle(el).display !== 'none';

    const menu = document.getElementById('menu-contextuel');
    if (estOuvert(menu)) { menu.style.display = 'none'; return; }

    const modale = document.getElementById('modale-fond');
    if (estOuvert(modale)) { modale.style.display = 'none'; return; }

    // Modale des réponses rapides
    const rrModale = document.querySelector('.rr-modale-fond--visible');
    if (rrModale) { rrModale.classList.remove('rr-modale-fond--visible'); return; }

    // Si on est en train d'écrire un message, le premier Échap retire seulement le focus
    const champ = document.getElementById('champ-message');
    if (champ && document.activeElement === champ && champ.value.trim() !== '') {
        champ.blur();
        return;
    }

    // Page conseiller (liste + fil) : on quitte sans recharger
    if (quitterConversation && document.getElementById('conv-liste')) {
        quitterConversation();
        return;
    }

    // Page client (pas de liste) : redirection
    const url = document.getElementById('fil-corps')?.dataset.retour;
    if (url) window.location.href = url;
});

(function () {
    'use strict';

    var data = (typeof REPONSES_RAPIDES !== 'undefined' && Array.isArray(REPONSES_RAPIDES)) ? REPONSES_RAPIDES : [];
    var champ = function () { return document.getElementById('champ-message'); };
    var zoneSuggestions = function () { return document.getElementById('suggestions-rr'); };

    function viderSuggestions() {
        var z = zoneSuggestions();
        if (z) z.textContent = '';
    }

    // remplacer = true : la réponse prend la place du texte tapé ; sinon elle s'ajoute à la suite
    function inserer(texte, remplacer) {
        var c = champ();
        if (!c) return;
        c.value = (remplacer || c.value.trim() === '')
            ? texte
            : c.value.replace(/\s+$/, '') + ' ' + texte;
        c.dispatchEvent(new Event('input', { bubbles: true }));   // taille du champ, brouillon, bouton d'envoi
        c.focus();
        c.scrollTop = c.scrollHeight;
        viderSuggestions();
    }

    function bouton(r, classe, remplacer) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = classe;

       if (classe === 'rr-suggestion') {
            // Suggestions : uniquement le contenu, sur 2 lignes maximum
            var texte = document.createElement('span');
            texte.className = 'rr-suggestion__texte';
            texte.textContent = r.contenu;
            b.appendChild(texte);
            b.title = r.contenu;                 // texte complet au survol
        } else {
            // Colonne de droite : titre + contenu
            var t = document.createElement('span');
            t.className = 'rr-item__titre';
            t.textContent = r.titre;

            var c = document.createElement('span');
            c.className = 'rr-item__contenu';
            c.textContent = r.contenu;

            b.appendChild(t);
            b.appendChild(c);
        }

        b.addEventListener('click', function () { inserer(r.contenu, remplacer); });
        return b;
    }

    // ----- Colonne de droite, regroupée par catégorie -----
    var liste = document.getElementById('rr-liste');
    if (liste) {
        liste.textContent = '';
        if (data.length === 0) {
            var vide = document.createElement('p');
            vide.textContent = 'Aucune réponse rapide enregistrée.';
            vide.style.cssText = 'font-size:13px;color:#9CA3AF;margin:0;';
            liste.appendChild(vide);
        }
        var groupes = {};
        data.forEach(function (r) {
            var cat = r.categorie || 'Général';
            (groupes[cat] = groupes[cat] || []).push(r);
        });
        Object.keys(groupes).forEach(function (cat) {
            var t = document.createElement('div');
            t.className = 'rr-categorie';
            t.textContent = cat;
            liste.appendChild(t);
            groupes[cat].forEach(function (r) { liste.appendChild(bouton(r, 'rr-item', false)); });
        });
    }

    // ----- Suggestions au-dessus du champ, selon le dernier mot tapé -----
    function normaliser(s) {
        return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }
    function mots(s) {
        return normaliser(s).split(/[^a-z0-9]+/).filter(Boolean);
    }

    function actualiserSuggestions() {
        var z = zoneSuggestions(), c = champ();
        if (!z || !c) return;
        z.textContent = '';

        var tapes = mots(c.value).filter(function (m) { return m.length >= 3; });
        if (tapes.length === 0) return;
        var dernier = tapes[tapes.length - 1];

        data.filter(function (r) {
            return mots(r.mots_cles).concat(mots(r.titre)).some(function (k) {
                return k.indexOf(dernier) === 0 || (k.length >= 4 && dernier.indexOf(k) === 0);
            });
        }).slice(0, 4).forEach(function (r) {
            z.appendChild(bouton(r, 'rr-suggestion', true));
        });
    }

    // Écoute déléguée : fonctionne aussi si le champ est créé après coup
    document.addEventListener('input', function (e) {
        if (e.target && e.target.id === 'champ-message') actualiserSuggestions();
    });
})();