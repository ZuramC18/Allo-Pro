(function () {
    'use strict';

    const interfaceAppel = document.getElementById('interface-appel-web');
    if (!interfaceAppel) return;

    const api = new URL('../api-appels-web.php', document.currentScript.src).href;
    const role = interfaceAppel.dataset.role;
    const csrf = interfaceAppel.dataset.csrf || '';
    const titre = document.getElementById('appel-web-titre');
    const statut = document.getElementById('appel-web-statut');
    const erreur = document.getElementById('appel-web-erreur');
    const repondre = document.getElementById('appel-web-repondre');
    const refuser = document.getElementById('appel-web-refuser');
    const boutonRetour = document.getElementById('appel-web-retour');
    const raccrocher = document.getElementById('appel-web-raccrocher');
    const boutonMuet = document.getElementById('appel-web-muet');
    const microDistant = document.getElementById('appel-web-micro-distant');
    const duree = document.getElementById('appel-web-duree');
    const audioDistant = document.getElementById('appel-web-audio');
    let appel = null;
    let connexion = null;
    let canalMicro = null;
    let fluxLocal = null;
    let prochainSignalId = 0;
    let signauxEnAttente = [];
    let minuterie = null;
    let appelEntrantActif = false;
    let boutonAppelActif = null;
    let presenceEnCours = false;
    let sondageEnCours = false;
    let horlogeDuree = null;
    let debutAppel = null;
    let nettoyageDiffere = null;
    let nomInterlocuteur = '';

    function afficherAvertissementConversation(actif) {
        if (role !== 'conseiller') return;
        const avertissement = document.querySelector('.fil__appel-avertissement');
        if (avertissement) avertissement.hidden = !actif;
    }

    async function requete(action, donnees) {
        const formulaire = new FormData();
        formulaire.set('action', action);
        formulaire.set('csrf', csrf);
        formulaire.set('acteur_role', role);
        Object.entries(donnees || {}).forEach(([cle, valeur]) => formulaire.set(cle, String(valeur)));
        const reponse = await fetch(api, { method: 'POST', body: formulaire, credentials: 'same-origin', cache: 'no-store' });
        const resultat = await reponse.json();
        if (!reponse.ok || resultat.erreur) {
            const exception = new Error(resultat.erreur || 'La demande a échoué.');
            exception.status = reponse.status;
            throw exception;
        }
        return resultat;
    }

    function afficher(statutTexte, options) {
        const config = options || {};
        if (role === 'conseiller' && nomInterlocuteur) {
            titre.textContent = nomInterlocuteur;
        } else {
            titre.textContent = '';
            const allo = document.createElement('span');
            allo.textContent = 'Allo';
            const pro = document.createElement('span');
            pro.className = 'appel-web__titre-pro';
            pro.textContent = 'Pro';
            titre.append(allo, pro);
        }
        statut.textContent = statutTexte;
        erreur.hidden = true;
        erreur.textContent = '';
        repondre.hidden = !config.repondre;
        refuser.hidden = !config.refuser;
        boutonRetour.hidden = !config.retour;
        raccrocher.hidden = !config.raccrocher;
        boutonMuet.hidden = !config.muet;
        interfaceAppel.hidden = false;
    }

    function afficherPleinEcran() {
        if (role !== 'conseiller') {
            interfaceAppel.classList.remove('appel-web--reduit');
            interfaceAppel.classList.add('appel-web--plein-ecran');
        }
    }

    function basculerAffichageAppel() {
        if (interfaceAppel.classList.contains('appel-web--reduit')) {
            interfaceAppel.classList.remove('appel-web--reduit');
            if (role === 'client') interfaceAppel.classList.add('appel-web--plein-ecran');
            boutonRetour.textContent = 'Retour à la conversation';
        } else {
            interfaceAppel.classList.remove('appel-web--plein-ecran');
            interfaceAppel.classList.add('appel-web--reduit');
            boutonRetour.textContent = 'Agrandir l’appel';
        }
    }

    function demarrerDuree() {
        if (debutAppel !== null) return;
        debutAppel = Date.now();
        duree.hidden = false;
        const actualiser = () => {
            const secondes = Math.floor((Date.now() - debutAppel) / 1000);
            duree.textContent = String(Math.floor(secondes / 60)).padStart(2, '0') + ':' +
                String(secondes % 60).padStart(2, '0');
        };
        actualiser();
        horlogeDuree = window.setInterval(actualiser, 1000);
    }

    function actualiserMicro() {
        if (!fluxLocal) return;
        const muet = fluxLocal.getAudioTracks().some((piste) => !piste.enabled);
        boutonMuet.setAttribute('aria-pressed', muet ? 'true' : 'false');
        boutonMuet.textContent = muet ? 'Activer le micro' : 'Couper le micro';
        envoyerEtatMicro(muet);
    }

    function envoyerEtatMicro(muet) {
        if (canalMicro && canalMicro.readyState === 'open') {
            canalMicro.send(muet ? 'micro:muet' : 'micro:actif');
        }
    }

    function recevoirEtatMicro(canal) {
        canalMicro = canal;
        canalMicro.addEventListener('message', (evenement) => {
            if (role !== 'conseiller') return;
            if (evenement.data === 'micro:muet') {
                microDistant.hidden = false;
            } else if (evenement.data === 'micro:actif') {
                microDistant.hidden = true;
            }
        });
        canalMicro.addEventListener('open', () => {
            if (role === 'client' && fluxLocal) {
                envoyerEtatMicro(fluxLocal.getAudioTracks().every((piste) => !piste.enabled));
            }
        });
    }

    function basculerMicro() {
        if (!fluxLocal) return;
        const microMuet = fluxLocal.getAudioTracks().some((piste) => piste.enabled);
        fluxLocal.getAudioTracks().forEach((piste) => { piste.enabled = !microMuet; });
        actualiserMicro();
    }

    function afficherErreur(message) {
        erreur.textContent = message;
        erreur.hidden = false;
    }

    function creerConnexion() {
        connexion = new RTCPeerConnection({
            iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
        });
        connexion.ondatachannel = (evenement) => recevoirEtatMicro(evenement.channel);
        connexion.ontrack = (evenement) => {
            audioDistant.srcObject = evenement.streams[0];
            audioDistant.play().catch(() => afficherErreur('Autorisez la lecture audio dans votre navigateur.'));
        };
        connexion.onicecandidate = (evenement) => {
            if (evenement.candidate && appel) {
                envoyerSignal('candidat', evenement.candidate.toJSON()).catch((exception) => afficherErreur(exception.message));
            }
        };
        connexion.onconnectionstatechange = () => {
            if (connexion && connexion.connectionState === 'connected') {
                statut.textContent = 'Appel en cours';
                afficherAvertissementConversation(true);
            }
            if (connexion && ['failed', 'disconnected'].includes(connexion.connectionState)) {
                afficherErreur('La connexion audio a été interrompue. Vérifiez votre réseau.');
            }
        };
    }

    async function envoyerSignal(type, contenu) {
        await requete('signal', {
            appel_id: appel.id,
            type,
            contenu: JSON.stringify(contenu)
        });
    }

    function descriptionJSON(description) {
        return { type: description.type, sdp: description.sdp };
    }

    async function viderSignauxEnAttente() {
        if (!connexion || !connexion.remoteDescription) return;
        const signaux = signauxEnAttente;
        signauxEnAttente = [];
        for (const candidat of signaux) await connexion.addIceCandidate(candidat);
    }

    async function traiterSignal(signal) {
        if (!connexion) creerConnexion();
        if (signal.type_signal === 'offre' && role === 'client') {
            await connexion.setRemoteDescription(signal.contenu);
            await viderSignauxEnAttente();
            const reponseLocale = await connexion.createAnswer();
            await connexion.setLocalDescription(reponseLocale);
            await envoyerSignal('reponse', descriptionJSON(connexion.localDescription));
        } else if (signal.type_signal === 'reponse' && role !== 'client') {
            await connexion.setRemoteDescription(signal.contenu);
            await viderSignauxEnAttente();
        } else if (signal.type_signal === 'candidat') {
            if (connexion.remoteDescription) await connexion.addIceCandidate(signal.contenu);
            else signauxEnAttente.push(signal.contenu);
        }
    }

    function nettoyer() {
        afficherAvertissementConversation(false);
        if (minuterie) window.clearInterval(minuterie);
        if (horlogeDuree) window.clearInterval(horlogeDuree);
        if (nettoyageDiffere) window.clearTimeout(nettoyageDiffere);
        minuterie = null;
        horlogeDuree = null;
        nettoyageDiffere = null;
        if (connexion) connexion.close();
        connexion = null;
        canalMicro = null;
        if (fluxLocal) fluxLocal.getTracks().forEach((piste) => piste.stop());
        fluxLocal = null;
        audioDistant.srcObject = null;
        appel = null;
        prochainSignalId = 0;
        signauxEnAttente = [];
        appelEntrantActif = false;
        presenceEnCours = false;
        sondageEnCours = false;
        debutAppel = null;
        duree.hidden = true;
        duree.textContent = '00:00';
        boutonMuet.hidden = true;
        boutonMuet.setAttribute('aria-pressed', 'false');
        boutonMuet.textContent = 'Couper le micro';
        microDistant.hidden = true;
        boutonRetour.hidden = true;
        boutonRetour.textContent = 'Retour à la conversation';
        nomInterlocuteur = '';
        repondre.disabled = false;
        interfaceAppel.classList.remove('appel-web--plein-ecran');
        interfaceAppel.classList.remove('appel-web--reduit');
        if (boutonAppelActif) boutonAppelActif.disabled = false;
        boutonAppelActif = null;
        interfaceAppel.hidden = true;
    }

    async function raccrocherAppel(actionServeur) {
        const appelActif = appel;
        if (!appelActif) return;
        try {
            if (actionServeur) await requete(actionServeur, { appel_id: appelActif.id });
        } catch (exception) {
            afficherErreur(exception.message);
        } finally {
            nettoyer();
        }
    }

    async function demarrerSondage() {
        if (minuterie) window.clearInterval(minuterie);
        minuterie = window.setInterval(async () => {
            if (!appel || sondageEnCours) return;
            sondageEnCours = true;
            try {
                const resultat = await requete('poll', {
                    appel_id: appel.id,
                    apres_id: prochainSignalId
                });
                for (const signal of resultat.signaux) {
                    prochainSignalId = Math.max(prochainSignalId, signal.id);
                    await traiterSignal(signal);
                }
                if (['refuse', 'termine', 'expire'].includes(resultat.statut)) {
                    const message = resultat.statut === 'refuse' ? 'L’appel a été refusé.' :
                        resultat.statut === 'expire' ? 'Le client n’a pas répondu.' : 'L’appel est terminé.';
                    window.clearInterval(minuterie);
                    minuterie = null;
                    afficher(message);
                    const appelTermineId = appel.id;
                    nettoyageDiffere = window.setTimeout(() => {
                        if (appel && appel.id === appelTermineId) nettoyer();
                    }, 2200);
                } else if (resultat.statut === 'accepte' && role !== 'client') {
                    statut.textContent = 'Appel en cours';
                    afficherAvertissementConversation(true);
                    afficherPleinEcran();
                    afficher('Appel en cours', {
                        raccrocher: true,
                        muet: true,
                        retour: role === 'conseiller'
                    });
                    demarrerDuree();
                }
            } catch (exception) {
                if (role === 'technicien' && exception.status === 403) {
                    await raccrocherAppel('terminer');
                    afficher('L’autorisation de cette mission a été révoquée.');
                    return;
                }
                afficherErreur(exception.message);
            } finally {
                sondageEnCours = false;
            }
        }, 1200);
    }

    async function demarrerAppelSortant(bouton) {
        if (appel) {
            afficherErreur('Un appel est déjà en cours.');
            return;
        }
        if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            afficher('Les appels web nécessitent une connexion HTTPS sécurisée.');
            return;
        }
        bouton.disabled = true;
        boutonAppelActif = bouton;
        nomInterlocuteur = role === 'conseiller' ? (bouton.dataset.nom || '') : '';
        try {
            afficher('Autorisation du microphone…');
            fluxLocal = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            const resultat = await requete('creer', {
                client_id: bouton.dataset.clientId,
                intervention_id: bouton.dataset.interventionId
            });
            appel = { id: resultat.appel_id };
            afficher('Appel en cours…', { raccrocher: true });
            creerConnexion();
            canalMicro = connexion.createDataChannel('etat-micro');
            recevoirEtatMicro(canalMicro);
            fluxLocal.getTracks().forEach((piste) => connexion.addTrack(piste, fluxLocal));
            const offre = await connexion.createOffer();
            await connexion.setLocalDescription(offre);
            await envoyerSignal('offre', descriptionJSON(connexion.localDescription));
            await demarrerSondage();
        } catch (exception) {
            const message = exception.name === 'NotAllowedError'
                ? 'L’accès au microphone a été refusé. Autorisez-le dans les réglages du navigateur.'
                : exception.message;
            if (appel) {
                try {
                    await requete('terminer', { appel_id: appel.id });
                } catch (erreurTerminaison) {
                    console.error('Appels web : fermeture après erreur impossible', erreurTerminaison);
                }
                nettoyer();
                afficher('L’appel n’a pas pu démarrer.');
                afficherErreur(message);
            } else {
                nettoyer();
                afficher('Appel non démarré');
                afficherErreur(message);
                nettoyageDiffere = window.setTimeout(() => {
                    if (!appel) nettoyer();
                }, 5000);
            }
            bouton.disabled = false;
        }
    }

    async function presenceClient() {
        if (appel || appelEntrantActif || presenceEnCours) return;
        presenceEnCours = true;
        try {
            const resultat = await requete('presence');
            if (resultat.appel) {
                appel = { id: resultat.appel.id };
                appelEntrantActif = true;
                afficherPleinEcran();
                afficher('Appel entrant', {
                    repondre: window.isSecureContext,
                    refuser: true
                });
                if (!window.isSecureContext) {
                    afficherErreur('Une connexion HTTPS est nécessaire pour autoriser le microphone et répondre.');
                }
                surveillerAppelEntrant();
            }
        } catch (exception) {
            console.error('Appels web : vérification des appels entrants impossible', exception);
        } finally {
            presenceEnCours = false;
        }
    }

    function surveillerAppelEntrant() {
        if (minuterie) window.clearInterval(minuterie);
        minuterie = window.setInterval(async () => {
            if (!appel || !appelEntrantActif || sondageEnCours) return;
            sondageEnCours = true;
            try {
                const resultat = await requete('poll', { appel_id: appel.id, apres_id: 0 });
                if (resultat.statut !== 'sonnerie') {
                    appelEntrantActif = false;
                    window.clearInterval(minuterie);
                    minuterie = null;
                    if (resultat.statut === 'accepte') return;
                    afficher(resultat.statut === 'expire'
                        ? 'Le délai de réponse est dépassé.'
                        : 'Cet appel a été annulé.');
                    const appelTermineId = appel.id;
                    nettoyageDiffere = window.setTimeout(() => {
                        if (appel && appel.id === appelTermineId) nettoyer();
                    }, 2200);
                }
            } catch (exception) {
                if (role === 'technicien' && exception.status === 403) {
                    await raccrocherAppel('terminer');
                    afficher('L’autorisation de cette mission a été révoquée.');
                    return;
                }
                afficherErreur(exception.message);
            } finally {
                sondageEnCours = false;
            }
        }, 1500);
    }

    repondre.addEventListener('click', async () => {
        if (!appel) return;
        if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            afficherErreur('Les appels web nécessitent une connexion HTTPS sécurisée.');
            return;
        }
        repondre.disabled = true;
        try {
            fluxLocal = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            const resultat = await requete('repondre', { appel_id: appel.id });
            if (!resultat.ok) throw new Error('L’appel n’est plus disponible.');
            appelEntrantActif = false;
            afficherPleinEcran();
            afficher('Connexion en cours…', { raccrocher: true, muet: true, retour: role === 'client' });
            demarrerDuree();
            creerConnexion();
            fluxLocal.getTracks().forEach((piste) => connexion.addTrack(piste, fluxLocal));
            actualiserMicro();
            await demarrerSondage();
        } catch (exception) {
            const message = exception.name === 'NotAllowedError'
                ? 'L’accès au microphone a été refusé. Autorisez-le dans les réglages du navigateur.'
                : exception.message;
            repondre.disabled = false;
            if (fluxLocal) fluxLocal.getTracks().forEach((piste) => piste.stop());
            fluxLocal = null;
            if (!appelEntrantActif && appel) {
                try {
                    await requete('terminer', { appel_id: appel.id });
                } catch (erreurTerminaison) {
                    console.error('Appels web : fermeture après erreur impossible', erreurTerminaison);
                }
                nettoyer();
                afficher('La connexion audio a échoué.');
            }
            afficherErreur(message);
        }
    });

    refuser.addEventListener('click', () => raccrocherAppel('refuser'));
    raccrocher.addEventListener('click', () => raccrocherAppel('terminer'));
    boutonRetour.addEventListener('click', basculerAffichageAppel);
    boutonMuet.addEventListener('click', basculerMicro);

    document.querySelectorAll('[data-webcall-start]').forEach((bouton) => {
        bouton.addEventListener('click', () => demarrerAppelSortant(bouton));
    });

    if (role === 'client') {
        presenceClient();
        window.setInterval(presenceClient, 1000);
        document.addEventListener('visibilitychange', presenceClient);
        window.addEventListener('focus', presenceClient);
    }
})();
