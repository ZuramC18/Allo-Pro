(function () {
    const statut = document.getElementById('statut-conversation');
    const fil = document.getElementById('fil-corps');
    if (!statut || !fil || fil.dataset.conversationOuverte !== '1') return;

    const url = new URL('api-statut-conversation.php', new URL('../../public/', window.location.href));
    let attenteObservee = !statut.hidden;

    async function actualiser() {
        try {
            const response = await fetch(url, { cache: 'no-store', credentials: 'same-origin' });
            if (!response.ok) throw new Error('Impossible de vérifier le statut.');
            const resultat = await response.json();
            if (!resultat.ouverte) {
                window.location.reload();
                return;
            }

            statut.classList.remove('fil__attente--erreur');
            if (resultat.en_attente) {
                attenteObservee = true;
                statut.hidden = false;
                statut.classList.remove('fil__attente--attribuee');
                statut.textContent = 'Votre conversation est en attente d’un conseiller. Vous pouvez déjà écrire votre message.';
            } else if (attenteObservee) {
                statut.hidden = false;
                statut.classList.add('fil__attente--attribuee');
                statut.textContent = 'Un conseiller a été attribué à votre conversation.';
            } else {
                statut.hidden = true;
            }
        } catch (erreur) {
            console.error('État de la conversation indisponible.', erreur);
            statut.hidden = false;
            statut.classList.remove('fil__attente--attribuee');
            statut.classList.add('fil__attente--erreur');
            statut.textContent = 'Impossible de vérifier l’état de votre conversation. Le contrôle sera réessayé.';
        }
    }

    window.setInterval(actualiser, 15000);
})();
