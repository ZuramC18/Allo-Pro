(function () {
    'use strict';

    const bouton = document.querySelector('[data-webcall-start][data-intervention-id]');
    if (!bouton) return;

    const csrf = bouton.dataset.csrf || '';
    const api = new URL('../api-appels-web.php', document.currentScript.src).href;
    let enCours = false;

    async function verifierAutorisation() {
        if (enCours) return;
        enCours = true;
        const donnees = new FormData();
        donnees.set('action', 'autorisation_mission');
        donnees.set('acteur_role', 'technicien');
        donnees.set('intervention_id', bouton.dataset.interventionId);
        donnees.set('csrf', csrf);

        try {
            const reponse = await fetch(api, {
                method: 'POST',
                body: donnees,
                credentials: 'same-origin',
                cache: 'no-store'
            });
            const resultat = await reponse.json();
            if (!reponse.ok || resultat.erreur) {
                bouton.hidden = true;
                throw new Error(resultat.erreur || 'Vérification de l’autorisation impossible.');
            }
            bouton.hidden = !resultat.autorise;
        } catch (exception) {
            bouton.hidden = true;
            console.error('Autorisation d’appel web technicien :', exception);
        } finally {
            enCours = false;
        }
    }

    verifierAutorisation();
    window.setInterval(verifierAutorisation, 10000);
})();
