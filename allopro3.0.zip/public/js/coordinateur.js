(function() {
    const API = '../../public/api-coordination.php';
    const liste = document.getElementById('coord-liste');
    const filtres = document.querySelectorAll('.coord-filtre');
    const ongletsVue = document.querySelectorAll('.coord-vue');
    const detail = document.getElementById('coord-detail');
    const accueilDetail = detail.innerHTML;
    let filtreActif = 'toutes';
    let vueActuelle = 'clients';
    let conseillerSelectionne = null;
    let requeteClientsConseiller = 0;
    let clientCible = null;
    let clientActuelConv = null;
    let nomActuelConv = null;

    function echapper(s) {
        const d = document.createElement('div');
        d.textContent = s || '';
        return d.innerHTML;
    }

    function tempsRelatifConversation(dateTexte) {
        if (!dateTexte) return '';
        const date = new Date(String(dateTexte).replace(' ', 'T'));
        if (Number.isNaN(date.getTime())) return '';

        let secondes = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
        if (secondes < 60) return 'À l’instant';

        const unites = [
            ['an', 31536000],
            ['mois', 2592000],
            ['sem', 604800],
            ['j', 86400],
            ['h', 3600],
            ['min', 60]
        ];
        const parties = [];
        for (const [libelle, duree] of unites) {
            const quantite = Math.floor(secondes / duree);
            if (quantite > 0) {
                parties.push(`${quantite} ${libelle}`);
                secondes %= duree;
                if (parties.length === 2) break;
            }
        }
        return `Il y a ${parties.join(' ')}`;
    }

    function jourConversation(dateTexte) {
        const texte = String(dateTexte || '');
        const morceaux = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/.exec(texte);
        const date = morceaux
            ? new Date(Number(morceaux[1]), Number(morceaux[2]) - 1, Number(morceaux[3]), Number(morceaux[4]), Number(morceaux[5]), Number(morceaux[6] || 0))
            : new Date(texte);
        if (Number.isNaN(date.getTime())) return null;
        const cle = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        const aujourdhui = new Date();
        const cleAujourdhui = `${aujourdhui.getFullYear()}-${String(aujourdhui.getMonth() + 1).padStart(2, '0')}-${String(aujourdhui.getDate()).padStart(2, '0')}`;
        const hier = new Date(aujourdhui.getFullYear(), aujourdhui.getMonth(), aujourdhui.getDate() - 1);
        const cleHier = `${hier.getFullYear()}-${String(hier.getMonth() + 1).padStart(2, '0')}-${String(hier.getDate()).padStart(2, '0')}`;
        const options = { weekday: 'long', day: 'numeric', month: 'long' };
        if (date.getFullYear() !== aujourdhui.getFullYear()) options.year = 'numeric';
        let libelle = new Intl.DateTimeFormat('fr-FR', options).format(date);
        libelle = libelle.charAt(0).toLocaleUpperCase('fr-FR') + libelle.slice(1);
        if (cle === cleAujourdhui) libelle = 'Aujourd’hui';
        else if (cle === cleHier) libelle = 'Hier';
        return { cle, libelle, heure: date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) };
    }

    async function chargerCompteurs() {
        const res = await fetch(`${API}?action=compteurs`);
        const data = await res.json();
        document.getElementById('badge-non_attribuees').textContent = data.non_attribuees;
        document.getElementById('badge-attribuees').textContent = data.attribuees;
        document.getElementById('badge-toutes').textContent = data.toutes;
    }

    async function chargerListe() {
        if (vueActuelle !== 'clients') return;
        liste.innerHTML = '<p class="coord-vide">Chargement…</p>';
        const res = await fetch(`${API}?action=liste&filtre=${filtreActif}`);
        const conversations = await res.json();
        if (vueActuelle !== 'clients') return;

        if (conversations.length === 0) { liste.innerHTML = '<p class="coord-vide">Aucune conversation ici.</p>'; return; }

        liste.innerHTML = conversations.map(c => {
            const nonAttribuee = !c.conseiller_assigne_id;
            const date = tempsRelatifConversation(c.derniere_date);
            const nom = c.nom_complet || c.nom || 'Client';
            return `
                <div class="coord-item" data-id="${c.id}">
                    <div class="coord-item__avatar ${nonAttribuee ? 'coord-item__avatar--non-attribuee' : ''}">${echapper(nom).charAt(0).toUpperCase()}</div>
                    <div class="coord-item__corps">
                        <div class="coord-item__haut"><span class="coord-item__nom">${echapper(nom)}</span><span class="coord-item__date">${date}</span></div>
                        <div class="coord-item__apercu">${echapper(c.dernier_message) || 'Aucun message'}</div>
                        <div class="coord-item__statut ${nonAttribuee ? 'coord-item__statut--non-attribuee' : 'coord-item__statut--attribuee'}">
                            ${nonAttribuee ? '⚠️ Non attribuée' : '👤 ' + echapper(c.conseiller_nom)}
                        </div>
                    </div>
                    ${c.non_lus > 0 ? `<span class="coord-item__non-lus">${c.non_lus}</span>` : ''}
                </div>`;
        }).join('');
    }

    async function chargerConseillersVue() {
        liste.innerHTML = '<p class="coord-vide">Chargement des conseillers…</p>';
        try {
            const res = await fetch(`${API}?action=conseillers`);
            if (!res.ok) throw new Error('Chargement impossible');
            const conseillers = await res.json();
            if (vueActuelle !== 'conseillers') return;
            if (!Array.isArray(conseillers) || conseillers.length === 0) {
                liste.innerHTML = '<p class="coord-vide">Aucun conseiller actif.</p>';
                return;
            }
            liste.innerHTML = conseillers.map(c => {
                const presence = ['online', 'pause'].includes(c.presence_status) ? c.presence_status : 'offline';
                const libellesPresence = { online: 'En ligne', pause: 'En pause', offline: 'Hors ligne' };
                return `
                    <button type="button" class="coord-item coord-conseiller-ligne ${Number(conseillerSelectionne) === Number(c.id) ? 'coord-item--actif' : ''}" data-conseiller-id="${Number(c.id)}">
                        <span class="coord-item__avatar">${echapper(c.nom).charAt(0).toUpperCase()}</span>
                        <span class="coord-item__corps">
                            <span class="coord-item__haut"><span class="coord-item__nom">${echapper(c.nom)}</span><span class="coord-item__date">${echapper(c.matricule || '')}</span></span>
                            <span class="coord-conseiller-presence coord-conseiller-presence--${presence}" aria-label="Statut : ${libellesPresence[presence]}"><span class="coord-conseiller-presence__point" aria-hidden="true"></span>${libellesPresence[presence]}</span>
                            <span class="coord-item__apercu">${Number(c.nb_clients) || 0} client(s) attribué(s)</span>
                        </span>
                        <span class="coord-conseiller-charge">${Number(c.nb_clients) || 0}</span>
                    </button>`;
            }).join('');
        } catch (e) {
            if (vueActuelle === 'conseillers') liste.innerHTML = '<p class="coord-vide">Impossible de charger les conseillers.</p>';
        }
    }

    async function afficherClientsConseiller(conseiller) {
        conseillerSelectionne = Number(conseiller.id);
        const requete = ++requeteClientsConseiller;
        liste.querySelectorAll('[data-conseiller-id]').forEach(item => {
            item.classList.toggle('coord-item--actif', Number(item.dataset.conseillerId) === conseillerSelectionne);
        });
        detail.innerHTML = '<p class="coord-vide coord-detail-chargement">Chargement des clients attribués…</p>';

        try {
            const res = await fetch(`${API}?action=clients_conseiller&conseiller_id=${conseillerSelectionne}`);
            if (!res.ok) throw new Error('Chargement impossible');
            const clients = await res.json();
            if (requete !== requeteClientsConseiller || vueActuelle !== 'conseillers') return;
            if (!Array.isArray(clients)) throw new Error('Réponse invalide');

            const lignes = clients.map(c => {
                const aConversation = Number(c.a_conversation) === 1;
                const date = tempsRelatifConversation(c.derniere_date) || 'Aucun échange';
                const nom = c.nom_complet || c.nom || 'Client';
                return `
                    <button type="button" class="coord-client-ligne" data-client-id="${Number(c.id)}" ${aConversation ? '' : 'disabled'}>
                        <span class="coord-client-ligne__avatar">${echapper(nom).charAt(0).toUpperCase()}</span>
                        <span class="coord-client-ligne__identite"><strong>${echapper(nom)}</strong><small>${echapper(c.telephone || 'Téléphone non renseigné')}</small></span>
                        <span class="coord-client-ligne__dernier"><span>${echapper(c.dernier_message || 'Aucun message')}</span><small>${date}</small></span>
                        ${Number(c.non_lus) > 0 ? `<span class="coord-item__non-lus coord-client-ligne__non-lus">${Number(c.non_lus)}</span>` : ''}
                        <span class="coord-client-ligne__action">${aConversation ? 'Ouvrir le fil' : 'Sans message'}</span>
                    </button>`;
            }).join('');

            detail.innerHTML = `
                <section class="coord-clients-attribues" aria-labelledby="coord-clients-titre">
                    <header class="coord-clients-attribues__entete">
                        <div><span class="coord-surtitre">PORTFOLIO CONSEILLER</span><h2 id="coord-clients-titre">${echapper(conseiller.nom)}</h2><p>${echapper(conseiller.matricule || '')} · Clients attribués</p></div>
                        <span class="coord-clients-attribues__total">${clients.length} client${clients.length === 1 ? '' : 's'}</span>
                    </header>
                    <div class="coord-clients-attribues__liste">${lignes || '<p class="coord-vide">Aucun client attribué à ce conseiller.</p>'}</div>
                </section>`;
        } catch (e) {
            if (requete === requeteClientsConseiller && vueActuelle === 'conseillers') {
                detail.innerHTML = '<p class="coord-vide">Impossible de charger les clients attribués.</p>';
            }
        }
    }

    function changerVue(vue) {
        vueActuelle = vue;
        ongletsVue.forEach(onglet => {
            const actif = onglet.dataset.vue === vue;
            onglet.classList.toggle('coord-vue--actif', actif);
            onglet.setAttribute('aria-selected', actif ? 'true' : 'false');
        });
        document.querySelector('.coord-sidebar__filtres').hidden = vue !== 'clients';

        if (vue === 'conseillers') {
            conseillerSelectionne = null;
            requeteClientsConseiller++;
            detail.innerHTML = '<div class="coord-accueil coord-accueil--compact"><h2>Clients par conseiller</h2><p>Sélectionnez un conseiller pour afficher tous les clients qui lui sont attribués.</p></div>';
            chargerConseillersVue();
        } else {
            detail.innerHTML = accueilDetail;
            chargerListe();
        }
    }

    ongletsVue.forEach(onglet => onglet.addEventListener('click', () => changerVue(onglet.dataset.vue)));

    filtres.forEach(btn => btn.addEventListener('click', () => {
        filtres.forEach(b => b.classList.remove('coord-filtre--actif'));
        btn.classList.add('coord-filtre--actif');
        filtreActif = btn.dataset.filtre;
        chargerListe();
    }));

    liste.addEventListener('click', (e) => {
        const conseiller = e.target.closest('[data-conseiller-id]');
        if (conseiller && vueActuelle === 'conseillers') {
            const nom = conseiller.querySelector('.coord-item__nom')?.textContent || '';
            const matricule = conseiller.querySelector('.coord-item__date')?.textContent || '';
            afficherClientsConseiller({ id: conseiller.dataset.conseillerId, nom, matricule });
            return;
        }
        const item = e.target.closest('.coord-item');
        if (item) ouvrirConversationOuAttribution(parseInt(item.dataset.id, 10));
    });

    detail.addEventListener('click', (e) => {
        const client = e.target.closest('[data-client-id]');
        if (client && !client.disabled) ouvrirConversationOuAttribution(parseInt(client.dataset.clientId, 10));
    });

    // ===== Attribution =====
    const modaleAttrib = document.getElementById('modale-attribution');
    const attribListe = document.getElementById('attrib-liste');
    const attribRecherche = document.getElementById('attrib-recherche');
    const attribNomClient = document.getElementById('attrib-nom-client');

    async function ouvrirAttribution(clientId, nomClient) {
        clientCible = clientId;
        attribNomClient.textContent = `pour ${nomClient}`;
        attribRecherche.value = '';
        await chargerConseillers('');
        modaleAttrib.classList.add('coord-modale-fond--visible');
    }

    async function chargerConseillers(terme) {
        const res = await fetch(`${API}?action=conseillers&q=${encodeURIComponent(terme)}`);
        const conseillers = await res.json();
        attribListe.innerHTML = conseillers.map(c => `
            <div class="coord-conseiller-item" data-id="${c.id}">
                <div><div class="coord-conseiller-item__nom">${echapper(c.nom)}</div><div class="coord-conseiller-item__matricule">${echapper(c.matricule)}</div></div>
                <span class="coord-conseiller-item__charge">${c.nb_clients} client(s)</span>
            </div>`).join('') || '<p class="coord-vide">Aucun conseiller trouvé.</p>';
    }

    let debounce;
    attribRecherche.addEventListener('input', () => {
        clearTimeout(debounce);
        debounce = setTimeout(() => chargerConseillers(attribRecherche.value.trim()), 250);
    });

    attribListe.addEventListener('click', async (e) => {
        const item = e.target.closest('.coord-conseiller-item');
        if (!item || !clientCible) return;
        await fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `action=assigner&client_id=${clientCible}&conseiller_id=${item.dataset.id}` });
        fermerModales();
        chargerListe();
        chargerCompteurs();
    });

    // ===== Conversation =====
    const modaleConv = document.getElementById('modale-conversation');
    const convNomClient = document.getElementById('conv-nom-client');
    const convConseillerActuel = document.getElementById('conv-conseiller-actuel');
    const convFil = document.getElementById('conv-fil');
    const themeToggle = document.getElementById('coord-theme-toggle');

    function appliquerTheme(theme, enregistrer = true) {
        const sombre = theme === 'dark';
        if (sombre) document.documentElement.setAttribute('data-theme', 'dark');
        else document.documentElement.removeAttribute('data-theme');
        themeToggle.setAttribute('aria-checked', String(sombre));
        themeToggle.setAttribute('aria-label', sombre ? 'Passer en mode clair' : 'Passer en mode sombre');
        themeToggle.title = sombre ? 'Passer en mode clair' : 'Passer en mode sombre';
        if (enregistrer) {
            try { localStorage.setItem('allopro_theme', sombre ? 'dark' : 'light'); } catch (e) {}
        }
    }

    if (themeToggle) {
        appliquerTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light', false);
        themeToggle.addEventListener('click', () => {
            appliquerTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
        });
        window.addEventListener('storage', event => {
            if (event.key === 'allopro_theme' && ['dark', 'light'].includes(event.newValue)) {
                appliquerTheme(event.newValue, false);
            }
        });
    }

    async function ouvrirConversationOuAttribution(clientId) {
        const res = await fetch(`${API}?action=conversation&client_id=${clientId}`);
        const data = await res.json();
        if (data.erreur) return;

        if (!data.client.conseiller_assigne_id) {
            ouvrirAttribution(clientId, data.client.nom_complet || data.client.nom);
            return;
        }

        clientActuelConv = clientId;
        nomActuelConv = data.client.nom_complet || data.client.nom;
        convNomClient.textContent = nomActuelConv;
        convConseillerActuel.textContent = `Attribuée à ${data.client.conseiller_nom} (${data.client.conseiller_matricule})`;
        let jourPrecedent = null;
        convFil.innerHTML = data.messages.map(m => {
            const jour = jourConversation(m.date_creation);
            const separateur = jour && jour.cle !== jourPrecedent
                ? `<div class="coord-fil__separateur-jour"><span>${echapper(jour.libelle)}</span></div>`
                : '';
            if (jour) jourPrecedent = jour.cle;
            return `${separateur}
                <div class="coord-bulle ${m.expediteur_type === 'client' ? 'coord-bulle--client' : 'coord-bulle--conseiller'}">
                    <div class="coord-bulle__meta">${echapper(m.nom_expediteur || m.expediteur_type)} · ${jour ? echapper(jour.heure) : ''}</div>
                    ${echapper(m.contenu).replace(/\n/g, '<br>')}
                </div>`;
        }).join('') || '<p class="coord-vide">Aucun message.</p>';

        modaleConv.classList.add('coord-modale-fond--visible');
        convFil.scrollTop = convFil.scrollHeight;
    }

    document.getElementById('btn-changer-conseiller').addEventListener('click', () => {
        fermerModales();
        ouvrirAttribution(clientActuelConv, nomActuelConv);
    });

    function fermerModales() {
        modaleAttrib.classList.remove('coord-modale-fond--visible');
        modaleConv.classList.remove('coord-modale-fond--visible');
    }

    document.querySelectorAll('[data-fermer]').forEach(b => b.addEventListener('click', fermerModales));
    document.querySelectorAll('.coord-modale-fond').forEach(fond => fond.addEventListener('click', (e) => { if (e.target === fond) fermerModales(); }));

    chargerCompteurs();
    chargerListe();
    window.setInterval(() => {
        if (vueActuelle === 'conseillers') chargerConseillersVue();
    }, 5 * 60 * 1000);
})();