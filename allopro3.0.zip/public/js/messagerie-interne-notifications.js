(function () {
    'use strict';

    const script = document.currentScript;
    if (!script) return;
    const api = new URL('../api-messagerie-interne.php', script.src).href;
    const badges = document.querySelectorAll('[data-mi-badge]');
    if (!badges.length) return;

    let enCours = false;

    function afficherTotal(total) {
        const texte = total > 99 ? '99+' : String(total);
        badges.forEach((badge) => {
            badge.dataset.count = String(total);
            badge.textContent = texte;
            badge.hidden = total === 0;
            badge.setAttribute('aria-label', total + (total > 1 ? ' messages non lus' : ' message non lu'));
            badge.setAttribute('role', 'status');
        });
    }

    async function actualiser() {
        if (enCours || document.hidden) return;
        enCours = true;
        try {
            const reponse = await fetch(api + '?action=conversations', {
                credentials: 'same-origin',
                cache: 'no-store'
            });
            if (!reponse.ok) return;

            const conversations = await reponse.json();
            if (!Array.isArray(conversations)) return;

            const activeId = Number(window.MI_CONVERSATION_ACTIVE) || 0;
            const total = conversations.reduce((somme, conversation) => {
                if (activeId && Number(conversation.conversation_id) === activeId) return somme;
                return somme + (Number(conversation.non_lus) || 0);
            }, 0);
            afficherTotal(total);
        } catch (e) {
            // Le badge conserve son dernier état si le réseau est momentanément indisponible.
        } finally {
            enCours = false;
        }
    }

    let minuteur;
    function planifier() {
        clearTimeout(minuteur);
        minuteur = setTimeout(async () => {
            await actualiser();
            planifier();
        }, document.hidden ? 20000 : 7000);
    }

    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) actualiser();
        planifier();
    });
    window.addEventListener('focus', actualiser);
    actualiser();
    planifier();
})();