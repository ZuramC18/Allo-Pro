(function () {
    const panneau = document.querySelector('.sidebar__presence');
    const select = document.getElementById('statut-presence-conseiller');
    const message = document.getElementById('presence-message');
    const point = document.querySelector('.sidebar__presence-point');
    const boutonEnLigne = panneau?.querySelector('[data-presence-en-ligne]');
    if (!panneau || !select || !message || !point) return;

    const api = '../../public/api-presence-conseiller.php';
    const csrf = panneau.dataset.csrf || '';
    let statutCourant = select.value;

    function afficherStatut(statut) {
        statutCourant = statut;
        select.value = statut;
        panneau.dataset.statut = statut;
        point.title = select.options[select.selectedIndex]?.text || '';
        if (boutonEnLigne) {
            boutonEnLigne.disabled = statut === 'online';
            const libelleBouton = boutonEnLigne.querySelector('[data-presence-button-label]');
            if (libelleBouton) {
                libelleBouton.textContent = statut === 'online' ? 'Vous êtes en ligne' : 'Se mettre en ligne';
            }
        }
    }

    function afficherErreur(texte) {
        message.textContent = texte;
        message.hidden = !texte;
        panneau.classList.toggle('sidebar__presence--erreur', Boolean(texte));
    }

    async function requete(url, options) {
        const reponse = await fetch(url, { cache: 'no-store', credentials: 'same-origin', ...options });
        const resultat = await reponse.json();
        if (!reponse.ok) throw new Error(resultat.erreur || 'Impossible d’enregistrer le statut.');
        if (!['online', 'pause', 'offline'].includes(resultat.presence_status)) {
            throw new Error('Réponse de statut invalide.');
        }
        return resultat.presence_status;
    }

    async function envoyer(action, statut) {
        const corps = new URLSearchParams({ csrf, action });
        if (statut) corps.set('status', statut);
        const suivant = await requete(api, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
            body: corps,
        });
        afficherStatut(suivant);
        afficherErreur('');
    }

    select.addEventListener('change', async () => {
        const demande = select.value;
        select.disabled = true;
        afficherErreur('');
        try {
            await envoyer('status', demande);
        } catch (erreur) {
            afficherStatut(statutCourant);
            afficherErreur(erreur.message);
        } finally {
            select.disabled = false;
        }
    });

    boutonEnLigne?.addEventListener('click', async () => {
        boutonEnLigne.disabled = true;
        afficherErreur('');
        try {
            await envoyer('status', 'online');
        } catch (erreur) {
            afficherStatut(statutCourant);
            afficherErreur(erreur.message);
        }
    });

    async function actualiserPresence() {
        if (statutCourant !== 'online' && statutCourant !== 'pause') return;
        try {
            await envoyer('heartbeat');
        } catch (erreur) {
            afficherErreur('Présence non actualisée. Vérifiez votre connexion.');
        }
    }

    async function initialiser() {
        try {
            afficherStatut(await requete(api, { method: 'GET' }));
            await actualiserPresence();
        } catch (erreur) {
            afficherErreur('Impossible de charger votre statut.');
        }
    }

    initialiser();
    window.setInterval(actualiserPresence, 60 * 1000);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') actualiserPresence();
    });
})();
