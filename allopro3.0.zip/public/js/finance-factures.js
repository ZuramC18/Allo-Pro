document.querySelectorAll('.factures-table__ligne[data-href]').forEach((ligne) => {
    const ouvrir = () => {
        window.location.href = ligne.dataset.href;
    };

    ligne.addEventListener('click', (event) => {
        if (event.target.closest('a, button, input, select, textarea')) return;
        ouvrir();
    });

    ligne.addEventListener('keydown', (event) => {
        if (event.target !== ligne || (event.key !== 'Enter' && event.key !== ' ')) return;
        event.preventDefault();
        ouvrir();
    });
});
