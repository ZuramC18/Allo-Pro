(function () {
    'use strict';

    if (window.__ADMIN_NAVIGATION_DYNAMIQUE__) return;
    window.__ADMIN_NAVIGATION_DYNAMIQUE__ = true;

    const shell = document.querySelector('.admin-app, .app');
    const sidebar = document.querySelector('.admin-sidebar');
    if (!shell || !sidebar) return;

    const selecteurContenu = '.admin-contenu, .mc-contenu, .contenu';
    const stylesGlobaux = /\/public\/css\/(?:admin|theme-admin|admin-sidebar-groups|admin-theme-coherence)\.css(?:\?|$)/;
    document.querySelectorAll('link[rel="stylesheet"], style').forEach((style) => {
        if (style.closest('.admin-sidebar')) return;
        if (style.tagName === 'LINK' && stylesGlobaux.test(style.href)) return;
        style.dataset.adminPageStyle = 'true';
        style.dataset.adminPageLoaded = 'true';
    });
    [...document.body.children].forEach((element) => {
        if (element !== shell && element.tagName !== 'SCRIPT') {
            element.dataset.adminPageExtra = 'true';
        }
    });
    let requeteEnCours = null;
    let urlContenuActuel = new URL(window.location.href);
    let chargeurPage = null;
    const indicateurChargement = document.createElement('div');
    indicateurChargement.className = 'admin-navigation-progress';
    indicateurChargement.setAttribute('role', 'progressbar');
    indicateurChargement.setAttribute('aria-label', 'Chargement de la page');
    indicateurChargement.setAttribute('aria-valuetext', 'Chargement');
    document.body.appendChild(indicateurChargement);

    function estRouteAdmin(url) {
        return url.origin === window.location.origin
            && /\/admin(?:\/|$)/.test(url.pathname);
    }

    function cheminNormalise(url) {
        return url.pathname.replace(/\.php$/, '').replace(/\/$/, '');
    }

    function urlAdmin(url) {
        const canonique = new URL(url.href);
        canonique.pathname = cheminNormalise(canonique) || '/admin';
        return canonique;
    }

    function estChangementConversation(url) {
        return /\/messagerie$/.test(url.pathname)
            && cheminNormalise(url) === cheminNormalise(urlContenuActuel)
            && url.searchParams.get('client_id') !== urlContenuActuel.searchParams.get('client_id');
    }

    function retrouverContenu(conteneur) {
        return conteneur.querySelector(selecteurContenu);
    }

    function attendreAffichageStyles() {
        return new Promise((resolve) => {
            requestAnimationFrame(() => requestAnimationFrame(resolve));
        });
    }

    function attendreDureeMinimum(debut, duree, signal) {
        const reste = duree - (performance.now() - debut);
        if (reste <= 0) return Promise.resolve();
        if (signal.aborted) return Promise.reject(new DOMException('Navigation annulée', 'AbortError'));

        return new Promise((resolve, reject) => {
            const minuterie = setTimeout(terminer, reste);
            function terminer() {
                signal.removeEventListener('abort', annuler);
                resolve();
            }
            function annuler() {
                clearTimeout(minuterie);
                signal.removeEventListener('abort', annuler);
                reject(new DOMException('Navigation annulée', 'AbortError'));
            }
            signal.addEventListener('abort', annuler, { once: true });
        });
    }

    function afficherChargeur(contenu) {
        if (!chargeurPage) {
            chargeurPage = document.createElement('div');
            chargeurPage.className = 'admin-page-loader';
            chargeurPage.setAttribute('role', 'status');
            chargeurPage.setAttribute('aria-live', 'polite');
            chargeurPage.innerHTML = '<span class="admin-page-loader__message"><span class="admin-page-loader__spinner" aria-hidden="true"></span>Chargement de la page…</span>'
                + '<span class="admin-page-loader__skeleton" aria-hidden="true"><span class="admin-page-loader__line admin-page-loader__line--title"></span>'
                + '<span class="admin-page-loader__line admin-page-loader__line--subtitle"></span>'
                + '<span class="admin-page-loader__cards"><span></span><span></span><span></span></span>'
                + '<span class="admin-page-loader__panel"></span><span class="admin-page-loader__panel admin-page-loader__panel--short"></span></span>';
        }
        contenu.scrollTop = 0;
        contenu.setAttribute('aria-busy', 'true');
        if (chargeurPage.parentElement !== contenu) contenu.prepend(chargeurPage);
    }

    async function chargerStyles(documentCible, urlBase, signal) {
        const styles = [...documentCible.querySelectorAll('link[rel="stylesheet"], style')]
            .filter((element) => {
                if (element.tagName === 'STYLE') return true;
                const href = new URL(element.getAttribute('href'), urlBase).href;
                return !stylesGlobaux.test(href);
            });
        const stylesActifs = [...document.querySelectorAll('[data-admin-page-style]')];
        const stylesParCle = new Map();
        const nouveauxStyles = [];

        try {
            const stylesPrets = await Promise.all(styles.map(async (styleSource) => {
                if (signal.aborted) throw new DOMException('Navigation annulée', 'AbortError');
                if (styleSource.tagName === 'LINK') {
                    const href = new URL(styleSource.getAttribute('href'), urlBase).href;
                    if (stylesParCle.has(href)) return stylesParCle.get(href);
                    let style = stylesActifs.find((actif) => actif.tagName === 'LINK'
                        && actif.href === href && actif.dataset.adminPageLoaded === 'true');
                    if (!style) {
                        style = document.createElement('link');
                        style.rel = 'stylesheet';
                        style.href = href;
                        style.media = 'not all';
                        style.dataset.adminPageStyle = 'true';
                        nouveauxStyles.push(style);
                        const chargement = new Promise((resolve, reject) => {
                            style.onload = () => {
                                style.dataset.adminPageLoaded = 'true';
                                resolve();
                            };
                            style.onerror = () => reject(new Error('Impossible de charger la feuille de style admin : ' + href));
                        });
                        const stylePret = chargement.then(() => {
                            style.dataset.adminPageMedia = styleSource.getAttribute('media') || 'all';
                            return style;
                        });
                        stylesParCle.set(href, stylePret);
                        document.head.appendChild(style);
                        return stylePret;
                    }
                    style.dataset.adminPageMedia = styleSource.getAttribute('media') || 'all';
                    stylesParCle.set(href, style);
                    return style;
                } else {
                    const contenu = styleSource.textContent || '';
                    const cle = 'inline:' + contenu;
                    if (stylesParCle.has(cle)) return stylesParCle.get(cle);
                    let style = stylesActifs.find((actif) => actif.tagName === 'STYLE' && actif.textContent === contenu);
                    if (!style) {
                        style = document.createElement('style');
                        style.textContent = contenu;
                        style.media = 'not all';
                        style.dataset.adminPageStyle = 'true';
                        style.dataset.adminPageLoaded = 'true';
                        nouveauxStyles.push(style);
                        document.head.appendChild(style);
                    }
                    style.dataset.adminPageMedia = styleSource.getAttribute('media') || 'all';
                    stylesParCle.set(cle, style);
                    return style;
                }
            }));
            if (signal.aborted) throw new DOMException('Navigation annulée', 'AbortError');
            return { stylesPrets, stylesActifs, nouveauxStyles };
        } catch (erreur) {
            nouveauxStyles.forEach((style) => style.remove());
            throw erreur;
        }
    }

    function ordonnerStylesGlobaux() {
        const liens = [...document.querySelectorAll('link[rel="stylesheet"]')]
            .filter((lien) => stylesGlobaux.test(lien.href));
        const parNom = new Map();
        liens.forEach((lien) => {
            const nom = new URL(lien.href).pathname.split('/').pop();
            if (!parNom.has(nom) || lien.hasAttribute('data-admin-theme-coherence')) {
                const precedent = parNom.get(nom);
                if (precedent && precedent !== lien) precedent.remove();
                parNom.set(nom, lien);
            } else {
                lien.remove();
            }
        });

        const adminBase = parNom.get('admin.css');
        const premiereFeuille = document.head.querySelector('link[rel="stylesheet"], style');
        if (adminBase && premiereFeuille) document.head.insertBefore(adminBase, premiereFeuille);

        ['theme-admin.css', 'admin-sidebar-groups.css', 'admin-theme-coherence.css']
            .forEach((nom) => {
                const lien = parNom.get(nom);
                if (lien) document.head.appendChild(lien);
            });
    }

    function actualiserLienActif(url) {
        sidebar.querySelectorAll('.admin-sidebar__lien').forEach((lien) => {
            const actif = cheminNormalise(new URL(lien.href, window.location.href)) === cheminNormalise(url);
            lien.classList.toggle('admin-sidebar__lien--actif', actif);
            if (actif) lien.setAttribute('aria-current', 'page');
            else lien.removeAttribute('aria-current');
        });

        const lienActif = [...sidebar.querySelectorAll('.admin-sidebar__lien')]
            .find((lien) => lien.classList.contains('admin-sidebar__lien--actif'));
        sidebar.querySelectorAll('.admin-sidebar__sous-section').forEach((groupe) => {
            groupe.open = Boolean(lienActif && groupe.contains(lienActif));
        });
        sidebar.querySelectorAll('.admin-sidebar__section').forEach((section) => {
            if (section.contains(lienActif)) section.open = true;
        });
    }

    async function naviguer(url, ajouterHistorique) {
        if (!estRouteAdmin(url)) {
            window.location.assign(url.href);
            return;
        }
        url = urlAdmin(url);
        if (url.href === urlAdmin(urlContenuActuel).href) return;

        const contenuAvantNavigation = retrouverContenu(shell);
        const scrollAvantNavigation = contenuAvantNavigation ? contenuAvantNavigation.scrollTop : window.scrollY;
        const afficherChargement = !estChangementConversation(url);
        if (requeteEnCours) requeteEnCours.abort();
        chargeurPage?.remove();
        contenuAvantNavigation?.removeAttribute('aria-busy');
        shell.removeAttribute('aria-busy');
        shell.classList.remove('admin-navigation-en-cours');
        indicateurChargement.classList.remove('is-visible');
        requeteEnCours = new AbortController();
        const controleur = requeteEnCours;
        if (afficherChargement) {
            shell.setAttribute('aria-busy', 'true');
            shell.classList.add('admin-navigation-en-cours');
            indicateurChargement.classList.add('is-visible');
        }
        const debutChargement = performance.now();
        if (afficherChargement && contenuAvantNavigation) afficherChargeur(contenuAvantNavigation);

        try {
            const reponse = await fetch(url.href, {
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { 'X-Requested-With': 'fetch' },
                signal: controleur.signal
            });
            if (!reponse.ok || !estRouteAdmin(new URL(reponse.url))) {
                window.location.assign(url.href);
                return;
            }

            const html = await reponse.text();
            const documentCible = new DOMParser().parseFromString(html, 'text/html');
            const shellCible = documentCible.querySelector('.admin-app, .app');
            const contenuCible = shellCible && retrouverContenu(shellCible);
            const contenuActuel = retrouverContenu(shell);
            const sidebarCible = documentCible.querySelector('.admin-sidebar');
            if (!contenuCible || !contenuActuel || !sidebarCible) {
                window.location.assign(url.href);
                return;
            }

            const urlFinale = new URL(reponse.url);
            const stylesPage = await chargerStyles(documentCible, urlFinale.href, controleur.signal);
            if (controleur.signal.aborted) {
                stylesPage.nouveauxStyles.forEach((style) => style.remove());
                return;
            }
            const themeCoherence = document.querySelector('link[data-admin-theme-coherence]');
            document.dispatchEvent(new CustomEvent('admin:page-quitte', { detail: { url: window.location.href } }));
            shell.className = shellCible.className;
            const nouveauContenu = document.importNode(contenuCible, true);
            if (afficherChargement) {
                nouveauContenu.prepend(chargeurPage);
                nouveauContenu.setAttribute('aria-busy', 'true');
            }
            stylesPage.stylesPrets.forEach((style) => {
                style.media = style.dataset.adminPageMedia || 'all';
            });
            contenuActuel.replaceWith(nouveauContenu);
            urlContenuActuel = urlFinale;
            document.body.className = documentCible.body.className;
            document.title = documentCible.title;
            actualiserLienActif(urlFinale);

            stylesPage.stylesActifs.forEach((style) => {
                if (!stylesPage.stylesPrets.includes(style)) style.remove();
            });
            if (themeCoherence) document.head.appendChild(themeCoherence);
            await attendreAffichageStyles();
            if (controleur.signal.aborted) return;

            document.querySelectorAll('[data-admin-page-extra]').forEach((element) => element.remove());
            [...documentCible.body.children].forEach((element) => {
                if (element === shellCible || element.tagName === 'SCRIPT') return;
                const copie = document.importNode(element, true);
                copie.dataset.adminPageExtra = 'true';
                document.body.appendChild(copie);
            });

            document.querySelectorAll('script[data-admin-page-script]').forEach((script) => script.remove());
            const scriptsPage = [...documentCible.body.querySelectorAll('script')]
                .filter((script) => !script.closest('.admin-sidebar'))
                .filter((script) => !script.closest('.admin-app, .app')
                    || contenuCible.contains(script))
                .filter((script) => !script.hasAttribute('data-admin-shell-script'))
                .filter((script) => !script.type || ['module', 'text/javascript', 'application/javascript'].includes(script.type))
                .filter((script) => !/messagerie-interne-notifications|admin-sidebar-notifications|admin-navigation-dynamique/.test(script.src));
            for (const scriptSource of scriptsPage) {
                const script = document.createElement('script');
                script.dataset.adminPageScript = 'true';
                for (const attribut of scriptSource.attributes) {
                    if (attribut.name !== 'src' && attribut.name !== 'async' && attribut.name !== 'defer') {
                        script.setAttribute(attribut.name, attribut.value);
                    }
                }
                if (scriptSource.src) {
                    script.src = new URL(scriptSource.getAttribute('src'), urlFinale.href).href;
                    script.async = false;
                    await new Promise((resolve, reject) => {
                        script.onload = resolve;
                        script.onerror = () => {
                            reject(new Error('Impossible de charger le script de la page admin : ' + script.src));
                        };
                        document.body.appendChild(script);
                    });
                } else {
                    const code = scriptSource.textContent;
                    script.textContent = script.type === 'module'
                        ? code
                        : '(() => {\n' + code + '\n})();';
                    document.body.appendChild(script);
                }
            }

            ordonnerStylesGlobaux();
            await attendreAffichageStyles();
            if (controleur.signal.aborted) return;
            if (afficherChargement) await attendreDureeMinimum(debutChargement, 1200, controleur.signal);
            if (controleur.signal.aborted) return;
            chargeurPage?.remove();
            nouveauContenu.removeAttribute('aria-busy');

            if (ajouterHistorique) {
                history.replaceState({
                    ...history.state,
                    adminNavigationDynamique: true,
                    scrollContenu: scrollAvantNavigation,
                    scrollY: window.scrollY
                }, '');
                history.pushState({ adminNavigationDynamique: true, scrollContenu: 0, scrollY: 0 }, '', urlFinale.href);
            }
            window.scrollTo(0, ajouterHistorique ? 0 : Math.max(0, Number(history.state?.scrollY) || 0));
            const contenuApresNavigation = retrouverContenu(shell);
            if (contenuApresNavigation) contenuApresNavigation.scrollTop = ajouterHistorique
                ? 0
                : Math.max(0, Number(history.state?.scrollContenu) || 0);
            document.dispatchEvent(new CustomEvent('admin:page-chargee', { detail: { url: urlFinale.href } }));
        } catch (erreur) {
            if (erreur.name !== 'AbortError' && requeteEnCours === controleur) {
                console.error('Navigation admin dynamique impossible :', erreur);
                window.location.assign(url.href);
            }
        } finally {
            if (requeteEnCours === controleur) {
                requeteEnCours = null;
                shell.removeAttribute('aria-busy');
                shell.classList.remove('admin-navigation-en-cours');
                if (chargeurPage?.isConnected) {
                    chargeurPage.remove();
                    retrouverContenu(shell)?.removeAttribute('aria-busy');
                }
                indicateurChargement.classList.remove('is-visible');
            }
        }
    }

    document.addEventListener('click', (event) => {
        if (event.defaultPrevented || event.button !== 0
            || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        const cible = event.target instanceof Element ? event.target : event.target.parentElement;
        const ligne = cible && cible.closest('[data-href]');
        if (ligne && !cible.closest('a, button, input, select, textarea')) {
            const urlLigne = new URL(ligne.dataset.href, window.location.href);
            if (estRouteAdmin(urlLigne)) {
                event.preventDefault();
                event.stopImmediatePropagation();
                naviguer(urlLigne, true);
            }
            return;
        }

        const lien = cible && cible.closest('a[href]');
        if (!lien || lien.target || lien.hasAttribute('download')) return;
        if (lien.hasAttribute('data-no-admin-navigation')) return;
        const url = new URL(lien.href, window.location.href);
        if (!estRouteAdmin(url) || url.hash && url.pathname === window.location.pathname) return;
        event.preventDefault();
        naviguer(url, true);
    }, true);

    document.addEventListener('submit', (event) => {
        const formulaire = event.target;
        if (!(formulaire instanceof HTMLFormElement) || formulaire.method.toLowerCase() !== 'get') return;
        if (formulaire.target || formulaire.hasAttribute('data-no-admin-navigation')
            || formulaire.querySelector('input[type="file"]')) return;
        const action = new URL(formulaire.action || window.location.href, window.location.href);
        if (!estRouteAdmin(action)) return;
        event.preventDefault();
        const donnees = event.submitter ? new FormData(formulaire, event.submitter) : new FormData(formulaire);
        const parametres = new URLSearchParams();
        donnees.forEach((valeur, cle) => {
            if (typeof valeur === 'string') parametres.append(cle, valeur);
        });
        action.search = parametres.toString();
        naviguer(action, true);
    });

    window.addEventListener('popstate', () => naviguer(new URL(window.location.href), false));
})();
