(function () {
    'use strict';

    const timers = Array.from(document.querySelectorAll('[data-sla-depart][data-sla-seuil]'));
    if (!timers.length) return;

    function formatDuree(secondes) {
        const jours = Math.floor(secondes / 86400);
        const heures = Math.floor((secondes % 86400) / 3600);
        const minutes = Math.floor((secondes % 3600) / 60);
        const reste = secondes % 60;
        const duree = [heures, minutes, reste].map((partie) => String(partie).padStart(2, '0')).join(':');
        return (jours ? jours + ' j ' : '') + duree;
    }

    function actualiserSla() {
        const maintenant = Math.floor(Date.now() / 1000);
        timers.forEach((element) => {
            const depart = Number(element.dataset.slaDepart);
            const seuil = Number(element.dataset.slaSeuil);
            if (!Number.isFinite(depart) || !Number.isFinite(seuil)) return;

            const age = Math.max(0, maintenant - depart);
            const depasse = age >= seuil;
            element.classList.toggle('coord-badge--rouge', depasse);
            element.classList.toggle('coord-badge--bleu', !depasse);
            element.textContent = depasse
                ? 'SLA dépassé · +' + formatDuree(age - seuil)
                : 'Transmise · ' + formatDuree(age);
        });
    }

    actualiserSla();
    window.setInterval(actualiserSla, 1000);
})();
