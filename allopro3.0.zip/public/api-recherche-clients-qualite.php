<?php
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require_once __DIR__ . '/../includes/auth.php';

function repondreRechercheClients(array $donnees, int $code = 200): void {
    http_response_code($code);
    echo json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    repondreRechercheClients(['erreur' => 'Méthode non autorisée.'], 405);
}

if (!isset($_SESSION['user_id'])) {
    repondreRechercheClients(['erreur' => 'Votre session a expiré. Reconnectez-vous.'], 401);
}

rafraichirCompteConnecte();
if (($_SESSION['role'] ?? '') !== 'qualite' || !peut('clients')) {
    repondreRechercheClients(['erreur' => 'Accès refusé.'], 403);
}

$recherche = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
if (mb_strlen($recherche) < 2) {
    repondreRechercheClients(['clients' => [], 'minimum' => 2]);
}
if (mb_strlen($recherche) > 100) {
    repondreRechercheClients(['erreur' => 'La recherche ne peut dépasser 100 caractères.'], 400);
}

try {
    require_once __DIR__ . '/../models/User.php';
    require_once __DIR__ . '/../includes/AvatarProfil.php';

    $clients = (new User())->getAllClients($recherche, 50);
    $resultats = array_map(static function (array $client): array {
        $nomComplet = trim((string) ($client['prenom'] ?? '') . ' ' . (string) ($client['nom'] ?? ''));
        $photo = AvatarProfil::estValide($client['photo_profil'] ?? null, 'clients')
            && empty($client['avatar_initiales'])
            ? (string) $client['photo_profil']
            : null;

        return [
            'id' => (int) $client['id'],
            'nom' => (string) ($client['nom'] ?? ''),
            'prenom' => (string) ($client['prenom'] ?? ''),
            'nom_complet' => $nomComplet,
            'telephone' => (string) ($client['telephone'] ?? ''),
            'email' => (string) ($client['email'] ?? ''),
            'nb_demandes' => (int) ($client['nb_demandes'] ?? 0),
            'nb_actives' => (int) ($client['nb_actives'] ?? 0),
            'date_creation' => (string) ($client['date_creation'] ?? ''),
            'statut' => (string) ($client['statut'] ?? ''),
            'photo_profil' => $photo,
            'avatar_initiales' => !empty($client['avatar_initiales']),
        ];
    }, $clients);

    repondreRechercheClients(['clients' => $resultats, 'limite' => 50]);
} catch (Throwable $exception) {
    error_log('[recherche clients Qualité] ' . $exception->getMessage());
    repondreRechercheClients(['erreur' => 'La recherche des clients a échoué. Réessayez.'], 500);
}
