<?php
session_start();
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Partenaire.php';
require_once __DIR__ . '/../models/Technicien.php';
require_once __DIR__ . '/../includes/password-reset.php';
require_once __DIR__ . '/../includes/phone-normalization.php';

$typesValides = ['client', 'partenaire', 'technicien'];
$type = in_array($_GET['type'] ?? '', $typesValides, true) ? $_GET['type'] : 'client';
$jeton = is_string($_GET['token'] ?? null) ? $_GET['token'] : '';
$message = '';
$erreur = '';
$afficherFormulaireMotDePasse = false;
$defiTelephoneActif = false;
$telephoneMasque = '';
$emailSaisi = '';
$messageDemandeGenerique = 'Si les informations correspondent à un compte admissible, un lien de réinitialisation sera envoyé. Vérifiez aussi vos courriers indésirables.';

header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');

if (empty($_SESSION['csrf_mot_de_passe'])) {
    $_SESSION['csrf_mot_de_passe'] = bin2hex(random_bytes(32));
}

function modeleCompte(string $type) {
    if ($type === 'partenaire') return new Partenaire();
    if ($type === 'technicien') return new Technicien();
    return new User();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $jeton !== '') {
    if (preg_match('/\A[a-f0-9]{64}\z/i', $jeton)) {
        $afficherFormulaireMotDePasse = modeleCompte($type)->jetonReinitialisationValide(hash('sha256', $jeton));
    }
    if (!$afficherFormulaireMotDePasse) {
        $erreur = 'Ce lien est invalide ou a expiré. Vous pouvez demander un nouveau lien ci-dessous.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_mot_de_passe'], $csrf)) {
        $erreur = 'La demande a expiré. Rechargez la page et réessayez.';
    } elseif (($_POST['action'] ?? '') === 'demander') {
        $type = in_array($_POST['type'] ?? '', $typesValides, true) ? $_POST['type'] : 'client';
        $email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
        $emailSaisi = $email;
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erreur = 'Saisissez une adresse email valide.';
        } else {
            $modele = modeleCompte($type);
            $compte = $modele->findByEmail($email);
            $compteEligible = $compte && ($type !== 'client'
                || (($compte['role'] ?? '') === 'client' && !empty($compte['email_verifie'])));
            unset($_SESSION['defi_telephone_reinitialisation']);
            if ($compteEligible && !empty($compte['telephone'])) {
                $telephoneEnregistre = normaliserTelephone((string) $compte['telephone']);
                $idCompte = (int) $compte['id'];
                if ($telephoneEnregistre !== '' && !$modele->telephoneReinitialisationBloque($idCompte)) {
                    $_SESSION['defi_telephone_reinitialisation'] = [
                        'type' => $type,
                        'email' => $email,
                        'nonce' => bin2hex(random_bytes(16)),
                        'expire' => time() + 600,
                    ];
                    $telephoneMasque = masquerTelephone((string) $compte['telephone']);
                    $defiTelephoneActif = true;
                    $message = 'Pour continuer, confirmez le numéro de téléphone complet enregistré pour ce compte.';
                } else {
                    $message = $messageDemandeGenerique;
                }
            } elseif (!$compte) {
                $erreur = 'Aucun compte n’est associé à cette adresse email.';
            } else {
                $message = $messageDemandeGenerique;
            }
        }
    } elseif (($_POST['action'] ?? '') === 'verifier_telephone') {
        $defi = $_SESSION['defi_telephone_reinitialisation'] ?? null;
        $nonceSoumis = is_string($_POST['nonce'] ?? null) ? $_POST['nonce'] : '';
        $telephoneSaisi = is_string($_POST['telephone'] ?? null) ? normaliserTelephone($_POST['telephone']) : '';
        if (!is_array($defi) || ($defi['expire'] ?? 0) < time()
            || !hash_equals((string) ($defi['nonce'] ?? ''), $nonceSoumis)) {
            unset($_SESSION['defi_telephone_reinitialisation']);
            $erreur = 'La vérification a expiré. Recommencez la demande.';
        } elseif (strlen($telephoneSaisi) < 2 || strlen($telephoneSaisi) > 20) {
            $type = $defi['type'];
            $emailSaisi = $defi['email'];
            $erreur = 'Saisissez le numéro complet associé au compte.';
            $defiTelephoneActif = true;
            $modele = modeleCompte($type);
            $compte = $modele->findByEmail($emailSaisi);
            if ($compte && !empty($compte['telephone'])) {
                $telephoneMasque = masquerTelephone((string) $compte['telephone']);
            }
        } else {
            $type = $defi['type'];
            $emailSaisi = $defi['email'];
            $modele = modeleCompte($type);
            $compte = $modele->findByEmail($defi['email']);
            $compteEligible = $compte && ($type !== 'client'
                || (($compte['role'] ?? '') === 'client' && !empty($compte['email_verifie'])));
            if ($compteEligible && !empty($compte['telephone'])) {
                $idCompte = (int) $compte['id'];
                if (!$modele->telephoneReinitialisationBloque($idCompte)) {
                    $telephoneEnregistre = normaliserTelephone((string) $compte['telephone']);
                    if ($telephoneEnregistre !== '' && hash_equals($telephoneEnregistre, $telephoneSaisi)) {
                        $modele->reinitialiserTentativesTelephone($idCompte);
                        try {
                            if (!envoyerLienReinitialisation($modele, $compte, $type)) {
                                error_log('Lien de réinitialisation non envoyé : délai de renvoi actif pour le compte ' . $idCompte . ' (' . $type . ').');
                            }
                        } catch (Throwable $e) {
                            error_log('Échec de l’envoi d’un lien de réinitialisation (' . $type . ') : ' . $e->getMessage());
                        }
                    } else {
                        $modele->enregistrerEchecTelephoneReinitialisation($idCompte);
                    }
                }
            }
            unset($_SESSION['defi_telephone_reinitialisation']);
            $message = $messageDemandeGenerique;
        }
    } elseif (($_POST['action'] ?? '') === 'reinitialiser') {
        $type = in_array($_POST['type'] ?? '', $typesValides, true) ? $_POST['type'] : 'client';
        $jeton = is_string($_POST['token'] ?? null) ? $_POST['token'] : '';
        $motDePasse = is_string($_POST['mot_de_passe'] ?? null) ? $_POST['mot_de_passe'] : '';
        $confirmation = is_string($_POST['confirmation'] ?? null) ? $_POST['confirmation'] : '';

        if (!preg_match('/\A[a-f0-9]{64}\z/i', $jeton)) {
            $erreur = 'Ce lien est invalide ou a expiré. Demandez-en un nouveau.';
        } elseif (strlen($motDePasse) < 8) {
            $erreur = 'Le mot de passe doit contenir au moins 8 caractères.';
            $afficherFormulaireMotDePasse = modeleCompte($type)->jetonReinitialisationValide(hash('sha256', $jeton));
        } elseif ($motDePasse !== $confirmation) {
            $erreur = 'Les deux mots de passe ne correspondent pas.';
            $afficherFormulaireMotDePasse = modeleCompte($type)->jetonReinitialisationValide(hash('sha256', $jeton));
        } elseif (modeleCompte($type)->reinitialiserMotDePasseParJeton(hash('sha256', $jeton), $motDePasse)) {
            $message = 'Votre mot de passe a été modifié. Vous pouvez maintenant vous connecter.';
            $jeton = '';
        } else {
            $erreur = 'Ce lien est invalide ou a expiré. Demandez-en un nouveau.';
        }
    } else {
        $erreur = 'La demande n’a pas pu être traitée. Rechargez la page et réessayez.';
    }
}

$typeConnexion = $type === 'partenaire' ? 'connexion-partenaire.php'
    : ($type === 'technicien' ? 'connexion-technicien.php' : 'connexion.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mot de passe oublié — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="images/icon.png">
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
    <style>
        .auth-reset-page { min-height: 100vh; }
        .auth-reset-content { width: 100%; max-width: 420px; }
        .auth-reset-form { width: 100%; }
        .auth-reset-form select { width: 100%; min-height: 48px; padding: 12px 14px; border: 1px solid #E2DFD8; border-radius: 8px; background: #fff; font: inherit; }
        .auth-reset-form .champ small { display: block; margin-top: 8px; color: var(--texte-discret); font-size: 12px; line-height: 1.5; }
        .auth-info { padding: 12px 14px; margin-bottom: 18px; border: 1px solid #A7F3D0; border-radius: 8px; background: #ECFDF5; color: #065F46; font-size: 14px; line-height: 1.5; }
        .auth-reset-logo { display: inline-block; margin-bottom: 30px; color: var(--noir); font-family: 'Space Grotesk', sans-serif; font-size: 32px; font-weight: 800; line-height: 1.1; text-decoration: none; }
        .auth-reset-logo span { color: var(--orange); }
        .auth-reset-return { display: flex; align-items: center; justify-content: center; width: 100%; min-height: 48px; margin-top: 18px; padding: 12px 16px; border: 1px solid #E2DFD8; border-radius: 8px; color: var(--noir); font-size: 14px; font-weight: 700; line-height: 1.4; text-align: center; text-decoration: none; transition: border-color 0.15s ease, background-color 0.15s ease; }
        .auth-reset-return:hover { border-color: var(--orange); background: #FFF8F3; }
        .auth-reset-return:focus-visible { outline: 3px solid rgba(255,122,48,0.35); outline-offset: 2px; }
        @media (max-width: 760px) {
            .auth-reset-panel { align-items: flex-start; padding: 28px 20px calc(32px + env(safe-area-inset-bottom)); }
            .auth-reset-content { margin: auto; }
            .auth-reset-logo { margin-bottom: 20px; font-size: 28px; }
            .auth-reset-form select { font-size: 16px; }
            .auth-reset-form .champ input { min-height: 48px; font-size: 16px; }
            .auth-reset-form .bouton-principal { min-height: 50px; padding: 12px 16px; line-height: 1.4; white-space: normal; }
            .auth-info, .erreur { overflow-wrap: anywhere; }
        }
        @media (max-width: 360px) {
            .auth-reset-panel { padding-right: 16px; padding-left: 16px; }
            .auth-reset-logo { margin-bottom: 16px; }
            .auth-reset-content .auth-form__soustitre { margin-bottom: 22px; }
        }
    </style>
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>
    <div class="auth-page auth-reset-page">
        <div class="auth-form-panel auth-reset-panel">
            <main class="auth-form auth-reset-content">
                <a href="index.php" class="auth-reset-logo" aria-label="ALLÔ PRO, accueil">ALLÔ<span> PRO</span></a>
                <h2>Mot de passe oublié</h2>
                <p class="auth-form__soustitre">Recevez un lien sécurisé pour choisir un nouveau mot de passe.</p>

                <?php if ($message): ?><div class="auth-info" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
                <?php if ($erreur): ?><div class="erreur" role="alert"><?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

                <?php if ($afficherFormulaireMotDePasse): ?>
                    <form method="POST" class="auth-reset-form">
                        <input type="hidden" name="action" value="reinitialiser">
                        <input type="hidden" name="type" value="<?= htmlspecialchars($type, ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="token" value="<?= htmlspecialchars($jeton, ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_mot_de_passe'], ENT_QUOTES, 'UTF-8') ?>">
                        <div class="champ">
                            <label for="mot_de_passe">Nouveau mot de passe</label>
                            <input type="password" id="mot_de_passe" name="mot_de_passe" class="auth-password-field" minlength="8" autocomplete="new-password" required>
                            <label class="auth-password-toggle-label"><input type="checkbox" class="auth-password-toggle"> Afficher le mot de passe</label>
                        </div>
                        <div class="champ">
                            <label for="confirmation">Confirmer le mot de passe</label>
                            <input type="password" id="confirmation" name="confirmation" class="auth-password-field" minlength="8" autocomplete="new-password" required>
                            <label class="auth-password-toggle-label"><input type="checkbox" class="auth-password-toggle"> Afficher le mot de passe</label>
                        </div>
                        <button type="submit" class="bouton-principal">Enregistrer le nouveau mot de passe</button>
                    </form>
                <?php elseif ($defiTelephoneActif): ?>
                    <form method="POST" class="auth-reset-form">
                        <input type="hidden" name="action" value="verifier_telephone">
                        <input type="hidden" name="nonce" value="<?= htmlspecialchars($_SESSION['defi_telephone_reinitialisation']['nonce'], ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_mot_de_passe'], ENT_QUOTES, 'UTF-8') ?>">
                        <div class="champ">
                            <label for="telephone-indice">Numéro enregistré</label>
                            <input type="text" id="telephone-indice" value="<?= htmlspecialchars($telephoneMasque, ENT_QUOTES, 'UTF-8') ?>" readonly aria-describedby="telephone-aide">
                        </div>
                        <div class="champ">
                            <label for="telephone">Saisissez le numéro complet associé au compte</label>
                            <input type="tel" id="telephone" name="telephone" autocomplete="tel" inputmode="tel" required>
                            <small id="telephone-aide">L’indice montre les deux derniers chiffres. Les espaces, tirets, parenthèses et le signe + sont ignorés lors de la vérification.</small>
                        </div>
                        <button type="submit" class="bouton-principal">Vérifier et continuer</button>
                    </form>
                <?php elseif (strpos($message, 'modifié') === false): ?>
                    <form method="POST" class="auth-reset-form">
                        <input type="hidden" name="action" value="demander">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_mot_de_passe'], ENT_QUOTES, 'UTF-8') ?>">
                        <div class="champ">
                            <label for="type">Type de compte</label>
                            <select id="type" name="type">
                                <option value="client" <?= $type === 'client' ? 'selected' : '' ?>>Client</option>
                                <option value="partenaire" <?= $type === 'partenaire' ? 'selected' : '' ?>>Partenaire</option>
                                <option value="technicien" <?= $type === 'technicien' ? 'selected' : '' ?>>Technicien</option>
                            </select>
                        </div>
                        <div class="champ">
                            <label for="email">Adresse email</label>
                            <input type="email" id="email" name="email" value="<?= htmlspecialchars($emailSaisi !== '' ? $emailSaisi : (is_string($_POST['email'] ?? null) ? $_POST['email'] : ''), ENT_QUOTES, 'UTF-8') ?>" autocomplete="email" required>
                        </div>
                        <button type="submit" class="bouton-principal">Envoyer le lien de réinitialisation</button>
                    </form>
                <?php endif; ?>
                <a href="<?= htmlspecialchars($typeConnexion, ENT_QUOTES, 'UTF-8') ?>" class="auth-reset-return">Retour à la connexion</a>
            </main>
        </div>
    </div>
    <script src="js/auth.js?v=<?= filemtime(__DIR__ . '/js/auth.js') ?>" defer></script>
</body>
</html>
