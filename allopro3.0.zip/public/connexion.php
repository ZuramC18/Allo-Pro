<?php
session_start();
if (isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/../includes/auth.php';
    verifierConnexion();
    header('Location: dashboard.php');
    exit;
}

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../includes/audit.php';
require_once __DIR__ . '/../includes/helpers.php';

$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $motDePasse = $_POST['mot_de_passe'];

    $user = new User();
    $data = $user->findByEmail($email);

    if ($data) {
        if ($data['mot_de_passe'] === null) {
            $erreur = "Ce compte utilise la connexion Google. Cliquez sur « Se connecter avec Google » ci-dessous.";
        } elseif (password_verify($motDePasse, $data['mot_de_passe'])) {
            if (empty($data['email_verifie'])) {
                $erreur = "Vérifiez votre adresse email avant de vous connecter.";
                $emailVerification = true;
            } elseif ($data['statut'] === 'suspendu') {
                $erreur = "Ce compte a été suspendu. Contactez le support ALLÔ PRO.";
                journaliser('connexion.refusee', 'compte', $data['id'], $data['matricule'], 'Compte suspendu');
            } else {
                $_SESSION['user_id'] = $data['id'];
                $_SESSION['role'] = $data['role'];
                $_SESSION['prenom'] = $data['prenom'];
                $_SESSION['nom_famille'] = $data['nom'];
                $_SESSION['nom'] = nomComplet($data['prenom'], $data['nom']);
                journaliser('connexion.reussie', 'compte', $data['id'], $data['matricule']);
                header("Location: dashboard.php");
                exit;
            }
        } else {
            $erreur = "Email ou mot de passe incorrect.";
            journaliser('connexion.echec', 'compte', $data['id'], $data['matricule'], 'Email saisi : ' . $email);
        }
    } else {
        $erreur = "Email ou mot de passe incorrect.";
        journaliser('connexion.echec', 'compte', null, null, 'Email saisi : ' . $email);
    }
}

if (isset($_GET['raison']) && !$erreur) {
    $messagesRaison = [
        'suspendu' => "Votre session a été fermée car ce compte a été suspendu.",
        'compte_introuvable' => "Votre session a expiré. Merci de vous reconnecter.",
    ];
    $erreur = $messagesRaison[$_GET['raison']] ?? '';
}

if (isset($_GET['erreur']) && !$erreur) {
    $messages = ['google_invalide' => "La connexion Google a échoué, réessayez.", 'suspendu' => "Ce compte a été suspendu."];
    $erreur = $messages[$_GET['erreur']] ?? '';
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion — ALLÔ PRO</title>
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
    <link rel="icon" type="image/png" href="images/icon.png">
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>
    <div class="auth-page">
        <div class="auth-photo">
            <div class="auth-photo__img"></div>
            <div class="auth-photo__contenu">
                <a href="index.php" class="auth-photo__logo">ALLÔ<span> PRO</span></a>

                <div class="auth-photo__citation">« Un problème, un seul numéro — et quelqu'un s'en occupe vraiment. »</div>

                <div class="auth-photo__badges">
                    <div>
                        <div class="auth-photo__badge-chiffre">34</div>
                        <div class="auth-photo__badge-label">Partenaires actifs</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">1200+</div>
                        <div class="auth-photo__badge-label">Interventions</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">4.8★</div>
                        <div class="auth-photo__badge-label">Satisfaction</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="auth-form-panel">
            <form method="POST" class="auth-form">
                <a href="index.php" class="auth-retour">← Retour à l’accueil</a>
                <h2>Content de vous revoir</h2>
                <p class="auth-form__soustitre">Connectez-vous à votre espace ALLÔ PRO</p>

                <?php if ($erreur): ?><div class="erreur"><?= htmlspecialchars($erreur) ?></div><?php endif; ?>
                <?php if (!empty($emailVerification)): ?>
                    <p class="auth-form__lien"><a href="verification-email.php?type=client&amp;email=<?= rawurlencode($email) ?>">Recevoir un code de vérification</a></p>
                <?php endif; ?>

                <div class="champ">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="champ">
                    <label for="mot_de_passe">Mot de passe</label>
                    <input type="password" id="mot_de_passe" name="mot_de_passe" class="auth-password-field" required>
                    <label class="auth-password-toggle-label">
                        <input type="checkbox" class="auth-password-toggle">
                        Afficher le mot de passe
                    </label>
                    <p class="auth-password-forgot"><a href="mot-de-passe-oublie.php?type=client">Mot de passe oublié ?</a></p>
                </div>

                <button type="submit" class="bouton-principal">Se connecter</button>
                <div style="text-align:center; margin:18px 0; color:#9CA3AF; font-size:13px;">— ou —</div>

                <div id="g_id_onload"
                    data-client_id="<?php require_once __DIR__ . '/../config/google.php'; echo htmlspecialchars(GOOGLE_CLIENT_ID, ENT_QUOTES, 'UTF-8'); ?>"
                    data-login_uri="<?= htmlspecialchars(GOOGLE_LOGIN_URI, ENT_QUOTES, 'UTF-8') ?>"
                    data-auto_select="false">
                </div>
                <div class="g_id_signin" data-type="standard" data-width="380" data-shape="rectangular" data-theme="outline" data-text="signin_with" data-size="large" style="display:flex; justify-content:center;"></div>

                <p class="auth-form__lien">Pas encore de compte ? <a href="inscription.php">S'inscrire</a></p>
            </form>
        </div>
    </div>
    <script src="js/auth.js?v=<?= filemtime(__DIR__ . '/js/auth.js') ?>" defer></script>
</body>
</html>