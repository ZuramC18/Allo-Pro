<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../models/EntrepriseB2B.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$repondre = static function (int $statut, array $donnees): never {
    http_response_code($statut);
    echo json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
};

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    $repondre(405, ['success' => false, 'message' => 'Méthode non autorisée.']);
}

$csrfKey = 'csrf_entreprise_membres';
$csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
if (empty($_SESSION[$csrfKey]) || !hash_equals($_SESSION[$csrfKey], $csrf)) {
    $repondre(403, ['success' => false, 'message' => 'La page a expiré. Rechargez-la puis réessayez.']);
}

$entrepriseId = filter_var($_GET['entreprise_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$membreId = filter_var($_POST['membre_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$permissions = $_POST['permissions'] ?? [];
if ($entrepriseId === false || $membreId === false || !is_array($permissions)) {
    $repondre(400, ['success' => false, 'message' => 'Les données transmises sont invalides.']);
}

$userId = (int) $_SESSION['user_id'];
try {
    $entrepriseModele = new EntrepriseB2B();
    if (!$entrepriseModele->getEntreprisePourMembre((int) $entrepriseId, $userId)
        || !$entrepriseModele->estAdministrateur((int) $entrepriseId, $userId)) {
        $repondre(403, ['success' => false, 'message' => 'Seul un administrateur de cette entreprise peut gérer les permissions.']);
    }
    $entrepriseModele->enregistrerPermissionsMembre((int) $entrepriseId, $userId, (int) $membreId, $permissions);
    $repondre(200, ['success' => true, 'message' => 'Permissions enregistrées.']);
} catch (InvalidArgumentException $exception) {
    $repondre(400, ['success' => false, 'message' => $exception->getMessage()]);
} catch (RuntimeException $exception) {
    $repondre(403, ['success' => false, 'message' => $exception->getMessage()]);
} catch (PDOException $exception) {
    error_log('Permissions membre entreprise ' . (int) $entrepriseId . ' : ' . $exception->getMessage());
    $repondre(500, ['success' => false, 'message' => 'Les permissions n’ont pas pu être enregistrées. Réessayez.']);
}
