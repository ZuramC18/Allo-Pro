<?php
session_start();
require_once __DIR__ . '/../models/MessageContact.php';

$raisonsContact = [
    'question-service' => 'Question sur un service',
    'suivi-demande' => 'Suivi d’une demande',
    'paiement-facture' => 'Paiement ou facture',
    'abonnement-pass' => 'Abonnement ou Pass',
    'probleme-technique' => 'Problème technique',
    'partenariat' => 'Devenir partenaire',
    'autre' => 'Autre demande',
];
$erreur = '';
$envoye = ($_GET['envoye'] ?? '') === '1';
$valeurs = [
    'nom' => '',
    'email' => '',
    'telephone' => '',
    'raison' => '',
    'sujet' => '',
    'message' => '',
];

if (empty($_SESSION['csrf_contact'])) {
    $_SESSION['csrf_contact'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($valeurs as $champ => $_) {
        $valeurs[$champ] = is_string($_POST[$champ] ?? null) ? trim($_POST[$champ]) : '';
    }

    $csrf = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    $raisonValide = isset($raisonsContact[$valeurs['raison']]);
    $nomLongueur = preg_match_all('/./us', $valeurs['nom']);
    $sujetLongueur = preg_match_all('/./us', $valeurs['sujet']);
    $messageLongueur = preg_match_all('/./us', $valeurs['message']);
    $telephoneValide = $valeurs['telephone'] === ''
        || preg_match('/^[0-9+().\s-]{6,30}$/', $valeurs['telephone']);

    if (!hash_equals($_SESSION['csrf_contact'], $csrf)) {
        $erreur = 'Le formulaire a expiré. Rechargez la page puis réessayez.';
    } elseif (!empty($_POST['website'] ?? '')) {
        $erreur = 'Votre message n’a pas pu être envoyé.';
    } elseif (isset($_SESSION['contact_last_submission']) && time() - (int) $_SESSION['contact_last_submission'] < 30) {
        $erreur = 'Merci de patienter quelques secondes avant d’envoyer un nouveau message.';
    } elseif (
        $nomLongueur === false || $nomLongueur < 2 || $nomLongueur > 120
        || !filter_var($valeurs['email'], FILTER_VALIDATE_EMAIL) || strlen($valeurs['email']) > 254
        || !$telephoneValide
        || !$raisonValide
        || $sujetLongueur === false || $sujetLongueur < 3 || $sujetLongueur > 160
        || $messageLongueur === false || $messageLongueur < 10 || $messageLongueur > 10000
    ) {
        $erreur = 'Vérifiez les champs : nom (2 à 120 caractères), email valide, sujet (3 à 160 caractères) et message (10 à 10 000 caractères).';
    } else {
        try {
            $messageContact = new MessageContact();
            $messageContact->creer(
                $valeurs['nom'],
                $valeurs['email'],
                $valeurs['telephone'],
                $raisonsContact[$valeurs['raison']],
                $valeurs['sujet'],
                $valeurs['message']
            );
            $_SESSION['contact_last_submission'] = time();
            $_SESSION['csrf_contact'] = bin2hex(random_bytes(32));
            header('Location: contact.php?envoye=1');
            exit;
        } catch (PDOException $exception) {
            error_log('Enregistrement du formulaire de contact : ' . $exception->getMessage());
            $erreur = 'Votre message n’a pas pu être enregistré. Réessayez dans quelques instants.';
        }
    }
}

$e = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contacter le support — ALLÔ PRO</title>
    <meta name="description" content="Contactez l’équipe ALLÔ PRO à propos d’un service, d’une demande, d’un paiement ou de votre compte.">
    <link rel="icon" type="image/png" href="images/icon.png">
    <link rel="stylesheet" href="css/index.css?v=<?= filemtime(__DIR__ . '/css/index.css') ?>">
    <link rel="stylesheet" href="css/contact.css?v=<?= filemtime(__DIR__ . '/css/contact.css') ?>">
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>
<header class="contact-nav">
    <a href="index.php" class="contact-nav__logo">ALLÔ<span> PRO</span></a>
    <a href="index.php" class="contact-nav__retour">Retour à l’accueil</a>
</header>
<main class="contact-page">
    <section class="contact-intro">
        <span class="contact-intro__surtitre">NOUS CONTACTER</span>
        <h1>Comment pouvons-nous vous aider&nbsp;?</h1>
        <p>Décrivez votre demande et notre équipe vous répondra à l’adresse email indiquée.</p>
    </section>

    <?php if ($envoye): ?>
        <div class="contact-alerte contact-alerte--succes" role="status">
            Votre message a bien été envoyé. Merci de nous avoir contactés.
        </div>
    <?php endif; ?>
    <?php if ($erreur !== ''): ?>
        <div class="contact-alerte contact-alerte--erreur" role="alert"><?= $e($erreur) ?></div>
    <?php endif; ?>

    <form class="contact-formulaire" method="post" action="contact.php" novalidate>
        <input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf_contact']) ?>">
        <div class="contact-formulaire__piege" aria-hidden="true">
            <label for="contact-website">Ne pas remplir</label>
            <input id="contact-website" type="text" name="website" tabindex="-1" autocomplete="off">
        </div>
        <div class="contact-champs">
            <label for="contact-nom">Nom complet <span>*</span></label>
            <input id="contact-nom" name="nom" type="text" maxlength="120" autocomplete="name" required value="<?= $e($valeurs['nom']) ?>">
        </div>
        <div class="contact-champs">
            <label for="contact-email">Adresse email <span>*</span></label>
            <input id="contact-email" name="email" type="email" maxlength="254" autocomplete="email" required value="<?= $e($valeurs['email']) ?>">
        </div>
        <div class="contact-champs">
            <label for="contact-telephone">Téléphone <small>(facultatif)</small></label>
            <input id="contact-telephone" name="telephone" type="tel" maxlength="30" autocomplete="tel" value="<?= $e($valeurs['telephone']) ?>">
        </div>
        <div class="contact-champs">
            <label for="contact-raison">Raison du contact <span>*</span></label>
            <select id="contact-raison" name="raison" required>
                <option value="">Sélectionnez une raison</option>
                <?php foreach ($raisonsContact as $identifiant => $libelle): ?>
                    <option value="<?= $e($identifiant) ?>" <?= $valeurs['raison'] === $identifiant ? 'selected' : '' ?>><?= $e($libelle) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="contact-champs contact-champs--large">
            <label for="contact-sujet">Sujet <span>*</span></label>
            <input id="contact-sujet" name="sujet" type="text" maxlength="160" required value="<?= $e($valeurs['sujet']) ?>" placeholder="Résumez votre demande en quelques mots">
        </div>
        <div class="contact-champs contact-champs--large">
            <label for="contact-message">Votre message <span>*</span></label>
            <textarea id="contact-message" name="message" rows="7" minlength="10" maxlength="10000" required><?= $e($valeurs['message']) ?></textarea>
            <small>10 caractères minimum. N’incluez pas de mot de passe ni d’information bancaire.</small>
        </div>
        <div class="contact-formulaire__bas contact-champs--large">
            <p>Les informations saisies servent uniquement à traiter votre demande et à vous répondre.</p>
            <button type="submit">Envoyer le message</button>
        </div>
    </form>
</main>
<footer class="contact-footer">© <?= date('Y') ?> ALLÔ PRO · <a href="mailto:contact@allopro.sn">contact@allopro.sn</a></footer>
</body>
</html>
