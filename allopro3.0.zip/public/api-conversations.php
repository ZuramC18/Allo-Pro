<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('messagerie');
require_once __DIR__ . '/../models/Message.php';
require_once __DIR__ . '/../includes/AvatarProfil.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$messageModel = new Message();

$estGestionnaireMessagerie = in_array($_SESSION['role'], ['coordinateur', 'admin', 'qualite'], true);

$conversations = $estGestionnaireMessagerie
    ? $messageModel->getConversationsToutes()
    : $messageModel->getConversationsPourConseiller((int) $_SESSION['user_id']);

foreach ($conversations as &$conversation) {
    if (!empty($conversation['avatar_initiales'])
        || !AvatarProfil::estValide($conversation['photo_profil'] ?? null, 'clients')) {
        $conversation['photo_profil'] = null;
    }
}
unset($conversation);

echo json_encode($conversations, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);