<?php
session_start();
require_once __DIR__ . '/../models/Partenaire.php';
require_once __DIR__ . '/../includes/email-verification.php';

$erreur = '';
$nom = '';
$email = '';
$telephone = '';
if (empty($_SESSION['csrf_inscription_partenaire'])) {
    $_SESSION['csrf_inscription_partenaire'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = is_string($_POST['nom_entreprise'] ?? null) ? trim($_POST['nom_entreprise']) : '';
    $email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
    $motDePasse = is_string($_POST['mot_de_passe'] ?? null) ? $_POST['mot_de_passe'] : '';
    $telephone = is_string($_POST['telephone'] ?? null) ? trim($_POST['telephone']) : '';

    $partenaire = new Partenaire();

    $csrfSoumis = is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '';
    if (!hash_equals($_SESSION['csrf_inscription_partenaire'], $csrfSoumis)) {
        $erreur = "Le formulaire a expiré. Rechargez la page et réessayez.";
    } elseif ($nom === '') {
        $erreur = "Le nom de l'entreprise est obligatoire.";
    } elseif (mb_strlen($nom) > 150) {
        $erreur = "Le nom de l'entreprise ne doit pas dépasser 150 caractères.";
    } elseif (mb_strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreur = "Saisissez une adresse email valide.";
    } elseif (strlen($motDePasse) < 8) {
        $erreur = "Le mot de passe doit contenir au moins 8 caractères.";
    } elseif ($partenaire->findByEmail($email)) {
        $erreur = "Cet email est déjà utilisé.";
    } else {
        $id = $partenaire->create($nom, $email, $motDePasse, $telephone, false);
        try {
            $_SESSION['verification_email_notice'] = envoyerCodeVerificationEmail(
                $partenaire,
                $id,
                $email,
                $nom,
                'partenaire'
            ) ? 'envoye' : 'echec';
        } catch (RuntimeException $e) {
            error_log('Échec de l’envoi du mail de vérification partenaire : ' . $e->getMessage());
            $_SESSION['verification_email_notice'] = 'echec';
        }
        $_SESSION['verification_email_type'] = 'partenaire';
        $_SESSION['verification_email_adresse'] = $email;
        header("Location: verification-email.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Devenir partenaire — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="images/icon.png">
    <link rel="stylesheet" href="css/auth.css?v=<?= filemtime(__DIR__ . '/css/auth.css') ?>">
    <style>
        .auth-photo--inscription .auth-photo__img {
            background-image:
                linear-gradient(180deg, rgba(18,24,27,0.55) 0%, rgba(18,24,27,0.92) 100%),
                url('/img/partenaire.jpg'),
                url('https://images.pexels.com/photos/33694014/pexels-photo-33694014.jpeg?auto=compress&cs=tinysrgb&w=1200');
        }
    </style>
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>
    <div class="auth-page">
        <div class="auth-photo auth-photo--inscription">
            <div class="auth-photo__img"></div>
            <div class="auth-photo__contenu">
                <a href="index.php" class="auth-photo__logo">ALLÔ<span> PRO</span></a>

                <div class="auth-photo__citation">« Rejoignez notre réseau de professionnels vérifiés. »</div>

                <div class="auth-photo__badges">
                    <div>
                        <div class="auth-photo__badge-chiffre">Missions</div>
                        <div class="auth-photo__badge-label">Régulières</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">Paiements</div>
                        <div class="auth-photo__badge-label">Organisés</div>
                    </div>
                    <div>
                        <div class="auth-photo__badge-chiffre">Réseau</div>
                        <div class="auth-photo__badge-label">Pros vérifiés</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="auth-form-panel">
            <form method="POST" class="auth-form">
                <a href="index.php" class="auth-retour">← Retour à l’accueil</a>
                <h2>Devenir partenaire</h2>
                <p class="auth-form__soustitre">Créez votre compte entreprise</p>

                <?php if ($erreur): ?><div class="erreur"><?= htmlspecialchars($erreur) ?></div><?php endif; ?>
                <?php if ($erreur === "Cet email est déjà utilisé."): ?>
                    <p class="auth-form__lien"><a href="verification-email.php?type=partenaire&amp;email=<?= rawurlencode($email) ?>">Vous n'avez pas encore vérifié votre adresse ?</a></p>
                <?php endif; ?>

                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_inscription_partenaire'], ENT_QUOTES, 'UTF-8') ?>">
                <div class="champ">
                    <label for="nom_entreprise">Nom de l'entreprise</label>
                    <input type="text" id="nom_entreprise" name="nom_entreprise" value="<?= htmlspecialchars($nom, ENT_QUOTES, 'UTF-8') ?>" autocomplete="organization" maxlength="150" required autofocus>
                </div>
                <div class="champ">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" autocomplete="email" maxlength="150" required>
                </div>
                <div class="champ">
                    <label for="mot_de_passe">Mot de passe</label>
                    <input type="password" id="mot_de_passe" name="mot_de_passe" class="auth-password-field" autocomplete="new-password" minlength="8" required>
                    <label class="auth-password-toggle-label">
                        <input type="checkbox" class="auth-password-toggle">
                        Afficher le mot de passe
                    </label>
                </div>
                <div class="champ">
                    <label for="telephone">Téléphone</label>
                    <input type="tel" id="telephone" name="telephone" value="<?= htmlspecialchars($telephone, ENT_QUOTES, 'UTF-8') ?>" autocomplete="tel">
                </div>
                <button type="submit" class="bouton-principal">Créer mon compte</button>

                <p class="auth-form__lien">Déjà partenaire ? <a href="connexion-partenaire.php">Se connecter</a></p>
            </form>
        </div>
    </div>
    <script src="js/auth.js?v=<?= filemtime(__DIR__ . '/js/auth.js') ?>" defer></script>
</body>
</html>