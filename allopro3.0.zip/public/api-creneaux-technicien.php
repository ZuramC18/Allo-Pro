<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
verifierAcces('interventions');
require_once __DIR__ . '/../models/AttributionDemandeCoordinateur.php';
require_once __DIR__ . '/../models/Demande.php';
require_once __DIR__ . '/../models/Intervention.php';
require_once __DIR__ . '/../models/Parametre.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

$demandeId = filter_var($_GET['demande_id'] ?? null, FILTER_VALIDATE_INT);
$technicienId = filter_var($_GET['technicien_id'] ?? null, FILTER_VALIDATE_INT);
$interventionId = isset($_GET['intervention_id'])
    ? filter_var($_GET['intervention_id'], FILTER_VALIDATE_INT)
    : null;
$reaffectationDemandee = ($_GET['reaffectation'] ?? '') === '1';
$date = is_string($_GET['date'] ?? null) ? $_GET['date'] : '';
$dateValidee = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
$dateMax = (new DateTimeImmutable('today'))->modify('+30 days')->format('Y-m-d');

if ($demandeId === false || $demandeId < 1 || $technicienId === false || $technicienId < 1
    || ($interventionId !== null && ($interventionId === false || $interventionId < 1))
    || !$dateValidee || $dateValidee->format('Y-m-d') !== $date
    || $date < date('Y-m-d') || $date > $dateMax) {
    http_response_code(400);
    echo json_encode(['error' => 'La date ou le technicien sélectionné est invalide.']);
    exit;
}

try {
    $attribution = (new AttributionDemandeCoordinateur())->getByDemande($demandeId);
    $demande = (new Demande())->getById($demandeId);
    $estAdmin = ($_SESSION['role'] ?? null) === 'admin';
    $intervention = new Intervention();
    if ($interventionId !== null) {
        $mission = $intervention->getByDemandeId($demandeId);
        $peutModifierMission = $mission
            && (int) $mission['id'] === $interventionId
            && (int) $mission['technicien_id'] === $technicienId
            && in_array($mission['statut'], ['en_attente', 'acceptee'], true)
            && (($estAdmin && (!$attribution || $attribution['statut'] === 'traitee'))
                || ($attribution && $attribution['statut'] === 'traitee'
                    && (int) ($attribution['coordinateur_id'] ?? 0) === (int) $_SESSION['user_id']));
        $peutReaffecterMission = $reaffectationDemandee
                && $mission
                && (int) $mission['id'] === $interventionId
                && $mission['statut'] === 'en_attente'
                && (int) $mission['technicien_id'] !== $technicienId
                && (($estAdmin && (!$attribution || $attribution['statut'] === 'traitee'))
                    || ($attribution && $attribution['statut'] === 'traitee'
                        && (int) ($attribution['coordinateur_id'] ?? 0) === (int) $_SESSION['user_id']));
    } else {
        $peutModifierMission = false;
        $peutReaffecterMission = false;
    }
    $peutAffecterNouveau = $demande && $demande['statut'] === 'nouvelle'
        && ($estAdmin
            || ($attribution && $attribution['statut'] === 'en_attente'
                && ($attribution['coordinateur_id'] === null
                    || (int) $attribution['coordinateur_id'] === (int) $_SESSION['user_id'])));
    if (!$demande || (!$peutModifierMission && !$peutReaffecterMission && !$peutAffecterNouveau)) {
        http_response_code(403);
        echo json_encode(['error' => 'Vous ne pouvez pas consulter les créneaux de ce dossier.']);
        exit;
    }

    if (!$peutModifierMission) {
        $compatible = false;
        foreach ($intervention->getTechniciensCompatiblesDemande($demandeId) as $technicien) {
            if ((int) $technicien['id'] === $technicienId) {
                $compatible = true;
                break;
            }
        }
        if (!$compatible) {
            http_response_code(403);
            echo json_encode(['error' => 'Ce technicien n’est pas compatible avec le dossier.']);
            exit;
        }
    }

    $parametres = new Parametre();
    $heureDebut = max(0, min(23, (int) $parametres->get('heure_debut_indisponibilites', '8')));
    $heureFin = max($heureDebut + 1, min(24, (int) $parametres->get('heure_fin_indisponibilites', '20')));
    $heures = $intervention->getCreneauxDisponiblesTechnicien(
        $technicienId,
        $date,
        $heureDebut,
        $heureFin,
        $interventionId
    );

    echo json_encode([
        'slots' => array_map(
            static fn(int $heure): array => [
                'value' => $heure,
                'label' => sprintf('%02d:00–%02d:00', $heure, ($heure + 1) % 24),
            ],
            $heures
        ),
    ], JSON_UNESCAPED_UNICODE);
} catch (PDOException $exception) {
    error_log('Chargement des créneaux technicien ' . $technicienId . ' pour demande ' . $demandeId . ' : ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Impossible de charger les disponibilités pour le moment.']);
}
