<?php
session_start();

require_once __DIR__ . '/../models/Abonnement.php';
require_once __DIR__ . '/dom.php';
$abonnementModel = new Abonnement();
$formulesAccueil = $abonnementModel->getFormulesActives();

$connecte = isset($_SESSION['user_id']);
$role = $_SESSION['role'] ?? '';
$estClient = $connecte && $role === 'client';

$derniereDemande = null;
if ($estClient) {
    require_once __DIR__ . '/../models/Demande.php';
    $demandeModel = new Demande();
    $mesDemandes = $demandeModel->getByClient($_SESSION['user_id']);
    $derniereDemande = $mesDemandes[0] ?? null;
}

$lienDemande = $connecte ? ($estClient ? '../views/client/nouvelle-demande.php' : 'dashboard.php') : 'inscription.php';
$e = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$illustrationsSouhait = [
    'halloween' => '<svg viewBox="0 0 76 76" aria-hidden="true" focusable="false"><path d="M13 29 8 12l19 9a27 27 0 0 1 22 0l19-9-5 19a27 27 0 0 1 3 12c0 16-12 27-29 27S8 59 8 43a27 27 0 0 1 5-14Z" fill="#713d91" stroke="#f5c76b" stroke-width="2.5" stroke-linejoin="round"/><path d="m13 25 2-8 9 7m27 0 10-7 2 9" fill="#f47b20" stroke="#f5c76b" stroke-width="2" stroke-linejoin="round"/><ellipse cx="28" cy="40" rx="6" ry="8" fill="#fff5df"/><ellipse cx="49" cy="40" rx="6" ry="8" fill="#fff5df"/><circle cx="29" cy="42" r="2.7" fill="#21152b"/><circle cx="48" cy="42" r="2.7" fill="#21152b"/><path d="M31 55q7 8 15 0" fill="none" stroke="#fff5df" stroke-width="3" stroke-linecap="round"/><path d="m36 57 3-4 3 4" fill="#f47b20"/><circle cx="17" cy="49" r="2" fill="#ff9e86"/><circle cx="59" cy="49" r="2" fill="#ff9e86"/></svg>',
    'noel' => '<svg viewBox="0 0 76 76" aria-hidden="true"><path d="m38 5 4 9 10-2-5 8 8 7-11 1 2 10-8-6-8 6 2-10-11-1 8-7-5-8 10 2z" fill="#f6d36e"/><path d="m38 18-21 26h12L14 60h48L47 44h12L38 18z" fill="#27865b" stroke="#c5f0c9" stroke-width="2" stroke-linejoin="round"/><path d="M33 60h10v10H33z" fill="#9b5c38"/><circle cx="29" cy="46" r="2.5" fill="#f4c858"/><circle cx="45" cy="39" r="2.5" fill="#e86b67"/><circle cx="39" cy="54" r="2.5" fill="#fff"/></svg>',
    'nouvel-an' => '<svg viewBox="0 0 76 76" aria-hidden="true"><g fill="none" stroke-width="3" stroke-linecap="round"><path d="M20 17v13m-6-6h13m-11-7 9 9m0-9-9 9" stroke="#ffcf5e"/><path d="M55 11v17m-8-8h17m-15-6 12 12m0-12L49 26" stroke="#ff7c58"/><path d="M42 39v18m-9-9h18m-16-7 14 14m0-14L35 55" stroke="#fff1a8"/></g><path d="m19 58 9-19 8 6-10 18z" fill="#70d6ff" stroke="#d8f7ff" stroke-width="2"/><path d="m18 62-5 9 12-5" fill="#f6a74a"/></svg>',
    'aid-el-fitr' => '<svg viewBox="0 0 76 76" aria-hidden="true"><path d="M48 9a28 28 0 1 0 20 46A30 30 0 0 1 48 9Z" fill="#f3d36f" stroke="#fff1b8" stroke-width="2"/><path d="m53 19 2.5 6.5 7 .3-5.5 4.3 2 6.8-6-3.8-5.8 3.8 1.8-6.8-5.4-4.3 7-.3z" fill="#fff1b8"/><circle cx="19" cy="21" r="2" fill="#fff"/><circle cx="20" cy="54" r="2" fill="#fff"/></svg>',
    'aid-el-adha' => '<svg viewBox="0 0 76 76" aria-hidden="true"><path d="M19 35q-9-7-8-17 11 1 16 12m20 5q9-7 8-17-11 1-16 12" fill="#eee4d0" stroke="#9b825e" stroke-width="2.5" stroke-linejoin="round"/><path d="M20 31q-9 4-8 14 1 9 9 11l5 9h25l5-9q9-4 8-14-1-9-10-12-17-7-34 1Z" fill="#fff7e8" stroke="#c9ae82" stroke-width="2.5"/><path d="M26 40h3m18 0h3" stroke="#574637" stroke-width="4" stroke-linecap="round"/><path d="M33 51q5 5 10 0" fill="none" stroke="#9b654e" stroke-width="2.5" stroke-linecap="round"/><path d="M30 61v6m16-6v6" stroke="#9b654e" stroke-width="3" stroke-linecap="round"/></svg>',
    'ramadan' => '<svg viewBox="0 0 76 76" aria-hidden="true"><path d="M28 16h20l8 10-5 6v25l7 8H18l7-8V32l-5-6z" fill="#d5a943" stroke="#ffebaa" stroke-width="2.5" stroke-linejoin="round"/><path d="M30 34h16v18H30z" fill="#ffe28a"/><path d="M28 16v-5h20v5m-27 49h34" fill="none" stroke="#ffebaa" stroke-width="2.5" stroke-linecap="round"/><path d="M38 36c-7 6 7 8 0 14" fill="none" stroke="#fff9dc" stroke-width="2.5" stroke-linecap="round"/><path d="m16 20 2 4 4 1-4 2-2 4-2-4-4-2 4-1z" fill="#fff1b8"/></svg>',
    'magal-touba' => '<svg viewBox="0 0 76 76" aria-hidden="true"><path d="M9 67V38h8V22h4V9h4v13h4v16h8v-8h5v-8h4v8h5v8h7V20h4V7h4v13h4v18h6v29z" fill="#e6d49b" stroke="#fff0bf" stroke-width="2" stroke-linejoin="round"/><path d="M28 67V48q0-12 10-18 10 6 10 18v19zm25 0V50q0-8 8-12 8 4 8 12v17z" fill="#507b68"/><path d="M34 67V54q0-5 4-5t4 5v13m19 0V54q0-4 4-4t4 4v13" fill="#f6dfa0"/></svg>',
    'tamkharit' => '<svg viewBox="0 0 76 76" aria-hidden="true"><path d="M13 30h50l-5 28q-2 9-20 9T18 58z" fill="#7b4e3e" stroke="#e7c08b" stroke-width="2.5"/><path d="M17 36h42M21 45h34" stroke="#d69b61" stroke-width="3" stroke-linecap="round"/><path d="M38 5v18m-9-9h18m-15-6 12 12m0-12L32 20" stroke="#f3d36f" stroke-width="2.5" stroke-linecap="round"/><circle cx="24" cy="52" r="2" fill="#f3d36f"/><circle cx="51" cy="55" r="2" fill="#f3d36f"/><path d="M29 68v4m18-4v4" stroke="#e7c08b" stroke-width="2.5" stroke-linecap="round"/></svg>',
];

function slug(string $s): string {
    $s = strtr(mb_strtolower($s, 'UTF-8'), [
        'à'=>'a','â'=>'a','ä'=>'a','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
        'î'=>'i','ï'=>'i','ô'=>'o','ö'=>'o','ù'=>'u','û'=>'u','ü'=>'u','ç'=>'c',
    ]);
    return trim(preg_replace('/[^a-z0-9]+/', '-', $s), '-');
}

// --- Catégories du bandeau : lues dans la table `categories` ---
$categoriesBandeau = [];
try {
    // Réutilise la connexion PDO déjà ouverte par le modèle Abonnement
    $rp = new ReflectionProperty($abonnementModel, 'conn');
    $rp->setAccessible(true);
    $pdo = $rp->getValue($abonnementModel);
    $categoriesBandeau = $pdo->query("SELECT id, nom FROM categories ORDER BY nom")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $ex) {
    error_log('Bandeau catégories : ' . $ex->getMessage());
}

// --- Domaines (catégories « parentes ») avec leur nombre de services ---
$domaines = [];
try {
    if (isset($pdo)) {
        // Suppose une colonne categories.parent_id (NULL ou 0 pour un domaine)
        $domaines = $pdo->query(
            "SELECT p.id, p.nom, COUNT(c.id) AS nb
             FROM categories p
             LEFT JOIN categories c ON c.parent_id = p.id
             WHERE p.parent_id IS NULL OR p.parent_id = 0
             GROUP BY p.id, p.nom
             ORDER BY p.nom"
        )->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $ex) {
    error_log('Domaines : ' . $ex->getMessage());
}
if (empty($domaines)) { // Secours si la requête échoue
    $domaines = [
        ['nom' => 'Auto/Deux-Roues',     'nb' => 5],
        ['nom' => 'Digital',             'nb' => 6],
        ['nom' => 'Froid/Climatisation', 'nb' => 5],
        ['nom' => 'Habitat',             'nb' => 9],
        ['nom' => 'Juridique/Admin',     'nb' => 4],
        ['nom' => 'Personnes & Biens',   'nb' => null],
    ];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Services du quotidien à Dakar | ALLÔ PRO</title>
    <meta name="description" content="Plomberie, électricité, climatisation, informatique et petits travaux à Dakar : décrivez votre besoin, suivez votre demande, payez par Wave ou Orange Money.">
    <link rel="stylesheet" href="css/index.css?v=<?= filemtime(__DIR__ . '/css/index.css') ?>">
    <link rel="icon" type="image/png" href="images/icon.png">
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>

<div class="progres" id="progres"></div>
<nav class="nav" id="nav">
    <a href="index.php" class="nav__logo" aria-label="ALLÔ PRO — Accueil"><span class="nav__logo-mark" aria-hidden="true"><?= ico('<path d="M4 12h4l2.2-6 3.6 12 2.2-6H20"/><circle cx="12" cy="12" r="10"/>') ?></span><span class="nav__logo-word">ALLÔ<span> PRO</span></span></a>
    <button type="button" class="nav__menu-toggle" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="nav-liens">
        <span></span><span></span><span></span>
    </button>
    <div class="nav__liens" id="nav-liens">
        <a href="#comment-ca-marche">Comment ça marche</a>
        <a href="#services">Services</a>
        <a href="#abonnement">Abonnement</a>
        <a href="#questions">FAQ</a>
        <?php if ($connecte): ?>
            <a href="dashboard.php" class="nav__bouton">Mon espace</a>
        <?php else: ?>
            <a href="connexion.php">Connexion</a>
            <a href="inscription.php" class="nav__bouton">S'inscrire</a>
        <?php endif; ?>
    </div>
</nav>

<header class="hero">
    <span class="blob blob--a"></span><span class="blob blob--b"></span>
    <div class="hero__grille">
        <div class="hero__texte">
            <?php if (!empty($activeEventTheme['greetingEnabled']) && !empty($activeEventTheme['greetingMessage'])): ?>
                <?php $illustrationSouhait = $illustrationsSouhait[$activeEventTheme['slug']] ?? ''; ?>
                <section class="souhait-evenement<?= $illustrationSouhait !== '' ? ' souhait-evenement--illustration' : '' ?>" aria-label="<?= $e($activeEventTheme['name']) ?>" role="status">
                    <?php if ($illustrationSouhait !== ''): ?>
                        <span class="souhait-evenement__illustration" aria-hidden="true"><?= $illustrationSouhait ?></span>
                    <?php endif; ?>
                    <span class="souhait-evenement__evenement"><?= $e($activeEventTheme['name']) ?></span>
                    <p><?= $e($activeEventTheme['greetingMessage']) ?></p>
                </section>
            <?php endif; ?>
            <span class="hero__badge"><?= ico(ICO_PIN) ?> Services du quotidien à Dakar</span>
            <h1 class="hero__titre"><span>Un souci à régler&nbsp;?</span><span class="hero__titre-accent">On organise la suite.</span></h1>
            <p>Plomberie, électricité, climatisation, informatique, petits travaux : décrivez votre besoin, notre équipe vous accompagne et vous suivez chaque étape depuis votre espace.</p>
            <div class="hero__actions">
                <a href="<?= $lienDemande ?>" class="btn btn--primaire"><?= $derniereDemande ? 'Nouvelle intervention' : 'Décrire mon besoin' ?><span aria-hidden="true">→</span></a>
                <a href="#comment-ca-marche" class="btn btn--ghost"><?= ico(ICO_CHEVRON) ?> Découvrir le parcours</a>
            </div>
            <ul class="hero__points">
                <li><?= ico(ICO_CHECK) ?> Sans abonnement obligatoire</li>
                <li><?= ico(ICO_CHECK) ?> Suivi dans votre espace</li>
                <li><?= ico(ICO_CHECK) ?> Wave &amp; Orange Money</li>
            </ul>
        </div>

        <aside class="suivi" aria-label="Illustration du suivi d'une demande">
            <div class="suivi__marque" aria-hidden="true"><?= ico('<path d="M4 12h4l2.2-6 3.6 12 2.2-6H20"/><circle cx="12" cy="12" r="10"/>') ?></div>
            <div class="suivi__tete"><span>Exemple de suivi</span><b><i aria-hidden="true"></i> En cours</b></div>
            <div class="suivi__separateur"></div>
            <div class="suivi__titre">Fuite sous l’évier</div>
            <div class="suivi__meta"><?= iconeCategorie('Plomberie') ?> Plomberie <span aria-hidden="true">·</span> Dakar</div>
            <ol class="suivi__etapes">
                <li class="ok"><span class="suivi__etape-icone"><?= ico(ICO_CHECK) ?></span><span><strong>Demande envoyée</strong><small>Votre besoin est bien reçu</small></span></li>
                <li class="ok"><span class="suivi__etape-icone"><?= ico(ICO_MSG) ?></span><span><strong>Prise en charge</strong><small>Un conseiller vous accompagne</small></span></li>
                <li class="now"><span class="suivi__etape-icone"><?= ico(ICO_PIN) ?></span><span><strong>Intervention planifiée</strong><small>Suivez les prochaines étapes</small></span></li>
            </ol>
            <span class="suivi__note"><?= ico(ICO_MSG) ?> Échangez avec l’équipe depuis votre espace client</span>
        </aside>
        <div class="event-tree" data-noel-tree aria-hidden="true" hidden></div>
    </div>
</header>

<?php if (!empty($categoriesBandeau)):
    $groupe = $categoriesBandeau;
    while (count($groupe) < 8) { $groupe = array_merge($groupe, $categoriesBandeau); }
?>
<div class="bandeau" aria-hidden="true">
    <div class="bandeau__piste" style="animation-duration: <?= max(30, (int) (count($groupe) * 3.5)) ?>s">
        <?php for ($copie = 0; $copie < 2; $copie++): foreach ($groupe as $cat): ?>
            <span><?= iconeCategorie($cat['nom']) ?><?= $e($cat['nom']) ?></span>
        <?php endforeach; endfor; ?>
    </div>
</div>
<?php endif; ?>

<section class="section" id="comment-ca-marche">
    <div class="conteneur">
        <span class="tag reveal">Le processus</span>
        <h2 class="titre reveal">De la demande au suivi, en 4 étapes</h2>
        <div class="etapes">
            <div class="carte reveal"><span class="num">01</span><h3>Décrivez le problème</h3><p>Catégorie, description, urgence et adresse. La photo est facultative.</p></div>
            <div class="carte reveal d1"><span class="num">02</span><h3>Un conseiller prend le relais</h3><p>Votre demande est examinée et son traitement organisé selon vos informations.</p></div>
            <div class="carte reveal d2"><span class="num">03</span><h3>Gardez le fil</h3><p>Consultez l'évolution et échangez avec l'équipe depuis votre espace client.</p></div>
            <div class="carte reveal d3"><span class="num">04</span><h3>Choisissez le paiement</h3><p>Wave ou Orange Money après l'intervention, ou un Pass / crédit applicable.</p></div>
        </div>
    </div>
</section>

<section class="section section--alt" id="services">
    <div class="conteneur">
        <span class="tag reveal">Nos domaines</span>
        <h2 class="titre reveal">Pour quoi pouvez-vous déposer une demande ?</h2>
        <div class="services">
            <?php foreach ($domaines as $i => $d):
                $img = photoDomaine($d['nom']);
                $nb = isset($d['nb']) ? (int) $d['nb'] : 0;
                // Connecté : comportement actuel. Non connecté : page du domaine.
                $lienDomaine = $connecte ? $lienDemande : 'domaine.php?d=' . slug($d['nom']);
            ?>
                <a href="<?= $e($lienDomaine) ?>" class="photo <?= $img ? '' : 'photo--icone' ?> reveal <?= $i % 3 ? 'd' . ($i % 3) : '' ?>">
                    <?php if ($img): ?>
                        <img loading="lazy" src="<?= $img ?>" alt="<?= $e($d['nom']) ?>">
                    <?php else: ?>
                        <span class="photo__ico" aria-hidden="true"><?= iconeCategorie($d['nom']) ?></span>
                    <?php endif; ?>
                    <span class="photo__badge" aria-hidden="true"><?= iconeCategorie($d['nom']) ?></span>
                    <div class="photo__txt">
                        <strong><?= $e($d['nom']) ?></strong>
                        <?php if ($nb > 0): ?><span class="photo__nb"><?= $nb ?> service<?= $nb > 1 ? 's' : '' ?></span><?php endif; ?>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section" id="garanties">
    <div class="conteneur">
        <span class="tag reveal">Pourquoi ALLÔ PRO</span>
        <h2 class="titre reveal">Un parcours clair, du début à la fin</h2>
        <div class="trio">
            <article class="carte reveal"><span class="num">Demande</span><h3>Les bonnes informations</h3><p>Catégorie, problème, urgence, adresse, et une photo si elle aide à préciser le besoin.</p></article>
            <article class="carte reveal d1"><span class="num">Accompagnement</span><h3>Une équipe qui répond</h3><p>Un conseiller prend en charge la demande et vous accompagne depuis votre espace client.</p></article>
            <article class="carte reveal d2"><span class="num">Suivi</span><h3>Tout au même endroit</h3><p>Statut, messagerie et informations de l'intervention : retrouvez tout sans chercher.</p></article>
        </div>
    </div>
</section>

<section class="section section--alt" id="abonnement">
    <div class="conteneur">
        <span class="tag reveal">Pour les besoins réguliers</span>
        <h2 class="titre reveal">Des formules selon votre rythme</h2>
        <p class="intro reveal">Comparez le tarif, le nombre de crédits et les catégories couvertes.</p>

        <div class="pricing">
            <?php foreach ($formulesAccueil as $i => $f):
                $catsEligibles = $abonnementModel->getCategoriesEligibles($f['id']);
                $lienFormule = 'connexion.php'; $texteLien = 'Se connecter';
                if ($connecte) {
                    if ($role === 'admin') { $lienFormule = '../views/admin/abonnements.php'; $texteLien = 'Gérer'; }
                    else { $lienFormule = '../views/client/abonnement.php'; $texteLien = 'Souscrire'; }
                }
                $vedette = count($formulesAccueil) > 2 && $i === 1;
                $nb = (int) $f['nombre_credits'];
            ?>
                <article class="offre reveal <?= $vedette ? 'offre--vedette' : '' ?>">
                    <?php if ($vedette): ?><span class="offre__badge">Populaire</span><?php endif; ?>
                    <h3><?= $e($f['nom']) ?></h3>
                    <div class="offre__prix"><?= number_format((float) $f['prix'], 0, ',', ' ') ?> <small>FCFA / mois</small></div>
                    <p><?= $e($f['description']) ?></p>
                    <ul>
                        <li>✓ <?= $nb ?> crédit<?= $nb > 1 ? 's' : '' ?> d’intervention</li>
                        <li>✓ <?= empty($catsEligibles) ? 'Toutes catégories de service' : implode(', ', array_map(fn($c) => $e($c['nom']), $catsEligibles)) ?></li>
                        <li>✓ Paiement par Wave ou Orange Money</li>
                    </ul>
                    <a href="<?= $lienFormule ?>" class="btn <?= $vedette ? 'btn--primaire' : 'btn--ghost-fonce' ?>"><?= $texteLien ?></a>
                </article>
            <?php endforeach; ?>
        </div>

        <?php if (empty($formulesAccueil)): ?>
            <div class="vide">
                <p>Aucune formule d’abonnement n’est disponible pour le moment.</p>
                <a href="<?= $lienDemande ?>">Vous pouvez tout de même demander une intervention à l’unité.</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="section" id="questions">
    <div class="conteneur conteneur--etroit">
        <span class="tag reveal">À savoir</span>
        <h2 class="titre reveal">Questions fréquentes</h2>
        <div class="faq reveal">
            <details><summary>Comment demander une intervention ?</summary><p>Créez votre compte, puis indiquez la catégorie, la description du problème, son urgence et l’adresse. Une photo peut être jointe, sans obligation.</p></details>
            <details><summary>Dois-je prendre un abonnement ?</summary><p>Non. Vous pouvez demander une intervention et payer après. Les abonnements et Pass sont une option pour utiliser des crédits prépayés.</p></details>
            <details><summary>Quelle différence entre un Pass et un abonnement ?</summary><p>Un Pass couvre une intervention dans la catégorie indiquée. Un abonnement propose plusieurs crédits et peut être limité à certaines catégories. Vérifiez les détails avant de choisir.</p></details>
            <details><summary>Comment régler une intervention ?</summary><p>Après l’intervention, par Wave ou Orange Money. Si votre abonnement ou Pass couvre la catégorie, vous pouvez aussi l’utiliser.</p></details>
            <details><summary>Où suivre ma demande ?</summary><p>Dans votre espace client : statut, détails et messagerie avec l’équipe.</p></details>
        </div>
    </div>
</section>

<section class="cta">
    <div class="conteneur">
        <h2>Un besoin à signaler ?</h2>
        <p>Créez une demande et suivez-la depuis votre espace client.</p>
        <a href="<?= $connecte ? 'dashboard.php' : 'inscription.php' ?>" class="btn btn--blanc"><?= $connecte ? 'Accéder à mon espace' : 'Créer mon compte' ?></a>
    </div>
</section>

<footer class="footer">
    <div class="footer__grille">
        <div>
            <div class="footer__titre">ALLÔ PRO</div>
            <p>Un point d’entrée pour organiser vos interventions à Dakar et suivre vos demandes.</p>
        </div>
        <div>
            <div class="footer__titre">Services</div>
            <ul>
                <li><a href="#services">Catégories</a></li>
                <li><a href="#comment-ca-marche">Comment ça marche</a></li>
                <li><a href="#abonnement">Formules</a></li>
                <li><a href="#questions">FAQ</a></li>
            </ul>
        </div>
        <div>
            <div class="footer__titre">Nous contacter</div>
            <ul>
                <li><a href="contact.php">Écrire au support</a></li>
                <li><a href="inscription-partenaire.php">Devenir partenaire</a></li>
                <li>Dakar, Sénégal</li>
            </ul>
        </div>
        <div>
            <div class="footer__titre">Accès rapide</div>
            <ul>
                <li><a href="#garanties">Notre approche</a></li>
                <li><a href="<?= $connecte ? 'dashboard.php' : 'connexion.php' ?>">Espace client</a></li>
            </ul>
        </div>
    </div>

    <div class="footer__bas">© <?= date('Y') ?> ALLÔ PRO. Tous droits réservés.</div>
    <div class="event-snowman" data-noel-snowman aria-hidden="true" hidden></div>
</footer>

<script>
try {
    // Filet de sécurité : le contenu redevient visible si le script plante
    setTimeout(() => document.documentElement.classList.add('js-echec'), 2000);

    const nav = document.getElementById('nav');
    const onScroll = () => nav.classList.toggle('nav--scrolled', window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    const bouton = document.querySelector('.nav__menu-toggle');
    const liens = document.getElementById('nav-liens');
    if (bouton && liens) {
        const set = ouvert => {
            nav.classList.toggle('nav--menu-ouvert', ouvert);
            bouton.setAttribute('aria-expanded', String(ouvert));
            bouton.setAttribute('aria-label', ouvert ? 'Fermer le menu' : 'Ouvrir le menu');
        };
        bouton.addEventListener('click', () => set(bouton.getAttribute('aria-expanded') !== 'true'));
        liens.querySelectorAll('a').forEach(a => a.addEventListener('click', () => set(false)));
        document.addEventListener('click', ev => { if (!nav.contains(ev.target)) set(false); });
        document.addEventListener('keydown', ev => { if (ev.key === 'Escape') { set(false); bouton.focus(); } });
    }

    const obs = new IntersectionObserver(entries => {
        entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('visible'); obs.unobserve(en.target); } });
    }, { threshold: 0.15 });
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));

    const calme = matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Barre de progression de lecture
    const barre = document.getElementById('progres');
    const majBarre = () => {
        const h = document.documentElement;
        barre.style.transform = 'scaleX(' + (h.scrollTop / ((h.scrollHeight - h.clientHeight) || 1)) + ')';
    };
    window.addEventListener('scroll', majBarre, { passive: true });
    majBarre();

    // Lien du menu actif selon la section visible
    const liensNav = [...liens.querySelectorAll('a[href^="#"]')];
    const suivi = new IntersectionObserver(es => es.forEach(en => {
        if (en.isIntersecting) liensNav.forEach(a => a.classList.toggle('actif', a.getAttribute('href') === '#' + en.target.id));
    }), { rootMargin: '-40% 0px -55% 0px' });
    document.querySelectorAll('section[id]').forEach(s => suivi.observe(s));

    // Halo lumineux qui suit la souris sur les cartes
    document.querySelectorAll('.carte, .offre').forEach(el => el.addEventListener('pointermove', ev => {
        const r = el.getBoundingClientRect();
        el.style.setProperty('--mx', (ev.clientX - r.left) + 'px');
        el.style.setProperty('--my', (ev.clientY - r.top) + 'px');
    }));

    if (!calme) {
        // Léger effet de profondeur sur les formes du haut
        const blobs = document.querySelectorAll('.blob');
        window.addEventListener('scroll', () => blobs.forEach((b, i) => b.style.translate = '0 ' + (window.scrollY * (0.12 + i * 0.1)) + 'px'), { passive: true });
    }
} catch (err) {
    console.error('Erreur script index.php :', err);
    document.documentElement.classList.add('js-echec');
}
</script>
</body>
</html>