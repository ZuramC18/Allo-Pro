<?php
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../models/AppelWeb.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/AutorisationAppelTechnicien.php';

function repondreAppel(array $donnees, int $statut = 200): void {
    http_response_code($statut);
    echo json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (!isset($_SESSION['user_id']) && !isset($_SESSION['technicien_id'])) {
    repondreAppel(['erreur' => 'Votre session a expiré. Reconnectez-vous.'], 401);
}

$estTechnicien = isset($_SESSION['technicien_id'])
    && (($_POST['acteur_role'] ?? '') === 'technicien' || !isset($_SESSION['user_id']));
if (!$estTechnicien) rafraichirCompteConnecte();
$userId = $estTechnicien ? 0 : (int) ($_SESSION['user_id'] ?? 0);
$technicienId = $estTechnicien ? (int) $_SESSION['technicien_id'] : null;
$role = $estTechnicien ? 'technicien' : (string) ($_SESSION['role'] ?? '');
$action = (string) ($_POST['action'] ?? '');
if (!$userId && !$technicienId) {
    repondreAppel(['erreur' => 'Votre session a expiré. Reconnectez-vous.'], 401);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    repondreAppel(['erreur' => 'Méthode non autorisée.'], 405);
}
if ($estTechnicien && !in_array($action, ['autorisation_mission', 'creer', 'terminer', 'signal', 'poll'], true)) {
    repondreAppel(['erreur' => 'Action non autorisée.'], 403);
}

if ($role !== 'client') {
    if (!$estTechnicien && !peut('messagerie')) repondreAppel(['erreur' => 'Accès refusé à la messagerie.'], 403);
} elseif (!in_array($action, ['presence', 'repondre', 'refuser', 'signal', 'terminer', 'poll'], true)) {
    repondreAppel(['erreur' => 'Action non autorisée.'], 403);
}

if ($action !== 'presence') {
    $cleCsrf = $estTechnicien ? 'csrf_technicien_mission' : 'csrf';
    $csrfSession = (string) ($_SESSION[$cleCsrf] ?? '');
    $csrf = (string) ($_POST['csrf'] ?? '');
    if ($csrfSession === '' || !hash_equals($csrfSession, $csrf)) {
        repondreAppel(['erreur' => 'Jeton de sécurité invalide. Rechargez la page.'], 403);
    }
}

try {
    $appels = new AppelWeb();
    $autorisationsTechnicien = new AutorisationAppelTechnicien();
    $users = new User();

    if ($estTechnicien) {
        $stmtTechnicien = (new Database())->getConnection()->prepare(
            "SELECT statut FROM techniciens WHERE id = :id"
        );
        $stmtTechnicien->execute([':id' => $technicienId]);
        if ($stmtTechnicien->fetchColumn() !== 'actif') {
            unset($_SESSION['technicien_id'], $_SESSION['technicien_nom']);
            repondreAppel(['erreur' => 'Votre session technicien est invalide. Reconnectez-vous.'], 401);
        }
    }

    if ($action === 'autorisation_mission') {
        if (!$estTechnicien) repondreAppel(['erreur' => 'Action réservée au technicien.'], 403);
        $interventionId = filter_var($_POST['intervention_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!$interventionId) repondreAppel(['erreur' => 'Mission invalide.'], 400);
        repondreAppel(['ok' => true, 'autorise' => $autorisationsTechnicien->estAutorise($interventionId, $technicienId)]);
    }

    if ($action === 'presence') {
        if ($role !== 'client') repondreAppel(['erreur' => 'Action réservée au client.'], 403);
        $appels->actualiserPresence($userId, $role);
        repondreAppel(['ok' => true, 'appel' => $appels->appelEntrant($userId)]);
    }

    if ($action === 'creer') {
        if ($role === 'client') repondreAppel(['erreur' => 'Le client ne peut pas initier un appel.'], 403);
        $clientId = filter_var($_POST['client_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!$clientId) repondreAppel(['erreur' => 'Client invalide.'], 400);

        $missionAutoriseeId = null;
        if ($estTechnicien) {
            $missionAutoriseeId = filter_var($_POST['intervention_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            $clientAutoriseId = $missionAutoriseeId
                ? $autorisationsTechnicien->clientPourMissionAutorisee($missionAutoriseeId, $technicienId)
                : null;
            if ($clientAutoriseId === null || $clientAutoriseId !== (int) $clientId) {
                repondreAppel(['erreur' => 'L’autorisation d’appel web pour cette mission est absente ou a été révoquée.'], 403);
            }
        }

        $client = $users->getById($clientId);
        if (!$client || ($client['role'] ?? '') !== 'client') {
            repondreAppel(['erreur' => 'Client introuvable.'], 404);
        }
        if ($role === 'conseiller' && (int) $users->getConseillerAssigne($clientId) !== $userId) {
            repondreAppel(['erreur' => 'Cette conversation ne vous est pas affectée.'], 403);
        }
        if (!$appels->clientDisponible($clientId)) {
            repondreAppel(['erreur' => 'Le client doit être connecté à sa messagerie pour recevoir un appel web.'], 409);
        }
        if ($estTechnicien) $appels->actualiserPresence(0, $role, $technicienId);
        else $appels->actualiserPresence($userId, $role);
        try {
            $appelId = $appels->creer(
                $clientId,
                $estTechnicien ? null : $userId,
                $role,
                $technicienId,
                $missionAutoriseeId
            );
        } catch (DomainException $exception) {
            repondreAppel(['erreur' => $exception->getMessage()], 409);
        }
        repondreAppel(['ok' => true, 'appel_id' => $appelId]);
    }

    $appelId = filter_var($_POST['appel_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!$appelId) repondreAppel(['erreur' => 'Appel invalide.'], 400);
    $appel = $appels->obtenir($appelId);
    if (!$appel) repondreAppel(['erreur' => 'Appel introuvable.'], 404);

    $coteClient = $role === 'client';
    $acteurEstAppelant = $estTechnicien
        ? (int) ($appel['appelant_technicien_id'] ?? 0) === $technicienId
        : (int) ($appel['appelant_id'] ?? 0) === $userId;
    if (($coteClient && (int) $appel['client_id'] !== $userId)
        || (!$coteClient && !$acteurEstAppelant)) {
        repondreAppel(['erreur' => 'Vous ne participez pas à cet appel.'], 403);
    }
    if ($estTechnicien && $action !== 'terminer'
        && (!$appel['intervention_id']
            || !$autorisationsTechnicien->estAutorise((int) $appel['intervention_id'], $technicienId))) {
        repondreAppel(['erreur' => 'L’autorisation de cette mission a été révoquée.'], 403);
    }
    if (!$coteClient && $role === 'conseiller'
        && (int) $users->getConseillerAssigne((int) $appel['client_id']) !== $userId) {
        repondreAppel(['erreur' => 'Cette conversation ne vous est plus affectée.'], 403);
    }
    if ($estTechnicien) $appels->actualiserPresence(0, $role, $technicienId);
    else $appels->actualiserPresence($userId, $role);
    if ($action === 'poll') $appels->actualiserActivite($appelId);
    $appels->expirerAppelsSansPresence($appelId);
    $appel = $appels->obtenir($appelId);

    if ($action === 'repondre' || $action === 'refuser' || $action === 'terminer') {
        if (!$coteClient && $action !== 'terminer') {
            repondreAppel(['erreur' => 'Action réservée au client.'], 403);
        }
        $nouveauStatut = ['repondre' => 'accepte', 'refuser' => 'refuse', 'terminer' => 'termine'][$action];
        if ($action === 'repondre' && (!$coteClient || $appel['statut'] !== 'sonnerie')) {
            repondreAppel(['erreur' => 'Cet appel ne peut plus être accepté.'], 409);
        }
        $modifie = $appels->changerStatut($appelId, $nouveauStatut, $userId, $coteClient, $technicienId);
        repondreAppel(['ok' => $modifie, 'statut' => $modifie ? $nouveauStatut : $appel['statut']]);
    }

    if ($action === 'signal') {
        $type = (string) ($_POST['type'] ?? '');
        $contenu = (string) ($_POST['contenu'] ?? '');
        $signal = json_decode($contenu);
        $tailleMaximale = $type === 'candidat' ? 8192 : 50000;
        $signalValide = is_object($signal);
        if ($type === 'offre' || $type === 'reponse') {
            $typeAttendu = $type === 'offre' ? 'offer' : 'answer';
            $signalValide = $signalValide
                && ($signal->type ?? null) === $typeAttendu
                && is_string($signal->sdp ?? null);
        } elseif ($type === 'candidat') {
            $signalValide = $signalValide && is_string($signal->candidate ?? null);
        }
        if (!in_array($type, ['offre', 'reponse', 'candidat'], true)
            || !$signalValide
            || strlen($contenu) > $tailleMaximale) {
            repondreAppel(['erreur' => 'Signal WebRTC invalide.'], 400);
        }
        if (($type === 'offre' && ($coteClient || !in_array($appel['statut'], ['sonnerie', 'accepte'], true)))
            || ($type === 'reponse' && (!$coteClient || $appel['statut'] !== 'accepte'))
            || ($type === 'candidat' && !in_array($appel['statut'], ['sonnerie', 'accepte'], true))) {
            repondreAppel(['erreur' => 'Ce signal n’est pas autorisé pour cet appel.'], 409);
        }
        if ($appels->compterSignaux($appelId) >= 256) {
            repondreAppel(['erreur' => 'La limite de signaux pour cet appel est atteinte.'], 429);
        }
        $appels->enregistrerSignal($appelId, $userId, $type, $contenu, $technicienId);
        repondreAppel(['ok' => true]);
    }

    if ($action === 'poll') {
        $apresId = filter_var($_POST['apres_id'] ?? 0, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        $signaux = $appels->signauxDepuis($appelId, $userId, $apresId === false ? 0 : $apresId, $technicienId);
        foreach ($signaux as &$signal) {
            $signal['id'] = (int) $signal['id'];
            $signal['expediteur_id'] = (int) $signal['expediteur_id'];
            $signal['expediteur_technicien_id'] = $signal['expediteur_technicien_id'] === null
                ? null
                : (int) $signal['expediteur_technicien_id'];
            $signal['contenu'] = json_decode($signal['contenu'], true);
        }
        unset($signal);
        repondreAppel(['ok' => true, 'statut' => $appel['statut'], 'signaux' => $signaux]);
    }

    repondreAppel(['erreur' => 'Action inconnue.'], 400);
} catch (Throwable $exception) {
    error_log('[appels web] ' . $exception->getMessage());
    repondreAppel(['erreur' => 'Le service d’appel est momentanément indisponible. Réessayez.'], 500);
}
