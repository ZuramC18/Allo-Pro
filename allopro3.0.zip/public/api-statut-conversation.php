<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

require_once __DIR__ . '/../models/User.php';
$client = (new User())->getById((int) $_SESSION['user_id']);
if (!$client || ($client['role'] ?? '') !== 'client') {
    http_response_code(404);
    echo json_encode(['erreur' => 'Conversation introuvable.']);
    exit;
}

$ouverte = ($client['conversation_statut'] ?? '') === 'ouverte';
$assignee = !empty($client['conseiller_assigne_id']);
echo json_encode([
    'ouverte' => $ouverte,
    'en_attente' => $ouverte && !$assignee,
]);
