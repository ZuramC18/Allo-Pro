<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../models/Notification.php';

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$redirection = is_string($_GET['redirection'] ?? null) ? $_GET['redirection'] : '';

if ($id !== false && $id !== null && $id > 0) {
    (new Notification())->marquerLue($id, (int) $_SESSION['user_id']);
}
$destination = '../client/notifications.php';
if ($redirection !== '') {
    $url = parse_url($redirection);
    $chemin = is_array($url) ? ($url['path'] ?? '') : '';
    if (is_string($chemin) && preg_match('~/views/client/([A-Za-z0-9_-]+\.php)$~', $chemin, $correspondance)) {
        $destination = '../client/' . $correspondance[1];
        if (!empty($url['query'])) {
            $destination .= '?' . $url['query'];
        }
    } elseif (is_string($chemin) && preg_match('~/views/entreprise/membres\.php$~', $chemin)) {
        parse_str((string) ($url['query'] ?? ''), $parametres);
        $entrepriseId = filter_var($parametres['entreprise_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($entrepriseId !== false && $entrepriseId !== null) {
            $destination = '../entreprise/membres.php?entreprise_id=' . (int) $entrepriseId . '&membre_parti=1';
        }
    } elseif (is_string($chemin) && preg_match('~^[A-Za-z0-9_-]+\.php$~', $chemin)) {
        $destination = '../client/' . $chemin;
        if (!empty($url['query'])) {
            $destination .= '?' . $url['query'];
        }
    }
}
header('Location: ' . $destination);
exit;