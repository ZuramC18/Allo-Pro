<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../models/ReponseRapide.php';

header('Content-Type: application/json; charset=utf-8');
verifierConnexion();

function reponseRapideJson(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    reponseRapideJson(['ok' => false, 'erreur' => 'Méthode non autorisée.'], 405);
}
$role = (string) ($_SESSION['role'] ?? '');
if (!in_array($role, ['admin', 'conseiller', 'coordinateur', 'qualite'], true)) {
    reponseRapideJson(['ok' => false, 'erreur' => 'Accès refusé.'], 403);
}
if (empty($_SESSION['csrf']) || !isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'], (string) $_POST['csrf'])) {
    reponseRapideJson(['ok' => false, 'erreur' => 'Requête invalide, rechargez la page.'], 403);
}

$userId = (int) $_SESSION['user_id'];
$gestionnaire = in_array($role, ['admin', 'coordinateur'], true);
$model = new ReponseRapide();
$action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
$lireChamps = static function (): array {
    $titre = trim((string) ($_POST['titre'] ?? ''));
    $contenu = trim((string) ($_POST['contenu'] ?? ''));
    $motsCles = trim((string) ($_POST['mots_cles'] ?? ''));
    $categorie = trim((string) ($_POST['categorie'] ?? ''));
    $motsCles = implode(', ', array_filter(array_map('trim', explode(',', $motsCles)), 'strlen'));
    if ($titre === '' || $contenu === '' || mb_strlen($titre) > 100 || mb_strlen($contenu) > 2000
        || mb_strlen($categorie) > 60 || mb_strlen($motsCles) > 255) {
        reponseRapideJson(['ok' => false, 'erreur' => 'Vérifiez les champs (titre 100, message 2 000 caractères maximum).'], 422);
    }
    return [$titre, $contenu, $motsCles, $categorie];
};

try {
    if ($action === 'creer') {
        [$titre, $contenu, $motsCles, $categorie] = $lireChamps();
        if ($gestionnaire) {
            $model->create($titre, $contenu, $motsCles, $categorie, $role, $userId);
        } else {
            $model->createPrive($titre, $contenu, $motsCles, $categorie, $role, $userId);
        }
    } elseif ($action === 'modifier' || $action === 'supprimer') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        $existante = $id ? $model->getById((int) $id) : false;
        if (!$existante) {
            reponseRapideJson(['ok' => false, 'erreur' => 'Réponse rapide introuvable.'], 404);
        }
        $estPriveePropre = (int) ($existante['est_prive'] ?? 0) === 1
            && (string) $existante['cree_par_type'] === $role
            && (int) $existante['cree_par_id'] === $userId;
        $estPartageeGerable = (int) ($existante['est_prive'] ?? 0) === 0 && $gestionnaire;
        if (!$estPriveePropre && !$estPartageeGerable) {
            reponseRapideJson(['ok' => false, 'erreur' => 'Vous ne pouvez modifier que vos réponses privées ou les réponses partagées autorisées.'], 403);
        }
        if ($action === 'supprimer') {
            if ($estPriveePropre) {
                $model->supprimerPrive((int) $id, $role, $userId);
            } else {
                $model->supprimer((int) $id);
            }
        } else {
            [$titre, $contenu, $motsCles, $categorie] = $lireChamps();
            if ($estPriveePropre) {
                $model->modifierPrive((int) $id, $titre, $contenu, $motsCles, $categorie, $role, $userId);
            } else {
                $model->modifier((int) $id, $titre, $contenu, $motsCles, $categorie);
            }
        }
    } else {
        reponseRapideJson(['ok' => false, 'erreur' => 'Action inconnue.'], 400);
    }
    reponseRapideJson([
        'ok' => true,
        'reponses' => $model->getVisiblePour($role, $userId),
    ]);
} catch (PDOException $exception) {
    error_log('Réponses rapides utilisateur ' . $userId . ' : ' . $exception->getMessage());
    reponseRapideJson(['ok' => false, 'erreur' => 'Enregistrement impossible. Réessayez.'], 500);
}
