<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);
require_once __DIR__ . '/../models/EntrepriseB2B.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

$nom = is_string($_GET['nom'] ?? null) ? trim($_GET['nom']) : '';
if (mb_strlen($nom) < 2 || mb_strlen($nom) > 150) {
    http_response_code(422);
    echo json_encode([
        'disponible' => false,
        'message' => 'Saisissez un nom entre 2 et 150 caractères.',
    ]);
    exit;
}

try {
    $existe = (new EntrepriseB2B())->nomExiste($nom);
    echo json_encode([
        'disponible' => !$existe,
        'message' => $existe ? 'Une entreprise porte déjà ce nom.' : 'Ce nom est disponible.',
    ]);
} catch (Throwable $exception) {
    error_log('Vérification disponibilité nom entreprise : ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode([
        'disponible' => false,
        'message' => 'Vérification indisponible. Réessayez.',
    ]);
}
