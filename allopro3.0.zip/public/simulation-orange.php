<?php
$reference = $_GET['reference'] ?? null;
$montant = $_GET['montant'] ?? 0;

$type = $_GET['type'] ?? 'intervention';
$webhooks = ['abonnement' => 'webhook-abonnement.php', 'pass' => 'webhook-pass.php'];
$webhook = $webhooks[$type] ?? 'webhook-paiement.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header("Location: {$webhook}?reference=" . urlencode($reference) . "&depuis_client=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Orange Money — Paiement</title>
    <link rel="icon" type="image/png" href="images/icon.png">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', Arial, sans-serif; }
        body { background: #1C1C1C; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .carte { background: white; border-radius: 16px; padding: 32px; width: 100%; max-width: 360px; }
        .logo { display: flex; align-items: center; gap: 10px; margin-bottom: 28px; }
        .logo__icone { width: 34px; height: 34px; background: #FF7900; border-radius: 8px; }
        .logo__texte { font-weight: 700; font-size: 18px; color: #1C1C1C; }
        .logo__texte span { color: #FF7900; }
        .montant-bloc { text-align: center; margin-bottom: 28px; }
        .montant-bloc__label { font-size: 13px; color: #6B7280; margin-bottom: 4px; }
        .montant-bloc__valeur { font-size: 30px; font-weight: 700; color: #1C1C1C; }
        .reference { font-size: 12px; color: #9CA3AF; text-align: center; margin-bottom: 24px; }
        label { font-size: 13px; font-weight: 500; display: block; margin-bottom: 6px; color: #1C1C1C; }
        input { width: 100%; padding: 12px 14px; border: 1px solid #E2DFD8; border-radius: 8px; font-size: 15px; margin-bottom: 16px; }
        button { width: 100%; padding: 14px; background: #FF7900; color: white; border: none; border-radius: 8px; font-weight: 700; font-size: 15px; cursor: pointer; }
        .note { font-size: 12px; color: #9CA3AF; text-align: center; margin-top: 16px; }
    </style>
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>
    <div class="carte">
        <div class="logo">
            <div class="logo__icone"></div>
            <div class="logo__texte">orange <span>money</span></div>
        </div>

        <div class="montant-bloc">
            <div class="montant-bloc__label">Montant à payer</div>
            <div class="montant-bloc__valeur"><?= number_format($montant, 0, ',', ' ') ?> FCFA</div>
        </div>
        <div class="reference">Réf. <?= htmlspecialchars($reference) ?></div>

        <form method="POST">
            <label>Numéro Orange Money</label>
            <input type="tel" placeholder="77 000 00 00" required>
            <label>Code secret</label>
            <input type="password" placeholder="••••" maxlength="4" required>
            <button type="submit">Confirmer le paiement</button>
        </form>

        <div class="note">Simulation — aucune vraie transaction n'est effectuée</div>
    </div>
</body>
</html>