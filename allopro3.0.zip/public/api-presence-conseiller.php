<?php
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

if (!in_array($_SESSION['role'] ?? '', ['conseiller', 'coordinateur', 'finance'], true)) {
    http_response_code(403);
    echo json_encode(['erreur' => 'Accès réservé aux membres de l’équipe concernés.']);
    exit;
}

require_once __DIR__ . '/../models/User.php';
$userModel = new User();
$userId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $presence = $userModel->actualiserPresenceEquipe($userId);
    if (!$presence) {
        http_response_code(403);
        echo json_encode(['erreur' => 'Compte inactif ou introuvable.']);
        exit;
    }
    echo json_encode($presence);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: GET, POST');
    http_response_code(405);
    echo json_encode(['erreur' => 'Méthode non autorisée.']);
    exit;
}

$csrfSession = (string) ($_SESSION['csrf'] ?? '');
$csrfRecu = (string) ($_POST['csrf'] ?? '');
if ($csrfSession === '' || !hash_equals($csrfSession, $csrfRecu)) {
    http_response_code(403);
    echo json_encode(['erreur' => 'Jeton de sécurité invalide.']);
    exit;
}

$action = $_POST['action'] ?? '';
if ($action === 'heartbeat') {
    $presence = $userModel->actualiserPresenceEquipe($userId);
} elseif ($action === 'status') {
    $statut = $_POST['status'] ?? '';
    if (!in_array($statut, ['online', 'pause', 'offline'], true)) {
        http_response_code(422);
        echo json_encode(['erreur' => 'Statut de présence invalide.']);
        exit;
    }
    $presenceAvant = $userModel->getPresenceEquipe($userId);
    $userModel->definirPresenceEquipe($userId, $statut);
    $presence = $userModel->getPresenceEquipe($userId);
    if ($presence && ($presenceAvant['presence_status'] ?? null) !== $statut) {
        require_once __DIR__ . '/../models/ActiviteConseiller.php';
        $libellesPresence = ['online' => 'En ligne', 'pause' => 'En pause', 'offline' => 'Hors ligne'];
        ActiviteConseiller::enregistrer(
            'presence',
            $userId,
            $statut,
            'Statut modifié : ' . $libellesPresence[$presenceAvant['presence_status'] ?? 'offline'] . ' → ' . $libellesPresence[$statut]
        );
    }
} else {
    http_response_code(400);
    echo json_encode(['erreur' => 'Action de présence inconnue.']);
    exit;
}

if (!$presence) {
    http_response_code(403);
    echo json_encode(['erreur' => 'Compte inactif ou introuvable.']);
    exit;
}

echo json_encode($presence);
