<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['admin']);
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

try {
    $connexion = (new Database())->getConnection();
    $compteurs = [
        'demandes' => 0,
        'refus' => 0,
        'devis' => 0,
        'remboursements' => 0,
    ];

    if (peut('demandes')) {
        $compteurs['demandes'] = (int) $connexion
            ->query("SELECT COUNT(*) FROM demandes WHERE statut = 'nouvelle'")
            ->fetchColumn();
    }
    if (peut('interventions')) {
        $compteurs['refus'] = (int) $connexion
            ->query("SELECT COUNT(*) FROM file_attente_interventions WHERE statut = 'en_attente'")
            ->fetchColumn();
    }
    if (peut('devis_entreprises')) {
        $compteurs['devis'] = (int) $connexion
            ->query(
                "SELECT COUNT(*) FROM devis_b2b
                 WHERE statut = 'demande'
                   AND qualite_statut IN ('a_traiter', 'a_preciser', 'valide')"
            )
            ->fetchColumn();
    }
    if (peut('remboursements_sav')) {
        $compteurs['remboursements'] = (int) $connexion
            ->query("SELECT COUNT(*) FROM remboursements_sav WHERE statut = 'en_attente'")
            ->fetchColumn();
    }

    echo json_encode($compteurs, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
} catch (Throwable $exception) {
    error_log('Comptage des notifications sidebar admin : ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['erreur' => 'Impossible de récupérer les compteurs de la sidebar.'], JSON_UNESCAPED_UNICODE);
}
