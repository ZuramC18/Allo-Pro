<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../models/Abonnement.php';
require_once __DIR__ . '/dom.php';

$e = static fn($v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

if (!function_exists('slugDomaine')) {
    function slugDomaine(string $s): string {
        $s = mb_strtolower(trim($s), 'UTF-8');
        $s = strtr($s, [
            'à'=>'a','â'=>'a','ä'=>'a','á'=>'a','ã'=>'a',
            'é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
            'î'=>'i','ï'=>'i','í'=>'i',
            'ô'=>'o','ö'=>'o','ó'=>'o',
            'ù'=>'u','û'=>'u','ü'=>'u','ú'=>'u',
            'ç'=>'c','ñ'=>'n','œ'=>'oe','æ'=>'ae'
        ]);
        return trim((string) preg_replace('/[^a-z0-9]+/', '-', $s), '-');
    }
}

$slugDemande = trim((string)($_GET['d'] ?? ''));
$domaine = null;
$services = [];
$erreurBase = false;
$connecte = isset($_SESSION['user_id']);
$contenu = [];
$photo = null;

try {
    $modele = new Abonnement();
    $rp = new ReflectionProperty($modele, 'conn');
    $rp->setAccessible(true);
    $pdo = $rp->getValue($modele);

    $categories = $pdo->query(
        "SELECT id, nom FROM categories WHERE parent_id IS NULL OR parent_id = 0 ORDER BY nom"
    )->fetchAll(PDO::FETCH_ASSOC);

    foreach ($categories as $categorie) {
        if (slugDomaine((string)$categorie['nom']) === $slugDemande) {
            $domaine = $categorie;
            break;
        }
    }

    if ($domaine) {
        $stmt = $pdo->prepare(
            "SELECT id, nom FROM categories WHERE parent_id = ? ORDER BY nom ASC"
        );
        $stmt->execute([(int)$domaine['id']]);
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $ex) {
    $erreurBase = true;
    error_log('domaine.php : ' . $ex->getMessage());
}

/* Contenu de secours : permet de présenter les domaines même si la base est indisponible. */
if (!$domaine) {
    foreach (domainesParDefaut() as $fallback) {
        if (slugDomaine((string)$fallback['nom']) === $slugDemande) {
            $domaine = ['id' => null, 'nom' => $fallback['nom']];
            break;
        }
    }
}

if ($domaine) {
    $contenu = contenuDomaine((string)$domaine['nom']);
    $photo = photoDomaine((string)$domaine['nom'], 1800);

    /* Les services de la base sont prioritaires. Les services éditoriaux complètent
       l'affichage si aucune sous-catégorie n'est enregistrée. */
    if (!$services && !empty($contenu['services'])) {
        $services = array_map(
            static fn($nom) => ['id' => null, 'nom' => $nom],
            $contenu['services']
        );
    }
} else {
    http_response_code(404);
}

$nomDomaine = (string)($domaine['nom'] ?? 'Domaine introuvable');
$accent = (string)($contenu['accent'] ?? '#e85d2a');
$descriptionMeta = (string)($contenu['meta'] ?? 'Découvrez les services ALLÔ PRO à Dakar et faites organiser votre intervention.');
$accroche = (string)($contenu['accroche'] ?? 'Le bon service, au bon moment.');
$intro = (string)($contenu['intro'] ?? 'Décrivez votre besoin : nous vous aidons à organiser la suite.');
$messages = $contenu['messages'] ?? [];
$precisions = $contenu['precisions'] ?? [];
$nbServices = count($services);
$urlDemande = $connecte ? 'dashboard.php' : 'inscription.php';
$urlConnexion = 'connexion.php';
$cssPath = __DIR__ . '/css/index.css';
$cssVersion = is_file($cssPath) ? (string)filemtime($cssPath) : '1';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?= $e($descriptionMeta) ?>">
    <meta name="theme-color" content="<?= $e($accent) ?>">
    <title><?= $domaine ? $e($nomDomaine . ' à Dakar | ALLÔ PRO') : 'Domaine introuvable | ALLÔ PRO' ?></title>
    <link rel="stylesheet" href="css/index.css?v=<?= $e($cssVersion) ?>">
    <link rel="icon" type="image/png" href="images/icon.png">
    <style>
        :root{--domaine-accent:<?= $e($accent) ?>;--domaine-ink:#172033;--domaine-muted:#667085;--domaine-line:#e8ebf0;--domaine-soft:#f6f8fb}
        *{box-sizing:border-box}
        html{scroll-behavior:smooth;scroll-padding-top:100px}
        body{color:var(--domaine-ink);background:#fff}
        .nav {position: fixed;inset: 0 0 auto 0;z-index: 1000;display: flex;align-items: center;
            justify-content: space-between;gap: 24px;padding: 16px max(20px, calc((100% - 1120px) / 2));background: transparent;
            transition: background .25s ease, box-shadow .25s ease;
        }
        .nav--scrolled,
        .nav--menu-ouvert {background: var(--ink, #172033);box-shadow: 0 2px 16px rgba(0, 0, 0, .2);}

        .nav__logo {flex-shrink: 0;font-size: 1.35rem;font-weight: 850;
            letter-spacing: -.5px;
            color: #fff;
            text-decoration: none;
        }

        .nav__logo span {
            color: var(--domaine-accent);
        }

        .nav__liens {
            display: flex;
            align-items: center;
            gap: 22px;
        }

        .nav__liens a {
            color: #e7eef3;
            text-decoration: none;
            font-size: .92rem;
            font-weight: 550;
            transition: color .2s ease;
        }

        .nav__liens a:hover {
            color: #fff;
        }

        .nav__liens .nav__bouton {
            padding: 10px 19px;
            border-radius: 999px;
            background: var(--domaine-accent);
            color: #fff;
            font-weight: 700;
            transition: background .2s ease, transform .2s ease;
        }

        .nav__liens .nav__bouton:hover {
            background: var(--accent-d, #c94a20);
            transform: translateY(-1px);
        }

        /* Bouton du menu mobile */

        .nav__menu-toggle {
            display: none;
            flex-shrink: 0;
            padding: 8px;
            border: 0;
            border-radius: 8px;
            background: transparent;
            cursor: pointer;
        }

        .nav__menu-toggle span {
            display: block;
            width: 25px;
            height: 2px;
            margin: 5px 0;
            border-radius: 2px;
            background: #fff;
            transition: transform .2s ease, opacity .2s ease;
        }

        .nav--menu-ouvert .nav__menu-toggle span:first-child {
            transform: translateY(7px) rotate(45deg);
        }

        .nav--menu-ouvert .nav__menu-toggle span:nth-child(2) {
            opacity: 0;
        }

        .nav--menu-ouvert .nav__menu-toggle span:last-child {
            transform: translateY(-7px) rotate(-45deg);
        }

        /* Tablettes et téléphones */

        @media (max-width: 800px) {
            .nav {
                padding: 14px 20px;
            }

            .nav__menu-toggle {
                display: block;
            }

            .nav__liens {
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;

                display: flex;
                flex-direction: column;
                align-items: stretch;
                gap: 0;

                padding: 8px 20px 20px;
                background: var(--ink, #172033);
                box-shadow: 0 12px 18px rgba(0, 0, 0, .15);

                visibility: hidden;
                opacity: 0;
                transform: translateY(-8px);
                pointer-events: none;

                transition:
                    opacity .2s ease,
                    transform .2s ease,
                    visibility .2s ease;
            }

            .nav--menu-ouvert .nav__liens {
                visibility: visible;
                opacity: 1;
                transform: translateY(0);
                pointer-events: auto;
            }

            .nav__liens a {
                display: block;
                padding: 13px 4px;
            }

            .nav__liens .nav__bouton {
                margin-top: 8px;
                padding: 12px 16px;
                text-align: center;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .nav,
            .nav__liens,
            .nav__menu-toggle span {
                transition: none;
            }
        }
        .dp-hero{position:relative;isolation:isolate;overflow:hidden;min-height:590px;display:flex;align-items:center;padding:145px clamp(20px,8vw,120px) 85px;background:linear-gradient(105deg,rgba(12,20,36,.92),rgba(12,20,36,.76) 48%,rgba(12,20,36,.24)),<?= $photo ? "url('" . $e($photo) . "')" : "linear-gradient(135deg,#172033,#344054)" ?>;background-size:cover;background-position:center}
        .dp-hero:after{content:"";position:absolute;z-index:-1;width:420px;height:420px;border:1px solid rgba(255,255,255,.18);border-radius:50%;right:-90px;bottom:-210px;box-shadow:0 0 0 55px rgba(255,255,255,.035),0 0 0 110px rgba(255,255,255,.025)}
        .dp-hero-content{width:min(780px,100%);color:#fff}.dp-eyebrow{display:inline-flex;align-items:center;gap:9px;padding:8px 12px;border:1px solid rgba(255,255,255,.26);border-radius:999px;background:rgba(255,255,255,.1);font-size:.82rem;font-weight:750;letter-spacing:.04em}
        .dp-dot{width:8px;height:8px;border-radius:50%;background:#8ce0b0;box-shadow:0 0 0 4px rgba(140,224,176,.16)}
        .dp-hero h1{font-size:clamp(2.6rem,6vw,5rem);line-height:1.02;letter-spacing:-.055em;margin:23px 0 20px;color:#fff;max-width:850px}
        .dp-hero h1 em{font-style:normal;color:#fff;text-decoration:underline;text-decoration-color:var(--domaine-accent);text-decoration-thickness:6px;text-underline-offset:8px}
        .dp-hero p{font-size:clamp(1.03rem,1.7vw,1.22rem);line-height:1.8;color:rgba(255,255,255,.84);max-width:680px;margin:0}
        .dp-hero-actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:30px}.dp-btn--light{background:#fff;color:#172033!important}
        .dp-trust{display:flex;flex-wrap:wrap;gap:18px 25px;margin-top:27px;color:rgba(255,255,255,.85);font-size:.88rem}.dp-trust span{display:flex;align-items:center;gap:8px}
        .dp-trust svg{width:17px;height:17px;color:#9fe2b8}
        .dp-wrap{width:min(1160px,calc(100% - 40px));margin-inline:auto}.dp-section{padding:88px 0}.dp-section--soft{background:var(--domaine-soft)}
        .dp-heading{max-width:720px;margin-bottom:34px}.dp-kicker{text-transform:uppercase;letter-spacing:.14em;font-size:.76rem;font-weight:850;color:var(--domaine-accent);margin-bottom:12px}
        .dp-heading h2{font-size:clamp(2rem,4vw,3.1rem);line-height:1.12;letter-spacing:-.045em;margin:0 0 14px;color:var(--domaine-ink)}
        .dp-heading p{color:var(--domaine-muted);line-height:1.8;font-size:1.02rem;margin:0}
        .dp-service-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:17px}
        .dp-service{position:relative;padding:25px;border:1px solid var(--domaine-line);border-radius:18px;background:#fff;min-height:195px;transition:transform .2s,border-color .2s,box-shadow .2s}
        .dp-service:hover{transform:translateY(-4px);border-color:color-mix(in srgb,var(--domaine-accent) 50%,white);box-shadow:0 18px 40px rgba(18,30,50,.07)}
        .dp-service-icon{width:48px;height:48px;display:grid;place-items:center;background:color-mix(in srgb,var(--domaine-accent) 10%,white);color:var(--domaine-accent);border-radius:14px;margin-bottom:19px}
        .dp-service-icon .ico{width:25px;height:25px}.dp-service h3{font-size:1.07rem;margin:0 0 8px;letter-spacing:-.02em}.dp-service p{font-size:.91rem;line-height:1.65;color:var(--domaine-muted);margin:0}
        .dp-count{display:inline-block;margin-top:22px;padding:7px 11px;border-radius:999px;background:#fff;border:1px solid var(--domaine-line);font-size:.82rem;color:#475467}
        .dp-examples{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:17px}
        .dp-example{padding:25px;border-radius:18px;background:#fff;border:1px solid var(--domaine-line);display:flex;flex-direction:column;justify-content:space-between;gap:20px}
        .dp-quote{font-size:1.08rem;line-height:1.65;font-weight:650;letter-spacing:-.015em}.dp-example-foot{display:flex;align-items:center;gap:9px;color:var(--domaine-accent);font-size:.85rem;font-weight:750}
        .dp-example-foot svg{width:18px;height:18px}
        .dp-steps{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:24px;counter-reset:step}
        .dp-step{counter-increment:step;padding:26px 0;border-top:1px solid var(--domaine-line)}
        .dp-step-number{display:grid;place-items:center;width:46px;height:46px;border-radius:14px;background:var(--domaine-accent);color:#fff;font-weight:850;margin-bottom:21px}
        .dp-step h3{font-size:1.15rem;margin:0 0 10px}.dp-step p{margin:0;color:var(--domaine-muted);line-height:1.75}
        .dp-info-layout{display:grid;grid-template-columns:.8fr 1.2fr;gap:60px;align-items:start}
        .dp-checklist{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}
        .dp-check{display:flex;gap:12px;align-items:flex-start;padding:17px;border:1px solid var(--domaine-line);border-radius:14px;background:#fff;color:#475467;line-height:1.55}
        .dp-check svg{width:19px;height:19px;flex:0 0 19px;color:var(--domaine-accent);margin-top:1px}
        .dp-faq{max-width:850px;margin:0 auto}.dp-faq details{border-bottom:1px solid var(--domaine-line);padding:20px 0}
        .dp-faq summary{cursor:pointer;list-style:none;font-weight:750;font-size:1rem;display:flex;align-items:center;justify-content:space-between;gap:18px}
        .dp-faq summary::-webkit-details-marker{display:none}.dp-faq summary:after{content:"+";font-size:1.5rem;color:var(--domaine-accent);font-weight:500}
        .dp-faq details[open] summary:after{content:"−"}.dp-faq details p{color:var(--domaine-muted);line-height:1.8;margin:13px 32px 0 0}
        .dp-cta{position:relative;overflow:hidden;padding:clamp(30px,6vw,65px);border-radius:25px;background:#172033;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:35px}
        .dp-cta:after{content:"";position:absolute;width:300px;height:300px;right:-90px;top:-150px;border-radius:50%;border:55px solid rgba(255,255,255,.045);pointer-events:none}
        .dp-cta-copy{max-width:650px;position:relative;z-index:1}.dp-cta h2{font-size:clamp(1.8rem,4vw,2.8rem);letter-spacing:-.04em;line-height:1.12;margin:0 0 14px;color:#fff}.dp-cta p{color:rgba(255,255,255,.72);line-height:1.75;margin:0}
        .dp-cta .dp-btn{white-space:nowrap;position:relative;z-index:1}
        .dp-footer{padding:50px 0 22px;background:#101827;color:#c7cfdb}.dp-footer-grid{display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:35px;padding-bottom:35px}
        .dp-footer h3{font-size:.95rem;color:#fff;margin:0 0 15px}.dp-footer p{color:#aeb8c7;line-height:1.8;max-width:380px;margin:12px 0}
        .dp-footer ul{list-style:none;margin:0;padding:0;display:grid;gap:11px}.dp-footer a{color:#c7cfdb;text-decoration:none}.dp-footer a:hover{color:#fff}
        .dp-footer-bottom{padding-top:20px;border-top:1px solid rgba(255,255,255,.12);display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;font-size:.85rem;color:#98a5b7}
        .dp-notfound{text-align:center;padding:160px 20px 100px}.dp-notfound h1{font-size:clamp(2rem,5vw,3.5rem)}
        @media(max-width:850px){.dp-service-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.dp-info-layout{grid-template-columns:1fr;gap:28px}.dp-examples{grid-template-columns:1fr}.dp-cta{align-items:flex-start;flex-direction:column}.dp-footer-grid{grid-template-columns:1fr 1fr}}
        @media(max-width:600px){.dp-nav{padding:13px 17px}.dp-navlinks{gap:12px}.dp-navlinks>a:first-child{display:none}.dp-navlinks a{font-size:.82rem}.dp-navlinks .dp-navcta{padding:10px 12px}.dp-hero{min-height:610px;padding:125px 22px 65px;background-position:60% center}.dp-hero h1{font-size:2.75rem}.dp-section{padding:62px 0}.dp-wrap{width:calc(100% - 34px)}.dp-service-grid,.dp-steps,.dp-checklist{grid-template-columns:1fr}.dp-service{min-height:0}.dp-footer-grid{grid-template-columns:1fr}.dp-footer-bottom{flex-direction:column}}
        @media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}*,*:before,*:after{transition:none!important}}
    </style>
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>
<nav class="nav" id="nav">
    <a href="index.php" class="nav__logo">ALLÔ<span> PRO</span></a>

    <button type="button" class="nav__menu-toggle" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="nav-liens">
        <span></span>
        <span></span>
        <span></span>
    </button>

    <div class="nav__liens" id="nav-liens">
        <a href="index.php#services">Tous les domaines</a>
        <a href="#questions">FAQ</a>
        
        <?php if ($connecte): ?>
            <a href="dashboard.php" class="nav__bouton">
                Mon espace
            </a>
        <?php else: ?>
            <a href="connexion.php">Connexion</a>
            <a href="inscription.php" class="nav__bouton">
                S'inscrire
            </a>
        <?php endif; ?>
    </div>
</nav>

<?php if (!$domaine): ?>
    <main class="dp-notfound">
        <p class="dp-kicker">ALLÔ PRO · Dakar</p>
        <h1>Ce domaine est introuvable.</h1>
        <p>Le lien a peut-être changé. Découvrez les domaines disponibles sur ALLÔ PRO.</p>
        <p style="margin-top:25px"><a class="dp-btn" href="index.php#services">Voir tous les domaines</a></p>
    </main>
<?php else: ?>
<main>
    <section class="dp-hero">
        <div class="dp-hero-content">
            <span class="dp-eyebrow"><span class="dp-dot"></span> LES SERVICES ALLÔ PRO · DAKAR</span>
            <h1><?= $e($accroche) ?></h1>
            <p><?= $e($intro) ?></p>
            <div class="dp-hero-actions">
                <a class="dp-btn" href="<?= $e($urlDemande) ?>">Demander une intervention <span aria-hidden="true">→</span></a>
                <a class="dp-btn dp-btn--light" href="#services">Découvrir les services</a>
            </div>
            <div class="dp-trust">
                <span><?= ico(ICO_CHECK) ?> Une demande centralisée</span>
                <span><?= ico(ICO_CHECK) ?> Un suivi en ligne</span>
                <span><?= ico(ICO_PIN) ?> Dakar et environs</span>
            </div>
        </div>
    </section>

    <section class="dp-section" id="services">
        <div class="dp-wrap">
            <div class="dp-heading">
                <div class="dp-kicker">Nos prestations</div>
                <h2>De quoi avez-vous besoin ?</h2>
                <p>Parcourez les services de la catégorie <strong><?= $e($nomDomaine) ?></strong>. Si votre situation ne correspond pas exactement à un intitulé, vous pourrez expliquer votre besoin dans votre demande.</p>
                <span class="dp-count"><?= $nbServices ?> service<?= $nbServices > 1 ? 's' : '' ?> proposé<?= $nbServices > 1 ? 's' : '' ?></span>
            </div>
            <div class="dp-service-grid">
                <?php foreach ($services as $service):
                    $nomService = (string)($service['nom'] ?? '');
                    $description = descriptionService($nomService);
                    if ($description === '') {
                        $description = 'Décrivez votre besoin et les détails utiles : nous vous aidons à organiser la suite.';
                    }
                ?>
                    <article class="dp-service">
                        <div class="dp-service-icon"><?= iconeCategorie($nomService) ?></div>
                        <h3><?= $e($nomService) ?></h3>
                        <p><?= $e($description) ?></p>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <?php if (!empty($messages)): ?>
    <section class="dp-section dp-section--soft">
        <div class="dp-wrap">
            <div class="dp-heading">
                <div class="dp-kicker">Exemples de demandes</div>
                <h2>Vous pouvez commencer simplement.</h2>
                <p>Pas besoin d'être un expert : décrivez la situation avec vos mots. Voici quelques exemples de demandes que vous pouvez formuler.</p>
            </div>
            <div class="dp-examples">
                <?php foreach (array_slice($messages, 0, 3) as $message): ?>
                <article class="dp-example">
                    <div class="dp-quote">« <?= $e($message) ?> »</div>
                    <div class="dp-example-foot"><?= ico(ICO_MSG) ?> Exemple de description</div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <section class="dp-section">
        <div class="dp-wrap">
            <div class="dp-heading">
                <div class="dp-kicker">Simple et pratique</div>
                <h2>Comment ça marche ?</h2>
                <p>Quelques étapes pour transmettre votre besoin et garder une trace de votre demande.</p>
            </div>
            <div class="dp-steps">
                <article class="dp-step">
                    <div class="dp-step-number">01</div>
                    <h3>Décrivez votre besoin</h3>
                    <p>Précisez le service recherché, le problème rencontré, le lieu et le niveau d'urgence. Ajoutez une photo si elle peut aider.</p>
                </article>
                <article class="dp-step">
                    <div class="dp-step-number">02</div>
                    <h3>Votre demande est prise en charge</h3>
                    <p>Les informations transmises permettent d'orienter votre demande vers le bon interlocuteur et d'organiser la suite.</p>
                </article>
                <article class="dp-step">
                    <div class="dp-step-number">03</div>
                    <h3>Suivez son évolution</h3>
                    <p>Retrouvez les informations de votre demande depuis votre espace client et consultez son état d'avancement.</p>
                </article>
            </div>
        </div>
    </section>

    <?php if (!empty($precisions)): ?>
    <section class="dp-section dp-section--soft">
        <div class="dp-wrap dp-info-layout">
            <div class="dp-heading">
                <div class="dp-kicker">Pour gagner du temps</div>
                <h2>Les informations qui nous aident.</h2>
                <p>Avant de transmettre votre demande, rassemblez si possible quelques détails. Vous pourrez compléter les informations disponibles au moment de la demande.</p>
            </div>
            <div class="dp-checklist">
                <?php foreach ($precisions as $precision): ?>
                <div class="dp-check"><?= ico(ICO_CHECK) ?><span><?= $e($precision) ?></span></div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <section class="dp-section" id="questions">
        <div class="dp-wrap">
            <div class="dp-heading" style="margin-inline:auto;text-align:center">
                <div class="dp-kicker">Questions fréquentes</div>
                <h2>Avant de vous lancer</h2>
                <p>Quelques réponses pour vous aider à faire votre demande en toute simplicité.</p>
            </div>
            <div class="dp-faq">
                <details>
                    <summary>Comment choisir le bon service ?</summary>
                    <p>Choisissez l'intitulé qui se rapproche le plus de votre besoin. Si vous hésitez, expliquez simplement votre situation dans la description de la demande.</p>
                </details>
                <details>
                    <summary>Dois-je connaître la cause exacte du problème ?</summary>
                    <p>Non. Décrivez ce que vous constatez, depuis quand et dans quelles circonstances. Pour une panne, les symptômes sont déjà des informations utiles.</p>
                </details>
                <details>
                    <summary>Puis-je faire une demande depuis mon téléphone ?</summary>
                    <p>Oui. Cette page s'adapte aux téléphones, tablettes et ordinateurs. Vous pouvez accéder à votre espace et transmettre votre demande depuis votre navigateur.</p>
                </details>
                <details>
                    <summary>Comment suivre ma demande ?</summary>
                    <p>Connectez-vous à votre espace client pour retrouver vos demandes et consulter les informations disponibles sur leur avancement.</p>
                </details>
                <details>
                    <summary>Et si le service recherché n'apparaît pas ici ?</summary>
                    <p>Vous pouvez revenir à la liste des domaines ou décrire votre besoin depuis votre espace client afin qu'il soit orienté correctement.</p>
                </details>
            </div>
        </div>
    </section>

    <section class="dp-section" style="padding-top:0">
        <div class="dp-wrap">
            <div class="dp-cta">
                <div class="dp-cta-copy">
                    <h2>Prêt à faire avancer les choses ?</h2>
                    <p>Expliquez-nous ce qu'il vous faut dans le domaine <?= $e($nomDomaine) ?>. Commencez votre demande en quelques étapes.</p>
                </div>
                <a class="dp-btn" href="<?= $e($urlDemande) ?>">Faire ma demande <span aria-hidden="true">→</span></a>
            </div>
        </div>
    </section>
</main>
<?php endif; ?>

<footer class="dp-footer">
    <div class="dp-wrap">
        <div class="dp-footer-grid">
            <div>
                <a href="index.php" class="dp-logo" style="color:#fff">ALLÔ<span> PRO</span></a>
                <p>Un point d'entrée pour organiser vos interventions à Dakar et suivre vos demandes au même endroit.</p>
            </div>
            <div>
                <h3>Explorer</h3>
                <ul>
                    <li><a href="index.php#services">Tous les domaines</a></li>
                    <li><a href="index.php#comment-ca-marche">Comment ça marche</a></li>
                    <li><a href="index.php#abonnement">Formules</a></li>
                    <li><a href="index.php#questions">FAQ</a></li>
                </ul>
            </div>
            <div>
                <h3>Nous contacter</h3>
                <ul>
                    <li><a href="mailto:contact@allopro.sn">contact@allopro.sn</a></li>
                    <li><a href="inscription-partenaire.php">Devenir partenaire</a></li>
                    <li>Dakar, Sénégal</li>
                    <li><a href="<?= $connecte ? 'dashboard.php' : 'connexion.php' ?>">Espace client</a></li>
                </ul>
            </div>
        </div>
        <div class="dp-footer-bottom">
            <span>© <?= date('Y') ?> ALLÔ PRO. Tous droits réservés.</span>
            <span>Des demandes plus simples, un suivi plus clair.</span>
        </div>
    </div>
</footer>
<script>
(() => {
    const nav = document.getElementById('nav');
    if (!nav) return;

    const bouton = nav.querySelector('.nav__menu-toggle');
    const liens = document.getElementById('nav-liens');

    const onScroll = () => {
        nav.classList.toggle(
            'nav--scrolled',
            window.scrollY > 40
        );
    };

    window.addEventListener('scroll', onScroll, {
        passive: true
    });

    onScroll();

    if (!bouton || !liens) return;

    const definirMenu = (ouvert) => {
        nav.classList.toggle('nav--menu-ouvert', ouvert);

        bouton.setAttribute(
            'aria-expanded',
            String(ouvert)
        );

        bouton.setAttribute(
            'aria-label',
            ouvert ? 'Fermer le menu' : 'Ouvrir le menu'
        );
    };

    bouton.addEventListener('click', () => {
        const ouvert =
            bouton.getAttribute('aria-expanded') === 'true';

        definirMenu(!ouvert);
    });

    liens.querySelectorAll('a').forEach((lien) => {
        lien.addEventListener('click', () => {
            definirMenu(false);
        });
    });

    document.addEventListener('click', (event) => {
        if (!nav.contains(event.target)) {
            definirMenu(false);
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            definirMenu(false);
            bouton.focus();
        }
    });
})();
</script>
</body>
</html>
