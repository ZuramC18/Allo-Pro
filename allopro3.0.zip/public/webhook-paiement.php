<?php
require_once __DIR__ . '/../models/Paiement.php';
require_once __DIR__ . '/../models/Demande.php';
require_once __DIR__ . '/../models/Notification.php';
require_once __DIR__ . '/../models/Facture.php';
require_once __DIR__ . '/../includes/audit.php';

$reference = $_GET['reference'] ?? $_POST['reference'] ?? null;

// --- En production : vérifier ici la signature du webhook envoyée par Wave/Orange Money ---
// pour s'assurer que la requête vient bien d'eux et n'a pas été forgée par n'importe qui.

if ($reference) {
    $paiementModel = new Paiement();
    $paiement = $paiementModel->getByReference($reference);

    if ($paiement) {
        if ($paiement['statut'] === 'en_attente' && $paiementModel->marquerValide($reference)) {
            journaliser('paiement.valide', 'paiement', $paiement['id'], $reference, number_format($paiement['montant'], 0, ',', ' ') . ' F (' . $paiement['methode'] . ')', ACTEUR_SYSTEME);
            $demande = (new Demande())->getById((int) $paiement['demande_id']);
            if ($demande) {
                (new Notification())->create(
                    (int) $demande['client_id'],
                    "Votre paiement pour la demande {$demande['numero_dossier']} a été confirmé : " . number_format((float) $paiement['montant'], 0, ',', ' ') . ' FCFA.',
                    '/allopro/views/client/detail-demande.php?id=' . (int) $demande['id']
                );
            }
        }
        $paiement = $paiementModel->getByReference($reference);
        if ($paiement && $paiement['statut'] === 'valide') {
            try {
                (new Facture())->genererEtEnvoyerPourReference('intervention', $reference);
            } catch (Throwable $e) {
                error_log('Facture non generee pour la reference ' . $reference . ' : ' . $e->getMessage());
            }
        }
    }
}

if (isset($_GET['depuis_client'])) {
    session_start();
    header("Location: /allopro/views/client/paiement-succes.php?reference=" . urlencode($reference));
    exit;
}

http_response_code(200);
echo "OK";