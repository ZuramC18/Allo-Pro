<?php
require_once __DIR__ . '/../includes/auth.php';
verifierConnexion();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

if (($_SESSION['role'] ?? '') !== 'client') {
    http_response_code(403);
    echo json_encode(['erreur' => 'Accès réservé aux clients.'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    require_once __DIR__ . '/../models/Notification.php';

    $notificationModel = new Notification();
    $clientId = (int) $_SESSION['user_id'];
    echo json_encode([
        'non_lues' => $notificationModel->compterNonLues($clientId),
        'notifications' => $notificationModel->getDernieresPourUtilisateur($clientId),
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $exception) {
    error_log('Notifications client : ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['erreur' => 'Impossible de récupérer les notifications.'], JSON_UNESCAPED_UNICODE);
}
