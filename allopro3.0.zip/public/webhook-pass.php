<?php
require_once __DIR__ . '/../models/Abonnement.php';
require_once __DIR__ . '/../models/Facture.php';

$reference = $_GET['reference'] ?? $_POST['reference'] ?? null;

if ($reference) {
    $abonnementModel = new Abonnement();
    $achat = $abonnementModel->getPassAchatByReference($reference);
    if ($achat && $achat['statut'] === 'en_attente') {
        $abonnementModel->activerPassParReference($reference);
        $achat = $abonnementModel->getPassAchatByReference($reference);
    }
    if ($achat && $achat['statut'] !== 'en_attente') {
        try {
            (new Facture())->genererEtEnvoyerPourReference('pass', $reference);
        } catch (Throwable $e) {
            error_log('Facture non generee pour la reference Pass ' . $reference . ' : ' . $e->getMessage());
        }
    }
}

if (isset($_GET['depuis_client'])) {
    session_start();
    header("Location: /allopro/views/client/pass.php?succes=1");
    exit;
}

http_response_code(200);
echo "OK";