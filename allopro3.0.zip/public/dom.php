<?php
/**
 * Fonctions partagées par index.php et domaine.php
 * (icônes, photos, slug, contenu éditorial des domaines).
 */

// --- Icônes SVG (trait, couleur héritée du texte) ---
const ICO_PIN   = '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>';
const ICO_MSG   = '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>';
const ICO_PHONE = '<rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M11 18.5h2"/>';
const ICO_CHEVRON = '<path d="M9 5l7 7-7 7"/>';
const ICO_CHECK = '<path d="M5 12.5l4.5 4.5L19 7.5"/>';

function ico(string $chemins): string {
    return '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $chemins . '</svg>';
}

function iconeCategorie(string $nom): string {
    // Premier motif qui correspond = icône utilisée (du plus précis au plus général)
    $icones = [
        '/auto|carross|vidange|v[ée]hic/iu' => '<path d="M4 15v-3l2-5h12l2 5v3"/><rect x="3" y="15" width="18" height="4" rx="1"/><path d="M7 17h.01M17 17h.01"/>',
        '/moto|scooter|deux-roues/iu'       => '<circle cx="6" cy="16" r="3"/><circle cx="18" cy="16" r="3"/><path d="M6 16l3-7h4l3 7M9 9H7M13 9l2-3h2"/>',
        '/pneu/iu'                          => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M12 3v5.5M12 15.5V21M3 12h5.5M15.5 12H21"/>',
        '/[ée]lectr/iu'                     => '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
        '/plomb/iu'                         => '<path d="M12 2.5S5 10 5 14.5a7 7 0 0 0 14 0C19 10 12 2.5 12 2.5z"/>',
        '/clim|froid|cong[ée]l|r[ée]frig/iu'=> '<path d="M12 2v20M4.2 7l15.6 10M4.2 17 19.8 7M9 3.5l3 2.5 3-2.5M9 20.5l3-2.5 3 2.5"/>',
        '/imprim/iu'                        => '<path d="M7 9V3h10v6M7 17H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><rect x="7" y="14" width="10" height="7"/>',
        '/wi-?fi|r[ée]seau/iu'              => '<path d="M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0M12 20h.01"/>',
        '/vid[ée]osurv|cam[ée]ra/iu'        => '<rect x="2" y="6" width="14" height="12" rx="2"/><path d="M16 10l6-3v10l-6-3"/>',
        '/t[ée]l[ée]phone|mobile/iu'        => ICO_PHONE,
        '/informat|ordi|digital/iu'         => '<rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 20h20"/>',
        '/juridi|avocat|conseil/iu'         => '<path d="M12 3v18M5 21h14M5 7h14M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0z"/>',
        '/traduc|r[ée]dac|d[ée]marche|document|admin/iu' => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
        '/s[ée]curit|gardien|personnes/iu'  => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
        '/serrur/iu'                        => '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
        '/menuis/iu'                        => '<path d="M3 21V3l18 18z"/><path d="M7 16v-2M11 18v-2"/>',
        '/peintur/iu'                       => '<rect x="4" y="3" width="14" height="5" rx="1"/><path d="M18 5h2v6H11v3"/><rect x="9.5" y="14" width="3" height="7" rx="1"/>',
        '/carrel|[ée]tanch/iu'              => '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 12h18M12 3v18"/>',
        '/ma[çc]onn/iu'                     => '<rect x="2" y="6" width="20" height="12" rx="1"/><path d="M2 12h20M8 6v6M16 12v6"/>',
        '/vitr/iu'                          => '<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M8 15l6-6M9 18l8-8"/>',
        '/jardin/iu'                        => '<path d="M5 21c0-9 5-15 15-16 0 10-6 15-15 16zM5 21l8-8"/>',
        '/d[ée]m[ée]nag/iu'                 => '<path d="M2 6h11v10H2zM13 9h4l4 4v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
        '/enfant/iu'                        => '<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5a4.5 4.5 0 0 0 7 0M9 9.5h.01M15 9.5h.01"/>',
        '/m[ée]nage/iu'                     => '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
        '/[âa]g[ée]e|senior|aide/iu'        => '<path d="M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z"/>',
        '/habitat|maison/iu'                => '<path d="M3 11l9-8 9 8M5 10v10h14V10M10 20v-6h4v6"/>',
    ];
    foreach ($icones as $motif => $dessin) {
        if (preg_match($motif, $nom)) return ico($dessin);
    }
    // Par défaut (petits travaux, autres) : une clé à molette
    return ico('<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>');
}

// --- Photo de fond par domaine (Pexels, libre d'usage) ---
// Les domaines sans photo reçoivent un fond dégradé + icône.
function photoDomaine(string $nom, int $largeur = 900): ?string {
    $photos = [
        '/habitat/iu'                    => '6419128',
        '/digital|informat/iu'           => '2136243',
        '/froid|clim/iu'                 => '12741843',
        '/auto|moto|deux-roues/iu'       => '10490609',
        '/juridi|admin/iu'               => '6077447',
        '/personnes|biens|s[ée]curit/iu' => '31584595',
    ];
    foreach ($photos as $motif => $id) {
        if (preg_match($motif, $nom)) return "https://images.pexels.com/photos/$id/pexels-photo-$id.jpeg?auto=compress&w=$largeur&dpr=1";
    }
    return null;
}


// --- Domaines de secours si la base est indisponible ---
function domainesParDefaut(): array {
    return [
        ['nom' => 'Auto/Deux-Roues',     'nb' => 5],
        ['nom' => 'Digital',             'nb' => 6],
        ['nom' => 'Froid/Climatisation', 'nb' => 5],
        ['nom' => 'Habitat',             'nb' => 9],
        ['nom' => 'Juridique/Admin',     'nb' => 4],
        ['nom' => 'Personnes & Biens',   'nb' => 5],
    ];
}

// --- Courte description d'un service, d'après son nom ---
function descriptionService(string $nom): string {
    $descriptions = [
        '/plomb/iu'                    => 'Fuites, robinetterie, sanitaires, chauffe-eau.',
        '/[ée]lectr/iu'                => 'Pannes, prises, tableau électrique, éclairage.',
        '/serrur/iu'                   => 'Porte bloquée, changement de serrure, clés.',
        '/menuis/iu'                   => 'Portes, fenêtres, placards, réparations en bois.',
        '/peintur/iu'                  => 'Murs, plafonds, boiseries, remise à neuf.',
        '/carrel|[ée]tanch/iu'         => 'Pose de carrelage, joints, traitement des infiltrations.',
        '/ma[çc]onn/iu'                => 'Murs, fissures, petites constructions, réparations.',
        '/vitr/iu'                     => 'Remplacement de vitres, miroirs, baies vitrées.',
        '/jardin/iu'                   => 'Entretien, taille, nettoyage des espaces extérieurs.',
        '/vidange/iu'                  => 'Vidange, filtres et entretien courant du véhicule.',
        '/carross/iu'                  => 'Chocs, rayures, retouches de carrosserie.',
        '/pneu/iu'                     => 'Crevaison, changement, équilibrage.',
        '/moto|scooter|deux-roues/iu'  => 'Entretien et dépannage des deux-roues.',
        '/v[ée]hic|d[ée]pannage auto/iu' => 'Panne, batterie, problème de démarrage.',
        '/wi-?fi|r[ée]seau/iu'         => 'Installation, couverture Wi-Fi, connexion instable.',
        '/vid[ée]osurv|cam[ée]ra/iu'   => 'Pose et réglage de caméras, accès à distance.',
        '/imprim/iu'                   => 'Pannes, configuration, partage en réseau.',
        '/t[ée]l[ée]phone|mobile/iu'   => 'Écran, batterie, configuration, transfert de données.',
        '/informat|ordi/iu'            => 'Lenteurs, pannes, virus, installation de logiciels.',
        '/digital|site/iu'             => 'Site web, réseaux sociaux, outils en ligne.',
        '/r[ée]frig|cong[ée]l/iu'      => 'Pannes de froid, thermostat, joints, compresseur.',
        '/froid/iu'                    => 'Chambres froides et vitrines réfrigérées.',
        '/clim/iu'                     => 'Installation, entretien, recharge de gaz, pannes.',
        '/juridi|conseil/iu'           => 'Un avis clair sur un contrat, un litige, un droit.',
        '/traduc/iu'                   => 'Actes, certificats et documents officiels.',
        '/r[ée]dac/iu'                 => 'Courriers, attestations, contrats, demandes.',
        '/d[ée]marche|admin/iu'        => 'Dossiers, pièces à fournir, suivi auprès des administrations.',
        '/s[ée]curit|gardien/iu'       => 'Gardiennage de domicile, de chantier ou de commerce.',
        '/enfant/iu'                   => 'Garde régulière ou ponctuelle.',
        '/m[ée]nage/iu'                => 'Entretien du domicile ou des locaux.',
        '/d[ée]m[ée]nag/iu'            => 'Transport et manutention, petits et grands volumes.',
        '/[âa]g[ée]e|senior|aide/iu'   => 'Présence, courses, accompagnement au quotidien.',
    ];
    foreach ($descriptions as $motif => $texte) {
        if (preg_match($motif, $nom)) return $texte;
    }
    return '';
}

// --- Contenu éditorial d'un domaine (accroche, services par défaut, exemples...) ---
function contenuDomaine(string $nom): array {
    $domaines = [
        '/auto|moto|deux-roues/iu' => [
            'accent'   => '#d9480f',
            'accroche' => 'Votre véhicule repart, vous gardez votre journée.',
            'intro'    => 'Vidange, carrosserie, pneus, scooter en panne : décrivez le problème, un conseiller organise la mise en relation avec un professionnel.',
            'meta'     => 'Vidange, carrosserie, pneus, moto et scooter à Dakar : décrivez votre besoin et suivez votre demande en ligne.',
            'services' => ['Vidange et entretien', 'Carrosserie', 'Pneus', 'Moto et scooter', 'Dépannage véhicule'],
            'messages' => [
                'Ma voiture fume au démarrage et je dois aller travailler demain.',
                'Il me faut une vidange avant un long trajet ce week-end.',
                'Mon scooter a une roue crevée, il est resté devant chez moi.',
            ],
            'precisions' => ['La marque, le modèle et l’année du véhicule', 'Ce que vous observez : bruit, fumée, voyant allumé', 'Où se trouve le véhicule, et s’il roule encore', 'Une photo de la panne ou du voyant, si vous en avez une'],
        ],
        '/digital|informat/iu' => [
            'accent'   => '#3b5bdb',
            'accroche' => 'Une panne informatique ne doit pas arrêter votre activité.',
            'intro'    => 'Ordinateur, Wi-Fi, caméras, imprimante, téléphone : expliquez ce qui ne marche plus, nous organisons l’intervention.',
            'meta'     => 'Dépannage informatique, Wi-Fi, vidéosurveillance et téléphonie à Dakar : décrivez votre besoin et suivez-le en ligne.',
            'services' => ['Dépannage informatique', 'Wi-Fi et réseau', 'Vidéosurveillance', 'Imprimantes', 'Téléphone mobile', 'Site web et présence digitale'],
            'messages' => [
                'Le Wi-Fi coupe toute la journée dans mon commerce.',
                'Mon ordinateur ne démarre plus et j’ai des fichiers importants dessus.',
                'Je voudrais installer deux caméras devant la boutique.',
            ],
            'precisions' => ['Le type d’appareil et sa marque', 'Le message d’erreur ou le symptôme exact', 'Depuis quand le problème existe', 'Si des données importantes sont en jeu'],
        ],
        '/froid|clim/iu' => [
            'accent'   => '#0b7285',
            'accroche' => 'Du froid qui fonctionne, même en pleine chaleur.',
            'intro'    => 'Climatiseur qui goutte, congélateur tiède, chambre froide en panne : une demande suffit pour lancer l’intervention.',
            'meta'     => 'Climatisation, réfrigérateur, congélateur et chambre froide à Dakar : décrivez la panne et suivez votre demande.',
            'services' => ['Climatisation', 'Réfrigérateur', 'Congélateur', 'Chambre froide', 'Entretien et recharge de gaz'],
            'messages' => [
                'Le climatiseur du salon goutte et ne refroidit presque plus.',
                'Mon congélateur est tiède, j’ai peur de perdre mes produits.',
                'Nous voulons un entretien de nos quatre splits avant la saison chaude.',
            ],
            'precisions' => ['Le type d’appareil, la marque et la puissance si vous la connaissez', 'Ce que vous constatez : fuite d’eau, bruit, plus de froid', 'Si des produits sont en train de se perdre (marquez l’urgence)', 'Le nombre d’appareils concernés'],
        ],
        '/habitat|maison/iu' => [
            'accent'   => '#2b8a3e',
            'accroche' => 'Les soucis de la maison, sans courir après un artisan.',
            'intro'    => 'Plomberie, électricité, serrurerie, peinture, maçonnerie : une seule demande, un seul suivi.',
            'meta'     => 'Plomberie, électricité, serrurerie, peinture et petits travaux à Dakar : décrivez votre besoin et suivez votre demande.',
            'services' => ['Plomberie', 'Électricité', 'Serrurerie', 'Menuiserie', 'Peinture', 'Carrelage et étanchéité', 'Maçonnerie', 'Vitrerie', 'Jardinage'],
            'messages' => [
                'Fuite sous l’évier de la cuisine, l’eau coule depuis ce matin.',
                'Le disjoncteur saute dès que j’allume le four.',
                'La serrure de la porte d’entrée est bloquée, je suis dehors.',
            ],
            'precisions' => ['La pièce concernée et ce que vous constatez', 'Depuis quand le problème est présent', 'Une photo, surtout pour une fuite ou une fissure', 'L’adresse et un repère du quartier'],
        ],
        '/juridi|admin/iu' => [
            'accent'   => '#6741d9',
            'accroche' => 'Des démarches claires, sans file d’attente.',
            'intro'    => 'Conseil, rédaction, traduction, dossiers administratifs : dites-nous ce qu’il vous faut, nous organisons la suite.',
            'meta'     => 'Conseil juridique, rédaction, traduction et démarches administratives à Dakar : déposez votre demande en ligne.',
            'services' => ['Conseil juridique', 'Rédaction de documents', 'Traduction', 'Démarches administratives'],
            'messages' => [
                'Je dois traduire mon acte de naissance en anglais.',
                'J’ai besoin d’aide pour monter un dossier administratif.',
                'Je voudrais un avis sur mon contrat de bail avant de signer.',
            ],
            'precisions' => ['Le type de document ou de démarche', 'La date limite, s’il y en a une', 'La langue de départ et d’arrivée pour une traduction', 'Les pièces dont vous disposez déjà'],
        ],
        '/personnes|biens|s[ée]curit/iu' => [
            'accent'   => '#c2255c',
            'accroche' => 'Des mains de confiance pour vos proches et vos biens.',
            'intro'    => 'Gardiennage, garde d’enfants, aide aux seniors, ménage, déménagement : précisez vos horaires et vos attentes.',
            'meta'     => 'Gardiennage, garde d’enfants, aide aux seniors, ménage et déménagement à Dakar : déposez votre demande en ligne.',
            'services' => ['Sécurité et gardiennage', 'Garde d’enfants', 'Aide aux seniors', 'Ménage', 'Déménagement'],
            'messages' => [
                'Je cherche quelqu’un pour garder mes enfants deux soirs par semaine.',
                'J’ai besoin d’un gardien pour mon chantier pendant un mois.',
                'Aide demandée pour un déménagement samedi, avec un camion.',
            ],
            'precisions' => ['Les jours et horaires souhaités', 'La durée : ponctuelle ou régulière', 'Le lieu et le nombre de personnes concernées', 'Toute attente particulière (langue, expérience, matériel)'],
        ],
    ];

    foreach ($domaines as $motif => $contenu) {
        if (preg_match($motif, $nom)) return $contenu;
    }
    return [
        'accent'     => '#d9480f',
        'accroche'   => 'Décrivez votre besoin, nous organisons la suite.',
        'intro'      => 'Une demande claire, un conseiller qui la prend en charge, un suivi en ligne.',
        'meta'       => 'Déposez une demande d’intervention à Dakar et suivez-la depuis votre espace client.',
        'services'   => [],
        'messages'   => ['J’ai un besoin urgent et je ne sais pas qui appeler.'],
        'precisions' => ['Ce que vous constatez', 'L’adresse de l’intervention', 'Le niveau d’urgence'],
    ];
}