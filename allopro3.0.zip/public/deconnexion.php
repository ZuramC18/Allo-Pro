<?php
session_start();
if (in_array($_SESSION['role'] ?? '', ['conseiller', 'coordinateur', 'finance'], true) && !empty($_SESSION['user_id'])) {
    require_once __DIR__ . '/../models/User.php';
    require_once __DIR__ . '/../models/ActiviteConseiller.php';
    $userModel = new User();
    $conseillerId = (int) $_SESSION['user_id'];
    $presenceAvant = $userModel->getPresenceEquipe($conseillerId);
    if (($presenceAvant['presence_status'] ?? 'offline') !== 'offline') {
        ActiviteConseiller::enregistrer('presence', $conseillerId, 'offline', 'Statut modifié : ' . ($presenceAvant['presence_status'] === 'pause' ? 'En pause' : 'En ligne') . ' → Hors ligne');
    }
    $userModel->definirPresenceEquipe($conseillerId, 'offline');
}
session_unset();
session_destroy();
header("Location: index.php");
exit;