<?php
require __DIR__ . '/api-reponses-rapides.php';
