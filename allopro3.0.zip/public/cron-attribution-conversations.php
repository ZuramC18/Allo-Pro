<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Planifier ce script avec PHP CLI à une fréquence d’une minute.
require_once __DIR__ . '/../models/ConversationAttribution.php';

$resultat = (new ConversationAttribution())->traiterFile();
if (!$resultat['active']) {
    fwrite(STDOUT, "Attribution déjà en cours; exécution ignorée.\n");
    exit(0);
}

fwrite(
    STDOUT,
    sprintf(
        "Conversations transférées: %d; attribuées: %d.\n",
        $resultat['transferees'],
        count($resultat['attribuees'])
    )
);
