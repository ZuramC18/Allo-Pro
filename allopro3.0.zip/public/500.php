<?php
http_response_code(500);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Erreur serveur — ALLÔ PRO</title>
    <link rel="icon" type="image/png" href="images/icon.png">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@700;800&family=Inter:wght@400;500;600&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: #12181B;
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 24px;
        }

        .conteneur { max-width: 440px; }

        .code {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 800;
            font-size: 96px;
            line-height: 1;
            color: #FF7A30;
            margin-bottom: 8px;
        }

        h1 {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 12px;
        }

        p {
            color: rgba(255,255,255,0.6);
            font-size: 14.5px;
            line-height: 1.6;
            margin-bottom: 32px;
        }

        .actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }

        .btn {
            padding: 13px 26px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
        }

        .btn-primaire { background: #FF7A30; color: white; }
        .btn-secondaire { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.2); color: white; }

        .logo {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 800;
            font-size: 15px;
            color: rgba(255,255,255,0.4);
            margin-top: 40px;
        }

        .logo span { color: #FF7A30; }
    </style>
    <?php include __DIR__ . '/../includes/event-theme-head.php'; ?>
</head>
<body>
    <div class="conteneur">
        <div class="code">500</div>
        <h1>Une erreur est survenue</h1>
        <p>Quelque chose s'est mal passé de notre côté. Réessayez dans un instant — si le problème persiste, contactez le support.</p>

        <div class="actions">
            <a href="/allopro/public/index.php" class="btn btn-primaire">Retour à l'accueil</a>
            <a href="mailto:contact@allopro.sn" class="btn btn-secondaire">Contacter le support</a>
        </div>

        <div class="logo">ALLÔ<span> PRO</span></div>
    </div>
</body>
</html>