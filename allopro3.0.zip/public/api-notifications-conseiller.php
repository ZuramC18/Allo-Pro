<?php
require_once __DIR__ . '/../includes/auth.php';
verifierAcces('demandes');
verifierAcces('messagerie');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

try {
    require_once __DIR__ . '/../models/Demande.php';
    require_once __DIR__ . '/../models/Message.php';

    $conseillerId = (int) $_SESSION['user_id'];
    echo json_encode([
        'demandes_nouvelles' => (new Demande())->compterNouvelles(),
        'messages_non_lus' => (new Message())->compterNonLusPourConseiller($conseillerId),
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $exception) {
    error_log('Notifications conseiller : ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['erreur' => 'Impossible de récupérer les notifications du conseiller.'], JSON_UNESCAPED_UNICODE);
}
