<?php
require_once __DIR__ . '/../models/Abonnement.php';
require_once __DIR__ . '/../models/Facture.php';
require_once __DIR__ . '/../models/Audit.php';
require_once __DIR__ . '/../includes/audit.php';

$reference = $_GET['reference'] ?? $_POST['reference'] ?? null;

if ($reference) {
    $abonnementModel = new Abonnement();
    $abonnement = $abonnementModel->getByReference($reference);

    if ($abonnement && $abonnement['statut'] === 'en_attente') {
        if ($abonnementModel->activerParReference($reference)) {
            journaliser('abonnement.active', 'abonnement', $abonnement['id'], $reference, 'Client #' . $abonnement['client_id'], ACTEUR_SYSTEME);
        }
        $abonnement = $abonnementModel->getByReference($reference);
    }
    if ($abonnement && $abonnement['statut'] !== 'en_attente') {
        try {
            (new Facture())->genererEtEnvoyerPourReference('abonnement', $reference);
        } catch (Throwable $e) {
            error_log('Facture non generee pour la reference abonnement ' . $reference . ' : ' . $e->getMessage());
        }
    }
}

if (isset($_GET['depuis_client'])) {
    session_start();
    header("Location: /allopro/views/client/abonnement.php?succes=1");
    exit;
}

http_response_code(200);
echo "OK";