<?php
require_once __DIR__ . '/../includes/auth.php';
verifierConnexion();

$role = $_SESSION['role'] ?? '';
$module = match ($role) {
    'admin', 'coordinateur' => 'interventions',
    'conseiller' => 'demandes',
    default => null,
};
if ($module === null || !peut($module)) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['erreur' => 'Accès refusé.'], JSON_UNESCAPED_UNICODE);
    exit;
}

require_once __DIR__ . '/../models/AjustementCreneauAutomatique.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
echo json_encode(
    ['count' => (new AjustementCreneauAutomatique())->compterATraiter()],
    JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
);
