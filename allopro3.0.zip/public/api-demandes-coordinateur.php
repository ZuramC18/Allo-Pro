<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['coordinateur', 'admin']);
require_once __DIR__ . '/../models/AttributionDemandeCoordinateur.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

try {
    echo json_encode(
        ['nouvelles' => (new AttributionDemandeCoordinateur())->compterEnAttente()],
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
} catch (Throwable $exception) {
    error_log('Comptage demandes coordinateur : ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['erreur' => 'Impossible de récupérer le nombre de nouvelles demandes.'], JSON_UNESCAPED_UNICODE);
}
