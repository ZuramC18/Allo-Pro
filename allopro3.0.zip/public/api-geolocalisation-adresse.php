<?php
require_once __DIR__ . '/../includes/auth.php';
verifierRole(['client']);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    http_response_code(405);
    echo json_encode(['erreur' => 'Méthode non autorisée.']);
    exit;
}

$donnees = json_decode(file_get_contents('php://input'), true);
$csrf = is_array($donnees) && is_string($donnees['csrf'] ?? null) ? $donnees['csrf'] : '';
if (empty($_SESSION['csrf_adresses']) || !hash_equals($_SESSION['csrf_adresses'], $csrf)) {
    http_response_code(403);
    echo json_encode(['erreur' => 'La session a expiré. Rechargez la page puis réessayez.']);
    exit;
}

$maintenant = time();
$appelsRecents = array_values(array_filter(
    $_SESSION['appels_geocodage_adresse'] ?? [],
    static fn($horodatage): bool => is_int($horodatage) && $horodatage > $maintenant - 60
));
if (count($appelsRecents) >= 5) {
    http_response_code(429);
    echo json_encode(['erreur' => 'Trop de recherches de position. Attendez une minute avant de réessayer.']);
    exit;
}
$appelsRecents[] = $maintenant;
$_SESSION['appels_geocodage_adresse'] = $appelsRecents;

$latitude = is_array($donnees) ? filter_var($donnees['latitude'] ?? null, FILTER_VALIDATE_FLOAT) : false;
$longitude = is_array($donnees) ? filter_var($donnees['longitude'] ?? null, FILTER_VALIDATE_FLOAT) : false;
if ($latitude === false || $longitude === false || !is_finite((float) $latitude) || !is_finite((float) $longitude)
    || $latitude < 12 || $latitude > 17 || $longitude < -18 || $longitude > -11) {
    http_response_code(422);
    echo json_encode(['erreur' => 'La position reçue est invalide ou située hors du Sénégal.']);
    exit;
}

if (!function_exists('curl_init')) {
    error_log('[géolocalisation adresse] Extension cURL indisponible.');
    http_response_code(503);
    echo json_encode(['erreur' => 'Le service de localisation est temporairement indisponible.']);
    exit;
}

$cacheDirectory = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'allopro-nominatim-cache';
if (!is_dir($cacheDirectory) && !mkdir($cacheDirectory, 0700, true) && !is_dir($cacheDirectory)) {
    error_log('[géolocalisation adresse] Impossible de créer le répertoire de cache.');
    http_response_code(503);
    echo json_encode(['erreur' => 'Le service de localisation est temporairement indisponible.']);
    exit;
}

$cacheCle = hash('sha256', number_format((float) $latitude, 5, '.', '') . ',' . number_format((float) $longitude, 5, '.', ''));
$cacheFichier = $cacheDirectory . DIRECTORY_SEPARATOR . $cacheCle . '.json';
$lireCache = static function () use ($cacheFichier): ?array {
    if (!is_file($cacheFichier)) {
        return null;
    }
    $dateModification = filemtime($cacheFichier);
    $contenu = file_get_contents($cacheFichier);
    if ($dateModification === false || $dateModification <= time() - 86400 || !is_string($contenu)) {
        return null;
    }
    $resultat = json_decode($contenu, true);
    return is_array($resultat) && is_array($resultat['address'] ?? null) ? $resultat : null;
};
$geocodage = $lireCache();
$erreurGeocodage = null;
$statutErreurGeocodage = 502;

if (!is_array($geocodage)) {
    $verrou = fopen($cacheDirectory . DIRECTORY_SEPARATOR . 'nominatim.lock', 'c');
    if ($verrou === false || !flock($verrou, LOCK_EX)) {
        if (is_resource($verrou)) {
            fclose($verrou);
        }
        error_log('[géolocalisation adresse] Impossible d’acquérir le verrou global Nominatim.');
        $erreurGeocodage = 'Le service de localisation est temporairement indisponible. Réessayez ou renseignez votre adresse manuellement.';
        $statutErreurGeocodage = 503;
    } else {
        try {
            $geocodage = $lireCache();
            if (!is_array($geocodage)) {
                $dernierAppelFichier = $cacheDirectory . DIRECTORY_SEPARATOR . 'dernier-appel';
                $dernierAppelContenu = is_file($dernierAppelFichier)
                    ? file_get_contents($dernierAppelFichier)
                    : '0';
                $dernierAppel = is_string($dernierAppelContenu) ? (float) $dernierAppelContenu : 0.0;
                $attenteMicrosecondes = 1000000 - (int) ((microtime(true) - $dernierAppel) * 1000000);
                if ($attenteMicrosecondes > 0) {
                    usleep($attenteMicrosecondes);
                }
                if (file_put_contents($dernierAppelFichier, (string) microtime(true), LOCK_EX) === false) {
                    error_log('[géolocalisation adresse] Impossible de mettre à jour la limite de débit Nominatim.');
                    $erreurGeocodage = 'Le service de localisation est temporairement indisponible. Réessayez ou renseignez votre adresse manuellement.';
                    $statutErreurGeocodage = 503;
                } else {
                    $url = 'https://nominatim.openstreetmap.org/reverse?' . http_build_query([
                        'lat' => number_format((float) $latitude, 7, '.', ''),
                        'lon' => number_format((float) $longitude, 7, '.', ''),
                        'format' => 'jsonv2',
                        'addressdetails' => 1,
                        'zoom' => 18,
                        'accept-language' => 'fr',
                    ]);
                    $requete = curl_init($url);
                    if ($requete === false) {
                        error_log('[géolocalisation adresse] Impossible d’initialiser cURL pour Nominatim.');
                        $erreurGeocodage = 'Le service de localisation est temporairement indisponible.';
                        $statutErreurGeocodage = 503;
                    } else {
                        curl_setopt_array($requete, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_CONNECTTIMEOUT => 4,
                            CURLOPT_TIMEOUT => 8,
                            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                            CURLOPT_USERAGENT => 'ALLO-PRO/1.0 (https://allo-pro.com; geolocalisation-adresses)',
                            CURLOPT_HTTPHEADER => ['Accept: application/json'],
                        ]);
                        $corps = curl_exec($requete);
                        $codeHttp = (int) curl_getinfo($requete, CURLINFO_HTTP_CODE);
                        $erreurCurl = curl_error($requete);
                        curl_close($requete);

                        if (!is_string($corps) || $codeHttp !== 200) {
                            error_log('[géolocalisation adresse] Échec HTTP Nominatim: ' . ($erreurCurl !== '' ? $erreurCurl : (string) $codeHttp));
                            $erreurGeocodage = 'OpenStreetMap n’a pas pu convertir votre position en adresse. Réessayez ou renseignez-la manuellement.';
                        } else {
                            $geocodage = json_decode($corps, true);
                            if (!is_array($geocodage) || empty($geocodage['address']) || !is_array($geocodage['address'])) {
                                error_log('[géolocalisation adresse] Réponse Nominatim invalide ou sans adresse.');
                                $erreurGeocodage = 'Aucune adresse n’a été trouvée à cette position. Vous pouvez compléter le formulaire manuellement.';
                                $statutErreurGeocodage = 404;
                            } elseif (file_put_contents($cacheFichier, json_encode($geocodage, JSON_UNESCAPED_UNICODE), LOCK_EX) === false) {
                                error_log('[géolocalisation adresse] Impossible de mettre en cache la réponse Nominatim.');
                            }
                        }
                    }
                }
            }
        } finally {
            flock($verrou, LOCK_UN);
            fclose($verrou);
        }
    }
}

if ($erreurGeocodage !== null) {
    http_response_code($statutErreurGeocodage);
    echo json_encode(['erreur' => $erreurGeocodage]);
    exit;
}

$composants = $geocodage['address'];
$villes = array_merge(
    array_map(static fn($cle): string => (string) ($composants[$cle] ?? ''), ['city', 'town', 'village', 'municipality']),
    array_map(static fn($cle): string => (string) ($composants[$cle] ?? ''), ['county', 'state_district', 'state'])
);
$quartiers = array_map(
    static fn($cle): string => (string) ($composants[$cle] ?? ''),
    ['neighbourhood', 'suburb', 'quarter', 'city_district', 'hamlet', 'residential']
);
$nomAdresse = trim((string) ($geocodage['display_name'] ?? ''));
if ($nomAdresse === '') {
    error_log('[géolocalisation adresse] Réponse Nominatim sans adresse formatée.');
    http_response_code(502);
    echo json_encode(['erreur' => 'L’adresse n’a pas pu être identifiée. Vous pouvez la renseigner manuellement.']);
    exit;
}

echo json_encode([
    'adresse' => mb_substr($nomAdresse, 0, 500),
    'latitude' => (float) $latitude,
    'longitude' => (float) $longitude,
    'villes' => array_values(array_unique(array_filter($villes))),
    'quartiers' => array_values(array_unique(array_filter($quartiers))),
    'attribution' => '© OpenStreetMap contributors',
], JSON_UNESCAPED_UNICODE);
